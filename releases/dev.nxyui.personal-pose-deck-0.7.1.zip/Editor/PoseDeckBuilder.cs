using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using nadena.dev.modular_avatar.core;
using UnityEditor;
using UnityEditor.Animations;
using UnityEditor.SceneManagement;
using UnityEngine;
using VRC.SDK3.Avatars.Components;
using VRC.SDK3.Avatars.ScriptableObjects;
using Object = UnityEngine.Object;
using Control = VRC.SDK3.Avatars.ScriptableObjects.VRCExpressionsMenu.Control;

namespace PersonalPoseDeck
{
    internal static class PoseDeckBuilder
    {
        internal static readonly string[] CategoryNames = { "앉기", "눕기", "서기", "기타" };
        private static readonly string[] SlotStates = { "Left", "Right", "Left Init", "Right Init" };
        private const string Emote = "VRCEmote";
        private const string Float = "Go/Float";
        private const string PoseMachine = "VRCEmote 210 -253";
        private const string GeneratedBaseName = "PoseDeckBase.controller";
        private const string GeneratedMenuName = "PoseDeckInstaller.asset";
        private const string ExistingInstallationName = "PoseDeckExistingInstallation.asset";
        internal static readonly string[] VendorRoots = { "Assets/GoGo/GoLoco/", "Packages/gogoloco/Runtime/GoGo/GoLoco/" };
        private static readonly string[] VendorPoseMenus =
        {
            "GoMenuPoseFloor", "GoMenuPoseProne", "GoMenuPoseSit",
            "SubMenuPoses/GoMenuPoseFloor+", "SubMenuPoses/GoMenuPoseLaydown+", "SubMenuPoses/GoMenuPoseSit+"
        };

        internal sealed class Target
        {
            public ModularAvatarMergeAnimator Base;
            public ModularAvatarMenuInstaller Menu;
        }

        private sealed class Slot
        {
            public int Number;
            public AnimatorState[] States;
            public BlendTree Tree;
            public bool Blank;
            public AnimationClip[] Clips;
        }

        private sealed class Assignment
        {
            public int Number;
            public Control NativeControl;
        }

        private sealed class Plan
        {
            public Assignment[] Rows;
            public int NativeCount;
            public int CustomCapacity;
            public int BlankCapacity;
        }

        internal static Target GetTarget(GameObject go)
        {
            if (!go || !go.scene.IsValid() || EditorUtility.IsPersistent(go) ||
                !go.GetComponentInParent<VRCAvatarDescriptor>(true))
                throw new InvalidOperationException("Hierarchy에서 아바타 아래의 GoGoLoco MA 오브젝트를 선택해 주세요.");
            return GetBindings(go);
        }

        internal static Target GetBindings(GameObject go)
        {
            var bases = go.GetComponents<ModularAvatarMergeAnimator>()
                .Where(x => x.enabled && x.layerType == VRCAvatarDescriptor.AnimLayerType.Base).ToArray();
            var installers = go.GetComponents<ModularAvatarMenuInstaller>().Where(x => x.enabled).ToArray();
            if (bases.Length != 1 || installers.Length != 1)
                throw new InvalidOperationException("활성 MA Merge Animator (Base)와 MA Menu Installer가 하나씩 붙은 GoGoLoco 오브젝트를 선택해 주세요.");
            return new Target { Base = bases[0], Menu = installers[0] };
        }

        private static bool IsGenerated(AnimatorController controller, VRCExpressionsMenu menu) =>
            (controller && Path.GetFileName(AssetDatabase.GetAssetPath(controller)) == GeneratedBaseName) ||
            (menu && Path.GetFileName(AssetDatabase.GetAssetPath(menu)) == GeneratedMenuName);

        private static (AnimatorController controller, VRCExpressionsMenu menu, PoseDeckPreset installedPreset, bool legacy)
            Sources(PoseDeckPreset preset, Target target)
        {
            var currentBase = target.Base.animator as AnimatorController;
            var currentMenu = target.Menu.menuToAppend;
            if (!currentBase || !currentMenu)
                throw new InvalidOperationException("GoGoLoco Base 컨트롤러와 설치 메뉴가 모두 연결되어 있어야 합니다.");

            var menuPath = AssetDatabase.GetAssetPath(currentMenu);
            if (Path.GetFileName(menuPath) == GeneratedMenuName)
            {
                var marker = AssetDatabase.LoadAssetAtPath<PoseDeckExistingInstallation>(
                    menuPath.Substring(0, menuPath.LastIndexOf('/') + 1) + ExistingInstallationName);
                if (marker)
                {
                    if (marker.appliedBase != currentBase || marker.appliedMenu != currentMenu ||
                        !marker.stockBase || !marker.stockMenu || IsGenerated(marker.stockBase, marker.stockMenu))
                        throw new InvalidOperationException("현재 생성본의 Base·메뉴 연결 또는 GoGoLoco 원본 참조를 확인할 수 없습니다.");
                    return (marker.stockBase, marker.stockMenu, marker.preset, false);
                }
            }
            if (!IsGenerated(currentBase, currentMenu)) return (currentBase, currentMenu, null, false);

            bool MatchesLegacy(PoseDeckPreset p) => p && p.appliedBase == currentBase && p.appliedMenu == currentMenu &&
                p.stockBase && p.stockMenu && !IsGenerated(p.stockBase, p.stockMenu);
            var matches = AssetDatabase.FindAssets("t:PoseDeckPreset", new[] { "Assets" })
                .Select(guid => AssetDatabase.LoadAssetAtPath<PoseDeckPreset>(AssetDatabase.GUIDToAssetPath(guid)))
                .Prepend(preset).Where(MatchesLegacy).Distinct().ToArray();
            if (matches.Length == 0)
                throw new InvalidOperationException("예전 생성본의 원래 Base·메뉴를 찾지 못했습니다. 그 생성본을 만든 프리셋과 GoGoLoco 원본 파일이 프로젝트에 있는지 확인해 주세요.");
            var previous = matches[0];
            if (matches.Any(p => p.stockBase != previous.stockBase || p.stockMenu != previous.stockMenu))
                throw new InvalidOperationException("같은 예전 생성본에 서로 다른 GoGoLoco 원본이 기록되어 있어 연결을 바꾸지 않았습니다.");
            return (previous.stockBase, previous.stockMenu, previous, true);
        }

        private static IEnumerable<Control> Controls(VRCExpressionsMenu menu, HashSet<VRCExpressionsMenu> seen)
        {
            if (!menu || !seen.Add(menu) || menu.controls == null) yield break;
            foreach (var c in menu.controls)
            {
                if (c == null) continue;
                yield return c;
                if (c.type == Control.ControlType.SubMenu)
                    foreach (var child in Controls(c.subMenu, seen)) yield return child;
            }
        }

        private static IEnumerable<AnimatorStateMachine> Machines(AnimatorStateMachine machine)
        {
            yield return machine;
            foreach (var child in machine.stateMachines)
                foreach (var nested in Machines(child.stateMachine)) yield return nested;
        }

        private static IEnumerable<BlendTree> PoseBranches(BlendTree tree)
        {
            if (tree.blendParameter == "VRModeProxy" && tree.children.Length == 2 &&
                tree.children.All(c => c.motion is AnimationClip))
            {
                yield return tree;
                yield break;
            }
            foreach (var child in tree.children)
                if (child.motion is BlendTree nested)
                    foreach (var branch in PoseBranches(nested)) yield return branch;
        }

        private static List<Slot> FindSlots(AnimatorController controller)
        {
            var machine = controller.layers.SelectMany(l => Machines(l.stateMachine))
                .SingleOrDefault(m => m.name == PoseMachine);
            if (!machine) throw new InvalidOperationException("GoGoLoco 1.8.6 포즈 구조를 찾지 못했습니다. 지원되는 All (Modular Avatar) 프리팹과 Base를 확인해 주세요.");
            var slots = new List<Slot>();
            foreach (var child in machine.stateMachines)
            {
                if (!int.TryParse(child.stateMachine.name, out int n) || n < 210 || n > 253) continue;
                var states = child.stateMachine.states.Select(s => s.state).Where(s => SlotStates.Contains(s.name)).ToArray();
                if (states.Length != SlotStates.Length || states.Select(s => s.name).Distinct().Count() != SlotStates.Length ||
                    !(states[0].motion is BlendTree tree) || tree.name != "go_" + n || states.Any(s => s.motion != tree)) continue;
                var branches = PoseBranches(tree).ToArray();
                if (branches.Length != 1) continue;
                var clips = branches[0].children.Select(c => (AnimationClip)c.motion).Distinct().ToArray();
                bool blank = clips.All(c => c.name == "go_pose_desktop" || c.name == "go_pose_vr");
                slots.Add(new Slot { Number = n, States = states, Tree = tree, Blank = blank, Clips = clips });
            }
            return slots.OrderByDescending(s => s.Blank).ThenBy(s => s.Number).ToList();
        }

        private static bool IsPoseControl(Control c) =>
            c.parameter?.name == Emote && c.value >= 210 && c.value <= 253 && c.value == (int)c.value &&
            (c.type == Control.ControlType.Button || (c.type == Control.ControlType.RadialPuppet &&
                c.subParameters?.FirstOrDefault()?.name == "Go/PoseRadial"));

        private static string VendorRoot(string path) =>
            VendorRoots.FirstOrDefault(root => path.StartsWith(root, StringComparison.Ordinal));

        private static IEnumerable<Control> AdditionalPoseControls(AnimatorController controller)
        {
            var root = VendorRoot(AssetDatabase.GetAssetPath(controller));
            if (root == null) yield break;
            var seen = new HashSet<VRCExpressionsMenu>();
            foreach (var name in VendorPoseMenus)
            {
                var menu = AssetDatabase.LoadAssetAtPath<VRCExpressionsMenu>(root + "MainMenu/Menu/SubMenu/" + name + ".asset");
                foreach (var control in Controls(menu, seen))
                    if (IsPoseControl(control)) yield return control;
            }
        }

        private static string ClipPathOnDisk(string path)
        {
            if (path.StartsWith("Assets/", StringComparison.Ordinal)) return path;
            var package = UnityEditor.PackageManager.PackageInfo.FindForAssetPath(path);
            return package == null ? null : Path.Combine(package.resolvedPath,
                path.Substring(("Packages/" + package.name + "/").Length));
        }

        private static bool IsSameVendorClip(string left, string right)
        {
            var leftRoot = VendorRoot(left);
            var rightRoot = VendorRoot(right);
            if (leftRoot == null || rightRoot == null || leftRoot == rightRoot ||
                !left.EndsWith(".anim", StringComparison.OrdinalIgnoreCase) ||
                !string.Equals(left.Substring(leftRoot.Length), right.Substring(rightRoot.Length), StringComparison.Ordinal))
                return false;
            // A locally edited copy at the same vendor path is still a custom clip.
            try
            {
                var leftFile = ClipPathOnDisk(left);
                var rightFile = ClipPathOnDisk(right);
                return leftFile != null && rightFile != null &&
                    string.Equals(File.ReadAllText(leftFile).Replace("\r\n", "\n"),
                        File.ReadAllText(rightFile).Replace("\r\n", "\n"), StringComparison.Ordinal);
            }
            catch (IOException) { return false; }
            catch (UnauthorizedAccessException) { return false; }
        }

        private static Plan PlanRows(PoseDeckPreset preset, AnimatorController controller, Control[] controls)
        {
            var slots = FindSlots(controller);
            var menuControls = controls.Where(IsPoseControl).OrderByDescending(c => c.type == Control.ControlType.RadialPuppet)
                .Concat(AdditionalPoseControls(controller)).ToLookup(c => (int)c.value);
            var native = slots.Where(s => !s.Blank && menuControls[s.Number].Any())
                .SelectMany(s => s.Clips.Select(clip => (s.Number, Clip: clip, Path: AssetDatabase.GetAssetPath(clip))))
                .ToArray();
            var rows = new Assignment[preset.poses.Count];
            var reserved = new HashSet<int>();
            int nativeCount = 0;
            // Reserve the original slot before assigning any custom clips, regardless of menu order.
            for (int i = 0; i < rows.Length; i++)
            {
                var clip = preset.poses[i].clip;
                if (!clip) continue;
                var match = Array.Find(native, x => x.Clip == clip);
                if (!match.Clip)
                {
                    var path = AssetDatabase.GetAssetPath(clip);
                    match = Array.Find(native, x => IsSameVendorClip(path, x.Path));
                }
                if (!match.Clip) continue;
                rows[i] = new Assignment { Number = match.Number, NativeControl = menuControls[match.Number].First() };
                reserved.Add(match.Number);
                nativeCount++;
            }

            var buttons = new HashSet<int>(controls.Where(c => IsPoseControl(c) && c.type == Control.ControlType.Button)
                .Select(c => (int)c.value));
            var custom = slots.Where(s => !reserved.Contains(s.Number) && (s.Blank || buttons.Contains(s.Number))).ToArray();
            int next = 0;
            for (int i = 0; i < rows.Length && next < custom.Length; i++)
                if (rows[i] == null) rows[i] = new Assignment { Number = custom[next++].Number };
            return new Plan { Rows = rows, NativeCount = nativeCount, CustomCapacity = custom.Length, BlankCapacity = custom.Count(s => s.Blank) };
        }

        private static string Title(PoseEntry row) => string.IsNullOrWhiteSpace(row.label) ? row.clip.name : row.label.Trim();

        private static void ValidateRows(PoseDeckPreset preset)
        {
            if (string.IsNullOrWhiteSpace(preset.menuTitle)) throw new InvalidOperationException("메뉴 이름을 입력해 주세요.");
            if (preset.poses.Count == 0) throw new InvalidOperationException("포즈를 하나 이상 추가해 주세요.");
            for (int i = 0; i < preset.poses.Count; i++)
            {
                var clip = preset.poses[i].clip;
                if (!clip || !clip.humanMotion || clip.legacy || !EditorUtility.IsPersistent(clip))
                    throw new InvalidOperationException($"포즈 {i + 1}: 프로젝트에 저장된 Humanoid 애니메이션 클립을 지정해 주세요. FBX는 Rig를 Humanoid로 임포트해야 합니다.");
            }
            if (preset.poses.GroupBy(p => (p.category, Title(p))).Any(g => g.Count() > 1))
                throw new InvalidOperationException("같은 분류에 중복된 이름이 있습니다. 포즈 이름을 구분해 주세요.");
        }

        internal static string Preview(PoseDeckPreset preset, GameObject go)
        {
            var (controller, menu, installed, legacy) = Sources(preset, ExistingTarget(go));
            var summary = Preview(preset, controller, menu);
            if (legacy)
                return $"현재 연결: 예전 생성본 ‘{installed.name}’. 생성 및 적용을 누르면 ‘{preset.name}’으로 갱신합니다.\n" + summary;
            if (installed && installed != preset)
                return $"현재 연결: ‘{installed.name}’. 생성 및 적용을 누르면 ‘{preset.name}’으로 바뀝니다.\n" + summary;
            return summary;
        }

        internal static string Preview(PoseDeckPreset preset, AnimatorController controller, VRCExpressionsMenu menu)
        {
            var plan = PlanRows(preset, controller, Controls(menu, new HashSet<VRCExpressionsMenu>()).ToArray());
            int custom = plan.Rows.Length - plan.NativeCount;
            var summary = $"원본 높이 유지: {plan.NativeCount}개. 커스텀 포즈: {custom}/{plan.CustomCapacity}개 (빈 슬롯 {plan.BlankCapacity}개).";
            var root = VendorRoot(AssetDatabase.GetAssetPath(controller));
            var unmatched = preset.poses.Select((row, i) => (row, i))
                .Where(x => x.row.clip && plan.Rows[x.i]?.NativeControl == null)
                .Select(x => (label: Title(x.row), root: VendorRoot(AssetDatabase.GetAssetPath(x.row.clip))))
                .Where(x => x.root != null).ToArray();
            if (unmatched.Length == 0) return summary;
            var labels = string.Join(", ", unmatched.Take(3).Select(x => x.label)) +
                (unmatched.Length > 3 ? $" 외 {unmatched.Length - 3}개" : "");
            return summary + $"\n원본 높이 프리셋이 연결되지 않은 GoGoLoco 클립: {labels}."
                + (root != null && unmatched.Any(x => x.root != root)
                    ? $" 다른 경로에서 가져왔다면 현재 Base가 사용하는 {root} 쪽도 확인해 주세요." : "");
        }

        private static BlendTree CloneTree(BlendTree source, AnimationClip pose, AnimatorController destination,
            Dictionary<BlendTree, BlendTree> cache)
        {
            if (cache.TryGetValue(source, out var previous)) return previous;
            var copy = Object.Instantiate(source);
            copy.name = source.name;
            copy.hideFlags = HideFlags.HideInHierarchy;
            AssetDatabase.AddObjectToAsset(copy, destination);
            cache.Add(source, copy);
            var children = source.children;
            bool replace = source.blendParameter == "VRModeProxy" && children.Length == 2 &&
                children.All(c => c.motion is AnimationClip);
            for (int i = 0; i < children.Length; i++)
            {
                if (replace) children[i].motion = pose;
                else if (children[i].motion is BlendTree child) children[i].motion = CloneTree(child, pose, destination, cache);
            }
            copy.children = children;
            EditorUtility.SetDirty(copy);
            return copy;
        }

        private static AnimatorController CopyController(AnimatorController stock, string path)
        {
            string source = AssetDatabase.GetAssetPath(stock);
            if (!AssetDatabase.CopyAsset(source, path))
            {
                const string prefix = "Packages/";
                var package = UnityEditor.PackageManager.PackageInfo.FindForAssetPath(source);
                if (package == null || !source.StartsWith(prefix + package.name + "/", StringComparison.Ordinal))
                    throw new IOException("Base 컨트롤러를 복제할 수 없습니다: " + source);
                string absoluteSource = Path.Combine(package.resolvedPath, source.Substring(prefix.Length + package.name.Length + 1));
                File.Copy(absoluteSource, path);
                AssetDatabase.ImportAsset(path, ImportAssetOptions.ForceSynchronousImport);
            }
            return AssetDatabase.LoadAssetAtPath<AnimatorController>(path) ??
                throw new IOException("복제한 Base 컨트롤러를 열 수 없습니다.");
        }

        private static Control Submenu(string name, VRCExpressionsMenu menu, Texture2D icon = null) =>
            new Control { name = name, type = Control.ControlType.SubMenu, subMenu = menu, icon = icon };

        private static Control CopyControl(Control source, string title) => new Control
        {
            name = title, type = source.type, icon = source.icon, value = source.value,
            parameter = new Control.Parameter { name = source.parameter?.name ?? "" },
            subParameters = source.subParameters?.Select(p => new Control.Parameter { name = p?.name ?? "" }).ToArray()
        };

        private static VRCExpressionsMenu MenuAsset(string folder, string name, IEnumerable<Control> controls)
        {
            var menu = ScriptableObject.CreateInstance<VRCExpressionsMenu>();
            menu.name = name;
            menu.controls = controls.ToList();
            if (menu.controls.Count > 8) throw new InvalidOperationException("메뉴당 8개 컨트롤을 초과했습니다.");
            AssetDatabase.CreateAsset(menu, $"{folder}/{name}.asset");
            return menu;
        }

        private static VRCExpressionsMenu Pages(string folder, string key, List<Control> controls, int page = 1)
        {
            if (controls.Count <= 8) return MenuAsset(folder, $"{key}_{page}", controls);
            var first = controls.Take(7).ToList();
            first.Add(Submenu("다음 페이지", Pages(folder, key, controls.Skip(7).ToList(), page + 1)));
            return MenuAsset(folder, $"{key}_{page}", first);
        }

        private static VRCExpressionsMenu BuildMenu(PoseDeckPreset preset, string folder, VRCExpressionsMenu original,
            Control reset, Control height, Assignment[] rows)
        {
            var root = new List<Control> { CopyControl(reset, "초기화"), CopyControl(height, "높이 조절") };
            foreach (var group in preset.poses.Select((p, i) => (p, i)).GroupBy(x => x.p.category).OrderBy(g => g.Key))
            {
                var controls = group.Select(x => rows[x.i].NativeControl != null
                    ? CopyControl(rows[x.i].NativeControl, Title(x.p))
                    : new Control
                    {
                        name = Title(x.p), type = Control.ControlType.Button,
                        parameter = new Control.Parameter { name = Emote }, value = rows[x.i].Number
                    }).ToList();
                root.Add(Submenu(CategoryNames[(int)group.Key], Pages(folder, group.Key.ToString(), controls)));
            }
            var stockLink = original.controls.FirstOrDefault(c => c?.type == Control.ControlType.SubMenu && c.subMenu);
            if (preset.keepStockMenu && stockLink != null)
                root.Add(Submenu("기존 GoGoLoco", stockLink.subMenu, stockLink.icon));
            var inner = MenuAsset(folder, "PoseDeckMenu", root);
            return MenuAsset(folder, "PoseDeckInstaller", new[] { Submenu(preset.menuTitle.Trim(), inner, stockLink?.icon) });
        }

        internal static void Wire(Target target, AnimatorController controller, VRCExpressionsMenu menu)
        {
            Undo.RecordObjects(new Object[] { target.Base, target.Menu }, "Change Personal Pose Deck");
            target.Base.animator = controller;
            target.Menu.menuToAppend = menu;
            PrefabUtility.RecordPrefabInstancePropertyModifications(target.Base);
            PrefabUtility.RecordPrefabInstancePropertyModifications(target.Menu);
            EditorUtility.SetDirty(target.Base);
            EditorUtility.SetDirty(target.Menu);
            EditorSceneManager.MarkSceneDirty(target.Base.gameObject.scene);
        }

        internal static string GenerateAndApply(PoseDeckPreset preset, GameObject go)
        {
            var target = ExistingTarget(go);
            var (stock, original, _, _) = Sources(preset, target);
            var (folder, copy, wrapper) = GenerateAssets(preset, stock, original);
            Undo.IncrementCurrentGroup();
            int group = Undo.GetCurrentGroup();
            Undo.SetCurrentGroupName("Apply Personal Pose Deck");
            try
            {
                var marker = ScriptableObject.CreateInstance<PoseDeckExistingInstallation>();
                marker.preset = preset;
                marker.stockBase = stock;
                marker.stockMenu = original;
                marker.appliedBase = copy;
                marker.appliedMenu = wrapper;
                AssetDatabase.CreateAsset(marker, folder + "/" + ExistingInstallationName);
                Wire(target, copy, wrapper);
                AssetDatabase.SaveAssets();
                Undo.CollapseUndoOperations(group);
                return folder;
            }
            catch
            {
                Undo.RevertAllDownToGroup(group);
                AssetDatabase.DeleteAsset(folder);
                throw;
            }
        }

        internal static (string folder, AnimatorController controller, VRCExpressionsMenu menu) GenerateAssets(
            PoseDeckPreset preset, AnimatorController stock, VRCExpressionsMenu original)
        {
            var controls = Controls(original, new HashSet<VRCExpressionsMenu>()).ToArray();
            var (reset, height) = HeightControls(controls);
            if (reset == null || height == null) throw new InvalidOperationException("GoGoLoco 원본 메뉴에서 초기화 또는 높이 조절을 찾을 수 없습니다.");
            ValidateRows(preset);
            var plan = PlanRows(preset, stock, controls);
            if (plan.Rows.Any(row => row == null))
                throw new InvalidOperationException($"원본 높이를 유지하는 포즈를 제외하면 커스텀 슬롯은 {plan.CustomCapacity}개입니다. 포즈를 줄여 주세요.");
            string presetPath = AssetDatabase.GetAssetPath(preset);
            if (!presetPath.StartsWith("Assets/", StringComparison.Ordinal))
                throw new InvalidOperationException("프리셋을 프로젝트 Assets 폴더에 저장해 주세요.");
            string parent = Path.GetDirectoryName(presetPath).Replace('\\', '/');
            string requested = AssetDatabase.GenerateUniqueAssetPath(parent + "/PoseDeck_Generated");
            string guid = AssetDatabase.CreateFolder(parent, Path.GetFileName(requested));
            string folder = AssetDatabase.GUIDToAssetPath(guid);
            if (string.IsNullOrEmpty(folder)) throw new IOException("생성 결과 폴더를 만들 수 없습니다.");
            AnimatorController copy;
            VRCExpressionsMenu wrapper;
            try
            {
                copy = CopyController(stock, folder + "/" + GeneratedBaseName);
                var slots = FindSlots(copy).ToDictionary(slot => slot.Number);
                for (int i = 0; i < preset.poses.Count; i++)
                {
                    if (plan.Rows[i].NativeControl != null) continue;
                    var slot = slots[plan.Rows[i].Number];
                    var tree = CloneTree(slot.Tree, preset.poses[i].clip, copy, new Dictionary<BlendTree, BlendTree>());
                    foreach (var state in slot.States) { state.motion = tree; EditorUtility.SetDirty(state); }
                }
                EditorUtility.SetDirty(copy);
                wrapper = BuildMenu(preset, folder, original, reset, height, plan.Rows);
                AssetDatabase.SaveAssets();
            }
            catch
            {
                AssetDatabase.DeleteAsset(folder);
                throw;
            }
            return (folder, copy, wrapper);
        }

        private static (Control reset, Control height) HeightControls(IEnumerable<Control> controls) =>
            (controls.FirstOrDefault(c => c.type == Control.ControlType.Button && c.parameter?.name == Emote && c.value == 255),
             controls.FirstOrDefault(c => c.type == Control.ControlType.RadialPuppet &&
                 c.parameter?.name == Emote && c.value == 125 && c.subParameters?.FirstOrDefault()?.name == Float));

        internal static bool SupportsSource(AnimatorController controller, VRCExpressionsMenu menu)
        {
            var (reset, height) = HeightControls(Controls(menu, new HashSet<VRCExpressionsMenu>()));
            if (reset == null || height == null) return false;
            try { return FindSlots(controller).Count != 0; }
            catch (InvalidOperationException) { return false; }
        }

        private static Target ExistingTarget(GameObject go)
        {
            var target = GetTarget(go);
            if (PoseDeckAvatarInstall.IsAvatarInstallation(go, target))
                throw new InvalidOperationException("아바타에 새로 붙인 덱입니다. ‘아바타에 새로 적용’에서 갱신하거나 제거해 주세요.");
            return target;
        }

        internal static void Restore(PoseDeckPreset preset, GameObject go)
        {
            var target = ExistingTarget(go);
            if (!IsGenerated(target.Base.animator as AnimatorController, target.Menu.menuToAppend))
                throw new InvalidOperationException("이 GoGoLoco 오브젝트에 연결된 Pose Deck 생성본이 없습니다.");
            var (stock, original, _, _) = Sources(preset, target);
            Wire(target, stock, original);
        }
    }
}
