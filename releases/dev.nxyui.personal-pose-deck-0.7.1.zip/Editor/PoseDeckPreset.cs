using System;
using System.Collections.Generic;
using UnityEditor.Animations;
using UnityEngine;
using VRC.SDK3.Avatars.ScriptableObjects;

namespace PersonalPoseDeck
{
    internal enum PoseCategory { Sit, Lie, Stand, Other }

    [Serializable]
    internal sealed class PoseEntry
    {
        public string label;
        public AnimationClip clip;
        public PoseCategory category;
    }

    public sealed class PoseDeckPreset : ScriptableObject
    {
        [SerializeField] internal string menuTitle = "내 포즈";
        [SerializeField] internal bool keepStockMenu = true;
        [SerializeField] internal List<PoseEntry> poses = new List<PoseEntry>();
        // Retained as-is to resolve scenes wired to results from 0.7.0 and earlier.
        [SerializeField, HideInInspector] internal AnimatorController stockBase = null;
        [SerializeField, HideInInspector] internal VRCExpressionsMenu stockMenu = null;
        [SerializeField, HideInInspector] internal AnimatorController appliedBase = null;
        [SerializeField, HideInInspector] internal VRCExpressionsMenu appliedMenu = null;
    }
}
