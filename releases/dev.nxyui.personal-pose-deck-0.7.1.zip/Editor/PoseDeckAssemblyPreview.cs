using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using nadena.dev.ndmf;
using nadena.dev.ndmf.platform;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using Object = UnityEngine.Object;

namespace PersonalPoseDeck
{
    internal sealed class PoseDeckAssemblyPreview : IDisposable
    {
        private const BindingFlags All = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static;
        private Scene scene;
        private readonly HashSet<Object> generated = new HashSet<Object>();
        internal GameObject Root { get; private set; }

        internal PoseDeckAssemblyPreview(GameObject source)
        {
            scene = EditorSceneManager.NewPreviewScene();
            var stage = EditorUtility.CreateGameObjectWithHideFlags("Pose Deck staging", HideFlags.HideAndDontSave);
            var originalAssets = new HashSet<Object>();
            bool haveBaseline = false;
            try
            {
                SceneManager.MoveGameObjectToScene(stage, scene);
                stage.SetActive(false);
                Root = Object.Instantiate(source, stage.transform, false);
                Root.name = source.name + " (Pose Deck Preview)";
                Root.SetActive(false);
                Root.transform.SetParent(null, false);
                Root.transform.SetPositionAndRotation(Vector3.zero, Quaternion.identity);
                Root.transform.localScale = source.transform.lossyScale;
                originalAssets.UnionWith(ReferencedAssets(Root));
                haveBaseline = true;
                // Keep MA and SDK tags; prevent unrelated edit-mode scripts from running in the clone.
                foreach (var script in Root.GetComponentsInChildren<MonoBehaviour>(true))
                {
                    if (!script) continue;
                    var type = script.GetType();
                    var ns = type.Namespace ?? "";
                    if (ns.StartsWith("nadena.dev.", StringComparison.Ordinal) || ns.StartsWith("VRC.", StringComparison.Ordinal)) continue;
                    if (type.IsDefined(typeof(ExecuteAlways), true) || type.IsDefined(typeof(ExecuteInEditMode), true))
                        Object.DestroyImmediate(script);
                }
                Root.SetActive(true);
                ApplyModularAvatar(Root);
                Root.hideFlags = HideFlags.HideAndDontSave;
                CollectGenerated(originalAssets);
            }
            catch
            {
                if (haveBaseline) CollectGenerated(originalAssets);
                Dispose();
                throw;
            }
        }

        private static void ApplyModularAvatar(GameObject root)
        {
            // NDMF's public full bake runs all installed plug-ins. Resolve only its core and MA passes for preview.
            var asm = typeof(BuildContext).Assembly;
            var resolverType = asm.GetType("nadena.dev.ndmf.PluginResolver", false);
            var concreteType = asm.GetType("nadena.dev.ndmf.ConcretePass", false);
            var find = resolverType?.GetMethod("FindPluginTypes", All);
            var ctor = resolverType?.GetConstructor(All, null,
                new[] { typeof(IEnumerable<Type>), typeof(INDMFPlatformProvider), typeof(bool) }, null);
            var passesProperty = resolverType?.GetProperty("Passes", All);
            var run = concreteType == null ? null : typeof(BuildContext).GetMethod("RunPass", All, null, new[] { concreteType }, null);
            if (find == null || ctor == null || passesProperty == null || run == null)
                throw new InvalidOperationException("이 NDMF 버전에서 MA 전용 미리보기를 사용할 수 없습니다.");

            var pluginTypes = ((IEnumerable<Type>)find.Invoke(null, null)).Where(t =>
                (t.Assembly == asm && t.Name == "InternalPasses") ||
                (t.Namespace ?? "").StartsWith("nadena.dev.modular_avatar.", StringComparison.Ordinal)).ToArray();
            if (!pluginTypes.Any(t => t.Name == "PluginDefinition"))
                throw new InvalidOperationException("Modular Avatar 조립 패스를 찾지 못했습니다.");

            var context = new BuildContext(root, (string)null);
            try
            {
                using (new AmbientPlatform.Scope(context.PlatformProvider))
                {
                    var resolver = ctor.Invoke(new object[] { pluginTypes, context.PlatformProvider, false });
                    int count = 0;
                    foreach (var pair in (IEnumerable)passesProperty.GetValue(resolver))
                    {
                        var pairType = pair.GetType();
                        var phase = (BuildPhase)pairType.GetField("Item1").GetValue(pair);
                        if (phase == BuildPhase.Optimizing) break;
                        foreach (var pass in (IEnumerable)pairType.GetField("Item2").GetValue(pair))
                        { run.Invoke(context, new[] { pass }); count++; }
                        if (phase == BuildPhase.Transforming) break;
                    }
                    if (count == 0) throw new InvalidOperationException("실행할 MA 조립 패스가 없습니다.");
                }
            }
            catch (TargetInvocationException e) when (e.InnerException != null)
            {
                throw new InvalidOperationException(e.InnerException.Message, e.InnerException);
            }
            finally
            {
                try { context.DeactivateAllExtensionContexts(); }
                finally { context.AssetSaver.Dispose(); }
            }
            if (!context.Successful)
                throw new InvalidOperationException("Modular Avatar 조립 중 오류가 발생했습니다. Unity Console을 확인하세요.");
        }

        private static IEnumerable<Object> ReferencedAssets(GameObject root)
        {
            foreach (var animator in root.GetComponentsInChildren<Animator>(true))
            {
                if (animator.avatar) yield return animator.avatar;
                if (animator.runtimeAnimatorController) yield return animator.runtimeAnimatorController;
            }
            foreach (var mesh in root.GetComponentsInChildren<MeshFilter>(true)) if (mesh.sharedMesh) yield return mesh.sharedMesh;
            foreach (var renderer in root.GetComponentsInChildren<Renderer>(true))
            {
                if (renderer is SkinnedMeshRenderer skinned && skinned.sharedMesh) yield return skinned.sharedMesh;
                foreach (var material in renderer.sharedMaterials) if (material) yield return material;
            }
        }

        private void CollectGenerated(HashSet<Object> originalAssets)
        {
            if (!Root) return;
            foreach (var asset in ReferencedAssets(Root))
                if (!originalAssets.Contains(asset) && !EditorUtility.IsPersistent(asset)) generated.Add(asset);
        }

        public void Dispose()
        {
            if (scene.IsValid()) EditorSceneManager.ClosePreviewScene(scene);
            Root = null;
            foreach (var asset in generated) if (asset) Object.DestroyImmediate(asset);
            generated.Clear();
        }
    }
}
