using System;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace PersonalPoseDeck
{
    internal sealed partial class PoseDeckPoseBrowser
    {
        [SerializeField] private GameObject target;
        [SerializeField] private int applyMode;
        [SerializeField] private bool deckOpen;
        private static readonly string[] ApplyModes = { "기존 GoGoLoco에 적용", "아바타에 새로 적용" };
        private Vector2 deckScroll;
        private string deckStatus;
        private MessageType deckStatusType;

        private static GameObject FindDeckTarget(GameObject selected)
        {
            if (!selected) return null;
            var avatarRoot = FindAvatar(selected);
            if (selected != avatarRoot && selected.name.IndexOf("gogoloco", StringComparison.OrdinalIgnoreCase) >= 0) return selected;
            var child = avatarRoot.GetComponentsInChildren<Transform>(true).FirstOrDefault(t =>
                t.name.Equals("GogoLoco All (Modular Avatar)", StringComparison.OrdinalIgnoreCase));
            return child ? child.gameObject : null;
        }

        private void Do(Func<string> action)
        {
            try { deckStatus = action(); deckStatusType = MessageType.Info; }
            catch (Exception e) { deckStatus = e.Message; deckStatusType = MessageType.Error; }
        }

        private void NewPreset()
        {
            string path = EditorUtility.SaveFilePanelInProject("포즈 프리셋 저장", "MyPoseDeck", "asset", "프리셋을 Assets에 저장하세요.");
            if (string.IsNullOrEmpty(path)) return;
            preset = CreateInstance<PoseDeckPreset>();
            AssetDatabase.CreateAsset(preset, AssetDatabase.GenerateUniqueAssetPath(path));
            AssetDatabase.SaveAssets();
            deckStatus = null;
        }

        private void DrawDeckBar()
        {
            int next = EditorGUILayout.Popup("적용 방식", applyMode, ApplyModes);
            if (next != applyMode) { applyMode = next; deckStatus = null; }
            bool onAvatar = applyMode == 1;
            using (new EditorGUILayout.HorizontalScope())
            {
                if (onAvatar)
                    EditorGUILayout.LabelField("적용 대상", avatar ? avatar.name + " (위에서 선택한 아바타)" : "위에서 아바타를 선택하세요.");
                else
                {
                    target = (GameObject)EditorGUILayout.ObjectField("GoGoLoco 오브젝트", target, typeof(GameObject), true);
                    if (GUILayout.Button("아바타에서 찾기", GUILayout.Width(104))) target = FindDeckTarget(avatar);
                }
            }
            using (new EditorGUILayout.HorizontalScope())
            {
                preset = (PoseDeckPreset)EditorGUILayout.ObjectField("포즈 프리셋", preset, typeof(PoseDeckPreset), false);
                if (GUILayout.Button("새 프리셋", GUILayout.Width(85))) NewPreset();
                using (new EditorGUI.DisabledScope(!preset || !(onAvatar ? avatar : target)))
                {
                    if (GUILayout.Button("슬롯 확인", GUILayout.Width(84))) Do(() =>
                        onAvatar ? PoseDeckAvatarInstall.Preview(preset, avatar) : PoseDeckBuilder.Preview(preset, target));
                    if (GUILayout.Button("생성 및 적용", GUILayout.Width(100))) Do(() =>
                    {
                        string folder = onAvatar ? PoseDeckAvatarInstall.Apply(preset, avatar) : PoseDeckBuilder.GenerateAndApply(preset, target);
                        ResetPreview();
                        return $"‘{preset.name}’의 포즈 {preset.poses.Count}개를 적용했습니다. 씬을 저장하고 Build & Test로 확인하세요.\n" + folder;
                    });
                }
                using (new EditorGUI.DisabledScope(onAvatar ? !avatar : !target))
                {
                    if (GUILayout.Button(onAvatar ? "적용 제거" : "GoGoLoco 원복", GUILayout.Width(106))) Do(() =>
                    {
                        if (onAvatar) PoseDeckAvatarInstall.Remove(avatar);
                        else PoseDeckBuilder.Restore(preset, target);
                        ResetPreview();
                        return onAvatar ? "이 아바타에 추가한 Pose Deck을 제거했습니다. 씬을 저장하세요."
                            : "원래 Base와 메뉴로 복구했습니다. 씬을 저장하세요.";
                    });
                }
            }
            if (!string.IsNullOrEmpty(deckStatus)) EditorGUILayout.HelpBox(deckStatus, deckStatusType);
        }

        private void DrawDeckSettings()
        {
            if (!preset) return;
            deckOpen = EditorGUILayout.Foldout(deckOpen, $"Deck 설정 · 선택한 포즈 {preset.poses.Count}개", true);
            if (!deckOpen) return;
            using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
            {
                EditorGUI.BeginChangeCheck();
                var title = EditorGUILayout.TextField("메뉴 이름", preset.menuTitle);
                var keep = EditorGUILayout.ToggleLeft("메뉴 안에 기존 GoGoLoco도 남기기", preset.keepStockMenu);
                if (EditorGUI.EndChangeCheck())
                {
                    Undo.RecordObject(preset, "Edit Pose Deck Settings");
                    preset.menuTitle = title;
                    preset.keepStockMenu = keep;
                    EditorUtility.SetDirty(preset);
                }

                using (var view = new EditorGUILayout.ScrollViewScope(deckScroll, GUILayout.Height(106)))
                {
                    deckScroll = view.scrollPosition;
                    for (int i = 0; i < preset.poses.Count; i++)
                    {
                        int index = i;
                        var row = preset.poses[i];
                        using (new EditorGUILayout.HorizontalScope())
                        {
                            GUILayout.Label((i + 1).ToString(), GUILayout.Width(24));
                            EditorGUI.BeginChangeCheck();
                            var label = EditorGUILayout.TextField(row.label ?? "", GUILayout.MinWidth(46));
                            var clip = (AnimationClip)EditorGUILayout.ObjectField(row.clip, typeof(AnimationClip), false, GUILayout.MinWidth(65));
                            var cat = EditorGUILayout.Popup((int)row.category, PoseDeckBuilder.CategoryNames, GUILayout.Width(66));
                            if (EditorGUI.EndChangeCheck())
                            {
                                Change("Edit Pose", () => { row.label = label; row.clip = clip; row.category = (PoseCategory)cat; });
                            }
                            using (new EditorGUI.DisabledScope(i == 0))
                                if (GUILayout.Button("↑", GUILayout.Width(25)))
                                { Change("Move Pose", () => { preset.poses.RemoveAt(index); preset.poses.Insert(index - 1, row); }); break; }
                            using (new EditorGUI.DisabledScope(i == preset.poses.Count - 1))
                                if (GUILayout.Button("↓", GUILayout.Width(25)))
                                { Change("Move Pose", () => { preset.poses.RemoveAt(index); preset.poses.Insert(index + 1, row); }); break; }
                            if (GUILayout.Button("×", GUILayout.Width(25)))
                            { Change("Remove Pose", () => preset.poses.RemoveAt(index)); break; }
                        }
                    }
                }

                using (new EditorGUILayout.HorizontalScope())
                {
                    if (GUILayout.Button("+ 포즈 추가")) Change("Add Pose", () => preset.poses.Add(new PoseEntry()));
                    if (GUILayout.Button("+ Project 선택"))
                    {
                        var clips = Selection.objects.OfType<AnimationClip>().ToArray();
                        if (clips.Length != 0) Change("Add Selected Poses", () =>
                            preset.poses.AddRange(clips.Select(c => new PoseEntry { clip = c })));
                        else { deckStatus = "Project 창에서 애니메이션 클립을 먼저 선택하세요."; deckStatusType = MessageType.Warning; }
                    }
                    if (GUILayout.Button("프리셋만 저장")) Do(() =>
                    {
                        AssetDatabase.SaveAssetIfDirty(preset);
                        return $"‘{preset.name}’에 포즈 {preset.poses.Count}개를 저장했습니다. 아바타에 반영하려면 ‘생성 및 적용’을 눌러 주세요.";
                    });
                }
            }
        }

        private void Change(string undoName, Action edit)
        {
            Undo.RecordObject(preset, undoName);
            edit();
            EditorUtility.SetDirty(preset);
        }
    }
}
