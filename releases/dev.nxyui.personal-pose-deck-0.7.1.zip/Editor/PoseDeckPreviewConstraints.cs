using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Animations;
using VRC.Dynamics;
using VRC.Dynamics.ManagedTypes;

namespace PersonalPoseDeck
{
    // A pose-only solver for the preview scene; it never registers constraints on VRChat's global manager.
    internal sealed class PoseDeckPreviewConstraints
    {
        private enum Kind { Parent, Position, Rotation, Scale, Aim }
        private struct Link
        {
            public Transform Node;
            public float Weight;
            public Vector3 Position, Rotation;
        }
        private sealed class Entry
        {
            public Transform Owner, Target, Up;
            public Kind Mode;
            public float Weight;
            public bool Local;
            public Axis PositionAxes = AllAxes, RotationAxes = AllAxes, ScaleAxes = AllAxes;
            public Vector3 PositionOffset, RotationOffset, ScaleOffset;
            public Vector3 AimAxis = Vector3.forward, UpAxis = Vector3.up, WorldUp = Vector3.up;
            public readonly List<Link> Sources = new List<Link>();
            public Vector3 BasePosition, BaseScale, BaseWorldPosition;
            public Quaternion BaseRotation, BaseWorldRotation;
        }
        private const Axis AllAxes = Axis.X | Axis.Y | Axis.Z;
        private readonly List<Entry> entries = new List<Entry>();
        private readonly Dictionary<Transform, (Vector3 position, Quaternion rotation, Vector3 scale)> rest =
            new Dictionary<Transform, (Vector3, Quaternion, Vector3)>();

        internal PoseDeckPreviewConstraints(GameObject source, Func<Transform, Transform> map)
        {
            foreach (var vrc in source.GetComponentsInChildren<VRCConstraintBase>(true))
            {
                if (!vrc || !vrc.enabled || !vrc.IsActive || vrc.FreezeToWorld || vrc.GlobalWeight <= 0f) continue;
                var e = new Entry { Owner = map(vrc.transform), Target = map(vrc.TargetTransform ? vrc.TargetTransform : vrc.transform),
                    Weight = vrc.GlobalWeight, Local = vrc.SolveInLocalSpace };
                if (!e.Owner || !e.Target) continue;
                switch (vrc)
                {
                    case VRCParentConstraintBase p:
                        e.Mode = Kind.Parent;
                        e.PositionAxes = Axes(p.AffectsPositionX, p.AffectsPositionY, p.AffectsPositionZ);
                        e.RotationAxes = Axes(p.AffectsRotationX, p.AffectsRotationY, p.AffectsRotationZ);
                        break;
                    case VRCPositionConstraintBase p:
                        e.Mode = Kind.Position;
                        e.PositionAxes = Axes(p.AffectsPositionX, p.AffectsPositionY, p.AffectsPositionZ);
                        e.PositionOffset = p.PositionOffset;
                        break;
                    case VRCRotationConstraintBase r:
                        e.Mode = Kind.Rotation;
                        e.RotationAxes = Axes(r.AffectsRotationX, r.AffectsRotationY, r.AffectsRotationZ);
                        e.RotationOffset = r.RotationOffset;
                        break;
                    case VRCScaleConstraintBase s:
                        e.Mode = Kind.Scale;
                        e.ScaleAxes = Axes(s.AffectsScaleX, s.AffectsScaleY, s.AffectsScaleZ);
                        e.ScaleOffset = s.ScaleOffset;
                        break;
                    case VRCAimConstraintBase a:
                        e.Mode = Kind.Aim;
                        e.RotationAxes = Axes(a.AffectsRotationX, a.AffectsRotationY, a.AffectsRotationZ);
                        e.RotationOffset = a.RotationOffset;
                        e.AimAxis = a.AimAxis; e.UpAxis = a.UpAxis; e.WorldUp = a.WorldUpVector;
                        e.Up = map(a.WorldUpTransform);
                        break;
                    case VRCLookAtConstraintBase l:
                        e.Mode = Kind.Aim;
                        e.RotationOffset = l.RotationOffset + Vector3.forward * l.Roll;
                        e.Up = l.UseUpTransform ? map(l.WorldUpTransform) : null;
                        break;
                    default: continue;
                }
                for (int i = 0; i < vrc.SourceCount; i++)
                {
                    var s = vrc.GetSource(i);
                    var node = map(s.SourceTransform);
                    if (node && s.Weight > 0f)
                        e.Sources.Add(new Link { Node = node, Weight = s.Weight, Position = s.ParentPositionOffset, Rotation = s.ParentRotationOffset });
                }
                Add(e);
            }

            foreach (var behaviour in source.GetComponentsInChildren<Behaviour>(true))
            {
                if (!(behaviour is IConstraint unity) || !behaviour.enabled || !unity.constraintActive || unity.weight <= 0f) continue;
                var e = new Entry { Owner = map(behaviour.transform), Target = map(behaviour.transform), Weight = unity.weight };
                if (!e.Target) continue;
                switch (behaviour)
                {
                    case ParentConstraint p:
                        e.Mode = Kind.Parent; e.PositionAxes = p.translationAxis; e.RotationAxes = p.rotationAxis; break;
                    case PositionConstraint p:
                        e.Mode = Kind.Position; e.PositionAxes = p.translationAxis; e.PositionOffset = p.translationOffset; break;
                    case RotationConstraint r:
                        e.Mode = Kind.Rotation; e.RotationAxes = r.rotationAxis; e.RotationOffset = r.rotationOffset; break;
                    case ScaleConstraint s:
                        e.Mode = Kind.Scale; e.ScaleAxes = s.scalingAxis; e.ScaleOffset = s.scaleOffset; break;
                    case AimConstraint a:
                        e.Mode = Kind.Aim; e.RotationAxes = a.rotationAxis; e.RotationOffset = a.rotationOffset;
                        e.AimAxis = a.aimVector; e.UpAxis = a.upVector; e.WorldUp = a.worldUpVector; e.Up = map(a.worldUpObject); break;
                    case LookAtConstraint l:
                        e.Mode = Kind.Aim; e.RotationOffset = l.rotationOffset + Vector3.forward * l.roll;
                        e.Up = l.useUpObject ? map(l.worldUpObject) : null; break;
                    default: continue;
                }
                for (int i = 0; i < unity.sourceCount; i++)
                {
                    var s = unity.GetSource(i);
                    var node = map(s.sourceTransform);
                    if (!node || s.weight <= 0f) continue;
                    var link = new Link { Node = node, Weight = s.weight };
                    if (behaviour is ParentConstraint p)
                    { link.Position = p.GetTranslationOffset(i); link.Rotation = p.GetRotationOffset(i); }
                    e.Sources.Add(link);
                }
                Add(e);
            }
        }

        private static Axis Axes(bool x, bool y, bool z) => (x ? Axis.X : Axis.None) | (y ? Axis.Y : Axis.None) | (z ? Axis.Z : Axis.None);

        private void Add(Entry entry)
        {
            if (entry.Sources.Count == 0) return;
            entries.Add(entry);
            var t = entry.Target;
            if (!rest.ContainsKey(t)) rest.Add(t, (t.localPosition, t.localRotation, t.localScale));
        }

        internal void ResetTargets()
        {
            foreach (var pair in rest)
            {
                var t = pair.Key;
                var pose = pair.Value;
                t.localPosition = pose.position;
                t.localRotation = pose.rotation;
                t.localScale = pose.scale;
            }
        }

        internal void Apply()
        {
            foreach (var e in entries)
            {
                e.BasePosition = e.Target.localPosition; e.BaseRotation = e.Target.localRotation; e.BaseScale = e.Target.localScale;
                e.BaseWorldPosition = e.Target.position; e.BaseWorldRotation = e.Target.rotation;
            }
            // Resolve chains (for example body -> target sphere -> light aim) without carrying state from the previous pose.
            for (int pass = 0; pass < 4; pass++)
                foreach (var e in entries)
                    if (e.Owner.gameObject.activeInHierarchy) Solve(e);
        }

        private static Vector3 Mask(Vector3 keep, Vector3 value, Axis axes) => new Vector3(
            (axes & Axis.X) != 0 ? value.x : keep.x, (axes & Axis.Y) != 0 ? value.y : keep.y, (axes & Axis.Z) != 0 ? value.z : keep.z);

        private static void Solve(Entry e)
        {
            var t = e.Target;
            var parent = t.parent;
            float sum = 0f;
            Vector3 position = Vector3.zero, scale = Vector3.zero;
            Quaternion rotation = Quaternion.identity;
            foreach (var source in e.Sources)
            {
                var node = source.Node;
                bool self = node == t;
                float w = source.Weight;
                Vector3 p = e.Local ? (self ? e.BasePosition : node.localPosition) : (self ? e.BaseWorldPosition : node.position);
                Quaternion q = e.Local ? (self ? e.BaseRotation : node.localRotation) : (self ? e.BaseWorldRotation : node.rotation);
                if (e.Mode == Kind.Parent)
                {
                    p += q * Vector3.Scale(e.Local ? node.localScale : node.lossyScale, source.Position);
                    q *= Quaternion.Euler(source.Rotation);
                }
                position += p * w;
                scale += (self ? e.BaseScale : node.localScale) * w;
                rotation = sum == 0f ? q : Quaternion.Slerp(rotation, q, w / (sum + w));
                sum += w;
            }
            if (sum <= 0f) return;
            float blend = Mathf.Clamp01(e.Weight);
            position /= sum;
            if (e.Mode == Kind.Position || e.Mode == Kind.Parent)
            {
                if (!e.Local && parent) position = parent.InverseTransformPoint(position);
                var result = Vector3.Lerp(e.BasePosition, position + e.PositionOffset, blend);
                t.localPosition = Mask(t.localPosition, result, e.PositionAxes);
            }
            if (e.Mode == Kind.Rotation || e.Mode == Kind.Parent || e.Mode == Kind.Aim)
            {
                if (e.Mode == Kind.Aim)
                {
                    if (e.Local && parent) position = parent.TransformPoint(position);
                    var delta = position - t.position;
                    if (delta.sqrMagnitude < .000001f) return;
                    var up = e.Up ? e.Up.up : e.WorldUp;
                    if (up.sqrMagnitude < .000001f) up = Vector3.up;
                    var forward = e.AimAxis.sqrMagnitude > .000001f ? e.AimAxis : Vector3.forward;
                    var localUp = e.UpAxis.sqrMagnitude > .000001f ? e.UpAxis : Vector3.up;
                    rotation = Quaternion.LookRotation(delta, up) * Quaternion.Inverse(Quaternion.LookRotation(forward, localUp));
                }
                if ((!e.Local || e.Mode == Kind.Aim) && parent) rotation = Quaternion.Inverse(parent.rotation) * rotation;
                var result = Quaternion.Slerp(e.BaseRotation, rotation * Quaternion.Euler(e.RotationOffset), blend);
                if (e.RotationAxes == AllAxes) t.localRotation = result;
                else if (e.RotationAxes != Axis.None) t.localEulerAngles = Mask(t.localEulerAngles, result.eulerAngles, e.RotationAxes);
            }
            if (e.Mode == Kind.Scale)
                t.localScale = Mask(t.localScale, Vector3.Lerp(e.BaseScale, scale / sum + e.ScaleOffset, blend), e.ScaleAxes);
        }
    }
}
