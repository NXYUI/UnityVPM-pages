using System;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace PersonalPoseDeck
{
    internal sealed partial class PoseDeckPoseBrowser
    {
        [SerializeField] private GameObject target;
        [SerializeField] private int applyMode;
        [SerializeField] private bool deckOpen;
        private static readonly string[] ApplyModes = { "기존 GoGoLoco에 적용", "아바타에 새로 적용" };
        private Vector2 deckScroll;
        private string deckStatus;
        private MessageType deckStatusType;

        // Window shell: menu entry, editor lifecycle and the top-level layout. Browsing lives in PoseDeckPoseBrowser.cs.
        [MenuItem("Tools/Personal Pose Deck")]
        private static void OpenStandalone() => OpenFor(Selection.activeGameObject, Selection.activeObject as PoseDeckPreset);

        internal static void OpenFor(GameObject target, PoseDeckPreset targetPreset)
        {
            var w = GetWindow<PoseDeckPoseBrowser>("Personal Pose Deck");
            w.minSize = new Vector2(850, 550);
            if (targetPreset) w.preset = targetPreset;
            var resolved = FindAvatar(target);
            if (resolved && resolved.GetComponent<Animator>()) w.ChangeAvatar(resolved);
            if (!w.target && w.avatar) w.target = FindDeckTarget(w.avatar);
            w.Show();
        }

        private void OnEnable()
        {
            startScan = true;
            previewNeedsBuild = true;
            splitRatio = EditorPrefs.GetFloat(SplitPreference, .55f);
            invertRightDragVertical = EditorPrefs.GetBool(InvertCameraPreference, false);
            if (!target && avatar) target = FindDeckTarget(avatar);
            EditorApplication.update += Tick;
            EditorApplication.projectChanged += OnProjectChanged;
            EditorApplication.playModeStateChanged += PlayModeChanged;
        }

        private void OnDisable()
        {
            EditorApplication.update -= Tick;
            EditorApplication.projectChanged -= OnProjectChanged;
            EditorApplication.playModeStateChanged -= PlayModeChanged;
            ResetPreview();
        }

        private void OnProjectChanged() { scanStale = true; Repaint(); }
        private void PlayModeChanged(PlayModeStateChange mode)
        {
            if (mode == PlayModeStateChange.ExitingEditMode || mode == PlayModeStateChange.EnteredEditMode) ResetPreview();
        }

        private void Tick()
        {
            if (EditorApplication.isPlayingOrWillChangePlaymode) return;
            TickAssembly();
            if (startScan)
            {
                try { StartIndex(); }
                catch (Exception e) { startScan = false; pending = null; message = "검색을 시작하지 못했습니다: " + e.Message; Repaint(); }
            }
            if (pending != null) IndexStep();
            TickThumbnail();
            if (renderer != null && renderer.TickCamera()) Repaint();
            if (!playing || active == null || !active.Clip || !rendererIsReady) return;
            var now = EditorApplication.timeSinceStartup;
            if (now - lastPlayback < 1.0 / 30) return;
            time = Mathf.Repeat(time + (float)(now - lastPlayback), Mathf.Max(.001f, active.Clip.length));
            lastPlayback = now;
            sampleDirty = true;
            Repaint();
        }

        private void OnGUI()
        {
            if (EditorApplication.isPlayingOrWillChangePlaymode)
            {
                EditorGUILayout.HelpBox("플레이 모드를 끝낸 뒤 포즈 탐색기를 사용하세요.", MessageType.Info);
                return;
            }
            using (new EditorGUILayout.HorizontalScope())
            {
                var next = (GameObject)EditorGUILayout.ObjectField("미리 볼 아바타", avatar, typeof(GameObject), true);
                if (next != avatar) ChangeAvatar(FindAvatar(next));
                if (GUILayout.Button("Hierarchy 선택", GUILayout.Width(108))) ChangeAvatar(FindAvatar(Selection.activeGameObject));
            }
            using (new EditorGUILayout.HorizontalScope())
            {
                var next = EditorGUILayout.ToggleLeft("Modular Avatar 조립 미리보기", assemblePreview, GUILayout.Width(208));
                if (next != assemblePreview) { assemblePreview = next; ResetPreview(); }
                using (new EditorGUI.DisabledScope(!avatar))
                    if (GUILayout.Button("미리보기 갱신", GUILayout.Width(99))) ResetPreview();
                if (avatar)
                {
                    bool fullBuild = assembled != null && assembled.UsedFullBuild;
                    var status = !assemblePreview ? "원본" : assemblyPending ? "조립 대기 중…" : assemblyError != null ? "조립 실패 · 원본 표시" :
                        fullBuild ? "전체 빌드로 조립" : "MA 조립 완료";
                    var tip = assemblyError ?? (fullBuild
                        ? "이 NDMF 버전에서는 MA만 따로 실행할 수 없어 설치된 NDMF 플러그인 전체로 조립했습니다."
                        : null);
                    GUILayout.Label(new GUIContent(status, tip), EditorStyles.miniLabel);
                }
            }
            DrawDeckBar();
            EditorGUILayout.Space();
            using (new EditorGUILayout.HorizontalScope(GUILayout.ExpandHeight(true)))
            {
                DrawGallery(Mathf.Clamp(position.width * splitRatio, 270f, position.width - 325f));
                DrawSplitter();
                DrawPreview();
            }
        }

        private const string SplitPreference = "PersonalPoseDeck.SplitRatio";
        private float splitRatio = .55f;

        private void DrawSplitter()
        {
            var rect = GUILayoutUtility.GetRect(7f, 7f, 1f, 10000f, GUILayout.Width(7f), GUILayout.ExpandHeight(true));
            int id = GUIUtility.GetControlID("PoseDeckSplitter".GetHashCode(), FocusType.Passive, rect);
            var evt = Event.current;
            EditorGUIUtility.AddCursorRect(rect, MouseCursor.ResizeHorizontal);
            if (evt.type == EventType.Repaint)
                EditorGUI.DrawRect(new Rect(rect.center.x - 1f, rect.y, 2f, rect.height),
                    GUIUtility.hotControl == id ? new Color(.31f, .61f, .85f) : new Color(.35f, .36f, .39f));
            if (evt.type == EventType.MouseDown && evt.button == 0 && rect.Contains(evt.mousePosition))
            {
                if (evt.clickCount > 1) { splitRatio = .55f; EditorPrefs.SetFloat(SplitPreference, splitRatio); }
                else GUIUtility.hotControl = id;
                evt.Use();
                Repaint();
            }
            else if (GUIUtility.hotControl == id && evt.type == EventType.MouseDrag)
            {
                splitRatio = Mathf.Clamp(evt.mousePosition.x, 270f, position.width - 325f) / position.width;
                evt.Use();
                Repaint();
            }
            else if (GUIUtility.hotControl == id && (evt.type == EventType.MouseUp || evt.type == EventType.Ignore))
            {
                GUIUtility.hotControl = 0;
                EditorPrefs.SetFloat(SplitPreference, splitRatio);
                if (evt.type == EventType.MouseUp) evt.Use();
                Repaint();
            }
        }

        private void OnLostFocus() => renderer?.StopCameraDrag();

        private static GameObject FindDeckTarget(GameObject selected)
        {
            if (!selected) return null;
            var avatarRoot = FindAvatar(selected);
            if (selected != avatarRoot && selected.name.IndexOf("gogoloco", StringComparison.OrdinalIgnoreCase) >= 0) return selected;
            var child = avatarRoot.GetComponentsInChildren<Transform>(true).FirstOrDefault(t =>
                t.name.Equals("GogoLoco All (Modular Avatar)", StringComparison.OrdinalIgnoreCase));
            return child ? child.gameObject : null;
        }

        private void Do(Func<string> action)
        {
            try { deckStatus = action(); deckStatusType = MessageType.Info; }
            catch (Exception e) { deckStatus = e.Message; deckStatusType = MessageType.Error; }
        }

        private void NewPreset()
        {
            string path = EditorUtility.SaveFilePanelInProject("포즈 프리셋 저장", "MyPoseDeck", "asset", "프리셋을 Assets에 저장하세요.");
            if (string.IsNullOrEmpty(path)) return;
            preset = CreateInstance<PoseDeckPreset>();
            AssetDatabase.CreateAsset(preset, AssetDatabase.GenerateUniqueAssetPath(path));
            AssetDatabase.SaveAssets();
            deckStatus = null;
        }

        private void DrawDeckBar()
        {
            int next = EditorGUILayout.Popup("적용 방식", applyMode, ApplyModes);
            if (next != applyMode) { applyMode = next; deckStatus = null; }
            bool onAvatar = applyMode == 1;
            using (new EditorGUILayout.HorizontalScope())
            {
                if (onAvatar)
                    EditorGUILayout.LabelField("적용 대상", avatar ? avatar.name + " (위에서 선택한 아바타)" : "위에서 아바타를 선택하세요.");
                else
                {
                    target = (GameObject)EditorGUILayout.ObjectField("GoGoLoco 오브젝트", target, typeof(GameObject), true);
                    if (GUILayout.Button("아바타에서 찾기", GUILayout.Width(104))) target = FindDeckTarget(avatar);
                }
            }
            using (new EditorGUILayout.HorizontalScope())
            {
                preset = (PoseDeckPreset)EditorGUILayout.ObjectField("포즈 프리셋", preset, typeof(PoseDeckPreset), false);
                if (GUILayout.Button("새 프리셋", GUILayout.Width(85))) NewPreset();
                using (new EditorGUI.DisabledScope(!preset || !(onAvatar ? avatar : target)))
                {
                    if (GUILayout.Button("슬롯 확인", GUILayout.Width(84))) Do(() =>
                        onAvatar ? PoseDeckAvatarInstall.Preview(preset, avatar) : PoseDeckBuilder.Preview(preset, target));
                    if (GUILayout.Button("생성 및 적용", GUILayout.Width(100))) Do(() =>
                    {
                        string folder = onAvatar ? PoseDeckAvatarInstall.Apply(preset, avatar) : PoseDeckBuilder.GenerateAndApply(preset, target);
                        ResetPreview();
                        return $"‘{preset.name}’의 포즈 {preset.poses.Count}개를 적용했습니다. 씬을 저장하고 Build & Test로 확인하세요.\n" + folder;
                    });
                }
                using (new EditorGUI.DisabledScope(onAvatar ? !avatar : !target))
                {
                    if (GUILayout.Button(onAvatar ? "적용 제거" : "GoGoLoco 원복", GUILayout.Width(106))) Do(() =>
                    {
                        if (onAvatar) PoseDeckAvatarInstall.Remove(avatar);
                        else PoseDeckBuilder.Restore(preset, target);
                        ResetPreview();
                        return onAvatar ? "이 아바타에 추가한 Pose Deck을 제거했습니다. 씬을 저장하세요."
                            : "원래 Base와 메뉴로 복구했습니다. 씬을 저장하세요.";
                    });
                }
            }
            if (!string.IsNullOrEmpty(deckStatus)) EditorGUILayout.HelpBox(deckStatus, deckStatusType);
        }

        private void DrawDeckSettings()
        {
            if (!preset) return;
            deckOpen = EditorGUILayout.Foldout(deckOpen, $"Deck 설정 · 선택한 포즈 {preset.poses.Count}개", true);
            if (!deckOpen) return;
            using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
            {
                EditorGUI.BeginChangeCheck();
                var title = EditorGUILayout.TextField("메뉴 이름", preset.menuTitle);
                var keep = EditorGUILayout.ToggleLeft("메뉴 안에 기존 GoGoLoco도 남기기", preset.keepStockMenu);
                if (EditorGUI.EndChangeCheck())
                {
                    Undo.RecordObject(preset, "Edit Pose Deck Settings");
                    preset.menuTitle = title;
                    preset.keepStockMenu = keep;
                    EditorUtility.SetDirty(preset);
                }

                using (var view = new EditorGUILayout.ScrollViewScope(deckScroll, GUILayout.Height(106)))
                {
                    deckScroll = view.scrollPosition;
                    for (int i = 0; i < preset.poses.Count; i++)
                    {
                        int index = i;
                        var row = preset.poses[i];
                        using (new EditorGUILayout.HorizontalScope())
                        {
                            GUILayout.Label((i + 1).ToString(), GUILayout.Width(24));
                            EditorGUI.BeginChangeCheck();
                            var label = EditorGUILayout.TextField(row.label ?? "", GUILayout.MinWidth(46));
                            var clip = (AnimationClip)EditorGUILayout.ObjectField(row.clip, typeof(AnimationClip), false, GUILayout.MinWidth(65));
                            var cat = EditorGUILayout.Popup((int)row.category, PoseDeckBuilder.CategoryNames, GUILayout.Width(66));
                            if (EditorGUI.EndChangeCheck())
                            {
                                Change("Edit Pose", () => { row.label = label; row.clip = clip; row.category = (PoseCategory)cat; });
                            }
                            using (new EditorGUI.DisabledScope(i == 0))
                                if (GUILayout.Button("↑", GUILayout.Width(25)))
                                { Change("Move Pose", () => { preset.poses.RemoveAt(index); preset.poses.Insert(index - 1, row); }); break; }
                            using (new EditorGUI.DisabledScope(i == preset.poses.Count - 1))
                                if (GUILayout.Button("↓", GUILayout.Width(25)))
                                { Change("Move Pose", () => { preset.poses.RemoveAt(index); preset.poses.Insert(index + 1, row); }); break; }
                            if (GUILayout.Button("×", GUILayout.Width(25)))
                            { Change("Remove Pose", () => preset.poses.RemoveAt(index)); break; }
                        }
                    }
                }

                using (new EditorGUILayout.HorizontalScope())
                {
                    if (GUILayout.Button("+ 포즈 추가")) Change("Add Pose", () => preset.poses.Add(new PoseEntry()));
                    if (GUILayout.Button("+ Project 선택"))
                    {
                        var clips = Selection.objects.OfType<AnimationClip>().ToArray();
                        if (clips.Length != 0) Change("Add Selected Poses", () =>
                            preset.poses.AddRange(clips.Select(c => new PoseEntry { clip = c })));
                        else { deckStatus = "Project 창에서 애니메이션 클립을 먼저 선택하세요."; deckStatusType = MessageType.Warning; }
                    }
                    if (GUILayout.Button("프리셋만 저장")) Do(() =>
                    {
                        AssetDatabase.SaveAssetIfDirty(preset);
                        return $"‘{preset.name}’에 포즈 {preset.poses.Count}개를 저장했습니다. 아바타에 반영하려면 ‘생성 및 적용’을 눌러 주세요.";
                    });
                    if (GUILayout.Button(new GUIContent("안 쓰는 생성본 정리",
                        "씬·프리팹·프리셋 어디에서도 쓰지 않는 PoseDeck_Generated 폴더를 휴지통으로 옮깁니다."))) Do(CleanUpGenerated);
                }
            }
        }

        private static string CleanUpGenerated()
        {
            var folders = PoseDeckBuilder.FindUnusedGeneratedFolders();
            if (folders.Length == 0) return "정리할 생성본이 없습니다. 씬·프리팹·프리셋이 쓰는 폴더는 남겨 둡니다.";
            var list = string.Join("\n", folders.Take(12)) + (folders.Length > 12 ? $"\n외 {folders.Length - 12}개" : "");
            if (!EditorUtility.DisplayDialog("안 쓰는 생성본 정리",
                    $"Assets의 씬·프리팹·에셋 어디에서도 쓰지 않는 생성 폴더 {folders.Length}개를 휴지통으로 옮깁니다.\n\n{list}",
                    "휴지통으로 이동", "취소"))
                return "정리를 취소했습니다.";
            int moved = folders.Count(AssetDatabase.MoveAssetToTrash);
            return $"생성 폴더 {moved}개를 휴지통으로 옮겼습니다." +
                (moved < folders.Length ? $" {folders.Length - moved}개는 옮기지 못했습니다. Unity Console을 확인하세요." : "");
        }

        private void Change(string undoName, Action edit)
        {
            Undo.RecordObject(preset, undoName);
            edit();
            EditorUtility.SetDirty(preset);
        }
    }
}
