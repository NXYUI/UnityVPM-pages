using System;
using System.Collections.Generic;
using System.Linq;
using nadena.dev.ndmf;
using UnityEngine;
using Control = VRC.SDK3.Avatars.ScriptableObjects.VRCExpressionsMenu.Control;

namespace AvatarMenuTools
{
    [DisallowMultipleComponent]
    [AddComponentMenu("NXYUI/Avatar Customizer")]
    public sealed class AvatarCustomizer : MonoBehaviour, INDMFEditorOnly
    {
        // Keep the first menu in its original serialized fields. Existing scenes and prefab overrides need no migration.
        public string menuName = "즐겨찾기";
        public bool useRoot = true;
        public FavoriteMenuKey destination = new FavoriteMenuKey();
        public List<FavoriteMenuEntry> entries = new List<FavoriteMenuEntry>();
        public List<MenuNameOverride> nameOverrides = new List<MenuNameOverride>();
        public string nextPageLabel = "";
        public List<FavoriteMenuGroup> additionalMenus = new List<FavoriteMenuGroup>();
        public bool pinToFirstPage;
        public Texture2D menuIcon;
        // Starting values of built menu items (toggles and radials), wherever they sit, by menu path and parameter.
        public List<MenuDefaultOverride> defaultOverrides = new List<MenuDefaultOverride>();
        // In-game controls for blendshapes. Each one is built only while a favorites menu holds it (entry.shapeId).
        public List<BlendshapeControl> blendshapeControls = new List<BlendshapeControl>();

        public BlendshapeControl FindShape(string id) => string.IsNullOrEmpty(id) ? null :
            blendshapeControls?.FirstOrDefault(s => s != null && s.id == id);

        // Every favorites menu, the first one included.
        public IEnumerable<FavoriteMenuGroup> AllMenus() =>
            new[] { GetMenu(0) }.Concat(additionalMenus ?? Enumerable.Empty<FavoriteMenuGroup>()).Where(m => m != null);

        public FavoriteMenuGroup GetMenu(int index)
        {
            if (index == 0)
                return new FavoriteMenuGroup
                {
                    name = menuName, useRoot = useRoot, destination = destination,
                    entries = entries, pinToFirstPage = pinToFirstPage, icon = menuIcon,
                };
            return index > 0 && additionalMenus != null && index <= additionalMenus.Count ? additionalMenus[index - 1] : null;
        }
    }

    [Serializable]
    public sealed class FavoriteMenuGroup
    {
        public string name = "새 메뉴";
        public bool useRoot = true;
        public FavoriteMenuKey destination;
        public List<FavoriteMenuEntry> entries = new List<FavoriteMenuEntry>();
        public bool pinToFirstPage;
        public Texture2D icon;

        public string DisplayName => string.IsNullOrWhiteSpace(name) ? "즐겨찾기" : name.Trim();
    }

    public enum FavoriteMenuMatch { Exact, Moved, Changed, Missing, Ambiguous }

    [Serializable]
    public sealed class FavoriteMenuKey
    {
        public string[] path;
        public Control.ControlType type;
        public string parameter;
        public string[] subParameters;
        public float value;
        [NonSerialized] public int sharedControl;

        public string DisplayPath => string.Join(" / ", path ?? Array.Empty<string>());
        public string Binding => string.Join(", ", new[] { parameter }.Concat(subParameters ?? Array.Empty<string>())
            .Where(p => !string.IsNullOrEmpty(p)));
        public string Name => path?.LastOrDefault() ?? "";

        public bool SamePath(FavoriteMenuKey other) => type == other.type &&
            (path ?? Array.Empty<string>()).SequenceEqual(other.path ?? Array.Empty<string>(), StringComparer.Ordinal);

        public bool SameBinding(FavoriteMenuKey other) => type == other.type && value.Equals(other.value) &&
            string.Equals(parameter ?? "", other.parameter ?? "", StringComparison.Ordinal) &&
            (subParameters ?? Array.Empty<string>()).SequenceEqual(other.subParameters ?? Array.Empty<string>(), StringComparer.Ordinal);

        public static FavoriteMenuKey Resolve(IReadOnlyList<FavoriteMenuKey> catalogue, FavoriteMenuKey key) =>
            Resolve(catalogue, key, out _);

        public static FavoriteMenuKey Resolve(IReadOnlyList<FavoriteMenuKey> catalogue, FavoriteMenuKey key,
            out FavoriteMenuMatch match)
        {
            match = FavoriteMenuMatch.Missing;
            if (key?.path == null || key.path.Length == 0) return null;
            var atPath = catalogue.Where(x => key.SamePath(x)).ToArray();
            var exact = UniqueControl(atPath.Where(x => key.SameBinding(x)));
            if (exact != null) { match = FavoriteMenuMatch.Exact; return exact; }
            if (atPath.Length == 1)
            {
                // Generated parameter names can change between builds. Keep the fallback visible.
                match = FavoriteMenuMatch.Changed;
                return atPath[0];
            }
            if (atPath.Length > 0) { match = FavoriteMenuMatch.Ambiguous; return null; }
            // Moved: the same kind of item under the same name elsewhere (with the same parameter, when it has one).
            // Of several, the one sharing the longest end of the old path, e.g. "기믹/ABT/핀/동기화" → "ABT/핀/동기화"
            // after the ABT menu moved out of 기믹. Submenus have no parameter, so this is how they are found again,
            // and so are buttons that share a parameter across submenus.
            bool submenu = key.type == Control.ControlType.SubMenu;
            var sameName = catalogue.Where(x => x.Name == key.Name && (submenu
                ? x.type == key.type && string.Equals(x.parameter ?? "", key.parameter ?? "", StringComparison.Ordinal)
                : key.SameBinding(x))).ToArray();
            var moved = Closest(sameName, key);
            // Renamed as well: the parameter alone, when a single control uses it.
            var sameBinding = submenu || key.Binding.Length == 0 ? Array.Empty<FavoriteMenuKey>()
                : catalogue.Where(x => key.SameBinding(x)).ToArray();
            if (moved == null && sameName.Length == 0) moved = UniqueControl(sameBinding);
            if (moved != null) match = FavoriteMenuMatch.Moved;
            else if (sameName.Length > 0 || sameBinding.Length > 0) match = FavoriteMenuMatch.Ambiguous;
            return moved;
        }

        // The candidate that shares the most trailing path segments with key, when only one control does.
        private static FavoriteMenuKey Closest(IReadOnlyList<FavoriteMenuKey> candidates, FavoriteMenuKey key)
        {
            if (candidates.Count == 0) return null;
            var path = key.path;
            int Shared(FavoriteMenuKey x)
            {
                var other = x.path ?? Array.Empty<string>();
                int n = 0;
                while (n < path.Length && n < other.Length &&
                       string.Equals(path[path.Length - 1 - n], other[other.Length - 1 - n], StringComparison.Ordinal)) n++;
                return n;
            }
            int best = candidates.Max(Shared);
            return UniqueControl(candidates.Where(x => Shared(x) == best));
        }

        private static FavoriteMenuKey UniqueControl(IEnumerable<FavoriteMenuKey> keys)
        {
            FavoriteMenuKey first = null;
            foreach (var key in keys)
            {
                if (first == null) first = key;
                else if (first.sharedControl == 0 || key.sharedControl != first.sharedControl) return null;
            }
            return first;
        }
    }

    [Serializable]
    public sealed class FavoriteMenuEntry
    {
        public FavoriteMenuKey source;
        public string label;
        public string folderId;
        public string parentId;
        // Folder icon, or for a shortcut an icon used instead of the original's.
        public Texture2D icon;
        // Starting value of the item's parameter on the built avatar: a toggle on (1) or off (0), a radial 0–1.
        // Off keeps the avatar's own default. Saved by 2.0.0; later versions keep defaults in
        // AvatarCustomizer.defaultOverrides and still apply these.
        public bool overrideDefault;
        public float defaultValue;
        // A blendshape control of the component (BlendshapeControl.id) instead of a built menu item.
        public string shapeId;
        public bool IsFolder => !string.IsNullOrEmpty(folderId);
        public bool IsShape => !IsFolder && !string.IsNullOrEmpty(shapeId);
        public bool IsShapeReset => IsShape && shapeId == BlendshapeControl.ResetId;
        public string Parent => parentId ?? "";
    }

    public enum BlendshapeControlType { Radial, Toggle }

    // A menu control for one blendshape: an FX layer and an expression parameter made when the avatar is built.
    [Serializable]
    public sealed class BlendshapeControl
    {
        public string id;
        public SkinnedMeshRenderer renderer;
        public string blendshape;
        public BlendshapeControlType type;
        // Blendshape weight at radial 0% / toggle off, and at radial 100% / toggle on.
        public float min;
        public float max = 100f;
        // Radial position (0–1) or toggle state (0 off, 1 on) when the avatar first loads.
        public float defaultValue;
        public bool synced = true;
        public bool saved = true;

        // A favorites entry with this shapeId is the reset button: pressing it puts every built control back to its
        // default (StartValue). Control ids are hexadecimal, so they never take this one.
        public const string ResetId = "reset";
        public const string ResetParameter = "NXYUI/Customizer/Reset";

        public string Parameter => "NXYUI/Customizer/" + id;
        // What the expression parameter starts at: the radial position, or 0/1 for a toggle.
        public float StartValue => type == BlendshapeControlType.Toggle ? (defaultValue >= .5f ? 1f : 0f) : Mathf.Clamp01(defaultValue);
        // Synced expression parameter memory: a float takes 8 bits, a bool 1.
        public int SyncedBits => !synced ? 0 : type == BlendshapeControlType.Radial ? 8 : 1;
    }

    // The starting value of a built menu item's parameter: a toggle on (1) or off (0), a radial 0–1.
    [Serializable]
    public sealed class MenuDefaultOverride
    {
        public FavoriteMenuKey source;
        public float value;
    }

    [Serializable]
    public sealed class MenuNameOverride
    {
        public FavoriteMenuKey source;
        public string label;
    }
}
