using System;
using System.Collections.Generic;
using System.Linq;
using nadena.dev.modular_avatar.core;
using UnityEditor;
using UnityEditor.Animations;
using UnityEngine;
using VRC.SDK3.Avatars.Components;
using TrackingType = VRC.SDKBase.VRC_AnimatorTrackingControl.TrackingType;

namespace PersonalPoseDeck
{
    // Animators on the avatar, other than GoGoLoco's and Pose Deck's, with a state that puts the hips or feet on Tracking.
    // Such a layer can hand a pose's legs back to IK while it plays: AvatarBasicTool's tracking layer does whenever its
    // own poses are off, which is how it gives 3-point users moving legs. Read from the descriptor's playable layers (those
    // no MA Merge Animator replaces) and the MA Merge Animators; animators other tools add at build time (VRCFury) are
    // not seen.
    internal static class PoseDeckTrackingGimmicks
    {
        internal static string[] Find(GameObject avatar)
        {
            if (!avatar) return Array.Empty<string>();
            var merges = avatar.GetComponentsInChildren<ModularAvatarMergeAnimator>(true).Where(m => m && m.animator).ToArray();
            var replaced = new HashSet<VRCAvatarDescriptor.AnimLayerType>(merges.Where(Replaces).Select(m => m.layerType));
            var sources = new List<(string Owner, RuntimeAnimatorController Controller)>();
            var descriptor = avatar.GetComponent<VRCAvatarDescriptor>();
            if (descriptor && descriptor.customizeAnimationLayers)
                foreach (var layer in (descriptor.baseAnimationLayers ?? Array.Empty<VRCAvatarDescriptor.CustomAnimLayer>())
                         .Concat(descriptor.specialAnimationLayers ?? Array.Empty<VRCAvatarDescriptor.CustomAnimLayer>()))
                    if (!layer.isDefault && layer.animatorController && !replaced.Contains(layer.type))
                        sources.Add((avatar.name, layer.animatorController));
            sources.AddRange(merges.Select(m => (m.gameObject.name, m.animator)));
            var found = new List<string>();
            foreach (var (owner, runtime) in sources)
            {
                var controller = runtime as AnimatorController ??
                                 (runtime as AnimatorOverrideController)?.runtimeAnimatorController as AnimatorController;
                if (!controller || IsGoGoLocoOrDeck(controller) || !SetsLegTracking(controller)) continue;
                string label = $"{owner} ({controller.name})";
                if (!found.Contains(label)) found.Add(label);
            }
            return found.ToArray();
        }

        // Read through the serialized field, so an MA release that moves it does not break the build of this package.
        private static bool Replaces(ModularAvatarMergeAnimator merge)
        {
            var mode = new SerializedObject(merge).FindProperty("mergeAnimatorMode");
            return mode != null && mode.propertyType == SerializedPropertyType.Enum && mode.enumValueIndex == 1;
        }

        private static bool IsGoGoLocoOrDeck(AnimatorController controller)
        {
            string path = AssetDatabase.GetAssetPath(controller);
            return PoseDeckBuilder.VendorRoots.Any(root => path.StartsWith(root, StringComparison.Ordinal)) ||
                   path.Contains("/PoseDeck_Generated") || controller.parameters.Any(p => p.name == "Go/Pose");
        }

        private static bool SetsLegTracking(AnimatorController controller) =>
            controller.layers.SelectMany(l => Machines(l.stateMachine)).SelectMany(m => m.states).Any(s => s.state &&
                s.state.behaviours.OfType<VRCAnimatorTrackingControl>().Any(t =>
                    t.trackingHip == TrackingType.Tracking || t.trackingLeftFoot == TrackingType.Tracking ||
                    t.trackingRightFoot == TrackingType.Tracking));

        private static IEnumerable<AnimatorStateMachine> Machines(AnimatorStateMachine machine)
        {
            if (!machine) yield break;
            yield return machine;
            foreach (var child in machine.stateMachines)
                foreach (var nested in Machines(child.stateMachine)) yield return nested;
        }
    }
}
