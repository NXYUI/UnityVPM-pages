using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEditor.Animations;
using UnityEngine;
using UnityEngine.Animations;
using UnityEngine.Playables;
using UnityEngine.Rendering;
using UnityEngine.SceneManagement;
using VRC.Dynamics;
using VRC.SDK3.Avatars.Components;
using VRC.SDKBase;
using Object = UnityEngine.Object;

namespace PersonalPoseDeck
{
    // Copies the rig and renderers only. No scene behaviours are instantiated; the only controller ever run is
    // GoGoLoco's own Base, for the start-height preview.
    internal sealed class PoseDeckPosePreview : IDisposable
    {
        // GoGoLoco enters a pose through VRChat parameter drivers (Go/Pose, Go/Float, …). The editor does not run them,
        // so apply them here for preview rigs only, the way Gesture Manager emulates them.
        private static readonly HashSet<Animator> Simulated = new HashSet<Animator>();
        private static bool driverHooked;

        private static void ApplyDriver(VRC_AvatarParameterDriver driver, Animator target)
        {
            if (!target || !Simulated.Contains(target)) return;
            foreach (var p in driver.parameters)
            {
                if (p.type != VRC_AvatarParameterDriver.ChangeType.Set && p.type != VRC_AvatarParameterDriver.ChangeType.Add) continue;
                var param = target.parameters.FirstOrDefault(x => x.name == p.name);
                if (param == null) continue;
                // By hash: VRCFury patches the by-name parameter methods in the editor, and on preview rigs they throw
                // ("The Playable is null").
                int id = param.nameHash;
                float current = param.type == AnimatorControllerParameterType.Float ? target.GetFloat(id) :
                    param.type == AnimatorControllerParameterType.Int ? target.GetInteger(id) : target.GetBool(id) ? 1f : 0f;
                float value = p.type == VRC_AvatarParameterDriver.ChangeType.Add ? current + p.value : p.value;
                if (param.type == AnimatorControllerParameterType.Float) target.SetFloat(id, value);
                else if (param.type == AnimatorControllerParameterType.Int) target.SetInteger(id, Mathf.RoundToInt(value));
                else target.SetBool(id, value != 0f);
            }
        }

        private PoseDeckBuilder.PreviewSource gogo;
        private AnimatorOverrideController gogoOverride;
        // The shown clip with GoGoLoco's additive reference pose, when it needs one (PoseDeckBuilder.NeedsReference).
        private AnimationClip gogoPose;
        private int gogoSlot, gogoLayer = -1, gogoState;
        private float startHeight = PoseDeckBuilder.DefaultStartHeight, eyeHeight = 1.3f;
        private bool gogoDirty, gogoReady;
        private string gogoProblem;
        private readonly PreviewRenderUtility preview;
        private readonly Dictionary<Transform, Transform> rig = new Dictionary<Transform, Transform>();
        private readonly List<Renderer> renderers = new List<Renderer>();
        // The meshes that move with the humanoid skeleton (skinned to bones under the hips, or placed under them): the
        // floor reading and the framing use only these. Objects elsewhere under the avatar (world-fixed objects, floor
        // helpers, outfits still on their own armature) do not follow the pose; Modular Avatar's assembly can put them
        // far below the feet. All renderers when the avatar is not humanoid.
        private readonly List<Renderer> measured = new List<Renderer>();
        // What the floor reading measures: each measured mesh with the vertices the skeleton holds in place (null: all of
        // them). Hair, skirts, tails and leashes that a PhysBone swings are left out. The preview does not simulate them,
        // so they hang in their rest shape (long hair can reach far below the feet), and in VRChat they fall and rest on
        // their colliders instead of carrying the avatar. The bone a PhysBone starts from still counts.
        private readonly List<(Renderer renderer, int[] vertices)> floorMeshes = new List<(Renderer, int[])>();
        private double nextPlayingMeasure;
        private readonly List<(Transform bone, Vector3 position, Quaternion rotation, Vector3 scale)> rest =
            new List<(Transform, Vector3, Quaternion, Vector3)>();
        private Animator animator;
        private Transform previewRoot;
        private readonly PoseDeckPreviewConstraints constraints;
        private PlayableGraph graph;
        private AnimationClipPlayable playable;
        private AnimationClip clip;
        private Bounds frame;
        // The camera works like Unity's Scene view: one perspective camera looking at a pivot from a distance, at the
        // orbit angles (yaw 0 looks at the avatar's front, +Z; a negative pitch looks down from above). Orbiting turns
        // around the pivot; looking around with the right button turns the camera in place and carries the pivot along
        // in front of it, so the next orbit turns around what is in front of the camera.
        private const float FieldOfView = 60f, MaxPitch = 89f, MinDistance = .02f, MaxDistance = 200f;
        // The Scene view's mouse speeds: .003 rad per pixel to turn, size × (1 + .015 × wheel delta) to zoom.
        private const float DegreesPerPixel = .003f * Mathf.Rad2Deg, WheelZoom = .015f;
        private Vector3 pivot;
        private float yaw = 45f, pitch = -25f, distance = 2.5f;
        // Width over height of the last drawn preview; Fit frames the bounds in it.
        private float aspect = 1f;
        private enum CameraDrag { None, Orbit, Pan, Zoom, Look }
        private CameraDrag drag;
        private int dragButton;
        // How fast WASD/QE fly while looking around; the wheel changes it then, as in the Scene view.
        private float flySpeed = 1f;
        private double lastCameraTick, flySpeedShownUntil;
        private readonly HashSet<KeyCode> movementKeys = new HashSet<KeyCode>();
        // Mirroring goes through a one-state, in-memory controller so Unity mirrors the pose exactly as GoGoLoco's
        // "Right" states (AnimatorState.mirror) do in game.
        private static readonly int MirrorStateHash = Animator.StringToHash("Pose");
        private AnimatorController mirrorController;
        private AnimatorControllerPlayable controllerPlayable;
        private bool mirror;
        private GameObject floor;
        private Mesh floorMesh;
        private Material floorMaterial;
        private PoseDeckVrPose vrPose;

        // The VR look (PoseDeckVrPose) put on each sample; null shows the pose as animated. VrHandsOnClip keeps the hands
        // on the clip, as a deck pose with "VR에서 손도 포즈대로" plays in game.
        internal PoseDeckVrPose.Settings? Vr { get; set; }
        internal bool VrHandsOnClip { get; set; }
        // What the last sample's VR look moved. Not valid when Vr is off or the pose could not be shown.
        internal PoseDeckVrPose.Result VrResult { get; private set; }
        internal PoseDeckVrPose VrRig => vrPose;

        // How far the head and hands would move in VR from the pose as last sampled, without showing it.
        internal PoseDeckVrPose.Result MeasureVr(PoseDeckVrPose.Settings settings) =>
            vrPose != null && vrPose.Valid && clip && clip.humanMotion && (!SimulatingGoGoLoco || gogoReady)
                ? vrPose.Measure(settings) : default;

        internal bool HasHumanoidAvatar => animator && animator.avatar && animator.avatar.isValid && animator.avatar.isHuman;
        internal bool HasRenderers => renderers.Count != 0;
        // Lowest point of the meshes above the avatar root (the floor), from floorMeshes. Measured on every sample when
        // ExactMeasure is on; while playing, a few times a second after a draw.
        internal float? LowestPoint { get; private set; }
        internal bool ExactMeasure { get; set; } = true;

        // True while the pose is shown as GoGoLoco places it in game for StartHeight (VR, 3-point tracking).
        internal bool SimulatingGoGoLoco => gogo != null && clip && clip.humanMotion && HasHumanoidAvatar;
        internal bool GoGoLocoReady => SimulatingGoGoLoco && gogoReady;
        internal string GoGoLocoProblem => gogoProblem;

        internal enum Tracking { VR, Desktop, FullBody }

        // VRChat's TrackingType / VRMode for the simulated user. GoGoLoco picks its desktop or VR pose variant from them.
        // With full body (TrackingType > 4) GoGoLoco plays no poses at all: its Action layer resets VRCEmote to 0 and
        // the Base only enters a pose below 5 tracked points.
        internal Tracking Mode
        {
            get => mode;
            set { if (mode != value) { mode = value; gogoDirty = true; } }
        }
        private Tracking mode = Tracking.VR;

        internal float StartHeight
        {
            get => startHeight;
            set
            {
                value = Mathf.Clamp01(value);
                if (Mathf.Approximately(startHeight, value)) return;
                startHeight = value;
                gogoDirty = true;
            }
        }

        // null turns the GoGoLoco preview off and shows the clip on its own again.
        internal void UseGoGoLoco(PoseDeckBuilder.PreviewSource source)
        {
            if (gogo == source) return;
            gogo = source;
            animator.runtimeAnimatorController = null;
            if (gogoOverride) { Object.DestroyImmediate(gogoOverride); gogoOverride = null; }
            var current = clip;
            clip = null;
            SetClip(current);
        }

        internal bool ShowFloor
        {
            get => floor && floor.activeSelf;
            set { if (floor) floor.SetActive(value); }
        }

        internal bool Mirror
        {
            get => mirror;
            set
            {
                if (mirror == value) return;
                mirror = value;
                var current = clip;
                clip = null;
                SetClip(current);
            }
        }

        internal PoseDeckPosePreview(GameObject avatar)
        {
            preview = new PreviewRenderUtility();
            try
            {
                Transform root = MakeNode(avatar.transform, null, true);
                previewRoot = root;
                CopyRenderers(avatar.transform, true);
                animator = root.gameObject.AddComponent<Animator>();
                var original = avatar.GetComponent<Animator>();
                if (original) animator.avatar = original.avatar;
                animator.applyRootMotion = false;
                animator.fireEvents = false;
                animator.cullingMode = AnimatorCullingMode.AlwaysAnimate;
                animator.Rebind();
                var hips = HasHumanoidAvatar ? animator.GetBoneTransform(HumanBodyBones.Hips) : null;
                measured.AddRange(hips ? renderers.Where(r => FollowsSkeleton(r, hips)) : renderers);
                if (measured.Count == 0) measured.AddRange(renderers);
                CollectFloorMeshes(avatar);
                // VRChat reports the view height as EyeHeightAsMeters; GoGoLoco scales its upper height range with it.
                var descriptor = avatar.GetComponent<VRCAvatarDescriptor>();
                var head = HasHumanoidAvatar ? animator.GetBoneTransform(HumanBodyBones.Head) : null;
                eyeHeight = descriptor ? descriptor.ViewPosition.y * avatar.transform.lossyScale.y :
                    head ? (head.position.y - root.position.y) * 1.06f : eyeHeight;
                foreach (var bone in rig.Values) rest.Add((bone, bone.localPosition, bone.localRotation, bone.localScale));
                vrPose = new PoseDeckVrPose(animator, root);
                constraints = new PoseDeckPreviewConstraints(avatar, Map);
                constraints.Apply();
                preview.camera.clearFlags = CameraClearFlags.Color;
                preview.camera.backgroundColor = new Color(.24f, .26f, .29f, 1f);
                preview.camera.orthographic = false;
                preview.ambientColor = new Color(.65f, .65f, .65f, 1f);
                preview.lights[0].intensity = 1.55f;
                preview.lights[0].transform.rotation = Quaternion.Euler(34f, -151f, 0f);
                preview.lights[1].intensity = 1.10f;
                preview.lights[1].transform.rotation = Quaternion.Euler(17f, 143f, 0f);
                Fit();
                CreateFloor(Mathf.Max(1.5f, frame.size.y * 1.6f));
            }
            catch
            {
                Dispose();
                throw;
            }
        }

        private Transform MakeNode(Transform source, Transform parent, bool isRoot)
        {
            var obj = EditorUtility.CreateGameObjectWithHideFlags(source.name, HideFlags.HideAndDontSave);
            obj.layer = source.gameObject.layer;
            var node = obj.transform;
            if (isRoot)
            {
                preview.AddSingleGO(obj);
                node.localScale = source.lossyScale;
            }
            else
            {
                SceneManager.MoveGameObjectToScene(obj, parent.gameObject.scene);
                node.SetParent(parent, false);
                node.localPosition = source.localPosition;
                node.localRotation = source.localRotation;
                node.localScale = source.localScale;
                obj.SetActive(source.gameObject.activeSelf);
            }
            rig.Add(source, node);
            foreach (Transform child in source) MakeNode(child, node, false);
            return node;
        }

        private Transform Map(Transform source) => source && rig.TryGetValue(source, out var node) ? node : null;

        // A line grid on the avatar's floor (y = 0 under the root), so floating or sinking poses are visible.
        private void CreateFloor(float size)
        {
            var shader = Shader.Find("Hidden/Internal-Colored");
            if (!shader) return;
            floorMaterial = new Material(shader) { hideFlags = HideFlags.HideAndDontSave };
            floorMaterial.SetInt("_SrcBlend", (int)BlendMode.SrcAlpha);
            floorMaterial.SetInt("_DstBlend", (int)BlendMode.OneMinusSrcAlpha);
            floorMaterial.SetInt("_Cull", (int)CullMode.Off);
            // No depth writes: drawn over the opaque avatar it only dims what is behind it, and the avatar's own
            // transparent materials (drawn later) are not hidden behind the floor when it is seen from below.
            floorMaterial.SetInt("_ZWrite", 0);
            var vertices = new List<Vector3>();
            var colors = new List<Color>();
            const int lines = 10;
            float half = size * .5f, step = size / lines;
            for (int i = 0; i <= lines; i++)
            {
                float o = -half + i * step;
                var color = i == lines / 2 ? new Color(.66f, .70f, .76f, .95f) : new Color(.46f, .49f, .55f, .55f);
                vertices.AddRange(new[] { new Vector3(o, 0, -half), new Vector3(o, 0, half), new Vector3(-half, 0, o), new Vector3(half, 0, o) });
                colors.AddRange(new[] { color, color, color, color });
            }
            int lineCount = vertices.Count;
            // A faint surface just under the lines: parts of the pose below the floor show through it dimmed.
            var fill = new Color(.42f, .47f, .55f, .28f);
            vertices.AddRange(new[] { new Vector3(-half, -.001f, -half), new Vector3(-half, -.001f, half),
                new Vector3(half, -.001f, half), new Vector3(half, -.001f, -half) });
            colors.AddRange(new[] { fill, fill, fill, fill });
            floorMesh = new Mesh { name = "Pose Deck floor", hideFlags = HideFlags.HideAndDontSave, subMeshCount = 2 };
            floorMesh.SetVertices(vertices);
            floorMesh.SetColors(colors);
            floorMesh.SetIndices(Enumerable.Range(0, lineCount).ToArray(), MeshTopology.Lines, 0);
            floorMesh.SetIndices(new[] { lineCount, lineCount + 1, lineCount + 2, lineCount, lineCount + 2, lineCount + 3 },
                MeshTopology.Triangles, 1);
            floorMaterial.renderQueue = (int)RenderQueue.Transparent;
            floor = EditorUtility.CreateGameObjectWithHideFlags("Pose Deck floor", HideFlags.HideAndDontSave,
                typeof(MeshFilter), typeof(MeshRenderer));
            floor.GetComponent<MeshFilter>().sharedMesh = floorMesh;
            var meshRenderer = floor.GetComponent<MeshRenderer>();
            meshRenderer.sharedMaterials = new[] { floorMaterial, floorMaterial };
            meshRenderer.shadowCastingMode = ShadowCastingMode.Off;
            meshRenderer.receiveShadows = false;
            preview.AddSingleGO(floor);
        }

        // Key light from the given position, fill light opposite it, ambient as a grey of the given strength.
        internal void ApplyLighting(PoseDeckPreviewLighting lighting)
        {
            if (lighting == null) return;
            var key = preview.lights[0];
            var towards = lighting.TowardsLight;
            key.transform.rotation = Quaternion.LookRotation(-towards, Vector3.up);
            key.intensity = lighting.intensity;
            key.color = lighting.LightColor;
            var fillLight = preview.lights[1];
            var opposite = new Vector3(-towards.x, Mathf.Max(.25f, towards.y * .5f), -towards.z).normalized;
            fillLight.transform.rotation = Quaternion.LookRotation(-opposite, Vector3.up);
            fillLight.intensity = lighting.fill;
            fillLight.color = Color.Lerp(Color.white, lighting.LightColor, .35f);
            preview.ambientColor = new Color(lighting.ambient, lighting.ambient, lighting.ambient, 1f);
        }

        internal float KeyIntensity => preview.lights[0].intensity;
        internal Vector3 KeyForward => preview.lights[0].transform.forward;

        // Material values from a lighting package (Light Limit Changer), set through property blocks so the materials
        // themselves are untouched. "_Name.x" style targets set one component of a vector property.
        internal int ApplyMaterialControls(IReadOnlyList<PoseDeckMaterialControl> controls, PoseDeckLightFilter filter = null)
        {
            int applied = 0;
            var block = new MaterialPropertyBlock();
            var vectors = new Dictionary<string, Vector4>();
            foreach (var r in renderers)
            {
                if (!r) continue;
                bool excluded = filter != null && filter.ExcludedPaths.Contains(AnimationUtility.CalculateTransformPath(r.transform, previewRoot));
                var materials = r.sharedMaterials;
                for (int i = 0; i < materials.Length; i++)
                {
                    block.Clear();
                    vectors.Clear();
                    var material = materials[i];
                    string key = material ? PoseDeckLightPackages.ShaderKey(material.shader) : null;
                    bool any = false;
                    if (key != null && controls != null && !excluded && (filter == null || filter.Allows(key, material)))
                        foreach (var control in controls)
                            foreach (var (shader, names) in control.Targets)
                            {
                                if (shader != key) continue;
                                foreach (var target in names)
                                {
                                    int dot = target.LastIndexOf('.');
                                    string property = dot > 0 ? target.Substring(0, dot) : target;
                                    int component = dot > 0 ? "xyzw".IndexOf(target[dot + 1]) : -1;
                                    if (!material.HasProperty(property)) continue;
                                    int index = material.shader.FindPropertyIndex(property);
                                    var type = index >= 0 ? material.shader.GetPropertyType(index) : ShaderPropertyType.Float;
                                    if (component >= 0 && type == ShaderPropertyType.Vector)
                                    {
                                        if (!vectors.TryGetValue(property, out var v)) v = material.GetVector(property);
                                        v[component] = control.Value;
                                        vectors[property] = v;
                                    }
                                    else if (component < 0 && (type == ShaderPropertyType.Float || type == ShaderPropertyType.Range))
                                        block.SetFloat(property, control.Value);
                                    else if (component < 0 && type == ShaderPropertyType.Int)
                                        block.SetInteger(property, Mathf.RoundToInt(control.Value));
                                    else continue;
                                    any = true;
                                }
                            }
                    foreach (var pair in vectors) block.SetVector(pair.Key, pair.Value);
                    r.SetPropertyBlock(block, i);
                    if (any) applied++;
                }
            }
            return applied;
        }

        // The view buttons: the avatar from that side, at the distance the camera has now.
        internal void SetView(float viewYaw, float viewPitch)
        {
            yaw = viewYaw;
            pitch = Mathf.Clamp(viewPitch, -MaxPitch, MaxPitch);
            pivot = frame.center;
            StopCameraDrag();
        }

        // The camera as the window keeps it between poses, window sessions and presets: the framed bounds, the pivot,
        // the orbit angles and the distance.
        internal PoseDeckCameraState CameraState
        {
            get => new PoseDeckCameraState
            {
                frameCenter = frame.center, frameSize = frame.size, pivot = pivot, yaw = yaw, pitch = pitch, distance = distance,
            };
            set
            {
                StopCameraDrag();
                frame = new Bounds(value.frameCenter, value.frameSize);
                yaw = value.yaw;
                pitch = Mathf.Clamp(value.pitch, -MaxPitch, MaxPitch);
                // Settings saved before 0.20.0 have no pivot or distance: look at the framed bounds from the fitted
                // distance, keeping the angles.
                if (value.distance > 0f)
                {
                    pivot = value.pivot;
                    distance = Mathf.Clamp(value.distance, MinDistance, MaxDistance);
                }
                else
                {
                    pivot = frame.center;
                    distance = FitDistance();
                }
            }
        }

        private Vector3 ToCamera => Quaternion.Euler(pitch, yaw, 0f) * Vector3.forward;
        private Vector3 CameraPosition => pivot + ToCamera * distance;
        private Quaternion CameraRotation => Quaternion.LookRotation(-ToCamera, Vector3.up);

        private void CopyRenderers(Transform source, bool visible)
        {
            var node = rig[source];
            foreach (var original in source.GetComponents<Light>())
            {
                var light = node.gameObject.AddComponent<Light>();
                EditorUtility.CopySerialized(original, light);
            }
            if (visible)
            {
                foreach (var old in source.GetComponents<SkinnedMeshRenderer>())
                {
                    if (!old.enabled || !old.sharedMesh) continue;
                    var oldBones = old.bones;
                    if (oldBones.Any(b => b && !rig.ContainsKey(b))) continue;
                    var copy = node.gameObject.AddComponent<SkinnedMeshRenderer>();
                    copy.sharedMesh = old.sharedMesh;
                    copy.sharedMaterials = old.sharedMaterials;
                    copy.bones = oldBones.Select(Map).ToArray();
                    copy.rootBone = Map(old.rootBone);
                    copy.localBounds = old.localBounds;
                    copy.updateWhenOffscreen = true;
                    copy.quality = old.quality;
                    for (int i = 0; i < old.sharedMesh.blendShapeCount; i++) copy.SetBlendShapeWeight(i, old.GetBlendShapeWeight(i));
                    renderers.Add(copy);
                }
                var oldFilter = source.GetComponent<MeshFilter>();
                var oldMesh = source.GetComponent<MeshRenderer>();
                if (oldFilter && oldFilter.sharedMesh && oldMesh && oldMesh.enabled)
                {
                    node.gameObject.AddComponent<MeshFilter>().sharedMesh = oldFilter.sharedMesh;
                    var copy = node.gameObject.AddComponent<MeshRenderer>();
                    copy.sharedMaterials = oldMesh.sharedMaterials;
                    renderers.Add(copy);
                }
            }
            foreach (Transform child in source) CopyRenderers(child, visible && child.gameObject.activeSelf);
        }

        internal void SetClip(AnimationClip value)
        {
            if (clip == value) return;
            if (graph.IsValid()) graph.Destroy();
            DestroyMirrorController();
            clip = value;
            animator.runtimeAnimatorController = null;
            if (gogoPose) { Object.DestroyImmediate(gogoPose); gogoPose = null; }
            Simulated.Remove(animator);
            gogoReady = false;
            gogoProblem = null;
            animator.Rebind();
            foreach (var (bone, pos, rot, scale) in rest)
            {
                bone.localPosition = pos;
                bone.localRotation = rot;
                bone.localScale = scale;
            }
            if (!clip || clip.legacy || (clip.humanMotion && !HasHumanoidAvatar)) return;
            if (SimulatingGoGoLoco)
            {
                // A stock pose plays its own slot; any other clip plays in an empty slot through an override.
                int native = gogo.SlotFor(clip);
                gogoSlot = native >= 0 ? native : gogo.BlankSlot;
                RuntimeAnimatorController controller = gogo.Base;
                if (gogoSlot == gogo.BlankSlot)
                {
                    if (!gogoOverride)
                        gogoOverride = new AnimatorOverrideController(gogo.Base)
                            { name = "Pose Deck GoGoLoco preview", hideFlags = HideFlags.HideAndDontSave };
                    if (PoseDeckBuilder.NeedsReference(clip, gogo.Reference))
                    {
                        gogoPose = PoseDeckBuilder.WithReference(clip, gogo.Reference);
                        gogoPose.hideFlags = HideFlags.HideAndDontSave;
                    }
                    foreach (var blank in gogo.BlankClips) gogoOverride[blank] = gogoPose ? gogoPose : clip;
                    controller = gogoOverride;
                }
                animator.runtimeAnimatorController = controller;
                Simulated.Add(animator);
                if (!driverHooked)
                {
                    VRC_AvatarParameterDriver.OnApplySettings += ApplyDriver;
                    driverHooked = true;
                }
                gogoDirty = true;
                return;
            }
            graph = PlayableGraph.Create("Pose Deck preview");
            graph.SetTimeUpdateMode(DirectorUpdateMode.Manual);
            var output = AnimationPlayableOutput.Create(graph, "Pose Deck pose", animator);
            if (mirror)
            {
                mirrorController = new AnimatorController { name = "Pose Deck mirror", hideFlags = HideFlags.HideAndDontSave };
                mirrorController.AddLayer("Pose");
                var state = mirrorController.layers[0].stateMachine.AddState("Pose");
                state.motion = clip;
                state.mirror = true;
                state.iKOnFeet = false;
                state.writeDefaultValues = true;
                state.speed = 0f;
                controllerPlayable = AnimatorControllerPlayable.Create(graph, mirrorController);
                output.SetSourcePlayable(controllerPlayable);
            }
            else
            {
                playable = AnimationClipPlayable.Create(graph, clip);
                playable.SetApplyFootIK(false);
                playable.SetApplyPlayableIK(false);
                playable.SetSpeed(0);
                output.SetSourcePlayable(playable);
            }
            graph.Play();
        }

        private void DestroyMirrorController()
        {
            if (!mirrorController) return;
            var machine = mirrorController.layers.Length > 0 ? mirrorController.layers[0].stateMachine : null;
            if (machine)
            {
                foreach (var child in machine.states) if (child.state) Object.DestroyImmediate(child.state);
                Object.DestroyImmediate(machine);
            }
            Object.DestroyImmediate(mirrorController);
            mirrorController = null;
        }

        internal void Sample(float time)
        {
            constraints.ResetTargets();
            bool posed = false;
            if (SimulatingGoGoLoco)
            {
                if (gogoDirty) SettleGoGoLoco();
                if (gogoReady)
                {
                    var t = Mathf.Clamp(time, 0, Mathf.Max(0, clip.length));
                    animator.Play(gogoState, gogoLayer, clip.length > 0 ? t / clip.length : 0f);
                    animator.Update(0f);
                    posed = true;
                }
            }
            else if (graph.IsValid())
            {
                var t = Mathf.Clamp(time, 0, Mathf.Max(0, clip.length));
                if (mirror && controllerPlayable.IsValid())
                    controllerPlayable.Play(MirrorStateHash, 0, clip.length > 0 ? t / clip.length : 0f);
                else
                    playable.SetTime(t);
                graph.Evaluate(0f);
                posed = true;
            }
            // Before the constraints, so accessories follow the moved head and hands.
            VrResult = posed && Vr is PoseDeckVrPose.Settings vr && vrPose != null && vrPose.Valid && clip.humanMotion
                ? vrPose.Apply(vr, VrHandsOnClip) : default;
            constraints.Apply();
            if (ExactMeasure) LowestPoint = MeshLowest();
        }

        private void Step(float seconds)
        {
            for (float t = 0f; t < seconds; t += 1f / 60f) animator.Update(1f / 60f);
        }

        // Press the pose button and let go, as in game, then let GoGoLoco's smoothing settle.
        private void SettleGoGoLoco()
        {
            gogoDirty = false;
            gogoReady = false;
            gogoProblem = null;
            animator.Rebind();
            var types = animator.parameters.ToDictionary(p => p.name, p => p.type);
            // By hash, as in ApplyDriver: VRCFury's editor patches of the by-name setters throw on preview rigs.
            void Set(string name, float value)
            {
                if (!types.TryGetValue(name, out var type)) return;
                int id = Animator.StringToHash(name);
                if (type == AnimatorControllerParameterType.Float) animator.SetFloat(id, value);
                else if (type == AnimatorControllerParameterType.Int) animator.SetInteger(id, Mathf.RoundToInt(value));
                else if (type == AnimatorControllerParameterType.Bool) animator.SetBool(id, value != 0f);
            }
            bool vr = mode != Tracking.Desktop;
            Set("IsLocal", 1); Set("TrackingType", mode == Tracking.FullBody ? 6 : 3);
            Set("VRMode", vr ? 1 : 0); Set("VRModeProxy", vr ? 1 : 0); Set("Upright", 1);
            Set("Grounded", 1); Set("AvatarVersion", 3); Set("EyeHeightAsMeters", eyeHeight); Set("Go/Weight", 1);
            Set("Go/Mirror", mirror ? 1 : 0);
            Set("Go/Float", startHeight);
            Step(.6f);
            Set("VRCEmote", gogoSlot);
            Step(.15f);
            Set("Go/Float", startHeight); // GoGoLoco's Action layer writes the start height on the press
            Set("VRCEmote", 0);
            Step(1.2f);
            gogoLayer = Enumerable.Range(0, animator.layerCount).FirstOrDefault(i => animator.GetLayerName(i) == "Poses");
            var info = animator.GetCurrentAnimatorStateInfo(gogoLayer);
            // A generated Base can already be in a held pose's "Left Hold"/"Right Hold" loop (PoseDeckBuilder.ApplyHeld).
            if (animator.GetLayerName(gogoLayer) != "Poses" || !(info.IsName("Left") || info.IsName("Right") ||
                                                                 info.IsName("Left Hold") || info.IsName("Right Hold")))
            {
                gogoProblem = mode == Tracking.FullBody
                    ? "풀바디(5점 이상)에서는 GoGoLoco가 포즈를 재생하지 않습니다. 게임에서도 같아서 클립만 표시합니다."
                    : "GoGoLoco 포즈 상태에 들어가지 못해 클립만 표시합니다.";
                return;
            }
            gogoState = info.fullPathHash;
            gogoReady = true;
        }

        private Mesh measureMesh;
        private readonly List<Vector3> measureVertices = new List<Vector3>();

        private static bool FollowsSkeleton(Renderer r, Transform hips)
        {
            if (r is SkinnedMeshRenderer skinned)
                return skinned.rootBone && skinned.rootBone.IsChildOf(hips) || skinned.bones.Any(b => b && b.IsChildOf(hips));
            return r.transform.IsChildOf(hips);
        }

        // The mesh that set LowestPoint (shown with the floor reading), or null.
        internal string LowestMesh { get; private set; }

        // True when the floor reading leaves out parts a PhysBone swings (shown in the floor tooltip).
        internal bool SkipsSwingingParts { get; private set; }

        private void CollectFloorMeshes(GameObject avatar)
        {
            var swinging = SwingingTransforms(avatar);
            foreach (var r in measured)
            {
                if (r is SkinnedMeshRenderer skinned)
                {
                    var still = StillVertices(skinned, swinging);
                    if (still == null) floorMeshes.Add((r, null));
                    else if (still.Length > 0) floorMeshes.Add((r, still));
                    SkipsSwingingParts |= still != null;
                }
                else if (swinging.Contains(r.transform)) SkipsSwingingParts = true;
                else floorMeshes.Add((r, null));
            }
            if (floorMeshes.Count == 0) floorMeshes.AddRange(measured.Select(r => (r, (int[])null)));
        }

        // The preview transforms a PhysBone moves: everything below each PhysBone's root, minus its ignored branches. The
        // root itself stays (it holds the chain; a jiggle bone there still carries the hips or thighs it is part of).
        // Humanoid bones stop the walk, so a PhysBone set on part of the body cannot take the limbs below it.
        private HashSet<Transform> SwingingTransforms(GameObject avatar)
        {
            var swinging = new HashSet<Transform>();
            var body = new HashSet<Transform>();
            if (HasHumanoidAvatar)
                for (var bone = HumanBodyBones.Hips; bone < HumanBodyBones.LastBone; bone++)
                {
                    var t = animator.GetBoneTransform(bone);
                    if (t) body.Add(t);
                }
            foreach (var physBone in avatar.GetComponentsInChildren<VRCPhysBoneBase>(true))
            {
                if (!physBone) continue;
                var root = Map(physBone.rootTransform ? physBone.rootTransform : physBone.transform);
                if (!root) continue;
                var ignored = new HashSet<Transform>();
                if (physBone.ignoreTransforms != null)
                    foreach (var t in physBone.ignoreTransforms)
                        if (Map(t) is Transform node) ignored.Add(node);
                var stack = new Stack<Transform>();
                foreach (Transform child in root) stack.Push(child);
                while (stack.Count > 0)
                {
                    var t = stack.Pop();
                    if (body.Contains(t) || ignored.Contains(t) || !swinging.Add(t)) continue;
                    foreach (Transform child in t) stack.Push(child);
                }
            }
            return swinging;
        }

        // Indices of the vertices held mostly (over half their weight) by bones no PhysBone moves. Null when that is all
        // of them, or when the weights cannot be read (then the whole mesh is measured).
        private static int[] StillVertices(SkinnedMeshRenderer skinned, HashSet<Transform> swinging)
        {
            var mesh = skinned.sharedMesh;
            if (!mesh || swinging.Count == 0) return null;
            var bones = skinned.bones;
            var moves = new bool[bones.Length];
            bool any = false;
            for (int i = 0; i < bones.Length; i++) any |= moves[i] = bones[i] && swinging.Contains(bones[i]);
            if (!any) return null;
            try
            {
                var counts = mesh.GetBonesPerVertex();
                var weights = mesh.GetAllBoneWeights();
                if (counts.Length != mesh.vertexCount) return null;
                var still = new List<int>(counts.Length);
                for (int v = 0, w = 0; v < counts.Length; v++)
                {
                    float moving = 0f, total = 0f;
                    for (int k = 0; k < counts[v]; k++, w++)
                    {
                        var weight = weights[w];
                        total += weight.weight;
                        if (weight.boneIndex < moves.Length && moves[weight.boneIndex]) moving += weight.weight;
                    }
                    if (moving <= total * .5f) still.Add(v);
                }
                return still.Count == counts.Length ? null : still.ToArray();
            }
            catch (Exception) { return null; }
        }

        // Lowest vertex of the visible floor meshes (floorMeshes), above the floor, from the current pose.
        private float? MeshLowest()
        {
            LowestMesh = null;
            if (floorMeshes.Count == 0) return null;
            float min = float.PositiveInfinity;
            foreach (var (r, vertices) in floorMeshes)
            {
                if (!r || !r.enabled || !r.gameObject.activeInHierarchy) continue;
                float low;
                try { low = Lowest(r, vertices); }
                catch (Exception) { low = r.bounds.min.y; }
                if (low < min)
                {
                    min = low;
                    LowestMesh = r.name;
                }
            }
            return float.IsPositiveInfinity(min) ? (float?)null : min - previewRoot.position.y;
        }

        // The lowest world height of one mesh in its current pose: its vertices (only the listed ones, when given) when
        // readable, else its bounds.
        private float Lowest(Renderer r, int[] only)
        {
            Matrix4x4 toWorld;
            if (r is SkinnedMeshRenderer skinned)
            {
                if (!measureMesh) measureMesh = new Mesh { name = "Pose Deck measure", hideFlags = HideFlags.HideAndDontSave };
                skinned.BakeMesh(measureMesh, true);
                measureMesh.GetVertices(measureVertices);
                toWorld = Matrix4x4.TRS(skinned.transform.position, skinned.transform.rotation, Vector3.one);
            }
            else if (r.TryGetComponent<MeshFilter>(out var filter) && filter.sharedMesh && filter.sharedMesh.isReadable)
            {
                filter.sharedMesh.GetVertices(measureVertices);
                toWorld = r.transform.localToWorldMatrix;
            }
            else return r.bounds.min.y;
            float min = float.PositiveInfinity;
            if (only == null)
                foreach (var v in measureVertices) min = Mathf.Min(min, toWorld.MultiplyPoint3x4(v).y);
            else
                foreach (int i in only)
                    if (i < measureVertices.Count) min = Mathf.Min(min, toWorld.MultiplyPoint3x4(measureVertices[i]).y);
            return min;
        }

        // The start height at which the pose's lowest mesh point rests on the floor (within 3 mm), searched with the
        // GoGoLoco preview. Null when the preview is not running GoGoLoco.
        internal float? FitStartHeight(float time)
        {
            if (!SimulatingGoGoLoco) return null;
            bool exact = ExactMeasure;
            ExactMeasure = true;
            // The animated pose rests on the floor; the VR look only moves the head and hands around it.
            var vr = Vr;
            Vr = null;
            try
            {
                float height = startHeight;
                for (int i = 0; i < 6; i++)
                {
                    StartHeight = height;
                    Sample(time);
                    if (!gogoReady || LowestPoint == null) return null;
                    float low = LowestPoint.Value;
                    if (Mathf.Abs(low) < .003f) break;
                    float step = height < .97f ? .02f : -.02f;
                    StartHeight = height + step;
                    Sample(time);
                    if (!gogoReady || LowestPoint == null) return null;
                    float slope = (LowestPoint.Value - low) / step;
                    if (slope < .05f) break; // the pose does not move with Go/Float here
                    height = Mathf.Clamp01(height - low / slope);
                }
                StartHeight = height;
                Sample(time);
                return gogoReady ? height : (float?)null;
            }
            finally
            {
                ExactMeasure = exact;
                Vr = vr;
            }
        }

        internal void Fit()
        {
            if (measured.Count > 0)
            {
                frame = measured[0].bounds;
                for (int i = 1; i < measured.Count; i++) frame.Encapsulate(measured[i].bounds);
            }
            else frame = new Bounds(Vector3.up * .8f, new Vector3(.8f, 1.6f, .5f));
            pivot = frame.center;
            distance = FitDistance();
            StopCameraDrag();
        }

        // As the Scene view frames a selection: the bounds' sphere just fits the narrower side of the view.
        private float FitDistance()
        {
            float radius = Mathf.Max(.12f, frame.extents.magnitude);
            float half = FieldOfView * .5f * Mathf.Deg2Rad;
            if (aspect < 1f) half = Mathf.Atan(Mathf.Tan(half) * aspect);
            return Mathf.Clamp(radius / Mathf.Sin(half), MinDistance, MaxDistance);
        }

        private static GUIStyle speedStyle;

        internal void Draw(Rect rect, bool invertVertical)
        {
            HandleCamera(rect, invertVertical);
            var evt = Event.current;
            if (evt.type != EventType.Repaint || rect.width < 2 || rect.height < 2) return;
            aspect = rect.width / rect.height;
            Aim();
            preview.BeginPreview(rect, GUIStyle.none);
            try { preview.Render(true, false); }
            finally
            {
                var texture = preview.EndPreview();
                if (texture) GUI.DrawTexture(rect, texture, ScaleMode.StretchToFill, false);
            }
            if (drag == CameraDrag.Look && EditorApplication.timeSinceStartup < flySpeedShownUntil)
            {
                if (speedStyle == null)
                    speedStyle = new GUIStyle(EditorStyles.helpBox) { alignment = TextAnchor.MiddleCenter, fontSize = 11 };
                GUI.Label(new Rect(rect.center.x - 60f, rect.yMax - 30f, 120f, 20f), $"이동 속도 ×{flySpeed:0.##}", speedStyle);
            }
            // While playing, measure the posed meshes a few times a second rather than on every frame.
            if (!ExactMeasure && EditorApplication.timeSinceStartup >= nextPlayingMeasure)
            {
                nextPlayingMeasure = EditorApplication.timeSinceStartup + .2;
                LowestPoint = MeshLowest();
            }
        }

        // The Scene view's mouse: left drag (or Alt+left) orbits, the wheel zooms toward the pivot, the middle button (or
        // Ctrl+Alt+left) pans, Alt+right zooms, and the right button looks around, flying with WASD/QE (Shift faster,
        // the wheel sets the speed). A plain left click is left to the buttons on the preview: the orbit starts once
        // the mouse moves, and only when no button holds the mouse.
        private void HandleCamera(Rect rect, bool invertVertical)
        {
            var evt = Event.current;
            int id = GUIUtility.GetControlID("PoseDeckPreviewCamera".GetHashCode(), FocusType.Passive, rect);
            bool inside = rect.Contains(evt.mousePosition);
            // Control ids match only outside Repaint: the window draws the VR marks and the light menu before the
            // preview in the other events and after it in Repaint.
            if (evt.type != EventType.Repaint && drag == CameraDrag.None && GUIUtility.hotControl == id) GUIUtility.hotControl = 0;
            if (drag != CameraDrag.None)
            {
                if (GUIUtility.hotControl != id)
                {
                    // Another control took the mouse: the drag is over.
                    if (evt.type == EventType.MouseDown || evt.type == EventType.MouseUp) StopCameraDrag();
                    return;
                }
                if (evt.type == EventType.Ignore || evt.type == EventType.MouseUp && evt.button == dragButton ||
                    drag == CameraDrag.Look && evt.type == EventType.KeyDown && evt.keyCode == KeyCode.Escape)
                {
                    StopCameraDrag();
                    GUIUtility.hotControl = 0;
                    if (evt.type != EventType.Ignore) evt.Use();
                }
                else if (evt.type == EventType.MouseDrag)
                {
                    Dragged(rect, evt.delta, invertVertical, evt.shift);
                    evt.Use();
                    GUI.changed = true;
                }
                else if (drag == CameraDrag.Look && (evt.type == EventType.KeyDown || evt.type == EventType.KeyUp) && IsCameraKey(evt.keyCode))
                {
                    if (evt.type == EventType.KeyDown) movementKeys.Add(evt.keyCode); else movementKeys.Remove(evt.keyCode);
                    evt.Use();
                }
                else if (drag == CameraDrag.Look && evt.type == EventType.ScrollWheel)
                {
                    flySpeed = Mathf.Clamp(flySpeed * Mathf.Exp(-evt.delta.y * .05f), .1f, 10f);
                    flySpeedShownUntil = EditorApplication.timeSinceStartup + 1.5;
                    evt.Use();
                    GUI.changed = true;
                }
                return;
            }
            var start = CameraDrag.None;
            if (evt.type == EventType.MouseDown && inside)
            {
                if (evt.button == 2) start = CameraDrag.Pan;
                else if (evt.button == 1) start = evt.alt ? CameraDrag.Zoom : CameraDrag.Look;
                else if (evt.button == 0 && evt.alt) start = evt.control ? CameraDrag.Pan : CameraDrag.Orbit;
            }
            else if (evt.type == EventType.MouseDrag && evt.button == 0 && inside && GUIUtility.hotControl == 0)
                start = CameraDrag.Orbit;
            if (start != CameraDrag.None)
            {
                drag = start;
                dragButton = evt.button;
                movementKeys.Clear();
                lastCameraTick = EditorApplication.timeSinceStartup;
                GUIUtility.hotControl = id;
                if (start == CameraDrag.Look) GUIUtility.keyboardControl = 0;
                if (evt.type == EventType.MouseDrag) Dragged(rect, evt.delta, invertVertical, evt.shift);
                evt.Use();
                GUI.changed = true;
            }
            else if (evt.type == EventType.ScrollWheel && inside)
            {
                distance = Mathf.Clamp(distance * Mathf.Exp(evt.delta.y * WheelZoom), MinDistance, MaxDistance);
                evt.Use();
                GUI.changed = true;
            }
        }

        private void Dragged(Rect rect, Vector2 delta, bool invertVertical, bool fast)
        {
            switch (drag)
            {
                case CameraDrag.Orbit:
                    yaw += delta.x * DegreesPerPixel;
                    pitch = Mathf.Clamp(pitch - delta.y * DegreesPerPixel, -MaxPitch, MaxPitch);
                    break;
                case CameraDrag.Look:
                {
                    var eye = CameraPosition;
                    yaw += delta.x * DegreesPerPixel;
                    pitch = Mathf.Clamp(pitch - delta.y * (invertVertical ? -DegreesPerPixel : DegreesPerPixel), -MaxPitch, MaxPitch);
                    pivot = eye - ToCamera * distance;
                    break;
                }
                case CameraDrag.Pan:
                {
                    // The point at the pivot's depth stays under the mouse.
                    float perPixel = 2f * distance * Mathf.Tan(FieldOfView * .5f * Mathf.Deg2Rad) / Mathf.Max(1f, rect.height);
                    var rotation = CameraRotation;
                    pivot += (rotation * Vector3.left * delta.x + rotation * Vector3.up * delta.y) * perPixel;
                    break;
                }
                case CameraDrag.Zoom:
                {
                    // As the Scene view reads the drag: the larger axis, right or up moves away.
                    float amount = Mathf.Abs(delta.x) >= Mathf.Abs(delta.y) ? delta.x : -delta.y;
                    distance = Mathf.Clamp(distance * Mathf.Exp(amount * (fast ? .009f : .003f)), MinDistance, MaxDistance);
                    break;
                }
            }
        }

        private static bool IsCameraKey(KeyCode key) => key == KeyCode.W || key == KeyCode.S ||
            key == KeyCode.A || key == KeyCode.D || key == KeyCode.Q || key == KeyCode.E ||
            key == KeyCode.LeftShift || key == KeyCode.RightShift;

        // Flies with WASD/QE while the right button is held (the camera and its pivot together). True when the view
        // changed and needs a repaint.
        internal bool TickCamera()
        {
            double now = EditorApplication.timeSinceStartup;
            bool hideSpeed = flySpeedShownUntil > 0 && now >= flySpeedShownUntil;
            if (hideSpeed) flySpeedShownUntil = 0;
            if (drag != CameraDrag.Look) return hideSpeed;
            float dt = Mathf.Clamp((float)(now - lastCameraTick), 0f, .08f);
            lastCameraTick = now;
            float Axis(KeyCode plus, KeyCode minus) => (movementKeys.Contains(plus) ? 1 : 0) - (movementKeys.Contains(minus) ? 1 : 0);
            var local = new Vector3(Axis(KeyCode.D, KeyCode.A), Axis(KeyCode.E, KeyCode.Q), Axis(KeyCode.W, KeyCode.S));
            if (local.sqrMagnitude < .001f) return hideSpeed;
            float multiplier = movementKeys.Contains(KeyCode.LeftShift) || movementKeys.Contains(KeyCode.RightShift) ? 3f : 1f;
            pivot += CameraRotation * local.normalized * (Mathf.Max(.25f, frame.extents.magnitude) * .8f * flySpeed * multiplier * dt);
            return true;
        }

        // Where a world point shows in the preview rect, from the camera of the last repaint. False behind the camera.
        internal bool ToGui(Rect rect, Vector3 world, out Vector2 gui)
        {
            gui = default;
            var camera = preview.camera;
            var p = camera.transform.InverseTransformPoint(world);
            if (p.z <= camera.nearClipPlane || rect.height < 1f) return false;
            float halfHeight = camera.orthographic ? camera.orthographicSize : p.z * Mathf.Tan(camera.fieldOfView * .5f * Mathf.Deg2Rad);
            float halfWidth = halfHeight * rect.width / rect.height;
            gui = new Vector2(rect.x + (p.x / halfWidth * .5f + .5f) * rect.width, rect.y + (.5f - p.y / halfHeight * .5f) * rect.height);
            return true;
        }

        // A world point moved with the mouse by a GUI delta, in the view plane at its depth.
        internal Vector3 MoveInView(Rect rect, Vector3 world, Vector2 delta)
        {
            var camera = preview.camera;
            float depth = Mathf.Max(.05f, camera.transform.InverseTransformPoint(world).z);
            float halfHeight = camera.orthographic ? camera.orthographicSize : depth * Mathf.Tan(camera.fieldOfView * .5f * Mathf.Deg2Rad);
            return world + (camera.transform.right * delta.x - camera.transform.up * delta.y) * (2f * halfHeight / Mathf.Max(1f, rect.height));
        }

        internal void StopCameraDrag()
        {
            drag = CameraDrag.None;
            movementKeys.Clear();
        }

        // readable keeps the pixels on the CPU (for saving as PNG); transparent clears the background to alpha 0.
        internal Texture2D CaptureThumbnail(AnimationClip animation, int size, bool readable = false, bool transparent = false,
            float yaw = 45f, float pitch = -25f)
        {
            SetClip(animation);
            Sample(animation.length * .5f);
            Fit();
            AimThumbnail(yaw, pitch);
            bool showFloor = ShowFloor;
            ShowFloor = false;
            var background = preview.camera.backgroundColor;
            Texture2D result = null, black = null, white = null;
            try
            {
                if (!transparent) result = RenderStill(size);
                else
                {
                    // The static preview comes back without alpha: render on black and on white and recover the
                    // coverage from the difference.
                    preview.camera.backgroundColor = Color.black;
                    black = RenderStill(size);
                    preview.camera.backgroundColor = Color.white;
                    white = RenderStill(size);
                    if (black && white) result = Matte(black, white);
                }
            }
            finally
            {
                ShowFloor = showFloor;
                preview.camera.backgroundColor = background;
                if (black) Object.DestroyImmediate(black);
                if (white) Object.DestroyImmediate(white);
            }
            if (result)
            {
                result.hideFlags = HideFlags.HideAndDontSave;
                result.filterMode = FilterMode.Bilinear;
                result.Apply(false, !readable);
            }
            return result;
        }

        private Texture2D RenderStill(int size)
        {
            preview.BeginStaticPreview(new Rect(0, 0, size, size));
            Texture2D result = null;
            bool succeeded = false;
            try
            {
                preview.Render(true, false);
                succeeded = true;
            }
            finally
            {
                result = preview.EndStaticPreview();
                if (!succeeded && result) { Object.DestroyImmediate(result); result = null; }
            }
            return result;
        }

        // Pixels over black (b) and white (w) are a*F and a*F + (1 - a): the difference gives the coverage a, and b / a
        // the colour. Blending happens in linear space, so the sRGB values are converted first.
        private static Texture2D Matte(Texture2D black, Texture2D white)
        {
            bool linear = QualitySettings.activeColorSpace == ColorSpace.Linear;
            var toLinear = new float[256];
            for (int i = 0; i < 256; i++) toLinear[i] = linear ? Mathf.GammaToLinearSpace(i / 255f) : i / 255f;
            byte Encode(float v) => (byte)Mathf.RoundToInt(Mathf.Clamp01(linear ? Mathf.LinearToGammaSpace(Mathf.Clamp01(v)) : v) * 255f);
            var b = black.GetPixels32();
            var w = white.GetPixels32();
            var pixels = new Color32[b.Length];
            for (int i = 0; i < b.Length; i++)
            {
                float r = toLinear[b[i].r], g = toLinear[b[i].g], bl = toLinear[b[i].b];
                float alpha = Mathf.Clamp01(1f - (toLinear[w[i].r] - r + toLinear[w[i].g] - g + toLinear[w[i].b] - bl) / 3f);
                pixels[i] = alpha < .5f / 255f ? new Color32(0, 0, 0, 0)
                    : new Color32(Encode(r / alpha), Encode(g / alpha), Encode(bl / alpha), (byte)Mathf.RoundToInt(alpha * 255f));
            }
            var result = new Texture2D(black.width, black.height, TextureFormat.RGBA32, false);
            result.SetPixels32(pixels);
            return result;
        }

        // The avatar as it stands now, with the floor when shown. The framed bounds are kept across poses and avatars,
        // so a pose can move well away from them (GoGoLoco's start height lifts the avatar, lying poses spread out).
        // Skinned bounds only follow the pose once it is rendered, so the rig's transforms (posed by the last sample,
        // with room for the mesh around them) are added for the first frame after a change.
        private Bounds LiveBounds()
        {
            bool any = false;
            var bounds = frame;
            foreach (var r in renderers)
            {
                if (!r || !r.enabled || !r.gameObject.activeInHierarchy) continue;
                if (any) bounds.Encapsulate(r.bounds);
                else { bounds = r.bounds; any = true; }
            }
            var joints = new Bounds(previewRoot.position, Vector3.zero);
            foreach (var bone in rig.Values) if (bone) joints.Encapsulate(bone.position);
            joints.Expand(.3f * Mathf.Max(.1f, previewRoot.lossyScale.y));
            if (any) bounds.Encapsulate(joints);
            else bounds = joints;
            if (ShowFloor && floor.TryGetComponent<MeshRenderer>(out var floorRenderer)) bounds.Encapsulate(floorRenderer.bounds);
            return bounds;
        }

        // Nearest and farthest depth of the bounds' corners along a view direction, from a point.
        private static (float Nearest, float Farthest) Depths(Bounds bounds, Vector3 from, Vector3 forward)
        {
            float nearest = float.PositiveInfinity, farthest = float.NegativeInfinity;
            var c = bounds.center;
            var e = bounds.extents;
            for (int i = 0; i < 8; i++)
            {
                var corner = c + new Vector3((i & 1) == 0 ? -e.x : e.x, (i & 2) == 0 ? -e.y : e.y, (i & 4) == 0 ? -e.z : e.z);
                float d = Vector3.Dot(corner - from, forward);
                nearest = Mathf.Min(nearest, d);
                farthest = Mathf.Max(farthest, d);
            }
            return (nearest, farthest);
        }

        // Near enough to look closely, far enough to keep the whole pose in view wherever it has moved to.
        private void Aim()
        {
            var camera = preview.camera;
            camera.orthographic = false;
            camera.fieldOfView = FieldOfView;
            var position = CameraPosition;
            var rotation = CameraRotation;
            camera.transform.SetPositionAndRotation(position, rotation);
            float radius = Mathf.Max(.12f, frame.extents.magnitude);
            var (_, farthest) = Depths(LiveBounds(), position, rotation * Vector3.forward);
            camera.nearClipPlane = Mathf.Clamp(distance * .01f, .002f, .05f);
            camera.farClipPlane = Mathf.Max(farthest + radius, distance + radius * 8f);
        }

        // Thumbnails and icons: an orthographic view of the framed bounds from one side, filling the square.
        private void AimThumbnail(float viewYaw, float viewPitch)
        {
            var size = frame.extents;
            float radius = Mathf.Max(.12f, size.magnitude);
            var rotation = Quaternion.Euler(viewPitch, viewYaw, 0);
            var cam = preview.camera;
            cam.orthographic = true;
            var center = frame.center;
            // An orthographic view looks the same from any distance: stand back far enough that nothing visible is
            // behind the camera or cut by the near plane, then fit the far plane past the farthest point.
            var toCamera = rotation * Vector3.forward;
            var (nearest, farthest) = Depths(LiveBounds(), center, -toCamera);
            float margin = .05f * Mathf.Max(1f, radius);
            float standBack = Mathf.Max(radius * 4f, margin - nearest);
            cam.transform.position = center + toCamera * standBack;
            cam.transform.rotation = Quaternion.LookRotation(-toCamera, Vector3.up);
            cam.nearClipPlane = Mathf.Max(.001f, standBack + nearest - margin);
            cam.farClipPlane = Mathf.Max(standBack + farthest + margin, radius * 8f);
            // Enclose the bounds in camera space, including the vertical extent added by the elevated view.
            var right = cam.transform.right;
            var up = cam.transform.up;
            float HalfSpan(Vector3 axis) => Mathf.Abs(axis.x) * size.x + Mathf.Abs(axis.y) * size.y + Mathf.Abs(axis.z) * size.z;
            cam.orthographicSize = Mathf.Max(HalfSpan(up), HalfSpan(right), .07f) * 1.10f;
        }

        public void Dispose()
        {
            StopCameraDrag();
            if (graph.IsValid()) graph.Destroy();
            DestroyMirrorController();
            if (animator) { Simulated.Remove(animator); animator.runtimeAnimatorController = null; }
            if (gogoOverride) Object.DestroyImmediate(gogoOverride);
            if (gogoPose) Object.DestroyImmediate(gogoPose);
            if (measureMesh) Object.DestroyImmediate(measureMesh);
            preview.Cleanup();
            if (floorMesh) Object.DestroyImmediate(floorMesh);
            if (floorMaterial) Object.DestroyImmediate(floorMaterial);
        }
    }
}
