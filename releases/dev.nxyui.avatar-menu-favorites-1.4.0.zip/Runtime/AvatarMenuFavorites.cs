using System;
using System.Collections.Generic;
using System.Linq;
using nadena.dev.ndmf;
using UnityEngine;
using Control = VRC.SDK3.Avatars.ScriptableObjects.VRCExpressionsMenu.Control;

namespace AvatarMenuTools
{
    [DisallowMultipleComponent]
    [AddComponentMenu("NXYUI/Avatar Menu Favorites")]
    public sealed class AvatarMenuFavorites : MonoBehaviour, INDMFEditorOnly
    {
        // Keep the first menu in its original serialized fields. Existing scenes and prefab overrides need no migration.
        public string menuName = "즐겨찾기";
        public bool useRoot = true;
        public FavoriteMenuKey destination = new FavoriteMenuKey();
        public List<FavoriteMenuEntry> entries = new List<FavoriteMenuEntry>();
        public List<MenuNameOverride> nameOverrides = new List<MenuNameOverride>();
        public string nextPageLabel = "";
        public List<FavoriteMenuGroup> additionalMenus = new List<FavoriteMenuGroup>();
        public bool pinToFirstPage;
        public Texture2D menuIcon;

        public FavoriteMenuGroup GetMenu(int index)
        {
            if (index == 0)
                return new FavoriteMenuGroup
                {
                    name = menuName, useRoot = useRoot, destination = destination,
                    entries = entries, pinToFirstPage = pinToFirstPage, icon = menuIcon,
                };
            return index > 0 && additionalMenus != null && index <= additionalMenus.Count ? additionalMenus[index - 1] : null;
        }
    }

    [Serializable]
    public sealed class FavoriteMenuGroup
    {
        public string name = "새 메뉴";
        public bool useRoot = true;
        public FavoriteMenuKey destination;
        public List<FavoriteMenuEntry> entries = new List<FavoriteMenuEntry>();
        public bool pinToFirstPage;
        public Texture2D icon;

        public string DisplayName => string.IsNullOrWhiteSpace(name) ? "즐겨찾기" : name.Trim();
    }

    public enum FavoriteMenuMatch { Exact, Moved, Changed, Missing, Ambiguous }

    [Serializable]
    public sealed class FavoriteMenuKey
    {
        public string[] path;
        public Control.ControlType type;
        public string parameter;
        public string[] subParameters;
        public float value;
        [NonSerialized] public int sharedControl;

        public string DisplayPath => string.Join(" / ", path ?? Array.Empty<string>());
        public string Binding => string.Join(", ", new[] { parameter }.Concat(subParameters ?? Array.Empty<string>())
            .Where(p => !string.IsNullOrEmpty(p)));
        public string Name => path?.LastOrDefault() ?? "";

        public bool SamePath(FavoriteMenuKey other) => type == other.type &&
            (path ?? Array.Empty<string>()).SequenceEqual(other.path ?? Array.Empty<string>(), StringComparer.Ordinal);

        public bool SameBinding(FavoriteMenuKey other) => type == other.type && value.Equals(other.value) &&
            string.Equals(parameter ?? "", other.parameter ?? "", StringComparison.Ordinal) &&
            (subParameters ?? Array.Empty<string>()).SequenceEqual(other.subParameters ?? Array.Empty<string>(), StringComparer.Ordinal);

        public static FavoriteMenuKey Resolve(IReadOnlyList<FavoriteMenuKey> catalogue, FavoriteMenuKey key) =>
            Resolve(catalogue, key, out _);

        public static FavoriteMenuKey Resolve(IReadOnlyList<FavoriteMenuKey> catalogue, FavoriteMenuKey key,
            out FavoriteMenuMatch match)
        {
            match = FavoriteMenuMatch.Missing;
            if (key?.path == null || key.path.Length == 0) return null;
            var atPath = catalogue.Where(x => key.SamePath(x)).ToArray();
            var exact = UniqueControl(atPath.Where(x => key.SameBinding(x)));
            if (exact != null) { match = FavoriteMenuMatch.Exact; return exact; }
            if (atPath.Length == 1)
            {
                // Generated parameter names can change between builds. Keep the fallback visible.
                match = FavoriteMenuMatch.Changed;
                return atPath[0];
            }
            if (atPath.Length > 0) { match = FavoriteMenuMatch.Ambiguous; return null; }
            if (key.Binding.Length == 0) return null;
            var sameBinding = catalogue.Where(x => key.SameBinding(x)).ToArray();
            var sameName = UniqueControl(sameBinding.Where(x => x.Name == key.Name));
            var moved = sameName ?? UniqueControl(sameBinding);
            if (moved != null) match = FavoriteMenuMatch.Moved;
            else if (sameBinding.Length > 0) match = FavoriteMenuMatch.Ambiguous;
            return moved;
        }

        private static FavoriteMenuKey UniqueControl(IEnumerable<FavoriteMenuKey> keys)
        {
            FavoriteMenuKey first = null;
            foreach (var key in keys)
            {
                if (first == null) first = key;
                else if (first.sharedControl == 0 || key.sharedControl != first.sharedControl) return null;
            }
            return first;
        }
    }

    [Serializable]
    public sealed class FavoriteMenuEntry
    {
        public FavoriteMenuKey source;
        public string label;
        public string folderId;
        public string parentId;
        // Folder icon, or for a shortcut an icon used instead of the original's.
        public Texture2D icon;
        public bool IsFolder => !string.IsNullOrEmpty(folderId);
        public string Parent => parentId ?? "";
    }

    [Serializable]
    public sealed class MenuNameOverride
    {
        public FavoriteMenuKey source;
        public string label;
    }
}
