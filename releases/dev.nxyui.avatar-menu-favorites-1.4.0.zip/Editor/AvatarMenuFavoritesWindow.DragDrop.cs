#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using VRC.SDK3.Avatars.Components;
using Object = UnityEngine.Object;

namespace AvatarMenuTools
{
    // Drag a favorite or folder by its ≡ handle: drop on the upper or lower half of a row to place it before or after,
    // or on the middle of a folder to put it inside.
    internal sealed partial class AvatarMenuFavoritesWindow
    {
        private const string DragKey = "NXYUI.AvatarMenuFavorites.Entry";

        private sealed class DragPayload
        {
            public VRCAvatarDescriptor Avatar;
            public int MenuIndex;
            public FavoriteMenuEntry Entry;
        }

        private enum DropZone { Before, Inside, After }

        private FavoriteMenuEntry dropTarget;
        private DropZone dropZone;

        private void DragHandle(Rect handle, FavoriteMenuEntry entry)
        {
            var evt = Event.current;
            GUI.Label(handle, new GUIContent("≡", "끌어서 순서를 바꾸거나 폴더 가운데에 놓아 넣습니다."), EditorStyles.centeredGreyMiniLabel);
            EditorGUIUtility.AddCursorRect(handle, MouseCursor.Pan);
            if (evt.type != EventType.MouseDrag || evt.button != 0 || !handle.Contains(evt.mousePosition) || GUIUtility.hotControl != 0) return;
            DragAndDrop.PrepareStartDrag();
            DragAndDrop.SetGenericData(DragKey, new DragPayload { Avatar = avatar, MenuIndex = menuIndex, Entry = entry });
            DragAndDrop.objectReferences = Array.Empty<Object>();
            DragAndDrop.StartDrag(string.IsNullOrWhiteSpace(entry.label) ? "즐겨찾기" : entry.label);
            evt.Use();
        }

        // True when target sits inside folder (or is it), so a folder is never dropped into itself.
        private static bool IsWithin(IReadOnlyList<FavoriteMenuEntry> entries, FavoriteMenuEntry target, string folder)
        {
            var seen = new HashSet<string>();
            for (var node = target; node != null; node = Find(entries, node.Parent))
            {
                if (node.IsFolder && node.folderId == folder) return true;
                if (!seen.Add(node.Parent) || node.Parent.Length == 0) return false;
            }
            return false;
        }

        private static FavoriteMenuEntry Find(IReadOnlyList<FavoriteMenuEntry> entries, string folderId)
        {
            foreach (var e in entries) if (e != null && e.IsFolder && e.folderId == folderId) return e;
            return null;
        }

        private void DropTarget(Rect row, FavoriteMenuEntry entry, IReadOnlyList<FavoriteMenuEntry> entries)
        {
            var evt = Event.current;
            if (!(DragAndDrop.GetGenericData(DragKey) is DragPayload payload) || payload.Avatar != avatar || payload.MenuIndex != menuIndex)
                return;
            if (evt.type == EventType.Repaint && dropTarget == entry)
            {
                var color = new Color(.33f, .67f, .93f, 1f);
                if (dropZone == DropZone.Inside) EditorGUI.DrawRect(new Rect(row.x, row.y, row.width, row.height), new Color(color.r, color.g, color.b, .18f));
                else EditorGUI.DrawRect(new Rect(row.x, dropZone == DropZone.Before ? row.y - 1f : row.yMax - 1f, row.width, 2f), color);
            }
            if ((evt.type != EventType.DragUpdated && evt.type != EventType.DragPerform) || !row.Contains(evt.mousePosition)) return;
            float t = (evt.mousePosition.y - row.y) / Mathf.Max(1f, row.height);
            var zone = entry.IsFolder && t > .3f && t < .7f ? DropZone.Inside : t < .5f ? DropZone.Before : DropZone.After;
            var moving = payload.Entry;
            bool valid = moving != entry && !(moving.IsFolder && IsWithin(entries, entry, moving.folderId));
            DragAndDrop.visualMode = valid ? DragAndDropVisualMode.Move : DragAndDropVisualMode.Rejected;
            dropTarget = valid ? entry : null;
            dropZone = zone;
            if (evt.type == EventType.DragPerform && valid)
            {
                DragAndDrop.AcceptDrag();
                ChangeEntries("Drag favorites item", list =>
                {
                    if (!list.Remove(moving)) return;
                    if (zone == DropZone.Inside)
                    {
                        moving.parentId = entry.folderId;
                        list.Add(moving);
                    }
                    else
                    {
                        moving.parentId = entry.Parent;
                        int at = list.IndexOf(entry);
                        list.Insert(at < 0 ? list.Count : zone == DropZone.Before ? at : at + 1, moving);
                    }
                });
                if (zone == DropZone.Inside) collapsed.Remove(entry.folderId);
                dropTarget = null;
                DragAndDrop.SetGenericData(DragKey, null);
            }
            evt.Use();
            Repaint();
        }
    }
}
#endif
