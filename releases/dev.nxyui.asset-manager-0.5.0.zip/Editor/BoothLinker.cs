using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using UnityEditor;
using UnityEngine;

namespace NXYUI.AssetManager
{
    // Finds Booth candidates for an asset or proposal and links the one the user picks. Candidates come, best first,
    // from a Booth link in the asset's own readme files, from a link made for the same package or folder name in any
    // project on this PC, then from Booth searches by the package and asset names and from the products of the asset's
    // shop, ordered by how close their names are. Nothing is linked without the user's choice, and products that need
    // Booth's age check are never shown (they are linked by address).
    internal static class BoothLinker
    {
        private static readonly HashSet<string> Running = new HashSet<string>();
        // Each search of an owner has a number; a newer one (the user's) makes the older one stop where it is.
        private static readonly Dictionary<string, int> Generations = new Dictionary<string, int>();
        // A proposal made into an asset while its search runs: the asset counts as searching until it ends.
        private static readonly Dictionary<string, string> Moved = new Dictionary<string, string>();
        private static readonly string[] TextExtensions = { ".txt", ".md", ".url", ".html", ".htm", ".rtf" };

        // A search result this close to the asset's name ends the search before the shop is looked at.
        private const float Strong = 0.8f;
        // A shop product at least this close is offered; a shop with this many products or fewer is offered whole.
        private const float ShopMatch = 0.3f;
        private const int SmallShop = 3;
        private const int ShopPages = 2;
        private const int ShopNameLookups = 2;

        public static event Action Updated;

        public static bool IsSearching(string owner) => Running.Contains(owner);

        private static readonly HashSet<string> Scheduled = new HashSet<string>();

        // The same, started after the current GUI pass: a window must not change what it draws in the middle of one.
        public static void SearchSoon(string owner, string name, IEnumerable<string> folderPaths, string package)
        {
            if (!Scheduled.Add(owner)) return;
            var folders = folderPaths?.ToList() ?? new List<string>();
            EditorApplication.delayCall += () =>
            {
                Scheduled.Remove(owner);
                SearchOnce(owner, name, folders, package);
            };
        }

        // The automatic search when an asset or proposal appears; it runs once per owner unless asked again (or cut
        // off by a domain reload before it finished).
        public static void SearchOnce(string owner, string name, IEnumerable<string> folderPaths, string package)
        {
            var cache = AssetStore.SearchFor(owner);
            if (cache != null && cache.done || Running.Contains(owner)) return;
            // A package file name usually names the product; one that says nothing ("Package.unitypackage") does not.
            var query = BoothClient.QueryFrom(package);
            if (query.Length < 2 || string.Equals(query, "package", StringComparison.OrdinalIgnoreCase)) query = BoothClient.QueryFrom(name);
            Run(owner, new Plan
            {
                Queries = new[] { query, BoothClient.QueryFrom(name) }.Where(q => q.Length > 0).Distinct().ToList(),
                RetryShorter = true,
                Folders = folderPaths?.ToList() ?? new List<string>(),
                HintKeys = new[] { package, name },
                Names = new[] { name, package },
                Name = name,
                Package = package,
            }, false);
        }

        // A search the user asked for, by their words. It replaces one still running for the same asset.
        public static void Search(string owner, string query, IEnumerable<string> folderPaths, IEnumerable<string> hintKeys, bool retryShorter)
        {
            var keys = hintKeys?.ToList() ?? new List<string>();
            Run(owner, new Plan
            {
                Queries = string.IsNullOrWhiteSpace(query) ? new List<string>() : new List<string> { query.Trim() },
                EmptyIsError = true,
                RetryShorter = retryShorter,
                Folders = folderPaths?.ToList() ?? new List<string>(),
                HintKeys = keys,
                Names = new[] { query }.Concat(keys).ToArray(),
                Name = keys.Count > 1 ? keys[1] : "",
                Package = keys.Count > 0 ? keys[0] : "",
            }, true);
        }

        // The products of one shop (a shop address the user gave), closest to the asset's name first.
        public static void SearchShop(AssetRecord asset, string shop)
        {
            Run(asset.id, new Plan
            {
                Queries = new List<string>(),
                Folders = AssetFolders.ExistingFolders(asset).ToList(),
                HintKeys = new[] { asset.package, asset.name },
                Names = new[] { asset.name, asset.package },
                Name = asset.name,
                Package = asset.package,
                Shop = shop,
                WholeShop = true,
            }, true);
        }

        private sealed class Plan
        {
            public List<string> Queries;
            public bool RetryShorter, EmptyIsError;
            public List<string> Folders;
            public IEnumerable<string> HintKeys;
            public string[] Names;
            public string Name = "", Package = "";
            // A shop to list straight away (the user's shop address), and whether to keep all its products.
            public string Shop;
            public bool WholeShop;
        }

        private static void Run(string owner, Plan plan, bool userAsked)
        {
            if (Running.Contains(owner) && !userAsked) return;
            // A search the user starts on an asset made from a proposal ends the proposal's search.
            foreach (var moved in Moved.Where(m => m.Value == owner).Select(m => m.Key).ToList())
            {
                Generations[moved] = (Generations.TryGetValue(moved, out var old) ? old : 0) + 1;
                Running.Remove(moved);
                Moved.Remove(moved);
            }
            Running.Add(owner);
            var generation = Generations[owner] = (Generations.TryGetValue(owner, out var last) ? last : 0) + 1;
            var cache = AssetStore.NewSearch(owner);
            cache.query = plan.Queries.FirstOrDefault() ?? "";
            var fixedIds = new List<long>();
            var (readme, readmeShops) = ReadReadmes(plan.Folders);
            if (readme > 0)
            {
                cache.readmeItem = readme;
                fixedIds.Add(readme);
            }
            foreach (var key in plan.HintKeys ?? Enumerable.Empty<string>())
            {
                var hinted = AssetStore.HintFor(key);
                if (hinted > 0 && !fixedIds.Contains(hinted)) fixedIds.Add(hinted);
            }
            AssetStore.SaveState();
            Updated?.Invoke();

            var names = plan.Names.Where(n => !string.IsNullOrWhiteSpace(n)).ToList();
            float Closeness(BoothItem item) => names.Count == 0 ? 0 : names.Max(n => BoothClient.Similarity(n, item.name));
            // The readme's product counts only when Booth gave it (a removed product leaves the search to go on).
            bool HasStrong() => cache.results.Any(r => r.id == readme) || cache.results.Any(r => Closeness(r) >= Strong);
            var sent = new HashSet<string>();
            var triedShops = new HashSet<string>();
            string error = null;
            var finished = false;
            bool Stale() => finished || !Generations.TryGetValue(owner, out var now) || now != generation;

            void Add(IEnumerable<BoothItem> items)
            {
                foreach (var item in items ?? Enumerable.Empty<BoothItem>())
                    if (cache.results.All(r => r.id != item.id)) cache.results.Add(item);
            }

            void Finish()
            {
                if (Stale()) return;
                finished = true;
                // The links found for this asset first, then the rest by how close the name is (the shop's own a bit
                // ahead); a tie keeps the order Booth gave.
                var fixedItems = fixedIds.Select(id => cache.results.FirstOrDefault(r => r.id == id)).Where(r => r != null).ToList();
                var rest = cache.results.Where(r => !fixedIds.Contains(r.id))
                    .Select((r, i) => (r, i, score: Closeness(r) + (cache.shopItems.Contains(r.id) ? 0.35f : 0)))
                    .OrderByDescending(t => t.score).ThenBy(t => t.i).Select(t => t.r).ToList();
                cache.results = fixedItems.Concat(rest).ToList();
                cache.error = cache.results.Count > 0 ? "" : error ?? "";
                cache.time = AssetStore.Now;
                cache.done = true;
                Running.Remove(owner);
                if (Moved.TryGetValue(owner, out var to))
                {
                    Running.Remove(to);
                    Moved.Remove(owner);
                }
                AssetStore.SaveState();
                Updated?.Invoke();
            }

            // Every answer from Booth goes through this: a newer search for the same owner wins, and a fault in the
            // handling still ends the search (so the asset never stays "searching").
            void Step(Action body)
            {
                if (Stale()) return;
                try { body(); }
                catch (Exception e)
                {
                    Debug.LogException(e);
                    error = "검색하다 오류가 났어요: " + e.Message;
                    Finish();
                }
            }

            // 1. The products linked for this asset (readme, earlier links).
            void FetchFixed(int index)
            {
                if (index >= fixedIds.Count)
                {
                    SearchNames(0);
                    return;
                }
                var known = AssetStore.Item(fixedIds[index]);
                if (known != null)
                {
                    Add(new[] { known });
                    FetchFixed(index + 1);
                    return;
                }
                BoothClient.Fetch(fixedIds[index], (item, _) => Step(() =>
                {
                    if (item != null)
                    {
                        Add(new[] { item });
                        AssetStore.Remember(item);
                    }
                    FetchFixed(index + 1);
                }));
            }

            // 2. Booth's search by the names (the package's, then the asset's). Only the first is tried shorter when it
            // finds nothing; the next name only while nothing close has turned up; no query goes out twice.
            void SearchNames(int index)
            {
                while (index < plan.Queries.Count && !sent.Add(plan.Queries[index])) index++;
                if (index >= plan.Queries.Count || index > 0 && HasStrong())
                {
                    if (plan.Queries.Count == 0 && plan.Shop == null)
                        error = plan.EmptyIsError ? "검색어를 넣어 주세요." : fixedIds.Count == 0 ? "검색할 이름이 없어요. 직접 검색하거나 URL을 넣어 주세요." : null;
                    FindShop();
                    return;
                }
                var text = plan.Queries[index];
                BoothClient.Search(text, (results, searchError) => Step(() =>
                {
                    Add(results);
                    if (searchError != null)
                    {
                        // Booth cannot be reached: the shop would not answer either.
                        error = searchError;
                        Finish();
                        return;
                    }
                    var shorter = index == 0 && plan.RetryShorter && (results == null || results.Count == 0) ? BoothClient.Shorter(text) : null;
                    if (shorter != null && !sent.Contains(shorter))
                    {
                        cache.query = shorter;
                        plan.Queries.Insert(1, shorter);
                    }
                    SearchNames(index + 1);
                }));
            }

            // 3. The asset's shop, from the surest hint on: each is tried in turn until a shop answers with a product
            // close enough to offer.
            void FindShop()
            {
                if (plan.Shop != null)
                {
                    ListShop(plan.Shop, 1, new List<BoothItem>(), Finish);
                    return;
                }
                if (HasStrong())
                {
                    Finish();
                    return;
                }
                TryHint(ShopHints(plan.Name, plan.Package, plan.Folders, readmeShops), 0, 0);
            }

            void TryHint(List<ShopHint> hints, int index, int lookups)
            {
                if (index >= hints.Count)
                {
                    Finish();
                    return;
                }
                var hint = hints[index];
                if (hint.Shop != null)
                {
                    if (triedShops.Contains(hint.Shop)) TryHint(hints, index + 1, lookups);
                    else ListShop(hint.Shop, 1, new List<BoothItem>(), () => TryHint(hints, index + 1, lookups));
                    return;
                }
                // A name to look up as a shop's: a search by it, then the shop whose name it is.
                if (lookups >= ShopNameLookups || sent.Contains(hint.Text))
                {
                    TryHint(hints, index + 1, lookups);
                    return;
                }
                sent.Add(hint.Text);
                BoothClient.Search(hint.Text, (results, searchError) => Step(() =>
                {
                    var shop = searchError == null ? ShopNamed(hint.Text, results) : null;
                    if (shop != null && !triedShops.Contains(shop)) ListShop(shop, 1, new List<BoothItem>(), () => TryHint(hints, index + 1, lookups + 1));
                    else TryHint(hints, index + 1, lookups + 1);
                }));
            }

            // One shop's products, up to ShopPages pages. "next" is the way on when the shop gives nothing to offer.
            void ListShop(string shop, int page, List<BoothItem> found, Action next)
            {
                triedShops.Add(shop);
                BoothClient.ListShop(shop, page, (items, more, shopError) => Step(() =>
                {
                    // A product behind Booth's age check is not shown here; such products are linked by address.
                    foreach (var item in items ?? new List<BoothItem>())
                    {
                        if (item.adult) cache.adultHidden++;
                        else found.Add(item);
                    }
                    if (shopError == null && more && page < ShopPages)
                    {
                        ListShop(shop, page + 1, found, next);
                        return;
                    }
                    if (shopError != null && plan.WholeShop) error = shopError;
                    var offered = plan.WholeShop || found.Count <= SmallShop
                        ? found
                        : found.Where(i => Closeness(i) >= ShopMatch).OrderByDescending(Closeness).Take(5).ToList();
                    if (offered.Count == 0 && !plan.WholeShop)
                    {
                        next();
                        return;
                    }
                    Add(offered);
                    cache.shop = found.FirstOrDefault()?.shop ?? shop;
                    // Search results from the same shop count as the shop's too.
                    cache.shopItems = cache.results.Where(r => ShopOf(r) == shop).Select(r => r.id).ToList();
                    Finish();
                }));
            }

            try { FetchFixed(0); }
            catch (Exception e)
            {
                Debug.LogException(e);
                error = "검색하다 오류가 났어요: " + e.Message;
                Finish();
            }
        }

        private static string ShopOf(BoothItem item) => BoothClient.ShopFromUrl(item.shopUrl);

        // The shop a search by a shop's name points to: one whose name or address is exactly that name, else the
        // shop most of the results come from among those whose name holds it (or is held by it), or none.
        private static string ShopNamed(string text, List<BoothItem> results)
        {
            var wanted = BoothClient.Letters(text);
            if (wanted.Length < 2 || results == null) return null;
            var shops = results.Select(r => (Name: BoothClient.Letters(r.shop), Address: ShopOf(r))).Where(s => s.Address != null).ToList();
            var exact = shops.FirstOrDefault(s => s.Name == wanted || s.Address.Replace("-", "") == wanted).Address;
            if (exact != null) return exact;
            return shops.Where(s => s.Name.Length >= 2 && (s.Name.Contains(wanted) || wanted.Contains(s.Name)))
                .GroupBy(s => s.Address).OrderByDescending(g => g.Count()).Select(g => g.Key).FirstOrDefault();
        }

        internal sealed class ShopHint
        {
            public string Shop;  // a shop's booth.pm subdomain, when known
            public string Text;  // a name that may be the shop's, to look up
            public string From;  // where it was found, for the tests and the log
        }

        // Where the asset's shop may show, the surest first: a shop address in its readme files, the shop of the
        // linked assets beside it (same parent folder), the parent folder's name, and 【notes】 in its names. A parent
        // folder whose linked assets come from several shops (an "Avatars" folder) is a mix and says nothing.
        internal static List<ShopHint> ShopHints(string name, string package, IEnumerable<string> folderPaths, IEnumerable<string> readmeShops = null)
        {
            var hints = new List<ShopHint>();
            var folders = (folderPaths ?? Enumerable.Empty<string>()).Select(f => f.Replace('\\', '/').TrimEnd('/')).ToList();
            foreach (var shop in readmeShops ?? ReadReadmes(folders).Shops) hints.Add(new ShopHint { Shop = shop, From = "readme" });

            var parents = folders.Select(f => Path.GetDirectoryName(f)?.Replace('\\', '/')).Where(p => !string.IsNullOrEmpty(p) && p != "Assets").Distinct().ToList();
            var own = new HashSet<string>(folders);
            var siblingShops = new List<string>();
            foreach (var asset in AssetStore.Project.assets.Where(a => a.boothId > 0))
            {
                var shop = ShopOf(AssetStore.Item(asset.boothId) ?? new BoothItem());
                if (shop == null) continue;
                if (AssetFolders.ExistingFolders(asset).Any(f => !own.Contains(f) && parents.Contains(Path.GetDirectoryName(f)?.Replace('\\', '/'))))
                    siblingShops.Add(shop);
            }
            var top = siblingShops.GroupBy(s => s).OrderByDescending(g => g.Count()).FirstOrDefault();
            // Two thirds of the linked neighbours from one shop make it the folder's shop.
            var dominant = top != null && top.Count() * 3 >= siblingShops.Count * 2 ? top.Key : null;
            var mixed = siblingShops.Count > 0 && dominant == null;
            if (dominant != null) hints.Add(new ShopHint { Shop = dominant, From = "sibling" });

            var query = BoothClient.Letters(name);
            void Text(string text, string from)
            {
                var letters = BoothClient.Letters(text);
                // A note about the avatar or the price says nothing of the shop; nor does the product's own name.
                if (letters.Length < 2 || letters == query || text.Contains("対応") || text.Contains("대응") ||
                    Regex.IsMatch(text.Trim(), @"(?i)^(free|無料|무료|sale|new|vrc|vrchat|quest|pc|unity)$")) return;
                if (hints.All(h => h.Text == null || BoothClient.Letters(h.Text) != letters)) hints.Add(new ShopHint { Text = text.Trim(), From = from });
            }
            if (!mixed)
                foreach (var parent in parents) Text(Path.GetFileName(parent), "parent folder");
            foreach (var source in new[] { name, package }.Concat(folders.Select(Path.GetFileName)))
                foreach (Match m in Regex.Matches(source ?? "", @"【([^】]+)】|\[([^\]]+)\]|［([^］]+)］"))
                    Text(m.Groups[1].Success ? m.Groups[1].Value : m.Groups[2].Success ? m.Groups[2].Value : m.Groups[3].Value, "bracket");
            return hints.GroupBy(h => h.Shop ?? "\u0000" + h.Text).Select(g => g.First()).ToList();
        }

        public static void Link(AssetRecord asset, BoothItem item)
        {
            asset.boothId = item.id;
            asset.boothName = item.name ?? "";
            AssetStore.Remember(item);
            foreach (var key in new[] { asset.package, asset.name }.Concat(AssetFolders.ExistingFolders(asset).Select(Path.GetFileName)))
                AssetStore.Hint(key, item.id);
            AssetStore.SaveProject();
            Updated?.Invoke();
        }

        // Links by URL or ID; when Booth gives no details (for example an age-restricted product) the link is kept
        // with the ID alone and the user's own asset name.
        public static void LinkById(AssetRecord asset, long id, Action<string> done)
        {
            var known = AssetStore.Item(id);
            if (known != null)
            {
                Link(asset, known);
                done?.Invoke(null);
                return;
            }
            BoothClient.Fetch(id, (item, error) =>
            {
                Link(asset, item ?? new BoothItem { id = id });
                done?.Invoke(item == null ? error : null);
            });
        }

        public static void Unlink(AssetRecord asset)
        {
            asset.boothId = 0;
            asset.boothName = "";
            AssetStore.SaveProject();
            Updated?.Invoke();
        }

        // Results found for a proposal carry over to the asset made from it; a search still running goes on for it.
        public static void Transfer(string fromOwner, string toOwner)
        {
            var cache = AssetStore.SearchFor(fromOwner);
            if (cache == null) return;
            AssetStore.State.searches.RemoveAll(s => s.owner == toOwner);
            cache.owner = toOwner;
            if (Running.Contains(fromOwner))
            {
                Moved[fromOwner] = toOwner;
                Running.Add(toOwner);
            }
            AssetStore.SaveState();
        }

        // The asset's readme-like files (small text files only): the first Booth product linked in them, and every
        // shop address they mention.
        private static (long Item, List<string> Shops) ReadReadmes(IEnumerable<string> folderPaths)
        {
            long item = 0;
            var shops = new List<string>();
            foreach (var folder in folderPaths ?? Enumerable.Empty<string>())
            {
                if (!Directory.Exists(folder)) continue;
                IEnumerable<string> files;
                try { files = Directory.EnumerateFiles(folder, "*", SearchOption.AllDirectories).Take(4000).ToList(); }
                catch (IOException) { continue; }
                catch (UnauthorizedAccessException) { continue; }
                foreach (var file in files.Where(f => TextExtensions.Contains(Path.GetExtension(f).ToLowerInvariant()))
                             .OrderBy(f => f.Count(c => c == '/' || c == '\\')).Take(40))
                {
                    try
                    {
                        if (new FileInfo(file).Length > 1 << 20) continue;
                        var text = File.ReadAllText(file);
                        if (item == 0) item = BoothClient.FindItemIds(text).FirstOrDefault();
                        foreach (var shop in BoothClient.FindShops(text))
                            if (!shops.Contains(shop)) shops.Add(shop);
                    }
                    catch (IOException) { }
                    catch (UnauthorizedAccessException) { }
                }
            }
            return (item, shops);
        }
    }
}
