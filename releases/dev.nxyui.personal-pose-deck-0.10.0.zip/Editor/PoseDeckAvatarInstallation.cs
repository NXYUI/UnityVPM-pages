using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using nadena.dev.modular_avatar.core;
using UnityEditor;
using UnityEditor.Animations;
using UnityEditor.SceneManagement;
using UnityEngine;
using VRC.SDK3.Avatars.Components;
using VRC.SDK3.Avatars.ScriptableObjects;
using Layer = VRC.SDK3.Avatars.Components.VRCAvatarDescriptor.AnimLayerType;

namespace PersonalPoseDeck
{
    // Project metadata for recognising the scene instance without adding a script to the avatar.
    public sealed class PoseDeckAvatarInstallation : ScriptableObject
    {
        [SerializeField] internal GameObject sourcePrefab;
        [SerializeField] internal AnimatorController controller;
        [SerializeField] internal VRCExpressionsMenu menu;
        // Recorded since 0.9.0. Older installations are matched to the preset next to their generated folder.
        [SerializeField] internal PoseDeckPreset preset;
    }

    internal static class PoseDeckAvatarInstall
    {
        private const string PrefabName = "GogoLoco All (Modular Avatar).prefab";
        private const string Marker = "PoseDeckAvatarInstallation.asset";
        private const string InstanceName = "Personal Pose Deck (GoGoLoco)";
        private static readonly Layer[] ReplacedLayers = { Layer.Base, Layer.Action, Layer.Sitting };

        private sealed class Setup
        {
            public GameObject Prefab;
            public AnimatorController Controller;
            public VRCExpressionsMenu Menu;
            public GameObject Installed;
        }

        private static VRCAvatarDescriptor GetAvatar(GameObject go)
        {
            if (!go || !go.scene.IsValid() || !go.scene.isLoaded || EditorUtility.IsPersistent(go) ||
                PrefabStageUtility.GetPrefabStage(go) != null || EditorSceneManager.IsPreviewScene(go.scene) ||
                !go.TryGetComponent<VRCAvatarDescriptor>(out var avatar))
                throw new InvalidOperationException("일반 씬의 Hierarchy에서 VRC Avatar Descriptor가 붙은 아바타 루트를 선택해 주세요.");
            return avatar;
        }

        private static PoseDeckAvatarInstallation GetMarker(VRCExpressionsMenu menu)
        {
            if (!menu) return null;
            string path = AssetDatabase.GetAssetPath(menu);
            const string suffix = "/PoseDeckInstaller.asset";
            if (!path.EndsWith(suffix, StringComparison.Ordinal)) return null;
            var marker = AssetDatabase.LoadAssetAtPath<PoseDeckAvatarInstallation>(
                path.Substring(0, path.Length - suffix.Length + 1) + Marker);
            return marker && marker.menu == menu ? marker : null;
        }

        internal static bool IsAvatarInstallation(GameObject go, PoseDeckBuilder.Target bindings) =>
            GetInstallation(go, bindings.Base.animator, bindings.Menu.menuToAppend);

        private static PoseDeckAvatarInstallation GetInstallation(
            GameObject go, RuntimeAnimatorController controller, VRCExpressionsMenu menu)
        {
            var marker = GetMarker(menu);
            if (!marker || !marker.sourcePrefab || !controller || marker.controller != controller ||
                PrefabUtility.GetCorrespondingObjectFromSource(go) != marker.sourcePrefab)
                return null;
            return marker;
        }

        private static IEnumerable<T> OnAvatar<T>(VRCAvatarDescriptor avatar) where T : Component =>
            avatar.GetComponentsInChildren<T>(true).Where(c => c.GetComponentInParent<VRCAvatarDescriptor>(true) == avatar);

        private static (GameObject go, PoseDeckAvatarInstallation marker) FindInstalled(VRCAvatarDescriptor avatar)
        {
            var installs = OnAvatar<ModularAvatarMenuInstaller>(avatar).Select(menu =>
            {
                var go = menu.gameObject;
                var bases = go.GetComponents<ModularAvatarMergeAnimator>().Where(x => x.layerType == Layer.Base).ToArray();
                return (go, marker: bases.Length == 1 ? GetInstallation(go, bases[0].animator, menu.menuToAppend) : null);
            }).Where(x => x.marker).ToArray();
            if (installs.Length > 1)
                throw new InvalidOperationException("이 아바타에 Pose Deck 설치본이 여러 개 있습니다. Hierarchy에서 중복 설치본을 정리해 주세요.");
            return installs.Length == 1 ? installs[0] : (null, null);
        }

        private static bool IsGoGoName(string value)
        {
            if (string.IsNullOrEmpty(value)) return false;
            var name = value.Replace(" ", "").Replace("-", "").Replace("_", "");
            return name.IndexOf("gogoloco", StringComparison.OrdinalIgnoreCase) >= 0 ||
                   name.IndexOf("golocobase", StringComparison.OrdinalIgnoreCase) >= 0;
        }

        private static bool HasGoGoParameters(IEnumerable<string> names)
        {
            var set = new HashSet<string>(names, StringComparer.Ordinal);
            return set.Contains("Go/Float") && set.Contains("Go/PoseRadial");
        }

        private static bool Ignored(Transform transform, Transform avatarRoot, GameObject installed)
        {
            if (installed && transform.IsChildOf(installed.transform)) return true;
            for (var node = transform; node && node != avatarRoot; node = node.parent)
                if (node.CompareTag("EditorOnly")) return true;
            return false;
        }

        private static void CheckConflicts(VRCAvatarDescriptor avatar, GameObject installed)
        {
            bool Skip(Component c) => Ignored(c.transform, avatar.transform, installed);
            var named = OnAvatar<Transform>(avatar).FirstOrDefault(t => t != avatar.transform && !Skip(t) &&
                (IsGoGoName(t.name) || (PrefabUtility.IsAnyPrefabInstanceRoot(t.gameObject) &&
                    IsGoGoName(Path.GetFileName(PrefabUtility.GetPrefabAssetPathOfNearestInstanceRoot(t.gameObject))))));
            var goGoParams = OnAvatar<ModularAvatarParameters>(avatar).FirstOrDefault(c => !Skip(c) &&
                HasGoGoParameters(c.parameters?.Select(p => p.nameOrPrefix) ?? Enumerable.Empty<string>()));
            if (named || goGoParams)
            {
                var name = named ? named.name : goGoParams.gameObject.name;
                throw new InvalidOperationException($"'{name}'에 기존 GoGoLoco가 있습니다. 개조한 구성을 유지하려면 ‘기존 GoGoLoco에 적용’을 선택해 주세요.");
            }
            if (avatar.customExpressions && avatar.expressionParameters && avatar.expressionParameters.parameters != null &&
                HasGoGoParameters(avatar.expressionParameters.parameters.Where(p => p != null).Select(p => p.name)))
                throw new InvalidOperationException("아바타의 Expression Parameters에 기존 GoGoLoco 파라미터가 있습니다. 중복 설치를 막기 위해 멈췄습니다.");

            var replace = OnAvatar<ModularAvatarMergeAnimator>(avatar).FirstOrDefault(c => !Skip(c) &&
                ReplacedLayers.Contains(c.layerType) && c.mergeAnimatorMode == MergeAnimatorMode.Replace);
            if (replace)
                throw new InvalidOperationException($"'{replace.gameObject.name}'이(가) 이미 {replace.layerType} 레이어를 교체합니다. 충돌을 막기 위해 설치를 멈췄습니다.");

            if (avatar.customizeAnimationLayers)
            {
                var layers = (avatar.baseAnimationLayers ?? Array.Empty<VRCAvatarDescriptor.CustomAnimLayer>())
                    .Concat(avatar.specialAnimationLayers ?? Array.Empty<VRCAvatarDescriptor.CustomAnimLayer>());
                var custom = layers.FirstOrDefault(l => ReplacedLayers.Contains(l.type) && !l.isDefault && l.animatorController);
                if (custom.animatorController)
                    throw new InvalidOperationException($"아바타의 {custom.type}에 '{custom.animatorController.name}'이(가) 지정되어 있습니다. 이 설정을 보호하기 위해 설치를 멈췄습니다.");
            }
        }

        private static Setup ReadStock(GameObject prefab)
        {
            if (!prefab || !prefab.activeSelf || prefab.transform.childCount == 0) return null;
            var layers = prefab.GetComponents<ModularAvatarMergeAnimator>();
            if (ReplacedLayers.Any(layer => layers.Count(c => c.layerType == layer && c.enabled && c.animator &&
                    c.mergeAnimatorMode == MergeAnimatorMode.Replace) != 1)) return null;
            var bases = layers.Where(c => c.layerType == Layer.Base && c.enabled).ToArray();
            var menus = prefab.GetComponents<ModularAvatarMenuInstaller>().Where(c => c.enabled).ToArray();
            if (bases.Length != 1 || !(bases[0].animator is AnimatorController controller) ||
                menus.Length != 1 || !menus[0].menuToAppend ||
                !prefab.GetComponents<ModularAvatarParameters>().Any(c =>
                    HasGoGoParameters(c.parameters?.Select(p => p.nameOrPrefix) ?? Enumerable.Empty<string>())) ||
                !PoseDeckBuilder.SupportsSource(controller, menus[0].menuToAppend)) return null;
            return new Setup { Prefab = prefab, Controller = controller, Menu = menus[0].menuToAppend };
        }

        private static Setup FindStock()
        {
            var known = PoseDeckBuilder.VendorRoots.Select(root => root + "Prefabs/Modular Avatar/" + PrefabName).ToArray();
            Setup TryPath(string path) => ReadStock(AssetDatabase.LoadAssetAtPath<GameObject>(path));
            foreach (var path in known)
                if (TryPath(path) is Setup stock) return stock;
            foreach (var path in AssetDatabase.GetAllAssetPaths().Where(path =>
                (path.StartsWith("Assets/", StringComparison.Ordinal) || path.StartsWith("Packages/", StringComparison.Ordinal)) &&
                path.EndsWith("/" + PrefabName, StringComparison.OrdinalIgnoreCase) && !known.Contains(path))
                .OrderBy(path => path, StringComparer.Ordinal))
                if (TryPath(path) is Setup stock) return stock;
            throw new InvalidOperationException("정상적으로 연결된 GoGoLoco All (Modular Avatar) 프리팹을 찾을 수 없습니다. 먼저 프로젝트에 GoGoLoco를 임포트해 주세요.");
        }

        // The stock GoGoLoco All (Modular Avatar) Base and Action, for the start-height preview.
        internal static PoseDeckBuilder.PreviewSource FindPreviewSource()
        {
            var stock = FindStock();
            var action = stock.Prefab.GetComponents<ModularAvatarMergeAnimator>()
                .FirstOrDefault(c => c.enabled && c.layerType == Layer.Action)?.animator as AnimatorController;
            return PoseDeckBuilder.PreviewSourceFor(stock.Controller, action);
        }

        private static Setup Resolve(GameObject avatar)
        {
            var descriptor = GetAvatar(avatar);
            var (installed, marker) = FindInstalled(descriptor);
            CheckConflicts(descriptor, installed);
            if (!installed) return FindStock();
            var source = ReadStock(marker.sourcePrefab);
            if (source == null)
                throw new InvalidOperationException("설치할 때 사용한 GoGoLoco 원본 프리팹을 사용할 수 없습니다. 원본을 다시 임포트해 주세요.");
            if (!installed.activeSelf || Ignored(installed.transform, avatar.transform, null))
                throw new InvalidOperationException("기존 Pose Deck 설치본이 비활성 상태입니다. 활성화하거나 ‘적용 제거’ 후 다시 설치해 주세요.");
            source.Installed = installed;
            return source;
        }

        internal static string Preview(PoseDeckPreset preset, GameObject avatar)
        {
            var source = Resolve(avatar);
            return PoseDeckBuilder.Preview(preset, source.Controller, source.Menu) +
                   "\n사용 원본: " + AssetDatabase.GetAssetPath(source.Prefab);
        }

        internal static string Apply(PoseDeckPreset preset, GameObject avatar)
        {
            var source = Resolve(avatar);
            if (source.Installed) PoseDeckBuilder.GetTarget(source.Installed);
            var (folder, controller, menu) = PoseDeckBuilder.GenerateAssets(preset, source.Controller, source.Menu);
            Undo.IncrementCurrentGroup();
            int group = Undo.GetCurrentGroup();
            Undo.SetCurrentGroupName("Install Personal Pose Deck on Avatar");
            try
            {
                var marker = ScriptableObject.CreateInstance<PoseDeckAvatarInstallation>();
                marker.sourcePrefab = source.Prefab;
                marker.controller = controller;
                marker.menu = menu;
                marker.preset = preset;
                AssetDatabase.CreateAsset(marker, folder + "/" + Marker);

                var instance = source.Installed;
                if (!instance)
                {
                    instance = PrefabUtility.InstantiatePrefab(source.Prefab, avatar.transform) as GameObject;
                    if (!instance) throw new InvalidOperationException("아바타 아래에 GoGoLoco 프리팹을 배치하지 못했습니다.");
                    instance.name = GameObjectUtility.GetUniqueNameForSibling(avatar.transform, InstanceName);
                    Undo.RegisterCreatedObjectUndo(instance, "Add Personal Pose Deck");
                    PrefabUtility.RecordPrefabInstancePropertyModifications(instance);
                }
                PoseDeckBuilder.Wire(PoseDeckBuilder.GetTarget(instance), controller, menu);
                AssetDatabase.SaveAssets();
                Undo.CollapseUndoOperations(group);
                return folder;
            }
            catch
            {
                Undo.RevertAllDownToGroup(group);
                AssetDatabase.DeleteAsset(folder);
                throw;
            }
        }

        // The installation added by "아바타에 새로 적용" and the preset it was generated from (null when unknown).
        internal static (GameObject installed, PoseDeckPreset preset) FindApplied(GameObject avatar)
        {
            if (!avatar || !avatar.TryGetComponent<VRCAvatarDescriptor>(out var descriptor)) return (null, null);
            try
            {
                var (installed, marker) = FindInstalled(descriptor);
                if (!installed) return (null, null);
                if (marker.preset) return (installed, marker.preset);
                // Generated folders are created next to their preset; use it when that folder holds exactly one.
                var folder = Path.GetDirectoryName(Path.GetDirectoryName(AssetDatabase.GetAssetPath(marker)))?.Replace('\\', '/');
                var nearby = string.IsNullOrEmpty(folder) ? Array.Empty<string>() :
                    AssetDatabase.FindAssets("t:PoseDeckPreset", new[] { folder })
                        .Select(AssetDatabase.GUIDToAssetPath)
                        .Where(p => Path.GetDirectoryName(p)?.Replace('\\', '/') == folder).ToArray();
                return (installed, nearby.Length == 1 ? AssetDatabase.LoadAssetAtPath<PoseDeckPreset>(nearby[0]) : null);
            }
            catch (InvalidOperationException) { return (null, null); }
        }

        internal static void Remove(GameObject avatar)
        {
            var descriptor = GetAvatar(avatar);
            var (installed, _) = FindInstalled(descriptor);
            if (!installed)
                throw new InvalidOperationException("이 아바타에 ‘아바타에 새로 적용’으로 설치한 Pose Deck이 없습니다.");
            Undo.DestroyObjectImmediate(installed);
            EditorSceneManager.MarkSceneDirty(avatar.scene);
        }
    }
}
