using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;
using Object = UnityEngine.Object;

namespace PersonalPoseDeck
{
    internal sealed partial class PoseDeckPoseBrowser
    {
        private const int ThumbnailPixels = 128;
        private const int ThumbnailCacheLimit = 180;
        private const float TileMinWidth = 112f;
        private const float TileHeight = 128f;
        private const float HeaderHeight = 24f;
        private const float Gap = 6f;

        private sealed class GalleryGroup
        {
            public string Root;
            public List<Item> Items;
        }

        private sealed class Thumbnail
        {
            public Texture2D Image;
            public LinkedListNode<AnimationClip> Order;
        }

        [SerializeField] private string folderFilter = "";
        private readonly Dictionary<string, bool> groupOpen = new Dictionary<string, bool>(StringComparer.Ordinal);
        private readonly List<GalleryGroup> galleryGroups = new List<GalleryGroup>();
        private readonly Dictionary<AnimationClip, Thumbnail> thumbnails = new Dictionary<AnimationClip, Thumbnail>();
        private readonly LinkedList<AnimationClip> thumbOrder = new LinkedList<AnimationClip>();
        private readonly List<Item> visibleThumbRequests = new List<Item>();
        private string[] folderRoots = { "" }, folderLabels = { "모든 폴더" };
        private Vector2 galleryScroll;
        private PoseDeckPosePreview thumbnailRenderer;
        private string thumbnailProblem;
        private double nextThumbnailTime;
        private GUIStyle tileCaption, tilePlaceholder;

        internal static string GroupRootFor(string path)
        {
            int slash = path.IndexOf('/');
            if (slash < 0) return path;
            int next = path.IndexOf('/', slash + 1);
            return next < 0 ? path.Substring(0, slash) : path.Substring(0, next);
        }

        private static string FolderLabel(string root)
        {
            int slash = root.IndexOf('/');
            if (slash < 0) return root + " (최상위)";
            return root.Substring(slash + 1) + " · " + root.Substring(0, slash);
        }

        private bool MatchesSourceAndType(Item item)
        {
            return item.Clip && (typeFilter != 0 || item.Humanoid) && (typeFilter != 2 || !item.Humanoid) &&
                   (sourceFilter != 1 || item.Path.StartsWith("Assets/", StringComparison.Ordinal)) &&
                   (sourceFilter != 2 || item.Path.StartsWith("Packages/", StringComparison.Ordinal));
        }

        private void RebuildGalleryGroups()
        {
            galleryGroups.Clear();
            galleryGroups.AddRange(filtered.GroupBy(item => item.GroupRoot, StringComparer.Ordinal)
                .OrderBy(group => FolderLabel(group.Key), StringComparer.OrdinalIgnoreCase)
                .Select(group => new GalleryGroup { Root = group.Key, Items = group.ToList() }));
            var roots = new HashSet<string>(index.Where(MatchesSourceAndType).Select(i => i.GroupRoot), StringComparer.Ordinal);
            if (!string.IsNullOrEmpty(folderFilter)) roots.Add(folderFilter);
            folderRoots = new[] { "" }.Concat(roots.OrderBy(FolderLabel, StringComparer.OrdinalIgnoreCase)).ToArray();
            folderLabels = folderRoots.Select(x => x.Length == 0 ? "모든 폴더" : FolderLabel(x)).ToArray();
        }

        private bool IsExpanded(GalleryGroup group, int indexInView)
        {
            if (groupOpen.TryGetValue(group.Root, out var open)) return open;
            return indexInView == 0 || !string.IsNullOrWhiteSpace(search) || !string.IsNullOrEmpty(folderFilter);
        }

        private void SetExpansion(bool open)
        {
            foreach (var group in galleryGroups) groupOpen[group.Root] = open;
            galleryScroll = Vector2.zero;
            Repaint();
        }

        private void DrawGallery(float width)
        {
            using (new EditorGUILayout.VerticalScope(GUILayout.Width(width), GUILayout.ExpandHeight(true)))
            {
                EditorGUI.BeginChangeCheck();
                search = EditorGUILayout.TextField(search, EditorStyles.toolbarSearchField);
                using (new EditorGUILayout.HorizontalScope())
                {
                    sourceFilter = EditorGUILayout.Popup(sourceFilter, SourceOptions);
                    typeFilter = EditorGUILayout.Popup(typeFilter, TypeOptions);
                }
                if (EditorGUI.EndChangeCheck()) { refreshFilter = true; galleryScroll = Vector2.zero; }
                DrawAvatarFilters();
                if (refreshFilter) Filter();

                using (new EditorGUILayout.HorizontalScope())
                {
                    int selected = Mathf.Max(0, Array.IndexOf(folderRoots, folderFilter ?? ""));
                    int folder = EditorGUILayout.Popup(selected, folderLabels, GUILayout.ExpandWidth(true));
                    if (folder != selected)
                    {
                        folderFilter = folderRoots[folder];
                        if (!string.IsNullOrEmpty(folderFilter)) groupOpen[folderFilter] = true;
                        galleryScroll = Vector2.zero;
                        Filter();
                    }
                    if (GUILayout.Button("펼치기", EditorStyles.miniButtonLeft, GUILayout.Width(54))) SetExpansion(true);
                    if (GUILayout.Button("접기", EditorStyles.miniButtonRight, GUILayout.Width(43))) SetExpansion(false);
                }

                using (new EditorGUILayout.HorizontalScope())
                {
                    var total = pending == null ? $"{galleryGroups.Count:N0}개 폴더 · {filtered.Count:N0} / {index.Count:N0}개" :
                        $"검색 중 {cursor:N0}/{pending.Length:N0} · {filtered.Count:N0}개";
                    EditorGUILayout.LabelField(total, EditorStyles.miniLabel);
                    if (GUILayout.Button(scanStale ? "새로 검색 *" : "새로 검색", EditorStyles.miniButton, GUILayout.Width(84))) startScan = true;
                }
                if (skippedPaths != 0 && pending == null) EditorGUILayout.LabelField($"읽지 못한 파일 {skippedPaths}개", EditorStyles.miniLabel);

                var viewport = GUILayoutUtility.GetRect(250, 220, GUILayout.ExpandWidth(true), GUILayout.ExpandHeight(true));
                DrawGalleryViewport(viewport);
            }
        }

        private void DrawGalleryViewport(Rect viewport)
        {
            bool repaint = Event.current.type == EventType.Repaint;
            if (repaint) visibleThumbRequests.Clear();
            if (viewport.width < 40 || viewport.height < 40) return;
            float contentWidth = viewport.width - 17f;
            int columns = Mathf.Max(1, Mathf.FloorToInt((contentWidth - Gap) / (TileMinWidth + Gap)));
            float tileWidth = (contentWidth - Gap * (columns + 1)) / columns;
            float rowStride = TileHeight + Gap;
            float height = Gap;
            for (int i = 0; i < galleryGroups.Count; i++)
            {
                var group = galleryGroups[i];
                height += HeaderHeight + Gap;
                if (IsExpanded(group, i)) height += ((group.Items.Count + columns - 1) / columns) * rowStride;
            }
            if (repaint) EditorGUI.DrawRect(viewport, new Color(.15f, .16f, .18f));
            if (galleryGroups.Count == 0)
            {
                string label = pending != null || startScan ? "프로젝트에서 애니메이션을 찾고 있어요…" : "이 필터에 맞는 클립이 없어요.";
                GUI.Label(new Rect(viewport.x + 12, viewport.y + 10, viewport.width - 24, 22), label, EditorStyles.miniLabel);
                return;
            }

            galleryScroll.y = Mathf.Clamp(galleryScroll.y, 0, Mathf.Max(0, height - viewport.height));
            galleryScroll = GUI.BeginScrollView(viewport, galleryScroll, new Rect(0, 0, contentWidth, height), false, true);
            try
            {
                float top = galleryScroll.y, bottom = top + viewport.height;
                float y = Gap;
                for (int i = 0; i < galleryGroups.Count && y < bottom; i++)
                {
                    var group = galleryGroups[i];
                    bool open = IsExpanded(group, i);
                    var header = new Rect(Gap, y, contentWidth - Gap * 2, HeaderHeight);
                    if (header.yMax >= top)
                    {
                        if (repaint) EditorGUI.DrawRect(header, new Color(.27f, .28f, .31f));
                        var foldRect = new Rect(header.x + 13, header.y, header.width - 17, header.height);
                        bool next = EditorGUI.Foldout(foldRect, open,
                            new GUIContent($"{FolderLabel(group.Root)}  ({group.Items.Count:N0})", group.Root), true);
                        if (next != open) { groupOpen[group.Root] = next; Repaint(); }
                    }
                    y += HeaderHeight + Gap;
                    if (!open) continue;
                    int rows = (group.Items.Count + columns - 1) / columns;
                    int first = Mathf.Clamp(Mathf.FloorToInt((top - y) / rowStride), 0, rows);
                    int last = Mathf.Clamp(Mathf.CeilToInt((bottom - y) / rowStride), 0, rows);
                    for (int row = first; row < last; row++)
                        for (int col = 0; col < columns; col++)
                        {
                            int itemIndex = row * columns + col;
                            if (itemIndex >= group.Items.Count) break;
                            var card = new Rect(Gap + col * (tileWidth + Gap), y + row * rowStride, tileWidth, TileHeight);
                            DrawCard(card, group.Items[itemIndex], repaint);
                        }
                    y += rows * rowStride;
                }
            }
            finally { GUI.EndScrollView(); }
        }

        private void DrawCard(Rect card, Item item, bool repaint)
        {
            if (tileCaption == null)
            {
                tileCaption = new GUIStyle(EditorStyles.miniLabel) { clipping = TextClipping.Clip, wordWrap = false };
                tilePlaceholder = new GUIStyle(EditorStyles.miniLabel) { alignment = TextAnchor.MiddleCenter, clipping = TextClipping.Clip };
            }
            bool selected = active != null && active.Clip == item.Clip;
            bool marked = queued.Contains(item.Clip);
            var image = new Rect(card.x + 3f, card.y + 3f, card.width - 6f, card.height - 25f);
            var tooltip = item.Name + "\n" + item.Path;
            if (repaint)
            {
                EditorGUI.DrawRect(card, selected ? new Color(.23f, .46f, .70f) : marked ? new Color(.25f, .39f, .32f) : new Color(.24f, .25f, .28f));
                EditorGUI.DrawRect(image, new Color(.19f, .21f, .24f));
            }
            if (GUI.Button(image, new GUIContent("", tooltip), GUIStyle.none)) Select(item);
            if (repaint)
            {
                if (thumbnails.TryGetValue(item.Clip, out var thumb))
                {
                    Touch(thumb);
                    if (thumb.Image) GUI.DrawTexture(image, thumb.Image, ScaleMode.ScaleToFit, false);
                    else GUI.Label(image, "미리보기 없음", tilePlaceholder);
                }
                else if (avatar && item.Clip && !item.Clip.legacy && thumbnailProblem == null)
                {
                    visibleThumbRequests.Add(item);
                    GUI.Label(image, "미리보기 준비 중", tilePlaceholder);
                }
                else GUI.Label(image, thumbnailProblem ?? (avatar ? "미리보기 없음" : "아바타 선택"), tilePlaceholder);
                if (deckClips.Contains(item.Clip))
                {
                    var badge = new Rect(image.x + 3f, image.y + 3f, 24f, 15f);
                    EditorGUI.DrawRect(badge, new Color(.20f, .48f, .32f, .95f));
                    GUI.Label(badge, new GUIContent("덱", "현재 프리셋에 들어 있는 클립입니다."), tilePlaceholder);
                }
            }
            using (new EditorGUI.DisabledScope(!item.Humanoid))
            {
                bool next = GUI.Toggle(new Rect(card.x + 5, card.yMax - 19, 15, 17), marked, new GUIContent("", "프리셋에 넣을 목록에 선택"));
                if (next != marked) { if (next) queued.Add(item.Clip); else queued.Remove(item.Clip); Repaint(); }
            }
            GUI.Label(new Rect(card.x + 22, card.yMax - 20, card.width - 26, 18), new GUIContent(item.Name, tooltip), tileCaption);
        }

        private void Touch(Thumbnail thumbnail)
        {
            thumbOrder.Remove(thumbnail.Order);
            thumbOrder.AddLast(thumbnail.Order);
        }

        private void SaveThumbnail(AnimationClip clip, Texture2D texture)
        {
            thumbnails.Add(clip, new Thumbnail { Image = texture, Order = thumbOrder.AddLast(clip) });
            while (thumbnails.Count > ThumbnailCacheLimit)
            {
                var key = thumbOrder.First.Value;
                if (thumbnails[key].Image) Object.DestroyImmediate(thumbnails[key].Image);
                thumbnails.Remove(key);
                thumbOrder.RemoveFirst();
            }
        }

        private void TickThumbnail()
        {
            var source = PreviewRoot;
            if (!source || thumbnailProblem != null || visibleThumbRequests.Count == 0 || EditorApplication.isUpdating) return;
            var now = EditorApplication.timeSinceStartup;
            if (now < nextThumbnailTime) return;
            var next = visibleThumbRequests.FirstOrDefault(i => i.Clip && !thumbnails.ContainsKey(i.Clip));
            if (next == null) return;
            nextThumbnailTime = now + .05;
            if (thumbnailRenderer == null)
            {
                try
                {
                    thumbnailRenderer = new PoseDeckPosePreview(source);
                    if (!thumbnailRenderer.HasRenderers) thumbnailProblem = "렌더러 없음";
                }
                catch (Exception e)
                {
                    thumbnailProblem = "미리보기 오류";
                    message = "갤러리 미리보기: " + e.Message;
                }
                if (thumbnailProblem != null) { Repaint(); return; }
            }

            Texture2D texture = null;
            try
            {
                if (!next.Humanoid || thumbnailRenderer.HasHumanoidAvatar)
                    texture = thumbnailRenderer.CaptureThumbnail(next.Clip, ThumbnailPixels);
            }
            catch (Exception e)
            {
                message = $"{next.Name} 미리보기: {e.Message}";
            }
            SaveThumbnail(next.Clip, texture);
            Repaint();
        }

        private void ClearThumbnails()
        {
            foreach (var thumb in thumbnails.Values) if (thumb.Image) Object.DestroyImmediate(thumb.Image);
            thumbnails.Clear();
            thumbOrder.Clear();
            visibleThumbRequests.Clear();
            thumbnailRenderer?.Dispose();
            thumbnailRenderer = null;
            thumbnailProblem = null;
            nextThumbnailTime = 0;
        }
    }
}
