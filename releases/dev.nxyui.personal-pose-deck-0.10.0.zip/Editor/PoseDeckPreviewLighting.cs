using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using UnityEngine;

namespace PersonalPoseDeck
{
    // Preview lights. Position is a top-down view of the avatar: up = its front (+Z), right = its right (+X);
    // the centre puts the key light overhead and the edge on the horizon.
    [Serializable]
    internal sealed class PoseDeckPreviewLighting
    {
        public Vector2 position = new Vector2(.42f, .62f);
        [Range(0f, 3f)] public float intensity = 1.55f;
        [Range(0f, 1f)] public float temperature = .5f; // 0 warm (2700 K) – .5 neutral – 1 cool (9000 K)
        [Range(0f, 3f)] public float fill = 1.1f;
        [Range(0f, 2f)] public float ambient = .65f;

        internal static readonly (string Label, PoseDeckPreviewLighting Value)[] Presets =
        {
            ("기본", new PoseDeckPreviewLighting()),
            ("정면", new PoseDeckPreviewLighting { position = new Vector2(0f, .55f), intensity = 1.4f, fill = .6f, ambient = .7f }),
            ("측면", new PoseDeckPreviewLighting { position = new Vector2(.92f, .1f), intensity = 1.6f, fill = .35f, ambient = .45f }),
            ("역광", new PoseDeckPreviewLighting { position = new Vector2(0f, -.8f), intensity = 1.8f, fill = .5f, ambient = .5f }),
            ("야외", new PoseDeckPreviewLighting { position = new Vector2(.3f, .35f), intensity = 1.9f, temperature = .58f, fill = .9f, ambient = 1.05f }),
            ("밤", new PoseDeckPreviewLighting { position = new Vector2(-.5f, .5f), intensity = .35f, temperature = .82f, fill = .15f, ambient = .22f }),
        };

        internal PoseDeckPreviewLighting Clone() => (PoseDeckPreviewLighting)MemberwiseClone();

        internal void CopyFrom(PoseDeckPreviewLighting other)
        {
            position = other.position; intensity = other.intensity; temperature = other.temperature; fill = other.fill; ambient = other.ambient;
        }

        // Elevation in degrees: 90 overhead at the centre, 5 at the edge.
        internal float Elevation => Mathf.Lerp(90f, 5f, Mathf.Clamp01(position.magnitude));
        // 0 = in front of the avatar, 90 = on its right.
        internal float Azimuth => position.sqrMagnitude < 1e-6f ? 0f : Mathf.Atan2(position.x, position.y) * Mathf.Rad2Deg;

        // Unit vector from the avatar towards the light.
        internal Vector3 TowardsLight
        {
            get
            {
                float e = Elevation * Mathf.Deg2Rad, a = Azimuth * Mathf.Deg2Rad;
                return new Vector3(Mathf.Sin(a) * Mathf.Cos(e), Mathf.Sin(e), Mathf.Cos(a) * Mathf.Cos(e));
            }
        }

        internal int Kelvin => Mathf.RoundToInt(temperature < .5f ? Mathf.Lerp(2700f, 6500f, temperature * 2f) : Mathf.Lerp(6500f, 9000f, (temperature - .5f) * 2f));

        // Approximate black-body colour (Tanner Helland's fit), normalised so the brightest channel is 1.
        internal Color LightColor
        {
            get
            {
                float t = Kelvin / 100f;
                float r = t <= 66f ? 255f : 329.698727446f * Mathf.Pow(t - 60f, -0.1332047592f);
                float g = t <= 66f ? 99.4708025861f * Mathf.Log(t) - 161.1195681661f : 288.1221695283f * Mathf.Pow(t - 60f, -0.0755148492f);
                float b = t >= 66f ? 255f : t <= 19f ? 0f : 138.5177312231f * Mathf.Log(t - 10f) - 305.0447927307f;
                var c = new Color(Mathf.Clamp(r, 0f, 255f), Mathf.Clamp(g, 0f, 255f), Mathf.Clamp(b, 0f, 255f)) / 255f;
                float max = Mathf.Max(c.r, c.g, c.b, .001f);
                return new Color(c.r / max, c.g / max, c.b / max, 1f);
            }
        }
    }

    // One material control taken from a lighting package on the avatar, applied to the preview copies only.
    internal sealed class PoseDeckMaterialControl
    {
        public string Label, Group;
        public float Min, Max, Initial, Value;
        public bool Toggle;
        public (string Shader, string[] Names)[] Targets;

        internal float Normalized
        {
            get => Max > Min ? Mathf.InverseLerp(Min, Max, Value) : 0f;
            set => Value = Toggle ? (value >= .5f ? 1f : 0f) : Mathf.Lerp(Min, Max, Mathf.Clamp01(value));
        }

        internal string ValueText => Toggle ? (Value >= .5f ? "켜짐" : "꺼짐") : $"{Value:0.###}";
    }

    // Reads Light Limit Changer (io.github.azukimochi) by reflection, so Pose Deck does not depend on it.
    internal static class PoseDeckLightPackages
    {
        private const string Namespace = "io.github.azukimochi";
        internal const string LightLimitChanger = Namespace + ".LightLimitChangerComponent";

        private static readonly Dictionary<string, string> GeneralLabels = new Dictionary<string, string>
        {
            ["MinLight"] = "밝기 하한", ["MaxLight"] = "밝기 상한", ["Monochrome"] = "모노크롬", ["Unlit"] = "Unlit",
            ["EmissionStrength"] = "에미션 강도", ["ColorControlHue"] = "색조", ["ColorControlSaturation"] = "채도",
            ["ColorControlBrightness"] = "색 밝기", ["ColorControlGamma"] = "감마",
        };

        // LLC's own shader detection (lilToon: "lilToon"/"lts_pass"; Poiyomi and UnlitWF by name).
        internal static string ShaderKey(Shader shader)
        {
            var name = shader ? shader.name : "";
            if (name.Contains("lilToon") || name.Contains("lts_pass")) return "liltoon";
            if (name.IndexOf("poiyomi", StringComparison.OrdinalIgnoreCase) >= 0) return "poiyomi";
            if (name.IndexOf("unlitwf", StringComparison.OrdinalIgnoreCase) >= 0) return "unlitwf";
            if (name.IndexOf("sunao", StringComparison.OrdinalIgnoreCase) >= 0) return "sunao";
            return null;
        }

        internal static MonoBehaviour FindLightLimitChanger(GameObject avatar) => avatar
            ? avatar.GetComponentsInChildren<MonoBehaviour>(true).FirstOrDefault(c => c && c.GetType().FullName == LightLimitChanger)
            : null;

        // The animated float and toggle controls LLC adds to the avatar's menu, with their initial values and ranges.
        internal static List<PoseDeckMaterialControl> Detect(GameObject avatar, out string source)
        {
            var controls = new List<PoseDeckMaterialControl>();
            source = null;
            var component = FindLightLimitChanger(avatar);
            if (!component) return controls;
            source = "Light Limit Changer";
            try { Walk(component, true, "", 0, controls); }
            catch (Exception e) { source += " (일부를 읽지 못함: " + e.Message + ")"; }
            return controls;
        }

        private static bool IsParameter(Type type) =>
            type.IsGenericType && type.Namespace == Namespace && type.Name.StartsWith("Parameter`", StringComparison.Ordinal);

        private static void Walk(object node, bool enabled, string group, int depth, List<PoseDeckMaterialControl> controls)
        {
            foreach (var field in node.GetType().GetFields(BindingFlags.Public | BindingFlags.Instance))
            {
                object value;
                try { value = field.GetValue(node); }
                catch (Exception) { continue; }
                if (value == null || value is UnityEngine.Object) continue;
                var type = value.GetType();
                if (IsParameter(type))
                {
                    if (enabled) AddParameter(field, value, type, group, controls);
                    continue;
                }
                if (depth >= 6 || !type.IsClass || type.Namespace != Namespace || type.IsArray) continue;
                bool childEnabled = enabled;
                var enable = type.GetField("Enable", BindingFlags.Public | BindingFlags.Instance);
                if (enable?.FieldType == typeof(bool)) childEnabled &= (bool)enable.GetValue(value);
                Walk(value, childEnabled, group.Length == 0 ? field.Name : group + " › " + field.Name, depth + 1, controls);
            }
        }

        private static void AddParameter(FieldInfo field, object parameter, Type type, string group, List<PoseDeckMaterialControl> controls)
        {
            var arg = type.GetGenericArguments()[0];
            if (arg != typeof(float) && arg != typeof(bool)) return; // colours and vectors are not previewed
            bool Flag(string name) => type.GetField(name)?.GetValue(parameter) is bool b && b;
            if (!Flag("Enable") || !Flag("Animation")) return;
            var targets = field.GetCustomAttributes(true).Where(a => a.GetType().Name == "MaterialPropertyNameAttribute")
                .Select(a => ((string)a.GetType().GetProperty("Shader")?.GetValue(a), (string[])a.GetType().GetProperty("Names")?.GetValue(a)))
                .Where(t => t.Item1 != null && t.Item2 != null && t.Item2.Length > 0).ToArray();
            if (targets.Length == 0) return;
            bool toggle = arg == typeof(bool);
            var raw = type.GetField("Value")?.GetValue(parameter);
            float initial = toggle ? (raw is bool on && on ? 1f : 0f) : raw is float f ? f : 0f;
            var range = toggle ? new Vector2(0f, 1f) : type.GetField("MinMaxRange")?.GetValue(parameter) is Vector2 r ? r : new Vector2(0f, 1f);
            var general = field.GetCustomAttributes(true).FirstOrDefault(a => a.GetType().Name == "GeneralControlAttribute");
            string generalType = general?.GetType().GetProperty("Type")?.GetValue(general)?.ToString();
            // Light direction drives a vector override computed by LLC at build time; not previewed.
            if (generalType == "LightDirection" || generalType == "ColorTemperature") return;
            string kind = generalType != null && GeneralLabels.ContainsKey(generalType) ? generalType : null;
            string owner = group.Length == 0 ? "" : group.Substring(group.LastIndexOf('›') + 1).Trim();
            controls.Add(new PoseDeckMaterialControl
            {
                Label = kind != null ? GeneralLabels[kind] : owner.Length > 0 ? $"{owner} · {field.Name}" : field.Name,
                Group = kind != null ? "기본" : group,
                Min = Mathf.Min(range.x, range.y), Max = Mathf.Max(range.x, range.y),
                Initial = initial, Value = initial, Toggle = toggle, Targets = targets,
            });
        }
    }
}
