using System;
using System.Collections.Generic;
using UnityEditor.Animations;
using UnityEngine;
using VRC.SDK3.Avatars.ScriptableObjects;

namespace PersonalPoseDeck
{
    internal enum PoseCategory { Sit, Lie, Stand, Other }

    [Serializable]
    internal sealed class PoseEntry
    {
        public string label;
        public AnimationClip clip;
        public PoseCategory category;
        // Off keeps GoGoLoco's own start height for the slot (Go/Float 0.25 on a custom slot, the preset on a stock one).
        public bool overrideHeight;
        [Range(0f, 1f)] public float height = PoseDeckBuilder.DefaultStartHeight;
    }

    public sealed class PoseDeckPreset : ScriptableObject
    {
        [SerializeField] internal string menuTitle = "내 포즈";
        [SerializeField] internal bool keepStockMenu = true;
        // Put reset and height adjustment at the top of every category page, next to the poses.
        [SerializeField] internal bool controlsOnEveryPage = true;
        [SerializeField] internal List<PoseEntry> poses = new List<PoseEntry>();
        // Retained as-is to resolve scenes wired to results from 0.7.0 and earlier.
        [SerializeField, HideInInspector] internal AnimatorController stockBase = null;
        [SerializeField, HideInInspector] internal VRCExpressionsMenu stockMenu = null;
        [SerializeField, HideInInspector] internal AnimatorController appliedBase = null;
        [SerializeField, HideInInspector] internal VRCExpressionsMenu appliedMenu = null;
    }
}
