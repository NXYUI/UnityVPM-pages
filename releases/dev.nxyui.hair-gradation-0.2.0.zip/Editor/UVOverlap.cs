#if UNITY_EDITOR
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace NXYUI.HairGradation
{
    // Where two parts of a hair (or two places of one part) share a spot of their texture at different heights of the
    // gradient. TexTransTool paints such a spot once, so one of them gets the other's color. Each hair texture is drawn at
    // a low resolution with the gradient value of every texel.
    internal static class UVOverlap
    {
        internal sealed class Result
        {
            internal string Texture;
            // The share of the texture's painted area where the parts disagree.
            internal float Share;
            internal string Between;
        }

        private const int Size = 256;
        // Gradient values further apart than this look different.
        private const float Tolerance = 0.1f;
        // Smaller clashes are seams, not overlaps.
        private const float Smallest = 0.005f;

        internal static List<Result> Check(HairGradationSettings s, List<Renderer> parts)
        {
            var results = new List<Result>();
            var m = HairGradationBuilder.Measured(s, parts);
            if (!m.Valid) return results;
            foreach (var group in HairGradationBuilder.Groups(parts, new List<string>()))
            {
                var low = new float[Size * Size];
                var high = new float[Size * Size];
                var owner = Enumerable.Repeat(-1, Size * Size).ToArray();
                var clashed = new bool[Size * Size];
                var pairs = new Dictionary<(int, int), int>();
                int covered = 0, clashes = 0;
                for (int r = 0; r < group.Renderers.Count; r++)
                {
                    var renderer = group.Renderers[r];
                    var mesh = HairGradationBuilder.MeshOf(renderer);
                    var uv = mesh ? mesh.uv : null;
                    if (uv == null || uv.Length == 0) continue;
                    var (vertices, toWorld) = HairGradationBuilder.Posed(renderer);
                    if (vertices.Length != uv.Length) continue;
                    var at = new float[vertices.Length];
                    for (int i = 0; i < vertices.Length; i++) at[i] = HairGradationBuilder.GradientAt(s, m, toWorld.MultiplyPoint3x4(vertices[i]));
                    var materials = renderer.sharedMaterials;
                    for (int sub = 0; sub < mesh.subMeshCount && sub < materials.Length; sub++)
                    {
                        if (!group.Materials.Contains(materials[sub])) continue;
                        var triangles = mesh.GetTriangles(sub);
                        for (int i = 0; i + 2 < triangles.Length; i += 3)
                        {
                            int a = triangles[i], b = triangles[i + 1], c = triangles[i + 2];
                            Raster(uv[a], uv[b], uv[c], at[a], at[b], at[c], (texel, value) =>
                            {
                                if (owner[texel] < 0)
                                {
                                    owner[texel] = r;
                                    low[texel] = high[texel] = value;
                                    covered++;
                                    return;
                                }
                                low[texel] = Mathf.Min(low[texel], value);
                                high[texel] = Mathf.Max(high[texel], value);
                                if (clashed[texel] || high[texel] - low[texel] <= Tolerance) return;
                                clashed[texel] = true;
                                clashes++;
                                var key = (Mathf.Min(owner[texel], r), Mathf.Max(owner[texel], r));
                                pairs[key] = pairs.TryGetValue(key, out int n) ? n + 1 : 1;
                            });
                        }
                    }
                }
                if (covered == 0 || clashes / (float)covered < Smallest) continue;
                string Name(int i) => $"‘{group.Renderers[i].name}’";
                results.Add(new Result
                {
                    Texture = group.Texture.name,
                    Share = clashes / (float)covered,
                    Between = string.Join(", ", pairs.OrderByDescending(p => p.Value).Take(3)
                        .Select(p => p.Key.Item1 == p.Key.Item2 ? Name(p.Key.Item1) + " 안에서" : $"{Name(p.Key.Item1)} ↔ {Name(p.Key.Item2)}")),
                });
            }
            return results;
        }

        // Visits the texels whose centers a UV triangle covers, with the gradient value there. Like TexTransTool, only the
        // part inside the texture (UV 0 to 1) counts; a triangle outside it paints nothing. Also like it, the corners'
        // values are interpolated as they are and each texel is clamped to the range after: clamped first, a triangle
        // that reaches above the start would read the same as one that starts at it.
        private static void Raster(Vector2 a, Vector2 b, Vector2 c, float ta, float tb, float tc, System.Action<int, float> visit)
        {
            a *= Size;
            b *= Size;
            c *= Size;
            float area = (b.x - a.x) * (c.y - a.y) - (c.x - a.x) * (b.y - a.y);
            if (Mathf.Abs(area) < 1e-8f) return;
            int x0 = Mathf.Max(0, Mathf.FloorToInt(Mathf.Min(a.x, Mathf.Min(b.x, c.x))));
            int x1 = Mathf.Min(Size - 1, Mathf.CeilToInt(Mathf.Max(a.x, Mathf.Max(b.x, c.x))));
            int y0 = Mathf.Max(0, Mathf.FloorToInt(Mathf.Min(a.y, Mathf.Min(b.y, c.y))));
            int y1 = Mathf.Min(Size - 1, Mathf.CeilToInt(Mathf.Max(a.y, Mathf.Max(b.y, c.y))));
            for (int y = y0; y <= y1; y++)
                for (int x = x0; x <= x1; x++)
                {
                    float px = x + 0.5f, py = y + 0.5f;
                    float wa = ((b.x - px) * (c.y - py) - (c.x - px) * (b.y - py)) / area;
                    float wb = ((c.x - px) * (a.y - py) - (a.x - px) * (c.y - py)) / area;
                    float wc = 1f - wa - wb;
                    if (wa < 0f || wb < 0f || wc < 0f) continue;
                    visit(y * Size + x, Mathf.Clamp01(wa * ta + wb * tb + wc * tc));
                }
        }
    }
}
#endif
