#if UNITY_EDITOR
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace NXYUI.HairGradation
{
    [CustomEditor(typeof(HairGradationSettings))]
    internal sealed class HairGradationEditor : Editor
    {
        private static readonly string[] Outputs = { "메인 텍스처에 합치기", "lilToon 메인 컬러 2nd", "lilToon 메인 컬러 3rd" };

        private bool partsOpen = true;
        private List<string> problems;
        // What the last press of the build button made, said below it while that setup stands.
        private string built;
        private List<UVOverlap.Result> overlaps;
        // Why the UV check had nothing to look at, or null.
        private string overlapNote;
        // The hair measured for the structure it was measured with.
        private HairGradationBuilder.Measure measure;
        private string measuredFor;
        // Whether the generated decals sit where that measure puts them, for the range they were compared with.
        private bool placed = true;
        private string placedFor;

        private GUIStyle wrappedBold;
        private GUIStyle WrappedBold => wrappedBold ??= new GUIStyle(EditorStyles.boldLabel) { wordWrap = true };

        // Undo and Redo move the generated objects without anything the comparison is kept for changing.
        private void OnEnable() => Undo.undoRedoPerformed += Forget;
        private void OnDisable() => Undo.undoRedoPerformed -= Forget;
        private void Forget() => placedFor = null;

        public override void OnInspectorGUI()
        {
            var s = (HairGradationSettings)target;
            serializedObject.Update();
            EditorGUILayout.LabelField("헤어 하나에 그라데이션 하나", WrappedBold);
            EditorGUILayout.LabelField("이 오브젝트 아래의 켜진 헤어 메시를 모아, 파츠가 나뉘어 있어도 높이에 따라 이어지는 그라데이션을 만들어요. " +
                                       "TexTransTool이 빌드할 때 적용하고, 원본 텍스처는 바뀌지 않아요.", EditorStyles.wordWrappedMiniLabel);
            DrawWhere(s);
            EditorGUILayout.Space(6);

            DrawParts(s);
            EditorGUILayout.Space(6);
            bool lilToon = s.output != GradationOutput.MainTexture;

            EditorGUILayout.LabelField("그라데이션", EditorStyles.boldLabel);
            EditorGUILayout.PropertyField(serializedObject.FindProperty("gradient"), new GUIContent("색", "왼쪽이 시작(위), 오른쪽이 끝(아래)이에요. 알파로 서서히 나타나게 할 수 있어요."));
            EditorGUILayout.Slider(serializedObject.FindProperty("opacity"), 0f, 1f, new GUIContent("불투명도"));
            Blend(serializedObject.FindProperty("blend"), "섞는 방식", lilToon);
            var start = serializedObject.FindProperty("start");
            var end = serializedObject.FindProperty("end");
            float from = start.floatValue, to = end.floatValue;
            using (new EditorGUILayout.HorizontalScope())
            {
                EditorGUILayout.PrefixLabel(new GUIContent("범위", "헤어의 맨 위(0)부터 가장 아래 끝(1)까지 중 그라데이션이 펼쳐지는 구간이에요. 범위 밖은 양 끝 색이 이어져요."));
                GUILayout.Label("위", EditorStyles.miniLabel, GUILayout.ExpandWidth(false));
                EditorGUILayout.MinMaxSlider(ref from, ref to, 0f, 1f);
                GUILayout.Label("아래", EditorStyles.miniLabel, GUILayout.ExpandWidth(false));
            }
            if (!Mathf.Approximately(from, start.floatValue) || !Mathf.Approximately(to, end.floatValue))
            {
                // The end stays below the start, and both inside the hair (0 to 1).
                start.floatValue = Mathf.Min(from, 0.99f);
                end.floatValue = Mathf.Clamp(to, start.floatValue + 0.01f, 1f);
            }
            EditorGUILayout.LabelField($"시작 {start.floatValue * 100f:0}% · 끝 {end.floatValue * 100f:0}%", EditorStyles.miniLabel);
            EditorGUILayout.Space(6);

            EditorGUILayout.LabelField("패턴 (선택)", EditorStyles.boldLabel);
            EditorGUILayout.PropertyField(serializedObject.FindProperty("pattern"), new GUIContent("텍스처", "앞에서 헤어 전체에 투영해요. 비워 두면 그라데이션만 넣어요."));
            if (s.pattern)
            {
                EditorGUILayout.PropertyField(serializedObject.FindProperty("patternColor"), new GUIContent("색"));
                EditorGUILayout.Slider(serializedObject.FindProperty("patternOpacity"), 0f, 1f, new GUIContent("불투명도"));
                EditorGUILayout.IntSlider(serializedObject.FindProperty("patternRepeat"), 1, 16, new GUIContent("반복", "헤어 전체의 가로로 패턴이 몇 번 반복되는지예요. 세로는 패턴 이미지의 비율에 맞춰 반복돼요."));
                EditorGUILayout.PropertyField(serializedObject.FindProperty("patternInsideGradient"), new GUIContent("그라데이션 안에만", "켜면 그라데이션이 보이는 곳에만 패턴이 나와요. 패턴은 그라데이션과 한 묶음이 되어 그라데이션의 섞는 방식으로 섞여요."));
                EditorGUILayout.PropertyField(serializedObject.FindProperty("patternOnBack"), new GUIContent("뒤쪽에도", "켜면 앞에서 투영한 패턴이 뒷머리에도 들어가요."));
                Blend(serializedObject.FindProperty("patternBlend"), "섞는 방식", false);
                EditorGUILayout.LabelField("패턴은 앞에서 평행하게 투영해서, 옆머리에서는 늘어나 보일 수 있어요.", EditorStyles.wordWrappedMiniLabel);
                if (HairGradationBuilder.Skewed(s))
                    EditorGUILayout.HelpBox("⚠ 이 헤어의 부모 중에 축마다 크기가 다른(비균일) 스케일 안에서 회전한 오브젝트가 있어서, 패턴이 조금 비스듬하게 들어갈 수 있어요. " +
                                            "그라데이션은 정확히 들어가요. 패턴도 맞추려면 부모 오브젝트들의 스케일을 X·Y·Z 같은 값으로 맞춰 주세요.", MessageType.Warning);
            }
            EditorGUILayout.Space(6);

            EditorGUILayout.LabelField("결과", EditorStyles.boldLabel);
            var output = serializedObject.FindProperty("output");
            output.enumValueIndex = EditorGUILayout.Popup(new GUIContent("넣을 곳",
                "메인 텍스처: 빌드할 때 텍스처를 새로 만들어 바꿔요. lilToon 2nd/3rd: 메인 텍스처는 두고 그 칸에 그라데이션을 넣어요."), output.enumValueIndex, Outputs);
            if (lilToon)
                EditorGUILayout.LabelField("lilToon 머티리얼에만 들어가요(lilToonLite 제외). 그 칸에 이미 넣어 둔 텍스처와 설정은 빌드에서 그라데이션으로 바뀌어요.", EditorStyles.wordWrappedMiniLabel);
            EditorGUILayout.Slider(serializedObject.FindProperty("padding"), 0f, 32f, new GUIContent("여백", "UV 섬 가장자리 밖으로 칠하는 픽셀 수예요. 이음매가 비치면 늘리세요."));
            bool changed = serializedObject.ApplyModifiedProperties();
            // Before the state below is drawn, so that it tells what is true after this edit.
            if (changed && HairGradationBuilder.Current(s))
            {
                HairGradationBuilder.Sync(s, MeasureOf(s));
                placedFor = null;
            }
            EditorGUILayout.Space(8);

            DrawBuild(s);
        }

        // Measured again when the parts change, move or change shape.
        private HairGradationBuilder.Measure MeasureOf(HairGradationSettings s)
        {
            var included = HairGradationBuilder.Included(s);
            string key = HairGradationBuilder.Structure(s) + "|" + HairGradationBuilder.Placement(included);
            if (measuredFor != key)
            {
                measure = HairGradationBuilder.Measured(s, included);
                measuredFor = key;
            }
            return measure;
        }

        // Whether the generated decals sit where the hair is now. Compared again only when the hair or the range
        // changes: measuring walks every vertex of the hair.
        private bool Placed(HairGradationSettings s)
        {
            var m = MeasureOf(s);
            string key = measuredFor + "|" + s.start + "|" + s.end;
            if (placedFor != key)
            {
                placed = HairGradationBuilder.Placed(s, m);
                placedFor = key;
            }
            return placed;
        }

        // Says so when the component does not sit on a hair inside an avatar.
        private static void DrawWhere(HairGradationSettings s)
        {
            if (!HairGradationBuilder.InAvatar(s))
                EditorGUILayout.HelpBox("이 오브젝트는 아바타(VRC Avatar Descriptor) 아래에 있지 않아요. 그라데이션은 아바타를 빌드할 때 들어가니, 헤어가 아바타 안에 있어야 결과가 보여요.", MessageType.Info);
            else if (HairGradationBuilder.AvatarRoot(s) == s.transform)
                EditorGUILayout.HelpBox("아바타 루트에 붙어 있어서 아바타의 모든 메시가 아래 목록에 나와요. 헤어의 루트 오브젝트에 붙이면 헤어만 나와요.", MessageType.Info);
        }

        private void DrawParts(HairGradationSettings s)
        {
            var parts = HairGradationBuilder.Parts(s);
            int included = parts.Count(p => p.Included);
            bool open = EditorGUILayout.Foldout(partsOpen, $"칠할 메시 {included}/{parts.Count}개", true);
            if (open != partsOpen)
            {
                // The list below appears or goes in the middle of the click: the pass ends, the next one draws it.
                partsOpen = open;
                GUIUtility.ExitGUI();
            }
            if (!partsOpen) return;
            if (parts.Count == 0)
            {
                EditorGUILayout.HelpBox("이 오브젝트 아래에 메시가 없어요. 헤어의 루트 오브젝트에 붙여 주세요.", MessageType.Info);
                return;
            }
            foreach (var part in parts)
                using (new EditorGUILayout.HorizontalScope())
                using (new EditorGUI.DisabledScope(part.Blocked != null))
                {
                    // A long name is cut by the Inspector's width: the tooltip has all of it.
                    bool next = EditorGUILayout.ToggleLeft(new GUIContent(part.Renderer.name, part.Renderer.name + "\n" + (part.Blocked ?? "끄면 이 메시는 칠하지 않아요.")), part.Included);
                    if (part.Blocked != null) GUILayout.Label(part.Blocked, EditorStyles.miniLabel, GUILayout.ExpandWidth(false));
                    if (next == part.Included || part.Blocked != null) continue;
                    Undo.RecordObject(s, "Hair Gradation parts");
                    if (next) s.excluded.Remove(part.Renderer);
                    else if (!s.excluded.Contains(part.Renderer)) s.excluded.Add(part.Renderer);
                    s.excluded.RemoveAll(r => !r);
                    HairGradationBuilder.Keep(s);
                    // What is drawn below (the count, the setup's state, the build button) follows the parts.
                    GUIUtility.ExitGUI();
                }
            EditorGUILayout.LabelField("악세서리처럼 칠하지 않을 메시는 체크를 끄세요. 꺼진 오브젝트는 들어가지 않아요.", EditorStyles.wordWrappedMiniLabel);
            if (included == 0)
                EditorGUILayout.HelpBox("칠할 메시가 하나도 없어요. 메시를 하나 이상 체크하거나, 꺼져 있는 헤어를 켜 주세요.", MessageType.Info);
        }

        private static void Blend(SerializedProperty property, string label, bool lilToon)
        {
            var blends = HairGradationBuilder.Blends.Take(lilToon ? HairGradationBuilder.LilToonBlends : HairGradationBuilder.Blends.Length).ToArray();
            int index = System.Array.FindIndex(blends, b => b.Key == property.stringValue);
            EditorGUI.BeginChangeCheck();
            int next = EditorGUILayout.Popup(label, Mathf.Max(0, index), blends.Select(b => b.Label).ToArray());
            // Written only when the user picks. A mode this list does not have stays stored and is back when the output
            // that has it is chosen again; written on every pass it changed the setting unasked and ate each Undo.
            if (EditorGUI.EndChangeCheck()) property.stringValue = blends[next].Key;
            if (index >= 0) return;
            string chosen = HairGradationBuilder.Blends.FirstOrDefault(b => b.Key == property.stringValue).Label ?? property.stringValue;
            EditorGUILayout.LabelField(lilToon
                ? $"lilToon 2nd/3rd 컬러는 보통·더하기·스크린·곱하기로만 섞을 수 있어요. 골라 둔 ‘{chosen}’ 대신 ‘보통’으로 섞어요."
                : $"‘{chosen}’은(는) 여기서 쓸 수 없는 방식이라 ‘보통’으로 섞어요.", EditorStyles.wordWrappedMiniLabel);
        }

        private void DrawBuild(HairGradationSettings s)
        {
            EditorGUILayout.LabelField("TexTransTool 구성", EditorStyles.boldLabel);
            var made = HairGradationBuilder.Made(s);
            bool own = HairGradationBuilder.Own(s);
            bool active = s.gameObject.activeInHierarchy;
            int parts = HairGradationBuilder.Included(s).Count;
            string outdated = own ? HairGradationBuilder.Outdated(s) : null;
            if (!active)
                EditorGUILayout.HelpBox("⚠ 이 헤어가 꺼져 있어요(부모 오브젝트나 아바타가 꺼져 있어도 같아요). 켜야 구성을 만들거나 고칠 수 있어요. " +
                                        "헤어를 꺼 둔 채 업로드하면 TexTransTool이 그 아래의 구성을 건너뛰어 그라데이션이 들어가지 않아요.", MessageType.Warning);
            else if (!own && s.generated)
                EditorGUILayout.HelpBox("⚠ 이 설정이 가리키는 구성이 이 오브젝트 아래에 없어요. 다른 헤어의 설정을 붙여 넣었거나 만든 오브젝트를 옮긴 경우예요. " +
                                        "‘구성 만들기’를 누르면 여기에 새로 만들고, 가리키던 구성은 건드리지 않아요.", MessageType.Warning);
            else if (!own && made.Count > 0)
                EditorGUILayout.HelpBox($"⚠ 예전에 만든 ‘{HairGradationBuilder.ContainerName}’이 이 오브젝트 아래에 남아 있어요. 지금 설정과 이어져 있지 않지만 빌드에는 그대로 적용돼요. " +
                                        "‘구성 다시 만들기’를 누르면 지금 설정으로 바꿔요.", MessageType.Warning);
            else if (!own)
                EditorGUILayout.HelpBox("아직 구성이 없어요. ‘구성 만들기’를 누르면 이 오브젝트 아래에 TexTransTool 컴포넌트를 만들어요.", MessageType.Info);
            else if (outdated != null)
                EditorGUILayout.HelpBox("⚠ " + outdated, MessageType.Warning);
            else if (!Placed(s))
                EditorGUILayout.HelpBox("⚠ 헤어의 모양이나 위치가 구성을 만든 뒤에 달라졌어요(블렌드셰이프, 파츠 이동 등). 그라데이션 범위가 지금 헤어와 어긋나 있어요. " +
                                        "‘구성 다시 만들기’를 눌러 다시 맞춰 주세요.", MessageType.Warning);
            else
                EditorGUILayout.LabelField("구성이 최신이에요. 색과 범위는 바꾸는 즉시 반영돼요. 만든 오브젝트는 직접 고치지 마세요.", EditorStyles.wordWrappedMiniLabel);
            using (new EditorGUILayout.HorizontalScope())
            {
                // Off while the hair is off (the box above says why) or no mesh is checked (the line below says why):
                // there would be nothing to paint. Making it again never takes a setup away; ‘구성 지우기’ does that.
                using (new EditorGUI.DisabledScope(!active || parts == 0))
                    if (GUILayout.Button(made.Count > 0 ? "구성 다시 만들기" : "구성 만들기"))
                    {
                        problems = HairGradationBuilder.Rebuild(s);
                        // Where the preview is switched on, for when nothing changes in the Scene view: NDMF's own menu,
                        // and in its preview settings TexTransTool's phases (canvases and material changes).
                        built = HairGradationBuilder.Own(s)
                            ? $"구성을 만들었어요(칠할 메시 {parts}개)." + (problems.Count > 0 ? " 아래 내용을 확인해 주세요." : "") +
                              "\nScene 뷰에 바뀐 게 없으면 상단 메뉴 Tools › NDM Framework › Enable Previews가 체크되어 있는지, " +
                              "Tools › NDM Framework › Configure Previews의 TexTransTool에서 BeforeUVModification-Phase와 MaterialModification-Phase가 켜져 있는지 확인해 주세요."
                            : null;
                        measuredFor = placedFor = null;
                        overlaps = null;
                        overlapNote = null;
                        GUIUtility.ExitGUI();
                    }
                // The check is the smaller of the two: making the setup is what this section is for.
                if (GUILayout.Button(new GUIContent("UV 겹침 확인", "파츠들이 텍스처의 같은 곳을 다른 높이에서 쓰는지 봐요."), GUILayout.Width(110f)))
                {
                    var included = HairGradationBuilder.Included(s);
                    overlaps = included.Count > 0 ? UVOverlap.Check(s, included) : null;
                    overlapNote = included.Count > 0 ? null : "칠할 메시가 없어서 UV 겹침을 확인하지 못했어요. 위 목록에서 메시를 체크해 주세요.";
                    GUIUtility.ExitGUI();
                }
            }
            if (active && parts == 0)
                EditorGUILayout.LabelField("칠할 메시가 없어서 구성을 만들 수 없어요. 위 ‘칠할 메시’에서 메시를 하나 이상 체크해 주세요." +
                                           (made.Count > 0 ? " 있던 구성은 그대로 빌드에 들어가요. 빼려면 아래 ‘구성 지우기’를 누르세요." : ""), EditorStyles.wordWrappedMiniLabel);
            if (built != null && own && outdated == null) EditorGUILayout.HelpBox(built, MessageType.Info);
            if (problems != null)
                foreach (var problem in problems) EditorGUILayout.HelpBox("⚠ " + problem, MessageType.Warning);
            if (overlapNote != null) EditorGUILayout.HelpBox(overlapNote, MessageType.Info);
            if (overlaps != null)
            {
                if (overlaps.Count == 0) EditorGUILayout.HelpBox("UV가 다른 높이에서 겹치는 곳이 없어요.", MessageType.Info);
                foreach (var o in overlaps)
                    EditorGUILayout.HelpBox($"⚠ ‘{o.Texture}’: 칠하는 곳의 {o.Share * 100f:0.#}%에서 높이가 다른 부분이 텍스처의 같은 곳을 써요 ({o.Between}). " +
                                            "그 자리는 한쪽 높이로만 칠해져 색이 어긋나요. 한쪽 파츠의 머티리얼과 텍스처를 복제해서 따로 쓰세요.", MessageType.Warning);
            }
            EditorGUILayout.LabelField("Scene 뷰의 NDMF 미리보기가 켜져 있으면 결과가 바로 보여요(상단 메뉴 Tools › NDM Framework › Enable Previews).", EditorStyles.wordWrappedMiniLabel);
            if (made.Count == 0) return;

            // Apart from the buttons above: it takes away what they make. Undo brings it back, so it asks nothing.
            EditorGUILayout.Space(8);
            EditorGUILayout.LabelField("그라데이션을 빼려면 구성을 지우세요. 이 컴포넌트만 지우면 만든 오브젝트가 남아서 빌드에 계속 적용돼요.", EditorStyles.wordWrappedMiniLabel);
            using (new EditorGUILayout.HorizontalScope())
            {
                GUILayout.FlexibleSpace();
                if (GUILayout.Button(new GUIContent("구성 지우기", $"이 도구가 만든 ‘{HairGradationBuilder.ContainerName}’ 오브젝트를 지워요. Ctrl+Z로 되돌릴 수 있어요."), EditorStyles.miniButton, GUILayout.Width(90f)))
                {
                    HairGradationBuilder.Remove(s);
                    problems = null;
                    built = null;
                    overlaps = null;
                    overlapNote = null;
                    measuredFor = placedFor = null;
                    GUIUtility.ExitGUI();
                }
            }
        }
    }

    internal static class HairGradationMenu
    {
        [MenuItem("NXYUI/Hair Gradation")]
        private static void Add() => AddTo(Selection.activeGameObject);

        [MenuItem("GameObject/NXYUI/Hair Gradation", false, 20)]
        private static void AddFromHierarchy(MenuCommand command) => AddTo(command.context as GameObject ? (GameObject)command.context : Selection.activeGameObject);

        private static void AddTo(GameObject go)
        {
            if (!go || EditorUtility.IsPersistent(go))
            {
                EditorUtility.DisplayDialog("Hair Gradation", "Hierarchy에서 헤어의 루트 오브젝트를 먼저 골라 주세요.", "확인");
                return;
            }
            if (!go.TryGetComponent<HairGradationSettings>(out _)) Undo.AddComponent<HairGradationSettings>(go);
            Selection.activeGameObject = go;
        }
    }
}
#endif
