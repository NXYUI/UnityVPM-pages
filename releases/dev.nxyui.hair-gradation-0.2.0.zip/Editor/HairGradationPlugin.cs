#if UNITY_EDITOR
using System.Collections.Generic;
using System.Linq;
using nadena.dev.ndmf;
using net.rs64.TexTransTool;
using UnityEngine;

[assembly: ExportsPlugin(typeof(NXYUI.HairGradation.HairGradationPlugin))]

namespace NXYUI.HairGradation
{
    // lilToonMulti draws its 2nd and 3rd colors only while a shader keyword is on, and lilToon's own inspector turns that
    // keyword on and off with the color's switch. TexTransTool's MaterialModifier turns the switch on in its copy of the
    // material but never touches keywords, so on a lilToonMulti material whose 2nd (3rd) color was off the gradient would
    // not show. After TexTransTool this turns the keyword on in those copies, as lilToon's inspector would.
    [RunsOnAllPlatforms]
    internal sealed class HairGradationPlugin : Plugin<HairGradationPlugin>
    {
        public override string QualifiedName => "dev.nxyui.hair-gradation";
        public override string DisplayName => "Hair Gradation";

        protected override void Configure()
        {
            // TexTransTool changes materials in its Transforming passes and removes its components only in Optimizing,
            // so the setups are still there to read.
            InPhase(BuildPhase.Transforming).AfterPlugin("net.rs64.tex-trans-tool").Run("Turn on lilToonMulti 2nd/3rd color", Run);
        }

        internal static void Run(BuildContext context)
        {
            // The materials the setups in the avatar give a 2nd or 3rd color, with that color's switch and keyword.
            var changed = new List<(Material Target, string Use, string Keyword)>();
            foreach (var s in context.AvatarRootObject.GetComponentsInChildren<HairGradationSettings>(true))
            {
                if (!HairGradationBuilder.Own(s)) continue;
                foreach (var modifier in s.generated.GetComponentsInChildren<MaterialModifier>(true))
                    foreach (string slot in new[] { "2nd", "3rd" })
                        if (modifier.TargetMaterial && modifier.OverrideProperties.Any(p => p.PropertyName == $"_UseMain{slot}Tex"))
                            changed.Add((modifier.TargetMaterial, $"_UseMain{slot}Tex", HairGradationBuilder.Keyword(slot)));
            }
            if (changed.Count == 0) return;
            foreach (var renderer in context.AvatarRootObject.GetComponentsInChildren<Renderer>(true))
                foreach (var material in renderer.sharedMaterials)
                {
                    // Only copies made in this build: a material asset of the user's is never changed.
                    if (!material || !context.IsTemporaryAsset(material) || !HairGradationBuilder.IsMulti(material)) continue;
                    var origin = ObjectRegistry.GetReference(material);
                    foreach (var (target, use, keyword) in changed)
                        if (origin.Equals(ObjectRegistry.GetReference(target)) && material.HasProperty(use) && material.GetFloat(use) != 0f)
                            material.EnableKeyword(keyword);
                }
        }
    }
}
#endif
