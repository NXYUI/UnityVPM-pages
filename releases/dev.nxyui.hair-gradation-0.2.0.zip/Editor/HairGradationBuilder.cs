#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using net.rs64.TexTransTool;
using net.rs64.TexTransTool.Decal;
using net.rs64.TexTransTool.IslandSelector;
using net.rs64.TexTransTool.MultiLayerImage;
using UnityEditor;
using UnityEngine;
using VRC.SDK3.Avatars.Components;
using Object = UnityEngine.Object;
using TTTPropertyName = net.rs64.TexTransTool.PropertyName;
using MaterialProperty = net.rs64.TexTransTool.MaterialProperty;

namespace NXYUI.HairGradation
{
    // Turns HairGradationSettings into TexTransTool components below the settings object. Each hair texture gets a
    // canvas: the original (main texture only), above it a folder with the gradient and the pattern clipped to it, and
    // the pattern once more on top for when it is not kept inside the gradient. Into the main texture the folder and the
    // top pattern are clipped to the original, so the texture keeps its own alpha. Into lilToon's 2nd or 3rd color, a
    // MaterialModifier gives each material a blank texture of its own there, which the canvas paints.
    // The gradient runs along the avatar's down axis by 3D height, so it continues across parts.
    internal static class HairGradationBuilder
    {
        internal const string ContainerName = "[TTT] Hair Gradation";
        internal const string AssetRoot = "Assets/NXYUI/Hair Gradation";
        private const string MainTex = "_MainTex";

        // Blend modes offered, by TexTransTool key, with Korean labels. lilToon's 2nd/3rd colors have only the first four.
        internal static readonly (string Key, string Label)[] Blends =
        {
            ("Normal", "보통"), ("Addition", "더하기"), ("Screen", "스크린"), ("Mul", "곱하기"), ("Overlay", "오버레이"),
            ("SoftLight", "소프트 라이트"), ("HardLight", "하드 라이트"), ("Color", "색상"), ("Luminosity", "밝기"),
        };
        internal const int LilToonBlends = 4;

        // ---- what takes part ---------------------------------------------------------------------------------------

        internal sealed class Part
        {
            internal Renderer Renderer;
            internal bool Included;
            // Why a renderer cannot take part (off, no mesh), or null.
            internal string Blocked;
        }

        // Every mesh renderer below the hair root, and whether it takes part.
        internal static List<Part> Parts(HairGradationSettings s)
        {
            var parts = new List<Part>();
            foreach (var renderer in s.GetComponentsInChildren<Renderer>(true))
            {
                if (!(renderer is SkinnedMeshRenderer) && !(renderer is MeshRenderer)) continue;
                string blocked = null;
                if (!MeshOf(renderer)) blocked = "메시 없음";
                else if (!renderer.gameObject.activeInHierarchy || !renderer.enabled) blocked = "꺼져 있음";
                parts.Add(new Part { Renderer = renderer, Blocked = blocked, Included = blocked == null && !s.excluded.Contains(renderer) });
            }
            return parts;
        }

        internal static List<Renderer> Included(HairGradationSettings s) => Parts(s).Where(p => p.Included).Select(p => p.Renderer).ToList();

        internal static Mesh MeshOf(Renderer renderer) =>
            renderer is SkinnedMeshRenderer skinned ? skinned.sharedMesh :
            renderer.TryGetComponent<MeshFilter>(out var filter) ? filter.sharedMesh : null;

        // A hair texture and the materials (of the parts) that show it.
        internal sealed class Group
        {
            internal Texture2D Texture;
            internal readonly List<Material> Materials = new List<Material>();
            internal readonly List<Renderer> Renderers = new List<Renderer>();
        }

        internal static List<Group> Groups(IEnumerable<Renderer> renderers, List<string> problems)
        {
            var groups = new Dictionary<Texture2D, Group>();
            foreach (var renderer in renderers)
            {
                var mesh = MeshOf(renderer);
                var materials = renderer.sharedMaterials;
                for (int i = 0; i < Math.Min(materials.Length, mesh ? mesh.subMeshCount : 0); i++)
                {
                    var material = materials[i];
                    if (!material) continue;
                    var texture = material.HasProperty(MainTex) ? material.GetTexture(MainTex) as Texture2D : null;
                    if (!texture)
                    {
                        string note = $"‘{material.name}’에 메인 텍스처가 없어 건너뛰어요.";
                        if (!problems.Contains(note)) problems.Add(note);
                        continue;
                    }
                    if (!groups.TryGetValue(texture, out var group)) groups[texture] = group = new Group { Texture = texture };
                    if (!group.Materials.Contains(material)) group.Materials.Add(material);
                    if (!group.Renderers.Contains(renderer)) group.Renderers.Add(renderer);
                }
            }
            return groups.Values.OrderBy(g => g.Texture.name).ToList();
        }

        internal static bool IsLilToon(Material material) =>
            material.shader && material.shader.name.IndexOf("lilToon", StringComparison.OrdinalIgnoreCase) >= 0;

        // "2nd" or "3rd": the lilToon color the gradient goes into, or null for the main texture.
        internal static string Slot(HairGradationSettings s) =>
            s.output == GradationOutput.LilToonMain2nd ? "2nd" : s.output == GradationOutput.LilToonMain3rd ? "3rd" : null;

        // Whether a material shows lilToon's 2nd or 3rd color. Being lilToon by name is not enough: lilToonLite and
        // FakeShadow have no such color, and the gem and fur-only shaders declare it without ever drawing it.
        internal static bool HasSlot(Material material, string slot)
        {
            if (!material || !IsLilToon(material)) return false;
            string shader = material.shader.name;
            return material.HasProperty($"_UseMain{slot}Tex") && material.HasProperty($"_Main{slot}Tex") &&
                   shader.IndexOf("Gem", StringComparison.Ordinal) < 0 && shader.IndexOf("FurOnly", StringComparison.Ordinal) < 0;
        }

        // lilToonMulti and its variants (lilToon's own test: "Multi" after the last slash of the shader name). They draw a
        // color only while its shader keyword is on, which lilToon's inspector sets from the color's switch.
        internal static bool IsMulti(Material material)
        {
            if (!material || !IsLilToon(material)) return false;
            string shader = material.shader.name;
            int slash = shader.LastIndexOf('/');
            return slash >= 0 && shader.IndexOf("Multi", slash + 1, StringComparison.Ordinal) >= 0;
        }

        // The keyword lilToonMulti draws the 2nd or 3rd color with (lil_replace_keywords.hlsl).
        internal static string Keyword(string slot) => slot == "3rd" ? "_COLORCOLOR_ON" : "_COLORADDSUBDIFF_ON";

        internal static bool InAvatar(Component c) => c.GetComponentInParent<VRCAvatarDescriptor>(true);

        // ---- where the hair is -------------------------------------------------------------------------------------

        // The hair measured along the avatar's own axes (right, up, forward), from the meshes as they are posed.
        internal struct Measure
        {
            internal Vector3 Right, Up, Forward;
            internal Vector2 R, U, F; // (min, max) along each axis
            internal bool Valid;
            internal float Height => U.y - U.x;
        }

        internal static Transform AvatarRoot(Component c)
        {
            var descriptor = c.GetComponentInParent<VRCAvatarDescriptor>(true);
            return descriptor ? descriptor.transform : c.transform.root;
        }

        internal static Measure Measured(HairGradationSettings s, IEnumerable<Renderer> renderers)
        {
            var root = AvatarRoot(s);
            var m = new Measure
            {
                Up = root.up, Forward = root.forward, Right = root.right,
                R = new Vector2(float.MaxValue, float.MinValue), U = new Vector2(float.MaxValue, float.MinValue), F = new Vector2(float.MaxValue, float.MinValue),
            };
            void Add(Vector3 p)
            {
                float r = Vector3.Dot(p, m.Right), u = Vector3.Dot(p, m.Up), f = Vector3.Dot(p, m.Forward);
                m.R = new Vector2(Mathf.Min(m.R.x, r), Mathf.Max(m.R.y, r));
                m.U = new Vector2(Mathf.Min(m.U.x, u), Mathf.Max(m.U.y, u));
                m.F = new Vector2(Mathf.Min(m.F.x, f), Mathf.Max(m.F.y, f));
                m.Valid = true;
            }
            foreach (var p in renderers.SelectMany(WorldVertices)) Add(p);
            return m;
        }

        // The vertices of a renderer in the world, as posed now.
        internal static IEnumerable<Vector3> WorldVertices(Renderer renderer)
        {
            var (vertices, toWorld) = Posed(renderer);
            foreach (var v in vertices) yield return toWorld.MultiplyPoint3x4(v);
        }

        internal static (Vector3[] Vertices, Matrix4x4 ToWorld) Posed(Renderer renderer)
        {
            if (renderer is SkinnedMeshRenderer skinned)
            {
                var baked = new Mesh();
                try
                {
                    // The renderer's scale baked in, so only its place and turn are left.
                    skinned.BakeMesh(baked, true);
                    return (baked.vertices, Matrix4x4.TRS(skinned.transform.position, skinned.transform.rotation, Vector3.one));
                }
                finally { Object.DestroyImmediate(baked); }
            }
            var mesh = MeshOf(renderer);
            return (mesh ? mesh.vertices : Array.Empty<Vector3>(), renderer.transform.localToWorldMatrix);
        }

        // Where on the gradient a point is: 0 at the start, 1 at the end, below 0 above the start and above 1 below the
        // end. Not clamped: TexTransTool interpolates this across a triangle and clamps each texel afterwards, and a
        // triangle that crosses the start or the end has other colors inside than its clamped corners would give.
        internal static float GradientAt(HairGradationSettings s, Measure m, Vector3 p)
        {
            float from = m.U.y - Mathf.Clamp01(s.start) * m.Height;
            float length = Mathf.Max(0.001f, (Mathf.Clamp01(s.end) - Mathf.Clamp01(s.start)) * m.Height);
            return (from - Vector3.Dot(p, m.Up)) / length;
        }

        // ---- the components ----------------------------------------------------------------------------------------

        // Starts a key of this form. Version 0.1.0 wrote keys made of instance ids, which are new in every editor session;
        // keys starting "2|" belong to setups that blend the gradient into the main texture with its own alpha, which
        // fills in the transparent parts of a cut-out hair.
        private const string KeyVersion = "3|";

        // What the generated objects depend on that a live update cannot change: then they are made again. Nothing in
        // it changes when the scene is opened again, the editor restarted, play mode entered or the avatar duplicated:
        // a part is named by its place below the hair root, an asset by its GUID.
        internal static string Structure(HairGradationSettings s)
        {
            var parts = Included(s);
            string slot = Slot(s);
            // Into lilToon, also whether the material can take the color: a shader changed to lilToon needs its modifier.
            string Material(Material m) => !m ? "0" : Id(m) + "/" + Id(TextureOf(m)) + (slot == null ? "" : HasSlot(m, slot) ? "+" : "-");
            var ids = parts.Select(r => Below(s.transform, r.transform) + ":" + string.Join(",", r.sharedMaterials.Select(Material)));
            string pattern = s.pattern ? $"{Id(s.pattern)}x{s.patternRepeat}/{Hash(s.pattern)}" : "-";
            return $"{KeyVersion}{s.output}|{pattern}|{string.Join(";", ids)}";
        }

        private static string Id(Object asset)
        {
            if (!asset) return "0";
            // An object that is no asset (a material made in the scene) has only its name to go by.
            return AssetDatabase.TryGetGUIDAndLocalFileIdentifier(asset, out string guid, out long local) ? guid + "." + local : "~" + asset.name;
        }

        // Where a transform sits below the hair root: the names on the way down, numbered among siblings of one name.
        private static string Below(Transform root, Transform t)
        {
            var names = new List<string>();
            for (; t && t != root; t = t.parent)
            {
                int same = 0;
                for (int i = t.GetSiblingIndex() - 1; t.parent && i >= 0; i--)
                    if (t.parent.GetChild(i).name == t.name) same++;
                names.Add(same == 0 ? t.name : t.name + "#" + same);
            }
            names.Reverse();
            return string.Join("/", names);
        }

        private static readonly Dictionary<string, (long Stamp, string Hash)> Hashes = new Dictionary<string, (long, string)>();

        // The pattern's file and import settings as they are on disk, read again only when a file was written. (Unity's
        // own import hash also changes with the build platform: every switch between PC and Android would call the
        // setup outdated and make one more repeated copy of the pattern.)
        private static string Hash(Object asset)
        {
            string path = AssetDatabase.GetAssetPath(asset);
            if (string.IsNullOrEmpty(path)) return "0";
            try
            {
                string file = Path.GetFullPath(path), meta = file + ".meta";
                if (!File.Exists(file)) return "0";
                long stamp = File.GetLastWriteTimeUtc(file).Ticks ^ (File.GetLastWriteTimeUtc(meta).Ticks << 1) ^ new FileInfo(file).Length;
                if (Hashes.TryGetValue(path, out var known) && known.Stamp == stamp) return known.Hash;
                var hash = new Hash128();
                hash.Append(File.ReadAllBytes(file));
                if (File.Exists(meta)) hash.Append(File.ReadAllBytes(meta));
                string text = hash.ToString().Substring(0, 8);
                Hashes[path] = (stamp, text);
                return text;
            }
            catch (Exception e) when (e is IOException || e is UnauthorizedAccessException)
            {
                // Being written right now (an image editor saving): what was read last still stands for it.
                return Hashes.TryGetValue(path, out var known) ? known.Hash : "0";
            }
        }

        // The settings point at an object of their own. After Paste Component Values they can point at another hair's,
        // and this tool only ever removes what is directly below its own hair root.
        internal static bool Own(HairGradationSettings s) => s.generated && s.generated.transform.parent == s.transform;

        // The objects this tool made below the hair root: the one the settings point to, and any they lost track of
        // (Reset on the component empties the reference; the object stays and would be applied next to a new one).
        internal static List<GameObject> Made(HairGradationSettings s)
        {
            var made = new List<GameObject>();
            foreach (Transform child in s.transform)
                if (child.gameObject == s.generated || Ours(child)) made.Add(child.gameObject);
            return made;
        }

        private static readonly string[] Layers = { "Pattern", "Gradient", "Original" };

        // Whether an object the settings do not point to is one this tool made: its name, and nothing in it but what this
        // tool puts there (the same since 0.1.0). An object of the user's that only has the name is left alone.
        private static bool Ours(Transform t)
        {
            if (t.name != ContainerName || t.childCount == 0) return false;
            foreach (Transform child in t)
            {
                bool known = child.name == "Gradient" ? child.GetComponent<SingleGradationDecal>() != null
                    : child.name == "Hair Renderers" ? child.GetComponent<RendererIslandSelector>() != null
                    : child.name.StartsWith("Material · ", StringComparison.Ordinal) ? child.GetComponent<MaterialModifier>() != null
                    : child.name.StartsWith("Canvas · ", StringComparison.Ordinal) && child.GetComponent<MultiLayerImageCanvas>() != null &&
                      child.Cast<Transform>().All(layer => Layers.Contains(layer.name));
                if (!known) return false;
            }
            return true;
        }

        internal static bool Current(HairGradationSettings s) => Own(s) && Outdated(s) == null;

        // Why a setup that exists has to be made again, in words for the inspector, or null when it is what the
        // settings ask for.
        internal static string Outdated(HairGradationSettings s)
        {
            if (!(s.generatedFor ?? "").StartsWith(KeyVersion, StringComparison.Ordinal))
                return "이전 버전에서 만든 구성이라 지금 설정과 맞는지 알 수 없어요. ‘구성 다시 만들기’를 한 번 눌러 주세요.";
            if (s.generatedFor != Structure(s)) return "메시, 텍스처, 패턴이나 넣을 곳이 바뀌었어요. ‘구성 다시 만들기’를 눌러야 반영돼요.";
            if (!Intact(s.generated)) return $"구성이 쓰는 텍스처가 없어졌어요({AssetRoot} 폴더를 지웠거나 옮긴 경우예요). ‘구성 다시 만들기’를 눌러 주세요.";
            if (Shared(s)) return "다른 헤어의 구성과 같은 빈 텍스처에 칠하고 있어요(헤어를 복제한 경우예요). 이대로면 빌드에서 한쪽 그라데이션만 남아요. ‘구성 다시 만들기’를 눌러 주세요.";
            return null;
        }

        // A texture this tool made that the setup paints and another setup in the avatar paints too. A copied hair keeps
        // pointing at the original's blank texture, and of two canvases on one texture the later wipes the earlier.
        private static bool Shared(HairGradationSettings s)
        {
            var mine = s.generated.GetComponentsInChildren<MultiLayerImageCanvas>(true).Select(c => c.TargetTexture.SelectTexture).Where(Generated).ToList();
            return mine.Count > 0 && CanvasTextures(AvatarRoot(s), s.generated.transform).Any(mine.Contains);
        }

        // The textures the canvases in the avatar paint, except those below one object (a setup's own).
        private static IEnumerable<Texture2D> CanvasTextures(Transform avatar, Transform except) =>
            avatar.GetComponentsInChildren<MultiLayerImageCanvas>(true).Where(c => !c.transform.IsChildOf(except)).Select(c => c.TargetTexture.SelectTexture).Where(t => t);

        private static bool Generated(Texture2D texture) =>
            texture && AssetDatabase.GetAssetPath(texture).StartsWith(AssetRoot + "/", StringComparison.Ordinal);

        // The textures this tool made for the setup are still there. Without its texture a canvas paints nothing, and
        // a pattern decal fills the hair with its plain color.
        private static bool Intact(GameObject generated) =>
            generated.GetComponentsInChildren<MultiLayerImageCanvas>(true).All(c => c.TargetTexture.SelectTexture) &&
            generated.GetComponentsInChildren<SimpleDecal>(true).All(d => d.DecalTexture);

        // Makes the generated objects again, as one Undo step. Returns what could not be done.
        internal static List<string> Rebuild(HairGradationSettings s)
        {
            var problems = new List<string>();
            var parts = Included(s);
            if (parts.Count == 0)
            {
                // Nothing to paint: nothing is made, and a setup that is there stays. Only Remove takes one away.
                problems.Add("칠할 메시가 없어서 구성을 만들지 않았어요. 위 ‘칠할 메시’에서 켜진 메시를 하나 이상 체크해 주세요." +
                             (Made(s).Count > 0 ? " 있던 구성은 그대로예요." : ""));
                return problems;
            }
            Undo.SetCurrentGroupName("Hair Gradation");
            int undo = Undo.GetCurrentGroup();
            foreach (var made in Made(s)) Undo.DestroyObjectImmediate(made);
            var groups = Groups(parts, problems);
            string slot = Slot(s);
            bool lilToon = slot != null;
            if (lilToon)
                foreach (var material in groups.SelectMany(g => g.Materials).Distinct())
                {
                    if (!IsLilToon(material))
                        problems.Add($"‘{material.name}’은(는) lilToon이 아니라서 2nd/3rd 컬러에 넣을 수 없어요. 넣을 곳을 ‘메인 텍스처에 합치기’로 바꾸거나 머티리얼을 lilToon으로 바꿔 주세요.");
                    else if (!HasSlot(material, slot))
                        problems.Add($"‘{material.name}’의 셰이더({material.shader.name})에서는 메인 컬러 {slot}를 쓸 수 없어서 건너뛰어요. 넣을 곳을 ‘메인 텍스처에 합치기’로 바꾸거나 lilToon의 일반 셰이더로 바꿔 주세요.");
                    else
                    {
                        if (MaterialProperty.TryGet(material, $"_UseMain{slot}Tex", out var use) && (use.FloatValue != 0f || use.IntValue != 0))
                            problems.Add($"‘{material.name}’은(는) 이미 lilToon 메인 컬러 {slot}를 쓰고 있어요. 빌드에서는 그 칸이 그라데이션으로 바뀌어, 넣어 둔 텍스처와 설정은 보이지 않아요. 그대로 두려면 넣을 곳을 다른 칸이나 ‘메인 텍스처에 합치기’로 바꿔 주세요.");
                        // The fur passes draw the main texture only.
                        if (material.shader.name.IndexOf("Fur", StringComparison.Ordinal) >= 0)
                            problems.Add($"‘{material.name}’은(는) 퍼 셰이더라서 털 부분에는 그라데이션이 보이지 않아요(바탕에만 들어가요). 털에도 넣으려면 넣을 곳을 ‘메인 텍스처에 합치기’로 바꿔 주세요.");
                        // The build turns the keyword on (HairGradationPlugin); the preview draws with the material's own keywords.
                        if (IsMulti(material) && !material.IsKeywordEnabled(Keyword(slot)))
                            problems.Add($"‘{material.name}’은(는) lilToonMulti이고 메인 컬러 {slot}가 꺼져 있어서, Scene 뷰의 NDMF 미리보기에는 그라데이션이 보이지 않아요. 빌드(업로드)할 때는 그 칸을 켜서 들어가요.");
                    }
                }
            // Into lilToon only the materials that show the color are changed; another material on the same texture is left out.
            List<Material> Painted(Group group) => lilToon ? group.Materials.Where(m => HasSlot(m, slot)).ToList() : group.Materials;

            // TexTransTool replaces a texture (and changes a material) everywhere it is used.
            var avatar = AvatarRoot(s).GetComponentsInChildren<Renderer>(true).Where(r => !parts.Contains(r)).ToList();
            foreach (var group in groups)
            {
                var painted = Painted(group);
                var others = avatar.Where(r => r.sharedMaterials.Any(m => m && (painted.Contains(m) || (!lilToon && TextureOf(m) == group.Texture))))
                    .Select(r => $"‘{r.name}’").Distinct().ToList();
                if (others.Count > 0)
                    problems.Add($"칠하지 않는 메시도 ‘{group.Texture.name}’을(를) 써요: {string.Join(", ", others.Take(5))}{(others.Count > 5 ? " …" : "")}. " +
                                 "그 메시에도 바뀐 결과가 보여요. 따로 두려면 그 메시의 머티리얼과 텍스처를 복제해 주세요.");
            }

            var container = new GameObject(ContainerName);
            Undo.RegisterCreatedObjectUndo(container, "Hair Gradation");
            container.transform.SetParent(s.transform, false);
            GameObject Child(string name, Transform parent)
            {
                var go = new GameObject(name);
                go.transform.SetParent(parent, false);
                return go;
            }

            // Into the main texture too every texture gets a canvas, never a decal of its own: a decal is laid onto the
            // texture with its own alpha, which fills in the transparent parts of a cut-out hair. In the canvas the paint
            // is clipped to the original, and a clipped layer leaves the alpha below it as it was.
            // Inside a canvas a decal paints every renderer that shows the canvas's texture; this keeps it to the parts.
            var selector = Child("Hair Renderers", container.transform).AddComponent<RendererIslandSelector>();
            selector.RendererList = parts.ToList();
            var tiled = s.pattern ? TiledPattern(s, problems) : null;
            void Pattern(Transform parent)
            {
                var pattern = Child("Pattern", parent).AddComponent<SimpleDecal>();
                pattern.DecalTexture = tiled;
                pattern.FixedAspect = false;
                pattern.IslandSelector = selector;
                pattern.TargetPropertyName = new TTTPropertyName(MainTex);
                pattern.gameObject.AddComponent<AsLayer>();
            }
            foreach (var group in groups)
            {
                var painted = Painted(group);
                if (painted.Count == 0) continue;
                var target = group.Texture;
                if (lilToon)
                {
                    target = BlankTexture(s, group.Texture, container.transform, problems);
                    if (!target) continue;
                    foreach (var material in painted)
                    {
                        var modifier = Child("Material · " + material.name, container.transform).AddComponent<MaterialModifier>();
                        modifier.TargetMaterial = material;
                        modifier.OverrideProperties = LilToonProperties(material, s, target);
                    }
                }
                var canvas = Child("Canvas · " + group.Texture.name, container.transform).AddComponent<MultiLayerImageCanvas>();
                canvas.TargetTexture.SelectTexture = target;
                // The first child is the top layer. The pattern is there twice, over the gradient and clipped to it inside
                // its folder; Sync shows the one ‘inside the gradient’ asks for, so that setting needs no rebuild.
                if (tiled) Pattern(canvas.transform);
                var paint = Child("Gradient", canvas.transform).AddComponent<LayerFolder>();
                if (tiled) Pattern(paint.transform);
                var gradient = Child("Gradient", paint.transform).AddComponent<SingleGradationDecal>();
                gradient.IslandSelector = selector;
                gradient.TargetPropertyName = new TTTPropertyName(MainTex);
                gradient.gameObject.AddComponent<AsLayer>();
                if (!lilToon) Child("Original", canvas.transform).AddComponent<RasterLayer>().RasterTexture = group.Texture;
            }
            // Recorded after the objects are made, so Undo and Redo bring the reference back with them.
            Undo.RecordObject(s, "Hair Gradation");
            s.generated = container;
            s.generatedFor = Structure(s);
            Sync(s, Measured(s, parts));
            Keep(s);
            Undo.CollapseUndoOperations(undo);
            return problems;
        }

        // Takes the generated objects away, as one Undo step: the gradient is no longer applied at build.
        internal static void Remove(HairGradationSettings s)
        {
            Undo.SetCurrentGroupName("Hair Gradation");
            int undo = Undo.GetCurrentGroup();
            foreach (var made in Made(s)) Undo.DestroyObjectImmediate(made);
            Undo.RecordObject(s, "Hair Gradation");
            s.generated = null;
            s.generatedFor = "";
            Keep(s);
            Undo.CollapseUndoOperations(undo);
        }

        // Marks objects changed by script as changed. On an object of a prefab instance a change made this way is kept
        // only once it is recorded as an override; otherwise saving or reloading brings back the prefab's value.
        internal static void Keep(params Object[] changed)
        {
            foreach (var o in changed)
            {
                if (!o) continue;
                EditorUtility.SetDirty(o);
                if (PrefabUtility.IsPartOfPrefabInstance(o)) PrefabUtility.RecordPrefabInstancePropertyModifications(o);
            }
        }

        // Where the gradient decal goes: origin at the start height, its local y running down the hair from 0 at the
        // start to 1 at the end, and a box as wide and deep as the hair (only drawn in the Scene view).
        private static (Vector3 Position, Vector3 Down, Vector3 Forward, Vector3 Size) GradientBox(HairGradationSettings s, Measure m)
        {
            float from = m.U.y - Mathf.Clamp01(s.start) * m.Height;
            float length = Mathf.Max(0.001f, (Mathf.Clamp01(s.end) - Mathf.Clamp01(s.start)) * m.Height);
            var center = m.Right * ((m.R.x + m.R.y) / 2f) + m.Forward * ((m.F.x + m.F.y) / 2f);
            return (center + m.Up * from, -m.Up, m.Forward, new Vector3(m.R.y - m.R.x, length, m.F.y - m.F.x));
        }

        // Whether the gradient decal still sits where a measure puts it. It does not once the hair has changed shape
        // or a part has moved since the last update (a hair-length blendshape, a part dragged elsewhere).
        internal static bool Placed(HairGradationSettings s, Measure m)
        {
            if (!s.generated || !m.Valid) return true;
            var decal = s.generated.GetComponentInChildren<SingleGradationDecal>(true);
            if (!decal) return true;
            var box = GradientBox(s, m);
            var t = decal.transform;
            // Half a percent of the hair's height does not show; a longer hair or a moved part is far more.
            float slack = Mathf.Max(0.0005f, 0.005f * m.Height);
            // At every corner of the hair, the place on the gradient TexTransTool reads from the decal (its local y) and
            // the one the measure gives, in meters along the hair.
            var toLocal = t.worldToLocalMatrix;
            foreach (float r in new[] { m.R.x, m.R.y })
            foreach (float u in new[] { m.U.x, m.U.y })
            foreach (float f in new[] { m.F.x, m.F.y })
            {
                var p = m.Right * r + m.Up * u + m.Forward * f;
                if (Mathf.Abs(toLocal.MultiplyPoint3x4(p).y * box.Size.y - Vector3.Dot(p - box.Position, box.Down)) > slack) return false;
            }
            var size = Vector3.Scale(t.localScale, Stretch(t)) - box.Size;
            return (t.position - box.Position).magnitude <= slack && Mathf.Abs(size.x) <= slack && Mathf.Abs(size.z) <= slack;
        }

        // Whether the hair root is skewed in the world: a parent turned inside a non-uniform scale. No position, rotation
        // and scale of a child can undo that, so the pattern's box can only be placed nearly (the gradient exactly).
        internal static bool Skewed(HairGradationSettings s)
        {
            var m = s.transform.localToWorldMatrix;
            Vector3 x = ((Vector3)m.GetColumn(0)).normalized, y = ((Vector3)m.GetColumn(1)).normalized, z = ((Vector3)m.GetColumn(2)).normalized;
            // About half a degree off square.
            const float off = 0.01f;
            return Mathf.Abs(Vector3.Dot(x, y)) > off || Mathf.Abs(Vector3.Dot(y, z)) > off || Mathf.Abs(Vector3.Dot(x, z)) > off;
        }

        // Puts the settings a live edit can change into the generated components (recorded for Undo).
        internal static void Sync(HairGradationSettings s, Measure m)
        {
            if (!s.generated || !m.Valid) return;
            var components = s.generated.GetComponentsInChildren<Component>(true).Where(c => !(c is Transform)).ToArray();
            var transforms = s.generated.GetComponentsInChildren<Transform>(true);
            var objects = transforms.Select(t => t.gameObject).ToArray();
            var recorded = components.Concat<Object>(transforms).Concat(objects).ToArray();
            Undo.RecordObjects(recorded, "Hair Gradation");
            bool lilToon = s.output != GradationOutput.MainTexture;

            var box = GradientBox(s, m);
            foreach (var decal in components.OfType<SingleGradationDecal>())
            {
                PlaceGradient(decal.transform, box);
                // A copy with everything the gradient field can set, the color space of its keys included.
                decal.Gradient = new Gradient { mode = s.gradient.mode, colorSpace = s.gradient.colorSpace, colorKeys = s.gradient.colorKeys, alphaKeys = s.gradient.alphaKeys };
                decal.Alpha = s.opacity;
                // Off: TexTransTool stretches the end colors past the range (on, it leaves the rest unpainted).
                decal.GradientClamp = false;
                // Painted plain into its folder; the folder is blended as chosen, with the pattern clipped to the gradient.
                decal.BlendTypeKey = "Normal";
                decal.Padding = s.padding;
                if (decal.TryGetComponent<AsLayer>(out var layer))
                {
                    layer.Opacity = 1f;
                    layer.Clipping = false;
                    layer.BlendTypeKey = "Normal";
                }
            }
            foreach (var folder in components.OfType<LayerFolder>())
            {
                folder.Opacity = 1f;
                folder.PassThrough = false;
                // Into the main texture clipped to the original, whose alpha then stays. Into lilToon it is painted plain
                // on a blank texture (nothing below to clip to) and lilToon blends it with the chosen mode.
                folder.Clipping = !lilToon;
                folder.BlendTypeKey = lilToon ? "Normal" : Known(s.blend);
            }

            // The pattern: a square box over the hair's front, projecting backwards through it.
            float side = Mathf.Max(m.R.y - m.R.x, m.Height) * 1.05f;
            float margin = 0.01f;
            var patternPlace = m.Right * ((m.R.x + m.R.y) / 2f) + m.Up * ((m.U.x + m.U.y) / 2f) + m.Forward * (m.F.y + margin);
            foreach (var decal in components.OfType<SimpleDecal>())
            {
                Place(decal.transform, patternPlace, Quaternion.LookRotation(-m.Forward, m.Up), new Vector3(side, side, m.F.y - m.F.x + 2f * margin));
                decal.Color = s.patternColor;
                decal.BackCulling = !s.patternOnBack;
                decal.BlendTypeKey = Known(s.patternBlend);
                decal.Padding = s.padding;
                // The copy in the gradient's folder is clipped to the gradient; the one over it is on its own (into the
                // main texture clipped to the original, for its alpha). Only the one the setting asks for is shown.
                bool inside = decal.transform.parent && decal.transform.parent.GetComponent<LayerFolder>();
                if (decal.gameObject.activeSelf != (inside == s.patternInsideGradient)) decal.gameObject.SetActive(inside == s.patternInsideGradient);
                if (decal.TryGetComponent<AsLayer>(out var layer))
                {
                    layer.Opacity = s.patternOpacity;
                    layer.Clipping = inside || !lilToon;
                    layer.BlendTypeKey = Known(s.patternBlend);
                }
            }

            // lilToon: the 2nd/3rd color blends as chosen.
            int mode = LilToonBlendMode(s);
            foreach (var modifier in components.OfType<MaterialModifier>())
                for (int i = 0; i < modifier.OverrideProperties.Count; i++)
                {
                    var property = modifier.OverrideProperties[i];
                    if (!property.PropertyName.EndsWith("TexBlendMode", StringComparison.Ordinal)) continue;
                    modifier.OverrideProperties[i] = Number(property, mode);
                }
            Keep(recorded);
        }

        private static Texture2D TextureOf(Material material) =>
            material && material.HasProperty(MainTex) ? material.GetTexture(MainTex) as Texture2D : null;

        // A blend mode as stored, or Normal for one the lists above do not have (the inspector says so and leaves it).
        private static string Known(string blend) => Array.Exists(Blends, b => b.Key == blend) ? blend : "Normal";

        private static int LilToonBlendMode(HairGradationSettings s)
        {
            int mode = Array.FindIndex(Blends, b => b.Key == s.blend);
            return mode >= 0 && mode < LilToonBlends ? mode : 0;
        }

        // A number property set to a value, whether the shader declares it Float, Range or Int.
        private static MaterialProperty Number(MaterialProperty p, float value)
        {
            p.FloatValue = value;
            p.IntValue = Mathf.RoundToInt(value);
            return p;
        }

        // lilToon's 2nd/3rd color turned on with the texture to paint, white, blended as chosen. Whatever else the
        // material has set there goes back to lilToon's defaults: left as it is, a decal's angle or UV mode moves the
        // gradient, a mask or a dissolve hides it, and an alpha mode cuts the hair itself out.
        private static List<MaterialProperty> LilToonProperties(Material material, HairGradationSettings s, Texture2D blank)
        {
            var list = new List<MaterialProperty>();
            if (!material || !blank) return list;
            string n = Slot(s);
            void Set(string name, Func<MaterialProperty, MaterialProperty> value)
            {
                if (MaterialProperty.TryGet(material, name, out var property)) list.Add(value(property));
            }
            Set($"_UseMain{n}Tex", p => Number(p, 1f));
            Set($"_Main{n}Tex", p =>
            {
                p.TextureValue = blank;
                p.TextureScaleValue = Vector2.one;
                p.TextureOffsetValue = Vector2.zero;
                return p;
            });
            Set($"_Color{n}", p =>
            {
                p.ColorValue = Color.white;
                return p;
            });
            Set($"_Main{n}TexBlendMode", p => Number(p, LilToonBlendMode(s)));
            foreach (string off in new[] { "TexAngle", "Tex_UVMode", "Tex_Cull", "TexIsDecal", "TexIsLeftOnly", "TexIsRightOnly", "TexShouldCopy",
                         "TexShouldFlipMirror", "TexShouldFlipCopy", "TexIsMSDF", "TexAlphaMode" })
                Set($"_Main{n}{off}", p => Number(p, 0f));
            Set($"_AudioLink2Main{n}", p => Number(p, 0f));
            void Vector(string name, float x, float y, float z, float w) => Set(name, p =>
            {
                p.VectorValue = new Vector4(x, y, z, w);
                return p;
            });
            Vector($"_Main{n}Tex_ScrollRotate", 0f, 0f, 0f, 0f);
            Vector($"_Main{n}TexDecalAnimation", 1f, 1f, 1f, 30f);
            Vector($"_Main{n}TexDecalSubParam", 1f, 1f, 0f, 1f);
            Vector($"_Main{n}DissolveParams", 0f, 0f, 0.5f, 0.1f);
            Vector($"_Main{n}DistanceFade", 0.1f, 0.01f, 0f, 0f);
            Set($"_Main{n}BlendMask", p =>
            {
                p.TextureValue = null;
                p.TextureScaleValue = Vector2.one;
                p.TextureOffsetValue = Vector2.zero;
                return p;
            });
            return list;
        }

        // Places an object so that its matrix in the world is the position, rotation and size given. Below a mirrored
        // parent (a negative scale) that takes a negative scale of its own, on its X; setting the world rotation instead
        // would leave it mirrored, its box turned over. Below a skewed parent (see Skewed) it can only come close.
        private static void Place(Transform t, Vector3 position, Quaternion rotation, Vector3 size)
        {
            var parent = t.parent ? t.parent.localToWorldMatrix : Matrix4x4.identity;
            var local = parent.inverse * Matrix4x4.TRS(position, rotation, size);
            Vector3 x = local.GetColumn(0), y = local.GetColumn(1), z = local.GetColumn(2);
            float mirrored = Vector3.Dot(Vector3.Cross(x, y), z) < 0f ? -1f : 1f;
            t.localPosition = local.GetColumn(3);
            t.localRotation = Quaternion.LookRotation(z, y);
            t.localScale = new Vector3(mirrored * x.magnitude, y.magnitude, z.magnitude);
        }

        // Places the gradient decal. TexTransTool reads one thing from its transform: a point's place on the gradient is
        // its local y (SingleGradationSpace). That is set exactly below any parent, a mirrored or a skewed one too:
        // local y of a world point p = dot(p - start, down) / length. Its X and Z only size the box shown in the Scene view.
        private static void PlaceGradient(Transform t, (Vector3 Position, Vector3 Down, Vector3 Forward, Vector3 Size) box)
        {
            var parent = t.parent ? t.parent.localToWorldMatrix : Matrix4x4.identity;
            var toParent = parent.inverse;
            // In the parent's space q, p - start = parent (q - q0), so dot(p - start, down) = dot(transpose(parent) down, q - q0):
            // the local Y axis lies along transpose(parent) down, scaled so that one unit of it is the length.
            Vector3 along = parent.transpose.MultiplyVector(box.Down);
            var forward = Vector3.ProjectOnPlane(toParent.MultiplyVector(box.Forward), along);
            if (forward.sqrMagnitude < 1e-12f) forward = Vector3.ProjectOnPlane(Vector3.forward, along);
            if (forward.sqrMagnitude < 1e-12f) forward = Vector3.ProjectOnPlane(Vector3.right, along);
            t.localPosition = toParent.MultiplyPoint3x4(box.Position);
            t.localRotation = Quaternion.LookRotation(forward, along);
            var stretch = Stretch(t);
            t.localScale = new Vector3(box.Size.x / stretch.x, box.Size.y / along.magnitude, box.Size.z / stretch.z);
        }

        // How much the parent stretches each local axis of an object: its local scale times this is its size in the world.
        private static Vector3 Stretch(Transform t)
        {
            if (!t.parent) return Vector3.one;
            var parent = t.parent.localToWorldMatrix;
            float Along(Vector3 axis) => Mathf.Max(1e-6f, parent.MultiplyVector(t.localRotation * axis).magnitude);
            return new Vector3(Along(Vector3.right), Along(Vector3.up), Along(Vector3.forward));
        }

        // Where the parts are now, cheaply: the measure is taken again when they move or change shape. A skinned
        // mesh's bounds do not follow its blendshapes, so their weights are listed too.
        internal static string Placement(IEnumerable<Renderer> renderers) =>
            string.Join(";", renderers.Select(r => (Bounds: r.bounds, Shapes: Shapes(r))).Select(p =>
                $"{p.Bounds.center.x:0.000},{p.Bounds.center.y:0.000},{p.Bounds.center.z:0.000},{p.Bounds.size.x:0.000},{p.Bounds.size.y:0.000},{p.Bounds.size.z:0.000},{p.Shapes}"));

        private static string Shapes(Renderer renderer)
        {
            if (!(renderer is SkinnedMeshRenderer skinned) || !skinned.sharedMesh) return "";
            var shapes = new System.Text.StringBuilder();
            for (int i = 0; i < skinned.sharedMesh.blendShapeCount; i++)
            {
                float weight = skinned.GetBlendShapeWeight(i);
                if (weight != 0f) shapes.Append(i).Append('=').Append(weight.ToString("0.#")).Append(' ');
            }
            return shapes.ToString();
        }

        // ---- assets ------------------------------------------------------------------------------------------------

        private static string Folder(HairGradationSettings s)
        {
            string name = string.Concat(AvatarRoot(s).name.Select(ch => Path.GetInvalidFileNameChars().Contains(ch) ? '_' : ch)).Trim();
            string folder = AssetRoot + "/" + (string.IsNullOrEmpty(name) ? "Avatar" : name);
            if (!AssetDatabase.IsValidFolder(folder))
            {
                string at = "Assets";
                foreach (var part in folder.Split('/').Skip(1))
                {
                    if (!AssetDatabase.IsValidFolder(at + "/" + part)) AssetDatabase.CreateFolder(at, part);
                    at += "/" + part;
                }
            }
            return folder;
        }

        private static string Safe(string name) => string.Concat(name.Select(ch => Path.GetInvalidFileNameChars().Contains(ch) ? '_' : ch));

        // The pattern repeated into one square texture (TexTransTool's decal shows its texture once).
        private static Texture2D TiledPattern(HairGradationSettings s, List<string> problems)
        {
            string path = $"{Folder(s)}/Pattern_{Safe(s.pattern.name)}_{s.patternRepeat}x_{Hash(s.pattern)}.png";
            var existing = AssetDatabase.LoadAssetAtPath<Texture2D>(path);
            if (existing) return existing;
            // The size of the image file: Unity imports a texture scaled to powers of two, which loses its proportions.
            int width = s.pattern.width, height = s.pattern.height;
            if (AssetImporter.GetAtPath(AssetDatabase.GetAssetPath(s.pattern)) is TextureImporter source) source.GetSourceTextureWidthAndHeight(out width, out height);
            if (width <= 0 || height <= 0) (width, height) = (s.pattern.width, s.pattern.height);
            // The decal's box is square. A pattern that is not gets more (or fewer) rows than columns, so one cell of
            // it keeps the proportions of the image instead of being squashed into a square.
            float rows = s.patternRepeat * (float)width / height;
            int size = Mathf.Clamp(Mathf.NextPowerOfTwo(Mathf.Max(s.pattern.width, s.pattern.height) * s.patternRepeat), 256, 4096);
            var (wrapU, wrapV, wrapW) = (s.pattern.wrapModeU, s.pattern.wrapModeV, s.pattern.wrapModeW);
            var target = RenderTexture.GetTemporary(size, size, 0, RenderTextureFormat.ARGB32, RenderTextureReadWrite.sRGB);
            var active = RenderTexture.active;
            var image = new Texture2D(size, size, TextureFormat.RGBA32, false);
            try
            {
                s.pattern.wrapMode = TextureWrapMode.Repeat;
                Graphics.Blit(s.pattern, target, new Vector2(s.patternRepeat, rows), Vector2.zero);
                RenderTexture.active = target;
                image.ReadPixels(new Rect(0, 0, size, size), 0, 0);
                image.Apply();
                return Save(image, path, problems);
            }
            finally
            {
                s.pattern.wrapModeU = wrapU;
                s.pattern.wrapModeV = wrapV;
                s.pattern.wrapModeW = wrapW;
                RenderTexture.active = active;
                RenderTexture.ReleaseTemporary(target);
                Object.DestroyImmediate(image);
            }
        }

        // A transparent texture the size of a hair texture, for lilToon's 2nd/3rd color to be painted at build.
        private static Texture2D BlankTexture(HairGradationSettings s, Texture2D like, Transform container, List<string> problems)
        {
            string guid = AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(like));
            string tag = s.output == GradationOutput.LilToonMain3rd ? "3rd" : "2nd";
            int width = Mathf.Min(4096, like.width), height = Mathf.Min(4096, like.height);
            // One per hair root and size: two hairs on one texture each paint their own, or the later canvas would wipe
            // what the earlier one painted. The name is one no other setup in the avatar paints, so neither hair roots of
            // one name nor a copied hair (which points at the original's) share one, whatever their order.
            var taken = new HashSet<string>(CanvasTextures(AvatarRoot(s), container).Select(t => AssetDatabase.GetAssetPath(t)));
            string path;
            for (int n = 1; ; n++)
            {
                path = $"{Folder(s)}/{Safe(s.name)}{(n > 1 ? "_" + n : "")}_{Safe(like.name)}_{tag}_{width}x{height}_{(guid.Length >= 8 ? guid.Substring(0, 8) : "new")}.png";
                if (!taken.Contains(path)) break;
            }
            var existing = AssetDatabase.LoadAssetAtPath<Texture2D>(path);
            if (existing) return existing;
            var image = new Texture2D(width, height, TextureFormat.RGBA32, false);
            try
            {
                image.SetPixels32(new Color32[width * height]);
                image.Apply();
                return Save(image, path, problems);
            }
            finally { Object.DestroyImmediate(image); }
        }

        private static Texture2D Save(Texture2D image, string path, List<string> problems)
        {
            try { File.WriteAllBytes(path, image.EncodeToPNG()); }
            catch (Exception e)
            {
                if (File.Exists(path)) File.Delete(path);
                problems.Add($"텍스처를 저장하지 못했어요 ({path}): {e.Message}");
                return null;
            }
            AssetDatabase.ImportAsset(path, ImportAssetOptions.ForceUpdate);
            if (AssetImporter.GetAtPath(path) is TextureImporter importer)
            {
                importer.alphaIsTransparency = true;
                importer.mipmapEnabled = true;
                // VRChat requires mip streaming on every texture it uploads (NDMF checks it at build).
                importer.streamingMipmaps = true;
                importer.wrapMode = TextureWrapMode.Clamp;
                importer.maxTextureSize = Mathf.Max(image.width, image.height);
                importer.SaveAndReimport();
            }
            return AssetDatabase.LoadAssetAtPath<Texture2D>(path);
        }
    }
}
#endif
