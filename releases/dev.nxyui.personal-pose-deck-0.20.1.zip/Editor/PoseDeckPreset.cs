using System;
using System.Collections.Generic;
using UnityEditor.Animations;
using UnityEngine;
using VRC.SDK3.Avatars.ScriptableObjects;

namespace PersonalPoseDeck
{
    internal enum PoseCategory { Sit, Lie, Stand, Other }

    [Serializable]
    internal sealed class PoseEntry
    {
        public string label;
        public AnimationClip clip;
        public PoseCategory category;
        // Off keeps GoGoLoco's own start height for the slot (Go/Float 0.25 on a custom slot, the preset on a stock one).
        public bool overrideHeight;
        [Range(0f, 1f)] public float height = PoseDeckBuilder.DefaultStartHeight;
        // Menu icon for this pose. Empty uses the rendered icon (or GoGoLoco's own for a stock pose).
        public Texture2D icon;
        // "VR에서 손도 포즈대로": in VR (3–4 points) the hands follow the clip while this pose is held instead of the
        // controllers, which GoGoLoco otherwise keeps them on. See PoseDeckBuilder.ApplyHeld.
        public bool vrHands;
        // "VR에서 다리도 포즈대로": the feet follow the clip even when a gimmick turns leg tracking on during the pose
        // (AvatarBasicTool's tracking layer). The hips stay with GoGoLoco (headset or waist tracker): see ApplyHeld.
        public bool vrLegs;
    }

    public sealed class PoseDeckPreset : ScriptableObject
    {
        [SerializeField] internal string menuTitle = "내 포즈";
        [SerializeField] internal bool keepStockMenu = true;
        // Put reset and height adjustment at the top of every category page, next to the poses.
        [SerializeField] internal bool controlsOnEveryPage = true;
        // Render each pose as its menu icon when generating (needs an avatar in the preview).
        [SerializeField] internal bool generateIcons = true;
        // Camera for rendered icons: index into PoseDeckPoseBrowser.IconViews.
        [SerializeField] internal int iconView;
        // GoGoLoco stock poses keep GoGoLoco's own menu icon instead of a rendered one.
        [SerializeField] internal bool keepNativeIcons;
        [SerializeField] internal List<PoseEntry> poses = new List<PoseEntry>();
        // Retained as-is to resolve scenes wired to results from 0.7.0 and earlier.
        [SerializeField, HideInInspector] internal AnimatorController stockBase = null;
        [SerializeField, HideInInspector] internal VRCExpressionsMenu stockMenu = null;
        [SerializeField, HideInInspector] internal AnimatorController appliedBase = null;
        [SerializeField, HideInInspector] internal VRCExpressionsMenu appliedMenu = null;
    }
}
