#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using nadena.dev.modular_avatar.core;
using nadena.dev.ndmf;
using nadena.dev.ndmf.platform;
using nadena.dev.ndmf.util;
using UnityEditor;
using UnityEditor.Animations;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using VRC.SDK3.Avatars.Components;
using Object = UnityEngine.Object;

namespace AssemblyChecker
{
    // A copy of a scene avatar built by NDMF in a preview scene, with the path each of its objects had before the build.
    // The scene avatar is not changed; the copy, its scene and the build's temporary assets go away on Dispose. What a
    // build would write outside its own folder (unsaved assets, Modular Avatar's sync record) is held back or put back,
    // and what other tools' plug-ins change in the project during the build is put back or noted (BuildChanges).
    internal sealed class BuiltAvatar : IDisposable
    {
        private const string FolderPrefix = "__AssemblyCheckerBuild_";
        private static readonly Regex FolderName = new Regex("^" + FolderPrefix + "[0-9a-f]{32}$");
        // A build folder that still holds a scene-only object is kept under this name, which the sweep does not match.
        private const string KeptPrefix = "AssemblyChecker_Kept_";
        // Folders of builds that have not been disposed yet, and kept ones that could not be renamed.
        private static readonly HashSet<string> Open = new HashSet<string>();
        private static readonly HashSet<string> Kept = new HashSet<string>();
        // Where Modular Avatar keeps what Sync Parameter Sequence recorded for each blueprint ID (its ParameterInfoStore).
        private const string SyncRecords = "Library/nadena.dev.modular-avatar/AvatarParameterInfo";
        // What that record was before the check that is running, on disk until it has been put back.
        private const string SyncBackup = "Library/NXYUI.AssemblyChecker/SyncRecordBackup.txt";
        private const string SessionKey = "NXYUI.AssemblyChecker.Session";

        // The folder of the check that is under way ("" before it exists), from the start of its build until everything it
        // put back is back (Dispose), or null: while it is set, the editor writes no asset files but the open builds' own
        // (CheckSaveGuard). Not only during the build: making the copy and the folder can set off another tool's code,
        // and putting back can make another tool's postprocessor save, which would write assets not put back yet and the
        // user's other unsaved changes.
        internal static string Saving { get; private set; }
        // Whether this build set the guard, taken off in the last step of Dispose.
        private bool guarding;
        // The check under way, from the start of Build to the end of its Dispose (a second one is refused), and what the
        // refusal says.
        private static BuiltAvatar current;
        internal const string Busy = "점검이 이미 진행 중이에요. 끝난 뒤에 다시 눌러 주세요.";

        internal GameObject Source { get; private set; }
        internal GameObject Clone { get; private set; }
        internal bool Successful { get; private set; }
        // The parameter cleanup's report from this build (null when the pass did not run).
        internal ParameterCleanup.Report Cleanup { get; private set; }
        // What the check could not put back as it was, in words for the window (empty when all went well).
        internal readonly List<string> Problems = new List<string>();
        // What other tools changed in the project during the build and what went back, complete once disposed.
        internal BuildChanges.Report Changes => changes.Result;
        private readonly BuildChanges changes = new BuildChanges();
        // The copy's own duplicate of each object of the scene avatar that is not saved as an asset (a menu, material or
        // mesh some tool left in the scene), with the object it copies.
        private readonly Dictionary<Object, Object> copies = new Dictionary<Object, Object>();
        // The unsaved objects the copy still shares with the scene avatar (ones that cannot be duplicated, or that the
        // copy reaches only through a saved asset), with their hide flags.
        private readonly Dictionary<Object, HideFlags> unsaved = new Dictionary<Object, HideFlags>();
        // The names of shared objects that could not be taken back out of the build's folder: the folder is kept.
        private readonly List<string> stuck = new List<string>();
        // Each object of the copy and its path below the avatar before the build ("" for the root).
        internal readonly Dictionary<Transform, string> Before = new Dictionary<Transform, string>();
        // Each object of the copy and the scene object it was copied from, and the other way round: paths can repeat
        // (two siblings with one name).
        private readonly Dictionary<Transform, Transform> toScene = new Dictionary<Transform, Transform>();
        private readonly Dictionary<Transform, Transform> toCopy = new Dictionary<Transform, Transform>();

        private Scene scene;
        private string folder;

        internal static BuiltAvatar Build(VRCAvatarDescriptor avatar)
        {
            // No check inside a check (a tool's build step starting one): the inner build's end would switch the cleanup's
            // preview off, and the outer check would then file its report as the real ‘마지막 빌드’ record. Checks one
            // after another are not affected: the window queues them.
            if (current != null) throw new InvalidOperationException(Busy);
            var built = new BuiltAvatar { Source = avatar.gameObject };
            try
            {
                current = built;
                // The save guard from the first step, before the copy is made (an ExecuteAlways OnEnable of it) and before
                // the folder exists (a postprocessor reacting to it): while there is no folder, it lets nothing through.
                Saving = "";
                built.guarding = true;
                DeleteStaleFolders();
                RecoverSyncRecord();
                built.scene = EditorSceneManager.NewPreviewScene();
                var clone = Object.Instantiate(avatar.gameObject);
                clone.name = avatar.gameObject.name;
                SceneManager.MoveGameObjectToScene(clone, built.scene);
                clone.SetActive(true);
                built.Clone = clone;
                foreach (var t in clone.GetComponentsInChildren<Transform>(true)) built.Before[t] = PathOf(clone.transform, t);
                built.Pair(avatar.transform, clone.transform);
                built.Unshare(clone);
                built.folder = AssetDatabase.GUIDToAssetPath(AssetDatabase.CreateFolder("Assets", FolderPrefix + Guid.NewGuid().ToString("N")));
                if (string.IsNullOrEmpty(built.folder)) throw new InvalidOperationException("임시 빌드 폴더를 만들 수 없어요.");
                Open.Add(built.folder);
                Saving = built.folder;
                // The same walk NDMF saves by at the end of a build: what it will file under the build's folder of the
                // scene avatar's own. The saved assets it meets are the avatar's own that a plug-in could change in place.
                foreach (var asset in clone.ReferencedAssets(traverseSaved: true, includeScene: false))
                {
                    if (!asset) continue;
                    if (!EditorUtility.IsPersistent(asset))
                    {
                        if (!built.copies.ContainsKey(asset)) built.unsaved[asset] = asset.hideFlags;
                    }
                    else built.changes.Note(asset);
                }
                string record = SyncRecordOf(avatar.gameObject);
                // Read before the build: a record that cannot be read stops the check before anything is changed.
                byte[] recorded = BackUpSyncRecord(record);
                ParameterCleanup.Previewing = true;
                ParameterCleanup.Preview = null;
                try
                {
                    // What it could not take down is said after the build, and the check goes on.
                    try
                    {
                        built.changes.Begin(built.folder);
                    }
                    catch (Exception e)
                    {
                        Debug.LogException(e);
                        built.Changes.unsearched = true;
                    }
                    using (new OverrideTemporaryDirectoryScope(built.folder))
                        built.Successful = AvatarProcessor.ProcessAvatar(clone, UploadPlatform()).Successful;
                }
                finally
                {
                    // The save guard stays on: what follows here and in Dispose puts things back.
                    built.changes.EndWatch();
                    ParameterCleanup.Previewing = false;
                    built.Cleanup = ParameterCleanup.Preview;
                    ParameterCleanup.Preview = null;
                    built.ReturnUnsaved();
                    built.RestoreSyncRecord(record, recorded);
                }
                return built;
            }
            catch
            {
                built.Dispose();
                throw;
            }
        }

        // An upload always builds for VRChat. NDMF's default platform is whatever its console's platform menu was left
        // on, and on another platform the passes made for VRChat (this package's cleanup among them) do not run.
        private static INDMFPlatformProvider UploadPlatform() =>
            PlatformRegistry.PlatformProviders.TryGetValue(WellKnownPlatforms.VRChatAvatar30, out var vrchat) ? vrchat : AmbientPlatform.DefaultPlatform;

        // A copy made by Instantiate points at the scene avatar's own menus, parameter lists, materials and meshes. The
        // build's passes change in place what is not saved as an asset (NDMF counts it as the build's own): Modular
        // Avatar clears menu parameters and swaps menu icons for temporary textures, adds to the parameter list and strips
        // vertex colours, Avatar Optimizer, TexTransTool and Light Limit Changer edit materials. So the copy gets its own
        // duplicate of each unsaved object it reaches through components and other unsaved objects. One it reaches only
        // through a saved asset cannot be repointed without changing that asset, and stays shared (ReturnUnsaved).
        private void Unshare(GameObject clone)
        {
            var map = new Dictionary<Object, Object>();
            foreach (var original in clone.ReferencedAssets(traverseSaved: false, includeScene: false).ToList())
            {
                if (!original || EditorUtility.IsPersistent(original) || !Duplicable(original)) continue;
                var copy = Object.Instantiate(original);
                if (!copy) continue;
                copy.name = original.name;
                copy.hideFlags = original.hideFlags;
                map[original] = copy;
            }
            if (map.Count == 0) return;
            foreach (var component in clone.GetComponentsInChildren<Component>(true))
                if (component && !(component is Transform)) Repoint(component, map);
            foreach (var copy in map.Values) Repoint(copy, map);
            foreach (var pair in map) copies[pair.Value] = pair.Key;
        }

        // Kinds whose duplicate is a faithful copy. A texture or mesh whose data the editor cannot read stays shared.
        private static bool Duplicable(Object o) =>
            o is ScriptableObject || o is Material || o is AnimationClip || o is AvatarMask || o is RuntimeAnimatorController ||
            o is AnimatorStateMachine || o is AnimatorState || o is AnimatorTransitionBase || o is BlendTree ||
            (o is Mesh mesh && mesh.isReadable) || (o is Texture texture && !(texture is RenderTexture) && texture.isReadable);

        // Points an object's references at the duplicates. A clip's object curves are reached through AnimationUtility.
        private static void Repoint(Object target, Dictionary<Object, Object> map)
        {
            if (target is AnimationClip clip)
            {
                foreach (var binding in AnimationUtility.GetObjectReferenceCurveBindings(clip))
                {
                    var keys = AnimationUtility.GetObjectReferenceCurve(clip, binding);
                    bool moved = false;
                    for (int i = 0; i < keys.Length; i++)
                        if (keys[i].value && map.TryGetValue(keys[i].value, out var to))
                        {
                            keys[i].value = to;
                            moved = true;
                        }
                    if (moved) AnimationUtility.SetObjectReferenceCurve(clip, binding, keys);
                }
                return;
            }
            using (var serialized = new SerializedObject(target))
            {
                bool moved = false;
                foreach (var property in serialized.ObjectProperties())
                {
                    var value = property.objectReferenceValue;
                    if (value && map.TryGetValue(value, out var to))
                    {
                        property.objectReferenceValue = to;
                        moved = true;
                    }
                }
                if (moved) serialized.ApplyModifiedPropertiesWithoutUndo();
            }
        }

        // NDMF files every unsaved object the copy points at under the build's folder, a shared one of the scene avatar's
        // among them, and deleting the folder would destroy it. Each is taken back out, as unsaved as it was; when one
        // cannot be, the folder is kept.
        private void ReturnUnsaved()
        {
            foreach (var pair in unsaved)
            {
                var asset = pair.Key;
                if (!asset) continue;
                try
                {
                    if (Made(asset)) AssetDatabase.RemoveObjectFromAsset(asset);
                    if (asset.hideFlags != pair.Value) asset.hideFlags = pair.Value;
                }
                catch (Exception e)
                {
                    Debug.LogException(e);
                }
                if (Made(asset)) stuck.Add(asset.name);
            }
            if (stuck.Count > 0) KeepFolder();
        }

        // The folder stays, renamed so that no sweep of leftover folders deletes it later, and the check says where it is.
        private void KeepFolder()
        {
            string kept = AssetDatabase.GenerateUniqueAssetPath("Assets/" + KeptPrefix + DateTime.Now.ToString("yyyyMMdd-HHmmss"));
            string error = AssetDatabase.MoveAsset(folder, kept);
            string names = string.Join(", ", stuck.Select(n => $"‘{n}’"));
            string why = $"씬에만 있는(에셋으로 저장하지 않은) {names}을(를) 점검용 임시 폴더에서 꺼내지 못했어요. 폴더를 지우면 아바타에서 사라져서 ";
            if (string.IsNullOrEmpty(error))
            {
                Open.Remove(folder);
                folder = kept;
                Problems.Add(why + $"‘{folder}’ 폴더로 남겼어요. 아바타에 계속 쓴다면 이 폴더를 지우지 마세요.");
            }
            else
            {
                Debug.LogWarning("[Assembly Checker] " + error);
                Kept.Add(folder);
                Problems.Add(why + $"‘{folder}’ 폴더를 지우지 않았어요. 이 이름의 폴더는 에디터를 다시 켤 때 지워지니, 그 전에 폴더 이름을 바꿔 주세요.");
            }
        }

        // The record a build of this avatar writes, or null when it writes none.
        private static string SyncRecordOf(GameObject avatar)
        {
            if (!avatar.GetComponentInChildren<ModularAvatarSyncParameterSequence>(true)) return null;
            string id = ParameterCleanup.BlueprintOf(avatar);
            return id == null || id.IndexOfAny(Path.GetInvalidFileNameChars()) >= 0 ? null : SyncRecords + "/" + id;
        }

        // This editor session, as SessionState keeps it: the same across script reloads, new after the editor restarts.
        private static string Session()
        {
            string session = SessionState.GetString(SessionKey, "");
            if (session.Length == 0) SessionState.SetString(SessionKey, session = Guid.NewGuid().ToString("N"));
            return session;
        }

        // Reads the record before the build and writes it to a file of its own first: should the editor stop before the
        // check puts it back, the next start does (RecoverSyncRecord).
        private static byte[] BackUpSyncRecord(string record)
        {
            if (record == null) return null;
            byte[] before = File.Exists(record) ? File.ReadAllBytes(record) : null;
            WriteBackup(Session(), record, before);
            return before;
        }

        private static void WriteBackup(string session, string record, byte[] before)
        {
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(SyncBackup));
                File.WriteAllText(SyncBackup, session + "\n" + record + "\n" + (before == null ? "-" : Convert.ToBase64String(before)));
            }
            catch (Exception e)
            {
                Debug.LogException(e);
            }
        }

        // Modular Avatar's Sync Parameter Sequence writes down the synced parameters of every build, and the next build
        // for the other platform lines its list up with that record. A check is not an upload: the record goes back to
        // what it was, or a Quest build would follow a list that was never uploaded for PC.
        private void RestoreSyncRecord(string record, byte[] before)
        {
            if (record == null) return;
            try
            {
                if (before == null)
                {
                    if (File.Exists(record)) File.Delete(record);
                }
                else if (!File.Exists(record) || !File.ReadAllBytes(record).SequenceEqual(before)) File.WriteAllBytes(record, before);
            }
            catch (Exception e)
            {
                Debug.LogException(e);
                // Marked as not put back, so the next check or start tries again.
                WriteBackup("-", record, before);
                Problems.Add("Modular Avatar의 Sync Parameter Sequence 기록을 점검 전으로 되돌리지 못했어요. 다른 플랫폼을 올리기 전에 주 플랫폼을 다시 업로드해 주세요.");
                return;
            }
            try
            {
                File.Delete(SyncBackup);
            }
            catch (Exception e)
            {
                Debug.LogException(e);
            }
        }

        // A check that did not finish (the editor stopped while it built) left the record as its build wrote it: the copy
        // made before goes back. A copy this session left after putting the record back is only removed, since a real
        // upload may have written the record since.
        private static void RecoverSyncRecord()
        {
            try
            {
                if (!File.Exists(SyncBackup)) return;
                string[] lines = File.ReadAllText(SyncBackup).Split('\n');
                if (lines.Length == 3 && lines[0] != Session() && lines[1].StartsWith(SyncRecords + "/", StringComparison.Ordinal))
                {
                    if (lines[2] != "-") File.WriteAllBytes(lines[1], Convert.FromBase64String(lines[2]));
                    else if (File.Exists(lines[1])) File.Delete(lines[1]);
                    Debug.LogWarning("[Assembly Checker] 지난 점검이 끝나기 전에 에디터가 닫혀서, Modular Avatar Sync Parameter Sequence 기록을 점검 전으로 되돌렸어요.");
                }
                File.Delete(SyncBackup);
            }
            catch (Exception e)
            {
                Debug.LogException(e);
            }
        }

        // At every start, before anything can be uploaded with the record a check left.
        [InitializeOnLoadMethod]
        private static void RecoverSyncRecordOnLoad() => RecoverSyncRecord();

        // A copy keeps the order of children, so the two hierarchies pair up child by child.
        private void Pair(Transform scene, Transform copy)
        {
            toScene[copy] = scene;
            toCopy[scene] = copy;
            for (int i = 0; i < Math.Min(scene.childCount, copy.childCount); i++) Pair(scene.GetChild(i), copy.GetChild(i));
        }

        // Each step in the finally of the one before: whatever goes wrong in one, the next ones still run, and the save
        // guard goes last, once nothing more is put back or deleted.
        public void Dispose()
        {
            try
            {
                if (Clone) Object.DestroyImmediate(Clone);
                Clone = null;
                if (scene.IsValid()) EditorSceneManager.ClosePreviewScene(scene);
            }
            finally
            {
                try
                {
                    // Only now that the checks have read the build: they see it as an upload makes it, the other tools'
                    // changes to the avatar's materials included. PutBack destroys its copies in its own finally.
                    changes.PutBack(folder);
                }
                catch (Exception e)
                {
                    Debug.LogException(e);
                    changes.Result.unsearched = true;
                }
                finally
                {
                    try
                    {
                        if (!string.IsNullOrEmpty(folder))
                        {
                            Open.Remove(folder);
                            // A folder that still holds a scene-only object is never deleted (KeepFolder).
                            if (stuck.Count == 0 && FolderName.IsMatch(Path.GetFileName(folder))) AssetDatabase.DeleteAsset(folder);
                        }
                        folder = null;
                    }
                    finally
                    {
                        if (guarding)
                        {
                            Saving = null;
                            guarding = false;
                        }
                        if (current == this) current = null;
                    }
                }
            }
        }

        // Whether a path lies in the folder of a build that is open: the only files the save guard lets be written.
        internal static bool InOpenBuild(string path) => Open.Any(f => path.StartsWith(f + "/", StringComparison.Ordinal));

        // Folders left by a check that did not finish (an editor crash): only this tool's names, none still in use and
        // none kept.
        private static void DeleteStaleFolders()
        {
            foreach (var stale in AssetDatabase.GetSubFolders("Assets")
                         .Where(f => FolderName.IsMatch(Path.GetFileName(f)) && !Open.Contains(f) && !Kept.Contains(f)))
                AssetDatabase.DeleteAsset(stale);
        }

        // Also when the editor loads, so a folder a crash left does not sit in Assets until the next check.
        [InitializeOnLoadMethod]
        private static void DeleteStaleFoldersOnLoad() => EditorApplication.delayCall += DeleteStaleFolders;

        // Whether the build made an object: it lies in the build's folder (the scene avatar's unsaved objects have been
        // taken back out of it), and is destroyed with it on Dispose.
        internal bool Made(Object asset) =>
            asset && !string.IsNullOrEmpty(folder) && AssetDatabase.GetAssetPath(asset).StartsWith(folder + "/", StringComparison.Ordinal);

        // Whether an object stands for one of the scene avatar's that is not saved as an asset: that object itself, or
        // the copy's duplicate of it.
        internal bool Unsaved(Object asset) => asset && (unsaved.ContainsKey(asset) || copies.ContainsKey(asset));

        internal static string PathOf(Transform root, Transform t)
        {
            var names = new List<string>();
            for (var at = t; at && at != root; at = at.parent) names.Add(at.name);
            names.Reverse();
            return string.Join("/", names);
        }

        // The path an object of the copy had before the build, or null for one the build made.
        internal string PathBefore(Transform built) => built && Before.TryGetValue(built, out var path) ? path : null;

        // What became of a scene object in the built copy, or null when the build removed it.
        internal Transform Built(Transform scene) => scene && toCopy.TryGetValue(scene, out var t) && t ? t : null;

        // The scene object an object of the copy came from, or null for one the build made.
        internal Transform InScene(Transform built) => built && toScene.TryGetValue(built, out var t) && t ? t : null;

        internal GameObject SceneObject(Component built)
        {
            var t = built ? InScene(built.transform) : null;
            return t ? t.gameObject : null;
        }

        // How to name an object of the copy for the user: its path before the build when it had one.
        internal string Label(Transform built)
        {
            if (!built) return "(없음)";
            string path = PathBefore(built);
            if (path != null) return path.Length == 0 ? Source.name : path;
            return PathOf(Clone.transform, built) + " (빌드에서 생김)";
        }

        internal IEnumerable<RuntimeAnimatorController> Controllers()
        {
            var descriptor = Clone.GetComponent<VRCAvatarDescriptor>();
            return descriptor ? ParameterUses.Controllers(descriptor) : Enumerable.Empty<RuntimeAnimatorController>();
        }

        private List<(AnimationClip Clip, Transform Root)> clips;

        // Every clip that can play on the built avatar, with the object its paths start from: the playable layers' clips
        // from the root, and the clips of any other Animator in the avatar from that Animator's object.
        internal IReadOnlyList<(AnimationClip Clip, Transform Root)> Clips()
        {
            if (clips != null) return clips;
            clips = Controllers().SelectMany(c => c.animationClips).Where(c => c).Distinct().Select(c => (c, Clone.transform)).ToList();
            foreach (var animator in Clone.GetComponentsInChildren<Animator>(true))
                if (animator.transform != Clone.transform && animator.runtimeAnimatorController)
                    clips.AddRange(animator.runtimeAnimatorController.animationClips.Where(c => c).Distinct().Select(c => (c, animator.transform)));
            return clips;
        }

        // The object a clip's binding path names, from the clip's root.
        internal static Transform Find(Transform root, string path) => path.Length == 0 ? root : root.Find(path);

    }

    // While a check is under way (its build, and putting back after it), the editor writes only the build's own files.
    // NDMF ends a build with AssetDatabase.SaveAssets(), which would write every asset with unsaved changes, the user's
    // among them, also one a pass marks as changed again or one that shares a file with an asset a pass changes; and
    // another tool's postprocessor can save while things are put back. What is held back stays unsaved, as it was.
    internal sealed class CheckSaveGuard : UnityEditor.AssetModificationProcessor
    {
        private static string[] OnWillSaveAssets(string[] paths) =>
            BuiltAvatar.Saving == null ? paths : paths.Where(BuiltAvatar.InOpenBuild).ToArray();
    }
}
#endif
