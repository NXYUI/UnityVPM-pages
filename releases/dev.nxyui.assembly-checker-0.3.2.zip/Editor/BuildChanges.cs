#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using nadena.dev.ndmf.util;
using UnityEditor;
using UnityEditorInternal;
using UnityEngine;
using VRC.SDK3.Avatars.ScriptableObjects;
using Debug = UnityEngine.Debug;
using Object = UnityEngine.Object;

namespace AssemblyChecker
{
    // What a check's build changes in the project outside its own folder, and what goes back. Other tools' NDMF plug-ins
    // run in the check's build as at upload. Some change saved assets in place: PCSS4VRC sets up the `_pcss` copy of
    // every lilToon material (render queue, shader, properties) and marks it as changed, ShellProtector adds to its
    // history and locks Poiyomi materials. Others write files of their own (ShellProtector's and SeeThroughHair's
    // Generated folders) or change import settings (ShellProtector, the avatar's textures). The save guard keeps all of
    // it from being written until everything here is over (CheckSaveGuard), but what stays changed in memory would
    // reach the disk with the next save. The rule for every case: the user's unsaved edits are never lost, and what
    // cannot be put back with certainty is left alone and said.
    // - The avatar's own saved materials, menus and parameter lists, and every saved material or clip the user had
    //   changed without saving, go back to what they were in memory before the check, each marked as changed or not as
    //   it was. When the build also wrote the asset's own file (not only imported it again), it is marked as changed so
    //   that the next save writes the earlier content back.
    // - A material or clip file the build changed in memory, that had no unsaved changes and whose file it did not
    //   write, gets the content of the file back.
    // - A ScriptableObject the build changed is another tool's settings or record (its runtime state and the files it
    //   wrote follow it), with or without unsaved changes before (a first check leaves one like that): left, and said.
    // - Other objects the user had changed without saving are only watched: when Unity counts them as changed again,
    //   the window says the build may have changed them, and they are left. Prefabs and files of several objects are
    //   left, and warned about.
    // - Files other tools wrote or deleted are only noted: they are what those tools also do at upload.
    // Every step is guarded: what could not be put back is said, and the check's results are never lost for it.
    internal sealed class BuildChanges
    {
        // What the window shows after a check and the Console keeps. Plain data, so a script reload keeps it with the
        // window's status.
        [Serializable]
        internal sealed class Report
        {
            // Asset paths: the avatar's own assets put back as they were in memory before the check.
            public List<string> restored = new List<string>();
            // Other materials and clips the user had changed without saving, put back as they were in memory (still unsaved).
            public List<string> restoredOther = new List<string>();
            // Assets put back in memory whose file the build also wrote: marked as changed, the next save writes them back.
            public List<string> rewritten = new List<string>();
            // Materials and clips that had no unsaved changes, given the content of their files again.
            public List<string> reloaded = new List<string>();
            // Other tools' own settings or record assets (ScriptableObjects) they changed: theirs, left as they are.
            public List<string> records = new List<string>();
            // Assets the build changed, or may have changed, that stay as it left them, each with why.
            public List<Kept> left = new List<Kept>();
            // Set when what other tools changed could not be looked at (another check was under way, or the search failed).
            public bool unsearched;
            // Files other tools wrote during the build (created, changed, or only imported again) and the ones they
            // deleted, outside the check's folder. New and changed files are not told apart: Unity writes a file through
            // a temporary one, so its creation time does not say when it was made.
            public List<string> written = new List<string>();
            public List<string> deleted = new List<string>();
            // What the snapshot before the build and the putting back after it took, for the tests' log.
            [NonSerialized] public double snapshotMs, putBackMs;

            internal bool Empty => restored.Count == 0 && restoredOther.Count == 0 && rewritten.Count == 0 && reloaded.Count == 0 &&
                                   records.Count == 0 && left.Count == 0 && !unsearched && written.Count == 0 && deleted.Count == 0;

            // Lines for under the status, each with a tooltip that has all the names.
            internal List<(string Text, string Tooltip)> Notes()
            {
                var notes = new List<(string, string)>();
                if (restored.Count > 0)
                    notes.Add(($"점검 빌드 중에 다른 도구가 이 아바타의 에셋 {restored.Count}개를 바꿔서 점검 전으로 되돌렸어요: {Names(restored)}.",
                        Tooltip(restored)));
                if (restoredOther.Count > 0)
                    notes.Add(($"점검 빌드 중에 다른 도구가 저장하지 않은 변경이 있던 다른 에셋 {restoredOther.Count}개도 바꿔서, 저장하지 않은 변경은 " +
                               $"그대로 두고 점검 전으로 되돌렸어요: {Names(restoredOther)}.", Tooltip(restoredOther)));
                if (rewritten.Count > 0)
                    notes.Add(($"점검 빌드 중에 다른 도구가 에셋 {rewritten.Count}개의 파일도 다시 써서, 내용은 점검 전으로 되돌리고 ‘바뀜’으로 표시했어요. " +
                               $"저장하면 점검 전 내용이 파일에 다시 들어가요: {Names(rewritten)}.", Tooltip(rewritten)));
                if (reloaded.Count > 0)
                    notes.Add(($"점검 빌드 중에 다른 도구가 바꾼 머티리얼과 애니메이션 클립 {reloaded.Count}개는 저장된 파일의 내용으로 되돌렸어요: {Names(reloaded)}.",
                        Tooltip(reloaded)));
                if (records.Count > 0)
                    notes.Add(($"점검 빌드 중에 다른 도구가 자기 설정이나 기록 에셋 {records.Count}개를 바꿨어요. 그 도구의 것이라 그대로 뒀어요.", Tooltip(records)));
                var files = written.Concat(deleted).ToList();
                if (files.Count > 0)
                {
                    var folders = files.GroupBy(FolderOf).Select(g => (Folder: g.Key, Count: g.Count()))
                        .OrderByDescending(g => g.Count).ThenBy(g => g.Folder, StringComparer.Ordinal).ToList();
                    string where = string.Join(", ", folders.Take(3).Select(g => $"{g.Folder} {g.Count}개")) +
                                   (folders.Count > 3 ? $" 외 폴더 {folders.Count - 3}곳" : "");
                    var kinds = new List<string>();
                    if (written.Count > 0) kinds.Add($"만들거나 고치거나 다시 가져온 파일 {written.Count}개");
                    if (deleted.Count > 0) kinds.Add($"지운 파일 {deleted.Count}개");
                    notes.Add(($"점검 빌드 중에 다른 도구가 파일 {files.Count}개를 만들거나 고치거나 지웠어요({string.Join(", ", kinds)}): {where}. " +
                               "지우거나 되돌리지 않았어요. 업로드할 때도 그 도구가 하는 일이에요.",
                        Tooltip(written.Concat(deleted.Select(p => p + " (지움)")).OrderBy(p => p, StringComparer.Ordinal).ToList())));
                }
                return notes;
            }

            // A warning when something the build changed, or may have changed, was left as it is, or null.
            internal string Warning()
            {
                if (left.Count == 0 && !unsearched) return null;
                var lines = new List<string>();
                if (left.Count > 0)
                {
                    lines.Add($"⚠ 점검 빌드 중에 다른 도구가 바꾼 에셋 {left.Count}개는 확실히 되돌릴 수 없어서 그대로 뒀어요. 다음에 저장하면 그 내용이 파일에 들어가요.");
                    lines.AddRange(left.Take(5).Select(k => $"· {Path.GetFileName(k.path)}: {k.why}"));
                    if (left.Count > 5) lines.Add($"· 외 {left.Count - 5}개 (Console 창에 모두 있어요)");
                }
                if (unsearched)
                    lines.Add("⚠ 이번 점검에서는 다른 도구가 바꾼 것을 살피지 못했어요. 저장하기 전에 바뀐 에셋이 없는지 확인해 주세요.");
                return string.Join("\n", lines);
            }

            // Everything, for the Console.
            internal string Summary()
            {
                var lines = new List<string>();
                void Add(string head, IEnumerable<string> items)
                {
                    var list = items.ToList();
                    if (list.Count > 0) lines.Add(head + ":\n  " + string.Join("\n  ", list));
                }
                Add("점검 전으로 되돌린 이 아바타의 에셋", restored);
                Add("점검 전으로 되돌린, 저장하지 않은 변경이 있던 다른 에셋", restoredOther);
                Add("내용을 점검 전으로 되돌리고 ‘바뀜’으로 표시한 에셋(파일도 다시 쓰임)", rewritten);
                Add("파일의 내용으로 되돌린 머티리얼·애니메이션 클립", reloaded);
                Add("다른 도구가 바꾼 자기 설정·기록 에셋(그대로 둠)", records);
                Add("그대로 둔 에셋", left.Select(k => $"{k.path}: {k.why}"));
                if (unsearched) lines.Add("다른 도구가 바꾼 것을 살피지 못했어요.");
                Add("다른 도구가 만들거나 고친 파일(그대로 둠)", written);
                Add("다른 도구가 지운 파일", deleted);
                return "[Assembly Checker] 점검 빌드 중에 다른 도구가 프로젝트를 바꿨어요.\n" + string.Join("\n", lines);
            }

            private static string Names(List<string> paths) =>
                string.Join(", ", paths.Take(3).Select(Path.GetFileName)) + (paths.Count > 3 ? $" 외 {paths.Count - 3}개" : "");

            private static string Tooltip(List<string> paths) =>
                string.Join("\n", paths.Take(30)) + (paths.Count > 30 ? $"\n… 외 {paths.Count - 30}개 (Console 창에 모두 있어요)" : "");
        }

        // An asset left as the build changed it, and why, in words for the window.
        [Serializable]
        internal sealed class Kept
        {
            public string path;
            public string why;
        }

        // The folder a file is counted under: its first three levels ("Assets/ShellProtector/Generated"), so that one
        // tool's output reads as one place, or its own folder when that is higher.
        internal static string FolderOf(string path)
        {
            var parts = path.Split('/');
            return string.Join("/", parts.Take(Math.Min(3, Math.Max(1, parts.Length - 1))));
        }

        // An asset as it was before the build: an Instantiate copy (references to scene-only objects included, which JSON
        // loses) for materials, clips and the avatar's menus and parameter lists; for another ScriptableObject its JSON,
        // so that no second instance of a tool's script runs. With how often Unity had counted it as changed, and
        // whether it had unsaved changes.
        private sealed class Snapshot
        {
            internal Object Asset;
            internal string Path;
            internal Object Copy;
            internal string Json;
            // False when the JSON would lose the asset's references to scene-only objects: then it is not put back.
            internal bool Faithful = true;
            // Only compared, never put back: another tool's ScriptableObject that already had unsaved changes (its
            // record, which its runtime state and its files follow; a first check leaves one like that).
            internal bool RecordOnly;
            internal int Count;
            internal bool Dirty, Own;
            // The asset's file before the build: when it was last written and how long it was (null when there is none).
            internal DateTime? FileTime;
            internal long FileLength;
        }

        // The check whose build is running, for the postprocessor (BuildFiles), or null.
        internal static BuildChanges Watching { get; private set; }
        // The check between its snapshot and the end of its putting back: another one in between is not tracked, so
        // that it cannot overwrite this one's state.
        private static BuildChanges active;

        internal readonly Report Result = new Report();
        private readonly HashSet<Object> own = new HashSet<Object>();
        private readonly List<Snapshot> snapshots = new List<Snapshot>();
        // Objects the user had changed without saving that are not taken down: how often Unity had counted them as changed.
        private readonly Dictionary<Object, int> counted = new Dictionary<Object, int>();
        // The saved objects that had unsaved changes before the build, by instance ID (null when they could not be listed).
        private HashSet<int> dirtyBefore;
        private readonly HashSet<string> written = new HashSet<string>(), deleted = new HashSet<string>();
        // The files the AssetDatabase imported during the build (written holds these and files written without an import).
        private readonly HashSet<string> heard = new HashSet<string>();
        private string folder;
        private DateTime started;
        private bool begun, done;

        // A saved asset the avatar uses, from the walk before the build: the kinds a plug-in can plausibly change in place.
        // Meshes and textures are left out (big, and edited on NDMF's own copies).
        internal void Note(Object asset)
        {
            if (asset is Material || asset is VRCExpressionsMenu || asset is VRCExpressionParameters) own.Add(asset);
        }

        // Right before the build: what the avatar's assets and the user's unsaved ones are, and from now on which files
        // are written. Refused while another check is under way: that one keeps its state, and this one runs untracked.
        internal void Begin(string buildFolder)
        {
            var clock = Stopwatch.StartNew();
            if (active != null && active != this)
            {
                Result.unsearched = true;
                return;
            }
            active = this;
            begun = true;
            folder = buildFolder;
            foreach (var asset in own) Take(asset, true, EditorUtility.IsDirty(asset));
            try
            {
                var dirty = Changed().ToList();
                dirtyBefore = new HashSet<int>(dirty.Select(o => o.GetInstanceID()));
                var oneObject = new Dictionary<string, bool>(StringComparer.Ordinal);
                foreach (var o in dirty)
                {
                    if (own.Contains(o)) continue;
                    string path = AssetDatabase.GetAssetPath(o);
                    if (!Saved(path)) continue;
                    try
                    {
                        if (o is Material || o is AnimationClip) Take(o, false, true);
                        else if (o is ScriptableObject && OneObject(path, oneObject)) TakeJson(o, path);
                        else counted[o] = EditorUtility.GetDirtyCount(o);
                    }
                    catch (Exception e)
                    {
                        Debug.LogException(e);
                        counted[o] = EditorUtility.GetDirtyCount(o);
                    }
                }
            }
            catch (Exception e)
            {
                // Then nothing can tell the build's changes from the user's: only the avatar's own assets go back, and
                // the window says that the rest could not be looked at.
                Debug.LogException(e);
                dirtyBefore = null;
            }
            started = DateTime.UtcNow;
            Watching = this;
            Result.snapshotMs = clock.Elapsed.TotalMilliseconds;
        }

        private void Take(Object asset, bool isOwn, bool dirty)
        {
            var snapshot = new Snapshot { Asset = asset, Own = isOwn, Dirty = dirty };
            try
            {
                snapshot.Path = AssetDatabase.GetAssetPath(asset);
                snapshot.Count = EditorUtility.GetDirtyCount(asset);
                Stat(snapshot);
                // A clip's copy does not read like the clip in JSON: it is compared with its own JSON from before, and
                // put back from it unless it points at scene-only objects (then from the copy).
                if (asset is AnimationClip)
                {
                    snapshot.Json = EditorJsonUtility.ToJson(asset);
                    snapshot.Faithful = !HoldsUnsaved(asset);
                }
                var copy = Object.Instantiate(asset);
                copy.name = asset.name;
                copy.hideFlags = HideFlags.HideAndDontSave;
                snapshot.Copy = copy;
            }
            catch (Exception e)
            {
                // Without a copy the asset cannot be put back: said only if the build changes it (PutBack).
                Debug.LogException(e);
            }
            snapshots.Add(snapshot);
        }

        private void TakeJson(Object asset, string path)
        {
            var snapshot = new Snapshot
            {
                Asset = asset, Path = path, Dirty = true, RecordOnly = true, Count = EditorUtility.GetDirtyCount(asset),
                Json = EditorJsonUtility.ToJson(asset),
            };
            Stat(snapshot);
            snapshots.Add(snapshot);
        }

        private static void Stat(Snapshot s)
        {
            if (!Saved(s.Path)) return;
            var file = new FileInfo(FileUtil.GetPhysicalPath(s.Path));
            if (!file.Exists) return;
            s.FileTime = file.LastWriteTimeUtc;
            s.FileLength = file.Length;
        }

        // Whether the asset's own file changed since the build started: written again (its time or its length), not only
        // imported again. A file written directly and never imported is noted with the files other tools changed.
        private bool FileChanged(Snapshot s)
        {
            if (s.FileTime == null) return false;
            var file = new FileInfo(FileUtil.GetPhysicalPath(s.Path));
            bool changed = !file.Exists || file.LastWriteTimeUtc != s.FileTime.Value || file.Length != s.FileLength;
            if (changed && file.Exists) written.Add(s.Path);
            return changed;
        }

        // Whether an object points at something not saved as an asset: JSON writes such a reference as nothing.
        private static bool HoldsUnsaved(Object o)
        {
            bool Unsaved(Object value) => value && !EditorUtility.IsPersistent(value);
            if (o is AnimationClip clip)
                return AnimationUtility.GetObjectReferenceCurveBindings(clip).Any(b => AnimationUtility.GetObjectReferenceCurve(clip, b).Any(k => Unsaved(k.value))) ||
                       AnimationUtility.GetAnimationEvents(clip).Any(e => Unsaved(e.objectReferenceParameter));
            using (var serialized = new SerializedObject(o))
                foreach (var property in serialized.ObjectProperties())
                    if (Unsaved(property.objectReferenceValue)) return true;
            return false;
        }

        private static bool OneObject(string path, Dictionary<string, bool> known)
        {
            if (!known.TryGetValue(path, out bool one)) known[path] = one = AssetDatabase.LoadAllAssetsAtPath(path).Length == 1;
            return one;
        }

        private static bool Saved(string path) =>
            !string.IsNullOrEmpty(path) && (path.StartsWith("Assets/", StringComparison.Ordinal) || path.StartsWith("Packages/", StringComparison.Ordinal));

        // Right after the build: files written from now on are not the build's.
        internal void EndWatch()
        {
            if (Watching == this) Watching = null;
        }

        // Files imported, deleted or moved while the build runs (BuildFiles), outside the check's own folder.
        internal void Heard(string[] imported, string[] removed, string[] moved, string[] movedFrom)
        {
            foreach (var path in imported.Concat(moved))
                if (Outside(path) && !AssetDatabase.IsValidFolder(path))
                {
                    written.Add(path);
                    heard.Add(path);
                }
            foreach (var path in removed.Concat(movedFrom))
                if (Outside(path)) deleted.Add(path);
        }

        private bool Outside(string path) =>
            !string.IsNullOrEmpty(path) && (string.IsNullOrEmpty(folder) || path != folder && !path.StartsWith(folder + "/", StringComparison.Ordinal));

        // Whether the build deleted the file or wrote it (its write time is after the build started; an import alone
        // leaves the file as it was). A file written directly and never imported is noted with the files.
        private bool Written(string path)
        {
            if (deleted.Contains(path)) return true;
            string file = FileUtil.GetPhysicalPath(path);
            if (!File.Exists(file) || File.GetLastWriteTimeUtc(file) < started) return false;
            written.Add(path);
            return true;
        }

        // After the checks have read the build (BuiltAvatar.Dispose, while the save guard is still on): the results show
        // the build as an upload makes it, and then the project goes back. First what holds the avatar's and the user's
        // work, then only looking, then the rest. `buildFolder` is where the build's own files are now (it may have been
        // kept under another name).
        internal void PutBack(string buildFolder)
        {
            if (!begun || done) return;
            done = true;
            var clock = Stopwatch.StartNew();
            EndWatch();
            if (!string.IsNullOrEmpty(buildFolder)) folder = buildFolder;
            try
            {
                foreach (var snapshot in snapshots) PutBack(snapshot);
                try
                {
                    Recount();
                }
                catch (Exception e)
                {
                    Debug.LogException(e);
                    Result.unsearched = true;
                }
                try
                {
                    ReadAgain();
                }
                catch (Exception e)
                {
                    Debug.LogException(e);
                    Result.unsearched = true;
                }
                try
                {
                    NoteFiles();
                }
                catch (Exception e)
                {
                    Debug.LogException(e);
                }
            }
            finally
            {
                foreach (var snapshot in snapshots)
                    try
                    {
                        if (snapshot.Copy) Object.DestroyImmediate(snapshot.Copy);
                    }
                    catch (Exception e)
                    {
                        Debug.LogException(e);
                    }
                if (active == this) active = null;
                Result.putBackMs = clock.Elapsed.TotalMilliseconds;
                try
                {
                    if (!Result.Empty) Debug.Log(Result.Summary());
                }
                catch (Exception e)
                {
                    Debug.LogException(e);
                }
            }
        }

        // Back to what it was in memory when the build changed it; then marked as changed or not, as it was. An asset the
        // build only marked as changed is unmarked, so the next save does not write it. One whose file the build wrote
        // is marked as changed: the memory is as before the check, its file is not, and saving writes it back.
        private void PutBack(Snapshot s)
        {
            if (!s.Asset) return; // gone in the build: a deleted file, noted with the files
            string path = s.Path ?? AssetDatabase.GetAssetPath(s.Asset);
            try
            {
                bool rewrite = FileChanged(s);
                // A file written directly and never imported: the AssetDatabase still takes it for what it was, so a save
                // would skip the asset and leave the tool's file. It is imported first (the save guard is on), which
                // reloads the object from that file, and then put back like any other.
                if (rewrite && !s.RecordOnly && !heard.Contains(path) && File.Exists(FileUtil.GetPhysicalPath(path)))
                {
                    AssetDatabase.ImportAsset(path);
                    if (!s.Asset) return;
                }
                bool recounted = EditorUtility.GetDirtyCount(s.Asset) != s.Count;
                // Unity counts every change to a material, its setters' too: one it did not count, whose file was not
                // written, is as it was and is not compared (a few hundred materials stay cheap). A ScriptableObject's
                // fields change uncounted, and a clip is always compared.
                if (!recounted && !rewrite && s.Asset is Material) return;
                bool copied = !ReferenceEquals(s.Copy, null);
                if (copied && !s.Copy) throw new InvalidOperationException("The copy of " + path + " taken before the check is gone.");
                string was;
                if (s.Json != null) was = Comparable(s.Asset, s.Json);
                else if (copied) was = Json(s.Copy, s.Asset.hideFlags);
                else
                {
                    if (recounted || rewrite) Keep(path, "점검 전 상태를 담아 두지 못해서 되돌리지 못했어요. Console 창에 자세한 내용이 있어요.");
                    return;
                }
                bool changed = Json(s.Asset) != was;
                if (s.RecordOnly)
                {
                    // Another tool's record: said when the build changed it, and left as it is.
                    if (changed) Result.records.Add(path);
                    return;
                }
                if (changed)
                {
                    // From the JSON when it keeps everything, else from the copy; a JSON alone that would lose references
                    // to scene-only objects is not used.
                    if (s.Json != null && s.Faithful) EditorJsonUtility.FromJsonOverwrite(s.Json, s.Asset);
                    else if (copied) EditorUtility.CopySerialized(s.Copy, s.Asset);
                    else
                    {
                        Keep(path, "씬에만 있는 오브젝트를 가리키는 에셋이라 되돌리지 않았어요.");
                        return;
                    }
                    if (Json(s.Asset) != was)
                    {
                        // Left marked as changed: it is not what it was.
                        EditorUtility.SetDirty(s.Asset);
                        Keep(path, "되돌렸지만 점검 전과 같아지지 않았어요.");
                        return;
                    }
                }
                if (rewrite)
                {
                    EditorUtility.SetDirty(s.Asset);
                    Result.rewritten.Add(path);
                    return;
                }
                if (changed) (s.Own ? Result.restored : Result.restoredOther).Add(path);
                if (s.Dirty) EditorUtility.SetDirty(s.Asset);
                else if (EditorUtility.IsDirty(s.Asset)) EditorUtility.ClearDirty(s.Asset);
            }
            catch (Exception e)
            {
                Debug.LogException(e);
                Keep(path, "되돌리다가 오류가 났어요. Console 창에 자세한 내용이 있어요.");
            }
        }

        private static string Json(Object asset) => Comparable(asset, EditorJsonUtility.ToJson(asset));

        // A copy as JSON, read with the asset's hide flags: hidden and kept from unloading is all that tells our copy
        // from the asset in JSON.
        private static string Json(Object copy, HideFlags flags)
        {
            var own = copy.hideFlags;
            copy.hideFlags = flags;
            try
            {
                return Comparable(copy, EditorJsonUtility.ToJson(copy));
            }
            finally
            {
                copy.hideFlags = own;
            }
        }

        // JSON to compare by. A clip's carries the bindings Unity works out from its curves when it is first used
        // (m_ClipBindingConstant): empty in a copy or a clip just read from its file, filled in one that played. They are
        // not the clip's content and are left out.
        private static string Comparable(Object o, string json)
        {
            if (!(o is AnimationClip)) return json;
            const string key = "\"m_ClipBindingConstant\":";
            int start = json.IndexOf(key, StringComparison.Ordinal);
            if (start < 0) return json;
            int at = start + key.Length, depth = 0;
            bool quoted = false;
            for (; at < json.Length; at++)
            {
                char c = json[at];
                if (quoted)
                {
                    if (c == '\\') at++;
                    else if (c == '"') quoted = false;
                }
                else if (c == '"') quoted = true;
                else if (c == '{' || c == '[') depth++;
                else if ((c == '}' || c == ']') && --depth == 0) break;
            }
            return at < json.Length ? json.Remove(start, at + 1 - start) : json;
        }

        // Objects the user had changed without saving that are not taken down (controllers, prefabs, files of several
        // objects): only looked at. One Unity counted as changed again may have been changed by the build; it is left.
        private void Recount()
        {
            var files = new SortedSet<string>(StringComparer.Ordinal);
            foreach (var pair in counted)
                if (pair.Key && EditorUtility.GetDirtyCount(pair.Key) != pair.Value) files.Add(AssetDatabase.GetAssetPath(pair.Key));
            foreach (var path in files) Keep(path, "점검 전부터 저장하지 않은 변경이 있던 에셋이라 건드리지 않았어요. 빌드가 바꿨을 수 있어요.");
        }

        // Saved objects marked as changed now that were not before the build, by file. A file the build wrote or deleted
        // is that tool's output (noted with the files), and one that also holds the user's unsaved work is not touched.
        // A file of one material or clip still holds what the object was before the check, and the object gets its
        // content back, in place: other tools, a locked Inspector or a preview keep pointing at it. A reimport would not
        // do it (Unity keeps an asset with unsaved changes as it is in memory), and unloading it would pull it from under
        // them. ScriptableObjects are the tools' own settings or records, left; prefabs and other files are left too.
        private void ReadAgain()
        {
            if (dirtyBefore == null)
            {
                Result.unsearched = true;
                return;
            }
            var taken = new HashSet<Object>(snapshots.Select(s => s.Asset).Where(a => a));
            var byFile = new SortedDictionary<string, List<Object>>(StringComparer.Ordinal);
            foreach (var o in Changed())
            {
                if (dirtyBefore.Contains(o.GetInstanceID()) || taken.Contains(o)) continue;
                string path = AssetDatabase.GetAssetPath(o);
                if (!Outside(path) || !Saved(path)) continue;
                if (!byFile.TryGetValue(path, out var objects)) byFile[path] = objects = new List<Object>();
                objects.Add(o);
            }
            foreach (var pair in byFile) ReadAgain(pair.Key);
        }

        private void ReadAgain(string path)
        {
            try
            {
                if (Written(path)) return;
                var all = AssetDatabase.LoadAllAssetsAtPath(path);
                if (all.Any(o => o && dirtyBefore.Contains(o.GetInstanceID())))
                {
                    Keep(path, "같은 파일에 점검 전부터 저장하지 않은 변경이 있어서 건드리지 않았어요.");
                    return;
                }
                var main = AssetDatabase.GetMainAssetTypeAtPath(path);
                if (main != null && typeof(ScriptableObject).IsAssignableFrom(main))
                {
                    Result.records.Add(path);
                    return;
                }
                if (path.EndsWith(".prefab", StringComparison.OrdinalIgnoreCase))
                {
                    Keep(path, "프리팹은 다시 읽어 들이지 않아요. 열어 둔 프리팹 편집 화면이나 인스턴스의 변경이 있을 수 있어요.");
                    return;
                }
                if (all.Length != 1)
                {
                    Keep(path, "여러 에셋이 든 파일이라 다시 읽어 들이지 않았어요.");
                    return;
                }
                if (!(all[0] is Material || all[0] is AnimationClip))
                {
                    Keep(path, "이 종류의 에셋은 다시 읽어 들이지 않아요.");
                    return;
                }
                string why = FromFile(all[0], FileUtil.GetPhysicalPath(path));
                if (why == null) Result.reloaded.Add(path);
                else Keep(path, why);
            }
            catch (Exception e)
            {
                Debug.LogException(e);
                Keep(path, "다시 읽어 들이다가 오류가 났어요. Console 창에 자세한 내용이 있어요.");
            }
        }

        // For the tests: called on the live object between taking the file's content and checking it, to make that fail.
        internal static Action<Object> Reading;

        // The live object gets the content of a copy read from its file outside the AssetDatabase, and is no longer marked
        // as changed. The copy's JSON is taken first and the copy destroyed before the check, so that nothing pointing at
        // it can pass. When the live object does not match, or anything fails on the way, it goes back to what the build
        // left, still marked as changed. Returns why it was not put back, or null.
        private static string FromFile(Object live, string file)
        {
            var read = InternalEditorUtility.LoadSerializedFileAndForget(file);
            Object built = null;
            void LetGo()
            {
                for (int i = 0; i < read.Length; i++)
                {
                    if (read[i]) Object.DestroyImmediate(read[i]);
                    read[i] = null;
                }
            }
            try
            {
                var from = read.FirstOrDefault(o => o && o.GetType() == live.GetType());
                if (!from) throw new InvalidOperationException("Nothing of type " + live.GetType().Name + " was read from " + file + ".");
                string want = Json(from, live.hideFlags);
                built = Object.Instantiate(live);
                built.name = live.name;
                built.hideFlags = HideFlags.HideAndDontSave;
                string why;
                try
                {
                    EditorUtility.CopySerialized(from, live);
                    LetGo();
                    Reading?.Invoke(live);
                    if (Json(live) == want)
                    {
                        EditorUtility.ClearDirty(live);
                        return null;
                    }
                    why = "파일의 내용을 넣어도 파일과 같아지지 않아서, 빌드가 바꾼 그대로 뒀어요.";
                }
                catch (Exception e)
                {
                    Debug.LogException(e);
                    why = "파일의 내용으로 되돌리다가 오류가 나서, 빌드가 바꾼 그대로 뒀어요. Console 창에 자세한 내용이 있어요.";
                }
                EditorUtility.CopySerialized(built, live);
                EditorUtility.SetDirty(live);
                return why;
            }
            finally
            {
                if (built) Object.DestroyImmediate(built);
                LetGo();
            }
        }

        // The files. One deleted and written again counts as written; a folder that went with its files is not a file
        // of its own.
        private void NoteFiles()
        {
            Result.written = written.OrderBy(p => p, StringComparer.Ordinal).ToList();
            var all = written.Concat(deleted).ToList();
            Result.deleted = deleted.Where(p => !written.Contains(p) && Path.HasExtension(p) && !all.Any(o => o.StartsWith(p + "/", StringComparison.Ordinal)))
                .OrderBy(p => p, StringComparer.Ordinal).ToList();
        }

        // Every loaded saved object that is marked as changed.
        private static IEnumerable<Object> Changed() =>
            Resources.FindObjectsOfTypeAll(typeof(Object)).Where(o => o && EditorUtility.IsPersistent(o) && EditorUtility.IsDirty(o));

        private void Keep(string path, string why) => Result.left.Add(new Kept { path = string.IsNullOrEmpty(path) ? "(이름 없는 에셋)" : path, why = why });
    }

    // Hears what the AssetDatabase imports, deletes and moves while a check builds (BuildChanges.Watching). Only the
    // callback for all assets: it changes no import, so adding this class reimports nothing.
    internal sealed class BuildFiles : AssetPostprocessor
    {
        private static void OnPostprocessAllAssets(string[] imported, string[] deleted, string[] moved, string[] movedFrom)
        {
            var watching = BuildChanges.Watching;
            if (watching == null) return;
            try
            {
                watching.Heard(imported, deleted, moved, movedFrom);
            }
            catch (Exception e)
            {
                Debug.LogException(e);
            }
        }
    }
}
#endif
