using System.Collections.Generic;
using nadena.dev.ndmf;
using UnityEngine;

namespace AssemblyChecker
{
    // Turns the Assembly Checker's parameter cleanup on for one avatar, with its exceptions. The build cleans up only
    // when the avatar root has this component and its checkbox is on; without it the parameters stay as they are.
    // Editor-only: it is read during the build and never uploaded.
    [DisallowMultipleComponent]
    [AddComponentMenu("NXYUI/Assembly Checker")]
    public sealed class AssemblyCheckerSettings : MonoBehaviour, INDMFEditorOnly
    {
        // The switch of 0.1.0, when the cleanup ran without this component. A component saved with it off stays off
        // until it is turned on again (the component's checkbox is the switch now).
        [HideInInspector] public bool removeUnusedParameters = true;

        [Tooltip("지우지 않을 파라미터 이름이에요. 끝에 *를 붙이면 그 이름으로 시작하는 파라미터를 모두 남겨요.")]
        public List<string> keepParameters = new List<string>();

        // Unity shows the on/off checkbox only on a component with a message like this one.
        private void OnEnable() { }

        // On: the checkbox is on (and the old switch was not turned off).
        public bool CleansUp => enabled && removeUnusedParameters;
    }
}
