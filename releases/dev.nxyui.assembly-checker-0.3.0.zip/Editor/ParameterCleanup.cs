#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using nadena.dev.modular_avatar.core;
using nadena.dev.ndmf;
using nadena.dev.ndmf.localization;
using UnityEditor;
using UnityEditor.Animations;
using UnityEditor.SceneManagement;
using UnityEngine;
using VRC.Dynamics;
using VRC.SDK3.Avatars.Components;
using VRC.SDK3.Avatars.ScriptableObjects;
using VRC.SDK3.Dynamics.PhysBone.Components;
using Object = UnityEngine.Object;

[assembly: ExportsPlugin(typeof(AssemblyChecker.AssemblyCheckerPlugin))]

namespace AssemblyChecker
{
    public sealed class AssemblyCheckerPlugin : Plugin<AssemblyCheckerPlugin>
    {
        public override string QualifiedName => "dev.nxyui.assembly-checker";
        public override string DisplayName => "Assembly Checker";

        protected override void Configure()
        {
            InPhase(BuildPhase.Resolving).Run("Read parameter cleanup settings", ParameterCleanup.ReadSettings);
            // Last among the optimizations, so the layers and menus other tools leave are final.
            InPhase(BuildPhase.Optimizing)
                .AfterPlugin("nadena.dev.modular-avatar")
                .AfterPlugin("com.anatawa12.avatar-optimizer")
                .AfterPlugin("net.rs64.tex-trans-tool")
                .Run("Remove unused parameters", ParameterCleanup.Run);
        }
    }

    // Removes the expression parameters nothing in the built avatar uses: no animator reads or writes them, no menu
    // control sets them, no Contact, PhysBone or Raycast drives them, and no other component names them. Names that may
    // be used from outside the avatar (OSC, face tracking) and the avatar's exceptions are kept, and so are the synced
    // ones of an avatar whose PC and Quest sync order Modular Avatar lines up. Each build leaves a report per platform.
    internal static class ParameterCleanup
    {
        // Kept by default even when nothing in the avatar uses them: OSC and face tracking set them from outside. A
        // name only an OSC program uses that starts with none of these cannot be told from an unused one; the window
        // says so next to the list of what goes.
        internal static readonly string[] OutsideNames = { "FT/*", "v2/*", "OSC*", "VRCOSC*", "VRCFT*" };

        private static readonly HashSet<string> Builtin = new HashSet<string>
        {
            "IsLocal", "PreviewMode", "Viseme", "Voice", "GestureLeft", "GestureRight", "GestureLeftWeight",
            "GestureRightWeight", "AngularY", "VelocityX", "VelocityY", "VelocityZ", "VelocityMagnitude", "Upright",
            "Grounded", "Seated", "AFK", "TrackingType", "VRMode", "MuteSelf", "InStation", "Earmuffs", "IsOnFriendsList",
            "AvatarVersion", "IsAnimatorEnabled", "ScaleModified", "ScaleFactor", "ScaleFactorInverse",
            "EyeHeightAsMeters", "EyeHeightAsPercent",
        };

        internal sealed class Settings
        {
            // KeepSynced: MA Sync Parameter Sequence pads one platform's list with the other's parameters, which this
            // build does not use; removing them would shift the sync order between PC and Quest.
            public bool Read, Enabled = true, KeepSynced;
            // VRCFury components were on the avatar when the build began (VRCFury takes them off when it runs).
            public bool VRCFury;
            public List<string> Keep = new List<string>();
        }

        [Serializable]
        internal sealed class Entry
        {
            public string name, type, reason;
            // Synced bits the parameter takes (0 when it is not synced).
            public int bits;
        }

        [Serializable]
        internal sealed class Report
        {
            public string avatar, time, platform;
            // enabled: the avatar's switch; applied: parameters were removed in this build.
            public bool enabled, applied;
            // Why nothing was looked at, or empty.
            public string skipped = "";
            public int bitsBefore, bitsAfter;
            // The synced parameters the build ends with, in order, and what each takes on the wire ("Bool", "Int 4비트"):
            // PC and Quest must match in both.
            public List<string> synced = new List<string>();
            public List<string> syncedKinds = new List<string>();
            public List<Entry> removed = new List<Entry>();
            public List<Entry> kept = new List<Entry>();
            // vrcfury: the avatar had VRCFury components when the build began. vrcfuryPending: they were still there when
            // the cleanup looked, so VRCFury had not run (the checker's own build never runs it): what VRCFury adds or
            // uses is not in this report.
            public bool vrcfury, vrcfuryPending;
            // Made by a build in Play mode, which uploads nothing.
            public bool play;
        }

        // Set by the window while it builds a copy: the report then goes to Preview, not to the last build's report.
        internal static bool Previewing;
        internal static Report Preview;

        internal static readonly string[] Platforms = { "PC", "Android", "iOS" };

        // A Play mode build's report is filed apart from an upload's, so that playing never replaces what was uploaded.
        private static string KeyOf(string record, string platform, bool play) =>
            $"NXYUI.AssemblyChecker.Cleanup:{platform}:{record}" + (play ? ":play" : "");

        // An avatar's blueprint ID, or null before it has one.
        internal static string BlueprintOf(GameObject avatar)
        {
            var pipeline = avatar ? avatar.GetComponent<VRC.Core.PipelineManager>() : null;
            return pipeline && !string.IsNullOrWhiteSpace(pipeline.blueprintId) ? pipeline.blueprintId : null;
        }

        // What an avatar's reports are filed under: its blueprint ID, which the PC and Quest versions of one avatar
        // share whatever their objects are called and which two avatars of one name do not; its name before it has one.
        private static string RecordOf(GameObject avatar) =>
            BlueprintOf(avatar) is string id ? "id:" + id : "name:" + Clean(avatar.name);

        // The platform a build is for, as the SDK's build target sets it.
        private static string CurrentPlatform() =>
            EditorUserBuildSettings.activeBuildTarget == BuildTarget.Android ? "Android" :
            EditorUserBuildSettings.activeBuildTarget == BuildTarget.iOS ? "iOS" : "PC";

        // The VRChat SDK builds a copy named "<avatar>(Clone)".
        internal static string Clean(string name) =>
            name.EndsWith("(Clone)", StringComparison.Ordinal) ? name.Substring(0, name.Length - 7).TrimEnd() : name;

        // The report of the last build of this avatar for a platform in this editor session, or null: the last one outside
        // Play mode (an upload), and the last Play mode one only when there is none.
        internal static Report LastBuild(GameObject avatar, string platform)
        {
            string record = RecordOf(avatar);
            string json = SessionState.GetString(KeyOf(record, platform, false), "");
            if (string.IsNullOrEmpty(json)) json = SessionState.GetString(KeyOf(record, platform, true), "");
            return string.IsNullOrEmpty(json) ? null : JsonUtility.FromJson<Report>(json);
        }

        internal static void Store(GameObject avatar, Report report) =>
            SessionState.SetString(KeyOf(RecordOf(avatar), report.platform, report.play), JsonUtility.ToJson(report));

        // Whether another avatar in the open scenes files its reports with this one's: neither has a blueprint ID and
        // both have one name, so whose build a record is cannot be told.
        internal static bool SharesRecord(GameObject avatar) =>
            avatar && BlueprintOf(avatar) == null && Object.FindObjectsOfType<VRCAvatarDescriptor>(true).Any(d =>
                d && d.gameObject != avatar && !EditorUtility.IsPersistent(d) && d.gameObject.scene.IsValid() &&
                !EditorSceneManager.IsPreviewScene(d.gameObject.scene) && RecordOf(d.gameObject) == RecordOf(avatar));

        private static readonly Lazy<MethodInfo> AlignMobile = new Lazy<MethodInfo>(() =>
            AppDomain.CurrentDomain.GetAssemblies().Select(a => a.GetType("VF.Menu.AlignMobileParamsMenuItem")).FirstOrDefault(t => t != null)
                ?.GetMethod("Get", BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static, null, Type.EmptyTypes, null));

        // Whether VRCFury lines a mobile upload up with the last desktop upload (its "Align mobile parameters", on unless
        // turned off in its menu). Its ParameterPlatformAlignmentService then gives the mobile build the desktop's synced
        // parameters in their order, with their types and bit widths, a filler for each one mobile lacks, and stops
        // syncing what only mobile has. It runs after this cleanup, so the lists here are from before it.
        internal static bool VRCFuryAlignsMobile()
        {
            try
            {
                var get = AlignMobile.Value;
                return get != null && get.ReturnType == typeof(bool) && (bool)get.Invoke(null, null);
            }
            catch (Exception)
            {
                return false;
            }
        }

        // The settings component is editor-only: it is read before the build removes it.
        internal static void ReadSettings(BuildContext context)
        {
            var settings = context.GetState<Settings>();
            var component = context.AvatarRootObject.GetComponent<AssemblyCheckerSettings>();
            settings.Read = true;
            // Opt-in: only an avatar whose root has the component, turned on.
            settings.Enabled = component && component.CleansUp;
            settings.KeepSynced = context.AvatarRootObject.GetComponentInChildren<ModularAvatarSyncParameterSequence>(true);
            settings.VRCFury = (settings.Enabled || Previewing) && AssemblyChecks.HasVRCFury(context.AvatarRootObject);
            // As written: Matches also compares without the spaces at either end.
            settings.Keep = component && component.keepParameters != null
                ? component.keepParameters.Where(k => !string.IsNullOrWhiteSpace(k)).ToList()
                : new List<string>();
        }

        internal static void Run(BuildContext context)
        {
            var settings = context.GetState<Settings>();
            if (!settings.Read) ReadSettings(context);
            // Off: a real build leaves the avatar alone (no analysis, no notes in the console). The checker's own build
            // of a copy still looks, to show what turning it on would remove.
            if (!settings.Enabled && !Previewing) return;
            var root = context.AvatarRootObject;
            var report = new Report
            {
                avatar = Clean(root.name), time = DateTime.Now.ToString("yyyy-MM-dd HH:mm"), platform = CurrentPlatform(), enabled = settings.Enabled,
                vrcfury = settings.VRCFury, vrcfuryPending = AssemblyChecks.HasVRCFury(root), play = EditorApplication.isPlayingOrWillChangePlaymode,
            };
            try
            {
                var remove = Analyze(root, settings.Keep, settings.KeepSynced, report);
                if (string.IsNullOrEmpty(report.skipped) && settings.Enabled && remove.Count > 0)
                {
                    var descriptor = root.GetComponent<VRCAvatarDescriptor>();
                    var source = descriptor.expressionParameters;
                    // A copy: the list may be the avatar's own asset.
                    var copy = Object.Instantiate(source);
                    copy.name = source.name;
                    copy.parameters = source.parameters.Where(p => p == null || !remove.Contains(p.name)).ToArray();
                    context.AssetSaver.SaveAsset(copy);
                    descriptor.expressionParameters = copy;
                    report.applied = true;
                }
                var final = root.GetComponent<VRCAvatarDescriptor>();
                if (final && final.expressionParameters && final.expressionParameters.parameters != null)
                {
                    var synced = final.expressionParameters.parameters.Where(p => p != null && p.networkSynced && !string.IsNullOrEmpty(p.name)).ToList();
                    report.synced = synced.Select(p => p.name).ToList();
                    report.syncedKinds = synced.Select(Kind).ToList();
                }
                Announce(report);
            }
            finally
            {
                if (Previewing) Preview = report;
                else Store(root, report);
            }
        }

        // Sorts the avatar's expression parameters into used, unused and kept, and returns the names to remove.
        internal static HashSet<string> Analyze(GameObject root, IList<string> keep, bool keepSynced, Report report)
        {
            var remove = new HashSet<string>();
            var descriptor = root.GetComponent<VRCAvatarDescriptor>();
            var list = descriptor && descriptor.customExpressions ? descriptor.expressionParameters : null;
            if (!list || list.parameters == null)
            {
                report.skipped = "이 아바타에는 Expression Parameters가 없어요.";
                return remove;
            }
            var names = new HashSet<string>(list.parameters.Where(p => p != null && !string.IsNullOrEmpty(p.name)).Select(p => p.name));
            var uses = ParameterUses.Collect(root, descriptor, names);
            report.bitsBefore = Bits(list.parameters);
            foreach (var p in list.parameters)
            {
                if (p == null || string.IsNullOrEmpty(p.name) || uses.Used.Contains(p.name)) continue;
                var entry = new Entry { name = p.name, type = p.valueType.ToString(), bits = p.networkSynced ? Cost(p) : 0 };
                if (uses.Named.TryGetValue(p.name, out var where))
                    entry.reason = "다른 컴포넌트가 이름으로 가리켜요: " + string.Join(", ", where.Take(3)) + (where.Count > 3 ? $" 외 {where.Count - 3}곳" : "");
                else if (Builtin.Contains(p.name)) entry.reason = "VRChat 기본 파라미터 이름이에요.";
                else if (Matches(p.name, OutsideNames)) entry.reason = "OSC·페이스 트래킹처럼 아바타 밖에서 쓰일 수 있는 이름이에요.";
                else if (Matches(p.name, keep)) entry.reason = "예외 목록에 있어요.";
                else if (keepSynced && p.networkSynced)
                    entry.reason = "MA Sync Parameter Sequence가 PC·Quest의 동기화 순서를 맞추고 있어서 동기화 파라미터는 지우지 않아요.";
                if (entry.reason != null)
                {
                    if (report.kept.All(k => k.name != entry.name)) report.kept.Add(entry);
                    continue;
                }
                entry.reason = "애니메이터, 메뉴, Contact·PhysBone·Raycast 어디에서도 쓰지 않아요.";
                if (report.removed.All(r => r.name != entry.name)) report.removed.Add(entry);
                remove.Add(p.name);
            }
            // A name listed twice goes only when every entry of it can go.
            var kept = new HashSet<string>(report.kept.Select(k => k.name));
            report.removed.RemoveAll(e => kept.Contains(e.name));
            remove.ExceptWith(kept);
            report.bitsAfter = Bits(list.parameters.Where(p => p != null && !remove.Contains(p.name)));
            return remove;
        }

        // The synced bits of one parameter as the SDK counts them: 1 for a Bool, and for an Int or Float the bit width
        // set on the parameter (2 to 8, since SDK 3.10.6), not always 8.
        internal static int Cost(VRCExpressionParameters.Parameter p) => p.GetBitWidthByType();

        // What a synced parameter takes on the wire.
        internal static string Kind(VRCExpressionParameters.Parameter p) =>
            p.valueType == VRCExpressionParameters.ValueType.Bool ? "Bool" : $"{p.valueType} {Cost(p)}비트";

        internal static int Bits(IEnumerable<VRCExpressionParameters.Parameter> parameters) =>
            parameters.Where(p => p != null && p.networkSynced && !string.IsNullOrEmpty(p.name)).Sum(Cost);

        // "Name" matches itself; "Name*" matches every name that starts with "Name". Spaces at either end count for nothing
        // on either side: a parameter whose name ends in a space is kept by the exception typed without it, and the other
        // way round. A parameter kept by mistake costs bits; one removed by mistake breaks the uploaded avatar.
        internal static bool Matches(string name, IEnumerable<string> patterns) =>
            patterns != null && !string.IsNullOrEmpty(name) && patterns.Any(p => !string.IsNullOrWhiteSpace(p) && (Match(name, p) || Match(name.Trim(), p.Trim())));

        private static bool Match(string name, string pattern) =>
            pattern.EndsWith("*", StringComparison.Ordinal) ? name.StartsWith(pattern.Substring(0, pattern.Length - 1), StringComparison.Ordinal) : name == pattern;

        // ---- NDMF console --------------------------------------------------------------------------------------------

        private static readonly Dictionary<string, string> Texts = new Dictionary<string, string>
        {
            ["cleanup.removed"] = "안 쓰는 파라미터 {0}개를 지웠어요",
            ["cleanup.removed:description"] = "동기화 비트 {1} → {2}. 지운 파라미터: {3}",
            ["cleanup.removed:hint"] = "지우면 안 되는 파라미터는 조립 점검기 창의 파라미터 탭에서 예외로 넣거나, 이 아바타의 정리를 끄세요.",
            ["cleanup.off"] = "안 쓰는 파라미터 {0}개가 있어요 (정리 꺼짐)",
            ["cleanup.off:description"] = "정리를 켜면 동기화 비트가 {1} → {2}가 돼요. 대상: {3}",
            ["cleanup.kept"] = "쓰이지 않는 것 같지만 남긴 파라미터 {0}개",
            ["cleanup.kept:description"] = "{1}",
            ["cleanup.kept:hint"] = "정말 쓰지 않는다면 그 컴포넌트에서 이름을 지우세요. OSC·페이스 트래킹용이면 그대로 두세요.",
        };

        private static Localizer localizer;

        private static Localizer L => localizer ??= new Localizer("ko-KR", () =>
        {
            Func<string, string> lookup = key => Texts.TryGetValue(key, out var text) ? text : null;
            return new List<(string, Func<string, string>)> { ("ko-KR", lookup), ("en-US", lookup), ("ja-JP", lookup) };
        });

        private static void Announce(Report report)
        {
            try
            {
                string Names(IEnumerable<Entry> entries) => string.Join(", ", entries.Select(e => e.name));
                if (report.removed.Count > 0)
                    ErrorReport.ReportError(L, ErrorSeverity.Information, report.applied ? "cleanup.removed" : "cleanup.off",
                        report.removed.Count.ToString(), report.bitsBefore.ToString(), report.bitsAfter.ToString(), Names(report.removed));
                var notable = report.kept.Where(k => !k.reason.StartsWith("예외", StringComparison.Ordinal)).ToList();
                if (notable.Count > 0)
                    ErrorReport.ReportError(L, ErrorSeverity.Information, "cleanup.kept", notable.Count.ToString(),
                        string.Join("\n", notable.Select(k => $"{k.name}: {k.reason}")));
            }
            catch (Exception e)
            {
                // The report is a courtesy; the build goes on without it.
                Debug.LogWarning("[Assembly Checker] " + e.Message);
            }
        }
    }

    // Where the built avatar uses its parameters. Used: read or written by an animator, set by a menu, driven by a
    // Contact or PhysBone. Named: only some other component's text field holds the name.
    internal sealed class ParameterUses
    {
        internal readonly HashSet<string> Used = new HashSet<string>();
        internal readonly Dictionary<string, List<string>> Named = new Dictionary<string, List<string>>();

        private static readonly string[] PhysBoneSuffixes = { "_IsGrabbed", "_IsPosed", "_Angle", "_Stretch", "_Squish" };
        // VRC Raycast writes its results to the parameter's name with these endings.
        private static readonly string[] RaycastSuffixes = { "", "_Hit", "_Ratio", "_Distance" };

        internal static ParameterUses Collect(GameObject root, VRCAvatarDescriptor descriptor, ICollection<string> names)
        {
            var uses = new ParameterUses();
            uses.Menu(descriptor.expressionsMenu, new HashSet<VRCExpressionsMenu>());
            foreach (var controller in Controllers(descriptor)) uses.Controller(controller, names);
            // VRChat's own Action layer plays emotes by VRCEmote.
            if (OnDefault(descriptor, VRCAvatarDescriptor.AnimLayerType.Action)) uses.Add("VRCEmote");
            foreach (var receiver in root.GetComponentsInChildren<ContactReceiver>(true)) uses.Receiver(receiver);
            foreach (var bone in root.GetComponentsInChildren<VRCPhysBone>(true))
                if (!string.IsNullOrEmpty(bone.parameter))
                    foreach (var suffix in PhysBoneSuffixes) uses.Add(bone.parameter + suffix);
            foreach (var raycast in root.GetComponentsInChildren<Component>(true).Where(c => c && c.GetType().Name == "VRCRaycast"))
                using (var serialized = new SerializedObject(raycast))
                {
                    string name = serialized.FindProperty("parameter")?.stringValue;
                    if (!string.IsNullOrEmpty(name))
                        foreach (var suffix in RaycastSuffixes) uses.Add(name + suffix);
                }
            uses.Text(root, names);
            return uses;
        }

        // The playable layers' controllers. A layer left on VRChat's default has none to read here; in a build NDMF has
        // usually put the SDK's copy of the default in its place by now, and OnDefault covers the layer when it has not.
        internal static IEnumerable<RuntimeAnimatorController> Controllers(VRCAvatarDescriptor descriptor) =>
            (descriptor.baseAnimationLayers ?? Array.Empty<VRCAvatarDescriptor.CustomAnimLayer>())
            .Concat(descriptor.specialAnimationLayers ?? Array.Empty<VRCAvatarDescriptor.CustomAnimLayer>())
            .Where(l => !l.isDefault && l.animatorController).Select(l => l.animatorController).Distinct();

        // Whether VRChat plays its own controller on a playable layer.
        private static bool OnDefault(VRCAvatarDescriptor descriptor, VRCAvatarDescriptor.AnimLayerType type) =>
            !descriptor.customizeAnimationLayers || descriptor.baseAnimationLayers == null ||
            descriptor.baseAnimationLayers.Any(l => l.type == type && (l.isDefault || !l.animatorController));

        private void Add(string name)
        {
            if (!string.IsNullOrEmpty(name)) Used.Add(name);
        }

        // A Contact Receiver writes its value to its parameter, and each advanced output that is switched on (sender
        // type, position, scale, velocity, ..., one per collision tag) to that name with the output's ending.
        private void Receiver(ContactReceiver receiver)
        {
            string name = receiver.parameter;
            if (string.IsNullOrEmpty(name)) return;
            Add(name);
            void Outputs(ContactReceiver.AdvancedParameter output, params string[] endings)
            {
                if ((receiver.advancedParameters & output) == 0) return;
                foreach (var ending in endings) Add(name + ending);
            }
            Outputs(ContactReceiver.AdvancedParameter.SenderType, ContactReceiver.PARAM_SENDER_TYPE);
            Outputs(ContactReceiver.AdvancedParameter.SenderLocalPosition, ContactReceiver.PARAM_SENDER_LOCAL_POSITION_X,
                ContactReceiver.PARAM_SENDER_LOCAL_POSITION_Y, ContactReceiver.PARAM_SENDER_LOCAL_POSITION_Z);
            Outputs(ContactReceiver.AdvancedParameter.SenderLossyScale, ContactReceiver.PARAM_SENDER_LOSSY_SCALE_X,
                ContactReceiver.PARAM_SENDER_LOSSY_SCALE_Y, ContactReceiver.PARAM_SENDER_LOSSY_SCALE_Z);
            Outputs(ContactReceiver.AdvancedParameter.SenderVelocity, ContactReceiver.PARAM_SENDER_VELOCITY_X,
                ContactReceiver.PARAM_SENDER_VELOCITY_Y, ContactReceiver.PARAM_SENDER_VELOCITY_Z, ContactReceiver.PARAM_SENDER_VELOCITY_MAGNITUDE);
            Outputs(ContactReceiver.AdvancedParameter.PointSeparation, ContactReceiver.PARAM_POINT_SEPARATION);
            Outputs(ContactReceiver.AdvancedParameter.ProximitySpeed, ContactReceiver.PARAM_PROXIMITY_SPEED);
            if ((receiver.advancedParameters & ContactReceiver.AdvancedParameter.CollisionTags) != 0 && receiver.collisionTags != null)
                foreach (var tag in receiver.collisionTags)
                    if (!string.IsNullOrWhiteSpace(tag)) Add(name + ContactReceiver.PARAM_COLLISION_TAG_PREFIX + tag);
        }

        private void Menu(VRCExpressionsMenu menu, HashSet<VRCExpressionsMenu> seen)
        {
            if (!menu || !seen.Add(menu) || menu.controls == null) return;
            foreach (var control in menu.controls)
            {
                if (control == null) continue;
                Add(control.parameter?.name);
                if (control.subParameters != null)
                    foreach (var sub in control.subParameters) Add(sub?.name);
                if (control.type == VRCExpressionsMenu.Control.ControlType.SubMenu) Menu(control.subMenu, seen);
            }
        }

        private void Controller(RuntimeAnimatorController runtime, ICollection<string> names)
        {
            // Animated animator parameters: a clip curve on the Animator writes the parameter.
            foreach (var clip in runtime.animationClips.Where(c => c).Distinct())
                foreach (var binding in AnimationUtility.GetCurveBindings(clip))
                    if (binding.type == typeof(Animator)) Add(binding.propertyName);
            while (runtime is AnimatorOverrideController overrides) runtime = overrides.runtimeAnimatorController;
            if (!(runtime is AnimatorController controller)) return;
            var layers = controller.layers;
            foreach (var layer in layers)
            {
                // A synced layer plays another layer's states with motions and behaviours of its own.
                if (layer.syncedLayerIndex >= 0)
                {
                    var source = layer.syncedLayerIndex < layers.Length ? layers[layer.syncedLayerIndex].stateMachine : null;
                    if (!source) continue;
                    foreach (var state in States(source))
                    {
                        Motion(layer.GetOverrideMotion(state));
                        foreach (var behaviour in layer.GetOverrideBehaviours(state)) Strings(behaviour, names);
                    }
                    continue;
                }
                if (layer.stateMachine) Machine(layer.stateMachine, names);
            }
        }

        private static IEnumerable<AnimatorState> States(AnimatorStateMachine machine) =>
            machine.states.Select(s => s.state).Where(s => s)
                .Concat(machine.stateMachines.Where(m => m.stateMachine).SelectMany(m => States(m.stateMachine)));

        private void Machine(AnimatorStateMachine machine, ICollection<string> names)
        {
            foreach (var t in machine.anyStateTransitions) Conditions(t);
            foreach (var t in machine.entryTransitions) Conditions(t);
            foreach (var behaviour in machine.behaviours) Strings(behaviour, names);
            foreach (var child in machine.states)
            {
                var state = child.state;
                if (!state) continue;
                Motion(state.motion);
                if (state.speedParameterActive) Add(state.speedParameter);
                if (state.cycleOffsetParameterActive) Add(state.cycleOffsetParameter);
                if (state.mirrorParameterActive) Add(state.mirrorParameter);
                if (state.timeParameterActive) Add(state.timeParameter);
                foreach (var t in state.transitions) Conditions(t);
                foreach (var behaviour in state.behaviours) Strings(behaviour, names);
            }
            foreach (var child in machine.stateMachines)
            {
                if (!child.stateMachine) continue;
                foreach (var t in machine.GetStateMachineTransitions(child.stateMachine)) Conditions(t);
                Machine(child.stateMachine, names);
            }
        }

        private void Conditions(AnimatorTransitionBase transition)
        {
            if (!transition) return;
            foreach (var condition in transition.conditions) Add(condition.parameter);
        }

        private void Motion(Motion motion)
        {
            if (!(motion is BlendTree tree)) return;
            Add(tree.blendParameter);
            if (tree.blendType != BlendTreeType.Simple1D && tree.blendType != BlendTreeType.Direct) Add(tree.blendParameterY);
            foreach (var child in tree.children)
            {
                if (tree.blendType == BlendTreeType.Direct) Add(child.directBlendParameter);
                Motion(child.motion);
            }
        }

        // State behaviours (Parameter Driver, Play Audio, ...) name parameters in text fields.
        private void Strings(Object behaviour, ICollection<string> names)
        {
            if (!behaviour) return;
            foreach (var text in TextOf(behaviour))
                if (names.Contains(text)) Add(text);
        }

        // Other components that hold a parameter's name: a tool that runs after this pass (VRCFury), or one that reads
        // the name some other way. The name is kept and reported.
        private void Text(GameObject root, ICollection<string> names)
        {
            foreach (var component in root.GetComponentsInChildren<Component>(true))
            {
                if (!component || Skip(component)) continue;
                string where = null;
                foreach (var text in TextOf(component))
                {
                    if (!names.Contains(text) || Used.Contains(text)) continue;
                    where ??= $"{BuiltAvatar.PathOf(root.transform, component.transform)} ({component.GetType().Name})";
                    if (!Named.TryGetValue(text, out var list)) Named[text] = list = new List<string>();
                    if (!list.Contains(where)) list.Add(where);
                }
            }
        }

        // Components with no parameter names, ones read above, and Modular Avatar's, which have been applied by now. The
        // avatar descriptor is read: its face tracking settings can name parameters.
        private static bool Skip(Component c) =>
            c is Transform || c is Renderer || c is MeshFilter || c is Animator || c is ParticleSystem || c is Collider ||
            c is Rigidbody || c is Joint || c is Light || c is Camera || c is AudioSource || c is Cloth ||
            c is VRCPhysBone || c is ContactReceiver || c is AssemblyCheckerSettings ||
            c.GetType().Name == "VRCRaycast" ||
            (c.GetType().Namespace ?? "").StartsWith("nadena.dev.modular_avatar", StringComparison.Ordinal);

        // Every non-empty string a serialized object holds, nested and managed-reference fields included.
        internal static IEnumerable<string> TextOf(Object target)
        {
            using (var serialized = new SerializedObject(target))
            {
                var property = serialized.GetIterator();
                bool enter = true;
                while (property.Next(enter))
                {
                    enter = property.propertyType == SerializedPropertyType.Generic ||
                            property.propertyType == SerializedPropertyType.ManagedReference;
                    if (property.propertyType == SerializedPropertyType.String && !string.IsNullOrEmpty(property.stringValue))
                        yield return property.stringValue;
                }
            }
        }
    }
}
#endif
