using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

namespace PersonalPoseDeck
{
    // VRChat-style expression menu drawn with IMGUI: a ring of items, a radial puppet and a two-axis puppet.
    // Angles start at 12 o'clock and grow clockwise, as in VRChat.
    internal static class PoseDeckRadialMenu
    {
        private static readonly Color Back = new Color(.08f, .09f, .11f, .82f);
        private static readonly Color Slot = new Color(.20f, .22f, .26f, .92f);
        private static readonly Color Hover = new Color(.26f, .40f, .56f, .96f);
        private static readonly Color Accent = new Color(.33f, .67f, .93f, .95f);
        private static readonly Color Line = new Color(.55f, .58f, .64f, .9f);
        private static GUIStyle label, value;

        private static void Styles()
        {
            if (label != null) return;
            label = new GUIStyle(EditorStyles.miniBoldLabel) { alignment = TextAnchor.MiddleCenter, wordWrap = true, normal = { textColor = Color.white } };
            value = new GUIStyle(EditorStyles.boldLabel) { alignment = TextAnchor.MiddleCenter, normal = { textColor = Color.white } };
        }

        internal static Vector2 Point(Vector2 center, float angle, float radius) =>
            center + new Vector2(Mathf.Sin(angle * Mathf.Deg2Rad), -Mathf.Cos(angle * Mathf.Deg2Rad)) * radius;

        // 0–360, 0 at 12 o'clock, clockwise.
        internal static float AngleOf(Vector2 center, Vector2 point)
        {
            var d = point - center;
            return Mathf.Repeat(Mathf.Atan2(d.x, -d.y) * Mathf.Rad2Deg, 360f);
        }

        private static void Band(Vector2 c, float inner, float outer, float from, float to, Color color)
        {
            if (Event.current.type != EventType.Repaint || to <= from) return;
            Handles.color = color;
            int steps = Mathf.Max(2, Mathf.CeilToInt((to - from) / 6f));
            float step = (to - from) / steps;
            var quad = new Vector3[4];
            for (int i = 0; i < steps; i++)
            {
                float a0 = from + i * step, a1 = a0 + step;
                quad[0] = Point(c, a0, inner); quad[1] = Point(c, a0, outer); quad[2] = Point(c, a1, outer); quad[3] = Point(c, a1, inner);
                Handles.DrawAAConvexPolygon(quad);
            }
        }

        private static void Disc(Vector2 c, float r, Color color) => Band(c, 0f, r, 0f, 360f, color);

        private static void Ring(Vector2 c, float r, Color color, float width = 1.5f)
        {
            if (Event.current.type != EventType.Repaint) return;
            Handles.color = color;
            var points = new Vector3[65];
            for (int i = 0; i <= 64; i++) points[i] = Point(c, i * 360f / 64f, r);
            Handles.DrawAAPolyLine(width, points);
        }

        // Ring of items around a "back" hub. Returns the clicked item, -2 for the hub, -1 for none.
        internal static int Menu(Rect rect, IReadOnlyList<string> items, string hub)
        {
            Styles();
            var c = rect.center;
            float outer = Mathf.Min(rect.width, rect.height) * .5f - 2f, inner = outer * .36f;
            var evt = Event.current;
            int count = Mathf.Max(1, items.Count);
            float span = 360f / count;
            float distance = Vector2.Distance(evt.mousePosition, c);
            int hovered = distance > inner && distance <= outer
                ? Mathf.FloorToInt(Mathf.Repeat(AngleOf(c, evt.mousePosition) + span * .5f, 360f) / span) % count : -1;
            Disc(c, outer + 2f, Back);
            for (int i = 0; i < items.Count; i++)
            {
                float mid = i * span;
                Band(c, inner + 2f, outer, mid - span * .5f + 1f, mid + span * .5f - 1f, i == hovered ? Hover : Slot);
                var at = Point(c, mid, (inner + outer) * .5f);
                float w = Mathf.Min(outer - inner, 2f * Mathf.PI * (inner + outer) * .5f / count) - 4f;
                GUI.Label(new Rect(at.x - w * .5f, at.y - 15f, w, 30f), items[i], label);
            }
            bool overHub = distance <= inner;
            Disc(c, inner, overHub ? Hover : Slot);
            GUI.Label(new Rect(c.x - inner, c.y - 12f, inner * 2f, 24f), hub, label);
            if (evt.type == EventType.MouseDown && evt.button == 0 && distance <= outer + 2f)
            {
                evt.Use();
                return overHub ? -2 : hovered;
            }
            return -1;
        }

        // Radial puppet. Drag on the ring to set 0–1; the value does not wrap past the top. Returns true on change.
        internal static bool Radial(Rect rect, int id, ref float value01, string valueText)
        {
            Styles();
            var c = rect.center;
            float outer = Mathf.Min(rect.width, rect.height) * .5f - 2f, inner = outer * .45f;
            var evt = Event.current;
            bool changed = false;
            switch (evt.GetTypeForControl(id))
            {
                case EventType.MouseDown when evt.button == 0 && Vector2.Distance(evt.mousePosition, c) <= outer + 2f:
                    GUIUtility.hotControl = id;
                    changed = Track(c, evt.mousePosition, ref value01, true);
                    evt.Use();
                    break;
                case EventType.MouseDrag when GUIUtility.hotControl == id:
                    changed = Track(c, evt.mousePosition, ref value01, false);
                    evt.Use();
                    break;
                case EventType.MouseUp when GUIUtility.hotControl == id:
                    GUIUtility.hotControl = 0;
                    evt.Use();
                    break;
            }
            Disc(c, outer + 2f, Back);
            Band(c, inner, outer, 0f, 360f, Slot);
            Band(c, inner, outer, 0f, Mathf.Clamp01(value01) * 360f, Accent);
            if (evt.type == EventType.Repaint)
            {
                Handles.color = Color.white;
                Handles.DrawAAPolyLine(3f, Point(c, value01 * 360f, inner - 4f), Point(c, value01 * 360f, outer));
            }
            GUI.Label(new Rect(c.x - inner, c.y - 11f, inner * 2f, 22f), valueText, value);
            return changed;
        }

        private static bool Track(Vector2 c, Vector2 mouse, ref float value01, bool jump)
        {
            float next = AngleOf(c, mouse) / 360f;
            // Like VRChat: crossing 12 o'clock while dragging holds at the end instead of wrapping around.
            if (!jump && Mathf.Abs(next - value01) > .5f) next = value01 > .5f ? 1f : 0f;
            if (Mathf.Approximately(next, value01)) return false;
            value01 = next;
            return true;
        }

        // Two-axis puppet in a unit disc (x right, y up). Returns true on change.
        internal static bool Axis(Rect rect, int id, ref Vector2 axis, string top, string valueText)
        {
            Styles();
            var c = rect.center;
            float outer = Mathf.Min(rect.width, rect.height) * .5f - 2f;
            var evt = Event.current;
            bool changed = false;
            switch (evt.GetTypeForControl(id))
            {
                case EventType.MouseDown when evt.button == 0 && Vector2.Distance(evt.mousePosition, c) <= outer + 2f:
                    GUIUtility.hotControl = id;
                    changed = Place(c, outer, evt.mousePosition, ref axis);
                    evt.Use();
                    break;
                case EventType.MouseDrag when GUIUtility.hotControl == id:
                    changed = Place(c, outer, evt.mousePosition, ref axis);
                    evt.Use();
                    break;
                case EventType.MouseUp when GUIUtility.hotControl == id:
                    GUIUtility.hotControl = 0;
                    evt.Use();
                    break;
            }
            Disc(c, outer + 2f, Back);
            Disc(c, outer, Slot);
            Ring(c, outer * .5f, Line, 1f);
            if (evt.type == EventType.Repaint)
            {
                Handles.color = Line;
                Handles.DrawAAPolyLine(1f, c + Vector2.left * outer, c + Vector2.right * outer);
                Handles.DrawAAPolyLine(1f, c + Vector2.up * outer, c + Vector2.down * outer);
            }
            var knob = c + new Vector2(axis.x, -axis.y) * outer;
            Disc(knob, 7f, Accent);
            Ring(knob, 7f, Color.white, 2f);
            GUI.Label(new Rect(c.x - 40f, c.y - outer + 2f, 80f, 16f), top, label);
            GUI.Label(new Rect(c.x - outer, c.y + outer * .55f, outer * 2f, 18f), valueText, label);
            return changed;
        }

        private static bool Place(Vector2 c, float outer, Vector2 mouse, ref Vector2 axis)
        {
            var next = (mouse - c) / outer;
            next.y = -next.y;
            if (next.sqrMagnitude > 1f) next.Normalize();
            if ((next - axis).sqrMagnitude < 1e-8f) return false;
            axis = next;
            return true;
        }
    }
}
