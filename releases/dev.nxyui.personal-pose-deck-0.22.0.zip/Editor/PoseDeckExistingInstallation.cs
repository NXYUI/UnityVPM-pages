using UnityEditor.Animations;
using UnityEngine;
using VRC.SDK3.Avatars.ScriptableObjects;

namespace PersonalPoseDeck
{
    // Keep the original references with each generated result, independently of the preset being edited.
    public sealed class PoseDeckExistingInstallation : ScriptableObject
    {
        [SerializeField] internal PoseDeckPreset preset;
        [SerializeField] internal AnimatorController stockBase;
        [SerializeField] internal VRCExpressionsMenu stockMenu;
        [SerializeField] internal AnimatorController appliedBase;
        [SerializeField] internal VRCExpressionsMenu appliedMenu;
        // Since 0.22.0, when the deck put its start heights in a copy of the object's Action: the Action it was made
        // from and the copy (both null otherwise).
        [SerializeField] internal AnimatorController stockAction;
        [SerializeField] internal AnimatorController appliedAction;
    }
}
