using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using nadena.dev.ndmf;
using nadena.dev.ndmf.platform;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using Object = UnityEngine.Object;

namespace PersonalPoseDeck
{
    internal sealed class PoseDeckAssemblyPreview : IDisposable
    {
        private const BindingFlags All = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static;
        private Scene scene;
        private readonly HashSet<Object> generated = new HashSet<Object>();
        internal GameObject Root { get; private set; }
        // True when the MA-only path was unavailable and every installed NDMF plug-in ran instead.
        internal bool UsedFullBuild { get; private set; }

        internal PoseDeckAssemblyPreview(GameObject source)
        {
            scene = EditorSceneManager.NewPreviewScene();
            var stage = EditorUtility.CreateGameObjectWithHideFlags("Pose Deck staging", HideFlags.HideAndDontSave);
            var originalAssets = new HashSet<Object>();
            bool haveBaseline = false;
            try
            {
                SceneManager.MoveGameObjectToScene(stage, scene);
                stage.SetActive(false);
                Root = Object.Instantiate(source, stage.transform, false);
                Root.name = source.name + " (Pose Deck Preview)";
                Root.SetActive(false);
                Root.transform.SetParent(null, false);
                Root.transform.SetPositionAndRotation(Vector3.zero, Quaternion.identity);
                Root.transform.localScale = source.transform.lossyScale;
                originalAssets.UnionWith(ReferencedAssets(Root));
                haveBaseline = true;
                // Keep MA and SDK tags; prevent unrelated edit-mode scripts from running in the clone.
                foreach (var script in Root.GetComponentsInChildren<MonoBehaviour>(true))
                {
                    if (!script) continue;
                    var type = script.GetType();
                    var ns = type.Namespace ?? "";
                    if (ns.StartsWith("nadena.dev.", StringComparison.Ordinal) || ns.StartsWith("VRC.", StringComparison.Ordinal)) continue;
                    if (type.IsDefined(typeof(ExecuteAlways), true) || type.IsDefined(typeof(ExecuteInEditMode), true))
                        Object.DestroyImmediate(script);
                }
                Root.SetActive(true);
                if (!TryApplyModularAvatar(Root))
                {
                    UsedFullBuild = true;
                    ApplyFullBuild(Root);
                }
                Root.hideFlags = HideFlags.HideAndDontSave;
                CollectGenerated(originalAssets);
            }
            catch
            {
                if (haveBaseline) CollectGenerated(originalAssets);
                Dispose();
                throw;
            }
        }

        // Returns false, before touching the avatar, when this NDMF version no longer has the internals used here.
        private static bool TryApplyModularAvatar(GameObject root)
        {
            // NDMF's public full bake runs all installed plug-ins. Resolve only its core and MA passes for preview.
            var asm = typeof(BuildContext).Assembly;
            var resolverType = asm.GetType("nadena.dev.ndmf.PluginResolver", false);
            var concreteType = asm.GetType("nadena.dev.ndmf.ConcretePass", false);
            var find = resolverType?.GetMethod("FindPluginTypes", All);
            var ctor = resolverType?.GetConstructor(All, null,
                new[] { typeof(IEnumerable<Type>), typeof(INDMFPlatformProvider), typeof(bool) }, null);
            var passesProperty = resolverType?.GetProperty("Passes", All);
            var run = concreteType == null ? null : typeof(BuildContext).GetMethod("RunPass", All, null, new[] { concreteType }, null);
            if (find == null || ctor == null || passesProperty == null || run == null ||
                !typeof(IEnumerable<Type>).IsAssignableFrom(find.ReturnType))
                return false;

            var pluginTypes = ((IEnumerable<Type>)find.Invoke(null, null)).Where(t =>
                (t.Assembly == asm && t.Name == "InternalPasses") ||
                (t.Namespace ?? "").StartsWith("nadena.dev.modular_avatar.", StringComparison.Ordinal)).ToArray();
            // MA's plug-in type name is internal too; if it moved, use the public full build instead.
            if (!pluginTypes.Any(t => t.Name == "PluginDefinition")) return false;

            // Read the whole pass list first. BuildContext marks the avatar, so create it only once the layout is known.
            var platform = AmbientPlatform.DefaultPlatform;
            var plan = new List<object>();
            using (new AmbientPlatform.Scope(platform))
            {
                var resolver = ctor.Invoke(new object[] { pluginTypes, platform, false });
                if (!(passesProperty.GetValue(resolver) is IEnumerable phases)) return false;
                foreach (var pair in phases)
                {
                    var pairType = pair?.GetType();
                    var phaseField = pairType?.GetField("Item1");
                    var passesField = pairType?.GetField("Item2");
                    if (phaseField?.FieldType != typeof(BuildPhase) || passesField == null ||
                        !(passesField.GetValue(pair) is IEnumerable passes))
                        return false;
                    var phase = (BuildPhase)phaseField.GetValue(pair);
                    if (phase == BuildPhase.Optimizing) break;
                    foreach (var pass in passes)
                    {
                        if (!concreteType.IsInstanceOfType(pass)) return false;
                        plan.Add(pass);
                    }
                    if (phase == BuildPhase.Transforming) break;
                }
            }
            if (plan.Count == 0) throw new InvalidOperationException("실행할 MA 조립 패스가 없습니다.");

            var context = new BuildContext(root, (string)null, platform);
            try
            {
                using (new AmbientPlatform.Scope(context.PlatformProvider))
                    foreach (var pass in plan) run.Invoke(context, new[] { pass });
            }
            catch (TargetInvocationException e) when (e.InnerException != null)
            {
                throw new InvalidOperationException(e.InnerException.Message, e.InnerException);
            }
            finally
            {
                try { context.DeactivateAllExtensionContexts(); }
                finally { context.AssetSaver.Dispose(); }
            }
            if (!context.Successful)
                throw new InvalidOperationException("Modular Avatar 조립 중 오류가 발생했습니다. Unity Console을 확인하세요.");
            return true;
        }

        // Public NDMF API. A null temporary directory keeps generated assets in memory, as in the MA-only path.
        private static void ApplyFullBuild(GameObject root)
        {
            BuildContext context;
            using (new OverrideTemporaryDirectoryScope(null))
                context = nadena.dev.ndmf.AvatarProcessor.ProcessAvatar(root, AmbientPlatform.DefaultPlatform);
            if (!context.Successful)
                throw new InvalidOperationException("NDMF 전체 빌드로 조립하던 중 오류가 발생했습니다. Unity Console을 확인하세요.");
        }

        private static IEnumerable<Object> ReferencedAssets(GameObject root)
        {
            foreach (var animator in root.GetComponentsInChildren<Animator>(true))
            {
                if (animator.avatar) yield return animator.avatar;
                if (animator.runtimeAnimatorController) yield return animator.runtimeAnimatorController;
            }
            foreach (var mesh in root.GetComponentsInChildren<MeshFilter>(true)) if (mesh.sharedMesh) yield return mesh.sharedMesh;
            foreach (var renderer in root.GetComponentsInChildren<Renderer>(true))
            {
                if (renderer is SkinnedMeshRenderer skinned && skinned.sharedMesh) yield return skinned.sharedMesh;
                foreach (var material in renderer.sharedMaterials) if (material) yield return material;
            }
        }

        private void CollectGenerated(HashSet<Object> originalAssets)
        {
            if (!Root) return;
            foreach (var asset in ReferencedAssets(Root))
                if (!originalAssets.Contains(asset) && !EditorUtility.IsPersistent(asset)) generated.Add(asset);
        }

        public void Dispose()
        {
            if (scene.IsValid()) EditorSceneManager.ClosePreviewScene(scene);
            Root = null;
            foreach (var asset in generated) if (asset) Object.DestroyImmediate(asset);
            generated.Clear();
        }
    }
}
