using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEngine;

namespace PersonalPoseDeck
{
    // The preview camera: the framed bounds and the orbit or free-look view around them.
    [Serializable]
    internal struct PoseDeckCameraState
    {
        public Vector3 frameCenter, frameSize;
        public float yaw, pitch, zoom;
        public Vector3 orbitPan;
        public bool freeLook;
        public Vector3 freePosition;
        public float freeYaw, freePitch, freeFov;
    }

    // Everything the browser's preview lets you adjust: playback, display, GoGoLoco height and tracking, lights,
    // light-package values (by label) and the camera.
    [Serializable]
    internal sealed class PoseDeckPreviewSettings
    {
        [Serializable]
        internal sealed class LightValue
        {
            public string label;
            public float value;
        }

        public float playbackSpeed = 1f;
        public bool loop = true, mirror, floor = true, gogoHeight = true, thumbnailsInGame;
        public int tracking;
        // "VR 손·머리": the VR look (PoseDeckVrPose) on the preview, and where the controllers and headset are.
        public bool vr;
        public PoseDeckVrPose.Settings vrSettings = PoseDeckVrPose.Settings.Default;
        public PoseDeckPreviewLighting lighting = new PoseDeckPreviewLighting();
        public List<LightValue> lightControls = new List<LightValue>();
        // Off frames the avatar when the preview opens.
        public bool hasCamera;
        public PoseDeckCameraState camera;

        internal string Json => JsonUtility.ToJson(this);
        internal PoseDeckPreviewSettings Clone() => JsonUtility.FromJson<PoseDeckPreviewSettings>(Json);
        internal bool SameAs(PoseDeckPreviewSettings other) => other != null && other.Json == Json;
    }

    [Serializable]
    internal sealed class PoseDeckPreviewPreset
    {
        public string name;
        public PoseDeckPreviewSettings settings = new PoseDeckPreviewSettings();
    }

    // The last preview settings and the saved presets, kept per project in UserSettings (not shared through version
    // control), so they survive other poses, closing the window and restarting Unity.
    [Serializable]
    internal sealed class PoseDeckPreviewStore
    {
        public PoseDeckPreviewSettings current;
        public List<PoseDeckPreviewPreset> presets = new List<PoseDeckPreviewPreset>();

        // Tests point this at a scratch file.
        internal static string PathOverride;
        internal static string FilePath => PathOverride ??
            Path.Combine(Path.GetDirectoryName(Application.dataPath) ?? "", "UserSettings", "NXYUI", "PersonalPoseDeck.Preview.json");

        internal static PoseDeckPreviewStore Load()
        {
            try
            {
                if (File.Exists(FilePath))
                {
                    var store = JsonUtility.FromJson<PoseDeckPreviewStore>(File.ReadAllText(FilePath));
                    if (store != null)
                    {
                        store.presets = (store.presets ?? new List<PoseDeckPreviewPreset>())
                            .Where(p => p != null && !string.IsNullOrWhiteSpace(p.name) && p.settings != null).ToList();
                        return store;
                    }
                }
            }
            catch (Exception e) { Debug.LogWarning($"[Personal Pose Deck] 미리보기 설정을 읽지 못해 기본값을 씁니다: {FilePath}\n{e.Message}"); }
            return new PoseDeckPreviewStore();
        }

        internal void Save()
        {
            Directory.CreateDirectory(Path.GetDirectoryName(FilePath) ?? ".");
            File.WriteAllText(FilePath, JsonUtility.ToJson(this, true));
        }

        internal PoseDeckPreviewPreset Find(string name) => presets.FirstOrDefault(p => p.name == name);

        // Adds the preset, or replaces the one with the same name.
        internal void Put(string name, PoseDeckPreviewSettings settings)
        {
            var preset = Find(name);
            if (preset == null) presets.Add(preset = new PoseDeckPreviewPreset { name = name });
            preset.settings = settings.Clone();
            presets.Sort((a, b) => string.Compare(a.name, b.name, StringComparison.CurrentCultureIgnoreCase));
        }

        internal bool Remove(string name) => presets.RemoveAll(p => p.name == name) > 0;
    }
}
