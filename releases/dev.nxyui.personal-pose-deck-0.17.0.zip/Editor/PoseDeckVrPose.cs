using System;
using UnityEngine;

namespace PersonalPoseDeck
{
    // A rough look at a pose in VR with 3–4 point tracking. While a pose plays, GoGoLoco keeps the head on the headset
    // (unless its head button is on) and the hands on the controllers (unless the deck holds them), and VRChat's IK bends
    // the body to reach them. VRChat's solver is its own, so this only shows where the head and hands get pulled: the head
    // turns upright toward the headset, spread over the chest and neck, and each arm bends to its controller with a
    // two-bone solve. Hips and legs keep the animation.
    internal sealed class PoseDeckVrPose
    {
        internal enum HandPlace { Front, Side, Lap, Custom }
        internal enum HeadMode { Headset, Pose }

        internal static readonly string[] HandLabels = { "앞으로", "몸 옆", "무릎 위", "직접 지정" };
        internal static readonly string[] HeadLabels = { "헤드셋", "포즈대로" };

        // A pose is marked for VR when a hand moves this far (in arm lengths) or the head turns this much.
        internal const float HandCaution = .6f;
        internal const float HeadCaution = 40f;

        // Controller places relative to the shoulder, in arm lengths, in the headset's frame: x outward, y up, z forward.
        internal static readonly Vector3 FrontOffset = new Vector3(-.15f, -.55f, .6f);
        internal static readonly Vector3 SideOffset = new Vector3(.08f, -.9f, .1f);
        // Where the elbows point while reaching, in the same frame.
        private static readonly Vector3 ElbowHint = new Vector3(.6f, -.7f, -.35f);

        [Serializable]
        internal struct Settings
        {
            public HandPlace hands;
            public HeadMode head;
            // Controller places for HandPlace.Custom (see FrontOffset).
            public Vector3 left, right;

            internal static Settings Default => new Settings { left = FrontOffset, right = FrontOffset };
            internal string Key => $"{(int)hands}|{(int)head}|{left:F3}|{right:F3}";
        }

        internal struct Result
        {
            public bool Valid;
            // Degrees the head turns to face the headset upright (0 when it follows the pose).
            public float HeadAngle;
            // Metres each hand moves to its controller.
            public float LeftPull, RightPull;
            public float ArmLength;
            public Vector3 LeftTarget, RightTarget;

            internal float HandPull => Mathf.Max(LeftPull, RightPull);
            internal bool HandsMove => Valid && ArmLength > 0f && HandPull >= HandCaution * ArmLength;
            internal bool HeadTurns => Valid && HeadAngle >= HeadCaution;
            internal bool Caution(bool handsHeld) => HeadTurns || !handsHeld && HandsMove;
            internal Vector3 Target(int side) => side == 0 ? LeftTarget : RightTarget;

            // "손 38cm · 머리 52°": what moves, for labels and tooltips.
            internal string Summary(bool handsHeld) =>
                (handsHeld ? "손 클립대로" : $"손 최대 {HandPull * 100f:0}cm") + $" · 머리 {HeadAngle:0}°";

            internal string Reason(bool handsHeld)
            {
                if (!Valid) return "";
                var parts = new System.Collections.Generic.List<string>();
                if (!handsHeld && HandsMove) parts.Add($"손이 컨트롤러 쪽으로 최대 {HandPull * 100f:0}cm 끌려갑니다");
                if (HeadTurns) parts.Add($"머리가 헤드셋 방향으로 {HeadAngle:0}° 돌아갑니다");
                return string.Join(", ", parts);
            }
        }

        private readonly Transform root, head, neck, chest;
        private readonly Transform[] upper = new Transform[2], lower = new Transform[2], hand = new Transform[2];
        private readonly Transform[] thigh = new Transform[2], knee = new Transform[2];
        private readonly Quaternion headRest;
        private readonly Vector3[] shoulderRest = new Vector3[2];
        private readonly float armLength;
        private Quaternion lastFrame = Quaternion.identity;
        private Vector3 lastHead;

        internal bool Valid { get; }
        internal float ArmLength => armLength;

        // Reads the proportions from the rig as it stands now: the avatar's own pose, head upright and facing the root's
        // forward. Index 0 is the left side, 1 the right.
        internal PoseDeckVrPose(Animator animator, Transform root)
        {
            this.root = root;
            if (!root || !animator || !animator.avatar || !animator.avatar.isValid || !animator.avatar.isHuman) return;
            head = animator.GetBoneTransform(HumanBodyBones.Head);
            neck = animator.GetBoneTransform(HumanBodyBones.Neck);
            chest = animator.GetBoneTransform(HumanBodyBones.UpperChest);
            if (!chest) chest = animator.GetBoneTransform(HumanBodyBones.Chest);
            upper[0] = animator.GetBoneTransform(HumanBodyBones.LeftUpperArm);
            lower[0] = animator.GetBoneTransform(HumanBodyBones.LeftLowerArm);
            hand[0] = animator.GetBoneTransform(HumanBodyBones.LeftHand);
            upper[1] = animator.GetBoneTransform(HumanBodyBones.RightUpperArm);
            lower[1] = animator.GetBoneTransform(HumanBodyBones.RightLowerArm);
            hand[1] = animator.GetBoneTransform(HumanBodyBones.RightHand);
            thigh[0] = animator.GetBoneTransform(HumanBodyBones.LeftUpperLeg);
            knee[0] = animator.GetBoneTransform(HumanBodyBones.LeftLowerLeg);
            thigh[1] = animator.GetBoneTransform(HumanBodyBones.RightUpperLeg);
            knee[1] = animator.GetBoneTransform(HumanBodyBones.RightLowerLeg);
            if (!head) return;
            for (int s = 0; s < 2; s++) if (!upper[s] || !lower[s] || !hand[s]) return;
            var inverse = Quaternion.Inverse(root.rotation);
            headRest = inverse * head.rotation;
            for (int s = 0; s < 2; s++)
            {
                shoulderRest[s] = inverse * (upper[s].position - head.position);
                armLength += (Vector3.Distance(upper[s].position, lower[s].position) +
                              Vector3.Distance(lower[s].position, hand[s].position)) * .5f;
            }
            Valid = armLength > 1e-3f;
        }

        // The headset's orientation: upright, facing where the posed head faces (the avatar's front when it looks
        // straight up or down). With HeadMode.Pose the head keeps its pose and the frame follows it.
        private Quaternion Frame(HeadMode mode)
        {
            var posed = head.rotation * Quaternion.Inverse(headRest);
            if (mode == HeadMode.Pose) return posed;
            var up = root.up;
            var forward = Vector3.ProjectOnPlane(posed * Vector3.forward, up);
            if (forward.sqrMagnitude < .09f) forward = Vector3.ProjectOnPlane(root.forward, up);
            return Quaternion.LookRotation(forward.normalized, up);
        }

        private Vector3 Shoulder(int side, Quaternion frame, Vector3 headPosition) => headPosition + frame * shoulderRest[side];

        // Left mirrors right: x is outward on both sides. Its own inverse.
        private static Vector3 Outward(int side, Vector3 offset) => new Vector3(side == 0 ? -offset.x : offset.x, offset.y, offset.z);

        private Vector3 Target(int side, Settings settings, Quaternion frame, Vector3 headPosition)
        {
            if (settings.hands == HandPlace.Lap && thigh[side] && knee[side])
                return Vector3.Lerp(thigh[side].position, knee[side].position, .6f) + root.up * (.08f * armLength);
            var offset = settings.hands == HandPlace.Custom ? (side == 0 ? settings.left : settings.right)
                : settings.hands == HandPlace.Side ? SideOffset : FrontOffset;
            return Shoulder(side, frame, headPosition) + frame * (Outward(side, offset) * armLength);
        }

        // How far the head and hands move in VR, from the pose as it stands. Changes nothing.
        internal Result Measure(Settings settings)
        {
            var result = new Result { ArmLength = armLength };
            if (!Valid) return result;
            lastFrame = Frame(settings.head);
            lastHead = head.position;
            result.Valid = true;
            result.HeadAngle = settings.head == HeadMode.Headset ? Quaternion.Angle(head.rotation, lastFrame * headRest) : 0f;
            result.LeftTarget = Target(0, settings, lastFrame, lastHead);
            result.RightTarget = Target(1, settings, lastFrame, lastHead);
            result.LeftPull = Vector3.Distance(hand[0].position, result.LeftTarget);
            result.RightPull = Vector3.Distance(hand[1].position, result.RightTarget);
            return result;
        }

        // Turns the head to the headset and, unless the hands stay on the clip, bends the arms to the controllers.
        // Returns the measurements from before the change.
        internal Result Apply(Settings settings, bool handsOnClip)
        {
            var result = Measure(settings);
            if (!result.Valid) return result;
            if (settings.head == HeadMode.Headset) TurnHead(lastFrame * headRest);
            if (!handsOnClip)
                for (int side = 0; side < 2; side++)
                {
                    var hint = Shoulder(side, lastFrame, lastHead) + lastFrame * (Outward(side, ElbowHint) * armLength);
                    Reach(upper[side], lower[side], hand[side], result.Target(side), hint);
                }
            return result;
        }

        // The Custom offset that puts a side's controller at a world position, in the frame of the last Measure/Apply.
        internal Vector3 OffsetFor(int side, Vector3 world) =>
            Outward(side, Quaternion.Inverse(lastFrame) * (world - Shoulder(side, lastFrame, lastHead)) / armLength);

        // The chest and neck take part of the turn, the head the rest.
        private void TurnHead(Quaternion desired)
        {
            var bones = new[] { chest, neck, head };
            var shares = new[] { .25f, .45f, 1f };
            for (int i = 0; i < bones.Length; i++)
            {
                if (!bones[i]) continue;
                var delta = desired * Quaternion.Inverse(head.rotation);
                bones[i].rotation = Quaternion.Slerp(Quaternion.identity, delta, shares[i]) * bones[i].rotation;
            }
        }

        // Two-bone solve (as Unity's Animation Rigging does it): bend the elbow for the distance, aim the upper arm at the
        // target, then turn the arm about that line so the elbow points toward the hint. The hand keeps its wrist pose.
        private static void Reach(Transform a, Transform b, Transform c, Vector3 target, Vector3 hint)
        {
            Vector3 aPos = a.position, bPos = b.position, cPos = c.position;
            Vector3 ab = bPos - aPos, bc = cPos - bPos, ac = cPos - aPos, at = target - aPos;
            float abLen = ab.magnitude, bcLen = bc.magnitude;
            if (abLen < 1e-4f || bcLen < 1e-4f) return;
            float oldAngle = TriangleAngle(ac.magnitude, abLen, bcLen);
            float newAngle = TriangleAngle(at.magnitude, abLen, bcLen);
            var axis = Vector3.Cross(ab, bc);
            if (axis.sqrMagnitude < 1e-8f) axis = Vector3.Cross(hint - aPos, bc);
            if (axis.sqrMagnitude < 1e-8f) axis = Vector3.Cross(at, bc);
            if (axis.sqrMagnitude < 1e-8f) axis = Vector3.up;
            axis.Normalize();
            float half = .5f * (oldAngle - newAngle);
            float sin = Mathf.Sin(half);
            b.rotation = new Quaternion(axis.x * sin, axis.y * sin, axis.z * sin, Mathf.Cos(half)) * b.rotation;
            ac = c.position - aPos;
            if (ac.sqrMagnitude > 1e-8f && at.sqrMagnitude > 1e-8f) a.rotation = Quaternion.FromToRotation(ac, at) * a.rotation;
            ac = c.position - aPos;
            float acLength = ac.magnitude;
            if (acLength < 1e-4f) return;
            var line = ac / acLength;
            var abNow = b.position - aPos;
            var abSide = abNow - line * Vector3.Dot(abNow, line);
            var ah = hint - aPos;
            var ahSide = ah - line * Vector3.Dot(ah, line);
            float reach = abLen + bcLen;
            if (abSide.sqrMagnitude > reach * reach * .001f && ahSide.sqrMagnitude > 1e-8f)
                a.rotation = Quaternion.FromToRotation(abSide, ahSide) * a.rotation;
        }

        private static float TriangleAngle(float opposite, float side1, float side2) =>
            Mathf.Acos(Mathf.Clamp((side1 * side1 + side2 * side2 - opposite * opposite) / (2f * side1 * side2), -1f, 1f));
    }
}
