using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace PersonalPoseDeck
{
    // The VR look in the browser: the "VR 손·머리" preview row, the controller handles on the preview, and the VR marks
    // on gallery cards and deck rows. Marks are measured once per clip on the thumbnail frame, from the clip alone (a
    // renderer of their own, so the thumbnail options do not change them), for the deck's clips and the cards in view,
    // and again when the controller places or the avatar change.
    internal sealed partial class PoseDeckPoseBrowser
    {
        private static readonly GUIContent[] VrHandOptions =
        {
            new GUIContent("앞으로", "컨트롤러를 몸 앞, 허리 높이에 들고 있는 자세입니다."),
            new GUIContent("몸 옆", "팔을 내려 컨트롤러를 몸 옆에 둔 자세입니다."),
            new GUIContent("무릎 위", "컨트롤러를 아바타의 허벅지 위에 둡니다. 현실에서도 앉아서 무릎에 손을 올린 경우입니다."),
            new GUIContent("직접 지정", "미리보기의 원을 끌어 정한 위치입니다."),
        };
        private static readonly GUIContent[] VrHeadOptions =
        {
            new GUIContent("헤드셋", "현실에서 고개를 들고 정면을 보고 있다고 보고, 머리를 똑바로 세웁니다."),
            new GUIContent("포즈대로", "GoGoLoco 기타 메뉴의 머리 버튼을 켰거나, 현실에서도 같은 자세로 머리를 기울인 경우입니다."),
        };

        [SerializeField] private bool vrPreview;
        [SerializeField] private PoseDeckVrPose.Settings vrSettings = PoseDeckVrPose.Settings.Default;
        private readonly Dictionary<AnimationClip, PoseDeckVrPose.Result> vrChecks = new Dictionary<AnimationClip, PoseDeckVrPose.Result>();
        private readonly List<AnimationClip> visibleCards = new List<AnimationClip>();
        private string vrChecksKey;
        private PoseDeckPosePreview vrChecker;
        private bool vrCheckerFailed;
        private int vrDragSide = -1;
        // The dragged controller, moved by every drag event (several can come before the next sample).
        private Vector3 vrDragPoint;
        private GUIStyle vrCaution, vrHeld;

        private bool VrAllowed => previewTracking == (int)PoseDeckPosePreview.Tracking.VR;
        private bool VrShown => vrPreview && VrAllowed;

        // The deck row whose settings the clip plays with: the selected row when it shows this clip, else the first.
        private int DeckRowFor(AnimationClip clip)
        {
            int count = preset ? preset.poses.Count : 0;
            return selectedPose >= 0 && selectedPose < count && preset.poses[selectedPose].clip == clip ? selectedPose : DeckIndexOf(clip);
        }

        private bool HandsHeld(AnimationClip clip)
        {
            int row = DeckRowFor(clip);
            return row >= 0 && preset.poses[row].vrHands;
        }

        private void VrStyles()
        {
            if (vrCaution != null) return;
            vrCaution = new GUIStyle(EditorStyles.miniBoldLabel) { alignment = TextAnchor.MiddleCenter, normal = { textColor = new Color(1f, .68f, .3f) } };
            vrHeld = new GUIStyle(EditorStyles.miniBoldLabel) { alignment = TextAnchor.MiddleCenter, normal = { textColor = new Color(.55f, .9f, .6f) } };
        }

        // What the preview gets: the VR look when shown, and whether this pose keeps its hands on the clip.
        private void SyncVrPreview(AnimationClip clip)
        {
            var vr = VrShown ? vrSettings : (PoseDeckVrPose.Settings?)null;
            bool held = HandsHeld(clip);
            if (Nullable.Equals(renderer.Vr, vr) && renderer.VrHandsOnClip == held) return;
            renderer.Vr = vr;
            renderer.VrHandsOnClip = held;
            sampleDirty = true;
        }

        private void DrawVrRow()
        {
            using (new EditorGUILayout.HorizontalScope())
            {
                using (new EditorGUI.DisabledScope(!VrAllowed))
                {
                    bool next = GUILayout.Toggle(VrShown, new GUIContent("VR 손·머리", VrAllowed
                        ? "VR(3점)에서 VRChat IK가 바꾸는 머리와 손을 근사해 보여 줍니다. GoGoLoco는 포즈 중에도 손을 컨트롤러에, 머리를 헤드셋에 둡니다. 미리보기의 원이 컨트롤러 위치이고, 끌어서 옮길 수 있습니다."
                        : "트래킹이 VR (3점)일 때 쓸 수 있습니다."), EditorStyles.miniButton, GUILayout.Width(70));
                    if (VrAllowed && next != vrPreview) { vrPreview = next; sampleDirty = true; }
                    using (new EditorGUI.DisabledScope(!vrPreview))
                    {
                        GUILayout.Label("손", EditorStyles.miniLabel, GUILayout.Width(14));
                        int hands = EditorGUILayout.Popup((int)vrSettings.hands, VrHandOptions, GUILayout.Width(72));
                        GUILayout.Label("머리", EditorStyles.miniLabel, GUILayout.Width(26));
                        int head = EditorGUILayout.Popup((int)vrSettings.head, VrHeadOptions, GUILayout.Width(68));
                        if (hands != (int)vrSettings.hands || head != (int)vrSettings.head)
                        {
                            vrSettings.hands = (PoseDeckVrPose.HandPlace)hands;
                            vrSettings.head = (PoseDeckVrPose.HeadMode)head;
                            sampleDirty = true;
                        }
                    }
                }
            }
        }

        // The status line under the preview while the VR look is shown.
        private (string Text, GUIStyle Style, string Tip)? VrStatus(AnimationClip clip)
        {
            if (!VrShown || renderer == null) return null;
            var result = renderer.VrResult;
            if (!result.Valid) return ("VR 손·머리: 이 포즈에는 계산할 수 없음", EditorStyles.whiteMiniLabel,
                "Humanoid 아바타와 클립이 있고 포즈가 표시될 때 계산합니다.");
            bool held = HandsHeld(clip);
            string place = $"손 {VrHandOptions[(int)vrSettings.hands].text} · 머리 {VrHeadOptions[(int)vrSettings.head].text}";
            string tip = "VRChat IK를 흉내 낸 근사입니다. 실제 게임과 팔꿈치·허리 모양이 다를 수 있습니다." +
                (held ? " 이 포즈는 ‘VR에서 손도 포즈대로’가 켜져 있어 손을 클립대로 둡니다." : " 원을 끌면 컨트롤러 위치를 바꿀 수 있습니다.");
            return ($"VR 근사 ({place}) · {result.Summary(held)}", result.Caution(held) ? floorFloating : EditorStyles.whiteMiniLabel, tip);
        }

        // Called twice per event, like DrawLightMenu: before the preview for the drag (so the camera does not take it),
        // after it to paint. Each call takes one control id, so ids stay in step across events.
        private void VrHandles(Rect rect, bool paint)
        {
            int id = GUIUtility.GetControlID("PoseDeckVrHands".GetHashCode(), FocusType.Passive, rect);
            bool shown = VrShown && renderer != null && renderer.VrResult.Valid && !renderer.VrHandsOnClip && renderer.VrRig != null;
            if (!shown)
            {
                if (GUIUtility.hotControl == id) GUIUtility.hotControl = 0;
                vrDragSide = -1;
                return;
            }
            var result = renderer.VrResult;
            var evt = Event.current;
            if (paint)
            {
                for (int side = 0; side < 2; side++)
                {
                    if (!renderer.ToGui(rect, result.Target(side), out var at) || !rect.Contains(at)) continue;
                    var color = side == 0 ? new Color(.33f, .67f, .93f, .95f) : new Color(1f, .62f, .3f, .95f);
                    PoseDeckRadialMenu.Disc(at, vrDragSide == side ? 8f : 6.5f, new Color(color.r, color.g, color.b, .45f));
                    PoseDeckRadialMenu.Ring(at, 8f, color, 2f);
                    GUI.Label(new Rect(at.x + 9f, at.y - 9f, 16f, 16f), side == 0 ? "L" : "R", EditorStyles.whiteMiniLabel);
                    EditorGUIUtility.AddCursorRect(new Rect(at.x - 9f, at.y - 9f, 18f, 18f), MouseCursor.MoveArrow);
                }
                return;
            }
            if (evt.type == EventType.MouseDown && evt.button == 0 && rect.Contains(evt.mousePosition))
            {
                for (int side = 0; side < 2; side++)
                {
                    if (!renderer.ToGui(rect, result.Target(side), out var at) || Vector2.Distance(at, evt.mousePosition) > 10f) continue;
                    if (vrSettings.hands != PoseDeckVrPose.HandPlace.Custom)
                    {
                        // Start from where the controllers are now.
                        vrSettings.left = renderer.VrRig.OffsetFor(0, result.LeftTarget);
                        vrSettings.right = renderer.VrRig.OffsetFor(1, result.RightTarget);
                        vrSettings.hands = PoseDeckVrPose.HandPlace.Custom;
                    }
                    vrDragSide = side;
                    vrDragPoint = result.Target(side);
                    GUIUtility.hotControl = id;
                    evt.Use();
                    Repaint();
                    return;
                }
            }
            if (GUIUtility.hotControl != id) return;
            if (evt.type == EventType.MouseDrag && vrDragSide >= 0)
            {
                vrDragPoint = renderer.MoveInView(rect, vrDragPoint, evt.delta);
                var offset = renderer.VrRig.OffsetFor(vrDragSide, vrDragPoint);
                if (vrDragSide == 0) vrSettings.left = offset; else vrSettings.right = offset;
                sampleDirty = true;
                evt.Use();
                Repaint();
            }
            else if (evt.type == EventType.MouseUp && evt.button == 0 || evt.type == EventType.Ignore)
            {
                GUIUtility.hotControl = 0;
                vrDragSide = -1;
                if (evt.type != EventType.Ignore) evt.Use();
                Repaint();
            }
        }

        private PoseDeckVrPose.Result? VrCheckFor(AnimationClip clip) =>
            clip && vrChecks.TryGetValue(clip, out var result) && result.Valid ? result : (PoseDeckVrPose.Result?)null;

        // The deck row's VR mark: "손" when its hands are held, "VR" when the head or hands move a lot in VR.
        private void DrawVrMark(PoseEntry row)
        {
            VrStyles();
            var check = VrCheckFor(row.clip);
            var content = row.vrHands ? new GUIContent("손", "VR에서 손도 포즈대로: 이 포즈 동안 손 트래킹을 끄고 클립대로 둡니다." +
                    (check is PoseDeckVrPose.Result held && held.HeadTurns ? " " + held.Reason(true) + "." : ""))
                : check is PoseDeckVrPose.Result result && result.Caution(false)
                    ? new GUIContent("VR", $"VR 주의: {result.Reason(false)}. 번호를 눌러 ‘VR 손·머리’ 미리보기로 확인하세요.")
                    : new GUIContent("", check == null ? null : "VR에서도 크게 달라지지 않습니다.");
            GUILayout.Label(content, row.vrHands ? vrHeld : vrCaution, GUILayout.Width(22));
        }

        // The gallery card's VR mark, top right of the image.
        private void DrawVrBadge(Rect image, AnimationClip clip)
        {
            if (!(VrCheckFor(clip) is PoseDeckVrPose.Result result) || !result.Caution(false)) return;
            var badge = new Rect(image.xMax - 27f, image.y + 3f, 24f, 15f);
            EditorGUI.DrawRect(badge, new Color(.62f, .38f, .12f, .95f));
            GUI.Label(badge, new GUIContent("VR", $"VR 주의: {result.Reason(false)} (손 ‘{VrHandOptions[(int)vrSettings.hands].text}’ 기준)."), tilePlaceholder);
        }

        // The pose detail's VR part: the mark explained and "VR에서 손도 포즈대로".
        private void DrawVrDetail(PoseEntry row)
        {
            EditorGUILayout.Space(2);
            bool hold = EditorGUILayout.ToggleLeft(new GUIContent("VR에서 손도 포즈대로",
                "VR(3~4점)에서 이 포즈를 하는 동안 손 트래킹을 끄고 손을 클립대로 둡니다. 다른 사람에게 데스크톱과 같은 포즈로 보이지만, 그동안 아바타 손을 움직일 수 없습니다. " +
                "다른 포즈로 바꾸거나 포즈를 끝내면 손 트래킹이 돌아옵니다. 머리는 GoGoLoco의 머리 버튼을 따릅니다."), row.vrHands);
            if (hold != row.vrHands) Change("Edit Pose VR Hands", () => row.vrHands = hold);
            var check = VrCheckFor(row.clip);
            string place = $"손 ‘{VrHandOptions[(int)vrSettings.hands].text}’ 기준";
            string state = check is PoseDeckVrPose.Result result
                ? result.Caution(row.vrHands) ? $"VR 주의: {result.Reason(row.vrHands)} ({place})."
                    : row.vrHands && result.HandsMove ? $"손은 클립대로 둡니다. 그대로 두면 컨트롤러 쪽으로 최대 {result.HandPull * 100f:0}cm 끌려갑니다 ({place})."
                    : $"VR에서도 크게 달라지지 않습니다 ({place})."
                : row.clip && PreviewRoot ? "VR에서 달라지는 정도를 확인하는 중…" : "미리 볼 아바타가 있으면 VR에서 달라지는 정도를 보여 줍니다.";
            EditorGUILayout.LabelField(state + (row.vrHands
                ? " 켜 두면 이 포즈 동안 아바타 손을 움직일 수 없습니다. GoGoLoco가 중간에 손 트래킹을 켜도 1초(움직이는 포즈는 한 번 재생) 안에 다시 클립대로 맞춥니다. ‘생성 및 적용’ 후 반영됩니다."
                : ""), EditorStyles.wordWrappedMiniLabel);
        }

        private void ClearVrChecks()
        {
            vrChecks.Clear();
            vrChecker?.Dispose();
            vrChecker = null;
            vrCheckerFailed = false;
        }

        // Measures the deck's clips first, then the cards in view, for up to 8 ms a tick.
        private void TickVrChecks()
        {
            string key = vrSettings.Key;
            if (key != vrChecksKey) { vrChecks.Clear(); vrChecksKey = key; }
            if (EditorApplication.isUpdating || vrCheckerFailed || !PreviewRoot) return;
            var waiting = deckClips.Concat(visibleCards).Where(c => c && c.humanMotion && !c.legacy && !vrChecks.ContainsKey(c)).Distinct().ToList();
            if (waiting.Count == 0) return;
            if (vrChecker == null)
            {
                try { vrChecker = new PoseDeckPosePreview(PreviewRoot); }
                catch (Exception) { vrCheckerFailed = true; return; }
            }
            double end = EditorApplication.timeSinceStartup + .008;
            foreach (var clip in waiting)
            {
                vrChecks[clip] = MeasureVr(clip);
                if (EditorApplication.timeSinceStartup > end) break;
            }
            Repaint();
        }

        // On the thumbnail frame, so the mark matches the card.
        private PoseDeckVrPose.Result MeasureVr(AnimationClip clip)
        {
            try
            {
                if (!vrChecker.HasHumanoidAvatar) return default;
                vrChecker.SetClip(clip);
                vrChecker.Sample(clip.length * .5f);
                return vrChecker.MeasureVr(vrSettings);
            }
            catch (Exception) { return default; }
        }
    }
}
