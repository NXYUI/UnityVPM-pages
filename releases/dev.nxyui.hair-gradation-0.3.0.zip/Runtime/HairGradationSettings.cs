using System;
using System.Collections.Generic;
using nadena.dev.ndmf;
using UnityEngine;

namespace NXYUI.HairGradation
{
    public enum GradationOutput
    {
        // Into the hair's main texture (a new texture at build, the original stays).
        MainTexture,
        // Into lilToon's Main Color 2nd or 3rd, on a texture of its own; the main texture is untouched.
        LilToonMain2nd,
        LilToonMain3rd,
    }

    // A material of one mesh left out of the gradient (a ribbon or a pin on the hair's own mesh).
    [Serializable]
    public struct ExcludedMaterial
    {
        public Renderer renderer;
        public Material material;
    }

    // One gradient across every part of a hair, set on the hair's root object. The inspector turns these settings into
    // TexTransTool components (a child object), which apply them at build; this component itself is editor-only.
    [DisallowMultipleComponent]
    [AddComponentMenu("NXYUI/Hair Gradation")]
    public sealed class HairGradationSettings : MonoBehaviour, INDMFEditorOnly
    {
        // Renderers below this object left out (accessories, a face mesh).
        public List<Renderer> excluded = new List<Renderer>();
        // Materials of the renderers left out, each on its own mesh; every other material takes part (setups saved
        // before this list existed load it empty, so all of theirs do).
        public List<ExcludedMaterial> excludedMaterials = new List<ExcludedMaterial>();

        public Gradient gradient = DefaultGradient();
        [Range(0f, 1f)] public float opacity = 1f;
        public string blend = "Normal";
        // Where the gradient starts and ends along the hair's height: 0 = the top, 1 = the lowest tip. Above and below,
        // its end colors go on.
        [Range(0f, 1f)] public float start = 0.3f;
        [Range(0f, 1f)] public float end = 1f;

        public Texture2D pattern;
        public Color patternColor = Color.white;
        [Range(0f, 1f)] public float patternOpacity = 1f;
        [Range(1, 16)] public int patternRepeat = 4;
        // On: the pattern shows only where the gradient does (clipped to it).
        public bool patternInsideGradient = true;
        // On: the pattern is projected through to the back of the hair too.
        public bool patternOnBack = true;
        public string patternBlend = "Normal";

        public GradationOutput output = GradationOutput.MainTexture;
        [Range(0f, 32f)] public float padding = 5f;

        // The child object holding the TexTransTool components this tool made, and what they were made for.
        public GameObject generated;
        [HideInInspector] public string generatedFor = "";

        // One color that the hair turns into toward its tips: from its own color at the start (transparent there, so the
        // hair above the start keeps its color) to the full color at the end. The default of 0.2.0 had a second, pink
        // key at the start: a user who changed the color in Unity's gradient editor changed that key (the one it selects
        // first) and still got the default lavender at the tips, and the pink mixed in purple between them.
        public static readonly Color DefaultColor = new Color(0.55f, 0.6f, 1f);

        private static Gradient DefaultGradient()
        {
            var gradient = new Gradient();
            gradient.SetKeys(
                new[] { new GradientColorKey(DefaultColor, 0f), new GradientColorKey(DefaultColor, 1f) },
                new[] { new GradientAlphaKey(0f, 0f), new GradientAlphaKey(1f, 1f) });
            return gradient;
        }
    }
}
