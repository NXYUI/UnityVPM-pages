using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;
using Object = UnityEngine.Object;

namespace PersonalPoseDeck
{
    internal sealed partial class PoseDeckPoseBrowser
    {
        private const int ThumbnailPixels = 128;
        private const int ThumbnailCacheLimit = 180;
        private const float TileMinWidth = 112f;
        private const float TileHeight = 128f;
        private const float HeaderHeight = 24f;
        private const float Gap = 6f;

        private sealed class GalleryGroup
        {
            public string Root;
            public List<Item> Items;
        }

        private sealed class Thumbnail
        {
            public Texture2D Image;
            public LinkedListNode<AnimationClip> Order;
        }

        [SerializeField] private string folderFilter = "";
        private readonly Dictionary<string, bool> groupOpen = new Dictionary<string, bool>(StringComparer.Ordinal);
        private readonly List<GalleryGroup> galleryGroups = new List<GalleryGroup>();
        private readonly Dictionary<AnimationClip, Thumbnail> thumbnails = new Dictionary<AnimationClip, Thumbnail>();
        private readonly LinkedList<AnimationClip> thumbOrder = new LinkedList<AnimationClip>();
        private readonly List<Item> visibleThumbRequests = new List<Item>();
        private string[] folderRoots = { "" }, folderLabels = { "모든 폴더" };
        private Vector2 galleryScroll;
        private PoseDeckPosePreview thumbnailRenderer;
        private string thumbnailProblem;
        private double nextThumbnailTime;
        private GUIStyle tileCaption, tilePlaceholder;

        internal static string GroupRootFor(string path)
        {
            int slash = path.IndexOf('/');
            if (slash < 0) return path;
            int next = path.IndexOf('/', slash + 1);
            return next < 0 ? path.Substring(0, slash) : path.Substring(0, next);
        }

        private static string FolderLabel(string root)
        {
            int slash = root.IndexOf('/');
            if (slash < 0) return root + " (최상위)";
            return root.Substring(slash + 1) + " · " + root.Substring(0, slash);
        }

        private bool MatchesSourceAndType(Item item)
        {
            return item.Clip && (typeFilter != 0 || item.Humanoid) && (typeFilter != 2 || !item.Humanoid) &&
                   (sourceFilter != 1 || item.Path.StartsWith("Assets/", StringComparison.Ordinal)) &&
                   (sourceFilter != 2 || item.Path.StartsWith("Packages/", StringComparison.Ordinal));
        }

        private void RebuildGalleryGroups()
        {
            galleryGroups.Clear();
            galleryGroups.AddRange(filtered.GroupBy(item => item.GroupRoot, StringComparer.Ordinal)
                .OrderBy(group => FolderLabel(group.Key), StringComparer.OrdinalIgnoreCase)
                .Select(group => new GalleryGroup { Root = group.Key, Items = group.ToList() }));
            var roots = new HashSet<string>(index.Where(MatchesSourceAndType).Select(i => i.GroupRoot), StringComparer.Ordinal);
            if (!string.IsNullOrEmpty(folderFilter)) roots.Add(folderFilter);
            folderRoots = new[] { "" }.Concat(roots.OrderBy(FolderLabel, StringComparer.OrdinalIgnoreCase)).ToArray();
            folderLabels = folderRoots.Select(x => x.Length == 0 ? "모든 폴더" : FolderLabel(x)).ToArray();
        }

        private bool IsExpanded(GalleryGroup group, int indexInView)
        {
            if (groupOpen.TryGetValue(group.Root, out var open)) return open;
            return indexInView == 0 || !string.IsNullOrWhiteSpace(search) || !string.IsNullOrEmpty(folderFilter);
        }

        private void SetExpansion(bool open)
        {
            foreach (var group in galleryGroups) groupOpen[group.Root] = open;
            galleryScroll = Vector2.zero;
            Repaint();
        }

        // The left column: the gallery (with adding to the deck under it) or the deck itself, one tab at a time, so the
        // preview on the right keeps the height.
        [SerializeField] private int leftTab;

        private void DrawGallery(float width)
        {
            using (new EditorGUILayout.VerticalScope(GUILayout.Width(width), GUILayout.ExpandHeight(true)))
            {
                var tabs = new[]
                {
                    new GUIContent("갤러리", "프로젝트의 포즈 클립을 찾아 덱에 추가합니다."),
                    new GUIContent(preset ? $"덱 ({preset.poses.Count})" : "덱", "프리셋의 포즈 목록, 포즈별 시작 높이·아이콘·VR 설정, 메뉴 설정."),
                };
                leftTab = GUILayout.Toolbar(Mathf.Clamp(leftTab, 0, 1), tabs, EditorStyles.miniButton);
                if (leftTab == 1) DrawDeckTab();
                else
                {
                    DrawGalleryBody();
                    DrawAddBar();
                }
                // Messages from adding, presets and the preview, under whichever tab is open; × clears it.
                if (!string.IsNullOrEmpty(message))
                    using (new EditorGUILayout.HorizontalScope())
                    {
                        EditorGUILayout.HelpBox(message, MessageType.Info);
                        if (GUILayout.Button(new GUIContent("×", "이 안내 닫기"), EditorStyles.miniButton, GUILayout.Width(20))) message = null;
                    }
            }
        }

        // Under the cards: add the previewed clip or the checked cards to the deck, and the start height they get.
        private void DrawAddBar()
        {
            var clip = active?.Clip;
            int deckIndex = DeckIndexOf(clip);
            using (new EditorGUILayout.HorizontalScope())
            {
                category = EditorGUILayout.Popup(category, PoseDeckBuilder.CategoryNames, GUILayout.Width(56));
                using (new EditorGUI.DisabledScope(!preset || active == null || !active.Humanoid || deckIndex >= 0))
                    if (GUILayout.Button(new GUIContent(deckIndex >= 0 ? "덱에 있는 클립" : "현재 클립 추가", "오른쪽 미리보기의 클립을 이 분류로 덱에 넣습니다."),
                        EditorStyles.miniButtonLeft)) AddToPreset(new[] { active });
                using (new EditorGUI.DisabledScope(!preset || queued.Count == 0))
                    if (GUILayout.Button(new GUIContent($"선택 목록 추가 ({queued.Count})", "카드에서 체크한 클립을 모두 이 분류로 덱에 넣습니다."),
                        EditorStyles.miniButtonRight)) AddToPreset(index.Where(i => queued.Contains(i.Clip)).ToArray());
            }
            DrawAddHeight(clip, deckIndex);
            if (!preset) EditorGUILayout.LabelField("프리셋을 지정하면 포즈를 추가할 수 있어요.", EditorStyles.miniLabel);
            else if (clip && active != null && !active.Humanoid) EditorGUILayout.LabelField("Pose Deck에는 Humanoid 클립만 추가할 수 있어요.", EditorStyles.miniLabel);
        }

        // Three rows above the cards: search and type; avatar filter and regex; folder, expand/collapse, count and rescan.
        private void DrawGalleryBody()
        {
            EditorGUI.BeginChangeCheck();
            using (new EditorGUILayout.HorizontalScope())
            {
                search = EditorGUILayout.TextField(search, EditorStyles.toolbarSearchField, GUILayout.MinWidth(80));
                sourceFilter = EditorGUILayout.Popup(sourceFilter, SourceOptions, GUILayout.Width(74));
                typeFilter = EditorGUILayout.Popup(typeFilter, TypeOptions, GUILayout.Width(84));
            }
            if (EditorGUI.EndChangeCheck()) { refreshFilter = true; galleryScroll = Vector2.zero; }
            DrawAvatarFilters();
            // Not while a control is held: new cards shift the ids of everything drawn after the gallery, and a
            // slider being dragged in the right panel would lose its grip (the scan refilters every step).
            if (refreshFilter && GUIUtility.hotControl == 0) Filter();

            using (new EditorGUILayout.HorizontalScope())
            {
                int selected = Mathf.Max(0, Array.IndexOf(folderRoots, folderFilter ?? ""));
                int folder = EditorGUILayout.Popup(selected, folderLabels, GUILayout.MinWidth(80));
                if (folder != selected)
                {
                    folderFilter = folderRoots[folder];
                    if (!string.IsNullOrEmpty(folderFilter)) groupOpen[folderFilter] = true;
                    galleryScroll = Vector2.zero;
                    Filter();
                }
                if (GUILayout.Button(new GUIContent("+", "모든 폴더 펼치기"), EditorStyles.miniButtonLeft, GUILayout.Width(20))) SetExpansion(true);
                if (GUILayout.Button(new GUIContent("−", "모든 폴더 접기"), EditorStyles.miniButtonRight, GUILayout.Width(20))) SetExpansion(false);
                var total = pending == null ? $"{filtered.Count:N0} / {index.Count:N0}" : $"검색 중 {cursor:N0}/{pending.Length:N0}";
                var tip = (pending == null ? $"폴더 {galleryGroups.Count:N0}개, 보이는 클립 {filtered.Count:N0}개 / 전체 {index.Count:N0}개."
                    : $"찾은 클립 {filtered.Count:N0}개.") + (skippedPaths != 0 ? $" 읽지 못한 파일 {skippedPaths}개." : "");
                GUILayout.Label(new GUIContent(total + (skippedPaths != 0 && pending == null ? " ⚠" : ""), tip), EditorStyles.miniLabel, GUILayout.ExpandWidth(false));
                if (GUILayout.Button(new GUIContent(scanStale ? "새로 검색 *" : "새로 검색",
                    scanStale ? "프로젝트가 바뀌었습니다. 다시 검색하면 새 클립이 보입니다." : "프로젝트의 애니메이션을 다시 찾습니다."),
                    EditorStyles.miniButton, GUILayout.Width(66))) startScan = true;
            }

            var viewport = GUILayoutUtility.GetRect(250, 160, GUILayout.ExpandWidth(true), GUILayout.ExpandHeight(true));
            DrawGalleryViewport(viewport);
        }

        // The last real viewport. In Layout events GetRect hands out a 1×1 placeholder.
        private Rect galleryViewport;

        // The scroll view is opened in every event, Layout included, with the same cards: Unity applies a wheel scroll on
        // the next event's BeginScrollView with the same control id, and when the gallery skipped Layout, the scroll
        // view under the preview took that id there and swallowed the gallery's scroll.
        private void DrawGalleryViewport(Rect viewport)
        {
            bool repaint = Event.current.type == EventType.Repaint;
            if (repaint) { visibleThumbRequests.Clear(); visibleCards.Clear(); }
            if (Event.current.type == EventType.Layout) viewport = galleryViewport;
            else galleryViewport = viewport;
            float contentWidth = Mathf.Max(1f, viewport.width - 17f);
            int columns = Mathf.Max(1, Mathf.FloorToInt((contentWidth - Gap) / (TileMinWidth + Gap)));
            float tileWidth = (contentWidth - Gap * (columns + 1)) / columns;
            float rowStride = TileHeight + Gap;
            float height = Gap;
            for (int i = 0; i < galleryGroups.Count; i++)
            {
                var group = galleryGroups[i];
                height += HeaderHeight + Gap;
                if (IsExpanded(group, i)) height += ((group.Items.Count + columns - 1) / columns) * rowStride;
            }
            if (repaint) EditorGUI.DrawRect(viewport, new Color(.15f, .16f, .18f));
            bool drawable = viewport.width >= 40 && viewport.height >= 40;
            if (drawable) galleryScroll.y = Mathf.Clamp(galleryScroll.y, 0, Mathf.Max(0, height - viewport.height));
            galleryScroll = GUI.BeginScrollView(viewport, galleryScroll, new Rect(0, 0, contentWidth, height), false, true);
            try { if (drawable) DrawGalleryCards(viewport, contentWidth, columns, tileWidth, rowStride, repaint); }
            finally { GUI.EndScrollView(); }
            if (drawable && galleryGroups.Count == 0)
            {
                string label = pending != null || startScan ? "프로젝트에서 애니메이션을 찾고 있어요…" : "이 필터에 맞는 클립이 없어요.";
                GUI.Label(new Rect(viewport.x + 12, viewport.y + 10, viewport.width - 24, 22), label, EditorStyles.miniLabel);
            }
        }

        private void DrawGalleryCards(Rect viewport, float contentWidth, int columns, float tileWidth, float rowStride, bool repaint)
        {
            float top = galleryScroll.y, bottom = top + viewport.height;
            float y = Gap;
            for (int i = 0; i < galleryGroups.Count && y < bottom; i++)
            {
                var group = galleryGroups[i];
                bool open = IsExpanded(group, i);
                var header = new Rect(Gap, y, contentWidth - Gap * 2, HeaderHeight);
                if (header.yMax >= top)
                {
                    if (repaint) EditorGUI.DrawRect(header, new Color(.27f, .28f, .31f));
                    var foldRect = new Rect(header.x + 13, header.y, header.width - 17, header.height);
                    bool next = EditorGUI.Foldout(foldRect, open,
                        new GUIContent($"{FolderLabel(group.Root)}  ({group.Items.Count:N0})", group.Root), true);
                    if (next != open) { groupOpen[group.Root] = next; Repaint(); }
                }
                y += HeaderHeight + Gap;
                if (!open) continue;
                int rows = (group.Items.Count + columns - 1) / columns;
                int first = Mathf.Clamp(Mathf.FloorToInt((top - y) / rowStride), 0, rows);
                int last = Mathf.Clamp(Mathf.CeilToInt((bottom - y) / rowStride), 0, rows);
                for (int row = first; row < last; row++)
                    for (int col = 0; col < columns; col++)
                    {
                        int itemIndex = row * columns + col;
                        if (itemIndex >= group.Items.Count) break;
                        var card = new Rect(Gap + col * (tileWidth + Gap), y + row * rowStride, tileWidth, TileHeight);
                        DrawCard(card, group.Items[itemIndex], repaint);
                    }
                y += rows * rowStride;
            }
        }

        private void DrawCard(Rect card, Item item, bool repaint)
        {
            if (tileCaption == null)
            {
                tileCaption = new GUIStyle(EditorStyles.miniLabel) { clipping = TextClipping.Clip, wordWrap = false };
                tilePlaceholder = new GUIStyle(EditorStyles.miniLabel) { alignment = TextAnchor.MiddleCenter, clipping = TextClipping.Clip };
            }
            bool selected = active != null && active.Clip == item.Clip;
            bool marked = queued.Contains(item.Clip);
            var image = new Rect(card.x + 3f, card.y + 3f, card.width - 6f, card.height - 25f);
            var tooltip = item.Name + "\n" + item.Path;
            if (repaint)
            {
                EditorGUI.DrawRect(card, selected ? new Color(.23f, .46f, .70f) : marked ? new Color(.25f, .39f, .32f) : new Color(.24f, .25f, .28f));
                EditorGUI.DrawRect(image, new Color(.19f, .21f, .24f));
            }
            if (GUI.Button(image, new GUIContent("", tooltip), GUIStyle.none)) Select(item);
            if (repaint)
            {
                if (thumbnails.TryGetValue(item.Clip, out var thumb))
                {
                    Touch(thumb);
                    if (thumb.Image) GUI.DrawTexture(image, thumb.Image, ScaleMode.ScaleToFit, false);
                    else GUI.Label(image, "미리보기 없음", tilePlaceholder);
                }
                else if (avatar && item.Clip && !item.Clip.legacy && thumbnailProblem == null)
                {
                    visibleThumbRequests.Add(item);
                    GUI.Label(image, "미리보기 준비 중", tilePlaceholder);
                }
                else GUI.Label(image, thumbnailProblem ?? (avatar ? "미리보기 없음" : "아바타 선택"), tilePlaceholder);
                if (deckClips.Contains(item.Clip))
                {
                    var badge = new Rect(image.x + 3f, image.y + 3f, 24f, 15f);
                    EditorGUI.DrawRect(badge, new Color(.20f, .48f, .32f, .95f));
                    GUI.Label(badge, new GUIContent("덱", "현재 프리셋에 들어 있는 클립입니다."), tilePlaceholder);
                }
                if (item.Humanoid && item.Clip)
                {
                    visibleCards.Add(item.Clip);
                    DrawVrBadge(image, item.Clip);
                }
            }
            using (new EditorGUI.DisabledScope(!item.Humanoid))
            {
                bool next = GUI.Toggle(new Rect(card.x + 5, card.yMax - 19, 15, 17), marked, new GUIContent("", "프리셋에 넣을 목록에 선택"));
                if (next != marked) { if (next) queued.Add(item.Clip); else queued.Remove(item.Clip); Repaint(); }
            }
            GUI.Label(new Rect(card.x + 22, card.yMax - 20, card.width - 26, 18), new GUIContent(item.Name, tooltip), tileCaption);
        }

        private void Touch(Thumbnail thumbnail)
        {
            thumbOrder.Remove(thumbnail.Order);
            thumbOrder.AddLast(thumbnail.Order);
        }

        private void SaveThumbnail(AnimationClip clip, Texture2D texture)
        {
            thumbnails.Add(clip, new Thumbnail { Image = texture, Order = thumbOrder.AddLast(clip) });
            while (thumbnails.Count > ThumbnailCacheLimit)
            {
                var key = thumbOrder.First.Value;
                if (thumbnails[key].Image) Object.DestroyImmediate(thumbnails[key].Image);
                thumbnails.Remove(key);
                thumbOrder.RemoveFirst();
            }
        }

        // The renderer behind the gallery thumbnails, made on first use. Null when there is no avatar or it cannot be
        // made (thumbnailProblem says why).
        private PoseDeckPosePreview ThumbnailRenderer()
        {
            var source = PreviewRoot;
            if (!source || thumbnailProblem != null) return null;
            if (thumbnailRenderer != null) return thumbnailRenderer;
            try
            {
                thumbnailRenderer = new PoseDeckPosePreview(source);
                if (thumbnailsInGame)
                {
                    thumbnailRenderer.Mode = (PoseDeckPosePreview.Tracking)previewTracking;
                    thumbnailRenderer.UseGoGoLoco(gogoPreview ? GoGoLocoSource() : null);
                    thumbnailRenderer.ApplyLighting(lighting);
                    thumbnailRenderer.ApplyMaterialControls(lightControls, lightFilter);
                }
                if (!thumbnailRenderer.HasRenderers) thumbnailProblem = "렌더러 없음";
            }
            catch (Exception e)
            {
                thumbnailProblem = "미리보기 오류";
                message = "갤러리 미리보기: " + e.Message;
            }
            if (thumbnailProblem == null) return thumbnailRenderer;
            Repaint();
            return null;
        }

        private void TickThumbnail()
        {
            if (!PreviewRoot || thumbnailProblem != null || visibleThumbRequests.Count == 0 || EditorApplication.isUpdating) return;
            var now = EditorApplication.timeSinceStartup;
            if (now < nextThumbnailTime) return;
            var next = visibleThumbRequests.FirstOrDefault(i => i.Clip && !thumbnails.ContainsKey(i.Clip));
            if (next == null) return;
            nextThumbnailTime = now + .05;
            if (ThumbnailRenderer() == null) return;

            Texture2D texture = null;
            try
            {
                if (!next.Humanoid || thumbnailRenderer.HasHumanoidAvatar)
                {
                    if (thumbnailsInGame) thumbnailRenderer.StartHeight = PreviewStartHeight(next.Clip, out _, pending: false);
                    texture = thumbnailRenderer.CaptureThumbnail(next.Clip, ThumbnailPixels);
                }
            }
            catch (Exception e)
            {
                message = $"{next.Name} 미리보기: {e.Message}";
            }
            SaveThumbnail(next.Clip, texture);
            Repaint();
        }

        // With "썸네일에도", thumbnails show the lights, light-package values, tracking and start heights. When those change,
        // the thumbnails are drawn again once the change has settled (so dragging a light does not re-render every frame).
        private string thumbnailLook, pendingThumbnailLook;
        private double thumbnailLookChangedAt, thumbnailLookCheckedAt;

        private string ThumbnailLook()
        {
            if (!thumbnailsInGame) return "";
            var look = new System.Text.StringBuilder(JsonUtility.ToJson(lighting));
            look.Append('|').Append(previewTracking).Append(gogoPreview ? 'G' : '-');
            foreach (var control in lightControls) look.Append('|').Append(control.Label).Append('=').Append(control.Value.ToString("R"));
            if (preset)
                foreach (var row in preset.poses)
                    if (row != null && row.clip)
                        look.Append('|').Append(row.clip.GetInstanceID()).Append(row.overrideHeight ? row.height.ToString("R") : "-");
            return look.ToString();
        }

        private void RefreshStaleThumbnails()
        {
            double now = EditorApplication.timeSinceStartup;
            if (now - thumbnailLookCheckedAt < .25) return;
            thumbnailLookCheckedAt = now;
            string look = ThumbnailLook();
            if (thumbnailLook == null || look == thumbnailLook) { thumbnailLook = look; pendingThumbnailLook = null; return; }
            if (look != pendingThumbnailLook) { pendingThumbnailLook = look; thumbnailLookChangedAt = now; return; }
            if (now - thumbnailLookChangedAt < .5) return;
            ClearThumbnails();
            Repaint();
        }

        private void ClearThumbnails()
        {
            thumbnailLook = ThumbnailLook();
            pendingThumbnailLook = null;
            foreach (var thumb in thumbnails.Values) if (thumb.Image) Object.DestroyImmediate(thumb.Image);
            thumbnails.Clear();
            thumbOrder.Clear();
            visibleThumbRequests.Clear();
            thumbnailRenderer?.Dispose();
            thumbnailRenderer = null;
            thumbnailProblem = null;
            nextThumbnailTime = 0;
        }
    }
}
