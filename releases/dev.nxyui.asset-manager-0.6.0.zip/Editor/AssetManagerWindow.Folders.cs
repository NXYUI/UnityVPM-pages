using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;

namespace NXYUI.AssetManager
{
    // The 폴더 지정 tab (UI Toolkit): folders found by imports (proposals) and folders no asset owns yet. A folder becomes
    // an asset only when the user confirms it here, in the Project window's context menu or in the folder's Inspector card.
    // Look: design-system/unityvpm/pages/asset-manager.md ("Folder tab").
    internal sealed partial class AssetManagerWindow
    {
        private FolderProposals.Result unassignedCache;
        private readonly HashSet<string> checkedFolders = new HashSet<string>();
        private string groupName = "";
        private string foldersMessage;
        private bool foldersMessageWarn, showIgnored, showHidden;

        private ScrollView foldersScroll;
        private VisualElement foldersBody, joinBar;
        private Label joinCount, joinReason;
        private TextField joinName;
        private Button joinButton;
        private IVisualElementScheduledItem foldersItem;
        private Vector2 foldersScrollKept;
        // The folders the list shows (for the join bar), made with the list so a check never looks up every folder.
        private readonly Dictionary<string, string> listedByGuid = new Dictionary<string, string>();
        private FolderProposals.Result listedFor;

        private void BuildFoldersPage(VisualElement into)
        {
            var column = new VisualElement();
            column.AddToClassList("am-folders");
            foldersScroll = new ScrollView();
            foldersScroll.AddToClassList("am-grow");
            foldersBody = new VisualElement();
            foldersBody.AddToClassList("am-folders-body");
            foldersScroll.Add(foldersBody);
            column.Add(foldersScroll);

            // The join bar stays at the bottom while folders are checked, so joining never needs a scroll to the end.
            joinBar = new VisualElement();
            joinBar.AddToClassList("am-joinbar");
            joinCount = UiText("", "am-joinbar-count");
            joinBar.Add(joinCount);
            joinName = new TextField("에셋 이름") { value = groupName, tooltip = "체크한 폴더로 만들 에셋의 이름" };
            joinName.AddToClassList("am-field");
            joinName.AddToClassList("am-grow");
            joinName.RegisterValueChangedCallback(e =>
            {
                groupName = e.newValue ?? "";
                UpdateJoinBar();
            });
            joinBar.Add(joinName);
            joinButton = UiButton("하나로 묶어 에셋 만들기", "am-button--primary", JoinChecked);
            joinBar.Add(joinButton);
            joinBar.Add(UiButton("체크 풀기", "am-button--quiet", () =>
            {
                checkedFolders.Clear();
                RefreshFoldersPage();
            }));
            // A disabled button shows no tooltip: the reason sits in the bar.
            joinReason = UiText("에셋 이름을 적으세요.", "am-joinbar-reason");
            joinBar.Add(joinReason);
            column.Add(joinBar);
            into.Add(column);
            RefreshFoldersPage();
            KeepScroll(foldersScroll, foldersScrollKept);
        }

        private void RememberFoldersScroll()
        {
            if (foldersScroll != null) foldersScrollKept = foldersScroll.scrollOffset;
        }

        // A rebuild waits while the user types in a field of the page (a proposal's name), so nothing typed is lost.
        private void ScheduleFolders()
        {
            if (foldersBody == null || root == null) return;
            foldersItem?.Pause();
            foldersItem = root.schedule.Execute(() =>
            {
                if (Typing(foldersBody)) ScheduleFoldersLater();
                else RefreshFoldersPage();
            });
        }

        private void ScheduleFoldersLater()
        {
            foldersItem = root.schedule.Execute(ScheduleFolders).StartingIn(800);
        }

        private bool Typing(VisualElement area) =>
            root?.panel?.focusController?.focusedElement is VisualElement focused && area != null && area.Contains(focused) &&
            (focused is TextField || focused.GetFirstAncestorOfType<TextField>() != null);

        private void RefreshFoldersPage()
        {
            if (foldersBody == null) return;
            var offset = foldersScroll.scrollOffset;
            var focus = FocusSlot(foldersBody);
            foldersBody.Clear();
            foldersBody.Add(UiText("어떤 폴더를 에셋 하나로 볼지 정해요. Project 창에서 폴더를 우클릭하고 ‘NXYUI › 에셋으로 지정’을 눌러도 돼요.", "am-hint"));
            if (!string.IsNullOrEmpty(foldersMessage)) foldersBody.Add(UiNote(foldersMessage, foldersMessageWarn));
            foldersBody.Add(ProposalsSection());
            var found = unassignedCache ?? (unassignedCache = FolderProposals.Find());
            if (listedFor != found)
            {
                listedFor = found;
                listedByGuid.Clear();
                foreach (var path in found.Groups.SelectMany(g => g.Paths).Concat(found.Hidden.Select(h => h.Path)))
                    listedByGuid[AssetDatabase.AssetPathToGUID(path)] = path;
                checkedFolders.IntersectWith(listedByGuid.Keys);
            }
            foldersBody.Add(UnassignedSection(found));
            if (found.Hidden.Count > 0) foldersBody.Add(HiddenFold(found));
            if (AssetStore.State.ignoredFolders.Count > 0) foldersBody.Add(IgnoredFold());
            UpdateJoinBar();
            foldersScroll.scrollOffset = offset;
            RestoreFocus(foldersBody, focus);
        }

        private VisualElement ProposalsSection()
        {
            var proposals = AssetStore.State.proposals;
            var section = UiSection($"가져오면서 찾은 후보 ({proposals.Count}개)");
            if (proposals.Count == 0)
            {
                section.Add(UiText("패키지를 가져오면 새로 생긴 폴더가 여기에 올라와요.", "am-text"));
                return section;
            }
            foreach (var proposal in proposals.ToList())
            {
                var paths = proposal.folders.Select(AssetDatabase.GUIDToAssetPath).Where(AssetDatabase.IsValidFolder).ToList();
                var card = new VisualElement();
                card.AddToClassList("am-item");
                var head = new VisualElement();
                head.AddToClassList("am-item-head");
                var name = new TextField { value = proposal.name, isDelayed = true, tooltip = "에셋 이름. Enter로 바꿔요." };
                name.AddToClassList("am-field");
                name.AddToClassList("am-grow");
                name.RegisterValueChangedCallback(e =>
                {
                    if (string.IsNullOrWhiteSpace(e.newValue)) return;
                    proposal.name = e.newValue.Trim();
                    AssetStore.SaveState();
                });
                head.Add(name);
                var make = UiButton("에셋으로 만들기", "am-button--primary", () =>
                {
                    MakeAsset(paths, proposal.name, proposal.package, proposal.id);
                    RefreshFoldersPage();
                }, paths.Count == 0 ? "폴더가 없어졌어요." : "이 폴더로 에셋을 만들어요.");
                make.SetEnabled(paths.Count > 0);
                head.Add(make);
                head.Add(UiButton("무시", "am-button--quiet", () =>
                {
                    AssetStore.State.ignoredFolders.AddRange(proposal.folders.Where(g => !AssetStore.State.ignoredFolders.Contains(g)));
                    proposals.Remove(proposal);
                    AssetStore.SaveState();
                    unassignedCache = null;
                    RefreshFoldersPage();
                }, "다시 제안하지 않아요. 아래 ‘무시한 폴더’에서 되돌릴 수 있어요."));
                card.Add(head);
                foreach (var path in paths) card.Add(Tip(UiText("› " + path, "am-path"), path));
                if (paths.Count == 0) card.Add(UiNote("폴더를 찾지 못했어요(지웠거나 옮김). ‘무시’로 지우세요.", true));
                var meta = new VisualElement();
                meta.AddToClassList("am-chips");
                if (proposal.package.Length > 0) meta.Add(UiText("가져온 패키지: " + proposal.package, "am-text"));
                var cache = AssetStore.SearchFor(proposal.id);
                // A search cut off by a domain reload starts again when the proposal is shown.
                if (BoothLinker.NeedsSearch(cache) && !BoothLinker.IsSearching(proposal.id))
                    BoothLinker.SearchSoon(proposal.id, proposal.name, paths, proposal.package);
                if (BoothLinker.IsSearching(proposal.id) || BoothLinker.NeedsSearch(cache)) meta.Add(UiText("Booth에서 찾는 중…", "am-text"));
                else if (cache != null && cache.results.Count > 0)
                    meta.Add(Tip(UiChip($"Booth 후보 {cache.results.Count}개", "am-chip--ok"), "에셋으로 만든 뒤 에셋 탭에서 골라 연결해요. 첫 후보: " + cache.results[0].name));
                if (meta.childCount > 0) card.Add(meta);
                section.Add(card);
            }
            return section;
        }

        private VisualElement UnassignedSection(FolderProposals.Result found)
        {
            var section = UiSection($"상품으로 보이는 폴더 ({found.Count}개)");
            if (found.Count == 0)
            {
                section.Add(UiText("Assets 안의 상품 폴더는 모두 에셋이거나 무시한 폴더예요. 다른 폴더는 Project 창에서 우클릭해 지정할 수 있어요.", "am-text"));
                return section;
            }
            section.Add(UiText("폴더에 든 파일로 상품 폴더를 짐작했어요. 맞으면 ‘에셋으로 만들기’를 누르세요. 한 상품이 여러 폴더로 나뉘어 보이면 " +
                               "묶음 위의 ‘전체를 에셋 하나로’를 누르거나, 폴더를 체크해 아래 막대에서 하나로 묶으세요.", "am-text"));
            foreach (var group in found.Groups) section.Add(GroupView(group));
            return section;
        }

        // The proposals found in one folder under Assets: the folder itself, or a card with the products inside it.
        private VisualElement GroupView(FolderProposals.Group group)
        {
            if (group.Paths.Count == 1 && group.Paths[0] == group.Top) return FolderRow(group.Paths[0], Path.GetFileName(group.Top));
            var box = new VisualElement();
            box.AddToClassList("am-group");
            var head = new VisualElement();
            head.AddToClassList("am-group-head");
            head.Add(FolderIcon());
            head.Add(Tip(UiText(Path.GetFileName(group.Top), "am-group-name"), group.Top));
            head.Add(UiChip($"상품 {group.Paths.Count}개", ""));
            head.Add(Spacer());
            head.Add(UiButton("보기", "am-button--quiet", () => Ping(group.Top), group.Top));
            var problem = AssetFolders.Problem(group.Top);
            var whole = UiButton("전체를 에셋 하나로", "", () =>
            {
                MakeAsset(new List<string> { group.Top }, Path.GetFileName(group.Top), "", null);
                RefreshFoldersPage();
            }, problem ?? $"‘{Path.GetFileName(group.Top)}’ 폴더 전체를 에셋 하나로 만들어요. 아래 {group.Paths.Count}개가 모두 들어가요.");
            whole.SetEnabled(problem == null);
            head.Add(whole);
            box.Add(head);
            if (problem != null) box.Add(UiText("전체를 묶을 수 없어요: " + problem, "am-text"));
            // Inside a group, the path from the group's folder (샵 › 상품).
            foreach (var path in group.Paths)
            {
                var row = FolderRow(path, path.Substring(group.Top.Length + 1).Replace("/", " › "));
                row.AddToClassList("am-folder-row--nested");
                box.Add(row);
            }
            return box;
        }

        // A row: checkbox, icon, name, then 보기, 에셋으로 만들기, 무시. A hidden folder (reason given) has its reason as a
        // chip and no 무시; one that cannot be an asset says why under the row, and its box and button are off.
        private VisualElement FolderRow(string path, string shown, string reason = null)
        {
            var guid = AssetDatabase.AssetPathToGUID(path);
            var row = new VisualElement();
            row.AddToClassList("am-folder-row");
            var problem = reason != null ? AssetFolders.Problem(path) : null;
            var check = new Toggle
            {
                value = problem == null && checkedFolders.Contains(guid),
                tooltip = problem ?? "체크한 폴더를 아래 막대에서 에셋 하나로 묶을 수 있어요.",
            };
            check.AddToClassList("am-check");
            check.SetEnabled(problem == null);
            row.EnableInClassList("am-folder-row--on", check.value);
            check.RegisterValueChangedCallback(e =>
            {
                if (e.target != check) return;
                row.EnableInClassList("am-folder-row--on", e.newValue);
                SetChecked(guid, path, e.newValue);
            });
            row.Add(check);
            row.Add(FolderIcon());
            row.Add(Tip(UiText(shown, "am-folder-name"), path));
            if (reason != null) row.Add(UiChip(reason, ""));
            row.Add(UiButton("보기", "am-button--quiet", () => Ping(path), path));
            var make = UiButton("에셋으로 만들기", "", () =>
            {
                MakeAsset(new List<string> { path }, Path.GetFileName(path), "", null);
                RefreshFoldersPage();
            }, problem ?? (reason != null ? "그래도 상품이라면 에셋으로 등록해요." : $"‘{Path.GetFileName(path)}’ 폴더를 상품 하나로 등록해요."));
            make.SetEnabled(problem == null);
            row.Add(make);
            if (reason == null)
                row.Add(UiButton("무시", "am-button--quiet", () =>
                {
                    AssetStore.State.ignoredFolders.Add(guid);
                    checkedFolders.Remove(guid);
                    AssetStore.SaveState();
                    unassignedCache = null;
                    RefreshFoldersPage();
                }, "도구·SDK 폴더처럼 상품이 아닌 폴더는 목록에서 숨겨요."));
            if (problem == null) return row;
            var block = new VisualElement();
            block.Add(row);
            block.Add(UiText("에셋으로 만들 수 없어요: " + problem, "am-row-note"));
            return block;
        }

        private void SetChecked(string guid, string path, bool on)
        {
            if (on)
            {
                checkedFolders.Add(guid);
                // The first checked folder names the asset until the user writes a name (no change event: one update).
                if (string.IsNullOrWhiteSpace(groupName))
                {
                    groupName = Path.GetFileName(path);
                    joinName.SetValueWithoutNotify(groupName);
                }
            }
            else checkedFolders.Remove(guid);
            UpdateJoinBar();
        }

        private List<string> CheckedPaths() =>
            checkedFolders.Select(g => listedByGuid.TryGetValue(g, out var path) ? path : null).Where(p => p != null).ToList();

        private void UpdateJoinBar()
        {
            if (joinBar == null) return;
            var chosen = CheckedPaths();
            joinBar.EnableInClassList("am-hidden", chosen.Count == 0);
            if (chosen.Count == 0 && groupName.Length > 0)
            {
                groupName = "";
                joinName.SetValueWithoutNotify("");
            }
            joinCount.text = $"체크한 폴더 {chosen.Count}개";
            var named = !string.IsNullOrWhiteSpace(groupName);
            joinButton.SetEnabled(named);
            joinButton.tooltip = named ? $"체크한 {chosen.Count}개 폴더를 에셋 하나로 만들어요." : "에셋 이름을 적으세요.";
            joinReason.EnableInClassList("am-hidden", named);
        }

        // On failure the checks and the name stay, so the user can fix the choice instead of starting over.
        private void JoinChecked()
        {
            var chosen = CheckedPaths();
            if (chosen.Count == 0 || string.IsNullOrWhiteSpace(groupName)) return;
            if (MakeAsset(chosen, groupName.Trim(), "", null)) checkedFolders.Clear();
            RefreshFoldersPage();
        }

        // Folders left out on their own (empty, written by tools, Unity's special folders), with the reason. They can
        // still be made into an asset from here. Rows are made when the fold first opens.
        private VisualElement HiddenFold(FolderProposals.Result found) =>
            Fold($"자동으로 숨긴 폴더 ({found.Hidden.Count}개)", showHidden, open => showHidden = open, fold =>
            {
                fold.Add(UiText("빈 폴더, 도구가 만든 폴더, Unity 특수 폴더예요. 그래도 상품이면 에셋으로 만들 수 있어요.", "am-text"));
                foreach (var (path, reason) in found.Hidden) fold.Add(FolderRow(path, path.Substring("Assets/".Length), reason));
            });

        private VisualElement IgnoredFold()
        {
            var ignored = AssetStore.State.ignoredFolders;
            return Fold($"무시한 폴더 ({ignored.Count}개)", showIgnored, open => showIgnored = open, fold =>
            {
                foreach (var guid in ignored.ToList())
                {
                    var path = AssetDatabase.GUIDToAssetPath(guid);
                    var row = new VisualElement();
                    row.AddToClassList("am-folder-row");
                    row.Add(FolderIcon());
                    row.Add(Tip(UiText(path.Length > 0 ? path.Substring(Math.Min(path.Length, "Assets/".Length)) : "(없어진 폴더)", "am-folder-name"), path));
                    row.Add(UiButton("다시 보이기", "am-button--quiet", () =>
                    {
                        ignored.Remove(guid);
                        AssetStore.SaveState();
                        unassignedCache = null;
                        RefreshFoldersPage();
                    }, "‘상품으로 보이는 폴더’에 다시 올려요."));
                    fold.Add(row);
                }
            });
        }

        private static Foldout Fold(string title, bool open, Action<bool> remember, Action<Foldout> fill)
        {
            var fold = new Foldout { text = title, value = open };
            fold.AddToClassList("am-section");
            fold.AddToClassList("am-fold");
            fold.AddToClassList("am-fold--section");
            var filled = false;
            void FillOnce()
            {
                if (filled) return;
                filled = true;
                fill(fold);
            }
            if (open) FillOnce();
            // The rows' checkboxes send the same kind of change; only the fold's own counts.
            fold.RegisterValueChangedCallback(e =>
            {
                if (e.target != fold) return;
                remember(e.newValue);
                if (e.newValue) FillOnce();
            });
            return fold;
        }

        private bool MakeAsset(List<string> paths, string name, string package, string proposalId)
        {
            try
            {
                var asset = AssetFolders.Create(paths, name, package);
                if (proposalId != null) BoothLinker.Transfer(proposalId, asset.id);
                BoothLinker.SearchOnce(asset.id, asset.name, AssetFolders.ExistingFolders(asset), asset.package);
                foldersMessage = $"‘{asset.name}’ 에셋을 만들었어요. 에셋 탭에서 Booth 연결과 조립을 할 수 있어요.";
                foldersMessageWarn = false;
                selectedAsset = asset.id;
                unassignedCache = null;
                return true;
            }
            catch (InvalidOperationException e)
            {
                foldersMessage = "에셋으로 만들지 못했어요: " + e.Message;
                foldersMessageWarn = true;
                return false;
            }
        }

        private static void Ping(string path) => EditorGUIUtility.PingObject(AssetDatabase.LoadAssetAtPath<DefaultAsset>(path));
    }
}
