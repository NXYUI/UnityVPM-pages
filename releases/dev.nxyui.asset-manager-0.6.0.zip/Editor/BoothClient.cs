using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text.RegularExpressions;
using UnityEditor;
using UnityEngine;
using UnityEngine.Networking;

namespace NXYUI.AssetManager
{
    // A Booth product as this tool keeps it: enough to show a card and open its page.
    [Serializable]
    internal sealed class BoothItem
    {
        public long id;
        public string name = "";
        public string shop = "";
        public string shopUrl = "";
        public string thumbnail = "";
        public bool adult;
        // Booth's category in Japanese (shop lists give it), e.g. "3D衣装"; empty when not known.
        public string category = "";
        public string[] tags = Array.Empty<string>();

        public string Url => "https://booth.pm/ja/items/" + id;
    }

    // Booth has no public API. Search reads the public search page, a shop's products come from the shop's own items
    // page, and product details come from the item page's ".json" form, all as a browser would. Requests go out one at a time, at least a second apart, and only when the
    // user adds an asset or asks; results are cached by the caller. Age-restricted products are not searched for (the
    // search page leaves them out) and the age check is never bypassed: such products are linked by URL.
    internal static class BoothClient
    {
        private const string Origin = "https://booth.pm/ja/";
        // Searches stay in Booth's 3D Models category (avatars, outfits, accessories, tools for them): its browse
        // page takes the same query and lists the same cards as the search page.
        private const string ModelsCategory = "3Dモデル";
        private const double Spacing = 1.0;
        private static readonly Queue<(string Url, Action<UnityWebRequest> Done)> Pending = new Queue<(string, Action<UnityWebRequest>)>();
        private static UnityWebRequest running;
        private static double nextSend;

        public static bool Busy => running != null || Pending.Count > 0;

        // Set by the tests: no request leaves the editor.
        internal static bool Offline;
        private const string OfflineMessage = "Booth에 연결하지 않는 상태예요.";

        public static void Search(string query, Action<List<BoothItem>, string> done)
        {
            if (Offline)
            {
                done(null, OfflineMessage);
                return;
            }
            query = (query ?? "").Replace('/', ' ').Trim();
            if (query.Length == 0)
            {
                done(new List<BoothItem>(), null);
                return;
            }
            Send(Origin + "browse/" + Uri.EscapeDataString(ModelsCategory) + "?q=" + Uri.EscapeDataString(query), request =>
            {
                if (request.result != UnityWebRequest.Result.Success) done(null, Failure(request));
                else done(ParseSearch(request.downloadHandler.text), null);
            });
        }

        // One page (18 products) of a shop's own list, by the shop's booth.pm subdomain; "more" says a next page exists.
        public static void ListShop(string shop, int page, Action<List<BoothItem>, bool, string> done)
        {
            if (Offline)
            {
                done(null, false, OfflineMessage);
                return;
            }
            Send($"https://{shop}.booth.pm/items" + (page > 1 ? "?page=" + page : ""), request =>
            {
                if (request.result != UnityWebRequest.Result.Success) done(null, false, Failure(request));
                else
                {
                    var html = request.downloadHandler.text;
                    done(ParseShopItems(html), html.Contains("items?page=" + (page + 1)), null);
                }
            });
        }

        public static void Fetch(long id, Action<BoothItem, string> done)
        {
            if (Offline)
            {
                done(null, OfflineMessage);
                return;
            }
            Send(Origin + "items/" + id + ".json", request =>
            {
                if (request.result != UnityWebRequest.Result.Success) done(null, Failure(request));
                else
                {
                    var item = ParseItem(request.downloadHandler.text);
                    done(item, item == null ? "상품 정보를 읽지 못했어요." : null);
                }
            });
        }

        public static void Download(string url, Action<byte[]> done)
        {
            if (Offline)
            {
                done(null);
                return;
            }
            Send(url, request => done(request.result == UnityWebRequest.Result.Success ? request.downloadHandler.data : null));
        }

        private static string Failure(UnityWebRequest request)
        {
            if (request.responseCode == 404) return "Booth에서 상품 정보를 받지 못했어요. 주소가 맞으면 정보 없이 연결할 수 있어요.";
            return "Booth에 연결하지 못했어요: " + request.error;
        }

        private static void Send(string url, Action<UnityWebRequest> done)
        {
            Pending.Enqueue((url, done));
            EditorApplication.update -= Pump;
            EditorApplication.update += Pump;
        }

        private static void Pump()
        {
            if (running != null || Pending.Count == 0)
            {
                if (running == null) EditorApplication.update -= Pump;
                return;
            }
            if (EditorApplication.timeSinceStartup < nextSend) return;
            var (url, done) = Pending.Dequeue();
            var request = UnityWebRequest.Get(url);
            request.timeout = 20;
            running = request;
            try
            {
                request.SendWebRequest().completed += _ => Answer(request, done);
            }
            catch (Exception e)
            {
                // A request that cannot start answers as a failure, and the queue goes on.
                Debug.LogException(e);
                Answer(request, done);
            }
        }

        private static void Answer(UnityWebRequest request, Action<UnityWebRequest> done)
        {
            running = null;
            nextSend = EditorApplication.timeSinceStartup + Spacing;
            try { done(request); }
            catch (Exception e) { Debug.LogException(e); }
            finally { request.Dispose(); }
        }

        // ---- Parsing (pure; covered by tests with saved pages) ----

        private static readonly Regex Card = new Regex(@"<li\b[^>]*\bclass=""item-card\b[^>]*>", RegexOptions.Compiled);
        private static readonly Regex Attribute = new Regex(@"\b(data-product-[a-z]+)=""([^""]*)""", RegexOptions.Compiled);
        private static readonly Regex Title = new Regex(@"class=""item-card__title-anchor[^""]*""[^>]*>([^<]*)<", RegexOptions.Compiled);
        private static readonly Regex ShopName = new Regex(@"class=""item-card__shop-name""[^>]*>([^<]*)<", RegexOptions.Compiled);
        private static readonly Regex Thumbnail = new Regex(@"data-original=""([^""]+)""", RegexOptions.Compiled);

        public static List<BoothItem> ParseSearch(string html)
        {
            var items = new List<BoothItem>();
            var cards = Card.Matches(html ?? "");
            for (var i = 0; i < cards.Count; i++)
            {
                var start = cards[i].Index;
                var end = i + 1 < cards.Count ? cards[i + 1].Index : html.Length;
                var card = html.Substring(start, end - start);
                var attributes = Attribute.Matches(cards[i].Value).Cast<Match>()
                    .GroupBy(m => m.Groups[1].Value).ToDictionary(g => g.Key, g => Decode(g.First().Groups[2].Value));
                if (!attributes.TryGetValue("data-product-id", out var idText) || !long.TryParse(idText, out var id)) continue;
                var title = Title.Match(card);
                var shop = ShopName.Match(card);
                var thumbnail = Thumbnail.Match(card);
                items.Add(new BoothItem
                {
                    id = id,
                    // The attribute cuts long names with "..."; the title link has them whole.
                    name = title.Success ? Decode(title.Groups[1].Value) : attributes.TryGetValue("data-product-name", out var n) ? n : "",
                    shop = shop.Success ? Decode(shop.Groups[1].Value) : attributes.TryGetValue("data-product-brand", out var b) ? b : "",
                    shopUrl = attributes.TryGetValue("data-product-brand", out var brand) && brand.Length > 0 ? $"https://{brand}.booth.pm/" : "",
                    thumbnail = thumbnail.Success ? Decode(thumbnail.Groups[1].Value) : "",
                });
            }
            return items.GroupBy(item => item.id).Select(g => g.First()).ToList();
        }

        // A shop's own list carries each product as JSON in the card's data-item attribute.
        private static readonly Regex ShopCard = new Regex(
            @"<li\b[^>]*?\bclass=""js-mount-point-shop-item-card\b[^""]*""[^>]*?\bdata-item=""([^""]*)""", RegexOptions.Compiled);

        [Serializable] private sealed class ShopCardJson { public long id; public string name; public bool is_adult; public ShopJson shop; public string[] thumbnail_image_urls; public CategoryJson category; }
        [Serializable] private sealed class CategoryJson { public CategoryNameJson name; }
        [Serializable] private sealed class CategoryNameJson { public string ja; public string en; }

        // Booth's 3D Models subcategories all start with "3D" (3D衣装, 3D小道具, 3Dツール・システム…); "3DCG" is an
        // illustration category. A product of unknown category is kept.
        public static bool Is3DModel(string category) =>
            string.IsNullOrEmpty(category) || category.StartsWith("3D", StringComparison.Ordinal) && !category.StartsWith("3DCG", StringComparison.Ordinal);

        public static List<BoothItem> ParseShopItems(string html)
        {
            var items = new List<BoothItem>();
            foreach (Match match in ShopCard.Matches(html ?? ""))
            {
                ShopCardJson data;
                try { data = JsonUtility.FromJson<ShopCardJson>(WebUtility.HtmlDecode(match.Groups[1].Value)); }
                catch (ArgumentException) { continue; }
                if (data == null || data.id <= 0) continue;
                items.Add(new BoothItem
                {
                    id = data.id,
                    name = (data.name ?? "").Trim(),
                    shop = data.shop?.name ?? "",
                    shopUrl = data.shop?.url ?? "",
                    thumbnail = data.thumbnail_image_urls?.FirstOrDefault() ?? "",
                    adult = data.is_adult,
                    category = data.category?.name?.ja ?? "",
                });
            }
            return items.GroupBy(item => item.id).Select(g => g.First()).ToList();
        }

        [Serializable] private sealed class ItemJson { public long id; public string name; public bool is_adult; public ShopJson shop; public ImageJson[] images; public TagJson[] tags; }
        [Serializable] private sealed class ShopJson { public string name; public string url; }
        [Serializable] private sealed class ImageJson { public string original; public string resized; }
        [Serializable] private sealed class TagJson { public string name; }

        public static BoothItem ParseItem(string json)
        {
            ItemJson data;
            try { data = JsonUtility.FromJson<ItemJson>(json); }
            catch (ArgumentException) { return null; }
            if (data == null || data.id <= 0) return null;
            var image = data.images?.FirstOrDefault()?.original ?? "";
            return new BoothItem
            {
                id = data.id,
                name = data.name ?? "",
                shop = data.shop?.name ?? "",
                shopUrl = data.shop?.url ?? "",
                thumbnail = Sized(image),
                adult = data.is_adult,
                tags = data.tags?.Select(t => t.name).Where(t => !string.IsNullOrEmpty(t)).ToArray() ?? Array.Empty<string>(),
            };
        }

        // Booth serves a 300×300 copy of a product image under "/c/300x300_a2_g5/"; the original can be large.
        private static string Sized(string url)
        {
            const string host = "https://booth.pximg.net/";
            if (!url.StartsWith(host, StringComparison.Ordinal) || url.StartsWith(host + "c/", StringComparison.Ordinal)) return url;
            return host + "c/300x300_a2_g5/" + url.Substring(host.Length);
        }

        private static readonly Regex ItemLink = new Regex(
            @"(?:\bbooth\.pm/(?:[a-z]{2}(?:-[a-z]+)?/)?items/|[a-z0-9-]+\.booth\.pm/items/)(\d{3,12})",
            RegexOptions.Compiled | RegexOptions.IgnoreCase);

        // The product ID in a Booth URL (any language path or a shop's own address), or a bare ID.
        public static long ParseItemId(string text)
        {
            text = (text ?? "").Trim();
            if (long.TryParse(text, out var bare) && bare > 0) return bare;
            var match = ItemLink.Match(text);
            return match.Success && long.TryParse(match.Groups[1].Value, out var id) ? id : 0;
        }

        // Every product ID linked in a text (readme files often carry the product's own page).
        public static IEnumerable<long> FindItemIds(string text)
        {
            foreach (Match m in ItemLink.Matches(text ?? ""))
                if (long.TryParse(m.Groups[1].Value, out var id)) yield return id;
        }

        // A shop's own address: <subdomain>.booth.pm. Booth's own hosts are not shops.
        private static readonly Regex ShopLink = new Regex(@"(?<![a-z0-9.-])([a-z0-9][a-z0-9-]{0,62})\.booth\.pm\b", RegexOptions.Compiled | RegexOptions.IgnoreCase);
        private static readonly HashSet<string> BoothHosts = new HashSet<string>
            { "www", "accounts", "asset", "s", "manage", "checkout", "api", "help", "docs", "pay", "booth", "static", "img", "public" };

        public static string ShopFromUrl(string text) => FindShops(text).FirstOrDefault();

        public static IEnumerable<string> FindShops(string text)
        {
            var seen = new HashSet<string>();
            foreach (Match m in ShopLink.Matches(text ?? ""))
            {
                var shop = m.Groups[1].Value.ToLowerInvariant();
                if (!BoothHosts.Contains(shop) && seen.Add(shop)) yield return shop;
            }
        }

        // How alike two product names are, 0 to 1: the names without brackets, versions and separators, reduced to
        // letters and digits, compared by their pairs of characters (this works for Japanese, which has no spaces).
        // One name inside the other ("Wild Suit" in "Wild Suit / OGRE") counts as close when the shorter one is at
        // least four letters and half the longer ("Top" in "Desktop" does not).
        public static float Similarity(string a, string b)
        {
            var x = Letters(a);
            var y = Letters(b);
            if (x.Length == 0 || y.Length == 0) return 0;
            if (x == y) return 1;
            var (shortName, longName) = x.Length <= y.Length ? (x, y) : (y, x);
            var contained = shortName.Length >= 4 && shortName.Length * 2 >= longName.Length && longName.Contains(shortName) ? 0.85f : 0;
            if (x.Length < 2 || y.Length < 2) return contained;
            var pairs = new Dictionary<int, int>();
            for (var i = 0; i < x.Length - 1; i++)
            {
                var key = x[i] << 16 | x[i + 1];
                pairs[key] = pairs.TryGetValue(key, out var n) ? n + 1 : 1;
            }
            var common = 0;
            for (var i = 0; i < y.Length - 1; i++)
            {
                var key = y[i] << 16 | y[i + 1];
                if (!pairs.TryGetValue(key, out var n) || n == 0) continue;
                pairs[key] = n - 1;
                common++;
            }
            return Math.Max(contained, 2f * common / (x.Length - 1 + y.Length - 1));
        }

        // Letters and digits of a name, compatibility forms folded (full-width letters, half-width kana) and lower case.
        public static string Letters(string name)
        {
            var text = QueryFrom(name).Normalize(System.Text.NormalizationForm.FormKC).ToLowerInvariant();
            return new string(text.Where(char.IsLetterOrDigit).ToArray());
        }

        private static readonly Regex Bracketed = new Regex(@"【[^】]*】|\[[^\]]*\]|［[^］]*］|\([^)]*\)|（[^）]*）", RegexOptions.Compiled);
        private static readonly Regex Version = new Regex(
            @"(?i)(?:\bver(?:sion)?\.?\s*\d+(?:[._]\d+)*[a-z]?|\bv\d+(?:[._]\d+)*[a-z]?\b|\b\d+(?:\.\d+){1,3}\b)", RegexOptions.Compiled);
        private static readonly Regex Noise = new Regex(@"(?i)\b(?:unity\s*package|unitypackage|package)\b", RegexOptions.Compiled);

        // A search query from a file or folder name: no extension, version, bracketed notes or separators.
        public static string QueryFrom(string name)
        {
            var text = name ?? "";
            foreach (var extension in new[] { ".unitypackage", ".zip" })
                if (text.EndsWith(extension, StringComparison.OrdinalIgnoreCase)) text = text.Substring(0, text.Length - extension.Length);
            var stripped = Bracketed.Replace(text, " ");
            // A name that is only a bracketed note keeps its words.
            if (string.IsNullOrWhiteSpace(Clean(stripped))) stripped = Regex.Replace(text, @"[【】\[\]［］()（）]", " ");
            return Clean(stripped);
        }

        private static string Clean(string text)
        {
            // Separators first: "_" is a word character, so "Name_v1.2" would hide its version from \b.
            text = Regex.Replace(text, @"[_+＿・/\\|]+", " ");
            text = Version.Replace(text, " ");
            text = Noise.Replace(text, " ");
            text = Regex.Replace(text, @"(?<=\s|^)[-.]+|[-.]+(?=\s|$)", " ");
            return Regex.Replace(text, @"\s+", " ").Trim();
        }

        // A shorter query for a second try when the first finds nothing: the first two words.
        public static string Shorter(string query)
        {
            var words = (query ?? "").Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            return words.Length > 2 ? string.Join(" ", words.Take(2)) : words.Length == 2 ? words[0] : null;
        }

        private static string Decode(string text) => WebUtility.HtmlDecode(text ?? "").Trim();
    }
}
