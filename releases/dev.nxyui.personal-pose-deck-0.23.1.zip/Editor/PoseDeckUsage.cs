using UnityEditor;
using UnityEngine;

namespace PersonalPoseDeck
{
    // How the tool is used, written once (MASTER.md "Usage guide"): the window and the preset's inspector draw these
    // steps, README_KO.txt lists them word for word (a test checks that), and the public guide walks through the same
    // steps with the details. Nothing in it depends on the tool's state, so it lays out the same in every GUI pass.
    internal static class PoseDeckUsage
    {
        internal const string Url = "https://github.com/NXYUI/UnityVPM-pages/blob/main/packages/dev.nxyui.personal-pose-deck/README.md";

        internal static readonly string[] Steps =
        {
            "Edit Mode에서 아바타를 고르고 상단 메뉴 NXYUI > Personal Pose Deck을 열어요. 맨 위 ‘아바타’에 그 아바타가 들어가요.",
            "‘프리셋’ 줄에서 ‘새로’로 프리셋을 만들거나 ‘목록’에서 골라요. GoGoLoco가 이미 달린 아바타는 ‘기존 GoGoLoco에’, 아니면 ‘아바타에 새로’로 둬요.",
            "왼쪽 ‘갤러리’ 탭에서 카드를 눌러 오른쪽 미리보기로 보고, ‘현재 클립 추가’나 카드 체크 후 ‘선택 목록 추가’로 덱에 넣어요.",
            "‘덱’ 탭에서 번호를 눌러 포즈를 고르고, 필요하면 ‘시작 높이 직접 지정’이나 ‘바닥에 맞추기’로 시작 높이를 맞춰요.",
            "‘슬롯 확인’으로 확인한 뒤 ‘생성 및 적용’을 눌러요. 프리셋 옆에 PoseDeck_Generated 폴더가 생기고 아바타의 GoGoLoco가 이 덱을 써요.",
            "씬을 저장하고 VRChat SDK의 Build & Test로 확인해요. 포즈를 바꾸면 ‘생성 및 적용’을 다시 눌러야 아바타에 반영돼요.",
            "덱을 빼려면 ‘되돌리기’(기존 GoGoLoco에) 또는 ‘적용 제거’(아바타에 새로)를 누르고, 남은 폴더는 ‘덱’ 탭의 ‘생성본 정리’로 지워요.",
        };

        // Closed until the user opens it (the owner: the steps stay out of sight until ‘사용 방법’ is opened), then kept
        // as they left it, per surface, on this PC.
        internal const string WindowKey = "NXYUI.PersonalPoseDeck.Usage.Window";
        internal const string InspectorKey = "NXYUI.PersonalPoseDeck.Usage.Inspector";

        // The foldout and, while it is open, the numbered steps in a box. Returns the foldout's rect (valid at Repaint).
        // Opening or closing ends the GUI pass: everything below it moves, and the rest of this pass would not match the
        // pass that laid it out.
        internal static Rect Draw(string key) => Show(key, 0f);

        // In a window: the open list takes at most `room` and scrolls in its frame past that, so the columns below keep
        // the height they need at the window's minimum size.
        internal static Rect DrawInWindow(string key, float room) => Show(key, room);

        private static Vector2 scroll;

        // How tall the steps are at the width they get (the view's, less the frame and a scroll bar). The same in the
        // Layout and the Repaint pass of a frame.
        private static float StepsHeight()
        {
            float width = Mathf.Max(120f, EditorGUIUtility.currentViewWidth - 40f), height = 0f;
            for (int i = 0; i < Steps.Length; i++)
                height += EditorStyles.wordWrappedLabel.CalcHeight(new GUIContent($"{i + 1}. {Steps[i]}"), width) + 2f;
            return height;
        }

        private static Rect Show(string key, float room)
        {
            bool open = EditorPrefs.GetBool(key, false);
            bool next = EditorGUILayout.Foldout(open, "사용 방법", true);
            var foldout = GUILayoutUtility.GetLastRect();
            if (next != open)
            {
                EditorPrefs.SetBool(key, next);
                GUIUtility.ExitGUI();
            }
            if (!open) return foldout;
            using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
            {
                // Taller than the room it may take (a low window): the steps scroll inside the frame.
                bool scrolls = room > 0f && StepsHeight() > room;
                if (scrolls) scroll = EditorGUILayout.BeginScrollView(scroll, GUILayout.Height(room));
                for (int i = 0; i < Steps.Length; i++)
                    EditorGUILayout.LabelField($"{i + 1}. {Steps[i]}", EditorStyles.wordWrappedLabel);
                if (scrolls) EditorGUILayout.EndScrollView();
                using (new EditorGUILayout.HorizontalScope())
                {
                    if (GUILayout.Button(new GUIContent("자세한 설명 열기", Url), EditorStyles.miniButton, GUILayout.ExpandWidth(false)))
                        Application.OpenURL(Url);
                    GUILayout.Label("패키지 폴더의 README_KO.txt에도 있어요.", EditorStyles.miniLabel);
                }
            }
            return foldout;
        }
    }
}
