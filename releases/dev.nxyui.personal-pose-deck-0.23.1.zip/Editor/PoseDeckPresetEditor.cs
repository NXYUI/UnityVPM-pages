using UnityEditor;
using UnityEngine;

namespace PersonalPoseDeck
{
    // The preset's inspector: how the tool is used (PoseDeckUsage) and the way into the window with this preset, then the
    // preset's own fields as Unity draws them. The deck is edited and applied in the window.
    [CustomEditor(typeof(PoseDeckPreset))]
    internal sealed class PoseDeckPresetEditor : Editor
    {
        public override void OnInspectorGUI()
        {
            PoseDeckUsage.Draw(PoseDeckUsage.InspectorKey);
            // The window edits decks in Edit Mode only: off in Play Mode, with the reason beside it (a disabled button
            // shows no tooltip), instead of opening a window that can only say so.
            bool playing = EditorApplication.isPlayingOrWillChangePlaymode;
            using (new EditorGUI.DisabledScope(playing))
                if (GUILayout.Button(new GUIContent("Personal Pose Deck 창에서 열기",
                        "NXYUI > Personal Pose Deck 창을 열고 위쪽 ‘프리셋’에 이 프리셋을 넣어요. 포즈 추가와 ‘생성 및 적용’은 창에서 해요.")))
                {
                    PoseDeckPoseBrowser.OpenFor(null, (PoseDeckPreset)target);
                    GUIUtility.ExitGUI(); // another window opened and took the focus
                }
            if (playing)
                EditorGUILayout.LabelField("플레이 모드에서는 덱을 편집할 수 없어요. 플레이 모드를 끝낸 뒤 눌러 주세요.", EditorStyles.wordWrappedMiniLabel);
            EditorGUILayout.Space(4);
            DrawDefaultInspector();
        }
    }
}
