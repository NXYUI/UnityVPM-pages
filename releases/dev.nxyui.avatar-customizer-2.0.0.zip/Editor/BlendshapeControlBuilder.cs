#if UNITY_EDITOR
using System.Collections.Generic;
using System.Linq;
using nadena.dev.modular_avatar.core;
using nadena.dev.ndmf;
using UnityEditor;
using UnityEditor.Animations;
using UnityEngine;
using VRC.SDK3.Avatars.Components;

namespace AvatarMenuTools
{
    // Turns the blendshape controls placed in a favorites menu into one FX layer (a direct blend tree holding a 1D tree
    // per control) and an expression parameter each. It adds Modular Avatar components to the build copy before
    // Modular Avatar runs, so MA merges the layer and the parameters like any other; the favorites pass then puts the
    // radial or toggle into the menu.
    internal static class BlendshapeControlBuilder
    {
        internal const string One = "NXYUI/Customizer/One";
        internal const string HolderName = "Avatar Customizer Blendshapes";

        internal sealed class Built
        {
            internal string Parameter, Name;
            internal bool Radial;
        }

        internal sealed class State
        {
            internal readonly Dictionary<string, Built> Controls = new Dictionary<string, Built>();
            internal readonly Dictionary<string, string> Problems = new Dictionary<string, string>();
        }

        internal static IEnumerable<string> UsedIds(AvatarCustomizer c) => c.AllMenus()
            .SelectMany(m => m.entries ?? new List<FavoriteMenuEntry>())
            .Where(e => e != null && e.IsShape).Select(e => e.shapeId).Distinct();

        // Why the control cannot be built on this avatar, or null.
        internal static string Problem(BlendshapeControl s, Transform root)
        {
            if (s == null) return "삭제된 블렌드쉐이프 컨트롤입니다.";
            if (!s.renderer) return "대상 오브젝트가 없습니다.";
            if (!s.renderer.transform.IsChildOf(root)) return "아바타 안의 오브젝트가 아닙니다.";
            if (!s.renderer.sharedMesh || s.renderer.sharedMesh.GetBlendShapeIndex(s.blendshape ?? "") < 0)
                return $"‘{s.blendshape}’ 블렌드쉐이프가 메시에 없습니다.";
            return null;
        }

        internal static void Generate(BuildContext context)
        {
            var root = context.AvatarRootObject;
            var c = root.GetComponent<AvatarCustomizer>();
            if (!c || !c.enabled) return;
            var state = context.GetState<State>();
            var controls = new List<BlendshapeControl>();
            foreach (var id in UsedIds(c))
            {
                var shape = c.FindShape(id);
                var problem = Problem(shape, root.transform);
                if (problem != null) state.Problems[id] = problem;
                else controls.Add(shape);
            }
            if (controls.Count == 0) return;

            var controller = new AnimatorController { name = HolderName };
            controller.parameters = new[] { new AnimatorControllerParameter { name = One, type = AnimatorControllerParameterType.Float, defaultFloat = 1f } }
                .Concat(controls.Select(s => new AnimatorControllerParameter
                {
                    // Float even for a toggle: VRChat drives a float animator parameter from a bool expression parameter.
                    name = s.Parameter, type = AnimatorControllerParameterType.Float, defaultFloat = s.StartValue,
                })).ToArray();
            var direct = new BlendTree { name = "Blendshapes", blendType = BlendTreeType.Direct, useAutomaticThresholds = false };
            direct.children = controls.Select(s =>
            {
                string path = AnimationUtility.CalculateTransformPath(s.renderer.transform, root.transform);
                var tree = new BlendTree
                {
                    name = s.blendshape, blendType = BlendTreeType.Simple1D, blendParameter = s.Parameter, useAutomaticThresholds = false,
                };
                tree.children = new[]
                {
                    new ChildMotion { motion = Clip(s, path, s.min), threshold = 0f, timeScale = 1f },
                    new ChildMotion { motion = Clip(s, path, s.max), threshold = 1f, timeScale = 1f },
                };
                return new ChildMotion { motion = tree, directBlendParameter = One, timeScale = 1f };
            }).ToArray();
            // Direct blend trees need write defaults on; this layer animates nothing else.
            var animate = new AnimatorState { name = "Blendshapes", motion = direct, writeDefaultValues = true };
            var machine = new AnimatorStateMachine
            {
                name = "Blendshapes",
                states = new[] { new ChildAnimatorState { state = animate, position = new Vector3(300f, 100f) } },
                defaultState = animate,
            };
            controller.layers = new[] { new AnimatorControllerLayer { name = HolderName, defaultWeight = 1f, stateMachine = machine } };

            var holder = new GameObject(HolderName);
            holder.transform.SetParent(root.transform, false);
            var merge = holder.AddComponent<ModularAvatarMergeAnimator>();
            merge.animator = controller;
            merge.layerType = VRCAvatarDescriptor.AnimLayerType.FX;
            merge.pathMode = MergeAnimatorPathMode.Absolute;
            merge.matchAvatarWriteDefaults = false;
            var parameters = holder.AddComponent<ModularAvatarParameters>();
            parameters.parameters = controls.Select(s => new ParameterConfig
            {
                nameOrPrefix = s.Parameter,
                syncType = s.type == BlendshapeControlType.Radial ? ParameterSyncType.Float : ParameterSyncType.Bool,
                localOnly = !s.synced,
                saved = s.saved,
                defaultValue = s.StartValue,
                hasExplicitDefaultValue = true,
            }).ToList();

            foreach (var s in controls)
                state.Controls[s.id] = new Built { Parameter = s.Parameter, Name = s.blendshape, Radial = s.type == BlendshapeControlType.Radial };
        }

        private static AnimationClip Clip(BlendshapeControl s, string path, float weight)
        {
            var clip = new AnimationClip { name = $"{s.blendshape} {weight:0.#}" };
            AnimationUtility.SetEditorCurve(clip,
                EditorCurveBinding.FloatCurve(path, typeof(SkinnedMeshRenderer), "blendShape." + s.blendshape),
                AnimationCurve.Constant(0f, 1f / 60f, weight));
            return clip;
        }
    }
}
#endif
