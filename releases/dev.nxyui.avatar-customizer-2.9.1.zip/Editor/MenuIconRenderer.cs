#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;
using UnityEngine.SceneManagement;
using Object = UnityEngine.Object;

namespace AvatarMenuTools
{
    // Renders a menu icon of some of an avatar's objects. The avatar's transforms and renderers (nothing else, so no other
    // script runs, and the avatar in the scene is never changed) are copied into a preview scene; the chosen objects are
    // turned on there, framed, and rendered over black and over white to recover a clean alpha.
    internal sealed class MenuIconRenderer : IDisposable
    {
        internal enum View { Front, ThreeQuarter, Side, Top }

        private readonly PreviewRenderUtility preview = new PreviewRenderUtility();
        private readonly Dictionary<Transform, Transform> nodes = new Dictionary<Transform, Transform>();
        private readonly List<(Renderer Source, Renderer Copy)> renderers = new List<(Renderer, Renderer)>();
        private readonly Mesh measure;

        internal MenuIconRenderer(GameObject avatar)
        {
            try
            {
                MakeNode(avatar.transform, null);
                CopyRenderers(avatar.transform);
                measure = new Mesh { hideFlags = HideFlags.HideAndDontSave };
                preview.camera.clearFlags = CameraClearFlags.Color;
                preview.camera.orthographic = false;
                preview.camera.fieldOfView = 30f;
                preview.ambientColor = new Color(.62f, .62f, .62f, 1f);
                preview.lights[0].intensity = 1.25f;
                preview.lights[1].intensity = .55f;
            }
            catch
            {
                Dispose();
                throw;
            }
        }

        // The copy stands at the origin facing +Z, as VRChat avatars do, whatever the avatar's place in the scene.
        private void MakeNode(Transform source, Transform parent)
        {
            var obj = EditorUtility.CreateGameObjectWithHideFlags(source.name, HideFlags.HideAndDontSave);
            obj.layer = source.gameObject.layer;
            var node = obj.transform;
            if (parent == null)
            {
                preview.AddSingleGO(obj);
                node.localScale = source.lossyScale;
            }
            else
            {
                SceneManager.MoveGameObjectToScene(obj, parent.gameObject.scene);
                node.SetParent(parent, false);
                node.localPosition = source.localPosition;
                node.localRotation = source.localRotation;
                node.localScale = source.localScale;
                obj.SetActive(source.gameObject.activeSelf);
            }
            nodes.Add(source, node);
            foreach (Transform child in source) MakeNode(child, node);
        }

        // Every renderer, turned off ones too: a toggle may turn them on.
        private void CopyRenderers(Transform source)
        {
            var node = nodes[source];
            foreach (var old in source.GetComponents<SkinnedMeshRenderer>())
            {
                if (!old.sharedMesh) continue;
                var bones = old.bones;
                if (bones.Any(b => b && !nodes.ContainsKey(b))) continue;
                var copy = node.gameObject.AddComponent<SkinnedMeshRenderer>();
                copy.sharedMesh = old.sharedMesh;
                copy.sharedMaterials = old.sharedMaterials;
                copy.bones = bones.Select(b => b ? nodes[b] : null).ToArray();
                copy.rootBone = old.rootBone && nodes.TryGetValue(old.rootBone, out var rootBone) ? rootBone : null;
                copy.localBounds = old.localBounds;
                copy.updateWhenOffscreen = true;
                copy.quality = old.quality;
                for (int i = 0; i < old.sharedMesh.blendShapeCount; i++) copy.SetBlendShapeWeight(i, old.GetBlendShapeWeight(i));
                copy.enabled = old.enabled;
                renderers.Add((old, copy));
            }
            var filter = source.GetComponent<MeshFilter>();
            var mesh = source.GetComponent<MeshRenderer>();
            if (filter && filter.sharedMesh && mesh)
            {
                node.gameObject.AddComponent<MeshFilter>().sharedMesh = filter.sharedMesh;
                var copy = node.gameObject.AddComponent<MeshRenderer>();
                copy.sharedMaterials = mesh.sharedMaterials;
                copy.enabled = mesh.enabled;
                renderers.Add((mesh, copy));
            }
            foreach (Transform child in source) CopyRenderers(child);
        }

        // Turns on the objects to show (and what they are in, and their own renderer), from the avatar as it stands in
        // the scene. Alone (withAvatar off), only renderers inside them are drawn.
        internal void Show(IReadOnlyCollection<Transform> targets, bool withAvatar)
        {
            // The scene as it is now; an object removed since the copy was made stays as it was copied.
            foreach (var pair in nodes) if (pair.Key) pair.Value.gameObject.SetActive(pair.Key.gameObject.activeSelf);
            foreach (var (source, copy) in renderers) if (source) copy.enabled = source.enabled;
            var shown = new List<Transform>();
            foreach (var target in targets)
            {
                if (!target || !nodes.TryGetValue(target, out var node)) continue;
                shown.Add(node);
                for (var at = node; at; at = at.parent) at.gameObject.SetActive(true);
                foreach (var (_, copy) in renderers) if (copy.transform == node) copy.enabled = true;
            }
            if (!withAvatar)
                foreach (var (_, copy) in renderers)
                    if (!shown.Any(node => copy.transform.IsChildOf(node))) copy.enabled = false;
        }

        // An icon of what Show left on, size pixels square, or null when nothing is drawn.
        internal Texture2D Render(int size, View view, float zoom)
        {
            if (!Bounds(out var bounds)) return null;
            Aim(view, bounds, Mathf.Clamp(zoom, .3f, 4f));
            Texture2D black = null, white = null;
            try
            {
                preview.camera.backgroundColor = Color.black;
                black = Still(size);
                preview.camera.backgroundColor = Color.white;
                white = Still(size);
                if (!black || !white) return null;
                var result = Matte(black, white);
                result.hideFlags = HideFlags.HideAndDontSave;
                result.filterMode = FilterMode.Bilinear;
                result.Apply(false, false);
                return result;
            }
            finally
            {
                if (black) Object.DestroyImmediate(black);
                if (white) Object.DestroyImmediate(white);
            }
        }

        private bool Bounds(out Bounds bounds)
        {
            var all = default(Bounds);
            bool any = false;
            void Add(Bounds part)
            {
                if (any) all.Encapsulate(part);
                else { all = part; any = true; }
            }
            foreach (var (_, copy) in renderers)
            {
                if (!copy.enabled || !copy.gameObject.activeInHierarchy) continue;
                if (copy is SkinnedMeshRenderer skinned)
                {
                    // The mesh as posed now, with the renderer's scale baked in, so only its place and turn are left.
                    skinned.BakeMesh(measure, true);
                    var local = measure.bounds;
                    var matrix = Matrix4x4.TRS(skinned.transform.position, skinned.transform.rotation, Vector3.one);
                    for (int corner = 0; corner < 8; corner++)
                        Add(new Bounds(matrix.MultiplyPoint3x4(local.center + Vector3.Scale(local.extents,
                            new Vector3((corner & 1) == 0 ? -1 : 1, (corner & 2) == 0 ? -1 : 1, (corner & 4) == 0 ? -1 : 1))), Vector3.zero));
                }
                else Add(copy.bounds);
            }
            bounds = all;
            return any && all.size.sqrMagnitude > 0f;
        }

        private void Aim(View view, Bounds bounds, float zoom)
        {
            var (pitch, yaw) = view == View.Front ? (5f, 0f) : view == View.Side ? (5f, 90f) : view == View.Top ? (60f, 20f) : (15f, 35f);
            var rotation = Quaternion.Euler(pitch, 180f + yaw, 0f);
            var camera = preview.camera;
            float radius = Mathf.Max(bounds.extents.magnitude, .01f);
            float distance = radius / Mathf.Sin(camera.fieldOfView * .5f * Mathf.Deg2Rad) / zoom;
            camera.transform.rotation = rotation;
            camera.transform.position = bounds.center - rotation * Vector3.forward * distance;
            camera.nearClipPlane = Mathf.Max(distance * .01f, .001f);
            camera.farClipPlane = distance + radius * 4f;
            preview.lights[0].transform.rotation = rotation * Quaternion.Euler(30f, -35f, 0f);
            preview.lights[1].transform.rotation = rotation * Quaternion.Euler(-15f, 140f, 0f);
        }

        private Texture2D Still(int size)
        {
            preview.BeginStaticPreview(new Rect(0, 0, size, size));
            Texture2D result = null;
            bool done = false;
            try
            {
                preview.Render(true, false);
                done = true;
            }
            finally
            {
                result = preview.EndStaticPreview();
                if (!done && result) { Object.DestroyImmediate(result); result = null; }
            }
            return result;
        }

        // Over black (b) and white (w) a pixel is a*F and a*F + (1 - a): the difference gives the coverage a, and b / a
        // the colour. Blending happens in linear space, so sRGB values are converted first.
        internal static Texture2D Matte(Texture2D black, Texture2D white)
        {
            bool linear = QualitySettings.activeColorSpace == ColorSpace.Linear;
            var toLinear = new float[256];
            for (int i = 0; i < 256; i++) toLinear[i] = linear ? Mathf.GammaToLinearSpace(i / 255f) : i / 255f;
            byte Encode(float v) => (byte)Mathf.RoundToInt(Mathf.Clamp01(linear ? Mathf.LinearToGammaSpace(Mathf.Clamp01(v)) : v) * 255f);
            var b = black.GetPixels32();
            var w = white.GetPixels32();
            var pixels = new Color32[b.Length];
            for (int i = 0; i < b.Length; i++)
            {
                float r = toLinear[b[i].r], g = toLinear[b[i].g], bl = toLinear[b[i].b];
                float alpha = Mathf.Clamp01(1f - (toLinear[w[i].r] - r + toLinear[w[i].g] - g + toLinear[w[i].b] - bl) / 3f);
                pixels[i] = alpha < .5f / 255f ? new Color32(0, 0, 0, 0)
                    : new Color32(Encode(r / alpha), Encode(g / alpha), Encode(bl / alpha), (byte)Mathf.RoundToInt(alpha * 255f));
            }
            var result = new Texture2D(black.width, black.height, TextureFormat.RGBA32, false);
            result.SetPixels32(pixels);
            return result;
        }

        public void Dispose()
        {
            preview.Cleanup();
            if (measure) Object.DestroyImmediate(measure);
        }
    }

    // Menu icon files: PNGs a VRChat menu takes (the SDK refuses icons over 256 px and uncompressed ones).
    internal static class MenuIcons
    {
        internal const string Folder = "Assets/NXYUI/Avatar Customizer/Icons";

        // Saves image as a new icon asset in the avatar's folder (never over another file) and returns it with its path.
        internal static Texture2D Save(Texture2D image, string avatarName, string itemName, out string path)
        {
            string folder = EnsureFolder(Folder + "/" + Clean(avatarName, "Avatar"));
            path = AssetDatabase.GenerateUniqueAssetPath($"{folder}/{Clean(itemName, "Icon")}.png");
            string full = Path.Combine(Path.GetDirectoryName(Application.dataPath) ?? "", path);
            try { File.WriteAllBytes(full, image.EncodeToPNG()); }
            catch
            {
                // A file half written (a full disk) is not left behind.
                if (File.Exists(full)) File.Delete(full);
                throw;
            }
            try
            {
                AssetDatabase.ImportAsset(path, ImportAssetOptions.ForceSynchronousImport);
                var importer = (TextureImporter)AssetImporter.GetAtPath(path);
                importer.textureType = TextureImporterType.Default;
                importer.alphaSource = TextureImporterAlphaSource.FromInput;
                importer.alphaIsTransparency = true;
                importer.sRGBTexture = true;
                importer.mipmapEnabled = false;
                importer.wrapMode = TextureWrapMode.Clamp;
                importer.maxTextureSize = 256;
                importer.textureCompression = TextureImporterCompression.Compressed;
                importer.SaveAndReimport();
                var icon = AssetDatabase.LoadAssetAtPath<Texture2D>(path);
                if (!icon) throw new InvalidOperationException("아이콘 파일을 불러오지 못했어요: " + path);
                return icon;
            }
            catch
            {
                AssetDatabase.DeleteAsset(path);
                throw;
            }
        }

        // A name that works as a file or folder name.
        internal static string Clean(string name, string fallback)
        {
            var bad = new HashSet<char>(Path.GetInvalidFileNameChars().Concat(new[] { '/', '\\', ':', '*', '?', '"', '<', '>', '|' }));
            var text = new string((name ?? "").Select(c => bad.Contains(c) || char.IsControl(c) ? '_' : c).ToArray()).Trim().Trim('.');
            if (text.Length > 60) text = text.Substring(0, 60).Trim();
            return text.Length == 0 ? fallback : text;
        }

        private static string EnsureFolder(string path)
        {
            string at = "Assets";
            foreach (var part in path.Split('/').Skip(1))
            {
                string next = at + "/" + part;
                if (!AssetDatabase.IsValidFolder(next)) AssetDatabase.CreateFolder(at, part);
                at = next;
            }
            return at;
        }
    }
}
#endif
