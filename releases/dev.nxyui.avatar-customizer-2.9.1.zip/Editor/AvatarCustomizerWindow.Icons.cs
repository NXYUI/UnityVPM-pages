#if UNITY_EDITOR
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;
using Control = VRC.SDK3.Avatars.ScriptableObjects.VRCExpressionsMenu.Control;

namespace AvatarMenuTools
{
    // "아이콘 만들기": a menu icon rendered from the avatar's own objects, in the right column of the build result tab.
    // A toggle starts with the objects its FX layer turns on (ToggleTargets), when that is certain; anything else is
    // picked by hand. The PNG is a new asset; setting it as the item's icon is one Undo step.
    internal sealed partial class AvatarCustomizerWindow
    {
        private static readonly string[] IconViews = { "정면", "3/4", "옆", "위" };
        private const int IconSize = 256, IconPreviewSize = 128;

        // The item (its id in the level shown) the studio makes an icon for, and the way down to that level: the studio
        // closes when another level is shown, where the same id may name another item. Null while closed.
        private string iconFor;
        private readonly List<string> iconPath = new List<string>();
        // The settings when the studio opened, and the final menu last found made from them: an edit to the settings can
        // give the item's id to another item (a repeat moving up), so the studio closes then.
        private string iconSettings, iconCheckedFor;
        // The preview copy of the avatar, made again once the scene changed (sceneVersion) so it never holds removed objects.
        private MenuIconRenderer iconRenderer;
        private int iconSceneVersion;
        private readonly List<GameObject> iconTargets = new List<GameObject>();
        private MenuIconRenderer.View iconView = MenuIconRenderer.View.ThreeQuarter;
        private float iconZoom = 1f;
        private bool iconWithAvatar, iconDirty, iconSuggested;
        private Texture2D iconImage;
        private Vector2 iconScroll;

        private void OpenIconStudio(FinalMenu.Item item)
        {
            CloseIconStudio();
            iconFor = item.Id;
            iconPath.AddRange(finalPath);
            iconSettings = SettingsText();
            iconCheckedFor = finalFor;
            var c = item.Control;
            // Whether an object (or its renderer) is off in the scene now, for a toggle state that does not touch it.
            bool OffInScene(string path, bool renderer)
            {
                var target = !avatar ? null : path.Length == 0 ? avatar.transform : avatar.transform.Find(path);
                return target && (renderer ? target.TryGetComponent<Renderer>(out var r) && !r.enabled : !target.gameObject.activeSelf);
            }
            // The objects a toggle (or button) turns on, found in the avatar by their path before the build.
            if ((c.type == Control.ControlType.Toggle || c.type == Control.ControlType.Button) && !string.IsNullOrEmpty(c.parameter?.name) && avatar)
                foreach (var path in ToggleTargets.On(readToggles, c.parameter.name, c.value, OffInScene))
                {
                    var target = path.Length == 0 ? avatar.transform : avatar.transform.Find(path);
                    if (target && !iconTargets.Contains(target.gameObject)) iconTargets.Add(target.gameObject);
                }
            iconSuggested = iconTargets.Count > 0;
            iconDirty = true;
            iconScroll = Vector2.zero;
        }

        private string SettingsText() =>
            avatar && avatar.TryGetComponent<AvatarCustomizer>(out var config) ? EditorJsonUtility.ToJson(config) : "";

        private void CloseIconStudio()
        {
            iconRenderer?.Dispose();
            iconRenderer = null;
            if (iconImage) DestroyImmediate(iconImage);
            iconImage = null;
            iconFor = null;
            iconPath.Clear();
            iconTargets.Clear();
        }

        // fresh: copy the avatar again first (for the icon that is kept, so it shows the scene as it is now).
        private Texture2D RenderIcon(int size, bool fresh = false)
        {
            if (!avatar || iconTargets.Count == 0) return null;
            if (iconRenderer != null && (fresh || iconSceneVersion != sceneVersion))
            {
                iconRenderer.Dispose();
                iconRenderer = null;
            }
            if (iconRenderer == null)
            {
                iconRenderer = new MenuIconRenderer(avatar.gameObject);
                iconSceneVersion = sceneVersion;
            }
            iconRenderer.Show(iconTargets.Where(t => t).Select(t => t.transform).ToArray(), iconWithAvatar);
            return iconRenderer.Render(size, iconView, iconZoom);
        }

        // The item the studio is open for, or null once it is no longer the one shown: another level is open, or the
        // settings changed since it opened (its id may then name another item).
        private FinalMenu.Item IconStudioItem()
        {
            var level = FinalLevels().Last().Level;
            var item = finalPath.SequenceEqual(iconPath) ? level.Items.FirstOrDefault(i => i.Id == iconFor) : null;
            if (item != null && finalFor != iconCheckedFor)
            {
                if (SettingsText() == iconSettings) iconCheckedFor = finalFor;
                else item = null;
            }
            return item;
        }

        private void DrawIconStudio(AvatarCustomizer config)
        {
            var item = IconStudioItem();
            // DrawReview closes the studio in the Layout pass. Here it can only be an event that changed the level on the
            // way (a double click or a key on the left list): end the pass rather than leave half a column drawn.
            if (item == null)
            {
                CloseIconStudio();
                GUIUtility.ExitGUI();
            }
            // The scene changed under the preview: draw it again from a new copy.
            if (iconSceneVersion != sceneVersion) iconDirty = true;
            using (new EditorGUILayout.HorizontalScope())
            {
                if (GUILayout.Button(new GUIContent("←", "만들지 않고 돌아가기"), GUILayout.Width(28)))
                {
                    CloseIconStudio();
                    GUIUtility.ExitGUI();
                }
                EditorGUILayout.LabelField("아이콘 만들기 · " + FinalMenu.Name(item.Control), EditorStyles.boldLabel);
            }
            if (iconDirty && Event.current.type == EventType.Repaint)
            {
                iconDirty = false;
                if (iconImage) DestroyImmediate(iconImage);
                iconImage = RenderIcon(IconPreviewSize);
                Repaint();
            }
            using (new EditorGUILayout.HorizontalScope())
            {
                GUILayout.FlexibleSpace();
                var rect = GUILayoutUtility.GetRect(IconPreviewSize, IconPreviewSize, GUILayout.Width(IconPreviewSize), GUILayout.Height(IconPreviewSize));
                if (iconImage) EditorGUI.DrawTextureTransparent(rect, iconImage, ScaleMode.ScaleToFit);
                else GUI.Box(rect, iconTargets.Count == 0 ? "찍을 오브젝트를\n골라 주세요" : "보이는 것이 없어요", EditorStyles.helpBox);
                GUILayout.FlexibleSpace();
            }

            using (var scroll = new EditorGUILayout.ScrollViewScope(iconScroll, GUILayout.ExpandHeight(true)))
            {
                iconScroll = scroll.scrollPosition;
                EditorGUILayout.LabelField(iconSuggested ? "이 토글이 켜는 오브젝트를 골라 두었어요. 바꿀 수 있어요."
                    : "이 항목이 켜는 오브젝트를 알 수 없어요. 아래에서 찍을 오브젝트를 골라 주세요.", EditorStyles.wordWrappedMiniLabel);
                EditorGUILayout.LabelField("찍을 오브젝트", EditorStyles.boldLabel);
                for (int i = 0; i < iconTargets.Count; i++)
                    using (new EditorGUILayout.HorizontalScope())
                    {
                        var next = (GameObject)EditorGUILayout.ObjectField(iconTargets[i], typeof(GameObject), true);
                        if (next != iconTargets[i] && Inside(next)) { iconTargets[i] = next; iconDirty = true; }
                        if (GUILayout.Button(new GUIContent("×", "목록에서 빼기"), GUILayout.Width(22)))
                        {
                            iconTargets.RemoveAt(i);
                            iconDirty = true;
                            GUIUtility.ExitGUI();
                        }
                    }
                var added = (GameObject)EditorGUILayout.ObjectField(new GUIContent("추가", "아바타 안의 오브젝트를 끌어 놓거나 고르세요."), null, typeof(GameObject), true);
                if (added && Inside(added) && !iconTargets.Contains(added)) { iconTargets.Add(added); iconDirty = true; }
                EditorGUILayout.Space(6);
                int view = GUILayout.Toolbar((int)iconView, IconViews, EditorStyles.miniButton);
                if (view != (int)iconView) { iconView = (MenuIconRenderer.View)view; iconDirty = true; }
                float zoom = EditorGUILayout.Slider(new GUIContent("확대", "크게 하면 오브젝트가 아이콘을 더 채워요."), iconZoom, .5f, 2.5f);
                if (!Mathf.Approximately(zoom, iconZoom)) { iconZoom = zoom; iconDirty = true; }
                bool withAvatar = EditorGUILayout.ToggleLeft(new GUIContent("아바타와 함께", "끄면 고른 오브젝트만 찍어요."), iconWithAvatar);
                if (withAvatar != iconWithAvatar) { iconWithAvatar = withAvatar; iconDirty = true; }
                EditorGUILayout.LabelField($"{IconSize}×{IconSize} PNG로 {MenuIcons.Folder}/ 아래에 저장해요. 실행 취소는 아이콘 지정만 되돌리고 파일은 남아요.",
                    EditorStyles.wordWrappedMiniLabel);
            }

            string blocked = EditBlocked(config);
            if (blocked != null) EditorGUILayout.LabelField(blocked, EditorStyles.wordWrappedMiniLabel);
            using (new EditorGUILayout.HorizontalScope())
            {
                if (GUILayout.Button("취소", GUILayout.Width(60)))
                {
                    CloseIconStudio();
                    GUIUtility.ExitGUI();
                }
                using (new EditorGUI.DisabledScope(blocked != null || !iconImage))
                    if (GUILayout.Button("만들어서 적용")) ApplyIcon(config, item);
            }

            bool Inside(GameObject candidate)
            {
                if (!candidate) return false;
                if (avatar && candidate.transform.IsChildOf(avatar.transform)) return true;
                status = "아바타 안의 오브젝트만 찍을 수 있어요.";
                statusType = MessageType.Warning;
                return false;
            }
        }

        // Renders the icon at full size, saves it and sets it; a file whose icon could not be set is taken away again.
        private void ApplyIcon(AvatarCustomizer config, FinalMenu.Item item)
        {
            var image = RenderIcon(IconSize, true);
            if (!image)
            {
                Apply(null, null, "아이콘을 그리지 못했어요. 찍을 오브젝트가 보이는지 확인해 주세요.", true);
                return;
            }
            Texture2D icon;
            string path;
            try { icon = MenuIcons.Save(image, avatar.name, FinalMenu.Name(item.Control), out path); }
            finally { DestroyImmediate(image); }
            // Importing the file runs other tools' import code, which may take the avatar away.
            if (!IsSceneAvatar(avatar))
            {
                AssetDatabase.DeleteAsset(path);
                CloseIconStudio();
                Apply(null, null, "아바타가 씬에 없어서 아이콘을 적용하지 못했어요.", true);
                return;
            }
            FinalEdit edit;
            string error;
            try { edit = FinalMenuEdits.SetIcon(config, finalMenu, Context(), item, icon, out error); }
            catch
            {
                AssetDatabase.DeleteAsset(path);
                throw;
            }
            if (edit == null)
            {
                AssetDatabase.DeleteAsset(path);
                Apply(null, null, string.IsNullOrEmpty(error) ? "아이콘을 적용하지 못했어요." : error, true);
                return;
            }
            edit.Note = $"아이콘을 만들어 적용했어요: {path}. 실행 취소는 아이콘 지정만 되돌리고 파일은 남아요.";
            CloseIconStudio();
            if (!Apply("Set menu icon", edit, null, false)) AssetDatabase.DeleteAsset(path);
            GUIUtility.ExitGUI();
        }

        private void SetIconFinal(AvatarCustomizer config, FinalMenu.Item item, Texture2D icon, bool inGui = true)
        {
            if (EditBlocked(config) is string blocked) { Apply(null, null, blocked, inGui); return; }
            Apply("Set menu icon", FinalMenuEdits.SetIcon(config, finalMenu, Context(), item, icon, out string error), error, inGui);
        }

        private void RestoreIconFinal(AvatarCustomizer config, FinalMenu.Item item, bool inGui = true)
        {
            if (EditBlocked(config) is string blocked) { Apply(null, null, blocked, inGui); return; }
            Apply("Restore menu icon", FinalMenuEdits.RestoreIcon(config, finalMenu, Context(), item, out string error), error, inGui);
        }

        // The icon row of the selected item: pick one, make one, or go back to the item's own.
        private void DrawIconRow(AvatarCustomizer config, FinalMenu.Item item, string blocked)
        {
            using (new EditorGUI.DisabledScope(blocked != null || !Renamable(item)))
            using (new EditorGUILayout.HorizontalScope())
            {
                var next = (Texture2D)EditorGUILayout.ObjectField(item.Control.icon, typeof(Texture2D), false, GUILayout.Width(56), GUILayout.Height(56));
                if (next != item.Control.icon) SetIconFinal(config, item, next);
                using (new EditorGUILayout.VerticalScope())
                {
                    if (GUILayout.Button(new GUIContent("아이콘 만들기…", "아바타의 오브젝트를 찍어 아이콘을 만들어요."), EditorStyles.miniButton))
                    {
                        OpenIconStudio(item);
                        GUIUtility.ExitGUI();
                    }
                    if (finalMenu != null && FinalMenuEdits.HasIconRule(config, finalMenu, item) &&
                        GUILayout.Button(new GUIContent("원본 아이콘으로", "이 항목의 아이콘 규칙을 지워요."), EditorStyles.miniButton))
                        RestoreIconFinal(config, item);
                    EditorGUILayout.LabelField(item.Origin.Kind == MenuOriginKind.Original ? "비우면 아이콘 없이 보여요." : "비우면 원본 아이콘을 따라가요.",
                        EditorStyles.wordWrappedMiniLabel);
                }
            }
        }
    }
}
#endif
