#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Linq;
using nadena.dev.modular_avatar.core;
using nadena.dev.ndmf;
using UnityEditor;
using UnityEditor.Animations;
using UnityEngine;
using VRC.SDK3.Avatars.Components;
using VRC.SDK3.Avatars.ScriptableObjects;

namespace AvatarMenuTools
{
    // Turns the blendshape controls placed in a favorites menu into one FX layer (a direct blend tree holding a 1D tree
    // per control) and an expression parameter each. It adds Modular Avatar components to the build copy before
    // Modular Avatar runs, so MA merges the layer and the parameters like any other; the favorites pass then puts the
    // radial or toggle into the menu.
    internal static class BlendshapeControlBuilder
    {
        internal const string One = "NXYUI/Customizer/One";
        internal const string HolderName = "Avatar Customizer Blendshapes";
        internal const string ResetLayerName = "Avatar Customizer Reset";
        internal const string ResetName = "블렌드쉐이프 초기화";

        internal sealed class Built
        {
            internal string Parameter, Name;
            internal bool Radial;
            // Its parameter takes synced memory (BlendshapeControl.SyncedBits).
            internal bool Synced;
            // The reset button (BlendshapeControl.ResetId).
            internal bool Reset;
        }

        internal sealed class State
        {
            internal readonly Dictionary<string, Built> Controls = new Dictionary<string, Built>();
            internal readonly Dictionary<string, string> Problems = new Dictionary<string, string>();
            // Built, but another animation also moves the shape.
            internal readonly Dictionary<string, string> Notes = new Dictionary<string, string>();
            // A control left out because another on the same blendshape came first (Taken): that one's id.
            internal readonly Dictionary<string, string> TakenBy = new Dictionary<string, string>();
        }

        // A control's settings and the object it drives (by path below root), to tell whether it changed since a read.
        internal static string Fingerprint(BlendshapeControl s, Transform root) => s == null ? "" : string.Join("|",
            s.renderer ? AnimationUtility.CalculateTransformPath(s.renderer.transform, root) : "-", s.blendshape, s.type,
            s.min, s.max, s.defaultValue, s.synced, s.saved);

        // Why a control is missing from the menu (state of a plan or a build), or null when it is there.
        internal static string Verdict(State state, string id) =>
            state.Problems.TryGetValue(id, out var problem) ? problem : state.Controls.ContainsKey(id) ? null : "블렌드쉐이프 컨트롤을 만들지 못했어요.";

        internal static IEnumerable<string> UsedIds(AvatarCustomizer c) => c.AllMenus()
            .SelectMany(m => m.entries ?? new List<FavoriteMenuEntry>())
            .Where(e => e != null && e.IsShape).Select(e => e.shapeId).Distinct();

        // Why the control cannot be built on this avatar, or null.
        internal static string Problem(BlendshapeControl s, Transform root, BlendshapeConflicts conflicts = null)
        {
            if (s == null) return "삭제된 블렌드쉐이프 컨트롤입니다.";
            // In a build the EditorOnly objects are already gone, so both cases read the same there and in the scene.
            const string missing = "대상 오브젝트가 없거나 EditorOnly 오브젝트 안에 있습니다.";
            if (!s.renderer) return missing;
            if (!s.renderer.transform.IsChildOf(root)) return "아바타 안의 오브젝트가 아닙니다.";
            if (BlendshapeConflicts.RemovedAtBuild(s.renderer.transform, root)) return missing;
            if (!s.renderer.sharedMesh) return "대상 오브젝트의 Skinned Mesh Renderer에 메시가 없습니다.";
            if (s.renderer.sharedMesh.GetBlendShapeIndex(s.blendshape ?? "") < 0)
                return $"‘{s.blendshape}’ 블렌드쉐이프가 메시에 없습니다.";
            if (conflicts?.Blocked(s.renderer, s.blendshape) is string why)
                return $"다른 컴포넌트가 이 블렌드쉐이프를 바꿔서 막았습니다: {why}.";
            return null;
        }

        // Problem, and what only shows next to the avatar's other settings (c: the component that holds s): a favorites
        // entry the settings alone keep out of the menu, another control on the same blendshape, or a parameter name the
        // avatar already uses for something else.
        internal static string ProblemOn(AvatarCustomizer c, BlendshapeControl s, Transform root, BlendshapeConflicts conflicts = null)
        {
            if (Problem(s, root, conflicts) is string problem) return problem;
            var unplaceable = c ? Unplaceable(c) : new Dictionary<string, string>();
            if (unplaceable.TryGetValue(s.id, out var why)) return why;
            var declared = conflicts?.Parameters ?? DeclaredParameters.Read(root);
            if (TakenBy(c, s, declared, unplaceable) is BlendshapeControl first)
                return $"같은 블렌드쉐이프에 먼저 넣은 컨트롤이 ‘{MenuOf(c, first.id)}’ 메뉴에 있습니다. 한 블렌드쉐이프에는 컨트롤을 하나만 둘 수 있습니다.";
            return Clash(declared, s.Parameter, ParameterType(s));
        }

        // One blendshape takes one control: two would be two trees of one direct blend tree writing the same shape, and
        // their values add up instead of following either control. Of the controls the favorites menus hold, the first
        // in the menus' order is the one built. One that cannot be built anyway does not take the place: one left out
        // over its parameter (Clash), or whose entries the settings keep out of the menu (Unplaceable). Every other
        // reason is about the blendshape, which the two share. Whether a menu installed into a chosen submenu finds it
        // is only known once the menu is finished, after this choice; the menu pass says when the first one ends up
        // outside the menu (MenuComposer).
        private static BlendshapeControl TakenBy(AvatarCustomizer c, BlendshapeControl s, DeclaredParameters declared,
            IReadOnlyDictionary<string, string> unplaceable)
        {
            if (!c) return null;
            foreach (var id in UsedIds(c))
            {
                if (id == s.id) return null;
                var other = c.FindShape(id);
                if (other != null && other.renderer == s.renderer && other.blendshape == s.blendshape &&
                    !unplaceable.ContainsKey(id) && Clash(declared, other.Parameter, ParameterType(other)) == null)
                    return other;
            }
            return null;
        }

        // The name of the first favorites menu that holds a control.
        private static string MenuOf(AvatarCustomizer c, string id) =>
            c.AllMenus().FirstOrDefault(m => m.entries != null && m.entries.Any(e => e != null && e.IsShape && e.shapeId == id))?.DisplayName ?? "";

        // Why the settings alone keep every favorites entry of a control (or of the reset) out of the menu, by id. An id
        // with one entry that can go in is not listed. These are the entries MenuComposer.Install skips whatever the
        // avatar's menu is: a menu installed into a made folder that no rule makes, a menu set to a submenu with none
        // chosen, an entry under a folder its menu never reaches (a parent folder that was deleted, or past 64 levels).
        // Such a control is not built at all, so it takes no synced memory on any platform alike.
        internal static Dictionary<string, string> Unplaceable(AvatarCustomizer c)
        {
            var reasons = new Dictionary<string, string>();
            var placeable = new HashSet<string>();
            var folders = new HashSet<string>((c.createdFolders ?? new List<MenuFolderRule>())
                .Where(f => f != null && !string.IsNullOrEmpty(f.id)).Select(f => f.id));
            foreach (var menu in c.AllMenus())
            {
                var entries = (menu.entries ?? new List<FavoriteMenuEntry>()).Where(e => e != null).ToList();
                string why = menu.InFolder && !folders.Contains(menu.destinationFolder)
                    ? $"‘{menu.DisplayName}’ 메뉴를 설치할 새 폴더가 없어 메뉴에 들어갈 수 없습니다."
                    : !menu.useRoot && !menu.InFolder && (menu.destination?.IsEmpty ?? true)
                        ? $"‘{menu.DisplayName}’ 메뉴의 설치 위치가 정해지지 않아 메뉴에 들어갈 수 없습니다."
                        : null;
                // The entries the menu reaches from its top, walked as MenuComposer's MakeChildren walks them.
                var reached = new HashSet<FavoriteMenuEntry>();
                if (why == null)
                {
                    var children = entries.ToLookup(e => e.Parent);
                    var made = new HashSet<string>();
                    void Walk(string parent, int depth)
                    {
                        foreach (var e in children[parent])
                        {
                            if (!e.IsFolder) reached.Add(e);
                            else if (depth < 64 && made.Add(e.folderId)) Walk(e.folderId, depth + 1);
                        }
                    }
                    Walk("", 0);
                }
                foreach (var e in entries.Where(e => e.IsShape))
                {
                    if (reached.Contains(e)) placeable.Add(e.shapeId);
                    else if (!reasons.ContainsKey(e.shapeId))
                        reasons[e.shapeId] = why ?? $"‘{menu.DisplayName}’ 메뉴에서 이 항목이 든 폴더에 닿지 못해(위 폴더가 지워졌거나 64단계보다 깊음) 메뉴에 들어갈 수 없습니다.";
                }
            }
            foreach (var id in placeable) reasons.Remove(id);
            return reasons;
        }

        private static VRCExpressionParameters.ValueType ParameterType(BlendshapeControl s) =>
            s.type == BlendshapeControlType.Radial ? VRCExpressionParameters.ValueType.Float : VRCExpressionParameters.ValueType.Bool;

        // The avatar's own expression parameter of that name, before this tool adds any. The names are this tool's, so
        // only an avatar baked from an earlier build of these settings has one.
        private static VRCExpressionParameters.Parameter Existing(Transform root, string parameter)
        {
            var descriptor = root ? root.GetComponent<VRCAvatarDescriptor>() : null;
            var parameters = descriptor && descriptor.expressionParameters ? descriptor.expressionParameters.parameters : null;
            return parameters?.FirstOrDefault(p => p != null && p.name == parameter);
        }

        // The name is declared with another type somewhere Modular Avatar reads (DeclaredParameters): MA stops the build
        // over a parameter declared with two types, so the control is left out with the reason instead. Or a component on
        // the avatar root renames it for everything under the root, this tool's generated object included: the menu item
        // made later would then drive a name nothing has.
        private static string Clash(DeclaredParameters declared, string parameter, VRCExpressionParameters.ValueType type)
        {
            if (declared.RenamedTo(parameter) is string renamed)
                return $"아바타 루트의 컴포넌트(MA Parameters 등)가 이 컨트롤의 파라미터 이름(‘{parameter}’)을 ‘{renamed}’(으)로 바꿔서, " +
                       "메뉴로 이 컨트롤을 움직일 수 없습니다. 그 설정을 지우거나 컨트롤을 새로 만드세요.";
            var other = declared.OtherType(parameter, type);
            return other == null ? null
                : $"{other.Value.Source}에 같은 이름(‘{parameter}’)의 파라미터가 다른 타입({other.Value.Type})으로 이미 있어서, Modular Avatar가 둘을 합칠 수 없습니다. " +
                  "이전 빌드 결과를 구운 아바타라면 그 파라미터를 지우고, 아니면 컨트롤을 새로 만드세요.";
        }

        internal static string Note(BlendshapeControl s, BlendshapeConflicts conflicts) =>
            !(s?.renderer && conflicts?.Animated(s.renderer, s.blendshape) is string what) ? null
            : conflicts.AnimatedAbove(s.renderer, s.blendshape)
                ? $"{what}도 이 블렌드쉐이프를 움직입니다. 그 레이어가 이 컨트롤보다 뒤에 합쳐져서(레이어 우선순위가 더 높음), 그 애니메이션이 재생되는 동안에는 메뉴 값 대신 그 값이 보입니다."
                : $"{what}도 이 블렌드쉐이프를 움직입니다. 이 컨트롤의 레이어가 그 뒤에 합쳐져서 게임에서는 이 메뉴 값이 우선합니다.";

        // With the same type Modular Avatar merges the two declarations, keeping "saved" and "synced" on when either has it.
        private static string KeptNote(BlendshapeControl s, Transform root) =>
            Existing(root, s.Parameter) is VRCExpressionParameters.Parameter existing &&
            ((existing.saved && !s.saved) || (existing.networkSynced && !s.synced))
                ? "아바타의 Expression Parameters에 이 컨트롤의 파라미터가 이미 있어서, 거기서 켜 둔 저장·동기화는 여기서 꺼도 켜진 채로 빌드됩니다."
                : null;

        // Which of the controls the favorites menus hold can be built on this avatar (root), as the menu will show them:
        // fills state and returns the controls to build. The window runs it on the avatar in the scene; the build on
        // its copy before Modular Avatar, which has the same components.
        internal static List<BlendshapeControl> Plan(AvatarCustomizer c, Transform root, State state)
        {
            var controls = new List<BlendshapeControl>();
            if (!c || !c.enabled) return controls;
            var used = UsedIds(c).ToArray();
            bool reset = used.Contains(BlendshapeControl.ResetId);
            var ids = used.Where(id => id != BlendshapeControl.ResetId).ToArray();
            if (reset) state.Problems[BlendshapeControl.ResetId] = NothingToReset;
            if (ids.Length == 0) return controls;
            var conflicts = BlendshapeConflicts.Scan(root);
            var unplaceable = Unplaceable(c);
            foreach (var id in ids)
            {
                var shape = c.FindShape(id);
                var problem = shape == null ? Problem(null, root) : ProblemOn(c, shape, root, conflicts);
                if (problem != null)
                {
                    state.Problems[id] = problem;
                    if (shape != null && Problem(shape, root, conflicts) == null && !unplaceable.ContainsKey(id) &&
                        TakenBy(c, shape, conflicts.Parameters, unplaceable) is BlendshapeControl first)
                        state.TakenBy[id] = first.id;
                }
                else
                {
                    controls.Add(shape);
                    var notes = new[] { Note(shape, conflicts), KeptNote(shape, root) }.Where(n => n != null).ToArray();
                    if (notes.Length > 0) state.Notes[id] = string.Join(" ", notes);
                }
            }
            if (controls.Count == 0) return controls;
            foreach (var s in controls)
                state.Controls[s.id] = new Built
                {
                    Parameter = s.Parameter, Name = s.blendshape, Radial = s.type == BlendshapeControlType.Radial, Synced = s.SyncedBits > 0,
                };
            if (reset)
            {
                if (unplaceable.TryGetValue(BlendshapeControl.ResetId, out var why))
                    state.Problems[BlendshapeControl.ResetId] = why;
                else if (Clash(conflicts.Parameters, BlendshapeControl.ResetParameter, VRCExpressionParameters.ValueType.Bool) is string clash)
                    state.Problems[BlendshapeControl.ResetId] = clash;
                else
                {
                    state.Problems.Remove(BlendshapeControl.ResetId);
                    state.Controls[BlendshapeControl.ResetId] = new Built { Parameter = BlendshapeControl.ResetParameter, Name = ResetName, Reset = true };
                }
            }
            return controls;
        }

        private const string NothingToReset = "초기화할 블렌드쉐이프 컨트롤이 없습니다.";

        internal static void Generate(BuildContext context)
        {
            var root = context.AvatarRootObject;
            var c = root.GetComponent<AvatarCustomizer>();
            if (!c || !c.enabled) return;
            var state = context.GetState<State>();
            var planned = new State();
            List<BlendshapeControl> controls;
            try { controls = Plan(c, root.transform, planned); }
            finally
            {
                // Problems and notes now, even from a check that failed half way; the controls only once they are built,
                // so a failure below keeps them out of the menu.
                foreach (var problem in planned.Problems) state.Problems[problem.Key] = problem.Value;
                foreach (var note in planned.Notes) state.Notes[note.Key] = note.Value;
                foreach (var taken in planned.TakenBy) state.TakenBy[taken.Key] = taken.Value;
            }
            if (controls.Count == 0) return;
            bool reset = planned.Controls.ContainsKey(BlendshapeControl.ResetId);
            if (reset) state.Problems[BlendshapeControl.ResetId] = NothingToReset;

            var controller = new AnimatorController { name = HolderName };
            controller.parameters = new[] { new AnimatorControllerParameter { name = One, type = AnimatorControllerParameterType.Float, defaultFloat = 1f } }
                .Concat(controls.Select(s => new AnimatorControllerParameter
                {
                    // Float even for a toggle: VRChat drives a float animator parameter from a bool expression parameter.
                    name = s.Parameter, type = AnimatorControllerParameterType.Float, defaultFloat = s.StartValue,
                })).ToArray();
            var direct = new BlendTree { name = "Blendshapes", blendType = BlendTreeType.Direct, useAutomaticThresholds = false };
            direct.children = controls.Select(s =>
            {
                string path = AnimationUtility.CalculateTransformPath(s.renderer.transform, root.transform);
                var tree = new BlendTree
                {
                    name = s.blendshape, blendType = BlendTreeType.Simple1D, blendParameter = s.Parameter, useAutomaticThresholds = false,
                };
                tree.children = new[]
                {
                    new ChildMotion { motion = Clip(s, path, s.min), threshold = 0f, timeScale = 1f },
                    new ChildMotion { motion = Clip(s, path, s.max), threshold = 1f, timeScale = 1f },
                };
                return new ChildMotion { motion = tree, directBlendParameter = One, timeScale = 1f };
            }).ToArray();
            // Direct blend trees need write defaults on; this layer animates nothing else.
            var animate = new AnimatorState { name = "Blendshapes", motion = direct, writeDefaultValues = true };
            var machine = new AnimatorStateMachine
            {
                name = "Blendshapes",
                states = new[] { new ChildAnimatorState { state = animate, position = new Vector3(300f, 100f) } },
                defaultState = animate,
            };
            var layers = new List<AnimatorControllerLayer> { new AnimatorControllerLayer { name = HolderName, defaultWeight = 1f, stateMachine = machine } };
            if (reset)
            {
                // Pressing the button (Reset true) enters a state whose parameter driver sets every control back to its
                // default. It runs for the wearer only; synced controls then reach everyone as usual.
                controller.parameters = controller.parameters.Append(new AnimatorControllerParameter
                    { name = BlendshapeControl.ResetParameter, type = AnimatorControllerParameterType.Bool }).ToArray();
                var empty = new AnimationClip { name = ResetLayerName + " (empty)" };
                var idle = new AnimatorState { name = "Idle", motion = empty, writeDefaultValues = true };
                var apply = new AnimatorState { name = "Reset", motion = empty, writeDefaultValues = true };
                var driver = apply.AddStateMachineBehaviour<VRCAvatarParameterDriver>();
                driver.localOnly = true;
                driver.parameters = controls.Select(s => new VRC.SDKBase.VRC_AvatarParameterDriver.Parameter
                {
                    type = VRC.SDKBase.VRC_AvatarParameterDriver.ChangeType.Set, name = s.Parameter, value = s.StartValue,
                }).ToList();
                AnimatorStateTransition To(AnimatorState target, AnimatorConditionMode mode)
                {
                    var transition = new AnimatorStateTransition { destinationState = target, hasExitTime = false, duration = 0f, hasFixedDuration = true };
                    transition.AddCondition(mode, 0f, BlendshapeControl.ResetParameter);
                    return transition;
                }
                idle.transitions = new[] { To(apply, AnimatorConditionMode.If) };
                apply.transitions = new[] { To(idle, AnimatorConditionMode.IfNot) };
                layers.Add(new AnimatorControllerLayer
                {
                    name = ResetLayerName, defaultWeight = 1f,
                    stateMachine = new AnimatorStateMachine
                    {
                        name = "Reset", defaultState = idle,
                        states = new[]
                        {
                            new ChildAnimatorState { state = idle, position = new Vector3(300f, 100f) },
                            new ChildAnimatorState { state = apply, position = new Vector3(300f, 200f) },
                        },
                    },
                });
            }
            controller.layers = layers.ToArray();

            var holder = new GameObject(HolderName);
            holder.transform.SetParent(root.transform, false);
            var merge = holder.AddComponent<ModularAvatarMergeAnimator>();
            merge.animator = controller;
            merge.layerType = VRCAvatarDescriptor.AnimLayerType.FX;
            merge.pathMode = MergeAnimatorPathMode.Absolute;
            merge.matchAvatarWriteDefaults = false;
            var parameters = holder.AddComponent<ModularAvatarParameters>();
            parameters.parameters = controls.Select(s => new ParameterConfig
            {
                nameOrPrefix = s.Parameter,
                syncType = s.type == BlendshapeControlType.Radial ? ParameterSyncType.Float : ParameterSyncType.Bool,
                localOnly = !s.synced,
                saved = s.saved,
                defaultValue = s.StartValue,
                hasExplicitDefaultValue = true,
            }).ToList();
            if (reset)
                parameters.parameters.Add(new ParameterConfig
                {
                    nameOrPrefix = BlendshapeControl.ResetParameter, syncType = ParameterSyncType.Bool,
                    localOnly = true, saved = false, defaultValue = 0f, hasExplicitDefaultValue = true,
                });

            foreach (var built in planned.Controls) state.Controls[built.Key] = built.Value;
            if (reset) state.Problems.Remove(BlendshapeControl.ResetId);
        }

        private static AnimationClip Clip(BlendshapeControl s, string path, float weight)
        {
            var clip = new AnimationClip { name = $"{s.blendshape} {weight:0.#}" };
            AnimationUtility.SetEditorCurve(clip,
                EditorCurveBinding.FloatCurve(path, typeof(SkinnedMeshRenderer), "blendShape." + s.blendshape),
                AnimationCurve.Constant(0f, 1f / 60f, weight));
            return clip;
        }
    }

    // The parameters an avatar declares, as Modular Avatar will see them next to this tool's: NDMF's parameter
    // introspection, which MA's own inspector reads. It covers the avatar's expression parameters, MA Parameters after
    // their renames, and the components of other tools that tell NDMF their parameters, and leaves out EditorOnly
    // objects as a build does.
    internal sealed class DeclaredParameters
    {
        // The types each name is declared with (more than one when the declarations already disagree), and where.
        private readonly Dictionary<string, List<(string Type, string Source)>> types = new Dictionary<string, List<(string, string)>>();
        // Names a component on the avatar root gives another name, for everything under the root.
        private readonly Dictionary<string, string> renamed = new Dictionary<string, string>();

        internal static DeclaredParameters Read(Transform root)
        {
            var result = new DeclaredParameters();
            if (!root) return result;
            try
            {
                var info = ParameterInfo.ForUI;
                var declared = info.GetParametersForObject(root.gameObject, (conflict, a, b) =>
                {
                    if (conflict != ParameterInfo.ConflictType.TypeMismatch) return;
                    result.Add(a);
                    result.Add(b);
                }).ToList();
                foreach (var p in declared) result.Add(p);
                foreach (var pair in info.GetParameterRemappingsAt(root.gameObject))
                    if (pair.Key.Item1 == ParameterNamespace.Animator && pair.Value.ParameterName != pair.Key.Item2)
                        result.renamed[pair.Key.Item2] = pair.Value.ParameterName;
            }
            catch (Exception e)
            {
                // A tool's parameter provider that fails must not stop the build or the window: the avatar's own
                // expression parameters are still checked, as before.
                Debug.LogWarning("[Avatar Customizer] 다른 도구의 파라미터 정보를 읽지 못해 Expression Parameters만 확인했어요: " + e.Message, root);
                result.types.Clear();
                result.renamed.Clear();
                var descriptor = root.GetComponent<VRCAvatarDescriptor>();
                foreach (var p in descriptor && descriptor.expressionParameters ? descriptor.expressionParameters.parameters
                             : Array.Empty<VRCExpressionParameters.Parameter>())
                    if (p != null && !string.IsNullOrEmpty(p.name)) result.Add(p.name, p.valueType.ToString(), Label(descriptor));
            }
            return result;
        }

        // Declarations that adapt their type (Modular Avatar's menu items) and animator-only ones never clash in MA.
        private void Add(ProvidedParameter p)
        {
            if (p == null || p.Namespace != ParameterNamespace.Animator || p.IsAnimatorOnly || p.ExpandTypeOnConflict || p.ParameterType == null) return;
            Add(p.EffectiveName, p.ParameterType.Value.ToString(), Label(p.Source));
        }

        private void Add(string name, string type, string source)
        {
            if (string.IsNullOrEmpty(name)) return;
            if (!types.TryGetValue(name, out var list)) types.Add(name, list = new List<(string, string)>());
            if (!list.Contains((type, source))) list.Add((type, source));
        }

        private static string Label(Component source) =>
            !source ? "다른 컴포넌트" : source is VRCAvatarDescriptor ? "아바타의 Expression Parameters"
            : source is ModularAvatarParameters ? $"‘{source.gameObject.name}’의 MA Parameters"
            : $"‘{source.gameObject.name}’의 {ObjectNames.NicifyVariableName(source.GetType().Name)}";

        // A declaration of that name with a type other than type, or null.
        internal (string Type, string Source)? OtherType(string name, VRCExpressionParameters.ValueType type) =>
            types.TryGetValue(name, out var list) && list.FirstOrDefault(d => d.Type != type.ToString()) is var other && other.Type != null
                ? other : ((string, string)?)null;

        internal string RenamedTo(string name) => renamed.TryGetValue(name, out var to) ? to : null;
    }
}
#endif
