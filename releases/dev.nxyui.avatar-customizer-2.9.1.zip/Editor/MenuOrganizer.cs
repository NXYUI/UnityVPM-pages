#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.Rendering;
using VRC.SDK3.Avatars.ScriptableObjects;
using Control = VRC.SDK3.Avatars.ScriptableObjects.VRCExpressionsMenu.Control;
using Object = UnityEngine.Object;

namespace AvatarMenuTools
{
    // The first edit of the avatar's finished menu ("원본 메뉴 정리"): renames, moves and hides, on a copy of the menu — the menu
    // assets are never changed. The build runs it before the favorites menus are made, so favorites see the organized
    // menu; the window runs the same code on a saved copy of the last read menu, so the favorites tab shows the
    // organized menu as soon as a rule changes, without building again.
    internal sealed class MenuOrganizer
    {
        internal delegate void ReportIssue(string title, string detail, bool warning, FavoriteMenuBuilder.RepairTarget target,
            int itemIndex, FavoriteMenuKey saved, FavoriteMenuKey current);

        private readonly Texture2D moreIcon;
        private readonly string pageLabel;
        private readonly HideFlags flags;
        private readonly ReportIssue report;
        // The page links of the avatar's menu (FindPageLinks): of a read's copy as judged when it was read
        // (MenuSnapshot.PageLinks), otherwise as given or found on root itself.
        private readonly ICollection<(VRCExpressionsMenu, Control)> readLinks;

        // The menu as the avatar's tools built it: keys use its names and structure. Rules refer to these.
        internal readonly FavoriteMenuKey[] Original;
        internal readonly Dictionary<FavoriteMenuKey, Control> OriginalItems = new Dictionary<FavoriteMenuKey, Control>();
        // The organized copy (null without a menu) and its items. Keys keep each item's original name, so saved favorites
        // keep resolving; displayName carries the shown (renamed) name.
        internal readonly VRCExpressionsMenu Root;
        internal readonly FavoriteMenuKey[] Organized = Array.Empty<FavoriteMenuKey>();
        internal readonly Dictionary<FavoriteMenuKey, Control> OrganizedItems = new Dictionary<FavoriteMenuKey, Control>();
        // Every menu this organizer and later steps made: the build saves them, the window destroys them.
        internal readonly List<VRCExpressionsMenu> Created = new List<VRCExpressionsMenu>();
        // Each page of the copy that ends in a page link, and that link.
        internal readonly Dictionary<VRCExpressionsMenu, Control> PageLinks = new Dictionary<VRCExpressionsMenu, Control>();
        // Copies of the avatar's own items (not page links, not folders made here).
        internal readonly HashSet<Control> OriginalControls = new HashSet<Control>();
        internal readonly HashSet<Control> MovedControls = new HashSet<Control>();
        // Copies left out of the menu by "숨기기". They stay in OrganizedItems (marked hidden), so favorites can hold them.
        internal readonly HashSet<Control> HiddenControls = new HashSet<Control>();
        // Folders this organizer made (MenuFolderRule), by id: the submenu control placed in the menu and the menu it opens.
        internal readonly Dictionary<string, (Control Control, VRCExpressionsMenu Menu)> Folders =
            new Dictionary<string, (Control, VRCExpressionsMenu)>();
        // Copies of the avatar's own page links; the other page links were made here.
        internal readonly HashSet<Control> OriginalLinks = new HashSet<Control>();
        // Top-level folders made by a move without a place to a folder by name (before 2.7.0), and that name.
        internal readonly Dictionary<Control, string> LegacyFolders = new Dictionary<Control, string>();
        // Made folders left out because they held nothing (DropEmptyFolders), in that order: the first page of the level
        // each was in, and the item it was in front of then (null at the end).
        internal readonly List<(string Id, VRCExpressionsMenu Level, Control Before)> Dropped =
            new List<(string, VRCExpressionsMenu, Control)>();
        internal readonly string PageLabel;
        internal int NameCount => names.Count;
        internal int IconCount => icons.Count;
        internal int MoveCount => MovedControls.Count;
        internal int HideCount => HiddenControls.Count;
        internal int FolderCount => Folders.Count - droppedFolders.Count;

        private readonly Dictionary<FavoriteMenuKey, VRCExpressionsMenu> parentPages = new Dictionary<FavoriteMenuKey, VRCExpressionsMenu>();
        private readonly Dictionary<Control, string> names = new Dictionary<Control, string>();
        private readonly Dictionary<Control, Texture2D> icons = new Dictionary<Control, Texture2D>();
        private readonly Dictionary<VRCExpressionsMenu, VRCExpressionsMenu> copies = new Dictionary<VRCExpressionsMenu, VRCExpressionsMenu>();
        private readonly Dictionary<Control, Control> controlCopies = new Dictionary<Control, Control>();
        private readonly Dictionary<Control, Control> originalOf = new Dictionary<Control, Control>();
        private readonly Dictionary<Control, string> folderIds = new Dictionary<Control, string>();
        private readonly HashSet<string> droppedFolders = new HashSet<string>();
        // The first key of each of the avatar's controls (one reached by two ways has a key for each), and of the
        // submenu control that opens each of its menus.
        private readonly Dictionary<Control, FavoriteMenuKey> firstKeys = new Dictionary<Control, FavoriteMenuKey>();
        private readonly Dictionary<VRCExpressionsMenu, FavoriteMenuKey> openedBy = new Dictionary<VRCExpressionsMenu, FavoriteMenuKey>();
        private readonly Dictionary<VRCExpressionsMenu, VRCExpressionsMenu> originalMenus = new Dictionary<VRCExpressionsMenu, VRCExpressionsMenu>();
        private readonly Dictionary<Control, FavoriteMenuKey> organizedKeys = new Dictionary<Control, FavoriteMenuKey>();
        // Each key of the avatar's menu and the key of the submenu it was found in (null at the top level).
        private readonly Dictionary<FavoriteMenuKey, FavoriteMenuKey> originalParents = new Dictionary<FavoriteMenuKey, FavoriteMenuKey>();
        // Where each key's control sits (its menu and slot) and the copy made for that slot: a control some tool put in two
        // menus is one control, but each row of it is moved or hidden on its own.
        private readonly Dictionary<FavoriteMenuKey, (VRCExpressionsMenu Menu, int Slot)> keySlots = new Dictionary<FavoriteMenuKey, (VRCExpressionsMenu, int)>();
        private readonly Dictionary<(VRCExpressionsMenu, int), Control> slotCopies = new Dictionary<(VRCExpressionsMenu, int), Control>();
        private readonly Dictionary<Control, FavoriteMenuKey> copyKeys = new Dictionary<Control, FavoriteMenuKey>();

        // pageLabel: the name for page links ("More"), or null to keep theirs. flags: for the menus made (a preview's
        // copies are kept out of the scene and assets). pageLinks: root's page links when they are already known (a
        // read's own, MenuSnapshot.PageLinks, when root is its copy; the build's, which knows VRCFury's link as well);
        // null to find Modular Avatar's here. saved: the other keys the settings hold (favorites, install locations,
        // defaults: MenuSettings.SavedKeys), listed wherever they are (RowLimit) like the rules' own. Order: renames,
        // moves without a place (as before 2.7.0), made folders, moves to a place, hides.
        internal MenuOrganizer(VRCExpressionsMenu root, Texture2D moreIcon, string pageLabel,
            IReadOnlyList<MenuNameOverride> overrides, IReadOnlyList<MenuMoveRule> moves, IReadOnlyList<MenuHideRule> hides,
            IReadOnlyList<MenuFolderRule> folders, ReportIssue report, HideFlags flags = HideFlags.None,
            ICollection<(VRCExpressionsMenu, Control)> pageLinks = null, IReadOnlyList<MenuIconOverride> iconRules = null,
            IEnumerable<FavoriteMenuKey> saved = null)
        {
            this.moreIcon = moreIcon;
            this.pageLabel = pageLabel;
            PageLabel = pageLabel ?? "More";
            this.flags = flags;
            readLinks = pageLinks ?? FindPageLinks(root, moreIcon, null);
            this.report = report ?? ((t, d, w, target, i, s, c) => { });
            formerLinks = FormerPageLinks(root);
            formerLinkControls = new HashSet<Control>(formerLinks.Select(l => l.Item2));
            foreach (var key in (overrides ?? Array.Empty<MenuNameOverride>()).Select(r => r?.source)
                         .Concat((iconRules ?? Array.Empty<MenuIconOverride>()).Select(r => r?.source))
                         .Concat((moves ?? Array.Empty<MenuMoveRule>()).SelectMany(r => new[] { r?.source, r?.destination, r?.before }))
                         .Concat((hides ?? Array.Empty<MenuHideRule>()).Select(r => r?.source))
                         .Concat((folders ?? Array.Empty<MenuFolderRule>()).SelectMany(r => new[] { r?.parent, r?.before }))
                         .Concat(saved ?? Enumerable.Empty<FavoriteMenuKey>()))
                for (int n = 1; n <= (key?.path?.Length ?? 0); n++)
                    wanted.Add(PathText(key.path.Take(n)));
            Original = WalkOriginal(root);

            for (int i = 0; i < (overrides?.Count ?? 0); i++)
            {
                var rule = overrides[i];
                if (rule?.source == null || string.IsNullOrWhiteSpace(rule.label)) continue;
                string title = $"이름 변경 / {rule.source.DisplayPath}";
                var key = Match(rule.source, title, FavoriteMenuBuilder.RepairTarget.NameOverride, i);
                if (key == null) continue;
                var control = OriginalItems[key];
                var label = rule.label.Trim();
                if (names.TryGetValue(control, out var prior) && prior != label)
                    this.report(title, $"공유 항목에 이미 ‘{prior}’ 이름이 적용되어 ‘{label}’ 변경을 제외했습니다.", true,
                        FavoriteMenuBuilder.RepairTarget.NameOverride, i, rule.source, null);
                else names[control] = label;
            }

            for (int i = 0; i < (iconRules?.Count ?? 0); i++)
            {
                var rule = iconRules[i];
                if (rule?.source == null) continue;
                string title = $"아이콘 / {rule.source.DisplayPath}";
                var key = Match(rule.source, title, FavoriteMenuBuilder.RepairTarget.Icon, i);
                if (key == null) continue;
                var control = OriginalItems[key];
                if (icons.TryGetValue(control, out var prior) && prior != rule.icon)
                    this.report(title, "공유 항목에 다른 아이콘이 먼저 정해져 이 아이콘은 제외했습니다.", true,
                        FavoriteMenuBuilder.RepairTarget.Icon, i, rule.source, null);
                else icons[control] = rule.icon;
            }

            if (!root) return;
            try
            {
                Root = Clone(root);
                foreach (var key in Original)
                    if (keySlots.TryGetValue(key, out var slot) && slotCopies.TryGetValue(slot, out var copy) && !copyKeys.ContainsKey(copy))
                        copyKeys.Add(copy, key);
                var positioned = ApplyMoves(moves);
                ApplyPositioned(MakeFolders(folders), positioned);
                FindHidden(hides);
                // Walked before hidden items leave their pages, so they keep their place (and paths) in the list.
                Organized = WalkOrganized();
                if (rowsCut)
                    this.report("메뉴 목록", $"같은 하위 메뉴를 여는 길이 너무 많아서, 목록이 {RowLimit:N0}줄을 넘은 뒤에는 이미 나온 메뉴를 다른 길로 " +
                        "다시 적지 않았어요. 빌드되는 메뉴는 그대로이고, 그 안의 항목은 먼저 나온 길에서 고를 수 있어요. " +
                        "이미 저장한 설정이 가리키는 항목은 그 길에서도 그대로 찾아요.", false,
                        FavoriteMenuBuilder.RepairTarget.None, -1, null, null);
                RemoveHidden();
                if (MoveCount > 0 || HideCount > 0) CloseGaps();
            }
            catch
            {
                // The caller never gets this organizer, so free the menus it made.
                foreach (var menu in Created) if (menu) Object.DestroyImmediate(menu);
                throw;
            }
        }

        // ---------------------------------------------------------------- the original menu

        // A page link of the avatar's menu.
        internal bool IsOriginalPage(VRCExpressionsMenu menu, Control c) => c != null && readLinks.Contains((menu, c));

        // The page links of a menu tree: the last of eight controls, opening a submenu with no parameter, that looks as
        // Modular Avatar or VRCFury (next: its link on this avatar, null without it) make theirs
        // (FavoriteMenuBuilder.IsGeneratedLink), where the page it opens has no other way in. Those tools make that page
        // new, for the link alone. A "page" that another submenu opens too, or that leads back to a page before it, is
        // a menu of its own: laying its items out over the pages again would empty it for the other way in, and a ring
        // of pages has no last page to end on.
        internal static HashSet<(VRCExpressionsMenu, Control)> FindPageLinks(VRCExpressionsMenu root, Texture2D moreIcon, PageLinkLook next)
        {
            var links = new HashSet<(VRCExpressionsMenu, Control)>();
            if (!root) return links;
            // The controls that open each menu, over every menu reached from the top (which the avatar itself opens).
            var ways = new Dictionary<VRCExpressionsMenu, int> { [root] = 1 };
            var menus = new List<VRCExpressionsMenu> { root };
            for (int i = 0; i < menus.Count; i++)
                foreach (var c in menus[i].controls ?? new List<Control>())
                {
                    if (c == null || c.type != Control.ControlType.SubMenu || !c.subMenu) continue;
                    ways.TryGetValue(c.subMenu, out int count);
                    ways[c.subMenu] = count + 1;
                    if (count == 0) menus.Add(c.subMenu);
                }
            foreach (var menu in menus)
            {
                if (menu.controls?.Count != VRCExpressionsMenu.MAX_CONTROLS) continue;
                var c = menu.controls[menu.controls.Count - 1];
                if (c != null && c.type == Control.ControlType.SubMenu && c.subMenu && string.IsNullOrEmpty(c.parameter?.name) &&
                    ways[c.subMenu] == 1 && FavoriteMenuBuilder.IsGeneratedLink(c, moreIcon, next))
                    links.Add((menu, c));
            }
            return links;
        }

        // Each way to an item is a row of its own, so a menu that several submenus open is listed once for each. Menus
        // that share submenus layer after layer (or open each other in rings) have more ways than could ever be listed:
        // past this many rows, a menu already listed is listed again only for the rows the settings name (wanted, by
        // path and every path on the way there), so that a saved setting still finds its item at its own path. Every
        // item keeps a row, and the copy of the menu (Clone) holds every menu whatever the rows say.
        internal const int RowLimit = 20000;
        private bool rowsCut;
        private readonly HashSet<string> wanted = new HashSet<string>();

        private static string PathText(IEnumerable<string> path) => string.Join("\u001f", path);

        // Whether a row past the limit is listed: its path, or the path 2.8.2 saved it under, is named by the settings.
        private bool Wanted(string[] path, string[] former) =>
            wanted.Contains(PathText(path)) || (former != path && wanted.Contains(PathText(former)));

        // The submenus that 2.8.2 and before took for the rest of a page and that are menus of their own now
        // (FindPageLinks): the last of eight controls, a submenu with no parameter, named "More" without an icon or with
        // one of Modular Avatar's, or with Modular Avatar's More icon whatever its name. Those versions listed and saved
        // the items inside under the level before (FavoriteMenuKey.legacyPath).
        private readonly HashSet<(VRCExpressionsMenu, Control)> formerLinks;
        private readonly HashSet<Control> formerLinkControls;

        private HashSet<(VRCExpressionsMenu, Control)> FormerPageLinks(VRCExpressionsMenu root)
        {
            var links = new HashSet<(VRCExpressionsMenu, Control)>();
            var seen = new HashSet<VRCExpressionsMenu>();
            var menus = new List<VRCExpressionsMenu>();
            if (root && seen.Add(root)) menus.Add(root);
            for (int i = 0; i < menus.Count; i++)
            {
                var controls = menus[i].controls ?? new List<Control>();
                foreach (var c in controls)
                    if (c != null && c.type == Control.ControlType.SubMenu && c.subMenu && seen.Add(c.subMenu)) menus.Add(c.subMenu);
                var last = controls.Count == VRCExpressionsMenu.MAX_CONTROLS ? controls[controls.Count - 1] : null;
                if (last != null && last.type == Control.ControlType.SubMenu && last.subMenu && string.IsNullOrEmpty(last.parameter?.name) &&
                    ((moreIcon && last.icon == moreIcon) || (last.name == "More" && (!last.icon ||
                        UnityEditor.AssetDatabase.GetAssetPath(last.icon).StartsWith("Packages/nadena.dev.modular-avatar/", StringComparison.Ordinal)))) &&
                    !IsOriginalPage(menus[i], last))
                    links.Add((menus[i], last));
            }
            return links;
        }

        private FavoriteMenuKey[] WalkOriginal(VRCExpressionsMenu root)
        {
            var keys = new List<FavoriteMenuKey>();
            var groups = new Dictionary<Control, int>();
            var listed = new HashSet<VRCExpressionsMenu>();
            // former: the path 2.8.2 listed this menu's items under (FormerPageLinks).
            void Walk(VRCExpressionsMenu menu, string[] path, string[] former, HashSet<VRCExpressionsMenu> active, int depth,
                FavoriteMenuKey parent = null)
            {
                if (!menu || menu.controls == null || depth > 64 || active.Contains(menu)) return;
                bool guided = !listed.Add(menu) && keys.Count >= RowLimit;
                if (guided && wanted.Count == 0)
                {
                    rowsCut = true;
                    return;
                }
                active.Add(menu);
                for (int slot = 0; slot < menu.controls.Count; slot++)
                {
                    var c = menu.controls[slot];
                    if (c == null) continue;
                    if (IsOriginalPage(menu, c))
                    {
                        Walk(c.subMenu, path, former, active, depth, parent);
                        continue;
                    }
                    var next = path.Concat(new[] { c.name ?? "" }).ToArray();
                    bool wasPage = formerLinks.Contains((menu, c));
                    var formerNext = wasPage ? former : former == path ? next : former.Concat(new[] { c.name ?? "" }).ToArray();
                    if (guided && !Wanted(next, formerNext))
                    {
                        rowsCut = true;
                        continue;
                    }
                    if (!groups.TryGetValue(c, out int group)) groups.Add(c, group = groups.Count + 1);
                    var key = KeyOf(c, next, group);
                    // 2.8.2 had no row for the submenu it took for a page.
                    if (!wasPage && formerNext != next) key.legacyPath = formerNext;
                    OriginalItems.Add(key, c);
                    parentPages.Add(key, menu);
                    keys.Add(key);
                    originalParents.Add(key, parent);
                    keySlots.Add(key, (menu, slot));
                    if (!firstKeys.ContainsKey(c)) firstKeys.Add(c, key);
                    if (c.type == Control.ControlType.SubMenu && c.subMenu && !openedBy.ContainsKey(c.subMenu)) openedBy.Add(c.subMenu, key);
                    if (c.type == Control.ControlType.SubMenu) Walk(c.subMenu, next, formerNext, active, depth + 1, key);
                }
                active.Remove(menu);
            }
            // The same array for both paths while no former page link lies above (Wanted, legacyPath).
            var top = Array.Empty<string>();
            Walk(root, top, top, new HashSet<VRCExpressionsMenu>(), 0);
            return keys.ToArray();
        }

        private static FavoriteMenuKey KeyOf(Control c, string[] path, int group) => new FavoriteMenuKey
        {
            path = path, type = c.type, value = c.value, sharedControl = group,
            parameter = c.parameter?.name ?? "",
            subParameters = (c.subParameters ?? Array.Empty<Control.Parameter>()).Select(p => p?.name ?? "").ToArray(),
        };

        private FavoriteMenuKey Match(FavoriteMenuKey saved, string title, FavoriteMenuBuilder.RepairTarget target, int index)
        {
            var current = FavoriteMenuKey.Resolve(Original, saved, out var match);
            if (match != FavoriteMenuMatch.Exact)
                report(title, FavoriteMenuBuilder.MatchDetail(match), match != FavoriteMenuMatch.Moved, target, index, saved, current);
            return current;
        }

        // ---------------------------------------------------------------- the copy

        internal string NameOf(Control original) => names.TryGetValue(original, out var label) ? label : original.name;

        private VRCExpressionsMenu Clone(VRCExpressionsMenu original)
        {
            if (!original) return null;
            if (copies.TryGetValue(original, out var existing)) return existing;
            var clone = Object.Instantiate(original);
            clone.name = original.name;
            clone.hideFlags = flags;
            copies.Add(original, clone);
            originalMenus.Add(clone, original);
            Created.Add(clone);
            clone.controls = new List<Control>();
            var controls = original.controls ?? new List<Control>();
            for (int slot = 0; slot < controls.Count; slot++)
            {
                var c = controls[slot];
                if (c == null) continue;
                bool isPage = IsOriginalPage(original, c);
                var copy = FavoriteMenuBuilder.Copy(c, isPage && pageLabel != null ? pageLabel : NameOf(c), Clone);
                if (!isPage && icons.TryGetValue(c, out var icon)) copy.icon = icon;
                clone.controls.Add(copy);
                if (isPage)
                {
                    PageLinks.Add(clone, copy);
                    OriginalLinks.Add(copy);
                }
                else
                {
                    OriginalControls.Add(copy);
                    controlCopies[c] = copy;
                    slotCopies[(original, slot)] = copy;
                    originalOf[copy] = c;
                }
            }
            return clone;
        }

        internal VRCExpressionsMenu NewMenu(string name)
        {
            var menu = FavoriteMenuBuilder.NewMenu(name, Created);
            menu.hideFlags = flags;
            return menu;
        }

        // The pages of a menu level, following its page links.
        internal IEnumerable<VRCExpressionsMenu> Pages(VRCExpressionsMenu first)
        {
            var seen = new HashSet<VRCExpressionsMenu>();
            for (var page = first; page && seen.Add(page); page = PageLinks.TryGetValue(page, out var link) ? link.subMenu : null)
                yield return page;
        }

        // Splits an overfull page into pages behind page links; returns the last page.
        internal VRCExpressionsMenu Paginate(VRCExpressionsMenu page)
        {
            int keep = VRCExpressionsMenu.MAX_CONTROLS - 1;
            while (page.controls.Count > VRCExpressionsMenu.MAX_CONTROLS)
            {
                var next = NewMenu(page.name + " (More)");
                next.controls.AddRange(page.controls.Skip(keep));
                page.controls.RemoveRange(keep, page.controls.Count - keep);
                var link = FavoriteMenuBuilder.Submenu(PageLabel, next);
                link.icon = moreIcon;
                page.controls.Add(link);
                PageLinks.Add(page, link);
                page = next;
            }
            return page;
        }

        // The page (1 = first) of a menu level that holds item; 0 when it is not there.
        internal int PageOf(VRCExpressionsMenu first, Control item)
        {
            int number = 1;
            foreach (var page in Pages(first))
            {
                if (page.controls.Contains(item)) return number;
                number++;
            }
            return 0;
        }

        // The page of each of the avatar's own items on a menu level.
        internal Dictionary<Control, int> OriginalPages(VRCExpressionsMenu first)
        {
            var result = new Dictionary<Control, int>();
            int number = 1;
            foreach (var page in Pages(first))
            {
                foreach (var control in page.controls)
                    if (OriginalControls.Contains(control)) result[control] = number;
                number++;
            }
            return result;
        }

        // Puts control at slot of the first page, pushing the rest along the pages; returns the last page.
        internal VRCExpressionsMenu InsertPinned(VRCExpressionsMenu first, int slot, Control control)
        {
            var page = first;
            page.controls.Insert(slot, control);
            int keep = VRCExpressionsMenu.MAX_CONTROLS - 1;
            // Ends on the level's last page: page links never lead back to a page before them (FindPageLinks).
            while (PageLinks.TryGetValue(page, out var link))
            {
                if (page.controls.Count > VRCExpressionsMenu.MAX_CONTROLS)
                {
                    int count = page.controls.Count - keep - 1;
                    link.subMenu.controls.InsertRange(0, page.controls.GetRange(keep, count));
                    page.controls.RemoveRange(keep, count);
                }
                page = link.subMenu;
            }
            return Paginate(page);
        }

        // ---------------------------------------------------------------- moves

        // Each item leaves its page for the end of its new menu; pages left with gaps are filled from the pages after them.
        // Rules with a place (MenuMoveRule.positioned) are only claimed here, in the same order, so the first rule for an
        // item wins whatever its kind; they move after the made folders exist (ApplyPositioned).
        private List<(int Index, MenuMoveRule Rule, FavoriteMenuKey Key)> ApplyMoves(IReadOnlyList<MenuMoveRule> moves)
        {
            var positioned = new List<(int Index, MenuMoveRule Rule, FavoriteMenuKey Key)>();
            if ((moves?.Count ?? 0) == 0) return positioned;
            var folders = new Dictionary<string, VRCExpressionsMenu>();
            // The top-level submenu of that name (as shown, so after renames), or a new one at the end of the top level.
            VRCExpressionsMenu Folder(string name)
            {
                if (folders.TryGetValue(name, out var folder)) return folder;
                var links = new HashSet<Control>(PageLinks.Values);
                var existing = Pages(Root).SelectMany(p => p.controls).FirstOrDefault(c =>
                    c != null && !links.Contains(c) && c.type == Control.ControlType.SubMenu && c.subMenu && c.name == name);
                if (existing != null) folder = existing.subMenu;
                else
                {
                    folder = NewMenu(name);
                    var last = Pages(Root).Last();
                    var control = FavoriteMenuBuilder.Submenu(name, folder);
                    last.controls.Add(control);
                    LegacyFolders.Add(control, name);
                    Paginate(last);
                }
                folders.Add(name, folder);
                return folder;
            }

            var moving = new HashSet<Control>();
            for (int i = 0; i < moves.Count; i++)
            {
                var rule = moves[i];
                if (rule?.source == null) continue;
                string title = $"이동 / {rule.source.DisplayPath}";
                var key = Match(rule.source, title, FavoriteMenuBuilder.RepairTarget.Move, i);
                if (key == null) continue;
                var original = OriginalItems[key];
                var copy = CopyOf(key, out var found) ? found : null;
                if (!moving.Add(copy ?? original))
                {
                    report(title, "같은 항목을 옮기는 설정이 앞에 있어 이 설정은 제외했습니다.", true,
                        FavoriteMenuBuilder.RepairTarget.Move, i, rule.source, key);
                    continue;
                }
                if (rule.positioned)
                {
                    positioned.Add((i, rule, key));
                    continue;
                }
                VRCExpressionsMenu target;
                string where;
                if (rule.Folder != null)
                {
                    where = $"최상위 ‘{rule.Folder}’ 폴더";
                    target = Folder(rule.Folder);
                }
                else if (rule.ToRoot)
                {
                    where = "최상위 메뉴";
                    target = Root;
                }
                else
                {
                    var destinationKey = Match(rule.destination, title + " · 옮길 위치", FavoriteMenuBuilder.RepairTarget.MoveDestination, i);
                    if (destinationKey == null) continue;
                    var destination = OriginalItems[destinationKey];
                    if (destination.type != Control.ControlType.SubMenu || !destination.subMenu)
                    {
                        report(title, "옮길 위치가 하위 메뉴가 아니라 옮기지 않았습니다.", true,
                            FavoriteMenuBuilder.RepairTarget.MoveDestination, i, rule.destination, destinationKey);
                        continue;
                    }
                    where = $"‘{NameOf(destination)}’";
                    target = Clone(destination.subMenu);
                }
                // Earlier moves only push items to later pages, so look from the original page on.
                var from = copy == null ? null : Pages(Clone(parentPages[key])).FirstOrDefault(p => p.controls.Contains(copy));
                if (from == null)
                {
                    report(title, "빌드 메뉴에서 이 항목의 자리를 찾지 못해 옮기지 않았습니다.", true,
                        FavoriteMenuBuilder.RepairTarget.None, i, null, null);
                    continue;
                }
                if (copy.type == Control.ControlType.SubMenu && copy.subMenu &&
                    FavoriteMenuBuilder.Reaches(copy.subMenu, target, null, new HashSet<VRCExpressionsMenu>()))
                {
                    report(title, $"옮길 위치({where})가 이 메뉴 자신이거나 그 안에 있어 옮길 수 없습니다.", true,
                        FavoriteMenuBuilder.RepairTarget.MoveDestination, i, rule.destination, null);
                    continue;
                }
                if (Pages(target).Contains(from))
                {
                    report(title, $"이미 {where}에 있어 옮기지 않았습니다.", false, FavoriteMenuBuilder.RepairTarget.None, i, null, null);
                    continue;
                }
                from.controls.Remove(copy);
                var end = Pages(target).Last();
                end.controls.Add(copy);
                Paginate(end);
                MovedControls.Add(copy);
            }
            return positioned;
        }

        // ---------------------------------------------------------------- made folders and moves to a place

        // Something to put in its place: a made folder, or a built item moved by a rule with a place.
        private sealed class Placing
        {
            internal int Order, Index;
            internal string Title;
            internal Control Item;
            // The menu it opens (a submenu or made folder), to keep it out of itself.
            internal VRCExpressionsMenu Inner;
            internal VRCExpressionsMenu Target;
            internal FavoriteMenuKey Before;
            internal string BeforeFolder;
            // The move rule; null for a made folder.
            internal MenuMoveRule Move;
        }

        // Every folder's menu first, so folders can go into each other in any order and moves can target them. Their
        // places are worked out with the moves (Place).
        private List<Placing> MakeFolders(IReadOnlyList<MenuFolderRule> folders)
        {
            var made = new List<(int Index, MenuFolderRule Rule, Control Control, VRCExpressionsMenu Menu)>();
            for (int i = 0; i < (folders?.Count ?? 0); i++)
            {
                var rule = folders[i];
                if (rule == null || string.IsNullOrEmpty(rule.id)) continue;
                if (Folders.ContainsKey(rule.id))
                {
                    report($"새 폴더 / {rule.DisplayName}", "같은 ID의 폴더가 앞에 있어 이 폴더는 만들지 않았습니다.", true,
                        FavoriteMenuBuilder.RepairTarget.None, i, null, null);
                    continue;
                }
                var menu = NewMenu(rule.DisplayName);
                var control = FavoriteMenuBuilder.Submenu(rule.DisplayName, menu);
                control.icon = rule.icon;
                Folders.Add(rule.id, (control, menu));
                folderIds.Add(control, rule.id);
                made.Add((i, rule, control, menu));
            }
            var placings = new List<Placing>();
            foreach (var (i, rule, control, menu) in made)
            {
                string title = $"새 폴더 / {rule.DisplayName}";
                var level = LevelOf(rule.parent, rule.parentFolder, title, "넣을 위치", FavoriteMenuBuilder.RepairTarget.None, i);
                bool found = level;
                if (!found) report(title, "넣을 메뉴를 찾지 못해 최상위 끝에 놓았습니다.", true, FavoriteMenuBuilder.RepairTarget.None, i, null, null);
                placings.Add(new Placing
                {
                    Order = i, Index = i, Title = title, Item = control, Inner = menu, Target = found ? level : Root,
                    Before = found ? rule.before : null, BeforeFolder = found ? rule.beforeFolder : null,
                });
            }
            return placings;
        }

        // The menu level a rule puts something into: a made folder, a built submenu, or the top level when neither is
        // set. Null (reported) when the saved place is gone or is not a submenu.
        private VRCExpressionsMenu LevelOf(FavoriteMenuKey submenu, string folder, string title, string place,
            FavoriteMenuBuilder.RepairTarget target, int index)
        {
            if (!string.IsNullOrEmpty(folder))
            {
                if (Folders.TryGetValue(folder, out var made)) return made.Menu;
                report(title, $"{place}의 새 폴더를 찾을 수 없습니다.", true, FavoriteMenuBuilder.RepairTarget.None, index, null, null);
                return null;
            }
            if (submenu == null || submenu.IsEmpty) return Root;
            var key = Match(submenu, $"{title} · {place}", target, index);
            if (key == null) return null;
            var destination = OriginalItems[key];
            if (destination.type != Control.ControlType.SubMenu || !destination.subMenu)
            {
                report(title, $"{place}가 하위 메뉴가 아닙니다.", true, target, index, submenu, key);
                return null;
            }
            return Clone(destination.subMenu);
        }

        // The moves with a place, after the made folders (they go first, each kind in rule order).
        private void ApplyPositioned(List<Placing> folders, List<(int Index, MenuMoveRule Rule, FavoriteMenuKey Key)> rules)
        {
            var placings = new List<Placing>(folders);
            foreach (var (i, rule, key) in rules)
            {
                string title = $"이동 / {rule.source.DisplayPath}";
                var target = LevelOf(rule.destination, rule.destinationFolder, title, "옮길 위치",
                    FavoriteMenuBuilder.RepairTarget.MoveDestination, i);
                if (!target) continue;
                if (!CopyOf(key, out var copy))
                {
                    report(title, "빌드 메뉴에서 이 항목의 자리를 찾지 못해 옮기지 않았습니다.", true,
                        FavoriteMenuBuilder.RepairTarget.None, i, null, null);
                    continue;
                }
                placings.Add(new Placing
                {
                    Order = folders.Count + i, Index = i, Title = title, Item = copy, Target = target, Move = rule,
                    Inner = copy.type == Control.ControlType.SubMenu ? copy.subMenu : null,
                    Before = rule.before, BeforeFolder = rule.beforeFolder,
                });
            }
            if (placings.Count > 0) PlaceAll(placings);
        }

        // Puts everything in its place, in order, except that one placed before something not yet placed (wherever that
        // goes) waits for it: it then sits before it, or at the end when it went elsewhere. One that would land inside
        // itself waits until something else lands (a later move may take its child out); when nothing else can, a move
        // is refused and a folder goes to the end of the top level. Items that wait on each other go to the end.
        private void PlaceAll(List<Placing> placings)
        {
            var pending = placings.OrderBy(p => p.Order).ToList();
            var blocked = new List<Placing>();
            bool Unplaced(Placing self, Control anchor) =>
                anchor != null && pending.Concat(blocked).Any(o => o != self && o.Item == anchor);
            while (pending.Count > 0 || blocked.Count > 0)
            {
                var next = pending.FirstOrDefault(p => !Unplaced(p, AnchorOf(p.Before, p.BeforeFolder)));
                bool waiting = false;
                if (next == null)
                {
                    if (blocked.Count > 0)
                    {
                        // Nothing else can land, so these never can: refuse them, and the items waiting on them go on.
                        foreach (var stuck in blocked)
                        {
                            if (stuck.Move != null)
                            {
                                report(stuck.Title, "옮길 위치가 이 메뉴 자신이거나 그 안에 있어 옮길 수 없습니다.", true,
                                    FavoriteMenuBuilder.RepairTarget.MoveDestination, stuck.Index, stuck.Move.destination, null);
                                continue;
                            }
                            report(stuck.Title, "이 폴더 자신이나 그 안의 폴더에는 넣을 수 없어 최상위 끝에 놓았습니다.", true,
                                FavoriteMenuBuilder.RepairTarget.None, stuck.Index, null, null);
                            Place(stuck.Item, Root, null, null, stuck.Title, stuck.Index);
                        }
                        blocked.Clear();
                        continue;
                    }
                    next = pending[0];
                    waiting = true;
                }
                pending.Remove(next);
                if (next.Inner && FavoriteMenuBuilder.Reaches(next.Inner, next.Target, null, new HashSet<VRCExpressionsMenu>()))
                {
                    blocked.Add(next);
                    continue;
                }
                if (next.Move != null)
                {
                    var from = Created.FirstOrDefault(m => m && m.controls != null && m.controls.Contains(next.Item));
                    if (from == null)
                    {
                        report(next.Title, "빌드 메뉴에서 이 항목의 자리를 찾지 못해 옮기지 않았습니다.", true,
                            FavoriteMenuBuilder.RepairTarget.None, next.Index, null, null);
                        continue;
                    }
                    from.controls.Remove(next.Item);
                }
                if (waiting)
                    report(next.Title, "앞에 둘 항목도 이 항목 앞으로 옮기도록 되어 있어 맨 끝에 놓았습니다.", false,
                        FavoriteMenuBuilder.RepairTarget.None, next.Index, null, null);
                Place(next.Item, next.Target, waiting ? null : next.Before, waiting ? null : next.BeforeFolder, next.Title, next.Index);
                if (next.Move != null) MovedControls.Add(next.Item);
                if (blocked.Count > 0)
                {
                    pending.AddRange(blocked);
                    pending.Sort((a, b) => a.Order.CompareTo(b.Order));
                    blocked.Clear();
                }
            }
        }

        // A folder this organizer made. It never counts as a menu of the same name as a favorites menu: the user named
        // it, and an empty one leaves the build.
        internal bool IsMadeFolder(Control c) => c != null && folderIds.ContainsKey(c);

        // The id of a folder this organizer made, or null.
        internal string FolderIdOf(Control c) => c != null && folderIds.TryGetValue(c, out var id) ? id : null;

        // The avatar's own key of a copied item (the first, when it is reached by two ways); null for anything made here.
        internal FavoriteMenuKey OriginalKeyOf(Control copy) =>
            copy == null ? null : copyKeys.TryGetValue(copy, out var slotKey) ? slotKey :
            originalOf.TryGetValue(copy, out var original) && firstKeys.TryGetValue(original, out var key) ? key : null;

        // The copy of the row a key names.
        private bool CopyOf(FavoriteMenuKey key, out Control copy)
        {
            copy = null;
            if (keySlots.TryGetValue(key, out var slot) && slotCopies.TryGetValue(slot, out copy)) return true;
            return OriginalItems.TryGetValue(key, out var original) && controlCopies.TryGetValue(original, out copy);
        }

        // The icon a copied item had in the avatar's menu, before an icon rule.
        internal Texture2D OriginalIconOf(Control copy) => copy != null && originalOf.TryGetValue(copy, out var original) ? original.icon : null;

        // The name a copied item had in the avatar's menu, before "이름 변경"; null for anything made here.
        internal string OriginalNameOf(Control copy) => copy != null && originalOf.TryGetValue(copy, out var original) ? original.name ?? "" : null;

        // The key of the avatar's submenu that opens a copied menu (its first page), or null for a menu made here.
        internal FavoriteMenuKey SubmenuKeyOf(VRCExpressionsMenu copy) =>
            copy && originalMenus.TryGetValue(copy, out var original) && openedBy.TryGetValue(original, out var key) ? key : null;

        // Where one of the avatar's items was in its menu: the submenu it was in (null at the top level), and the item after
        // it there (null when it was last).
        internal FavoriteMenuKey OriginalParentOf(FavoriteMenuKey key) => key != null && originalParents.TryGetValue(key, out var parent) ? parent : null;

        internal FavoriteMenuKey OriginalNextOf(FavoriteMenuKey key)
        {
            if (key == null || !originalParents.TryGetValue(key, out var parent)) return null;
            for (int i = Array.IndexOf(Original, key) + 1; i > 0 && i < Original.Length; i++)
                if (originalParents[Original[i]] == parent) return Original[i];
            return null;
        }

        // The organized menu's key of an item (what favorites point at), or null for one made after organizing.
        internal FavoriteMenuKey OrganizedKeyOf(Control c) => c != null && organizedKeys.TryGetValue(c, out var key) ? key : null;

        // The organized menu's key of the submenu that opens a level (any of its pages), or null.
        internal FavoriteMenuKey OrganizedKeyOfMenu(VRCExpressionsMenu page)
        {
            var first = FirstPage(page);
            return organizedKeys.FirstOrDefault(p => p.Key.type == Control.ControlType.SubMenu && p.Key.subMenu &&
                                                     FirstPage(p.Key.subMenu) == first).Value;
        }

        // The first page of the level a page belongs to.
        internal VRCExpressionsMenu FirstPage(VRCExpressionsMenu page)
        {
            var linkedFrom = new Dictionary<VRCExpressionsMenu, VRCExpressionsMenu>();
            foreach (var pair in PageLinks) if (pair.Value.subMenu) linkedFrom[pair.Value.subMenu] = pair.Key;
            var seen = new HashSet<VRCExpressionsMenu>();
            while (page && seen.Add(page) && linkedFrom.TryGetValue(page, out var before)) page = before;
            return page;
        }

        // The control a rule's place is before: a made folder, or the copy of a built item. Null when it is gone.
        private Control AnchorOf(FavoriteMenuKey before, string beforeFolder)
        {
            if (!string.IsNullOrEmpty(beforeFolder)) return Folders.TryGetValue(beforeFolder, out var made) ? made.Control : null;
            var key = before == null || before.IsEmpty ? null : FavoriteMenuKey.Resolve(Original, before);
            return key != null && CopyOf(key, out var copy) ? copy : null;
        }

        // Puts item into a level, before its anchor or at the end, and lays the level's pages out again. An anchor that
        // is not in that level (gone, or in another menu) is noted and the item goes to the end.
        private void Place(Control item, VRCExpressionsMenu level, FavoriteMenuKey before, string beforeFolder, string title, int index)
        {
            var items = Items(level);
            int at = items.Count;
            if (!string.IsNullOrEmpty(beforeFolder) || !(before?.IsEmpty ?? true))
            {
                var anchor = AnchorOf(before, beforeFolder);
                int found = anchor == null ? -1 : items.IndexOf(anchor);
                if (found >= 0) at = found;
                else if (anchor == null)
                    report(title, "앞에 둘 항목을 찾을 수 없어 맨 끝에 놓았습니다. 빌드 결과 탭에서 다시 놓으면 고쳐져요.", true,
                        FavoriteMenuBuilder.RepairTarget.None, index, null, null);
                else
                {
                    bool elsewhere = Created.Any(m => m && m.controls != null && m.controls.Contains(anchor));
                    report(title, elsewhere ? "앞에 둘 항목이 다른 메뉴에 있어 맨 끝에 놓았습니다." : "앞에 둘 항목이 이 메뉴에 없어 맨 끝에 놓았습니다.",
                        false, FavoriteMenuBuilder.RepairTarget.None, index, null, null);
                }
            }
            items.Insert(at, item);
            Relayout(level, items);
        }

        // A level's items over all its pages, without the page links.
        private List<Control> Items(VRCExpressionsMenu first)
        {
            var links = new HashSet<Control>(PageLinks.Values);
            return Pages(first).SelectMany(p => p.controls).Where(c => c != null && !links.Contains(c)).ToList();
        }

        // Lays a level's items out over its pages again: seven and a page link while more follow, up to eight on the last
        // page. The level keeps its page menus and links in order; pages it no longer needs are emptied and unlinked.
        private void Relayout(VRCExpressionsMenu first, List<Control> items)
        {
            var pages = Pages(first).ToList();
            int max = VRCExpressionsMenu.MAX_CONTROLS, keep = max - 1;
            for (int p = 0, at = 0; ; p++)
            {
                var page = pages[p];
                int left = items.Count - at;
                if (left <= max)
                {
                    page.controls = items.GetRange(at, left);
                    PageLinks.Remove(page);
                    foreach (var unused in pages.Skip(p + 1))
                    {
                        unused.controls = new List<Control>();
                        PageLinks.Remove(unused);
                    }
                    return;
                }
                if (p + 1 == pages.Count) pages.Add(NewMenu(first.name + " (More)"));
                if (!PageLinks.TryGetValue(page, out var link))
                {
                    link = FavoriteMenuBuilder.Submenu(PageLabel, null);
                    link.icon = moreIcon;
                    PageLinks.Add(page, link);
                }
                link.subMenu = pages[p + 1];
                page.controls = items.GetRange(at, keep);
                page.controls.Add(link);
                at += keep;
            }
        }

        internal const string EmptyFolderDropped = "빈 폴더라 빌드에서 뺐습니다.";

        // Made folders that hold nothing (in the end: after the favorites menus went in) leave the menu, and so does a
        // folder that held only such folders. Where each was is kept in Dropped, for the window to show.
        internal void DropEmptyFolders()
        {
            var links = new HashSet<Control>(PageLinks.Values);
            for (bool changed = true; changed;)
            {
                changed = false;
                foreach (var pair in Folders)
                {
                    if (droppedFolders.Contains(pair.Key) ||
                        Pages(pair.Value.Menu).SelectMany(p => p.controls).Any(c => c != null && !links.Contains(c)))
                        continue;
                    var page = Created.FirstOrDefault(m => m && m.controls != null && m.controls.Contains(pair.Value.Control));
                    if (page)
                    {
                        var level = FirstPage(page);
                        var items = Items(level);
                        int at = items.IndexOf(pair.Value.Control);
                        Dropped.Add((pair.Key, level, at >= 0 && at + 1 < items.Count ? items[at + 1] : null));
                        page.controls.Remove(pair.Value.Control);
                    }
                    droppedFolders.Add(pair.Key);
                    changed = true;
                    report($"새 폴더 / {pair.Value.Control.name}", EmptyFolderDropped, true,
                        FavoriteMenuBuilder.RepairTarget.None, -1, null, null);
                }
            }
            if (droppedFolders.Count > 0) CloseGaps();
        }

        // ---------------------------------------------------------------- hides

        private void FindHidden(IReadOnlyList<MenuHideRule> hides)
        {
            for (int i = 0; i < (hides?.Count ?? 0); i++)
            {
                var rule = hides[i];
                if (rule?.source == null) continue;
                string title = $"숨기기 / {rule.source.DisplayPath}";
                var key = Match(rule.source, title, FavoriteMenuBuilder.RepairTarget.Hide, i);
                if (key == null) continue;
                if (CopyOf(key, out var copy)) HiddenControls.Add(copy);
                else report(title, "빌드 메뉴에서 이 항목의 자리를 찾지 못해 숨기지 않았습니다.", true,
                    FavoriteMenuBuilder.RepairTarget.None, i, null, null);
            }
        }

        // Each hidden item leaves the page it ended up on after the moves; CloseGaps fills the gap.
        private void RemoveHidden()
        {
            foreach (var copy in HiddenControls)
                Created.FirstOrDefault(m => m && m.controls != null && m.controls.Contains(copy))?.controls.Remove(copy);
        }

        // Lays every level with pages out again once items left it, as Relayout does: the gaps close, and a last page
        // that now fits in the page link's slot folds back (pulling items up alone would leave one item on a page of its
        // own behind a full page and its link).
        private void CloseGaps()
        {
            var linked = new HashSet<VRCExpressionsMenu>(PageLinks.Values.Select(l => l.subMenu));
            foreach (var first in Created.Where(m => m && PageLinks.ContainsKey(m) && !linked.Contains(m)).ToArray())
                Relayout(first, Items(first));
        }

        // ---------------------------------------------------------------- the organized menu

        private FavoriteMenuKey[] WalkOrganized()
        {
            var keys = new List<FavoriteMenuKey>();
            var groups = new Dictionary<Control, int>();
            var listed = new HashSet<VRCExpressionsMenu>();
            void Walk(VRCExpressionsMenu menu, string[] path, string[] former, HashSet<VRCExpressionsMenu> active, int depth, bool hidden)
            {
                if (!menu || menu.controls == null || depth > 64 || active.Contains(menu)) return;
                // As in WalkOriginal (RowLimit, FormerPageLinks).
                bool guided = !listed.Add(menu) && keys.Count >= RowLimit;
                if (guided && wanted.Count == 0)
                {
                    rowsCut = true;
                    return;
                }
                active.Add(menu);
                foreach (var c in menu.controls)
                {
                    if (c == null) continue;
                    if (PageLinks.TryGetValue(menu, out var link) && link == c)
                    {
                        Walk(c.subMenu, path, former, active, depth, hidden);
                        continue;
                    }
                    bool known = originalOf.TryGetValue(c, out var original);
                    string name = known ? original.name ?? "" : c.name ?? "";
                    var next = path.Concat(new[] { name }).ToArray();
                    bool wasPage = known && formerLinkControls.Contains(original);
                    var formerNext = wasPage ? former : former == path ? next : former.Concat(new[] { name }).ToArray();
                    if (guided && !Wanted(next, formerNext))
                    {
                        rowsCut = true;
                        continue;
                    }
                    if (!groups.TryGetValue(c, out int group)) groups.Add(c, group = groups.Count + 1);
                    var key = KeyOf(c, next, group);
                    if (!wasPage && formerNext != next) key.legacyPath = formerNext;
                    key.displayName = c.name ?? "";
                    key.hidden = hidden || HiddenControls.Contains(c);
                    key.createdFolder = folderIds.TryGetValue(c, out var folder) ? folder : null;
                    OrganizedItems.Add(key, c);
                    if (!organizedKeys.ContainsKey(c)) organizedKeys.Add(c, key);
                    keys.Add(key);
                    if (c.type == Control.ControlType.SubMenu) Walk(c.subMenu, next, formerNext, active, depth + 1, key.hidden);
                }
                active.Remove(menu);
            }
            var top = Array.Empty<string>();
            Walk(Root, top, top, new HashSet<VRCExpressionsMenu>(), 0, false);
            return keys.ToArray();
        }

        // A copy of a menu tree kept apart from the build's assets (so the window can organize it again later), taken
        // while the build's own menu and icons are there. links: its page links (FindPageLinks), judged on the build's
        // menu and kept with the copy, which could not be judged the same way once it lost a null control or an icon.
        // Icons that only the build has (buildOnly: its temporary assets) are copied, so they are still shown after
        // the read.
        internal static MenuSnapshot Snapshot(VRCExpressionsMenu root, ICollection<(VRCExpressionsMenu, Control)> links,
            Func<Texture2D, bool> buildOnly)
        {
            var result = new MenuSnapshot();
            var map = new Dictionary<VRCExpressionsMenu, VRCExpressionsMenu>();
            // One copy per control, so a control two menus share stays one control (the organizer treats it as one).
            var controls = new Dictionary<Control, Control>();
            var icons = new Dictionary<Texture2D, Texture2D>();
            Texture2D Icon(Texture2D icon)
            {
                if (!icon || buildOnly == null || !buildOnly(icon)) return icon;
                if (icons.TryGetValue(icon, out var kept)) return kept;
                kept = CopyIcon(icon);
                if (kept) result.Icons.Add(kept);
                else kept = icon;
                icons.Add(icon, kept);
                return kept;
            }
            VRCExpressionsMenu Copy(VRCExpressionsMenu menu)
            {
                if (!menu) return null;
                if (map.TryGetValue(menu, out var existing)) return existing;
                var copy = ScriptableObject.CreateInstance<VRCExpressionsMenu>();
                copy.name = menu.name;
                copy.hideFlags = HideFlags.HideAndDontSave;
                map.Add(menu, copy);
                result.Menus.Add(copy);
                copy.controls = new List<Control>();
                foreach (var c in menu.controls ?? new List<Control>())
                {
                    if (c == null) continue;
                    if (!controls.TryGetValue(c, out var control))
                    {
                        controls.Add(c, control = FavoriteMenuBuilder.Copy(c, c.name, Copy));
                        control.icon = Icon(c.icon);
                        control.labels = control.labels.Select(l => new Control.Label { name = l.name, icon = Icon(l.icon) }).ToArray();
                    }
                    if (links.Contains((menu, c))) result.PageLinks.Add((copy, control));
                    copy.controls.Add(control);
                }
                return copy;
            }
            try { result.Root = Copy(root); }
            catch
            {
                result.Destroy();
                throw;
            }
            return result;
        }

        // An in-memory copy of an icon, or null when it cannot be copied (a texture that is not readable, with no
        // graphics device to draw it).
        internal static Texture2D CopyIcon(Texture2D source)
        {
            Texture2D copy = null;
            if (source.isReadable) copy = Object.Instantiate(source);
            else if (SystemInfo.graphicsDeviceType != GraphicsDeviceType.Null)
            {
                int width = Mathf.Max(1, source.width), height = Mathf.Max(1, source.height);
                var target = RenderTexture.GetTemporary(width, height, 0, RenderTextureFormat.ARGB32, RenderTextureReadWrite.sRGB);
                var active = RenderTexture.active;
                try
                {
                    Graphics.Blit(source, target);
                    RenderTexture.active = target;
                    copy = new Texture2D(width, height, TextureFormat.RGBA32, false);
                    copy.ReadPixels(new Rect(0, 0, width, height), 0, 0);
                    copy.Apply();
                }
                catch
                {
                    if (copy) Object.DestroyImmediate(copy);
                    throw;
                }
                finally
                {
                    RenderTexture.active = active;
                    RenderTexture.ReleaseTemporary(target);
                }
            }
            if (!copy) return null;
            copy.name = source.name;
            copy.hideFlags = HideFlags.HideAndDontSave;
            return copy;
        }
    }

    // A read's copy of the avatar's finished menu (MenuOrganizer.Snapshot), owned by whoever keeps it: the window until
    // the next read, the build's scan until the window takes it. Destroy frees its menus and icon copies.
    internal sealed class MenuSnapshot
    {
        internal VRCExpressionsMenu Root;
        internal readonly List<VRCExpressionsMenu> Menus = new List<VRCExpressionsMenu>();
        internal readonly List<Texture2D> Icons = new List<Texture2D>();
        // The copies of the controls that were page links when the menu was read, with the page they ended.
        internal readonly HashSet<(VRCExpressionsMenu, Control)> PageLinks = new HashSet<(VRCExpressionsMenu, Control)>();

        internal void Destroy()
        {
            foreach (var menu in Menus) if (menu) Object.DestroyImmediate(menu);
            foreach (var icon in Icons) if (icon) Object.DestroyImmediate(icon);
            Menus.Clear();
            Icons.Clear();
            PageLinks.Clear();
            Root = null;
        }
    }
}
#endif
