#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;
using VRC.SDK3.Avatars.Components;

namespace AvatarMenuTools
{
    // The component's inspector: how the tool is used, the button that opens the window on this avatar, then the
    // settings as Unity draws them by default (they are edited in the window).
    [CustomEditor(typeof(AvatarCustomizer))]
    [CanEditMultipleObjects]
    internal sealed class AvatarCustomizerEditor : UnityEditor.Editor
    {
        public override void OnInspectorGUI()
        {
            AvatarCustomizerUsage.Draw(AvatarCustomizerUsage.InspectorKey);
            string problem = OpenProblem(out var descriptor);
            using (new EditorGUI.DisabledScope(problem != null))
                if (GUILayout.Button(new GUIContent("Avatar Customizer 창 열기", problem ?? "이 아바타를 골라 Avatar Customizer 창을 열어요.")))
                    AvatarCustomizerWindow.OpenFor(descriptor);
            // A disabled button shows no tooltip: the reason is a line of its own.
            if (problem != null) EditorGUILayout.LabelField(problem, EditorStyles.wordWrappedMiniLabel);
            EditorGUILayout.Space(4);
            DrawDefaultInspector();
        }

        // Why the window cannot open on this component's avatar, or null. The build reads the component on the avatar
        // root only (FavoriteMenuBuilder.ReadSettings), and the window works on avatars in an open scene.
        internal string OpenProblem(out VRCAvatarDescriptor descriptor)
        {
            descriptor = null;
            if (targets.Length != 1) return "여러 개를 고른 동안에는 창을 열 수 없어요. 하나만 골라 주세요.";
            var config = (AvatarCustomizer)target;
            descriptor = config ? config.GetComponent<VRCAvatarDescriptor>() : null;
            if (!descriptor)
                return "⚠ Avatar Customizer는 아바타 루트(VRC Avatar Descriptor가 있는 오브젝트)에 있을 때만 빌드에 적용돼요. " +
                       "이 컴포넌트를 지우고 아바타 루트에 붙여 주세요.";
            if (!AvatarCustomizerWindow.IsSceneAvatar(descriptor))
                return "프리팹 에셋이나 프리팹 편집 화면에서는 창을 열 수 없어요. 씬(Hierarchy)에 놓인 아바타에서 열어 주세요.";
            return null;
        }
    }
}
#endif
