#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;

namespace AvatarMenuTools
{
    // How the tool is used, drawn first in the component's inspector and under the window's top row
    // (design-system/unityvpm/MASTER.md, "Usage guide"). The same steps, word for word, are the "사용 방법" list of
    // README_KO.txt (CustomizerTests checks it), and the public guide at Url walks through them with the details.
    // The steps give the path most people take (the build-result tab); the other tabs are recipes in the guide.
    internal static class AvatarCustomizerUsage
    {
        internal static readonly string[] Steps =
        {
            "Hierarchy에서 아바타를 고르고 상단 메뉴 NXYUI › Avatar Customizer를 열어요. 설정은 아바타 루트의 Avatar Customizer 컴포넌트에 저장돼요.",
            "‘빌드 메뉴 읽기’를 눌러 아바타에서 실제로 만들어질 메뉴를 읽어요. 옷이나 다른 도구의 메뉴를 바꾼 뒤에도 다시 눌러요.",
            "‘빌드 결과’ 탭에서 완성될 메뉴를 봐요. 하위 메뉴는 ‘열기’로 들어가고, 줄을 누르면 오른쪽 ‘선택한 항목’에 자세한 내용이 나와요.",
            "줄을 끌어 다른 줄 위·아래에 놓으면 그 자리로, 하위 메뉴 줄 가운데에 놓으면 그 안으로 옮겨져요. 편집은 하나씩 Ctrl+Z로 되돌릴 수 있어요.",
            "이름은 ‘선택한 항목’ 맨 위 칸에 적고 Enter, 필요 없는 항목은 ‘숨기기’를 눌러요. 이런 정리는 ‘원본 메뉴 정리’ 탭에도 규칙으로 보여요.",
            "자주 쓰는 항목은 오른쪽 클릭 › ‘즐겨찾기에 추가…’로 즐겨찾기 메뉴에 모아요. 원본은 제자리에 남아요(즐겨찾기 메뉴로 끌어다 놓으면 원래 자리에서는 숨겨져요). 즐겨찾기는 ‘즐겨찾기 편집’ 탭에도 보여요.",
            "‘검토’ 탭의 ⚠ 경고를 확인하고 씬을 저장한 뒤 평소처럼 업로드해요. 적용 버튼은 없고, 빌드할 때 아바타의 빌드용 사본에만 적용돼요.",
        };

        internal const string Url = "https://github.com/NXYUI/UnityVPM-pages/blob/main/packages/dev.nxyui.avatar-customizer/README.md";

        // One open state per surface, kept on this computer: closed until the user opens it (only its one line shows).
        internal const string InspectorKey = "NXYUI.AvatarCustomizer.Usage.Inspector";
        internal const string WindowKey = "NXYUI.AvatarCustomizer.Usage.Window";

        // The foldout and, while it is open, the steps with the link to the guide. Nothing in it depends on the tool's
        // state, so every pass of a frame draws the same controls.
        internal static void Draw(string key) => Show(key, 0f);

        // In a window: the open list takes at most `room` and scrolls in its frame past that, so the columns below keep
        // the height they need at the window's minimum size.
        internal static void DrawInWindow(string key, float room) => Show(key, room);

        private static Vector2 scroll;

        // How tall the steps are at the width they get (the view's, less the frame and a scroll bar). The same in the
        // Layout and the Repaint pass of a frame.
        private static float StepsHeight()
        {
            float width = Mathf.Max(120f, EditorGUIUtility.currentViewWidth - 40f), height = 0f;
            for (int i = 0; i < Steps.Length; i++)
                height += EditorStyles.wordWrappedLabel.CalcHeight(new GUIContent($"{i + 1}. {Steps[i]}"), width) + 2f;
            return height;
        }

        private static void Show(string key, float room)
        {
            bool open = EditorPrefs.GetBool(key, false);
            bool next = EditorGUILayout.Foldout(open, "사용 방법", true);
            if (next != open)
            {
                EditorPrefs.SetBool(key, next);
                // What follows differs from what Layout measured.
                GUIUtility.ExitGUI();
            }
            if (!open) return;
            using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
            {
                // Taller than the room it may take (a low window): the steps scroll inside the frame.
                bool scrolls = room > 0f && StepsHeight() > room;
                if (scrolls) scroll = EditorGUILayout.BeginScrollView(scroll, GUILayout.Height(room));
                for (int i = 0; i < Steps.Length; i++)
                    EditorGUILayout.LabelField($"{i + 1}. {Steps[i]}", EditorStyles.wordWrappedLabel);
                if (scrolls) EditorGUILayout.EndScrollView();
                using (new EditorGUILayout.HorizontalScope())
                {
                    if (GUILayout.Button(new GUIContent("자세한 설명 열기", Url), EditorStyles.miniButton, GUILayout.ExpandWidth(false)))
                        Application.OpenURL(Url);
                    GUILayout.Label("패키지 폴더의 README_KO.txt에도 있어요.", EditorStyles.miniLabel);
                }
            }
        }
    }
}
#endif
