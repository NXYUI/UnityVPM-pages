#if UNITY_EDITOR
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using nadena.dev.ndmf;
using nadena.dev.ndmf.platform;
using UnityEditor;
using UnityEngine;
using VRC.SDK3.Avatars.Components;
using VRC.SDK3.Avatars.ScriptableObjects;
using Control = VRC.SDK3.Avatars.ScriptableObjects.VRCExpressionsMenu.Control;
using Object = UnityEngine.Object;

[assembly: ExportsPlugin(typeof(AvatarMenuTools.FavoriteMenuPlugin))]

namespace AvatarMenuTools
{
    public sealed class FavoriteMenuPlugin : Plugin<FavoriteMenuPlugin>
    {
        public override string QualifiedName => "dev.nxyui.avatar-customizer";
        public override string DisplayName => "Avatar Customizer";

        protected override void Configure()
        {
            InPhase(BuildPhase.Resolving).Run("Read avatar menu settings", FavoriteMenuBuilder.ReadSettings);
            InPhase(BuildPhase.Generating)
                .BeforePlugin("nadena.dev.modular-avatar")
                .Run("Generate blendshape controls", BlendshapeControlBuilder.Generate);
            InPhase(BuildPhase.PlatformFinish)
                .AfterPlugin("nadena.dev.modular-avatar")
                .Run("Apply menu names and favorites", FavoriteMenuBuilder.Build);
        }
    }

    internal static class FavoriteMenuBuilder
    {
        // Modular Avatar names its overflow link "More" and gives it Runtime/Icons/Icon_More_A.png (MenuInstallHook).
        // Find the icon by GUID first, so a moved file still matches.
        private const string MoreIconGuid = "2509fbb49062a464dbb0843b7c4f59d8";
        private const string MoreIconPath = "Packages/nadena.dev.modular-avatar/Runtime/Icons/Icon_More_A.png";
        // The window's reads build into a folder with this name (deleted afterwards).
        internal const string ScanFolderPrefix = "__AvatarCustomizerScan_";

        internal static Texture2D LoadMoreIcon()
        {
            var path = AssetDatabase.GUIDToAssetPath(MoreIconGuid);
            var icon = string.IsNullOrEmpty(path) ? null : AssetDatabase.LoadAssetAtPath<Texture2D>(path);
            return icon ? icon : AssetDatabase.LoadAssetAtPath<Texture2D>(MoreIconPath);
        }

        // Whether a control looks as the avatar's tools make the link to the rest of a full page. Modular Avatar: "More"
        // with its own icon (MenuInstallHook.SplitMenu; no icon when the file cannot be loaded, here as there). VRCFury,
        // on an avatar that has it: next (VrcFury.NextLink). Both signals are asked for: until 2.8.2 the name alone was
        // enough, which took a submenu the user had named "More" for a page and laid its items out with the page before.
        internal static bool IsGeneratedLink(Control c, Texture2D moreIcon, PageLinkLook next) =>
            (c.name == "More" && c.icon == moreIcon) || (next != null && c.name == next.Name && next.Shows(c.icon));

        // A texture that goes away with a read's build: never saved, or saved into the read's temporary folder.
        internal static bool BuildOnly(Texture2D texture) =>
            !EditorUtility.IsPersistent(texture) ||
            AssetDatabase.GetAssetPath(texture).StartsWith("Assets/" + ScanFolderPrefix, StringComparison.Ordinal);

        internal sealed class Scan : IDisposable
        {
            internal readonly GameObject Avatar;
            internal FavoriteMenuKey[] Menu;
            // Expression parameter defaults before this tool changes any, by parameter name.
            internal Dictionary<string, float> Defaults;
            // Expression parameter types (MenuComposer.ParameterTypes), so the window can work out defaults like the build.
            internal Dictionary<string, VRCExpressionParameters.ValueType> ParameterTypes;
            internal string Result;
            internal bool HasWarnings;
            internal readonly List<Issue> Issues = new List<Issue>();
            // The favorites menus this build made, so the review can point them out.
            internal readonly HashSet<VRCExpressionsMenu> FavoriteMenus = new HashSet<VRCExpressionsMenu>();
            // The menu after "원본 메뉴 정리" (renames, moves, hidden items marked): what the favorites tab picks from.
            internal FavoriteMenuKey[] Organized;
            // Each blendshape control the menus use, by id: why the build left it out, or null when it was built. The
            // window checks the scene and can tell when the build saw it differently.
            internal Dictionary<string, string> Shapes = new Dictionary<string, string>();
            // What the built FX layer's toggles turn on (ToggleTargets), by the objects' paths in the avatar before the
            // build (Paths, taken when the read starts).
            internal ToggleTargets.Result Toggles = new ToggleTargets.Result();
            internal readonly Dictionary<Transform, string> Paths;
            // A copy of the menu as the avatar's tools built it, kept apart from the build's assets so the window can
            // work the final menu out again without building. Whoever takes it destroys it.
            internal MenuSnapshot Tree;
            internal Scan(GameObject avatar)
            {
                Avatar = avatar;
                Paths = avatar.GetComponentsInChildren<Transform>(true).ToDictionary(t => t, t => AnimationUtility.CalculateTransformPath(t, avatar.transform));
                activeScan = this;
            }
            public void Dispose() { if (activeScan == this) activeScan = null; }
        }

        internal enum RepairTarget { None, Shortcut, Destination, NameOverride, Move, MoveDestination, Hide, Icon }

        internal sealed class Issue
        {
            internal string Title, Detail;
            internal bool Warning;
            internal RepairTarget Target;
            internal int MenuIndex, ItemIndex;
            internal FavoriteMenuKey Saved, Current;
        }

        internal static string Describe(FavoriteMenuKey key)
        {
            if (key == null) return "(없음)";
            if (key.type == Control.ControlType.SubMenu && key.Binding.Length == 0)
                return key.DisplayPath;
            var parameters = (key.subParameters ?? Array.Empty<string>())
                .Select(p => string.IsNullOrEmpty(p) ? "—" : p);
            string binding = string.Join(" · ", new[] { key.parameter }.Concat(parameters)
                .Where(p => !string.IsNullOrEmpty(p)));
            return $"{key.DisplayPath}  [{key.type} · {binding} · 값 {key.value}]";
        }

        private static Scan activeScan;

        internal static void ReadSettings(BuildContext context)
        {
            var settings = context.GetState<MenuSettings>();
            settings.Read(context.AvatarRootObject.GetComponent<AvatarCustomizer>());
            // Read now: in an upload VRCFury runs between this phase and the menu pass, and takes its components away.
            settings.Next = VrcFury.NextLink(context.AvatarRootObject);
        }

        internal static string MatchDetail(FavoriteMenuMatch match)
        {
            switch (match)
            {
                case FavoriteMenuMatch.Moved: return "경로가 바뀌었지만 같은 동작에 연결됩니다.";
                case FavoriteMenuMatch.Changed: return "같은 경로에서 동작이 바뀌었습니다. 아래 내용을 확인하세요.";
                case FavoriteMenuMatch.Ambiguous: return "원본 후보가 여러 개라 빌드에서 제외됩니다.";
                default: return "원본을 찾을 수 없어 빌드에서 제외됩니다.";
            }
        }

        internal static void Build(BuildContext context)
        {
            var avatar = context.AvatarRootObject;
            var descriptor = avatar.GetComponent<VRCAvatarDescriptor>();
            if (!descriptor) return;
            var scan = activeScan?.Avatar == avatar ? activeScan : null;
            var config = context.GetState<MenuSettings>();
            bool configured = config.Configured;
            if (!configured && scan == null) return;
            var root = descriptor.expressionsMenu;
            var parameters = descriptor.expressionParameters;
            var issues = scan?.Issues ?? new List<Issue>();
            var parameterTypes = MenuComposer.ParameterTypes(parameters);
            // Judged once, on the menu as the avatar's tools left it: the read's copy and the build use the same links.
            var pageLinks = MenuOrganizer.FindPageLinks(root, LoadMoreIcon(), config.Next);

            if (scan != null)
            {
                scan.Tree = MenuOrganizer.Snapshot(root, pageLinks, BuildOnly);
                scan.Defaults = (parameters ? parameters.parameters : null)?.Where(p => p != null && !string.IsNullOrEmpty(p.name))
                    .GroupBy(p => p.name).ToDictionary(g => g.Key, g => g.First().defaultValue) ?? new Dictionary<string, float>();
                scan.ParameterTypes = parameterTypes;
                scan.Toggles = ToggleTargets.Read(avatar, scan.Paths);
            }
            // Both edits, worked out the same way as the window's preview. Only the shapes state needs the build: the
            // blendshape controls it generated earlier.
            var shapes = configured ? context.GetState<BlendshapeControlBuilder.State>() : new BlendshapeControlBuilder.State();
            if (scan != null)
                scan.Shapes = config.Shapes.Keys.ToDictionary(id => id, id => BlendshapeControlBuilder.Verdict(shapes, id));
            var composition = MenuComposer.Compose(root, config, shapes, parameterTypes, issues, scan != null, pageLinks: pageLinks);
            var organizer = composition.Organizer;
            if (scan != null)
            {
                scan.Menu = organizer.Original;
                scan.Organized = organizer.Organized;
                scan.FavoriteMenus.UnionWith(composition.FavoriteMenus);
            }
            if (!configured)
            {
                composition.Destroy();
                return;
            }

            // A blendshape control the final menu has no reachable item for keeps its expression parameter (the composer
            // says so). This pass runs after Modular Avatar's Sync Parameter Sequence and VRCFury's mobile alignment have
            // recorded or aligned the platform's parameter list, and whether an install location exists can differ by
            // platform: taking a parameter out here would shift the synced parameters after it on one platform only.
            int defaultCount = 0;
            if (composition.Defaults.Count > 0)
            {
                // Never edit the project's asset: the build gets its own copy.
                var copy = Object.Instantiate(parameters);
                copy.name = parameters.name;
                foreach (var pair in composition.Defaults)
                {
                    copy.parameters.First(x => x != null && x.name == pair.Key).defaultValue = pair.Value;
                    defaultCount++;
                }
                context.AssetSaver.SaveAsset(copy);
                descriptor.expressionParameters = copy;
            }

            int nameCount = organizer.NameCount, moveCount = organizer.MoveCount, hideCount = organizer.HideCount;
            composition.DestroyStandIns();
            if (composition.MenuChanged)
            {
                // All edits belong to this avatar's build copy.
                context.AssetSaver.SaveAssets(organizer.Created);
                descriptor.expressionsMenu = composition.Root;
            }
            else composition.Destroy();
            var warnings = issues.Where(i => i.Warning).Select(i => i.Title + " · " + i.Detail).ToArray();
            if (scan != null)
            {
                scan.HasWarnings = warnings.Length > 0;
                scan.Result = $"메뉴 {composition.MenuCount}개 · 즐겨찾기 {composition.FavoriteCount}개 · 폴더 {composition.FolderCount}개 · 이름 변경 {nameCount}개" +
                    (organizer.IconCount > 0 ? $" · 아이콘 {organizer.IconCount}개" : "") +
                    (moveCount > 0 ? $" · 이동 {moveCount}개" : "") +
                    (organizer.FolderCount > 0 ? $" · 새 폴더 {organizer.FolderCount}개" : "") + (hideCount > 0 ? $" · 숨김 {hideCount}개" : "") +
                    (composition.ShapeCount > 0 ? $" · 블렌드쉐이프 {composition.ShapeCount}개" : "") + (defaultCount > 0 ? $" · 기본값 {defaultCount}개" : "");
                if (scan.HasWarnings) scan.Result += "\n" + string.Join("\n", warnings);
            }
            else foreach (var warning in warnings) Debug.LogWarning("[Avatar Customizer] " + warning, avatar);
        }

        // Runs every installed NDMF plug-in through the Transforming phase (where Modular Avatar installs menus),
        // then this tool's menu pass, skipping optimisers. Returns null, before touching the avatar, when this NDMF
        // version lacks the internals used here. assetFolder holds the build's generated assets, as in a full build:
        // many plug-ins store theirs next to the build's asset container (AssetDatabase.AddObjectToAsset) and fail
        // without one. The caller deletes the folder; null keeps everything in memory.
        internal static BuildContext ProcessFast(GameObject root, string assetFolder)
        {
            const BindingFlags all = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static;
            var asm = typeof(BuildContext).Assembly;
            var resolverType = asm.GetType("nadena.dev.ndmf.PluginResolver", false);
            var concreteType = asm.GetType("nadena.dev.ndmf.ConcretePass", false);
            var find = resolverType?.GetMethod("FindPluginTypes", all);
            var ctor = resolverType?.GetConstructor(all, null,
                new[] { typeof(IEnumerable<Type>), typeof(INDMFPlatformProvider), typeof(bool) }, null);
            var passesProperty = resolverType?.GetProperty("Passes", all);
            var run = concreteType == null ? null : typeof(BuildContext).GetMethod("RunPass", all, null, new[] { concreteType }, null);
            if (find == null || ctor == null || passesProperty == null || run == null ||
                !typeof(IEnumerable<Type>).IsAssignableFrom(find.ReturnType))
                return null;
            var platform = AmbientPlatform.DefaultPlatform;
            var plan = new List<object>();
            using (new AmbientPlatform.Scope(platform))
            {
                var resolver = ctor.Invoke(new[] { find.Invoke(null, null), platform, false });
                if (!(passesProperty.GetValue(resolver) is IEnumerable phases)) return null;
                foreach (var pair in phases)
                {
                    var type = pair?.GetType();
                    var phaseField = type?.GetField("Item1");
                    var passesField = type?.GetField("Item2");
                    if (phaseField?.FieldType != typeof(BuildPhase) || passesField == null || !(passesField.GetValue(pair) is IEnumerable passes))
                        return null;
                    var phase = (BuildPhase)phaseField.GetValue(pair);
                    if (phase == BuildPhase.Optimizing) break;
                    foreach (var pass in passes)
                    {
                        if (!concreteType.IsInstanceOfType(pass)) return null;
                        plan.Add(pass);
                    }
                    if (phase == BuildPhase.Transforming) break;
                }
            }
            var context = new BuildContext(root, assetFolder, platform);
            try
            {
                using (new AmbientPlatform.Scope(platform))
                {
                    foreach (var pass in plan) run.Invoke(context, new[] { pass });
                    Build(context);
                }
            }
            catch (TargetInvocationException e) when (e.InnerException != null)
            {
                throw new InvalidOperationException(e.InnerException.Message, e.InnerException);
            }
            finally
            {
                try { context.DeactivateAllExtensionContexts(); }
                finally { context.AssetSaver.Dispose(); }
            }
            return context;
        }

        internal static bool Reaches(VRCExpressionsMenu menu, VRCExpressionsMenu destination, VRCExpressionsMenu end,
            HashSet<VRCExpressionsMenu> seen)
        {
            if (!menu || !seen.Add(menu)) return false;
            if (menu == destination || menu == end) return true;
            return menu.controls != null && menu.controls.Any(c => c?.type == Control.ControlType.SubMenu &&
                Reaches(c.subMenu, destination, end, seen));
        }

        internal static Control Copy(Control c, string name, Func<VRCExpressionsMenu, VRCExpressionsMenu> map) => new Control
        {
            name = name, type = c.type, icon = c.icon, value = c.value, style = c.style,
            parameter = new Control.Parameter { name = c.parameter?.name ?? "" },
            subParameters = (c.subParameters ?? Array.Empty<Control.Parameter>())
                .Select(p => new Control.Parameter { name = p?.name ?? "" }).ToArray(),
            labels = (c.labels ?? Array.Empty<Control.Label>()).ToArray(),
            subMenu = c.type == Control.ControlType.SubMenu ? map(c.subMenu) : c.subMenu,
        };

        internal static Control Submenu(string name, VRCExpressionsMenu menu) => new Control
        {
            name = name, type = Control.ControlType.SubMenu, subMenu = menu, parameter = new Control.Parameter(),
        };

        internal static VRCExpressionsMenu NewMenu(string name, List<VRCExpressionsMenu> created)
        {
            var menu = ScriptableObject.CreateInstance<VRCExpressionsMenu>();
            menu.name = name;
            menu.controls = new List<Control>();
            created.Add(menu);
            return menu;
        }
    }

    // How a tool's link to the rest of a full page looks: its name and icon (none: null).
    internal sealed class PageLinkLook
    {
        internal string Name;
        internal Texture2D Icon;

        // Whether a link's icon is that icon: the same texture, or the copy VRCFury puts in its place (VrcFury.Replaced).
        internal bool Shows(Texture2D icon) => icon == Icon || (Icon && icon && VrcFury.Replaced(icon, Icon));
    }

    // VRCFury on an avatar, read by type and field names: this package does not need it installed. VRCFury is no NDMF
    // plug-in. In an upload it runs as a VRChat SDK callback between NDMF's Transforming and Optimizing phases (after
    // Modular Avatar, before this tool's menu pass), where it adds its own menu items and splits full pages again; the
    // window's reads run NDMF alone, so they never see that.
    internal static class VrcFury
    {
        // One of its components other than the debug marker: what makes VRCFury run on an avatar (VRCFuryBuilder.ShouldRun).
        private static bool IsComponent(MonoBehaviour c)
        {
            for (var type = c.GetType(); type != null; type = type.BaseType)
                if (type.FullName == "VF.Component.VRCFuryComponent") return c.GetType().FullName != "VF.Model.VRCFuryDebugInfo";
            return false;
        }

        // Its components that a build would see (those under EditorOnly objects are gone by then).
        private static IEnumerable<MonoBehaviour> Components(GameObject avatar) => !avatar ? Enumerable.Empty<MonoBehaviour>() :
            avatar.GetComponentsInChildren<MonoBehaviour>(true)
                .Where(c => c && IsComponent(c) && !BlendshapeConflicts.RemovedAtBuild(c.transform, avatar.transform));

        internal static bool On(GameObject avatar) => Components(avatar).Any();

        // The link VRCFury puts at the end of a page it splits (MenuSplitter.SplitMenus): "Next" without an icon, or the
        // text and icon of the avatar's first "Override Menu Settings" (FinalizeMenuService). Null without VRCFury.
        internal static PageLinkLook NextLink(GameObject avatar)
        {
            PageLinkLook look = null;
            foreach (var component in Components(avatar))
            {
                look ??= new PageLinkLook { Name = "Next" };
                var content = component.GetType().GetField("content")?.GetValue(component);
                if (content == null || content.GetType().FullName != "VF.Model.Feature.OverrideMenuSettings") continue;
                if (content.GetType().GetField("nextText")?.GetValue(content) is string text && text.Length > 0) look.Name = text;
                var icon = content.GetType().GetField("nextIcon")?.GetValue(content);
                look.Icon = icon?.GetType().GetField("objRef")?.GetValue(icon) as Texture2D;
                break;
            }
            return look;
        }

        // VRCFury saves what a build makes under this package (TmpFilePackage.TmpDirPath).
        private const string TempPackage = "Packages/com.vrcfury.temp/";

        // Whether icon is VRCFury's copy of original. After splitting the pages it fixes every menu icon for the SDK
        // (FixMenuIconTexturesService, after FinalizeMenuService): an icon larger than 256 px or not compressed becomes
        // Texture2DExtensions.Optimize's copy, and one the SDK would still refuse for its importer settings a plain copy
        // (VrcfObjectCloner). Both are textures VRCFury made (never saved, or saved into its temporary package by
        // SaveAssetsService before this tool runs), named as the original, at Optimize's size or the original's.
        internal static bool Replaced(Texture2D icon, Texture2D original)
        {
            if (icon == original || icon.name != original.name) return false;
            if (EditorUtility.IsPersistent(icon) && !AssetDatabase.GetAssetPath(icon).StartsWith(TempPackage, StringComparison.Ordinal))
                return false;
            if (icon.width == original.width && icon.height == original.height) return true;
            // Optimize: the longer side to at most 256, each side to the nearest power of two and at least 4.
            double scale = Math.Min(1d, 256d / Math.Max(original.width, original.height));
            int Side(int side) => Math.Max(4, Mathf.ClosestPowerOfTwo((int)Math.Round(side * scale)));
            return icon.width == Side(original.width) && icon.height == Side(original.height);
        }
    }
}
#endif
