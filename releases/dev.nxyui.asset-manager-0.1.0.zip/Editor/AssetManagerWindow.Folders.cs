using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace NXYUI.AssetManager
{
    // The 폴더 지정 tab: folders found by imports (proposals) and folders no asset owns yet. A folder becomes an asset
    // only when the user confirms it here, in the Project window's context menu or in the folder's Inspector card.
    internal sealed partial class AssetManagerWindow
    {
        private Vector2 foldersScroll;
        private List<string> unassignedCache;
        private readonly HashSet<string> checkedFolders = new HashSet<string>();
        private string groupName = "";
        private string foldersMessage;
        private MessageType foldersMessageType;
        private bool showIgnored;

        private void DrawFoldersTab()
        {
            foldersScroll = EditorGUILayout.BeginScrollView(foldersScroll);
            GUILayout.Label("어떤 폴더를 에셋 하나로 볼지 정해요. Project 창에서 폴더를 우클릭하고 ‘NXYUI › 에셋으로 지정’을 눌러도 돼요.",
                EditorStyles.wordWrappedMiniLabel);
            if (!string.IsNullOrEmpty(foldersMessage)) EditorGUILayout.HelpBox(foldersMessage, foldersMessageType);
            DrawProposals();
            DrawUnassigned();
            DrawIgnored();
            EditorGUILayout.EndScrollView();
        }

        private void DrawProposals()
        {
            var proposals = AssetStore.State.proposals;
            Section($"가져오면서 찾은 후보 ({proposals.Count}개)");
            if (proposals.Count == 0)
            {
                GUILayout.Label("패키지를 가져오면 새로 생긴 폴더가 여기에 올라와요.", EditorStyles.wordWrappedMiniLabel);
                return;
            }
            foreach (var proposal in proposals.ToList())
            {
                var paths = proposal.folders.Select(AssetDatabase.GUIDToAssetPath).Where(AssetDatabase.IsValidFolder).ToList();
                using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
                {
                    using (new EditorGUILayout.HorizontalScope())
                    {
                        EditorGUI.BeginChangeCheck();
                        var name = EditorGUILayout.DelayedTextField(proposal.name);
                        if (EditorGUI.EndChangeCheck() && !string.IsNullOrWhiteSpace(name))
                        {
                            proposal.name = name.Trim();
                            AssetStore.SaveState();
                        }
                        using (new EditorGUI.DisabledScope(paths.Count == 0))
                            if (GUILayout.Button(new GUIContent("에셋으로 만들기", paths.Count == 0 ? "폴더가 없어졌어요." : ""), GUILayout.Width(110)))
                            {
                                MakeAsset(paths, proposal.name, proposal.package, proposal.id);
                                GUIUtility.ExitGUI();
                            }
                        if (GUILayout.Button(new GUIContent("무시", "다시 제안하지 않아요. 아래 ‘무시한 폴더’에서 되돌릴 수 있어요."), GUILayout.Width(44)))
                        {
                            AssetStore.State.ignoredFolders.AddRange(proposal.folders.Where(g => !AssetStore.State.ignoredFolders.Contains(g)));
                            proposals.Remove(proposal);
                            AssetStore.SaveState();
                            unassignedCache = null;
                            GUIUtility.ExitGUI();
                        }
                    }
                    foreach (var path in paths) ClippedLabel("› " + path, EditorStyles.miniLabel);
                    if (paths.Count == 0) GUILayout.Label("⚠ 폴더를 찾지 못했어요(지웠거나 옮김). ‘무시’로 지우세요.", EditorStyles.miniLabel);
                    using (new EditorGUILayout.HorizontalScope())
                    {
                        if (proposal.package.Length > 0) GUILayout.Label("가져온 패키지: " + proposal.package, EditorStyles.miniLabel);
                        var cache = AssetStore.SearchFor(proposal.id);
                        if (BoothLinker.IsSearching(proposal.id)) GUILayout.Label("Booth에서 찾는 중…", EditorStyles.miniLabel);
                        else if (cache != null && cache.results.Count > 0)
                            DrawBadge($"Booth 후보 {cache.results.Count}개", "good", "에셋으로 만든 뒤 에셋 탭에서 골라 연결해요. 첫 후보: " + cache.results[0].name);
                        GUILayout.FlexibleSpace();
                    }
                }
            }
        }

        private void DrawUnassigned()
        {
            var folders = unassignedCache ?? (unassignedCache = AssetFolders.Unassigned());
            Section($"에셋으로 지정하지 않은 폴더 ({folders.Count}개)");
            if (folders.Count == 0)
            {
                GUILayout.Label("Assets 바로 아래 폴더는 모두 에셋이거나 무시한 폴더예요.", EditorStyles.wordWrappedMiniLabel);
                return;
            }
            GUILayout.Label("한 상품이 여러 폴더에 걸쳐 있으면 체크한 뒤 아래 ‘체크한 폴더로 에셋 하나 만들기’를 누르세요.", EditorStyles.wordWrappedMiniLabel);
            foreach (var path in folders)
            {
                var guid = AssetDatabase.AssetPathToGUID(path);
                using (new EditorGUILayout.HorizontalScope(EditorStyles.helpBox))
                {
                    var on = checkedFolders.Contains(guid);
                    var toggled = GUILayout.Toggle(on, GUIContent.none, GUILayout.Width(16));
                    if (toggled != on)
                    {
                        if (toggled) checkedFolders.Add(guid);
                        else checkedFolders.Remove(guid);
                    }
                    GUILayout.Label(EditorGUIUtility.IconContent("Folder Icon"), GUILayout.Width(18), GUILayout.Height(18));
                    ClippedLabel(path, EditorStyles.label, GUILayout.MinWidth(60));
                    if (GUILayout.Button("보기", EditorStyles.miniButton, GUILayout.Width(40)))
                        EditorGUIUtility.PingObject(AssetDatabase.LoadAssetAtPath<DefaultAsset>(path));
                    if (GUILayout.Button("에셋으로 만들기", EditorStyles.miniButton, GUILayout.Width(96)))
                    {
                        MakeAsset(new List<string> { path }, Path.GetFileName(path), "", null);
                        GUIUtility.ExitGUI();
                    }
                    if (GUILayout.Button(new GUIContent("무시", "도구·SDK 폴더처럼 상품이 아닌 폴더는 목록에서 숨겨요."), EditorStyles.miniButton, GUILayout.Width(40)))
                    {
                        AssetStore.State.ignoredFolders.Add(guid);
                        checkedFolders.Remove(guid);
                        AssetStore.SaveState();
                        unassignedCache = null;
                        GUIUtility.ExitGUI();
                    }
                }
            }
            var chosen = folders.Where(p => checkedFolders.Contains(AssetDatabase.AssetPathToGUID(p))).ToList();
            using (new EditorGUILayout.HorizontalScope())
            {
                groupName = EditorGUILayout.TextField("에셋 이름", groupName);
                var reason = chosen.Count < 1 ? "폴더를 하나 이상 체크하세요." : string.IsNullOrWhiteSpace(groupName) ? "에셋 이름을 적으세요." : null;
                using (new EditorGUI.DisabledScope(reason != null))
                    if (GUILayout.Button(new GUIContent($"체크한 폴더로 에셋 하나 만들기 ({chosen.Count})", reason ?? ""), GUILayout.Width(210)))
                    {
                        MakeAsset(chosen, groupName, "", null);
                        groupName = "";
                        checkedFolders.Clear();
                        GUIUtility.ExitGUI();
                    }
            }
        }

        private void DrawIgnored()
        {
            var ignored = AssetStore.State.ignoredFolders;
            if (ignored.Count == 0) return;
            GUILayout.Space(8);
            var open = EditorGUILayout.Foldout(showIgnored, $"무시한 폴더 ({ignored.Count}개)", true);
            if (open != showIgnored)
            {
                showIgnored = open;
                GUIUtility.ExitGUI();
            }
            if (!showIgnored) return;
            foreach (var guid in ignored.ToList())
                using (new EditorGUILayout.HorizontalScope())
                {
                    var path = AssetDatabase.GUIDToAssetPath(guid);
                    ClippedLabel(path.Length > 0 ? path : "(없어진 폴더)", EditorStyles.miniLabel, GUILayout.MinWidth(60));
                    if (GUILayout.Button("다시 보이기", EditorStyles.miniButton, GUILayout.Width(72)))
                    {
                        ignored.Remove(guid);
                        AssetStore.SaveState();
                        unassignedCache = null;
                        GUIUtility.ExitGUI();
                    }
                }
        }

        private void MakeAsset(List<string> paths, string name, string package, string proposalId)
        {
            try
            {
                var asset = AssetFolders.Create(paths, name, package);
                if (proposalId != null) BoothLinker.Transfer(proposalId, asset.id);
                BoothLinker.SearchOnce(asset.id, asset.name, AssetFolders.ExistingFolders(asset), asset.package);
                foldersMessage = $"‘{asset.name}’ 에셋을 만들었어요. 에셋 탭에서 Booth 연결과 조립을 할 수 있어요.";
                foldersMessageType = MessageType.Info;
                selectedAsset = asset.id;
                unassignedCache = null;
                prefabCache = null;
            }
            catch (InvalidOperationException e)
            {
                foldersMessage = "에셋으로 만들지 못했어요: " + e.Message;
                foldersMessageType = MessageType.Warning;
            }
        }
    }
}
