using System;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace NXYUI.AssetManager
{
    // A small card at the top of a folder's Inspector: which asset the folder belongs to, or a button to make it one.
    // Also the Project window's right-click entries for the same.
    [InitializeOnLoad]
    internal static class FolderInspectorCard
    {
        private const string DesignateMenu = "Assets/NXYUI/에셋으로 지정";
        private const string ShowMenu = "Assets/NXYUI/Asset Manager에서 보기";

        static FolderInspectorCard()
        {
            Editor.finishedDefaultHeaderGUI += Draw;
        }

        private static GUIStyle wrappedBold;
        private static GUIStyle WrappedBold => wrappedBold ?? (wrappedBold = new GUIStyle(EditorStyles.boldLabel) { wordWrap = true });

        private static void Draw(Editor editor)
        {
            if (editor.targets.Length != 1 || !(editor.target is DefaultAsset)) return;
            var path = AssetDatabase.GetAssetPath(editor.target);
            if (!AssetDatabase.IsValidFolder(path) || !path.StartsWith("Assets/", StringComparison.Ordinal)) return;
            var guid = AssetDatabase.AssetPathToGUID(path);
            var asset = AssetStore.AssetAt(path);
            var shared = AssetStore.Project.assets.Where(a => a.sharedFolders.Contains(guid)).ToList();
            using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
            {
                if (asset != null)
                {
                    var own = asset.folders.Contains(guid);
                    var title = own ? $"에셋: {asset.name}" : $"‘{asset.name}’ 에셋의 폴더 안이에요";
                    GUILayout.Label(new GUIContent(title, asset.name), WrappedBold);
                    var item = AssetStore.Item(asset.boothId);
                    GUILayout.Label(asset.boothId > 0 ? "Booth: " + (item?.name.Length > 0 ? item.name : asset.boothName.Length > 0 ? asset.boothName : "상품 " + asset.boothId)
                        : "Booth 상품과 아직 연결하지 않았어요.", EditorStyles.wordWrappedMiniLabel);
                    using (new EditorGUILayout.HorizontalScope())
                    {
                        if (GUILayout.Button("Asset Manager에서 열기", EditorStyles.miniButton)) AssetManagerWindow.ShowAsset(asset);
                        if (asset.boothId > 0 && GUILayout.Button("Booth 페이지", EditorStyles.miniButton)) Application.OpenURL("https://booth.pm/ja/items/" + asset.boothId);
                        GUILayout.FlexibleSpace();
                    }
                    return;
                }
                if (shared.Count > 0)
                {
                    GUILayout.Label("공용 폴더: " + string.Join(", ", shared.Select(a => a.name)), EditorStyles.wordWrappedMiniLabel);
                    return;
                }
                var problem = AssetFolders.Problem(path);
                using (new EditorGUILayout.HorizontalScope())
                {
                    GUILayout.Label("Asset Manager: 에셋으로 지정하지 않은 폴더예요.", EditorStyles.wordWrappedMiniLabel);
                    using (new EditorGUI.DisabledScope(problem != null))
                        if (GUILayout.Button(new GUIContent("에셋으로 지정", problem ?? "이 폴더를 상품 하나로 등록해요."), EditorStyles.miniButton, GUILayout.Width(90)))
                        {
                            Designate(new[] { path });
                            GUIUtility.ExitGUI();
                        }
                }
                if (problem != null) GUILayout.Label(problem, EditorStyles.wordWrappedMiniLabel);
            }
        }

        private static string[] SelectedFolders() =>
            Selection.assetGUIDs.Select(AssetDatabase.GUIDToAssetPath).Where(AssetDatabase.IsValidFolder).Distinct().ToArray();

        [MenuItem(DesignateMenu, false, 1100)]
        private static void DesignateSelected() => Designate(SelectedFolders());

        [MenuItem(DesignateMenu, true)]
        private static bool CanDesignate()
        {
            var folders = SelectedFolders();
            return folders.Length > 0 && folders.All(f => AssetFolders.Problem(f) == null);
        }

        [MenuItem(ShowMenu, false, 1101)]
        private static void ShowSelected()
        {
            var folder = SelectedFolders().FirstOrDefault();
            if (folder != null) AssetManagerWindow.ShowAsset(AssetStore.AssetAt(folder));
        }

        [MenuItem(ShowMenu, true)]
        private static bool CanShow() => SelectedFolders().Any(f => AssetStore.AssetAt(f) != null);

        private static void Designate(string[] folders)
        {
            if (folders.Length == 0) return;
            try
            {
                if (folders.Length == 1)
                {
                    Created(AssetFolders.Create(folders, Path.GetFileName(folders[0])));
                    return;
                }
                var choice = EditorUtility.DisplayDialogComplex("에셋으로 지정",
                    $"고른 폴더 {folders.Length}개를 어떻게 지정할까요?\n한 상품이 여러 폴더에 걸쳐 있으면 ‘하나로 묶기’를 고르세요.",
                    "하나로 묶기", "취소", "폴더마다 따로");
                if (choice == 0) Created(AssetFolders.Create(folders, Path.GetFileName(folders[0])));
                else if (choice == 2)
                    foreach (var folder in folders) Created(AssetFolders.Create(new[] { folder }, Path.GetFileName(folder)));
            }
            catch (InvalidOperationException e)
            {
                EditorUtility.DisplayDialog("에셋으로 지정", "지정하지 못했어요: " + e.Message, "확인");
            }
        }

        private static void Created(AssetRecord asset)
        {
            BoothLinker.SearchOnce(asset.id, asset.name, AssetFolders.ExistingFolders(asset), asset.package);
            AssetManagerWindow.ShowAsset(asset);
        }
    }
}
