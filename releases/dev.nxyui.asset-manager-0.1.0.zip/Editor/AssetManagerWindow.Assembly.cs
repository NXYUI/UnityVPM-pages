using System;
using System.Collections.Generic;
using System.Linq;
using nadena.dev.modular_avatar.core;
using UnityEditor;
using UnityEngine;
using UnityEngine.SceneManagement;
using VRC.SDK3.Avatars.Components;
using Object = UnityEngine.Object;

namespace NXYUI.AssetManager
{
    // The card's 조립 section: avatar, where the asset goes (its submenu), prefab, Outfit or Bone Proxy, then one button.
    internal sealed partial class AssetManagerWindow
    {
        [SerializeField] private VRCAvatarDescriptor assemblyAvatar;
        [SerializeField] private Transform assemblyParent;
        [SerializeField] private string newParentName = "";
        [SerializeField] private GameObject assemblyPrefab;
        [SerializeField] private AssemblyMode assemblyMode;
        [SerializeField] private Transform boneTarget;
        [SerializeField] private BoneProxyAttachmentMode attachMode = BoneProxyAttachmentMode.AsChildAtRoot;
        [SerializeField] private string toggleName = "";
        private string assemblyFor;
        private string assemblyMessage;
        private MessageType assemblyMessageType;
        private VRCAvatarDescriptor[] avatarCache;
        private List<GameObject> assetPrefabs;
        private string assetPrefabsFor;

        private static readonly (BoneProxyAttachmentMode Mode, string Label)[] AttachModes =
        {
            (BoneProxyAttachmentMode.AsChildAtRoot, "뼈 위치로 옮기기"),
            (BoneProxyAttachmentMode.AsChildKeepWorldPose, "지금 위치·회전 유지"),
            (BoneProxyAttachmentMode.AsChildKeepRotation, "회전만 유지"),
            (BoneProxyAttachmentMode.AsChildKeepPosition, "위치만 유지"),
        };

        private VRCAvatarDescriptor[] Avatars
        {
            get
            {
                if (avatarCache == null || avatarCache.Any(a => !a))
                    avatarCache = Object.FindObjectsByType<VRCAvatarDescriptor>(FindObjectsInactive.Include, FindObjectsSortMode.None)
                        .Where(a => a.gameObject.scene.IsValid() && !EditorUtility.IsPersistent(a))
                        .OrderBy(a => a.gameObject.scene.name).ThenBy(a => a.name).ToArray();
                return avatarCache;
            }
        }

        private void DrawAssemblySection(AssetRecord asset)
        {
            Section("조립");
            if (assemblyFor != asset.id) ResetAssembly(asset);
            var avatars = Avatars;
            if (avatars.Length == 0)
            {
                EditorGUILayout.HelpBox("씬에 아바타(VRC Avatar Descriptor)가 없어요. 아바타를 씬에 놓으면 여기서 바로 조립할 수 있어요.", MessageType.Info);
                return;
            }
            if (!assemblyAvatar || !avatars.Contains(assemblyAvatar)) assemblyAvatar = avatars[0];

            // Avatar
            var avatarIndex = Array.IndexOf(avatars, assemblyAvatar);
            var avatarNames = avatars.Select(a => avatars.Count(b => b.name == a.name) > 1 ? $"{a.name} ({a.gameObject.scene.name})" : a.name).ToArray();
            var newAvatar = EditorGUILayout.Popup("아바타", avatarIndex, avatarNames);
            if (newAvatar != avatarIndex)
            {
                assemblyAvatar = avatars[newAvatar];
                assemblyParent = null;
                boneTarget = null;
                assemblyMessage = null;
                GUIUtility.ExitGUI();
            }
            var root = assemblyAvatar.transform;

            // Where it goes: an existing object (its submenu) or a new one under the avatar root.
            var places = Places(root);
            var placeNames = new[] { "새로 만들기…" }.Concat(places.Select(p => Breadcrumb(root, p))).ToArray();
            var placeIndex = assemblyParent ? places.IndexOf(assemblyParent) + 1 : 0;
            if (assemblyParent && placeIndex == 0)
            {
                // Dragged in from the Hierarchy: shown as its own entry.
                places.Add(assemblyParent);
                placeNames = placeNames.Concat(new[] { Breadcrumb(root, assemblyParent) }).ToArray();
                placeIndex = placeNames.Length - 1;
            }
            using (new EditorGUILayout.HorizontalScope())
            {
                var chosen = EditorGUILayout.Popup(new GUIContent("넣을 위치", "에셋이 들어갈 오브젝트예요. 이 오브젝트가 에셋 메뉴를 담는 하위 메뉴가 돼요."), placeIndex, placeNames);
                var dropped = (Transform)EditorGUILayout.ObjectField(assemblyParent, typeof(Transform), true, GUILayout.Width(110));
                if (chosen != placeIndex || dropped != assemblyParent)
                {
                    assemblyParent = dropped != assemblyParent ? dropped : chosen == 0 ? null : places[chosen - 1];
                    GUIUtility.ExitGUI();
                }
            }
            if (!assemblyParent)
            {
                if (string.IsNullOrWhiteSpace(newParentName)) newParentName = asset.kind == AssetKind.Outfit ? "의상" : "액세서리";
                newParentName = EditorGUILayout.TextField(new GUIContent("새 오브젝트 이름", "아바타 루트 바로 아래에 이 이름으로 만들어요."), newParentName);
            }

            // Prefab
            var prefabs = PrefabsOf(asset);
            if (prefabs.Count == 0)
            {
                EditorGUILayout.HelpBox("이 에셋 폴더에 프리팹이 없어요. 프리팹이 든 폴더를 ‘폴더’에 넣으세요.", MessageType.Warning);
                return;
            }
            var ordered = OrderForAvatar(prefabs, assemblyAvatar);
            if (!assemblyPrefab || !ordered.Contains(assemblyPrefab)) assemblyPrefab = ordered[0];
            var prefabIndex = ordered.IndexOf(assemblyPrefab);
            var prefabNames = ordered.Select(p => PrefabLabel(asset, p)).ToArray();
            using (new EditorGUILayout.HorizontalScope())
            {
                var chosenPrefab = EditorGUILayout.Popup(new GUIContent("프리팹", "고른 아바타의 이름이 든 프리팹을 먼저 보여 줘요."), prefabIndex, prefabNames);
                if (chosenPrefab != prefabIndex)
                {
                    assemblyPrefab = ordered[chosenPrefab];
                    assemblyMode = AssetFolders.HasArmature(assemblyPrefab) ? AssemblyMode.Outfit : AssemblyMode.BoneProxy;
                    attachMode = RecommendedAttach(assemblyPrefab, assemblyAvatar);
                    GUIUtility.ExitGUI();
                }
                if (GUILayout.Button("보기", EditorStyles.miniButton, GUILayout.Width(40))) EditorGUIUtility.PingObject(assemblyPrefab);
            }

            // Mode
            var mode = (AssemblyMode)GUILayout.Toolbar((int)assemblyMode, new[] { "Outfit (옷 입히기)", "Bone Proxy (뼈에 붙이기)" });
            if (mode != assemblyMode)
            {
                assemblyMode = mode;
                GUIUtility.ExitGUI();
            }
            GUILayout.Label(assemblyMode == AssemblyMode.Outfit
                    ? "의상의 뼈를 아바타의 뼈에 합쳐요(MA Setup Outfit)."
                    : "에셋을 아바타의 뼈 하나에 붙여 따라 움직이게 해요(MA Bone Proxy).", EditorStyles.wordWrappedMiniLabel);
            if (assemblyMode == AssemblyMode.BoneProxy) DrawBoneTarget(asset, root);

            // Menu
            var plan = Plan();
            var describe = AssetAssembler.DescribeMenu(plan);
            if (AssetAssembler.WillMakeToggle(plan.Prefab))
            {
                if (string.IsNullOrWhiteSpace(toggleName)) toggleName = asset.name;
                toggleName = EditorGUILayout.TextField(new GUIContent("토글 이름", "메뉴에 보일 이름이에요."), toggleName);
                plan.ToggleName = toggleName;
                describe = AssetAssembler.DescribeMenu(plan);
            }
            GUILayout.Label("메뉴: " + describe, EditorStyles.wordWrappedMiniLabel);

            var problems = AssetAssembler.Problems(plan);
            foreach (var warning in AssetAssembler.Warnings(plan)) EditorGUILayout.HelpBox(warning, MessageType.Warning);
            using (new EditorGUI.DisabledScope(problems.Count > 0))
            {
                var tooltip = problems.Count > 0 ? problems[0] : "한 번 누르면 조립돼요. Ctrl+Z로 한 번에 되돌릴 수 있어요.";
                if (GUILayout.Button(new GUIContent("조립", tooltip), GUILayout.Height(26))) Assemble(plan);
            }
            if (problems.Count > 0) GUILayout.Label(problems[0], EditorStyles.wordWrappedMiniLabel);
            if (!string.IsNullOrEmpty(assemblyMessage)) EditorGUILayout.HelpBox(assemblyMessage, assemblyMessageType);
        }

        private void DrawBoneTarget(AssetRecord asset, Transform root)
        {
            var targets = BoneTargets.For(root, asset.name + " " + (assemblyPrefab ? assemblyPrefab.name : ""), AssetStore.RecentBonesFor(AvatarKey(assemblyAvatar)));
            var labels = targets.Select(t => $"{t.Group}/{t.Label}").ToArray();
            var index = targets.FindIndex(t => t.Bone == boneTarget);
            if (!boneTarget && targets.Count > 0 && targets[0].Group == BoneTargets.Suggested)
            {
                boneTarget = targets[0].Bone;
                index = 0;
            }
            using (new EditorGUILayout.HorizontalScope())
            {
                var shownLabels = index < 0 && boneTarget ? labels.Concat(new[] { "직접 고름/" + boneTarget.name }).ToArray() : labels;
                var shownIndex = index >= 0 ? index : boneTarget ? shownLabels.Length - 1 : -1;
                var chosen = EditorGUILayout.Popup(new GUIContent("붙일 뼈", "에셋 이름으로 추천한 뼈, 자주 쓰는 뼈, 아바타 고유 뼈, 최근 쓴 뼈 순이에요."), shownIndex, shownLabels);
                if (chosen != shownIndex && chosen >= 0 && chosen < targets.Count) boneTarget = targets[chosen].Bone;
                var dropped = (Transform)EditorGUILayout.ObjectField(boneTarget, typeof(Transform), true, GUILayout.Width(110));
                if (dropped != boneTarget) boneTarget = dropped;
            }
            var recommended = RecommendedAttach(assemblyPrefab, assemblyAvatar);
            var attachLabels = AttachModes.Select(m => m.Mode == recommended ? m.Label + " (추천)" : m.Label).ToArray();
            var attachIndex = Array.FindIndex(AttachModes, m => m.Mode == attachMode);
            var newAttach = EditorGUILayout.Popup(new GUIContent("붙이는 방식", "아바타용으로 만든 프리팹은 지금 위치를 유지하고, 범용 액세서리는 뼈 위치로 옮기는 게 보통이에요."),
                Math.Max(0, attachIndex), attachLabels);
            attachMode = AttachModes[newAttach].Mode;
        }

        private AssemblyPlan Plan() => new AssemblyPlan
        {
            Avatar = assemblyAvatar,
            Parent = assemblyParent,
            NewParentName = newParentName ?? "",
            Prefab = assemblyPrefab,
            Mode = assemblyMode,
            BoneTarget = boneTarget,
            Attach = attachMode,
            ToggleName = toggleName ?? "",
        };

        private void Assemble(AssemblyPlan plan)
        {
            try
            {
                var result = AssetAssembler.Assemble(plan);
                var lines = new List<string> { $"‘{result.Instance.name}’을(를) {plan.Avatar.name}에 조립했어요. Ctrl+Z로 한 번에 되돌릴 수 있어요." };
                lines.AddRange(result.Notes);
                assemblyMessage = string.Join("\n", lines);
                assemblyMessageType = MessageType.Info;
                if (plan.Mode == AssemblyMode.BoneProxy && plan.BoneTarget)
                    AssetStore.RememberBone(AvatarKey(plan.Avatar), RelativePath(plan.Avatar.transform, plan.BoneTarget));
                if (!plan.Parent)
                {
                    // The new parent exists now: later assemblies go into the same submenu.
                    assemblyParent = result.Instance.transform.parent;
                    while (assemblyParent && assemblyParent.parent != plan.Avatar.transform && !assemblyParent.GetComponent<ModularAvatarMenuItem>())
                        assemblyParent = assemblyParent.parent;
                }
                EditorGUIUtility.PingObject(result.Instance);
                Selection.activeGameObject = result.Instance;
            }
            catch (Exception e) when (!(e is ExitGUIException))
            {
                // The assembly was already undone; anything unexpected (from Modular Avatar too) also lands in the Console.
                if (!(e is InvalidOperationException)) Debug.LogException(e);
                assemblyMessage = "조립하지 못했어요: " + e.Message;
                assemblyMessageType = MessageType.Error;
            }
            avatarCache = null;
            GUIUtility.ExitGUI();
        }

        private void ResetAssembly(AssetRecord asset)
        {
            assemblyFor = asset.id;
            assemblyPrefab = null;
            boneTarget = null;
            toggleName = "";
            newParentName = "";
            assemblyMessage = null;
            var prefabs = PrefabsOf(asset);
            var first = prefabs.Count > 0 ? OrderForAvatar(prefabs, assemblyAvatar)[0] : null;
            assemblyMode = first && AssetFolders.HasArmature(first) ? AssemblyMode.Outfit : AssemblyMode.BoneProxy;
            attachMode = RecommendedAttach(first, assemblyAvatar);
        }

        private List<GameObject> PrefabsOf(AssetRecord asset)
        {
            if (assetPrefabs == null || assetPrefabsFor != asset.id || assetPrefabs.Any(p => !p))
            {
                assetPrefabs = AssetFolders.Prefabs(asset);
                assetPrefabsFor = asset.id;
            }
            return assetPrefabs;
        }

        // Prefabs named for the chosen avatar first, then the ones nearest the asset's top folder.
        private static List<GameObject> OrderForAvatar(List<GameObject> prefabs, VRCAvatarDescriptor avatar)
        {
            var words = AvatarWords(avatar);
            return prefabs.OrderByDescending(p => words.Any(w => AssetDatabase.GetAssetPath(p).IndexOf(w, StringComparison.OrdinalIgnoreCase) >= 0))
                .ThenBy(p => AssetDatabase.GetAssetPath(p).Count(c => c == '/'))
                .ThenBy(p => p.name, StringComparer.OrdinalIgnoreCase).ToList();
        }

        private static List<string> AvatarWords(VRCAvatarDescriptor avatar)
        {
            if (!avatar) return new List<string>();
            var names = new List<string> { avatar.name };
            var source = PrefabUtility.GetCorrespondingObjectFromOriginalSource(avatar.gameObject);
            if (source) names.Add(source.name);
            return names.SelectMany(n => n.Split(new[] { ' ', '_', '-', '(', ')', '.' }, StringSplitOptions.RemoveEmptyEntries))
                .Where(w => w.Length >= 3 && !w.Equals("variant", StringComparison.OrdinalIgnoreCase) && !w.All(char.IsDigit))
                .Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        }

        private BoneProxyAttachmentMode RecommendedAttach(GameObject prefab, VRCAvatarDescriptor avatar)
        {
            if (!prefab) return BoneProxyAttachmentMode.AsChildAtRoot;
            var words = AvatarWords(avatar);
            var path = AssetDatabase.GetAssetPath(prefab);
            return words.Any(w => path.IndexOf(w, StringComparison.OrdinalIgnoreCase) >= 0)
                ? BoneProxyAttachmentMode.AsChildKeepWorldPose
                : BoneProxyAttachmentMode.AsChildAtRoot;
        }

        private static string PrefabLabel(AssetRecord asset, GameObject prefab)
        {
            var path = AssetDatabase.GetAssetPath(prefab);
            foreach (var folder in AssetFolders.ExistingFolders(asset))
                if (path.StartsWith(folder + "/", StringComparison.Ordinal))
                    return path.Substring(folder.Length + 1).Replace("/", " › ");
            return prefab.name;
        }

        // Objects that can hold an asset: the avatar root's children that are not its body or armature, and every
        // object already made into a children-source submenu.
        private static List<Transform> Places(Transform root)
        {
            var hips = AssetFolders.FindHips(root);
            var armature = hips ? hips.parent : null;
            var list = new List<Transform>();
            foreach (Transform child in root)
            {
                if (child == armature || child.GetComponent<SkinnedMeshRenderer>() && !child.GetComponent<ModularAvatarMenuItem>()) continue;
                list.Add(child);
            }
            foreach (var item in root.GetComponentsInChildren<ModularAvatarMenuItem>(true))
                if (item.transform != root && item.MenuSource == SubmenuSource.Children && item.Control != null &&
                    item.Control.type == VRC.SDK3.Avatars.ScriptableObjects.VRCExpressionsMenu.Control.ControlType.SubMenu && !list.Contains(item.transform))
                    list.Add(item.transform);
            return list;
        }

        private static string Breadcrumb(Transform root, Transform t)
        {
            var parts = new List<string>();
            for (var p = t; p && p != root; p = p.parent) parts.Insert(0, p.name);
            var text = string.Join(" › ", parts);
            if (t.GetComponent<ModularAvatarMenuItem>()) text += "  (하위 메뉴)";
            return text.Replace("/", "／");
        }

        private static string RelativePath(Transform root, Transform t)
        {
            var parts = new List<string>();
            for (var p = t; p && p != root; p = p.parent) parts.Insert(0, p.name);
            return string.Join("/", parts);
        }

        private static string AvatarKey(VRCAvatarDescriptor avatar)
        {
            if (!avatar) return "";
            var source = PrefabUtility.GetCorrespondingObjectFromOriginalSource(avatar.gameObject);
            return source ? AssetDatabase.GetAssetPath(source) : avatar.gameObject.scene.path + "/" + avatar.name;
        }
    }
}
