using System;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace NXYUI.AssetManager
{
    // Window shell: menu entry, tabs and shared drawing helpers. The tabs live in the partial files next to this one.
    internal sealed partial class AssetManagerWindow : EditorWindow
    {
        // Every NXYUI package puts its windows under the top-level "NXYUI" menu (checked by tools/test_build_repo.py).
        private const string MenuPath = "NXYUI/Asset Manager";
        private static readonly string[] TabNames = { "에셋", "가져오기", "폴더 지정" };

        [SerializeField] private int tab;

        [MenuItem(MenuPath)]
        private static void OpenFromMenu() => Open();

        internal static AssetManagerWindow Open()
        {
            // Docked next to the Inspector when it is open, like the other panels the user works beside.
            var inspector = typeof(Editor).Assembly.GetType("UnityEditor.InspectorWindow");
            var window = inspector != null ? GetWindow<AssetManagerWindow>("Asset Manager", true, inspector) : GetWindow<AssetManagerWindow>("Asset Manager");
            window.minSize = new Vector2(740, 420);
            window.Show();
            return window;
        }

        internal static void ShowAsset(AssetRecord asset)
        {
            var window = Open();
            window.tab = 0;
            window.selectedAsset = asset?.id;
            window.Repaint();
        }

        internal static void ShowFolders()
        {
            var window = Open();
            window.tab = 2;
            window.Repaint();
        }

        private void OnEnable()
        {
            AssetStore.Changed += Repaint;
            BoothLinker.Updated += Repaint;
            ImportQueue.Changed += Repaint;
            EditorApplication.projectChanged += OnProjectChanged;
            EditorApplication.hierarchyChanged += OnHierarchyChanged;
            EditorApplication.update += TickImportTab;
        }

        private void OnDisable()
        {
            AssetStore.Changed -= Repaint;
            BoothLinker.Updated -= Repaint;
            ImportQueue.Changed -= Repaint;
            EditorApplication.projectChanged -= OnProjectChanged;
            EditorApplication.hierarchyChanged -= OnHierarchyChanged;
            EditorApplication.update -= TickImportTab;
        }

        private void OnProjectChanged()
        {
            AssetFolders.ForgetSizes();
            prefabCache = null;
            assetPrefabs = null;
            unassignedCache = null;
            Repaint();
        }

        private void OnHierarchyChanged()
        {
            avatarCache = null;
            Repaint();
        }

        private void OnGUI()
        {
            using (new EditorGUILayout.HorizontalScope(EditorStyles.toolbar))
            {
                var proposals = AssetStore.State.proposals.Count;
                var labels = new[]
                {
                    $"에셋 {AssetStore.Project.assets.Count}개",
                    ImportQueue.Running ? "가져오기 (진행 중)" : "가져오기",
                    proposals > 0 ? $"폴더 지정 (제안 {proposals}개)" : "폴더 지정",
                };
                var chosen = GUILayout.Toolbar(tab, labels, EditorStyles.toolbarButton, GUILayout.ExpandWidth(false));
                GUILayout.FlexibleSpace();
                if (chosen != tab)
                {
                    // Another tab draws other controls: end this pass so Layout and the event see the same ones.
                    tab = chosen;
                    GUIUtility.ExitGUI();
                }
            }
            switch (tab)
            {
                case 0: DrawAssetsTab(); break;
                case 1: DrawImportTab(); break;
                default: DrawFoldersTab(); break;
            }
        }

        // ---- Shared drawing ----

        private static GUIStyle badgeStyle;
        private static GUIStyle Badge => badgeStyle ?? (badgeStyle = new GUIStyle(EditorStyles.miniBoldLabel)
        {
            padding = new RectOffset(4, 4, 0, 0),
            margin = new RectOffset(0, 4, 2, 2),
            normal = { background = Texture2D.whiteTexture },
        });

        private static GUIStyle wrappedLabel;
        private static GUIStyle WrappedLabel => wrappedLabel ?? (wrappedLabel = new GUIStyle(EditorStyles.label) { wordWrap = true });

        // Badge colours: one tint per meaning, each with its own word so colour is never the only signal.
        private static Color Tint(string kind)
        {
            var pro = EditorGUIUtility.isProSkin;
            switch (kind)
            {
                case "good": return pro ? new Color(.20f, .40f, .25f) : new Color(.72f, .88f, .74f);
                case "warn": return pro ? new Color(.48f, .36f, .12f) : new Color(.98f, .86f, .58f);
                case "bad": return pro ? new Color(.50f, .20f, .20f) : new Color(.96f, .72f, .72f);
                default: return pro ? new Color(.28f, .28f, .30f) : new Color(.82f, .82f, .84f);
            }
        }

        private static void DrawBadge(string text, string kind = "", string tooltip = null)
        {
            var content = new GUIContent(text, tooltip);
            var rect = GUILayoutUtility.GetRect(content, Badge, GUILayout.ExpandWidth(false));
            var previous = GUI.backgroundColor;
            GUI.backgroundColor = Tint(kind);
            GUI.Label(rect, content, Badge);
            GUI.backgroundColor = previous;
        }

        // The selection mark, one per skin; the selected row's name is also bold, so colour is not the only sign.
        private static Color SelectedRow => EditorGUIUtility.isProSkin ? new Color(.17f, .36f, .53f, .55f) : new Color(.23f, .45f, .85f, .25f);

        private static void Highlight(Rect rect, bool selected)
        {
            if (selected && Event.current.type == EventType.Repaint) EditorGUI.DrawRect(rect, SelectedRow);
        }

        private static void DrawThumbnail(Texture texture, float size, string placeholder)
        {
            var rect = GUILayoutUtility.GetRect(size, size, GUILayout.Width(size), GUILayout.Height(size));
            if (Event.current.type != EventType.Repaint) return;
            if (texture) GUI.DrawTexture(rect, texture, ScaleMode.ScaleAndCrop);
            else
            {
                EditorGUI.DrawRect(rect, EditorGUIUtility.isProSkin ? new Color(.18f, .18f, .18f) : new Color(.86f, .86f, .86f));
                GUI.Label(rect, placeholder, new GUIStyle(EditorStyles.centeredGreyMiniLabel) { wordWrap = true });
            }
        }

        // A text that may not fit: it takes the room left in its row, is cut with "…" and shows whole in the tooltip.
        private static void ClippedLabel(string text, GUIStyle style, params GUILayoutOption[] options)
        {
            text = text ?? "";
            // The caller's options come last so they win over these defaults.
            var layout = new[] { GUILayout.ExpandWidth(true), GUILayout.MinWidth(30) }.Concat(options).ToArray();
            var rect = GUILayoutUtility.GetRect(new GUIContent("…"), style, layout);
            GUI.Label(rect, new GUIContent(Fit(text, style, rect.width), text), style);
        }

        private static string Fit(string text, GUIStyle style, float width)
        {
            if (width <= 0 || style.CalcSize(new GUIContent(text)).x <= width) return text;
            int low = 0, high = text.Length;
            while (low < high)
            {
                var middle = (low + high + 1) / 2;
                if (style.CalcSize(new GUIContent(text.Substring(0, middle) + "…")).x <= width) low = middle;
                else high = middle - 1;
            }
            return text.Substring(0, low) + "…";
        }

        private static string KindName(AssetKind kind)
        {
            switch (kind)
            {
                case AssetKind.Avatar: return "아바타";
                case AssetKind.Outfit: return "의상";
                case AssetKind.Accessory: return "액세서리";
                case AssetKind.Tool: return "도구";
                default: return "기타";
            }
        }

        private static readonly string[] KindNames = Enum.GetValues(typeof(AssetKind)).Cast<AssetKind>().Select(KindName).ToArray();

        private static void Section(string title)
        {
            GUILayout.Space(8);
            GUILayout.Label(title, EditorStyles.boldLabel);
        }
    }
}
