using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace NXYUI.AssetManager
{
    // The 에셋 tab: the confirmed assets on the left, the selected one's Booth link, folders and assembly on the right.
    internal sealed partial class AssetManagerWindow
    {
        [SerializeField] private string selectedAsset;
        [SerializeField] private string assetSearch = "";
        [SerializeField] private int kindFilter = -1;
        private Vector2 assetListScroll, assetDetailScroll;
        private string boothQuery = "", boothUrl = "", boothQueryFor;
        private string boothMessage;
        private MessageType boothMessageType;
        private string folderMessage;
        private Dictionary<string, GameObject> prefabCache;

        private AssetRecord SelectedAsset => AssetStore.AssetById(selectedAsset);

        private void DrawAssetsTab()
        {
            var assets = AssetStore.Project.assets;
            if (assets.Count == 0)
            {
                EditorGUILayout.HelpBox("아직 에셋이 없어요. ‘가져오기’에서 패키지를 가져오거나, ‘폴더 지정’에서 이미 있는 폴더를 에셋으로 지정하세요.", MessageType.Info);
                using (new EditorGUILayout.HorizontalScope())
                {
                    if (GUILayout.Button("가져오기 열기", GUILayout.Width(120))) tab = 1;
                    if (GUILayout.Button("폴더 지정 열기", GUILayout.Width(120))) tab = 2;
                }
                return;
            }
            using (new EditorGUILayout.HorizontalScope())
            {
                using (new EditorGUILayout.VerticalScope(GUILayout.Width(position.width * .48f))) DrawAssetList(assets);
                using (new EditorGUILayout.VerticalScope())
                {
                    assetDetailScroll = EditorGUILayout.BeginScrollView(assetDetailScroll);
                    var asset = SelectedAsset;
                    if (asset == null) EditorGUILayout.HelpBox("왼쪽에서 에셋을 고르면 Booth 연결, 폴더, 조립을 볼 수 있어요.", MessageType.None);
                    else DrawAssetDetail(asset);
                    EditorGUILayout.EndScrollView();
                }
            }
        }

        private void DrawAssetList(List<AssetRecord> assets)
        {
            using (new EditorGUILayout.HorizontalScope())
            {
                var search = EditorGUILayout.TextField(assetSearch, EditorStyles.toolbarSearchField);
                var options = new[] { "모든 종류" }.Concat(KindNames).ToArray();
                var filter = EditorGUILayout.Popup(kindFilter + 1, options, GUILayout.Width(90)) - 1;
                if (search != assetSearch || filter != kindFilter)
                {
                    // The list below changes length: end the pass before drawing it.
                    assetSearch = search;
                    kindFilter = filter;
                    GUIUtility.ExitGUI();
                }
            }
            var shown = assets.Where(a => kindFilter < 0 || (int)a.kind == kindFilter)
                .Where(a => string.IsNullOrEmpty(assetSearch) || Matches(a, assetSearch))
                .OrderBy(a => a.name, StringComparer.CurrentCultureIgnoreCase).ToList();
            GUILayout.Label($"{shown.Count}개 표시 · 전체 {assets.Count}개 · ↑↓로 고르기", EditorStyles.miniLabel);
            // Up and down arrows move the selection while no text field has the keyboard.
            var key = Event.current;
            if (key.type == EventType.KeyDown && GUIUtility.keyboardControl == 0 && shown.Count > 0 &&
                (key.keyCode == KeyCode.UpArrow || key.keyCode == KeyCode.DownArrow))
            {
                var index = shown.FindIndex(a => a.id == selectedAsset);
                index = index < 0 ? 0 : Mathf.Clamp(index + (key.keyCode == KeyCode.DownArrow ? 1 : -1), 0, shown.Count - 1);
                selectedAsset = shown[index].id;
                boothMessage = folderMessage = assemblyMessage = null;
                key.Use();
                GUIUtility.ExitGUI();
            }
            assetListScroll = EditorGUILayout.BeginScrollView(assetListScroll);
            if (shown.Count == 0) EditorGUILayout.HelpBox("찾는 에셋이 없어요. 검색어나 종류를 바꿔 보세요.", MessageType.None);
            foreach (var asset in shown)
            {
                var selected = asset.id == selectedAsset;
                var rect = EditorGUILayout.BeginHorizontal(EditorStyles.helpBox);
                Highlight(rect, selected);
                DrawThumbnail(AssetTexture(asset), 36, KindName(asset.kind));
                using (new EditorGUILayout.VerticalScope())
                {
                    ClippedLabel(asset.name, selected ? EditorStyles.boldLabel : EditorStyles.label);
                    var (bytes, _) = AssetFolders.Size(asset);
                    using (new EditorGUILayout.HorizontalScope())
                    {
                        DrawBadge(KindName(asset.kind));
                        if (asset.boothId > 0) DrawBadge("Booth", "good", "Booth 상품과 연결됨");
                        else DrawBadge("미연결", "warn", "Booth 상품과 아직 연결하지 않음");
                        GUILayout.Label(AssetFolders.FormatSize(bytes), EditorStyles.miniLabel);
                        GUILayout.FlexibleSpace();
                    }
                }
                EditorGUILayout.EndHorizontal();
                if (Event.current.type == EventType.MouseDown && rect.Contains(Event.current.mousePosition))
                {
                    if (selectedAsset != asset.id)
                    {
                        selectedAsset = asset.id;
                        boothMessage = folderMessage = assemblyMessage = null;
                    }
                    Event.current.Use();
                    GUIUtility.ExitGUI();
                }
            }
            EditorGUILayout.EndScrollView();
        }

        private static bool Matches(AssetRecord asset, string text)
        {
            var item = AssetStore.Item(asset.boothId);
            return asset.name.IndexOf(text, StringComparison.CurrentCultureIgnoreCase) >= 0 ||
                   asset.boothName.IndexOf(text, StringComparison.CurrentCultureIgnoreCase) >= 0 ||
                   item != null && (item.shop.IndexOf(text, StringComparison.CurrentCultureIgnoreCase) >= 0 ||
                                    item.tags.Any(t => t.IndexOf(text, StringComparison.CurrentCultureIgnoreCase) >= 0));
        }

        // The Booth image when linked, otherwise the preview of the asset's first prefab.
        private Texture AssetTexture(AssetRecord asset)
        {
            var item = AssetStore.Item(asset.boothId);
            if (item != null && item.thumbnail.Length > 0)
            {
                var booth = AssetStore.Thumbnail(item.thumbnail, Repaint);
                if (booth) return booth;
            }
            prefabCache = prefabCache ?? new Dictionary<string, GameObject>();
            if (!prefabCache.TryGetValue(asset.id, out var prefab))
                prefabCache[asset.id] = prefab = AssetFolders.Prefabs(asset).OrderBy(p => AssetDatabase.GetAssetPath(p).Count(c => c == '/')).FirstOrDefault();
            if (!prefab) return null;
            var preview = AssetPreview.GetAssetPreview(prefab);
            if (!preview && AssetPreview.IsLoadingAssetPreview(prefab.GetInstanceID())) Repaint();
            return preview ? preview : AssetPreview.GetMiniThumbnail(prefab);
        }

        private void DrawAssetDetail(AssetRecord asset)
        {
            using (new EditorGUILayout.HorizontalScope())
            {
                DrawThumbnail(AssetTexture(asset), 72, KindName(asset.kind));
                using (new EditorGUILayout.VerticalScope())
                {
                    EditorGUI.BeginChangeCheck();
                    var name = EditorGUILayout.DelayedTextField("이름", asset.name);
                    var kind = (AssetKind)EditorGUILayout.Popup("종류", (int)asset.kind, KindNames);
                    if (EditorGUI.EndChangeCheck())
                    {
                        if (!string.IsNullOrWhiteSpace(name)) asset.name = name.Trim();
                        asset.kind = kind;
                        AssetStore.SaveProject();
                    }
                    var (bytes, files) = AssetFolders.Size(asset);
                    GUILayout.Label($"파일 {files}개 · {AssetFolders.FormatSize(bytes)}" + (asset.package.Length > 0 ? $" · 가져온 패키지: {asset.package}" : ""),
                        EditorStyles.wordWrappedMiniLabel);
                }
            }
            DrawBoothSection(asset);
            DrawFolderSection(asset);
            DrawAssemblySection(asset);

            GUILayout.Space(16);
            using (new EditorGUILayout.HorizontalScope())
            {
                GUILayout.FlexibleSpace();
                if (GUILayout.Button(new GUIContent("에셋 목록에서 빼기", "에셋 지정만 풀어요. 파일은 지우지 않아요."), GUILayout.Width(140)) &&
                    EditorUtility.DisplayDialog("에셋 목록에서 빼기", $"‘{asset.name}’을(를) 에셋 목록에서 뺄까요?\n파일은 지우지 않고, Booth 연결과 폴더 지정만 사라져요.", "빼기", "취소"))
                {
                    AssetFolders.Delete(asset);
                    selectedAsset = null;
                    GUIUtility.ExitGUI();
                }
            }
        }

        // ---- Booth ----

        private void DrawBoothSection(AssetRecord asset)
        {
            Section("Booth");
            var item = AssetStore.Item(asset.boothId);
            if (asset.boothId > 0)
            {
                using (new EditorGUILayout.HorizontalScope(EditorStyles.helpBox))
                {
                    DrawThumbnail(item != null ? AssetStore.Thumbnail(item.thumbnail, Repaint) : null, 56, "Booth");
                    using (new EditorGUILayout.VerticalScope())
                    {
                        GUILayout.Label(item?.name.Length > 0 ? item.name : asset.boothName.Length > 0 ? asset.boothName : $"상품 {asset.boothId}", WrappedLabel);
                        if (item != null && item.shop.Length > 0) GUILayout.Label(item.shop, EditorStyles.miniLabel);
                        if (item == null || item.name.Length == 0) GUILayout.Label("Booth에서 상품 정보를 받지 못해 번호로만 연결했어요.", EditorStyles.wordWrappedMiniLabel);
                        using (new EditorGUILayout.HorizontalScope())
                        {
                            if (GUILayout.Button("Booth 페이지 열기", GUILayout.Width(120))) Application.OpenURL("https://booth.pm/ja/items/" + asset.boothId);
                            if (GUILayout.Button("다른 상품으로 바꾸기", GUILayout.Width(130)))
                            {
                                BoothLinker.Unlink(asset);
                                GUIUtility.ExitGUI();
                            }
                        }
                    }
                }
                return;
            }

            var cache = AssetStore.SearchFor(asset.id);
            var unfinished = cache == null || !cache.done;
            // Started after this GUI pass, so Layout and Repaint draw the same candidates.
            if (unfinished && !BoothLinker.IsSearching(asset.id))
                BoothLinker.SearchSoon(asset.id, asset.name, AssetFolders.ExistingFolders(asset), asset.package);
            if (boothQueryFor != asset.id)
            {
                boothQueryFor = asset.id;
                boothQuery = cache?.query ?? BoothClient.QueryFrom(asset.name);
                boothUrl = "";
            }
            GUILayout.Label("아직 Booth 상품과 연결하지 않았어요. 아래 후보에서 맞는 상품을 고르거나, 직접 검색하거나, 상품 주소를 넣으세요.", EditorStyles.wordWrappedMiniLabel);
            if (unfinished || BoothLinker.IsSearching(asset.id)) EditorGUILayout.HelpBox("Booth에서 찾고 있어요…", MessageType.None);
            else if (cache != null && cache.error.Length > 0) EditorGUILayout.HelpBox(cache.error, MessageType.Warning);
            else if (cache != null && cache.results.Count == 0) EditorGUILayout.HelpBox($"‘{cache.query}’(으)로 찾은 상품이 없어요. 검색어를 바꾸거나 주소를 넣으세요.", MessageType.None);
            if (cache != null)
                foreach (var candidate in cache.results.Take(8).ToList())
                {
                    using (new EditorGUILayout.HorizontalScope(EditorStyles.helpBox))
                    {
                        DrawThumbnail(AssetStore.Thumbnail(candidate.thumbnail, Repaint), 48, "Booth");
                        using (new EditorGUILayout.VerticalScope())
                        {
                            GUILayout.Label(candidate.name, WrappedLabel);
                            using (new EditorGUILayout.HorizontalScope())
                            {
                                if (candidate.id == cache.readmeItem) DrawBadge("설명서 링크", "good", "에셋 폴더의 설명서에 적힌 Booth 상품");
                                else if (AssetStore.HintFor(asset.package) == candidate.id || AssetStore.HintFor(asset.name) == candidate.id)
                                    DrawBadge("이전 연결", "good", "다른 프로젝트에서 같은 이름으로 연결한 상품");
                                GUILayout.Label(candidate.shop, EditorStyles.miniLabel);
                                GUILayout.FlexibleSpace();
                            }
                        }
                        using (new EditorGUILayout.VerticalScope(GUILayout.Width(64)))
                        {
                            if (GUILayout.Button("연결"))
                            {
                                BoothLinker.Link(asset, candidate);
                                boothMessage = null;
                                GUIUtility.ExitGUI();
                            }
                            if (GUILayout.Button(new GUIContent("보기", "브라우저에서 상품 페이지를 열어 확인해요."), EditorStyles.miniButton))
                                Application.OpenURL(candidate.Url);
                        }
                    }
                }
            if (cache != null && cache.results.Count > 8) GUILayout.Label($"후보 {cache.results.Count - 8}개가 더 있어요. 검색어를 좁혀 보세요.", EditorStyles.miniLabel);

            using (new EditorGUILayout.HorizontalScope())
            {
                boothQuery = EditorGUILayout.TextField("직접 검색", boothQuery);
                using (new EditorGUI.DisabledScope(BoothLinker.IsSearching(asset.id) || string.IsNullOrWhiteSpace(boothQuery)))
                    if (GUILayout.Button("검색", GUILayout.Width(56)))
                    {
                        BoothLinker.Search(asset.id, boothQuery.Trim(), AssetFolders.ExistingFolders(asset), new[] { asset.package, asset.name }, false);
                        GUIUtility.ExitGUI();
                    }
            }
            using (new EditorGUILayout.HorizontalScope())
            {
                boothUrl = EditorGUILayout.TextField(new GUIContent("상품 주소", "booth.pm 상품 주소 또는 상품 번호"), boothUrl);
                var id = BoothClient.ParseItemId(boothUrl);
                using (new EditorGUI.DisabledScope(id <= 0))
                    if (GUILayout.Button(new GUIContent("연결", id <= 0 ? "Booth 상품 주소나 번호를 넣으세요." : $"상품 {id}에 연결해요."), GUILayout.Width(56)))
                    {
                        boothMessage = "상품 정보를 받고 있어요…";
                        boothMessageType = MessageType.None;
                        BoothLinker.LinkById(asset, id, error =>
                        {
                            boothMessage = error;
                            boothMessageType = MessageType.Warning;
                            Repaint();
                        });
                        GUIUtility.ExitGUI();
                    }
            }
            if (!string.IsNullOrEmpty(boothMessage)) EditorGUILayout.HelpBox(boothMessage, boothMessageType);
        }

        // ---- Folders ----

        private void DrawFolderSection(AssetRecord asset)
        {
            Section("폴더");
            foreach (var guid in asset.folders.Concat(asset.sharedFolders).ToList())
            {
                var path = AssetDatabase.GUIDToAssetPath(guid);
                var shared = asset.sharedFolders.Contains(guid);
                using (new EditorGUILayout.HorizontalScope(EditorStyles.helpBox))
                {
                    GUILayout.Label(EditorGUIUtility.IconContent("Folder Icon"), GUILayout.Width(18), GUILayout.Height(18));
                    if (path.Length == 0 || !AssetDatabase.IsValidFolder(path)) GUILayout.Label("⚠ 폴더를 찾지 못했어요(지웠거나 프로젝트 밖으로 옮김)", EditorStyles.miniLabel);
                    else ClippedLabel(path, EditorStyles.label);
                    if (shared) DrawBadge("공용", "", "여러 에셋이 함께 쓰는 폴더");
                    if (GUILayout.Button("보기", EditorStyles.miniButton, GUILayout.Width(40)) && path.Length > 0)
                        EditorGUIUtility.PingObject(AssetDatabase.LoadAssetAtPath<DefaultAsset>(path));
                    if (GUILayout.Button(new GUIContent("빼기", "이 폴더를 에셋에서 빼요. 파일은 지우지 않아요."), EditorStyles.miniButton, GUILayout.Width(40)))
                    {
                        AssetFolders.RemoveFolder(asset, guid);
                        GUIUtility.ExitGUI();
                    }
                }
            }
            if (asset.folders.Count == 0) EditorGUILayout.HelpBox("이 에셋의 폴더가 없어요. Project 창에서 폴더를 고른 뒤 ‘고른 폴더 넣기’를 누르세요.", MessageType.Warning);
            var selected = Selection.assetGUIDs.Select(AssetDatabase.GUIDToAssetPath).Where(AssetDatabase.IsValidFolder).ToList();
            using (new EditorGUILayout.HorizontalScope())
            {
                var reason = selected.Count == 0 ? "Project 창에서 폴더를 먼저 고르세요." : null;
                using (new EditorGUI.DisabledScope(reason != null))
                {
                    if (GUILayout.Button(new GUIContent($"고른 폴더 넣기 ({selected.Count})", reason ?? "이 에셋만 쓰는 폴더로 넣어요.")))
                        AddFolders(asset, selected, false);
                    if (GUILayout.Button(new GUIContent("공용 폴더로 넣기", reason ?? "같은 샵의 Common 폴더처럼 여러 에셋이 함께 쓰는 폴더로 넣어요.")))
                        AddFolders(asset, selected, true);
                }
            }
            if (!string.IsNullOrEmpty(folderMessage)) EditorGUILayout.HelpBox(folderMessage, MessageType.Warning);
        }

        private void AddFolders(AssetRecord asset, List<string> paths, bool shared)
        {
            var problems = new List<string>();
            foreach (var path in paths)
            {
                try { AssetFolders.AddFolder(asset, path, shared); }
                catch (InvalidOperationException e) { problems.Add($"{Path.GetFileName(path)}: {e.Message}"); }
            }
            folderMessage = problems.Count > 0 ? string.Join("\n", problems) : null;
            prefabCache = null;
            GUIUtility.ExitGUI();
        }
    }
}
