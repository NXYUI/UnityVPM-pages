#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;
using VRC.SDK3.Avatars.Components;
using Object = UnityEngine.Object;

namespace AvatarMenuTools
{
    // Drag a favorite or folder by its ≡ handle, or a built menu item from the left list: drop on the upper or lower
    // half of a row to place it before or after, on the middle of a folder to put it inside, or below the list to put it
    // at the end of the "추가할 위치" folder.
    internal sealed partial class AvatarCustomizerWindow
    {
        private const string DragKey = "NXYUI.AvatarCustomizer.Entry";
        private const string SourceKey = "NXYUI.AvatarCustomizer.Source";

        private sealed class SourcePayload
        {
            public VRCAvatarDescriptor Avatar;
            public FavoriteMenuKey[] Keys;
        }

        private bool endHover;

        private sealed class DragPayload
        {
            public VRCAvatarDescriptor Avatar;
            public int MenuIndex;
            public FavoriteMenuEntry Entry;
        }

        private enum DropZone { Before, Inside, After }

        private FavoriteMenuEntry dropTarget;
        private DropZone dropZone;

        private void DragHandle(Rect handle, FavoriteMenuEntry entry)
        {
            var evt = Event.current;
            GUI.Label(handle, new GUIContent("≡", "끌어서 순서를 바꾸거나 폴더 가운데에 놓아 넣습니다."), EditorStyles.centeredGreyMiniLabel);
            EditorGUIUtility.AddCursorRect(handle, MouseCursor.Pan);
            if (evt.type != EventType.MouseDrag || evt.button != 0 || !handle.Contains(evt.mousePosition) || GUIUtility.hotControl != 0) return;
            DragAndDrop.PrepareStartDrag();
            DragAndDrop.SetGenericData(DragKey, new DragPayload { Avatar = avatar, MenuIndex = menuIndex, Entry = entry });
            DragAndDrop.objectReferences = Array.Empty<Object>();
            DragAndDrop.StartDrag(string.IsNullOrWhiteSpace(entry.label) ? "즐겨찾기" : entry.label);
            evt.Use();
        }

        // True when target sits inside folder (or is it), so a folder is never dropped into itself.
        private static bool IsWithin(IReadOnlyList<FavoriteMenuEntry> entries, FavoriteMenuEntry target, string folder)
        {
            var seen = new HashSet<string>();
            for (var node = target; node != null; node = Find(entries, node.Parent))
            {
                if (node.IsFolder && node.folderId == folder) return true;
                if (!seen.Add(node.Parent) || node.Parent.Length == 0) return false;
            }
            return false;
        }

        private static FavoriteMenuEntry Find(IReadOnlyList<FavoriteMenuEntry> entries, string folderId)
        {
            foreach (var e in entries) if (e != null && e.IsFolder && e.folderId == folderId) return e;
            return null;
        }

        private FavoriteMenuEntry DraggedEntry() =>
            DragAndDrop.GetGenericData(DragKey) is DragPayload p && p.Avatar == avatar && p.MenuIndex == menuIndex ? p.Entry : null;

        private FavoriteMenuKey[] DraggedSources() =>
            DragAndDrop.GetGenericData(SourceKey) is SourcePayload s && s.Avatar == avatar ? s.Keys : null;

        // Dragging a checked row carries every checked row, in list order.
        private void SourceDrag(Rect row, FavoriteMenuKey key, MenuView view)
        {
            var evt = Event.current;
            if (evt.type != EventType.MouseDrag || evt.button != 0 || !row.Contains(evt.mousePosition)) return;
            var keys = (batchSources.Contains(key) ? catalogue.Where(batchSources.Contains) : new[] { key })
                .Where(k => view.Resolve(k) != null).ToArray();
            if (keys.Length == 0) return;
            GUIUtility.hotControl = 0;
            DragAndDrop.PrepareStartDrag();
            DragAndDrop.SetGenericData(SourceKey, new SourcePayload { Avatar = avatar, Keys = keys });
            DragAndDrop.objectReferences = Array.Empty<Object>();
            DragAndDrop.StartDrag(keys.Length == 1 ? view.Name(keys[0]) : $"{keys.Length}개 항목");
            evt.Use();
        }

        // Adds shortcuts to the folder, skipping items the folder already has. anchor null appends.
        private void AddSources(FavoriteMenuKey[] keys, string parent, FavoriteMenuEntry anchor, bool after)
        {
            var config = avatar.GetComponent<AvatarCustomizer>();
            var view = new MenuView(catalogue, config);
            var current = config ? config.GetMenu(menuIndex)?.entries : null;
            var present = current?.Where(e => e != null && !e.IsFolder && e.Parent == parent)
                .Select(e => view.Resolve(e.source)?.sharedControl ?? 0).ToHashSet() ?? new HashSet<int>();
            var added = keys.Where(k => view.Resolve(k) != null && present.Add(k.sharedControl))
                .Select(k => new FavoriteMenuEntry { source = k, parentId = parent }).ToList();
            if (added.Count == 0)
            {
                status = "끌어 놓은 항목은 이미 그 폴더에 있어요.";
                statusType = MessageType.Info;
                return;
            }
            ChangeEntries("Drag favorites from menu", list =>
            {
                int at = anchor == null ? -1 : list.IndexOf(anchor);
                list.InsertRange(at < 0 ? list.Count : after ? at + 1 : at, added);
                Reveal(parent, list);
            });
            foreach (var key in keys) batchSources.Remove(key);
            if (added.Count < keys.Length)
            {
                status = $"{added.Count}개를 추가했어요. 그 폴더에 이미 있던 {keys.Length - added.Count}개는 건너뛰었어요.";
                statusType = MessageType.Info;
            }
        }

        // The area below the list: drops go to the end of the "추가할 위치" folder.
        private void EndDrop(Rect area, IReadOnlyList<FavoriteMenuEntry> entries)
        {
            var evt = Event.current;
            var moving = DraggedEntry();
            var adding = DraggedSources();
            if (moving == null && adding == null) return;
            if (evt.type == EventType.Repaint && endHover)
                EditorGUI.DrawRect(area, new Color(.33f, .67f, .93f, .18f));
            if (evt.type != EventType.DragUpdated && evt.type != EventType.DragPerform) return;
            if (!area.Contains(evt.mousePosition))
            {
                if (endHover) { endHover = false; Repaint(); }
                return;
            }
            string parent = addParent;
            bool valid = adding != null || !(moving.IsFolder && IsWithin(entries, Find(entries, parent), moving.folderId));
            DragAndDrop.visualMode = !valid ? DragAndDropVisualMode.Rejected
                : adding != null ? DragAndDropVisualMode.Copy : DragAndDropVisualMode.Move;
            endHover = valid;
            dropTarget = null;
            if (evt.type == EventType.DragPerform && valid)
            {
                DragAndDrop.AcceptDrag();
                if (adding != null) AddSources(adding, parent, null, false);
                else ChangeEntries("Drag favorites item", list =>
                {
                    if (!list.Remove(moving)) return;
                    moving.parentId = parent;
                    list.Add(moving);
                    Reveal(parent, list);
                });
                endHover = false;
                DragAndDrop.SetGenericData(DragKey, null);
                DragAndDrop.SetGenericData(SourceKey, null);
            }
            evt.Use();
            Repaint();
        }

        private void DropTarget(Rect row, FavoriteMenuEntry entry, IReadOnlyList<FavoriteMenuEntry> entries)
        {
            var evt = Event.current;
            var moving = DraggedEntry();
            var adding = DraggedSources();
            if (moving == null && adding == null) return;
            if (evt.type == EventType.Repaint && dropTarget == entry)
            {
                var color = new Color(.33f, .67f, .93f, 1f);
                if (dropZone == DropZone.Inside) EditorGUI.DrawRect(new Rect(row.x, row.y, row.width, row.height), new Color(color.r, color.g, color.b, .18f));
                else EditorGUI.DrawRect(new Rect(row.x, dropZone == DropZone.Before ? row.y - 1f : row.yMax - 1f, row.width, 2f), color);
            }
            if ((evt.type != EventType.DragUpdated && evt.type != EventType.DragPerform) || !row.Contains(evt.mousePosition)) return;
            float t = (evt.mousePosition.y - row.y) / Mathf.Max(1f, row.height);
            var zone = entry.IsFolder && t > .3f && t < .7f ? DropZone.Inside : t < .5f ? DropZone.Before : DropZone.After;
            bool valid = adding != null || (moving != entry && !(moving.IsFolder && IsWithin(entries, entry, moving.folderId)));
            DragAndDrop.visualMode = !valid ? DragAndDropVisualMode.Rejected
                : adding != null ? DragAndDropVisualMode.Copy : DragAndDropVisualMode.Move;
            dropTarget = valid ? entry : null;
            dropZone = zone;
            endHover = false;
            if (evt.type == EventType.DragPerform && valid && adding != null)
            {
                DragAndDrop.AcceptDrag();
                if (zone == DropZone.Inside) AddSources(adding, entry.folderId, null, false);
                else AddSources(adding, entry.Parent, entry, zone == DropZone.After);
                if (zone == DropZone.Inside) collapsed.Remove(entry.folderId);
                dropTarget = null;
                DragAndDrop.SetGenericData(SourceKey, null);
            }
            else if (evt.type == EventType.DragPerform && valid)
            {
                DragAndDrop.AcceptDrag();
                ChangeEntries("Drag favorites item", list =>
                {
                    if (!list.Remove(moving)) return;
                    if (zone == DropZone.Inside)
                    {
                        moving.parentId = entry.folderId;
                        list.Add(moving);
                    }
                    else
                    {
                        moving.parentId = entry.Parent;
                        int at = list.IndexOf(entry);
                        list.Insert(at < 0 ? list.Count : zone == DropZone.Before ? at : at + 1, moving);
                    }
                });
                if (zone == DropZone.Inside) collapsed.Remove(entry.folderId);
                dropTarget = null;
                DragAndDrop.SetGenericData(DragKey, null);
            }
            evt.Use();
            Repaint();
        }
    }
}
#endif
