#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using Control = VRC.SDK3.Avatars.ScriptableObjects.VRCExpressionsMenu.Control;

namespace AvatarMenuTools
{
    // The blendshape tab (edit weights on the selected avatar or the whole scene, with a radial knob) and default values
    // in the favorites tab. A blendshape becomes an in-game radial or toggle by adding a control, which goes straight
    // into the favorites menu being edited.
    internal sealed partial class AvatarCustomizerWindow
    {
        private static readonly string[] ShapeScopes = { "이 아바타", "씬 전체" };
        private static readonly int KnobHint = "NXYUI.AvatarCustomizer.Knob".GetHashCode();

        [SerializeField] private int shapeScope;
        [SerializeField] private string shapeSearch = "";
        [SerializeField] private bool shapeNonZero;
        [SerializeField] private bool shapeHideLocked;
        private readonly Dictionary<Transform, BlendshapeConflicts> conflictCache = new Dictionary<Transform, BlendshapeConflicts>();
        private Vector2 shapeScroll, shapeControlsScroll;
        private SkinnedMeshRenderer[] shapeRenderers = Array.Empty<SkinnedMeshRenderer>();
        private bool shapeRenderersDirty = true;
        private readonly HashSet<SkinnedMeshRenderer> shapeOpen = new HashSet<SkinnedMeshRenderer>();
        private SkinnedMeshRenderer shapeRenderer;
        private string shapeName;
        // Expression parameter defaults from the last read, to show what a favorite starts at today.
        private Dictionary<string, float> parameterDefaults = new Dictionary<string, float>();

        private void OnEnable() => EditorApplication.hierarchyChanged += MarkShapesDirty;
        private void OnDisable() => EditorApplication.hierarchyChanged -= MarkShapesDirty;

        private void MarkShapesDirty()
        {
            shapeRenderersDirty = true;
            if (tab == 2) Repaint();
        }

        // Component settings can change without a hierarchy change; read them again when the window comes back.
        private void OnFocus() => shapeRenderersDirty = true;

        // What else changes blendshapes in the avatar (or scene root) the renderer belongs to.
        private BlendshapeConflicts ConflictsFor(Component c)
        {
            var descriptor = c.GetComponentInParent<VRC.SDK3.Avatars.Components.VRCAvatarDescriptor>(true);
            var root = descriptor ? descriptor.transform : c.transform.root;
            if (!conflictCache.TryGetValue(root, out var found)) conflictCache.Add(root, found = BlendshapeConflicts.Scan(root));
            return found;
        }

        // --- favorites tab -------------------------------------------------------------------------------------------

        private const string DefaultTip = "아바타를 처음 불러오거나 초기화할 때의 값이에요. 저장되는(Saved) 파라미터는 사용자가 바꾼 값이 유지되고, " +
                                          "같은 파라미터를 쓰는 원래 메뉴에도 똑같이 적용돼요.";

        // Index of the stored default for this menu item (matched like favorites: by path and parameter), or -1.
        private static int DefaultIndex(MenuView view, AvatarCustomizer config, FavoriteMenuKey key)
        {
            var list = config ? config.defaultOverrides : null;
            if (list == null || key == null) return -1;
            var target = view.Resolve(key);
            for (int i = 0; i < list.Count; i++)
                if (SameItem(view, list[i]?.source, key, target)) return i;
            return -1;
        }

        private static bool SameItem(MenuView view, FavoriteMenuKey source, FavoriteMenuKey key, FavoriteMenuKey target)
        {
            if (source == null) return false;
            if (target != null && view.Resolve(source) is FavoriteMenuKey resolved && resolved.sharedControl == target.sharedControl) return true;
            return source.SamePath(key) && source.SameBinding(key);
        }

        private void SetDefault(MenuView view, FavoriteMenuKey key, bool on, float value)
        {
            var target = view.Resolve(key);
            Change("Change menu default", c =>
            {
                c.defaultOverrides ??= new List<MenuDefaultOverride>();
                c.defaultOverrides.RemoveAll(o => SameItem(view, o?.source, key, target));
                if (on) c.defaultOverrides.Add(new MenuDefaultOverride { source = target ?? key, value = value });
                // 2.0.0 kept the default on the favorite itself; it now lives with the other defaults.
                foreach (var menu in c.AllMenus())
                    foreach (var e in menu.entries ?? new List<FavoriteMenuEntry>())
                        if (e != null && e.overrideDefault && SameItem(view, e.source, key, target)) e.overrideDefault = false;
            });
        }

        // Starting value of a toggle or radial on the built avatar. legacy: the favorite that may hold a 2.0.0 default.
        private void DrawDefault(MenuView view, AvatarCustomizer config, FavoriteMenuKey key, FavoriteMenuEntry legacy)
        {
            if (key == null || (key.type != Control.ControlType.Toggle && key.type != Control.ControlType.RadialPuppet)) return;
            bool toggle = key.type == Control.ControlType.Toggle;
            int stored = DefaultIndex(view, config, key);
            bool on = stored >= 0 || (legacy != null && legacy.overrideDefault);
            float current = stored >= 0 ? config.defaultOverrides[stored].value : on ? legacy.defaultValue : 0f;
            string parameter = toggle ? key.parameter : key.subParameters?.FirstOrDefault();
            bool known = !string.IsNullOrEmpty(parameter) && parameterDefaults.ContainsKey(parameter);
            float original = known ? parameterDefaults[parameter] : 0f;
            using (new EditorGUILayout.HorizontalScope())
            {
                GUILayout.Label(new GUIContent("기본값", DefaultTip), EditorStyles.miniLabel, GUILayout.Width(38));
                bool nextOn = on;
                float next = current;
                if (toggle)
                {
                    int now = !on ? 0 : current >= .5f ? 2 : 1;
                    int choice = EditorGUILayout.Popup(now, new[] { "원래대로", "꺼짐", "켜짐" }, EditorStyles.miniPullDown, GUILayout.Width(72));
                    nextOn = choice != 0;
                    next = choice == 2 ? 1f : 0f;
                }
                else
                {
                    nextOn = GUILayout.Toggle(on, new GUIContent("", "켜면 오른쪽 값으로 시작해요."), GUILayout.Width(14));
                    float percent;
                    using (new EditorGUI.DisabledScope(!nextOn))
                        percent = EditorGUILayout.Slider(current * 100f, 0f, 100f, GUILayout.MinWidth(90));
                    // Turning it on starts from what the avatar uses today.
                    next = nextOn && !on && known ? original : Mathf.Clamp01(percent / 100f);
                }
                if (nextOn != on || (nextOn && !Mathf.Approximately(next, current))) SetDefault(view, key, nextOn, next);
                if (known)
                    GUILayout.Label(new GUIContent("원래 " + (toggle ? (Mathf.Approximately(original, key.value) ? "켜짐" : "꺼짐") : $"{original * 100f:0}%"),
                        $"‘{parameter}’의 지금 기본값"), EditorStyles.miniLabel, GUILayout.Width(60));
            }
        }

        private readonly HashSet<string> openSubmenus = new HashSet<string>();

        private static string TypeLabel(Control.ControlType type) => type switch
        {
            Control.ControlType.Toggle => "토글",
            Control.ControlType.Button => "버튼",
            Control.ControlType.SubMenu => "서브 메뉴",
            Control.ControlType.RadialPuppet => "래디얼",
            Control.ControlType.TwoAxisPuppet => "2축",
            Control.ControlType.FourAxisPuppet => "4축",
            _ => type.ToString(),
        };

        // The items inside a submenu favorite, so their defaults can be set without adding each one.
        private void DrawSubmenuItems(MenuView view, AvatarCustomizer config, FavoriteMenuKey parent, string id, int depth)
        {
            int length = parent.path?.Length ?? 0;
            var children = catalogue.Where(k => k.path != null && k.path.Length == length + 1 &&
                                                k.path.Take(length).SequenceEqual(parent.path, StringComparer.Ordinal)).ToArray();
            if (children.Length == 0 || depth > 8) return;
            bool open = openSubmenus.Contains(id);
            using (new EditorGUILayout.HorizontalScope())
            {
                GUILayout.Space(depth * 12f);
                bool next = EditorGUILayout.Foldout(open, new GUIContent($"안의 항목 {children.Length}개",
                    "이 서브 메뉴 안의 토글과 래디얼 기본값을 여기서 정할 수 있어요."), true);
                if (next != open)
                {
                    if (next) openSubmenus.Add(id);
                    else openSubmenus.Remove(id);
                }
            }
            if (!open) return;
            foreach (var child in children)
                using (new EditorGUILayout.HorizontalScope())
                {
                    GUILayout.Space(depth * 12f + 14f);
                    using (new EditorGUILayout.VerticalScope())
                    {
                        string name = view.Name(child);
                        EditorGUILayout.LabelField(new GUIContent($"{(string.IsNullOrWhiteSpace(name) ? "(이름 없음)" : name)} · {TypeLabel(child.type)}",
                            FavoriteMenuBuilder.Describe(child)), EditorStyles.miniBoldLabel);
                        DrawDefault(view, config, child, null);
                        if (child.type == Control.ControlType.SubMenu)
                            DrawSubmenuItems(view, config, child, id + "\u001f" + child.Name, depth + 1);
                    }
                }
        }

        private void DrawShapeEntry(FavoriteMenuEntry entry)
        {
            var config = avatar.GetComponent<AvatarCustomizer>();
            var shape = config ? config.FindShape(entry.shapeId) : null;
            string problem = BlendshapeControlBuilder.Problem(shape, avatar.transform, ConflictsFor(avatar));
            string text = (problem != null ? "⚠ " + problem + " · " : "") + (shape == null ? "빌드에서 제외돼요" :
                $"블렌드쉐이프 {(shape.type == BlendshapeControlType.Radial ? "래디얼" : "토글")} · {RendererLabel(shape.renderer)} / {shape.blendshape}");
            using (new EditorGUILayout.HorizontalScope())
            {
                EditorGUILayout.LabelField(new GUIContent(text, text), EditorStyles.miniLabel);
                using (new EditorGUI.DisabledScope(shape == null))
                    if (GUILayout.Button(new GUIContent("편집", "블렌드쉐이프 탭에서 이 컨트롤을 엽니다."), GUILayout.Width(40)))
                    {
                        ShowShape(shape);
                        GUIUtility.ExitGUI();
                    }
            }
            if (shape != null) DrawShapeDefault(shape);
        }

        private void DrawShapeDefault(BlendshapeControl shape)
        {
            using (new EditorGUILayout.HorizontalScope())
            {
                GUILayout.Label(new GUIContent("기본값", "아바타를 처음 불러오거나 초기화할 때의 값이에요. ‘저장’을 켠 컨트롤은 사용자가 바꾼 값이 유지돼요."),
                    EditorStyles.miniLabel, GUILayout.Width(38));
                float value;
                if (shape.type == BlendshapeControlType.Toggle)
                    value = EditorGUILayout.Popup(shape.defaultValue >= .5f ? 1 : 0, new[] { "꺼짐", "켜짐" }, EditorStyles.miniPullDown, GUILayout.Width(72));
                else value = EditorGUILayout.Slider(shape.defaultValue * 100f, 0f, 100f, GUILayout.MinWidth(90)) / 100f;
                if (!Mathf.Approximately(value, shape.defaultValue))
                    EditShape(shape.id, "Change blendshape default", s => s.defaultValue = Mathf.Clamp01(value));
            }
        }

        private void EditShape(string id, string action, Action<BlendshapeControl> edit) =>
            Change(action, c => { var s = c.FindShape(id); if (s != null) edit(s); });

        private static List<FavoriteMenuEntry> EntriesOf(AvatarCustomizer c, int index)
        {
            if (index > 0 && c.GetMenu(index) is FavoriteMenuGroup group) return group.entries ??= new List<FavoriteMenuEntry>();
            return c.entries ??= new List<FavoriteMenuEntry>();
        }

        // --- blendshape tab ------------------------------------------------------------------------------------------

        private void DrawBlendshapes(AvatarCustomizer config)
        {
            using (new EditorGUILayout.HorizontalScope())
            {
                int scope = EditorGUILayout.Popup(shapeScope, ShapeScopes, GUILayout.Width(84));
                if (scope != shapeScope) { shapeScope = scope; shapeRenderersDirty = true; }
                shapeSearch = EditorGUILayout.TextField(shapeSearch, EditorStyles.toolbarSearchField);
                shapeNonZero = GUILayout.Toggle(shapeNonZero, new GUIContent("0 아닌 값만", "값이 0이 아닌 블렌드쉐이프만 보여 줘요."),
                    EditorStyles.miniButton, GUILayout.Width(74));
                shapeHideLocked = GUILayout.Toggle(shapeHideLocked, new GUIContent("잠긴 것 숨기기",
                    "다른 컴포넌트(립싱크·눈 깜빡임, Shape Changer, Blendshape Sync, 최적화 도구 등)가 바꾸는 블렌드쉐이프는 꼬이지 않도록 잠가 둬요. 켜면 목록에서 숨겨요."),
                    EditorStyles.miniButton, GUILayout.Width(84));
                if (GUILayout.Button("새로고침", EditorStyles.miniButton, GUILayout.Width(56))) shapeRenderersDirty = true;
            }
            if (shapeRenderersDirty && Event.current.type == EventType.Layout) RefreshShapeRenderers();
            EditorGUILayout.LabelField(shapeScope == 0
                ? "선택한 아바타 안의 오브젝트예요. 이름을 누르면 Hierarchy에서 그 오브젝트를 선택해요."
                : "열린 씬의 모든 오브젝트예요. 게임 메뉴 컨트롤은 위에서 고른 아바타 안의 오브젝트에만 만들 수 있어요.",
                EditorStyles.wordWrappedMiniLabel);
            using (new EditorGUILayout.HorizontalScope())
            {
                using (new EditorGUILayout.VerticalScope(GUILayout.Width(position.width * .55f)))
                    DrawShapeList(config);
                using (new EditorGUILayout.VerticalScope(GUILayout.ExpandWidth(true)))
                {
                    DrawShapeDetail(config);
                    DrawShapeControls(config);
                }
            }
        }

        private void RefreshShapeRenderers()
        {
            shapeRenderersDirty = false;
            conflictCache.Clear();
            IEnumerable<SkinnedMeshRenderer> found;
            if (shapeScope == 0) found = avatar ? avatar.GetComponentsInChildren<SkinnedMeshRenderer>(true) : Enumerable.Empty<SkinnedMeshRenderer>();
            else
                found = Enumerable.Range(0, SceneManager.sceneCount).Select(SceneManager.GetSceneAt)
                    .Where(s => s.isLoaded && !EditorSceneManager.IsPreviewScene(s))
                    .SelectMany(s => s.GetRootGameObjects()).SelectMany(r => r.GetComponentsInChildren<SkinnedMeshRenderer>(true));
            shapeRenderers = found.Where(r => r && r.sharedMesh && r.sharedMesh.blendShapeCount > 0 && (r.hideFlags & HideFlags.HideInHierarchy) == 0)
                .OrderBy(HierarchyPath, StringComparer.OrdinalIgnoreCase).ToArray();
        }

        private static string HierarchyPath(Component c)
        {
            var names = new List<string>();
            for (var t = c.transform; t; t = t.parent) names.Insert(0, t.name);
            return string.Join("/", names);
        }

        private string RendererLabel(SkinnedMeshRenderer r)
        {
            if (!r) return "(없는 오브젝트)";
            if (avatar && r.transform.IsChildOf(avatar.transform) && r.transform != avatar.transform)
                return AnimationUtility.CalculateTransformPath(r.transform, avatar.transform);
            return HierarchyPath(r);
        }

        private void DrawShapeList(AvatarCustomizer config)
        {
            var terms = (shapeSearch ?? "").Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            bool Matches(string text) => terms.All(term => text.IndexOf(term, StringComparison.OrdinalIgnoreCase) >= 0);
            var controlled = new HashSet<(SkinnedMeshRenderer, string)>((config ? config.blendshapeControls : null)?
                .Where(s => s != null && s.renderer).Select(s => (s.renderer, s.blendshape)) ?? Enumerable.Empty<(SkinnedMeshRenderer, string)>());
            var itemStyle = new GUIStyle(EditorStyles.miniButton) { alignment = TextAnchor.MiddleLeft, clipping = TextClipping.Clip };
            using var scroll = new EditorGUILayout.ScrollViewScope(shapeScroll, GUILayout.ExpandHeight(true));
            shapeScroll = scroll.scrollPosition;
            int shown = 0;
            foreach (var r in shapeRenderers)
            {
                if (!r || !r.sharedMesh) continue;
                var mesh = r.sharedMesh;
                var conflicts = ConflictsFor(r);
                string label = RendererLabel(r);
                bool rendererMatches = terms.Length > 0 && Matches(label);
                var rows = Enumerable.Range(0, mesh.blendShapeCount)
                    .Where(i => (terms.Length == 0 || rendererMatches || Matches(mesh.GetBlendShapeName(i))) &&
                                (!shapeNonZero || Mathf.Abs(r.GetBlendShapeWeight(i)) > .0001f) &&
                                (!shapeHideLocked || conflicts.Blocked(r, mesh.GetBlendShapeName(i)) == null)).ToArray();
                int locked = conflicts.BlockedCount(r);
                if (rows.Length == 0) continue;
                shown++;
                bool filtering = terms.Length > 0 || shapeNonZero;
                bool open = filtering || shapeOpen.Contains(r);
                using (new EditorGUILayout.HorizontalScope())
                {
                    bool next = EditorGUILayout.Foldout(open, new GUIContent($"{label} · {rows.Length}" + (locked > 0 ? $" · 잠김 {locked}" : ""),
                        HierarchyPath(r) + (locked > 0 ? $"\n다른 컴포넌트가 바꾸는 블렌드쉐이프 {locked}개는 잠가 뒀어요." : "")), true);
                    if (next != open && !filtering)
                    {
                        if (next) shapeOpen.Add(r);
                        else shapeOpen.Remove(r);
                    }
                    if (GUILayout.Button(new GUIContent("선택", "Hierarchy에서 이 오브젝트를 선택합니다."), EditorStyles.miniButton, GUILayout.Width(36)))
                        Reveal(r);
                }
                if (!open) continue;
                foreach (int i in rows)
                {
                    string name = mesh.GetBlendShapeName(i);
                    bool selected = r == shapeRenderer && name == shapeName;
                    string blocked = conflicts.Blocked(r, name);
                    string animated = conflicts.Animated(r, name);
                    using (new EditorGUILayout.HorizontalScope())
                    {
                        GUILayout.Space(14);
                        var content = new GUIContent((blocked != null ? "잠김 · " : "") + (controlled.Contains((r, name)) ? "◆ " : "") +
                                                     (animated != null ? "애니 · " : "") + name,
                            name + (blocked != null ? $"\n잠김: {blocked}" : "") +
                            (controlled.Contains((r, name)) ? "\n◆ 게임 메뉴 컨트롤이 있어요." : "") +
                            (animated != null ? $"\n이미 움직이는 애니메이션: {animated}" : "") + "\n누르면 Hierarchy에서 오브젝트를 선택해요.");
                        if (GUILayout.Toggle(selected, content, itemStyle, GUILayout.MinWidth(60), GUILayout.ExpandWidth(true)) && !selected)
                        {
                            shapeRenderer = r;
                            shapeName = name;
                            Reveal(r);
                        }
                        float weight = r.GetBlendShapeWeight(i);
                        float value;
                        using (new EditorGUI.DisabledScope(blocked != null))
                            value = EditorGUILayout.Slider(weight, Mathf.Min(0f, weight), Mathf.Max(100f, weight), GUILayout.Width(150));
                        if (blocked == null && !Mathf.Approximately(value, weight)) SetWeight(r, i, value);
                    }
                }
            }
            if (shown == 0)
                EditorGUILayout.LabelField(shapeRenderers.Length == 0 ? "블렌드쉐이프가 있는 Skinned Mesh Renderer가 없어요." : "조건에 맞는 블렌드쉐이프가 없어요.",
                    EditorStyles.wordWrappedMiniLabel);
        }

        private static void Reveal(SkinnedMeshRenderer r)
        {
            Selection.activeGameObject = r.gameObject;
            EditorGUIUtility.PingObject(r.gameObject);
        }

        private static void SetWeight(SkinnedMeshRenderer r, int index, float value)
        {
            Undo.RecordObject(r, "Change Blendshape");
            r.SetBlendShapeWeight(index, value);
            PrefabUtility.RecordPrefabInstancePropertyModifications(r);
        }

        private void ShowShape(BlendshapeControl shape)
        {
            tab = 2;
            shapeSearch = "";
            shapeNonZero = false;
            if (shape?.renderer && avatar && !shape.renderer.transform.IsChildOf(avatar.transform)) shapeScope = 1;
            else shapeScope = 0;
            shapeRenderersDirty = true;
            shapeRenderer = shape?.renderer;
            shapeName = shape?.blendshape;
            if (shapeRenderer) shapeOpen.Add(shapeRenderer);
        }

        private void DrawShapeDetail(AvatarCustomizer config)
        {
            int index = shapeRenderer && shapeRenderer.sharedMesh ? shapeRenderer.sharedMesh.GetBlendShapeIndex(shapeName ?? "") : -1;
            using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
            {
                if (index < 0)
                {
                    EditorGUILayout.LabelField("왼쪽에서 블렌드쉐이프를 고르면 노브로 값을 바꾸고, 게임 메뉴용 래디얼이나 토글을 만들 수 있어요.",
                        EditorStyles.wordWrappedMiniLabel);
                    return;
                }
                EditorGUILayout.LabelField(new GUIContent(shapeName, shapeName), EditorStyles.boldLabel);
                EditorGUILayout.LabelField(new GUIContent(RendererLabel(shapeRenderer), HierarchyPath(shapeRenderer)), EditorStyles.miniLabel);
                var conflicts = ConflictsFor(shapeRenderer);
                string blocked = conflicts.Blocked(shapeRenderer, shapeName);
                string animated = conflicts.Animated(shapeRenderer, shapeName);
                if (blocked != null)
                    EditorGUILayout.HelpBox($"다른 컴포넌트가 이 블렌드쉐이프를 바꿔요: {blocked}\n꼬이지 않도록 여기서는 값 조절과 게임 메뉴 컨트롤을 막았어요. " +
                                            "그 컴포넌트에서 직접 설정하세요.", MessageType.Warning);
                else if (animated != null)
                    EditorGUILayout.HelpBox($"이미 움직이는 애니메이션이 있어요: {animated}\n여기서 바꾼 값은 그 애니메이션이 쉬는 동안의 기본값이에요. " +
                                            "게임 메뉴 컨트롤을 만들면 메뉴 값이 항상 우선해 그 애니메이션은 이 블렌드쉐이프를 바꾸지 못해요.", MessageType.Info);
                using (new EditorGUI.DisabledScope(blocked != null))
                using (new EditorGUILayout.HorizontalScope())
                {
                    float weight = shapeRenderer.GetBlendShapeWeight(index);
                    var knob = GUILayoutUtility.GetRect(96f, 96f, GUILayout.Width(96f), GUILayout.Height(96f));
                    float turned = Knob(knob, Mathf.Clamp01(weight / 100f), GUIUtility.GetControlID(KnobHint, FocusType.Passive)) * 100f;
                    if (!Mathf.Approximately(turned, Mathf.Clamp(weight, 0f, 100f))) SetWeight(shapeRenderer, index, turned);
                    using (new EditorGUILayout.VerticalScope())
                    {
                        float typed = EditorGUILayout.FloatField("값", shapeRenderer.GetBlendShapeWeight(index));
                        if (!Mathf.Approximately(typed, shapeRenderer.GetBlendShapeWeight(index))) SetWeight(shapeRenderer, index, typed);
                        if (GUILayout.Button("Hierarchy에서 보기")) Reveal(shapeRenderer);
                        bool inside = avatar && shapeRenderer.transform.IsChildOf(avatar.transform);
                        using (new EditorGUI.DisabledScope(!inside))
                        using (new EditorGUILayout.HorizontalScope())
                        {
                            const string tip = "게임 메뉴 컨트롤을 만들고, 지금 편집 중인 즐겨찾기 메뉴의 ‘추가할 위치’에 바로 넣어요.";
                            if (GUILayout.Button(new GUIContent("+ 래디얼", tip + " 0~100%로 값을 돌려요.")))
                                AddShapeControl(config, shapeRenderer, shapeName, BlendshapeControlType.Radial);
                            if (GUILayout.Button(new GUIContent("+ 토글", tip + " 켜고 끌 때의 값을 정해요.")))
                                AddShapeControl(config, shapeRenderer, shapeName, BlendshapeControlType.Toggle);
                        }
                        if (!inside)
                            EditorGUILayout.LabelField("아바타 밖의 오브젝트는 값만 바꿀 수 있어요.", EditorStyles.wordWrappedMiniLabel);
                    }
                }
                if (config && config.blendshapeControls != null && config.blendshapeControls.Any(s => s != null && s.renderer == shapeRenderer && s.blendshape == shapeName))
                    EditorGUILayout.LabelField("게임 메뉴 컨트롤이 있는 블렌드쉐이프예요. 게임에서는 메뉴 값이 이 값을 덮어써요.", EditorStyles.wordWrappedMiniLabel);
            }
        }

        // A VRChat-style radial: 0 at the top, increasing clockwise. Dragging past the top stops at 0 or 100%.
        private static float Knob(Rect rect, float value, int id)
        {
            var evt = Event.current;
            var center = rect.center;
            float radius = Mathf.Min(rect.width, rect.height) * .5f - 2f;
            float Angle(Vector2 point)
            {
                var d = point - center;
                float degrees = Mathf.Atan2(d.x, -d.y) * Mathf.Rad2Deg;
                return (degrees < 0f ? degrees + 360f : degrees) / 360f;
            }
            switch (evt.GetTypeForControl(id))
            {
                case EventType.MouseDown:
                    if (evt.button == 0 && Vector2.Distance(evt.mousePosition, center) <= radius)
                    {
                        GUIUtility.hotControl = id;
                        value = Angle(evt.mousePosition);
                        evt.Use();
                    }
                    break;
                case EventType.MouseDrag:
                    if (GUIUtility.hotControl == id)
                    {
                        float next = Angle(evt.mousePosition);
                        value = Mathf.Abs(next - value) > .5f ? (value > .5f ? 1f : 0f) : next;
                        evt.Use();
                    }
                    break;
                case EventType.MouseUp:
                    if (GUIUtility.hotControl == id)
                    {
                        GUIUtility.hotControl = 0;
                        evt.Use();
                    }
                    break;
                case EventType.Repaint:
                    var previous = Handles.color;
                    Handles.color = new Color(.13f, .14f, .16f, 1f);
                    Handles.DrawSolidDisc(center, Vector3.forward, radius);
                    Handles.color = new Color(.33f, .67f, .93f, 1f);
                    Handles.DrawSolidArc(center, Vector3.forward, Vector3.down, value * 360f, radius);
                    Handles.color = new Color(.2f, .21f, .23f, 1f);
                    Handles.DrawSolidDisc(center, Vector3.forward, radius * .62f);
                    Handles.color = previous;
                    GUI.Label(rect, $"{value * 100f:0}%", new GUIStyle(EditorStyles.whiteBoldLabel) { alignment = TextAnchor.MiddleCenter });
                    break;
            }
            EditorGUIUtility.AddCursorRect(rect, MouseCursor.SlideArrow);
            return value;
        }

        private void AddShapeControl(AvatarCustomizer config, SkinnedMeshRenderer r, string name, BlendshapeControlType type)
        {
            int index = r.sharedMesh.GetBlendShapeIndex(name);
            float weight = index >= 0 ? r.GetBlendShapeWeight(index) : 0f;
            var shape = new BlendshapeControl
            {
                id = Guid.NewGuid().ToString("N").Substring(0, 12), renderer = r, blendshape = name, type = type,
                // A radial covers the whole range and starts where the avatar is now; a toggle switches from now to the other end.
                min = type == BlendshapeControlType.Radial ? 0f : weight,
                max = type == BlendshapeControlType.Radial ? 100f : weight < 50f ? 100f : 0f,
                defaultValue = type == BlendshapeControlType.Radial ? Mathf.Clamp01(weight / 100f) : 0f,
            };
            string parent = addParent;
            Change("Add blendshape control", c =>
            {
                (c.blendshapeControls ??= new List<BlendshapeControl>()).Add(shape);
                var list = EntriesOf(c, menuIndex);
                list.Add(new FavoriteMenuEntry { shapeId = shape.id, parentId = parent });
                Reveal(parent, list);
            });
            config = avatar.GetComponent<AvatarCustomizer>();
            string menuName = config ? config.GetMenu(menuIndex)?.DisplayName ?? "즐겨찾기" : "즐겨찾기";
            status = $"‘{name}’ {(type == BlendshapeControlType.Radial ? "래디얼" : "토글")}을 ‘{menuName}’ 메뉴에 넣었어요. " +
                     "즐겨찾기 편집 탭에서 위치·이름·아이콘을 바꿀 수 있어요.";
            statusType = MessageType.Info;
        }

        private void DrawShapeControls(AvatarCustomizer config)
        {
            var shapes = (config ? config.blendshapeControls : null)?.Where(s => s != null).ToArray() ?? Array.Empty<BlendshapeControl>();
            var used = config ? new HashSet<string>(BlendshapeControlBuilder.UsedIds(config)) : new HashSet<string>();
            int bits = shapes.Where(s => used.Contains(s.id)).Sum(s => s.SyncedBits);
            EditorGUILayout.LabelField(new GUIContent($"게임 메뉴 컨트롤 · {shapes.Length}개 · 동기화 {bits} bit",
                "래디얼은 8 bit, 토글은 1 bit를 써요(동기화를 끄면 0). 아바타 전체 한도는 256 bit이고, 전체 사용량은 VRChat SDK에서 확인하세요."),
                EditorStyles.boldLabel);
            if (shapes.Length == 0)
            {
                EditorGUILayout.LabelField("아직 없어요. 블렌드쉐이프를 고르고 ‘+ 래디얼’이나 ‘+ 토글’을 누르세요.", EditorStyles.wordWrappedMiniLabel);
                return;
            }
            using var scroll = new EditorGUILayout.ScrollViewScope(shapeControlsScroll, GUILayout.ExpandHeight(true));
            shapeControlsScroll = scroll.scrollPosition;
            foreach (var shape in shapes)
            {
                string id = shape.id;
                using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
                {
                    using (new EditorGUILayout.HorizontalScope())
                    {
                        bool selected = shape.renderer == shapeRenderer && shape.blendshape == shapeName;
                        var title = new GUIContent(shape.blendshape, RendererLabel(shape.renderer) + " / " + shape.blendshape);
                        if (GUILayout.Toggle(selected, title, EditorStyles.miniButtonLeft, GUILayout.MinWidth(60)) && !selected)
                        {
                            ShowShape(shape);
                            if (shape.renderer) Reveal(shape.renderer);
                        }
                        int kind = EditorGUILayout.Popup((int)shape.type, new[] { "래디얼", "토글" }, EditorStyles.miniPullDown, GUILayout.Width(56));
                        if (kind != (int)shape.type) EditShape(id, "Change blendshape control type", s => s.type = (BlendshapeControlType)kind);
                        if (GUILayout.Button(new GUIContent("×", "이 컨트롤과 즐겨찾기의 해당 항목을 지웁니다."), GUILayout.Width(22)))
                        {
                            Change("Remove blendshape control", c =>
                            {
                                c.blendshapeControls?.RemoveAll(s => s?.id == id);
                                foreach (var menu in c.AllMenus()) menu.entries?.RemoveAll(e => e?.shapeId == id);
                            });
                            GUIUtility.ExitGUI();
                        }
                    }
                    string problem = BlendshapeControlBuilder.Problem(shape, avatar.transform, shape.renderer ? ConflictsFor(shape.renderer) : null);
                    if (problem != null) EditorGUILayout.LabelField("⚠ " + problem + " 빌드에서 제외돼요.", EditorStyles.wordWrappedMiniLabel);
                    using (new EditorGUILayout.HorizontalScope())
                    {
                        bool radial = shape.type == BlendshapeControlType.Radial;
                        float labelWidth = EditorGUIUtility.labelWidth;
                        EditorGUIUtility.labelWidth = 44f;
                        float min = EditorGUILayout.FloatField(new GUIContent(radial ? "0%일 때" : "끌 때", "블렌드쉐이프 값"), shape.min);
                        float max = EditorGUILayout.FloatField(new GUIContent(radial ? "100%" : "켤 때", "블렌드쉐이프 값"), shape.max);
                        EditorGUIUtility.labelWidth = labelWidth;
                        if (!Mathf.Approximately(min, shape.min) || !Mathf.Approximately(max, shape.max))
                            EditShape(id, "Change blendshape range", s => { s.min = min; s.max = max; });
                    }
                    DrawShapeDefault(shape);
                    using (new EditorGUILayout.HorizontalScope())
                    {
                        bool synced = GUILayout.Toggle(shape.synced, new GUIContent("동기화", "끄면 다른 사람에게는 보이지 않고 동기화 메모리를 쓰지 않아요."),
                            EditorStyles.miniButtonLeft);
                        bool saved = GUILayout.Toggle(shape.saved, new GUIContent("저장", "켜면 아바타를 다시 불러와도 마지막 값이 유지돼요."), EditorStyles.miniButtonRight);
                        if (synced != shape.synced || saved != shape.saved)
                            EditShape(id, "Change blendshape sync", s => { s.synced = synced; s.saved = saved; });
                        if (!used.Contains(id))
                        {
                            GUILayout.Label(new GUIContent("메뉴에 없음", "즐겨찾기 메뉴에 없으면 빌드에 만들지 않아요."), EditorStyles.miniLabel);
                            if (GUILayout.Button(new GUIContent("즐겨찾기에 넣기", "지금 편집 중인 즐겨찾기 메뉴의 ‘추가할 위치’에 넣어요."), EditorStyles.miniButton))
                            {
                                string parent = addParent;
                                Change("Add blendshape control to favorites", c =>
                                    EntriesOf(c, menuIndex).Add(new FavoriteMenuEntry { shapeId = id, parentId = parent }));
                                GUIUtility.ExitGUI();
                            }
                        }
                    }
                }
            }
        }
    }
}
#endif
