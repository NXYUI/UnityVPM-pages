#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using VRC.SDK3.Avatars.Components;
using Object = UnityEngine.Object;

namespace AssemblyChecker
{
    // "조립 점검기": builds a copy of the avatar with NDMF and shows what would go wrong in VRChat (점검), every texture
    // with where it sits (텍스처), and the synced bits and the parameter cleanup (파라미터). The scene avatar is changed
    // only by the cleanup settings on the parameter tab.
    internal sealed class AssemblyCheckerWindow : EditorWindow
    {
        private static readonly string[] TextureFilters = { "전체", "꺼진 칸", "애니메이션 전용", "셰이더에 없는 칸" };
        // The exception field's control name, to tell when Enter is pressed in it.
        private const string KeepField = "AssemblyChecker.KeepField";

        private VRCAvatarDescriptor avatar;
        private int tab;
        private string status;
        private MessageType statusType;

        // The last check (null before one) and the avatar it was made for.
        private VRCAvatarDescriptor checkedAvatar;
        private List<Finding> findings;
        private List<TextureRow> textures;
        private List<BitSource> sources;
        private int totalBits;
        private ParameterCleanup.Report cleanup;
        // The avatar's cleanup settings at the last check, and whether that check's build reported errors.
        private string checkedSettings;
        private bool buildErrors;

        private Finding selectedFinding;
        private TextureRow selectedTexture;
        private BitSource selectedSource;
        private int textureFilter;
        private string keepDraft = "";
        private Vector2 leftScroll, rightScroll;
        // Set when the arrow keys moved the selection: the next repaint scrolls the selected row into view.
        private bool revealSelected;
        // Set from the press of 점검하기 until the check it asked for has run (QueueCheck). Not kept through a script
        // reload: the delayed call is gone then, and a flag left set would leave both buttons off for good.
        [NonSerialized] private bool checkQueued;
        // The avatar the waiting check was asked for (the last request, when a second came while it waited).
        [NonSerialized] private VRCAvatarDescriptor queuedFor;

        private GUIStyle wrappedBold;
        private GUIStyle WrappedBold => wrappedBold ??= new GUIStyle(EditorStyles.boldLabel) { wordWrap = true };

        private static Color Selected => EditorGUIUtility.isProSkin ? new Color(0.24f, 0.48f, 0.9f, 0.28f) : new Color(0.24f, 0.48f, 0.9f, 0.2f);

        [MenuItem("NXYUI/Assembly Checker")]
        private static void Open() => GetWindow<AssemblyCheckerWindow>("조립 점검기");

        // The 파라미터 tab with a fresh check of this avatar, so the component's button leads straight to the list of
        // what would go. The check runs after the Inspector's own GUI pass.
        internal static void ShowParameters(VRCAvatarDescriptor target)
        {
            var window = GetWindow<AssemblyCheckerWindow>("조립 점검기");
            window.tab = 2;
            if (target && IsSceneAvatar(target))
            {
                window.SetAvatar(target);
                window.QueueCheck();
            }
            else
            {
                window.status = "프리팹 에셋이나 프리팹 편집 화면의 아바타는 점검할 수 없어요. 씬에 올려 둔 아바타의 컴포넌트에서 눌러 주세요.";
                window.statusType = MessageType.Warning;
            }
            window.Repaint();
        }

        // The window with the component's avatar in its field, from the component's Inspector. No check starts: the
        // window is where the user presses 점검하기. An avatar that cannot be checked (a prefab asset, Prefab Mode)
        // leaves the field as it was.
        internal static void ShowFor(VRCAvatarDescriptor target)
        {
            var window = GetWindow<AssemblyCheckerWindow>("조립 점검기");
            if (target && target != window.avatar && IsSceneAvatar(target)) window.SetAvatar(target);
            // Asked from a prefab asset, the prefab editing screen or an object under no avatar: the window cannot take
            // that one, and says so instead of showing the avatar it had as if it were the one asked for.
            else if (!target || !IsSceneAvatar(target))
            {
                window.status = target
                    ? "프로젝트 창의 프리팹이나 프리팹 편집 화면의 아바타는 점검할 수 없어요. 씬에 올려 둔 아바타를 ‘아바타’ 칸에 넣어 주세요."
                    : "누른 컴포넌트가 아바타(VRC Avatar Descriptor) 아래에 있지 않아서 넣을 아바타가 없어요. ‘아바타’ 칸에 씬의 아바타를 넣어 주세요.";
                window.statusType = MessageType.Warning;
            }
            window.Repaint();
        }

        private void OnEnable()
        {
            minSize = new Vector2(740, 420);
            if (!avatar) SetAvatar(FromSelection() ?? FindSceneAvatars().FirstOrDefault());
            // The settings shown on the 파라미터 tab change under the window: Undo, or an edit in the Inspector.
            Undo.undoRedoPerformed += Repaint;
        }

        private void OnDisable() => Undo.undoRedoPerformed -= Repaint;

        private void OnHierarchyChange() => Repaint();

        private void OnSelectionChange()
        {
            var selected = FromSelection();
            if (selected && selected != avatar)
            {
                SetAvatar(selected);
                Repaint();
            }
        }

        private static VRCAvatarDescriptor FromSelection()
        {
            var go = Selection.activeGameObject;
            var descriptor = go ? go.GetComponentInParent<VRCAvatarDescriptor>(true) : null;
            return descriptor && IsSceneAvatar(descriptor) ? descriptor : null;
        }

        private static IEnumerable<VRCAvatarDescriptor> FindSceneAvatars() =>
            FindObjectsOfType<VRCAvatarDescriptor>(true).Where(IsSceneAvatar);

        private static bool IsSceneAvatar(VRCAvatarDescriptor d) =>
            d && !EditorUtility.IsPersistent(d) && d.gameObject.scene.IsValid() && d.gameObject.scene.isLoaded &&
            !EditorSceneManager.IsPreviewScene(d.gameObject.scene) && PrefabStageUtility.GetPrefabStage(d.gameObject) == null;

        private void SetAvatar(VRCAvatarDescriptor next)
        {
            avatar = next;
            if (avatar == checkedAvatar) return;
            ClearResults();
            status = null;
        }

        private void ClearResults()
        {
            findings = null;
            textures = null;
            sources = null;
            cleanup = null;
            checkedAvatar = null;
            selectedFinding = null;
            selectedTexture = null;
            selectedSource = null;
            buildErrors = false;
        }

        private void OnGUI()
        {
            // The checked avatar was deleted or its scene closed: its results point at nothing. Only in the Layout pass,
            // so that every pass of one frame draws the same controls.
            if (findings != null && !checkedAvatar && Event.current.type == EventType.Layout)
            {
                ClearResults();
                avatar = null;
                status = "점검한 아바타가 씬에서 없어졌어요. 아바타를 다시 골라 점검해 주세요.";
                statusType = MessageType.Warning;
            }
            DrawHeader();
            if (findings == null)
            {
                EditorGUILayout.HelpBox((avatar ? "‘점검하기’를 누르세요. " : "아바타를 고르고 ‘점검하기’를 누르세요. ") +
                                        "복제본을 NDMF로 빌드해서 업로드될 모습 그대로 점검해요. 씬의 아바타는 바뀌지 않아요.", MessageType.Info);
                return;
            }
            int warnings = findings.Count(f => f.Severity == Severity.Warning);
            var labels = new[] { warnings > 0 ? $"점검 · 경고 {warnings}" : "점검", $"텍스처 {textures.Count}", $"파라미터 {totalBits}비트" };
            int next = GUILayout.Toolbar(tab, labels);
            if (next != tab)
            {
                // Another tab draws other lists: the rest of this pass would not match its Layout pass.
                tab = next;
                leftScroll = rightScroll = Vector2.zero;
                Repaint();
                GUIUtility.ExitGUI();
            }
            MoveSelection();
            EditorGUILayout.Space(4);
            using (new EditorGUILayout.HorizontalScope())
            {
                using (new EditorGUILayout.VerticalScope(GUILayout.Width(position.width * 0.48f)))
                using (var scroll = new EditorGUILayout.ScrollViewScope(leftScroll))
                {
                    leftScroll = scroll.scrollPosition;
                    if (tab == 0) DrawFindings();
                    else if (tab == 1) DrawTextureList();
                    else DrawSources();
                }
                using (new EditorGUILayout.VerticalScope())
                using (var scroll = new EditorGUILayout.ScrollViewScope(rightScroll))
                {
                    rightScroll = scroll.scrollPosition;
                    if (tab == 0) DrawFindingDetails();
                    else if (tab == 1) DrawTextureDetails();
                    else DrawCleanup();
                }
            }
        }

        private void DrawHeader()
        {
            bool playing = EditorApplication.isPlayingOrWillChangePlaymode;
            using (new EditorGUILayout.HorizontalScope())
            {
                var next = (VRCAvatarDescriptor)EditorGUILayout.ObjectField("아바타", avatar, typeof(VRCAvatarDescriptor), true);
                if (next != avatar)
                {
                    bool usable = next && IsSceneAvatar(next);
                    SetAvatar(usable ? next : null);
                    // Said, not skipped: a prefab from the Project window or one open in Prefab Mode cannot be built.
                    if (next && !usable)
                    {
                        status = "프로젝트 창의 프리팹이나 프리팹 편집 화면의 아바타는 점검할 수 없어요. 씬에 올려 둔 아바타를 넣어 주세요.";
                        statusType = MessageType.Warning;
                    }
                    Repaint();
                    GUIUtility.ExitGUI();
                }
                // While the check it asked for waits for the press to be over, the button says so (QueueCheck).
                var label = new GUIContent(checkQueued ? "준비 중…" : "점검하기", "복제본을 빌드해서 점검해요. 씬의 아바타는 바뀌지 않아요.");
                using (new EditorGUI.DisabledScope(!avatar || playing || checkQueued))
                    if (GUILayout.Button(label, GUILayout.Width(90)))
                    {
                        QueueCheck();
                        GUIUtility.ExitGUI();
                    }
            }
            // A disabled button shows no tooltip: the reason is a line of its own.
            if (playing)
                EditorGUILayout.LabelField("플레이 모드에서는 점검할 수 없어요. 플레이 모드를 끄고 ‘점검하기’를 눌러 주세요.", EditorStyles.wordWrappedMiniLabel);
            else if (!avatar)
                EditorGUILayout.LabelField("씬의 아바타를 ‘아바타’ 칸에 넣거나 Hierarchy에서 고르면 ‘점검하기’를 누를 수 있어요.", EditorStyles.wordWrappedMiniLabel);
            // How the tool is used: under the row it starts from, above the check's status and results. The button keeps
            // its place in the row whether the block is open or closed.
            AssemblyCheckerUsage.DrawInWindow(AssemblyCheckerUsage.WindowKey, Repaint, Mathf.Max(40f, position.height - minSize.y + 40f));
            if (!string.IsNullOrEmpty(status)) EditorGUILayout.HelpBox(status, statusType);
            if (buildErrors && GUILayout.Button(new GUIContent("NDMF 콘솔 열기", "이번 점검의 빌드에서 난 오류를 NDMF 콘솔에서 봐요."), GUILayout.Width(120)))
                nadena.dev.ndmf.ui.ErrorReportWindow.ShowErrorReportWindow();
        }

        // The check runs from a delayed call, once the press that asked for it has been handled: nothing the build does
        // (NDMF opening its console window, progress bars, asset imports, a second or more of work) happens while the
        // editor is still delivering that press to the window.
        private void QueueCheck()
        {
            if (!avatar || EditorApplication.isPlayingOrWillChangePlaymode) return;
            // Asked again while one waits (the component's button for another avatar): the one check that runs is for
            // the avatar asked for last.
            queuedFor = avatar;
            if (checkQueued) return;
            checkQueued = true;
            EditorApplication.delayCall += () =>
            {
                if (!this) return;
                checkQueued = false;
                var target = queuedFor;
                queuedFor = null;
                // Said, not skipped, each with what to do next: Play mode started, the avatar is gone, or another was put in.
                string stopped = EditorApplication.isPlayingOrWillChangePlaymode
                    ? "점검을 시작하기 전에 플레이 모드가 시작돼서 점검하지 않았어요. 플레이 모드를 끝낸 뒤 ‘점검하기’를 다시 눌러 주세요."
                    : !target ? "점검을 시작하기 전에 아바타가 씬에서 없어져서 점검하지 않았어요. 아바타를 다시 넣고 ‘점검하기’를 눌러 주세요."
                    : avatar != target ? "점검을 시작하기 전에 아바타를 바꿔서 점검하지 않았어요. 지금 아바타를 점검하려면 ‘점검하기’를 다시 눌러 주세요."
                    : null;
                if (stopped != null)
                {
                    status = stopped;
                    statusType = MessageType.Warning;
                    Repaint();
                    return;
                }
                RunCheck();
            };
            Repaint();
        }

        private void RunCheck()
        {
            var target = avatar;
            try
            {
                EditorUtility.DisplayProgressBar("조립 점검기", "복제본을 빌드하고 있어요…", 0.2f);
                using (var built = BuiltAvatar.Build(target))
                {
                    EditorUtility.DisplayProgressBar("조립 점검기", "점검하고 있어요…", 0.7f);
                    findings = AssemblyChecks.Run(built);
                    textures = TextureReport.Collect(built);
                    sources = ParameterBits.Attribute(built, out totalBits);
                    cleanup = built.Cleanup;
                    checkedAvatar = target;
                    checkedSettings = SettingsOf(target);
                    selectedFinding = null;
                    selectedTexture = null;
                    selectedSource = null;
                    buildErrors = !built.Successful;
                    int warnings = findings.Count(f => f.Severity == Severity.Warning);
                    status = built.Successful
                        ? $"점검을 마쳤어요 ({DateTime.Now:HH:mm}): 경고 {warnings}개, 참고 {findings.Count - warnings}개."
                        : "⚠ 빌드 중 오류가 있었어요. NDMF 콘솔을 확인해 주세요. 오류가 난 부분은 결과에서 빠질 수 있어요.";
                    if (AssemblyChecks.HasVRCFury(target.gameObject))
                        status += "\nVRCFury가 있어요. 업로드에서는 VRCFury가 빌드 중간에 돌지만 이 점검은 VRCFury를 돌리지 않아요. " +
                                  "VRCFury가 만드는 메뉴·파라미터·본 연결은 결과에 없어요.";
                    foreach (var problem in built.Problems) status += "\n⚠ " + problem;
                    statusType = buildErrors || warnings > 0 || built.Problems.Count > 0 ? MessageType.Warning : MessageType.Info;
                }
            }
            catch (Exception e)
            {
                // The lists of an earlier check would read as this one's.
                ClearResults();
                status = "점검 실패: " + e.Message + "\n결과를 만들지 못했어요. Console 창에 자세한 오류가 있어요.";
                statusType = MessageType.Error;
                Debug.LogException(e);
            }
            finally
            {
                EditorUtility.ClearProgressBar();
                Repaint();
            }
        }

        // The cleanup settings of an avatar as one line, to tell whether they changed since the check.
        private static string SettingsOf(VRCAvatarDescriptor of)
        {
            var settings = of ? of.GetComponent<AssemblyCheckerSettings>() : null;
            if (!settings) return "";
            return (settings.CleansUp ? "on" : "off") + "\n" + string.Join("\n", settings.keepParameters ?? new List<string>());
        }

        // A list row in a helpBox frame that selects on click. Returns true when clicked; the caller selects the row and
        // ends the pass (the details on the right change). The selected row is tinted and also marked by a bar in the
        // text colour along its left edge, so that it does not rest on colour alone.
        private bool Row(bool selected, Action draw)
        {
            var rect = EditorGUILayout.BeginVertical(EditorStyles.helpBox);
            draw();
            EditorGUILayout.EndVertical();
            if (selected && Event.current.type == EventType.Repaint)
            {
                EditorGUI.DrawRect(rect, Selected);
                EditorGUI.DrawRect(new Rect(rect.x, rect.y, 3f, rect.height), EditorStyles.label.normal.textColor);
                // The row the arrow keys moved to is scrolled into view.
                if (revealSelected)
                {
                    revealSelected = false;
                    GUI.ScrollTo(rect);
                    Repaint();
                }
            }
            if (Event.current.type == EventType.MouseDown && rect.Contains(Event.current.mousePosition))
            {
                Event.current.Use();
                // No field keeps the keyboard, so the arrow keys move in the list.
                GUI.FocusControl(null);
                Repaint();
                return true;
            }
            return false;
        }

        // Up and down move the selection in the list on the left while no field has the keyboard.
        private void MoveSelection()
        {
            var e = Event.current;
            if (e.type != EventType.KeyDown || GUIUtility.keyboardControl != 0 || (e.keyCode != KeyCode.UpArrow && e.keyCode != KeyCode.DownArrow)) return;
            int step = e.keyCode == KeyCode.UpArrow ? -1 : 1;
            T Next<T>(IList<T> list, T current) where T : class
            {
                if (list.Count == 0) return null;
                int at = list.IndexOf(current);
                return at < 0 ? list[step > 0 ? 0 : list.Count - 1] : list[Mathf.Clamp(at + step, 0, list.Count - 1)];
            }
            if (tab == 0) selectedFinding = Next(AssemblyChecks.Order.SelectMany(c => findings.Where(f => f.Check == c)).ToList(), selectedFinding);
            else if (tab == 1) selectedTexture = Next(FilteredTextures().ToList(), selectedTexture);
            else selectedSource = Next(sources, selectedSource);
            revealSelected = true;
            e.Use();
            Repaint();
            GUIUtility.ExitGUI();
        }

        private static void Badge(string text, float width = 0f)
        {
            if (width > 0f) GUILayout.Label(text, EditorStyles.miniBoldLabel, GUILayout.Width(width));
            else GUILayout.Label(text, EditorStyles.miniBoldLabel, GUILayout.ExpandWidth(false));
        }

        // A one-line label that gives way when its column is narrow: it is cut at the edge and its tooltip has the whole
        // text. Without this a long name widens the row past the column and the list grows a sideways scroll bar.
        private static void Clipped(string text, GUIStyle style, string tooltip = null) =>
            GUILayout.Label(new GUIContent(text, tooltip ?? text), style, GUILayout.MinWidth(40));

        private static void Select(Object target)
        {
            if (!target) return;
            Selection.activeObject = target;
            EditorGUIUtility.PingObject(target);
        }

        // ---- 점검 -----------------------------------------------------------------------------------------------------

        private void DrawFindings()
        {
            foreach (var check in AssemblyChecks.Order)
            {
                var items = findings.Where(f => f.Check == check).ToList();
                EditorGUILayout.LabelField(check, items.Count == 0 ? "문제 없음" : $"{items.Count}개", EditorStyles.boldLabel);
                if (items.Count == 0)
                {
                    EditorGUILayout.LabelField(AssemblyChecks.About[check], EditorStyles.wordWrappedMiniLabel);
                    EditorGUILayout.Space(4);
                    continue;
                }
                foreach (var finding in items)
                    if (Row(finding == selectedFinding, () =>
                        {
                            using (new EditorGUILayout.HorizontalScope())
                            {
                                Badge(finding.Severity == Severity.Warning ? "⚠ 경고" : "참고", 46);
                                Clipped(finding.Title, EditorStyles.label);
                            }
                        }))
                    {
                        selectedFinding = finding;
                        GUIUtility.ExitGUI();
                    }
                EditorGUILayout.Space(8);
            }
        }

        private void DrawFindingDetails()
        {
            if (selectedFinding == null)
            {
                int warnings = findings.Count(f => f.Severity == Severity.Warning);
                EditorGUILayout.LabelField($"경고 {warnings}개 · 참고 {findings.Count - warnings}개", EditorStyles.boldLabel);
                EditorGUILayout.LabelField("왼쪽에서 항목을 고르면 자세한 내용과 고치는 방법이 나와요. 경고는 VRChat에서 보이는 문제이고, " +
                                           "참고는 상황에 따라 괜찮을 수 있는 것이에요.", EditorStyles.wordWrappedMiniLabel);
                EditorGUILayout.Space(8);
                EditorGUILayout.LabelField("점검하는 것", EditorStyles.boldLabel);
                foreach (var check in AssemblyChecks.Order)
                    EditorGUILayout.LabelField($"{check}: {AssemblyChecks.About[check]}", EditorStyles.wordWrappedMiniLabel);
                return;
            }
            var f = selectedFinding;
            using (new EditorGUILayout.HorizontalScope())
            {
                Badge(f.Severity == Severity.Warning ? "⚠ 경고" : "참고");
                Badge("· " + f.Check);
                GUILayout.FlexibleSpace();
            }
            EditorGUILayout.LabelField(f.Title, WrappedBold);
            EditorGUILayout.Space(4);
            EditorGUILayout.LabelField(f.Detail, EditorStyles.wordWrappedLabel);
            EditorGUILayout.Space(8);
            // No button to press when there is nothing to select: the reason is said instead.
            if (f.Target)
            {
                if (GUILayout.Button(new GUIContent("씬에서 선택", "Hierarchy에서 이 오브젝트를 골라요."), GUILayout.Width(110))) Select(f.Target);
            }
            else
                EditorGUILayout.LabelField("씬에서 고를 오브젝트가 없어요. 빌드 중에 생긴 것이거나 점검한 뒤에 지워졌어요.", EditorStyles.wordWrappedMiniLabel);
        }

        // ---- 텍스처 ---------------------------------------------------------------------------------------------------

        private IEnumerable<TextureRow> FilteredTextures()
        {
            switch (textureFilter)
            {
                case 1: return textures.Where(r => r.AnyOff);
                case 2: return textures.Where(r => r.OnlyAnimated);
                case 3: return textures.Where(r => r.AnyStale);
                default: return textures;
            }
        }

        private void DrawTextureList()
        {
            long all = textures.Sum(r => r.Bytes);
            long unseen = textures.Where(r => r.Unused).Sum(r => r.Bytes);
            EditorGUILayout.LabelField($"텍스처 {textures.Count}개 · 약 {TextureReport.Size(all)}", EditorStyles.boldLabel);
            EditorGUILayout.LabelField(unseen > 0
                    ? $"꺼진 칸이나 셰이더에 없는 칸에만 있는 텍스처가 {TextureReport.Size(unseen)}예요. 보이지 않는데 업로드될 수 있어요."
                    : "크기는 그래픽 메모리(VRAM) 추정치예요.", EditorStyles.wordWrappedMiniLabel);
            int filter = GUILayout.Toolbar(textureFilter, TextureFilters, EditorStyles.miniButton);
            if (filter != textureFilter)
            {
                textureFilter = filter;
                selectedTexture = null;
                Repaint();
                GUIUtility.ExitGUI();
            }
            EditorGUILayout.Space(4);
            var rows = FilteredTextures().ToList();
            if (rows.Count == 0)
                EditorGUILayout.LabelField(textureFilter == 0 ? "이 아바타에는 텍스처가 없어요." : "이 조건에 맞는 텍스처가 없어요. ‘전체’를 누르면 모두 보여요.",
                    EditorStyles.wordWrappedMiniLabel);
            foreach (var row in rows)
                if (Row(row == selectedTexture, () =>
                    {
                        Clipped(row.Name, EditorStyles.label, row.AssetPath);
                        using (new EditorGUILayout.HorizontalScope())
                        {
                            Clipped($"{row.Width}×{row.Height} · {TextureReport.Size(row.Bytes)} · {row.Format}", EditorStyles.miniLabel);
                            GUILayout.FlexibleSpace();
                            if (row.Unused) Badge("안 보임");
                            else if (row.AnyOff) Badge("꺼진 칸");
                            if (row.AnyStale) Badge("셰이더에 없는 칸");
                            if (row.OnlyAnimated) Badge("애니메이션");
                            if (row.Unsaved) Badge("미저장");
                            else if (!row.Asset) Badge("빌드 생성");
                        }
                    }))
                {
                    selectedTexture = row;
                    GUIUtility.ExitGUI();
                }
        }

        private void DrawTextureDetails()
        {
            var row = selectedTexture;
            if (row == null)
            {
                EditorGUILayout.LabelField("왼쪽에서 텍스처를 고르면 어느 오브젝트의 어떤 머티리얼, 어떤 칸에 있는지 보여 줘요.", EditorStyles.wordWrappedMiniLabel);
                EditorGUILayout.Space(8);
                EditorGUILayout.LabelField("표시", EditorStyles.boldLabel);
                EditorGUILayout.LabelField("꺼진 칸: lilToon에서 그 기능을 껐는데 텍스처가 남은 칸이에요. 애니메이션이 그 기능을 켜는 칸은 켜진 것으로 봐요.",
                    EditorStyles.wordWrappedMiniLabel);
                EditorGUILayout.LabelField("셰이더에 없는 칸: 예전 셰이더의 칸에 남은 텍스처예요. 머티리얼에 남아 함께 올라가요.", EditorStyles.wordWrappedMiniLabel);
                EditorGUILayout.LabelField("안 보임: 꺼진 칸이나 셰이더에 없는 칸에만 있어서, 보이지 않는데 올라가는 텍스처예요.", EditorStyles.wordWrappedMiniLabel);
                EditorGUILayout.LabelField("애니메이션: 애니메이션이 바꿔 넣는 머티리얼에만 있는 텍스처예요.", EditorStyles.wordWrappedMiniLabel);
                EditorGUILayout.LabelField("빌드 생성: TexTransTool 같은 도구가 빌드 중에 만든 텍스처예요.", EditorStyles.wordWrappedMiniLabel);
                EditorGUILayout.LabelField("미저장: 에셋으로 저장하지 않고 씬에만 있는 텍스처예요.", EditorStyles.wordWrappedMiniLabel);
                return;
            }
            EditorGUILayout.LabelField(row.Name, WrappedBold);
            EditorGUILayout.LabelField($"{row.Width}×{row.Height} · {TextureReport.Size(row.Bytes)} · {row.Format}", EditorStyles.miniLabel);
            EditorGUILayout.LabelField(row.AssetPath ?? (row.Unsaved ? "에셋으로 저장하지 않고 씬에만 있는 텍스처예요. 프로젝트에는 파일이 없어요."
                : "빌드 중에 만든 텍스처라 에셋이 없어요."), EditorStyles.wordWrappedMiniLabel);
            // The asset can be deleted after the check: the row still names it, and a destroyed texture cannot be drawn.
            if (row.Asset)
                using (new EditorGUILayout.HorizontalScope())
                {
                    if (row.Asset is Texture2D preview)
                    {
                        var rect = GUILayoutUtility.GetRect(96, 96, GUILayout.Width(96), GUILayout.Height(96));
                        EditorGUI.DrawPreviewTexture(rect, preview, null, ScaleMode.ScaleToFit);
                    }
                    if (GUILayout.Button(new GUIContent("에셋 선택", "Project 창에서 이 텍스처를 골라요."), GUILayout.Width(80))) Select(row.Asset);
                    GUILayout.FlexibleSpace();
                }
            else if (row.AssetPath != null)
                EditorGUILayout.LabelField("점검한 뒤에 이 에셋이 지워졌어요. 다시 점검해 주세요.", EditorStyles.wordWrappedMiniLabel);
            EditorGUILayout.Space(8);
            EditorGUILayout.LabelField($"쓰는 곳 {row.Uses.Count}곳", EditorStyles.boldLabel);
            foreach (var use in row.Uses)
                using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
                {
                    EditorGUILayout.LabelField($"{use.Path} › {use.Material} › {use.Slot}", EditorStyles.wordWrappedLabel);
                    // A clip's name can be long: the badge says only that an animation puts it there, the name has a line of
                    // its own, cut at the edge with the whole name in its tooltip.
                    if (use.Animated) Clipped("클립: " + use.Clip, EditorStyles.miniLabel, use.Clip);
                    using (new EditorGUILayout.HorizontalScope())
                    {
                        if (use.Off) Badge("꺼진 칸");
                        if (use.Stale) Badge("셰이더에 없는 칸");
                        if (use.Animated) Badge("애니메이션");
                        GUILayout.FlexibleSpace();
                        if (use.MaterialAsset)
                        {
                            if (GUILayout.Button(new GUIContent("머티리얼", "머티리얼 에셋을 골라요."), EditorStyles.miniButton, GUILayout.Width(60)))
                                Select(use.MaterialAsset);
                        }
                        else
                            GUILayout.Label(new GUIContent("머티리얼 에셋 없음", "빌드 중에 만들었거나 씬에만 있는 머티리얼이에요."), EditorStyles.miniLabel,
                                GUILayout.ExpandWidth(false));
                    }
                }
            if (row.AnyOff || row.AnyStale)
                EditorGUILayout.LabelField("쓰지 않는 칸이면 머티리얼에서 그 칸을 비우세요. 셰이더에 없는 칸은 lilToon의 ‘사용하지 않는 프로퍼티 삭제’ 같은 " +
                                           "기능으로 정리할 수 있어요.", EditorStyles.wordWrappedMiniLabel);
        }

        // ---- 파라미터 -------------------------------------------------------------------------------------------------

        private void DrawSources()
        {
            EditorGUILayout.LabelField("동기화 파라미터", EditorStyles.boldLabel);
            var bar = GUILayoutUtility.GetRect(18, 18, GUILayout.ExpandWidth(true));
            EditorGUI.ProgressBar(bar, Mathf.Clamp01(totalBits / (float)ParameterBits.Limit), $"{totalBits} / {ParameterBits.Limit} 비트");
            if (cleanup != null && cleanup.applied)
                EditorGUILayout.LabelField($"정리로 {cleanup.bitsBefore - cleanup.bitsAfter}비트를 줄인 뒤예요 (정리 전 {cleanup.bitsBefore}비트).", EditorStyles.wordWrappedMiniLabel);
            if (totalBits > ParameterBits.Limit)
                EditorGUILayout.HelpBox($"⚠ {ParameterBits.Limit}비트를 넘어서 업로드할 수 없어요.", MessageType.Warning);
            if (cleanup != null && cleanup.vrcfuryPending)
                EditorGUILayout.LabelField("VRCFury가 업로드 때 더하는 파라미터는 여기에 없어요. 실제 비트는 더 많을 수 있고, 넘치면 VRCFury가 압축해요.",
                    EditorStyles.wordWrappedMiniLabel);
            EditorGUILayout.Space(4);
            if (sources.Count == 0)
                EditorGUILayout.LabelField("동기화 파라미터가 없어요.", EditorStyles.wordWrappedMiniLabel);
            foreach (var source in sources)
                if (Row(source == selectedSource, () =>
                    {
                        using (new EditorGUILayout.HorizontalScope())
                        {
                            Clipped(source.Name, EditorStyles.label);
                            GUILayout.FlexibleSpace();
                            GUILayout.Label($"{source.Bits}비트 · {source.Parameters.Count}개", EditorStyles.miniLabel, GUILayout.ExpandWidth(false));
                        }
                    }))
                {
                    selectedSource = source;
                    GUIUtility.ExitGUI();
                }
            EditorGUILayout.Space(4);
            EditorGUILayout.LabelField("프리팹은 Modular Avatar Parameters로 찾아요. 빌드 중에 이름이 바뀐 파라미터는 ‘빌드 중에 생긴 파라미터’에 모여요.",
                EditorStyles.wordWrappedMiniLabel);
        }

        private void DrawCleanup()
        {
            if (selectedSource != null)
            {
                EditorGUILayout.LabelField(selectedSource.Name, WrappedBold);
                EditorGUILayout.LabelField($"{selectedSource.Bits}비트 · {selectedSource.Parameters.Count}개", EditorStyles.miniLabel);
                foreach (var parameter in selectedSource.Parameters) EditorGUILayout.LabelField("· " + parameter, EditorStyles.wordWrappedMiniLabel);
                if (selectedSource.Target && GUILayout.Button("선택", GUILayout.Width(60))) Select(selectedSource.Target);
                EditorGUILayout.Space(12);
            }

            EditorGUILayout.LabelField("안 쓰는 파라미터 정리", EditorStyles.boldLabel);
            EditorGUILayout.LabelField("켜 두면 업로드(빌드)할 때마다 애니메이터, 메뉴, Contact·PhysBone·Raycast 어디에도 없는 Expression Parameter를 지워요. " +
                                       "씬의 아바타와 에셋은 바뀌지 않아요. 아바타 루트의 Assembly Checker 컴포넌트가 켜져 있을 때만 돌아요.",
                EditorStyles.wordWrappedMiniLabel);
            var settings = avatar ? avatar.GetComponent<AssemblyCheckerSettings>() : null;
            bool enabled = settings && settings.CleansUp;
            // What is changed in Play Mode is gone when it ends: the settings are edited in Edit Mode only.
            bool editable = avatar && !EditorApplication.isPlayingOrWillChangePlaymode;
            if (avatar && !editable)
                EditorGUILayout.LabelField("플레이 모드에서 바꾼 설정은 플레이 모드를 끄면 사라져서, 여기 설정은 편집 모드에서만 바꿀 수 있어요.", EditorStyles.wordWrappedMiniLabel);
            using (new EditorGUI.DisabledScope(!editable))
            {
                bool next = EditorGUILayout.ToggleLeft("이 아바타에서 정리하기", enabled);
                if (next != enabled)
                    EditSettings(next ? "Turn parameter cleanup on" : "Turn parameter cleanup off", s =>
                    {
                        s.enabled = next;
                        if (next) s.removeUnusedParameters = true;
                    });
            }
            EditorGUILayout.LabelField(
                !settings ? "꺼져 있어요. 켜면 아바타 루트에 Assembly Checker 컴포넌트를 붙여요."
                : enabled ? "켜져 있어요. 컴포넌트의 체크를 끄면 멈춰요."
                : "꺼져 있어요(컴포넌트의 체크가 꺼져 있어요). 예외 목록은 그대로 남아요.", EditorStyles.wordWrappedMiniLabel);
            // The build reads the component on the avatar root only: one further down does nothing, and says so here too.
            var misplaced = avatar ? avatar.GetComponentsInChildren<AssemblyCheckerSettings>(true)
                .FirstOrDefault(s => s.gameObject != avatar.gameObject && !s.GetComponent<VRCAvatarDescriptor>()) : null;
            if (misplaced)
                using (new EditorGUILayout.HorizontalScope())
                {
                    EditorGUILayout.LabelField($"⚠ ‘{BuiltAvatar.PathOf(avatar.transform, misplaced.transform)}’에도 Assembly Checker 컴포넌트가 있어요. " +
                                               "아바타 루트가 아니라서 그 컴포넌트는 동작하지 않아요.", EditorStyles.wordWrappedMiniLabel);
                    if (GUILayout.Button(new GUIContent("선택", "그 오브젝트를 골라요. 인스펙터에서 루트로 옮기거나 지울 수 있어요."), EditorStyles.miniButton, GUILayout.Width(40)))
                        Select(misplaced.gameObject);
                }
            EditorGUILayout.Space(4);
            EditorGUILayout.LabelField("예외 목록", EditorStyles.boldLabel);
            EditorGUILayout.LabelField($"여기 있는 이름은 지우지 않아요. 이름을 적고 ‘추가’를 누르세요. 끝에 *를 붙이면 그 이름으로 시작하는 것 모두예요. " +
                                       $"기본으로 남기는 이름: {string.Join(", ", ParameterCleanup.OutsideNames)}", EditorStyles.wordWrappedMiniLabel);
            var keep = settings && settings.keepParameters != null ? settings.keepParameters : new List<string>();
            for (int i = 0; i < keep.Count; i++)
                using (new EditorGUILayout.HorizontalScope())
                {
                    EditorGUILayout.LabelField(new GUIContent(keep[i], keep[i]));
                    using (new EditorGUI.DisabledScope(!editable))
                        if (GUILayout.Button(new GUIContent("×", "예외 목록에서 빼기"), GUILayout.Width(22)))
                        {
                            int index = i;
                            EditSettings("Remove parameter exception", s => s.keepParameters.RemoveAt(index));
                            GUIUtility.ExitGUI();
                        }
                }
            using (new EditorGUILayout.HorizontalScope())
            using (new EditorGUI.DisabledScope(!editable))
            {
                // Enter in the field adds, like the button. Read before the field takes the key.
                // Not while an input method is composing (Korean): there Enter only settles the letters.
                bool enter = Event.current.type == EventType.KeyDown && GUI.GetNameOfFocusedControl() == KeepField &&
                             (Event.current.keyCode == KeyCode.Return || Event.current.keyCode == KeyCode.KeypadEnter) && !Composing();
                GUI.SetNextControlName(KeepField);
                keepDraft = EditorGUILayout.TextField(keepDraft);
                bool blank = string.IsNullOrWhiteSpace(keepDraft);
                bool add;
                using (new EditorGUI.DisabledScope(blank))
                    add = GUILayout.Button(new GUIContent("추가", "적은 이름을 예외 목록에 넣어요."), GUILayout.Width(50));
                if ((add || enter) && !blank)
                {
                    if (enter) Event.current.Use();
                    AddException(keepDraft.Trim());
                    keepDraft = "";
                    GUI.FocusControl(null);
                    GUIUtility.ExitGUI();
                }
            }

            EditorGUILayout.Space(12);
            EditorGUILayout.LabelField("점검 결과 (복제본 빌드)", EditorStyles.boldLabel);
            if (cleanup == null)
                EditorGUILayout.LabelField("이번 점검에서는 정리 단계가 돌지 않았어요. 빌드가 오류로 멈췄거나 NDMF에서 Assembly Checker 플러그인을 꺼 둔 경우예요. " +
                                           "NDMF 콘솔을 확인해 주세요.", EditorStyles.wordWrappedMiniLabel);
            else if (!string.IsNullOrEmpty(cleanup.skipped))
                EditorGUILayout.LabelField(cleanup.skipped, EditorStyles.wordWrappedMiniLabel);
            else
            {
                // The lists below are the check's: they do not follow the settings until the next check.
                if (avatar && SettingsOf(avatar) != checkedSettings)
                    EditorGUILayout.LabelField("⚠ 점검한 뒤에 설정이 바뀌었어요. ‘점검하기’를 다시 눌러야 아래 결과에 반영돼요.", EditorStyles.wordWrappedMiniLabel);
                string head = cleanup.removed.Count == 0 ? "지울 파라미터가 없어요."
                    : cleanup.applied ? $"지울 파라미터 {cleanup.removed.Count}개 · 동기화 {cleanup.bitsBefore} → {cleanup.bitsAfter}비트"
                    : $"정리가 꺼져 있어요. 켜면 {cleanup.removed.Count}개를 지우고 동기화 {cleanup.bitsBefore} → {cleanup.bitsAfter}비트가 돼요.";
                EditorGUILayout.LabelField(head, EditorStyles.wordWrappedLabel);
                if (cleanup.removed.Count > 0)
                    EditorGUILayout.LabelField("아바타 안에서 쓰는 곳이 없는 파라미터예요. OSC 프로그램에서만 읽거나 쓰는 이름은 아바타 안에서는 알 수 없으니, " +
                                               "그런 이름이 있으면 ‘남기기’로 예외에 넣어 주세요.", EditorStyles.wordWrappedMiniLabel);
                if (cleanup.vrcfuryPending && cleanup.removed.Count > 0)
                    EditorGUILayout.LabelField("⚠ VRCFury가 있어요. 이 점검은 VRCFury를 돌리지 않아서, VRCFury가 합치는 컨트롤러·메뉴에서만 쓰는 파라미터도 여기에 " +
                                               "나올 수 있어요. 업로드에서는 VRCFury가 돈 뒤에 정리하므로 그런 파라미터는 지우지 않아요. 실제로 지운 것은 업로드한 뒤 " +
                                               "‘마지막 빌드’에서 확인하세요.", EditorStyles.wordWrappedMiniLabel);
                foreach (var entry in cleanup.removed)
                    using (new EditorGUILayout.HorizontalScope(EditorStyles.helpBox))
                    {
                        Clipped(entry.name, EditorStyles.label, entry.name + "\n" + entry.reason);
                        GUILayout.FlexibleSpace();
                        GUILayout.Label(entry.bits > 0 ? $"{entry.type} · {entry.bits}비트" : $"{entry.type} · 동기화 안 함", EditorStyles.miniLabel, GUILayout.ExpandWidth(false));
                        // Covered by a pattern ("Name*") counts too: the button would only add a second exception.
                        bool kept = ParameterCleanup.Matches(entry.name, keep);
                        using (new EditorGUI.DisabledScope(kept || !editable))
                            if (GUILayout.Button(new GUIContent(kept ? "예외됨" : "남기기", "예외 목록에 넣어 지우지 않게 해요. 다시 점검하면 반영돼요."),
                                    EditorStyles.miniButton, GUILayout.Width(52)))
                            {
                                AddException(entry.name);
                                GUIUtility.ExitGUI();
                            }
                    }
                if (cleanup.kept.Count > 0)
                {
                    EditorGUILayout.Space(4);
                    EditorGUILayout.LabelField($"쓰이지 않는 것 같지만 남긴 파라미터 {cleanup.kept.Count}개", EditorStyles.boldLabel);
                    foreach (var entry in cleanup.kept)
                    {
                        bool warn = !entry.reason.StartsWith("예외", StringComparison.Ordinal);
                        EditorGUILayout.LabelField($"{(warn ? "⚠ " : "")}{entry.name}: {entry.reason}", EditorStyles.wordWrappedMiniLabel);
                    }
                }
            }

            EditorGUILayout.Space(12);
            EditorGUILayout.LabelField("마지막 빌드", EditorStyles.boldLabel);
            // Records are filed by blueprint ID, by name before there is one: two such avatars of one name share them.
            if (avatar && ParameterCleanup.SharesRecord(avatar.gameObject))
            {
                EditorGUILayout.LabelField("씬에 이름이 같은 아바타가 또 있고 둘 다 Blueprint ID가 없어서, 빌드 기록이 어느 아바타의 것인지 구별할 수 없어요. " +
                                           "그래서 기록을 보여 주거나 비교하지 않아요. 업로드해서 ID가 생기면 아바타마다 따로 기록돼요.", EditorStyles.wordWrappedMiniLabel);
                return;
            }
            var builds = avatar
                ? ParameterCleanup.Platforms.Select(p => ParameterCleanup.LastBuild(avatar.gameObject, p)).Where(r => r != null).ToList()
                : new List<ParameterCleanup.Report>();
            if (builds.Count == 0)
                EditorGUILayout.LabelField(enabled ? "이번 에디터 세션에서 이 아바타를 업로드하거나 플레이한 기록이 없어요. 업로드하면 무엇을 지웠는지 여기에 나와요."
                    : "정리가 꺼져 있으면 빌드할 때 아무것도 하지 않아서 기록도 남지 않아요.", EditorStyles.wordWrappedMiniLabel);
            foreach (var last in builds)
            {
                string what = !string.IsNullOrEmpty(last.skipped) ? last.skipped
                    : last.applied ? $"{last.removed.Count}개를 지웠어요 · 동기화 {last.bitsBefore} → {last.bitsAfter}비트"
                    : !last.enabled && last.removed.Count > 0 ? $"정리가 꺼져 있었어요 (지울 수 있던 파라미터 {last.removed.Count}개)"
                    : "지울 파라미터가 없었어요.";
                EditorGUILayout.LabelField($"{last.platform}{(last.play ? " (플레이 모드)" : "")} · {last.time}: {what}", EditorStyles.wordWrappedLabel);
                if (last.applied) EditorGUILayout.LabelField("지운 것: " + string.Join(", ", last.removed.Select(e => e.name)), EditorStyles.wordWrappedMiniLabel);
            }
            if (builds.Any(r => r.play))
                EditorGUILayout.LabelField("플레이 모드 기록은 그 플랫폼의 업로드 기록이 없을 때만 보여요. 업로드 기록을 덮지 않고, PC·Quest 비교에도 쓰지 않아요.",
                    EditorStyles.wordWrappedMiniLabel);
            if (builds.Any(r => r.vrcfury))
                EditorGUILayout.LabelField("VRCFury의 파라미터 압축은 이 기록 뒤에 돌아요. 압축이 걸리면 실제로 올라간 비트는 여기 숫자보다 적어요.", EditorStyles.wordWrappedMiniLabel);
            var (text, warning) = Compare(builds, ParameterCleanup.VRCFuryAlignsMobile());
            if (text != null)
            {
                if (warning) EditorGUILayout.HelpBox(text, MessageType.Warning);
                else EditorGUILayout.LabelField(text, EditorStyles.wordWrappedMiniLabel);
            }
            if (builds.Count > 0) EditorGUILayout.LabelField("NDMF 콘솔에도 같은 내용이 남아요.", EditorStyles.wordWrappedMiniLabel);
        }

        // What the last builds say about PC and Quest syncing with each other: a warning, a note, or nothing (null). PC and
        // Quest must end with the same synced list in the same order, each parameter with the same type and bits. Only
        // records of builds outside Play mode are compared. aligned: VRCFury lines mobile uploads up with the last desktop
        // upload, after this cleanup (ParameterCleanup.VRCFuryAlignsMobile); then differing lists do not desync, and what
        // still matters is a synced parameter the desktop build removed that mobile uses: it stops syncing on mobile.
        internal static (string Text, bool Warning) Compare(IReadOnlyList<ParameterCleanup.Report> builds, bool aligned)
        {
            var lists = builds.Where(r => !r.play && string.IsNullOrEmpty(r.skipped)).ToList();
            // Names the cleanup removed in some of the records that another record's final list still syncs.
            List<string> Removed(IEnumerable<ParameterCleanup.Report> from, IReadOnlyCollection<ParameterCleanup.Report> to) =>
                from.SelectMany(r => r.applied ? r.removed.Where(e => e.bits > 0).Select(e => e.name) : Enumerable.Empty<string>())
                    .Where(name => to.Any(other => other.synced.Contains(name))).Distinct().ToList();
            if (aligned)
            {
                var desktop = lists.Where(r => r.platform == "PC").ToList();
                var mobile = lists.Where(r => r.platform != "PC").ToList();
                if (mobile.Count == 0)
                    return desktop.Count == 1 && desktop[0].applied && desktop[0].removed.Any(e => e.bits > 0)
                        ? ("PC에서 동기화 파라미터를 지운 기록만 있어요. Quest(Android·iOS)로 올릴 때는 VRCFury가 PC 목록에 맞추므로, PC에서 지운 파라미터를 " +
                           "Quest에서 쓰면 Quest에서는 그 파라미터가 동기화되지 않아요. Quest도 정리를 켠 채로 이번 에디터 세션에 올리면 비교해 드려요.", false)
                        : (null, false);
                var lost = Removed(desktop, mobile);
                if (lost.Count > 0)
                    return ($"⚠ PC에서 지운 동기화 파라미터를 Quest(Android·iOS)에서는 써요: {string.Join(", ", lost)}. VRCFury가 Quest 업로드를 PC 목록에 맞추면서 " +
                            "이 파라미터는 Quest에서 동기화되지 않아요. 동기화하려면 예외 목록에 넣고 PC부터 다시 올려 주세요.", true);
                if (lists.Any(r => !r.synced.SequenceEqual(lists[0].synced) || !r.syncedKinds.SequenceEqual(lists[0].syncedKinds)))
                    return ("플랫폼마다 동기화 파라미터 목록이 다르지만, VRCFury의 모바일 맞춤이 켜져 있어서 Quest(Android·iOS)로 올릴 때 마지막으로 업로드한 " +
                            "PC 버전의 순서·형식·비트 수에 맞춰져요. 그래서 동기화는 어긋나지 않아요.", false);
                return (null, false);
            }
            if (lists.Count > 1 && lists.Any(r => !r.synced.SequenceEqual(lists[0].synced)))
            {
                var restore = Removed(lists, lists);
                return (restore.Count > 0
                    ? "⚠ 플랫폼마다 최종 동기화 파라미터가 달라 PC와 Quest의 동기화가 어긋날 수 있어요. 한쪽에서만 지워진 이름을 예외 목록에 넣고 " +
                      $"두 플랫폼 모두 다시 업로드해 주세요: {string.Join(", ", restore)}"
                    : "⚠ 플랫폼마다 최종 동기화 파라미터가 달라요. 정리 때문은 아니에요. 두 버전의 파라미터 구성을 확인해 주세요.", true);
            }
            if (lists.Count > 1)
            {
                // The same names in the same order can still differ in what they take on the wire (a record made before
                // this was written down has no kinds and is not compared).
                var first = lists[0];
                var differing = lists.Skip(1).Where(r => r.syncedKinds.Count == r.synced.Count && first.syncedKinds.Count == first.synced.Count)
                    .SelectMany(r => Enumerable.Range(0, r.synced.Count).Where(i => r.syncedKinds[i] != first.syncedKinds[i])
                        .Select(i => $"{r.synced[i]} ({first.platform}: {first.syncedKinds[i]}, {r.platform}: {r.syncedKinds[i]})")).Distinct().ToList();
                return differing.Count > 0
                    ? ("⚠ 이름과 순서는 같지만 형식이나 비트 수가 플랫폼마다 다른 동기화 파라미터가 있어요. 그대로 두면 PC와 Quest의 동기화가 " +
                       $"어긋나요. 두 버전에서 같게 맞춰 주세요: {string.Join(", ", differing.Take(8))}{(differing.Count > 8 ? " …" : "")}", true)
                    : (null, false);
            }
            // Nothing to compare with: the other platform was not built in this session, or its cleanup is off.
            if (lists.Count == 1 && lists[0].applied && lists[0].removed.Any(e => e.bits > 0))
                return ($"{lists[0].platform}에서 동기화 파라미터를 지운 기록만 있어요. 이 아바타를 다른 플랫폼(PC·Quest)에도 올린다면, 그쪽도 " +
                        "정리를 켠 채로 이번 에디터 세션에 올려야 두 목록을 비교해 드릴 수 있어요. 한쪽에서만 지워지면 동기화가 어긋나요.", false);
            return (null, false);
        }

        // Whether an input method has letters under way. A project set to the new Input System only refuses the old
        // Input class: there the answer is no.
        private static bool Composing()
        {
            try { return !string.IsNullOrEmpty(Input.compositionString); }
            catch (InvalidOperationException) { return false; }
        }

        private void AddException(string name)
        {
            if (string.IsNullOrEmpty(name)) return;
            EditSettings("Add parameter exception", s =>
            {
                s.keepParameters ??= new List<string>();
                if (!s.keepParameters.Contains(name)) s.keepParameters.Add(name);
            });
        }

        // One Undo step on the avatar's settings component, added when it is not there yet.
        private void EditSettings(string action, Action<AssemblyCheckerSettings> change)
        {
            if (!IsSceneAvatar(avatar)) return;
            var settings = avatar.GetComponent<AssemblyCheckerSettings>();
            if (!settings)
            {
                // Added for an exception (or to turn it on): it starts off, so adding an exception never turns the cleanup on.
                settings = Undo.AddComponent<AssemblyCheckerSettings>(avatar.gameObject);
                settings.enabled = false;
            }
            Undo.RecordObject(settings, action);
            change(settings);
            PrefabUtility.RecordPrefabInstancePropertyModifications(settings);
            EditorUtility.SetDirty(settings);
            EditorSceneManager.MarkSceneDirty(settings.gameObject.scene);
            Repaint();
        }
    }
}
#endif
