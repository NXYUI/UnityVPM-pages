#if UNITY_EDITOR
using System;
using UnityEditor;
using UnityEngine;

namespace AssemblyChecker
{
    // How the tool is used, written once: the window and the component's Inspector draw these steps, README_KO.txt has
    // them word for word (a test checks that), and the public guide walks through the same steps with the details.
    internal static class AssemblyCheckerUsage
    {
        internal const string Url = "https://github.com/NXYUI/UnityVPM-pages/blob/main/packages/dev.nxyui.assembly-checker/README.md";

        // Open or closed per surface. Closed until the user opens it: the steps show only after a click on ‘사용 방법’,
        // and what the user chose stays. EditorPrefs: the choice is the user's on this computer, in every project.
        internal const string InspectorKey = "NXYUI.AssemblyChecker.Usage.Inspector";
        internal const string WindowKey = "NXYUI.AssemblyChecker.Usage.Window";

        internal static bool IsOpen(string key) => EditorPrefs.GetBool(key, false);

        internal static readonly string[] Steps =
        {
            "NXYUI › Assembly Checker 메뉴로 창을 열고 씬의 아바타를 ‘아바타’ 칸에 넣어요. Hierarchy에서 아바타를 고르면 저절로 들어가요.",
            "‘점검하기’를 누르면 잠깐 ‘준비 중…’이 나온 뒤 아바타의 복제본을 빌드해서 점검해요. 씬의 아바타는 바뀌지 않고, 몇 초 뒤 결과와 탭 세 개가 나와요.",
            "‘점검’ 탭에서 왼쪽 항목을 고르면 오른쪽에 원인과 고치는 방법이 나와요. ‘씬에서 선택’으로 그 오브젝트를 찾아 고친 뒤 ‘점검하기’를 다시 눌러요.",
            "‘텍스처’ 탭은 업로드되는 텍스처를 크기 순으로 보여 줘요. 고르면 어느 오브젝트·머티리얼·칸에 있는지 나오고, 위의 ‘꺼진 칸’ 같은 버튼으로 걸러 볼 수 있어요.",
            "‘파라미터’ 탭에서 동기화 비트를 봐요. 안 쓰는 파라미터를 업로드할 때 지우려면 ‘이 아바타에서 정리하기’를 켜요. 아바타 루트에 Assembly Checker 컴포넌트가 붙어요.",
            "남길 파라미터(OSC 프로그램에서만 쓰는 이름 등)는 지울 파라미터 옆 ‘남기기’를 누르거나, ‘예외 목록’ 아래 칸에 적고 ‘추가’를 눌러요. 다시 점검하면 반영돼요.",
            "켜 두면 업로드(빌드)할 때마다 정리하고, 실제로 지운 것은 ‘파라미터’ 탭의 ‘마지막 빌드’에 나와요. 그만두려면 ‘이 아바타에서 정리하기’를 끄거나 컴포넌트를 지워요.",
        };

        // The foldout and, while it is open, the steps with the way to the full guide. Closed, it is one line. Nothing in
        // it follows the tool's state, so every pass of a frame draws the same controls; opening or closing ends the
        // pass, and `repaint` (the surface's own) draws the new state.
        internal static void Draw(string key, Action repaint) => Show(key, repaint, 0f);

        // In a window: the open list takes at most `room` and scrolls in its frame past that, so the columns below keep
        // the height they need at the window's minimum size.
        internal static void DrawInWindow(string key, Action repaint, float room) => Show(key, repaint, room);

        private static Vector2 scroll;

        // How tall the steps are at the width they get (the view's, less the frame and a scroll bar). The same in the
        // Layout and the Repaint pass of a frame.
        private static float StepsHeight()
        {
            float width = Mathf.Max(120f, EditorGUIUtility.currentViewWidth - 40f), height = 0f;
            for (int i = 0; i < Steps.Length; i++)
                height += EditorStyles.wordWrappedLabel.CalcHeight(new GUIContent($"{i + 1}. {Steps[i]}"), width) + 2f;
            return height;
        }

        private static void Show(string key, Action repaint, float room)
        {
            bool open = IsOpen(key);
            bool next = EditorGUILayout.Foldout(open, "사용 방법", true);
            if (next != open)
            {
                EditorPrefs.SetBool(key, next);
                // The foldout took the keyboard with the click: given back, so the window's arrow keys move in its list.
                GUI.FocusControl(null);
                repaint();
                GUIUtility.ExitGUI();
            }
            if (!open) return;
            using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
            {
                // Taller than the room it may take (a low window): the steps scroll inside the frame.
                bool scrolls = room > 0f && StepsHeight() > room;
                if (scrolls) scroll = EditorGUILayout.BeginScrollView(scroll, GUILayout.Height(room));
                for (int i = 0; i < Steps.Length; i++)
                    EditorGUILayout.LabelField($"{i + 1}. {Steps[i]}", EditorStyles.wordWrappedLabel);
                if (scrolls) EditorGUILayout.EndScrollView();
                using (new EditorGUILayout.HorizontalScope())
                {
                    if (GUILayout.Button(new GUIContent("자세한 설명 열기", Url), EditorStyles.miniButton, GUILayout.ExpandWidth(false)))
                        Application.OpenURL(Url);
                    GUILayout.Label("패키지 폴더의 README_KO.txt에도 있어요.", EditorStyles.miniLabel);
                }
            }
        }
    }
}
#endif
