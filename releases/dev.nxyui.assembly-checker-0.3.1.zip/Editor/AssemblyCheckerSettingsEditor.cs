#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;
using VRC.SDK3.Avatars.Components;

namespace AssemblyChecker
{
    // The component's Inspector: how the tool is used and the way to its window, then whether the cleanup runs at build
    // time (the checkbox next to its name is the switch), or that it cannot from where the component sits (the build
    // reads the one on the avatar root only), then the exceptions, and a way to the checker's 파라미터 tab.
    [CustomEditor(typeof(AssemblyCheckerSettings))]
    internal sealed class AssemblyCheckerSettingsEditor : Editor
    {
        public override void OnInspectorGUI()
        {
            var settings = (AssemblyCheckerSettings)target;
            // The steps cover the whole tool, most of it in the window: the button to it follows them.
            AssemblyCheckerUsage.Draw(AssemblyCheckerUsage.InspectorKey, Repaint);
            if (GUILayout.Button(new GUIContent("조립 점검기 열기",
                    "조립 점검기 창을 열고 이 아바타를 ‘아바타’ 칸에 넣어요. 점검은 창에서 ‘점검하기’를 누르면 시작해요.")))
                AssemblyCheckerWindow.ShowFor(settings.GetComponentInParent<VRCAvatarDescriptor>(true));
            EditorGUILayout.Space(8);

            var avatar = settings.GetComponent<VRCAvatarDescriptor>();
            if (!avatar) Misplaced(settings);
            else if (!settings.removeUnusedParameters)
            {
                EditorGUILayout.HelpBox("예전 버전에서 정리를 끈 설정이 남아 있어서 꺼져 있어요.", MessageType.Info);
                if (GUILayout.Button("정리 켜기"))
                {
                    Undo.RecordObject(settings, "Turn parameter cleanup on");
                    settings.removeUnusedParameters = true;
                    settings.enabled = true;
                    PrefabUtility.RecordPrefabInstancePropertyModifications(settings);
                    EditorUtility.SetDirty(settings);
                }
            }
            else
                EditorGUILayout.HelpBox(settings.enabled
                    ? "켜져 있어요. 업로드(빌드)할 때마다 애니메이터, 메뉴, Contact·PhysBone·Raycast 어디에도 없는 Expression Parameter를 지워요. " +
                      "이름 옆 체크를 끄면 멈춰요."
                    : "꺼져 있어요. 업로드할 때 파라미터를 지우지 않아요. 이름 옆 체크를 켜면 정리해요.", MessageType.Info);

            // Under the name the window gives it, not the field's ("Keep Parameters").
            serializedObject.Update();
            EditorGUILayout.PropertyField(serializedObject.FindProperty(nameof(AssemblyCheckerSettings.keepParameters)),
                new GUIContent("예외 목록", "지우지 않을 파라미터 이름이에요. 끝에 *를 붙이면 그 이름으로 시작하는 파라미터를 모두 남겨요."), true);
            serializedObject.ApplyModifiedProperties();
            EditorGUILayout.LabelField("예외 목록의 이름은 지우지 않아요. 끝에 *를 붙이면 그 이름으로 시작하는 파라미터를 모두 남겨요.", EditorStyles.wordWrappedMiniLabel);

            // Only where a preview can be made; elsewhere the box above says what to do first.
            if (avatar && GUILayout.Button(new GUIContent("지울 파라미터 미리 보기",
                    "조립 점검기를 열고 이 아바타를 점검해서, 지울 것과 남길 것을 파라미터 탭에 보여 줘요. 복제본을 빌드하느라 몇 초 걸려요.")))
                AssemblyCheckerWindow.ShowParameters(avatar);
        }

        // On a child, or on an object that is no avatar: the build never reads the component. Said here, with a way to
        // put it right.
        private static void Misplaced(AssemblyCheckerSettings settings)
        {
            var avatar = settings.GetComponentInParent<VRCAvatarDescriptor>(true);
            if (!avatar)
            {
                EditorGUILayout.HelpBox("⚠ 여기서는 동작하지 않아요. 빌드는 아바타 루트(VRC Avatar Descriptor가 있는 오브젝트)에 붙은 컴포넌트만 읽어요. " +
                                        "이 오브젝트 위쪽에는 아바타가 없어요.", MessageType.Warning);
                return;
            }
            bool taken = avatar.GetComponent<AssemblyCheckerSettings>();
            EditorGUILayout.HelpBox($"⚠ 여기서는 동작하지 않아요. 빌드는 아바타 루트 ‘{avatar.name}’에 붙은 컴포넌트만 읽어요." +
                                    (taken ? " 루트에 이미 컴포넌트가 있으니 이 컴포넌트는 지워도 돼요." : ""), MessageType.Warning);
            if (!taken && GUILayout.Button(new GUIContent("아바타 루트로 옮기기", "이 컴포넌트를 설정 그대로 아바타 루트로 옮겨요. 실행 취소(Ctrl+Z) 한 번으로 되돌릴 수 있어요.")))
            {
                Move(settings, avatar.gameObject);
                GUIUtility.ExitGUI();
            }
        }

        // One Undo step: the component with its settings on the root, and gone from where it was.
        private static void Move(AssemblyCheckerSettings settings, GameObject root)
        {
            Undo.IncrementCurrentGroup();
            Undo.SetCurrentGroupName("Move Assembly Checker to the avatar root");
            int group = Undo.GetCurrentGroup();
            var moved = Undo.AddComponent<AssemblyCheckerSettings>(root);
            EditorUtility.CopySerialized(settings, moved);
            PrefabUtility.RecordPrefabInstancePropertyModifications(moved);
            Undo.DestroyObjectImmediate(settings);
            Undo.CollapseUndoOperations(group);
            EditorGUIUtility.PingObject(root);
        }
    }
}
#endif
