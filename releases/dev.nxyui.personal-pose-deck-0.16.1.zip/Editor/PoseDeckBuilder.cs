using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using nadena.dev.modular_avatar.core;
using UnityEditor;
using UnityEditor.Animations;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using VRC.SDK3.Avatars.Components;
using VRC.SDK3.Avatars.ScriptableObjects;
using Object = UnityEngine.Object;
using Control = VRC.SDK3.Avatars.ScriptableObjects.VRCExpressionsMenu.Control;

namespace PersonalPoseDeck
{
    internal static class PoseDeckBuilder
    {
        internal static readonly string[] CategoryNames = { "앉기", "눕기", "서기", "기타" };
        private static readonly string[] SlotStates = { "Left", "Right", "Left Init", "Right Init" };
        private const string Emote = "VRCEmote";
        private const string Float = "Go/Float";
        private const string PoseMachine = "VRCEmote 210 -253";
        private const string GeneratedBaseName = "PoseDeckBase.controller";
        private const string GeneratedMenuName = "PoseDeckInstaller.asset";
        private const string ExistingInstallationName = "PoseDeckExistingInstallation.asset";
        private const string GeneratedFolderPrefix = "PoseDeck_Generated";
        // GoGoLoco's Action layer sets Go/Float when a pose button is pressed (0.25 on custom slots). Pressing ▲/▼ during a
        // pose sets Go/PosePlaySpace, after which GoGoLoco stops applying start heights; the deck follows the same rule.
        internal const float DefaultStartHeight = 0.25f;
        private const string PlaySpace = "Go/PosePlaySpace";
        private const string HeightStateSuffix = " Height";
        // Medians of GoGoLoco 1.8.6's own presets per pose menu (Sit, Floor, Prone/Laydown) and its custom-slot value.
        internal static readonly (string Label, float Value)[] HeightPresets =
            { ("서기", .25f), ("의자", .19f), ("바닥", .12f), ("눕기", .06f) };
        // The slot layout, clip names and parameters below match this GoGoLoco release only.
        internal const string SupportedVendorVersion = "1.8.6";
        internal static readonly string[] VendorRoots = { "Assets/GoGo/GoLoco/", "Packages/gogoloco/Runtime/GoGo/GoLoco/" };
        private static readonly string[] VendorPoseMenus =
        {
            "GoMenuPoseFloor", "GoMenuPoseProne", "GoMenuPoseSit",
            "SubMenuPoses/GoMenuPoseFloor+", "SubMenuPoses/GoMenuPoseLaydown+", "SubMenuPoses/GoMenuPoseSit+"
        };

        internal sealed class Target
        {
            public ModularAvatarMergeAnimator Base;
            public ModularAvatarMenuInstaller Menu;
        }

        private sealed class Slot
        {
            public int Number;
            public AnimatorStateMachine Machine;
            public AnimatorState[] States;
            public BlendTree Tree;
            public bool Blank;
            public AnimationClip[] Clips;
        }

        private sealed class Assignment
        {
            public int Number;
            public Control NativeControl;
        }

        private sealed class Plan
        {
            public Assignment[] Rows;
            public int NativeCount;
            public int CustomCapacity;
            public int BlankCapacity;
        }

        internal static Target GetTarget(GameObject go)
        {
            if (!go || !go.scene.IsValid() || EditorUtility.IsPersistent(go) ||
                !go.GetComponentInParent<VRCAvatarDescriptor>(true))
                throw new InvalidOperationException("Hierarchy에서 아바타 아래의 GoGoLoco MA 오브젝트를 선택해 주세요.");
            return GetBindings(go);
        }

        internal static Target GetBindings(GameObject go)
        {
            var bases = go.GetComponents<ModularAvatarMergeAnimator>()
                .Where(x => x.enabled && x.layerType == VRCAvatarDescriptor.AnimLayerType.Base).ToArray();
            var installers = go.GetComponents<ModularAvatarMenuInstaller>().Where(x => x.enabled).ToArray();
            if (bases.Length != 1 || installers.Length != 1)
                throw new InvalidOperationException("활성 MA Merge Animator (Base)와 MA Menu Installer가 하나씩 붙은 GoGoLoco 오브젝트를 선택해 주세요.");
            return new Target { Base = bases[0], Menu = installers[0] };
        }

        private static bool IsGenerated(AnimatorController controller, VRCExpressionsMenu menu) =>
            (controller && Path.GetFileName(AssetDatabase.GetAssetPath(controller)) == GeneratedBaseName) ||
            (menu && Path.GetFileName(AssetDatabase.GetAssetPath(menu)) == GeneratedMenuName);

        private static (AnimatorController controller, VRCExpressionsMenu menu, PoseDeckPreset installedPreset, bool legacy)
            Sources(PoseDeckPreset preset, Target target)
        {
            var currentBase = target.Base.animator as AnimatorController;
            var currentMenu = target.Menu.menuToAppend;
            if (!currentBase || !currentMenu)
                throw new InvalidOperationException("GoGoLoco Base 컨트롤러와 설치 메뉴가 모두 연결되어 있어야 합니다.");

            var menuPath = AssetDatabase.GetAssetPath(currentMenu);
            if (Path.GetFileName(menuPath) == GeneratedMenuName)
            {
                var marker = AssetDatabase.LoadAssetAtPath<PoseDeckExistingInstallation>(
                    menuPath.Substring(0, menuPath.LastIndexOf('/') + 1) + ExistingInstallationName);
                if (marker)
                {
                    if (marker.appliedBase != currentBase || marker.appliedMenu != currentMenu ||
                        !marker.stockBase || !marker.stockMenu || IsGenerated(marker.stockBase, marker.stockMenu))
                        throw new InvalidOperationException("현재 생성본의 Base·메뉴 연결 또는 GoGoLoco 원본 참조를 확인할 수 없습니다.");
                    return (marker.stockBase, marker.stockMenu, marker.preset, false);
                }
            }
            if (!IsGenerated(currentBase, currentMenu)) return (currentBase, currentMenu, null, false);

            bool MatchesLegacy(PoseDeckPreset p) => p && p.appliedBase == currentBase && p.appliedMenu == currentMenu &&
                p.stockBase && p.stockMenu && !IsGenerated(p.stockBase, p.stockMenu);
            var matches = AssetDatabase.FindAssets("t:PoseDeckPreset", new[] { "Assets" })
                .Select(guid => AssetDatabase.LoadAssetAtPath<PoseDeckPreset>(AssetDatabase.GUIDToAssetPath(guid)))
                .Prepend(preset).Where(MatchesLegacy).Distinct().ToArray();
            if (matches.Length == 0)
                throw new InvalidOperationException("예전 생성본의 원래 Base·메뉴를 찾지 못했습니다. 그 생성본을 만든 프리셋과 GoGoLoco 원본 파일이 프로젝트에 있는지 확인해 주세요.");
            var previous = matches[0];
            if (matches.Any(p => p.stockBase != previous.stockBase || p.stockMenu != previous.stockMenu))
                throw new InvalidOperationException("같은 예전 생성본에 서로 다른 GoGoLoco 원본이 기록되어 있어 연결을 바꾸지 않았습니다.");
            return (previous.stockBase, previous.stockMenu, previous, true);
        }

        private static IEnumerable<Control> Controls(VRCExpressionsMenu menu, HashSet<VRCExpressionsMenu> seen)
        {
            if (!menu || !seen.Add(menu) || menu.controls == null) yield break;
            foreach (var c in menu.controls)
            {
                if (c == null) continue;
                yield return c;
                if (c.type == Control.ControlType.SubMenu)
                    foreach (var child in Controls(c.subMenu, seen)) yield return child;
            }
        }

        private static IEnumerable<AnimatorStateMachine> Machines(AnimatorStateMachine machine)
        {
            yield return machine;
            foreach (var child in machine.stateMachines)
                foreach (var nested in Machines(child.stateMachine)) yield return nested;
        }

        private static IEnumerable<BlendTree> PoseBranches(BlendTree tree)
        {
            if (tree.blendParameter == "VRModeProxy" && tree.children.Length == 2 &&
                tree.children.All(c => c.motion is AnimationClip))
            {
                yield return tree;
                yield break;
            }
            foreach (var child in tree.children)
                if (child.motion is BlendTree nested)
                    foreach (var branch in PoseBranches(nested)) yield return branch;
        }

        // Names the installed GoGoLoco package version when it differs from the supported one. Empty for Assets installs.
        internal static string VendorVersionNote(string assetPath)
        {
            var package = string.IsNullOrEmpty(assetPath) ? null : UnityEditor.PackageManager.PackageInfo.FindForAssetPath(assetPath);
            if (package == null || package.version == SupportedVendorVersion) return "";
            return $" 설치된 {(string.IsNullOrEmpty(package.displayName) ? package.name : package.displayName)} {package.version}은(는) 지원 버전 {SupportedVendorVersion}과 다릅니다.";
        }

        private static List<Slot> FindSlots(AnimatorController controller)
        {
            var machine = controller.layers.SelectMany(l => Machines(l.stateMachine))
                .SingleOrDefault(m => m.name == PoseMachine);
            if (!machine) throw new InvalidOperationException($"GoGoLoco {SupportedVendorVersion} 포즈 구조를 찾지 못했습니다. 지원되는 All (Modular Avatar) 프리팹과 Base를 확인해 주세요." +
                VendorVersionNote(AssetDatabase.GetAssetPath(controller)));
            var slots = new List<Slot>();
            foreach (var child in machine.stateMachines)
            {
                if (!int.TryParse(child.stateMachine.name, out int n) || n < 210 || n > 253) continue;
                var states = child.stateMachine.states.Select(s => s.state).Where(s => SlotStates.Contains(s.name)).ToArray();
                if (states.Length != SlotStates.Length || states.Select(s => s.name).Distinct().Count() != SlotStates.Length ||
                    !(states[0].motion is BlendTree tree) || tree.name != "go_" + n || states.Any(s => s.motion != tree)) continue;
                var branches = PoseBranches(tree).ToArray();
                if (branches.Length != 1) continue;
                var clips = branches[0].children.Select(c => (AnimationClip)c.motion).Distinct().ToArray();
                bool blank = clips.All(c => c.name == "go_pose_desktop" || c.name == "go_pose_vr");
                slots.Add(new Slot { Number = n, Machine = child.stateMachine, States = states, Tree = tree, Blank = blank, Clips = clips });
            }
            return slots.OrderByDescending(s => s.Blank).ThenBy(s => s.Number).ToList();
        }

        // What the start-height preview needs from a stock GoGoLoco: its Base, an empty slot to borrow, the stock clips
        // with their slots, and the start height GoGoLoco's Action layer gives each slot (read only).
        internal sealed class PreviewSource
        {
            public AnimatorController Base;
            public int BlankSlot;
            public AnimationClip[] BlankClips;
            public Dictionary<AnimationClip, int> NativeSlots;
            public Dictionary<int, float> StartHeights;
            // GoGoLoco's additive reference pose (go_additive_reference_pose); see NeedsReference.
            public AnimationClip Reference;
            private readonly Dictionary<AnimationClip, int> copies = new Dictionary<AnimationClip, int>();

            // The stock slot a clip plays in game, like PlanRows: the stock clip itself or an unedited copy of it
            // from the other GoGoLoco install location. -1 for a custom clip.
            internal int SlotFor(AnimationClip clip)
            {
                if (!clip) return -1;
                if (NativeSlots.TryGetValue(clip, out int slot) || copies.TryGetValue(clip, out slot)) return slot;
                string path = AssetDatabase.GetAssetPath(clip);
                slot = NativeSlots.Where(n => IsSameVendorClip(path, AssetDatabase.GetAssetPath(n.Key)))
                    .Select(n => n.Value).DefaultIfEmpty(-1).First();
                copies[clip] = slot;
                return slot;
            }

            internal float StartHeightFor(AnimationClip clip) =>
                SlotFor(clip) is int slot && slot >= 0 && StartHeights.TryGetValue(slot, out float value) ? value : DefaultStartHeight;
        }

        internal static PreviewSource PreviewSourceFor(AnimatorController stock, AnimatorController action)
        {
            var slots = FindSlots(stock);
            var blank = slots.FirstOrDefault(s => s.Blank) ?? throw new InvalidOperationException("GoGoLoco에서 빈 포즈 슬롯을 찾지 못했습니다.");
            var native = new Dictionary<AnimationClip, int>();
            foreach (var slot in slots.Where(s => !s.Blank))
                foreach (var clip in slot.Clips)
                    if (clip && !native.ContainsKey(clip)) native.Add(clip, slot.Number);
            var heights = new Dictionary<int, float>();
            var driver = action ? action.layers.SelectMany(l => Machines(l.stateMachine)).FirstOrDefault(m => m.name == "Float Driver") : null;
            if (driver)
                foreach (var child in driver.states)
                {
                    if (!int.TryParse(child.state.name, out int n)) continue;
                    var set = child.state.behaviours.OfType<VRCAvatarParameterDriver>().SelectMany(d => d.parameters)
                        .FirstOrDefault(p => p.name == Float && p.type == VRC.SDKBase.VRC_AvatarParameterDriver.ChangeType.Set);
                    if (set != null) heights[n] = set.value;
                }
            return new PreviewSource
            {
                Base = stock, BlankSlot = blank.Number, BlankClips = blank.Clips, NativeSlots = native, StartHeights = heights,
                Reference = AdditiveReference(slots.SelectMany(s => s.Clips)),
            };
        }

        // GoGoLoco's "Poses" layer is additive over its locomotion, and its pose clips are measured against
        // go_additive_reference_pose (their additive reference pose). A clip with no reference is measured against its
        // own first frame, which turns a still pose into no change at all, and a clip made for another system (e.g. an
        // avatar's own pose menu) carries that system's reference. Such clips play as copies that carry GoGoLoco's.
        internal static AnimationClip AdditiveReference(IEnumerable<AnimationClip> stockClips) =>
            stockClips.Where(c => c).Select(AnimationUtility.GetAnimationClipSettings)
                .Where(s => s.hasAdditiveReferencePose && s.additiveReferencePoseClip)
                .GroupBy(s => s.additiveReferencePoseClip).OrderByDescending(g => g.Count()).Select(g => g.Key).FirstOrDefault();

        internal static bool NeedsReference(AnimationClip clip, AnimationClip reference)
        {
            if (!clip || !reference || !clip.humanMotion || clip == reference) return false;
            var settings = AnimationUtility.GetAnimationClipSettings(clip);
            return !settings.hasAdditiveReferencePose || settings.additiveReferencePoseClip != reference ||
                   !Mathf.Approximately(settings.additiveReferencePoseTime, 0f);
        }

        // An unsaved copy of the clip that uses GoGoLoco's reference pose; the clip itself is left alone.
        internal static AnimationClip WithReference(AnimationClip clip, AnimationClip reference)
        {
            var copy = Object.Instantiate(clip);
            copy.name = clip.name;
            var settings = AnimationUtility.GetAnimationClipSettings(copy);
            settings.hasAdditiveReferencePose = true;
            settings.additiveReferencePoseClip = reference;
            settings.additiveReferencePoseTime = 0f;
            AnimationUtility.SetAnimationClipSettings(copy, settings);
            return copy;
        }

        private static string SafeFileName(string name)
        {
            var invalid = Path.GetInvalidFileNameChars();
            return new string(name.Select(ch => invalid.Contains(ch) ? '_' : ch).ToArray());
        }

        private static bool IsPoseControl(Control c) =>
            c.parameter?.name == Emote && c.value >= 210 && c.value <= 253 && c.value == (int)c.value &&
            (c.type == Control.ControlType.Button || (c.type == Control.ControlType.RadialPuppet &&
                c.subParameters?.FirstOrDefault()?.name == "Go/PoseRadial"));

        private static string VendorRoot(string path) =>
            VendorRoots.FirstOrDefault(root => path.StartsWith(root, StringComparison.Ordinal));

        private static IEnumerable<Control> AdditionalPoseControls(AnimatorController controller)
        {
            var root = VendorRoot(AssetDatabase.GetAssetPath(controller));
            if (root == null) yield break;
            var seen = new HashSet<VRCExpressionsMenu>();
            foreach (var name in VendorPoseMenus)
            {
                var menu = AssetDatabase.LoadAssetAtPath<VRCExpressionsMenu>(root + "MainMenu/Menu/SubMenu/" + name + ".asset");
                foreach (var control in Controls(menu, seen))
                    if (IsPoseControl(control)) yield return control;
            }
        }

        private static string ClipPathOnDisk(string path)
        {
            if (path.StartsWith("Assets/", StringComparison.Ordinal)) return path;
            var package = UnityEditor.PackageManager.PackageInfo.FindForAssetPath(path);
            return package == null ? null : Path.Combine(package.resolvedPath,
                path.Substring(("Packages/" + package.name + "/").Length));
        }

        private static bool IsSameVendorClip(string left, string right)
        {
            var leftRoot = VendorRoot(left);
            var rightRoot = VendorRoot(right);
            if (leftRoot == null || rightRoot == null || leftRoot == rightRoot ||
                !left.EndsWith(".anim", StringComparison.OrdinalIgnoreCase) ||
                !string.Equals(left.Substring(leftRoot.Length), right.Substring(rightRoot.Length), StringComparison.Ordinal))
                return false;
            // A locally edited copy at the same vendor path is still a custom clip.
            try
            {
                var leftFile = ClipPathOnDisk(left);
                var rightFile = ClipPathOnDisk(right);
                return leftFile != null && rightFile != null &&
                    string.Equals(File.ReadAllText(leftFile).Replace("\r\n", "\n"),
                        File.ReadAllText(rightFile).Replace("\r\n", "\n"), StringComparison.Ordinal);
            }
            catch (IOException) { return false; }
            catch (UnauthorizedAccessException) { return false; }
        }

        private static Plan PlanRows(PoseDeckPreset preset, AnimatorController controller, Control[] controls)
        {
            var slots = FindSlots(controller);
            var menuControls = controls.Where(IsPoseControl).OrderByDescending(c => c.type == Control.ControlType.RadialPuppet)
                .Concat(AdditionalPoseControls(controller)).ToLookup(c => (int)c.value);
            var native = slots.Where(s => !s.Blank && menuControls[s.Number].Any())
                .SelectMany(s => s.Clips.Select(clip => (s.Number, Clip: clip, Path: AssetDatabase.GetAssetPath(clip))))
                .ToArray();
            var rows = new Assignment[preset.poses.Count];
            var reserved = new HashSet<int>();
            int nativeCount = 0;
            // Reserve the original slot before assigning any custom clips, regardless of menu order.
            for (int i = 0; i < rows.Length; i++)
            {
                var clip = preset.poses[i].clip;
                if (!clip) continue;
                var match = Array.Find(native, x => x.Clip == clip);
                if (!match.Clip)
                {
                    var path = AssetDatabase.GetAssetPath(clip);
                    match = Array.Find(native, x => IsSameVendorClip(path, x.Path));
                }
                if (!match.Clip) continue;
                rows[i] = new Assignment { Number = match.Number, NativeControl = menuControls[match.Number].First() };
                reserved.Add(match.Number);
                nativeCount++;
            }

            var buttons = new HashSet<int>(controls.Where(c => IsPoseControl(c) && c.type == Control.ControlType.Button)
                .Select(c => (int)c.value));
            var custom = slots.Where(s => !reserved.Contains(s.Number) && (s.Blank || buttons.Contains(s.Number))).ToArray();
            int next = 0;
            for (int i = 0; i < rows.Length && next < custom.Length; i++)
                if (rows[i] == null) rows[i] = new Assignment { Number = custom[next++].Number };
            return new Plan { Rows = rows, NativeCount = nativeCount, CustomCapacity = custom.Length, BlankCapacity = custom.Count(s => s.Blank) };
        }

        private static string Title(PoseEntry row) => string.IsNullOrWhiteSpace(row.label) ? row.clip.name : row.label.Trim();

        private static void ValidateRows(PoseDeckPreset preset)
        {
            if (string.IsNullOrWhiteSpace(preset.menuTitle)) throw new InvalidOperationException("메뉴 이름을 입력해 주세요.");
            if (preset.poses.Count == 0) throw new InvalidOperationException("포즈를 하나 이상 추가해 주세요.");
            for (int i = 0; i < preset.poses.Count; i++)
            {
                var clip = preset.poses[i].clip;
                if (!clip || !clip.humanMotion || clip.legacy || !EditorUtility.IsPersistent(clip))
                    throw new InvalidOperationException($"포즈 {i + 1}: 프로젝트에 저장된 Humanoid 애니메이션 클립을 지정해 주세요. FBX는 Rig를 Humanoid로 임포트해야 합니다.");
            }
            if (preset.poses.GroupBy(p => (p.category, Title(p))).Any(g => g.Count() > 1))
                throw new InvalidOperationException("같은 분류에 중복된 이름이 있습니다. 포즈 이름을 구분해 주세요.");
        }

        internal static string Preview(PoseDeckPreset preset, GameObject go)
        {
            var (controller, menu, installed, legacy) = Sources(preset, ExistingTarget(go));
            var summary = Preview(preset, controller, menu);
            if (legacy)
                return $"현재 연결: 예전 생성본 ‘{installed.name}’. 생성 및 적용을 누르면 ‘{preset.name}’으로 갱신합니다.\n" + summary;
            if (installed && installed != preset)
                return $"현재 연결: ‘{installed.name}’. 생성 및 적용을 누르면 ‘{preset.name}’으로 바뀝니다.\n" + summary;
            return summary;
        }

        internal static string Preview(PoseDeckPreset preset, AnimatorController controller, VRCExpressionsMenu menu)
        {
            var plan = PlanRows(preset, controller, Controls(menu, new HashSet<VRCExpressionsMenu>()).ToArray());
            int custom = plan.Rows.Length - plan.NativeCount;
            int heights = preset.poses.Count(p => p.overrideHeight);
            var summary = $"원본 높이 유지: {plan.NativeCount}개. 커스텀 포즈: {custom}/{plan.CustomCapacity}개 (빈 슬롯 {plan.BlankCapacity}개)." +
                (heights > 0 ? $" 시작 높이 직접 지정: {heights}개." : "");
            var root = VendorRoot(AssetDatabase.GetAssetPath(controller));
            var unmatched = preset.poses.Select((row, i) => (row, i))
                .Where(x => x.row.clip && plan.Rows[x.i]?.NativeControl == null)
                .Select(x => (label: Title(x.row), root: VendorRoot(AssetDatabase.GetAssetPath(x.row.clip))))
                .Where(x => x.root != null).ToArray();
            if (unmatched.Length == 0) return summary;
            var labels = string.Join(", ", unmatched.Take(3).Select(x => x.label)) +
                (unmatched.Length > 3 ? $" 외 {unmatched.Length - 3}개" : "");
            return summary + $"\n원본 높이 프리셋이 연결되지 않은 GoGoLoco 클립: {labels}."
                + (root != null && unmatched.Any(x => x.root != root)
                    ? $" 다른 경로에서 가져왔다면 현재 Base가 사용하는 {root} 쪽도 확인해 주세요." : "");
        }

        private static BlendTree CloneTree(BlendTree source, AnimationClip pose, AnimatorController destination,
            Dictionary<BlendTree, BlendTree> cache)
        {
            if (cache.TryGetValue(source, out var previous)) return previous;
            var copy = Object.Instantiate(source);
            copy.name = source.name;
            copy.hideFlags = HideFlags.HideInHierarchy;
            AssetDatabase.AddObjectToAsset(copy, destination);
            cache.Add(source, copy);
            var children = source.children;
            bool replace = source.blendParameter == "VRModeProxy" && children.Length == 2 &&
                children.All(c => c.motion is AnimationClip);
            for (int i = 0; i < children.Length; i++)
            {
                if (replace) children[i].motion = pose;
                else if (children[i].motion is BlendTree child) children[i].motion = CloneTree(child, pose, destination, cache);
            }
            copy.children = children;
            EditorUtility.SetDirty(copy);
            return copy;
        }

        // GoGoLoco objects under root whose Base controller or installer menu points at an asset that no longer exists,
        // e.g. a generated folder that went to the trash before an undo brought the old link back.
        internal static GameObject[] FindBrokenLinks(GameObject root)
        {
            if (!root) return Array.Empty<GameObject>();
            return root.GetComponentsInChildren<ModularAvatarMenuInstaller>(true)
                .Where(menu => IsMissing(menu, "menuToAppend") || menu.GetComponents<ModularAvatarMergeAnimator>()
                    .Any(m => m.layerType == VRCAvatarDescriptor.AnimLayerType.Base && IsMissing(m, "animator")))
                .Select(menu => menu.gameObject).Distinct().ToArray();
        }

        private static bool IsMissing(Object component, string property)
        {
            var value = new SerializedObject(component).FindProperty(property);
            return value != null && value.propertyType == SerializedPropertyType.ObjectReference &&
                   !value.objectReferenceValue && value.objectReferenceInstanceIDValue != 0;
        }

        // Puts the broken Base controller and menu back to the GoGoLoco prefab's own values. Returns how many changed.
        internal static int RevertBrokenLinks(GameObject go)
        {
            var broken = go.GetComponents<ModularAvatarMergeAnimator>()
                .Where(m => m.layerType == VRCAvatarDescriptor.AnimLayerType.Base && IsMissing(m, "animator"))
                .Select(m => ((Object)m, "animator"))
                .Concat(go.GetComponents<ModularAvatarMenuInstaller>().Where(m => IsMissing(m, "menuToAppend"))
                    .Select(m => ((Object)m, "menuToAppend"))).ToArray();
            if (broken.Any(b => !PrefabUtility.IsPartOfPrefabInstance(b.Item1)))
                throw new InvalidOperationException($"‘{go.name}’은 GoGoLoco 프리팹 인스턴스가 아니라 원본 값을 알 수 없습니다. Inspector에서 Base와 메뉴를 직접 연결해 주세요.");
            foreach (var (component, property) in broken)
            {
                var value = new SerializedObject(component).FindProperty(property);
                if (value.prefabOverride) PrefabUtility.RevertPropertyOverride(value, InteractionMode.UserAction);
            }
            EditorSceneManager.MarkSceneDirty(go.scene);
            return broken.Length;
        }

        // A Pose Deck Base generated before 0.15.0 holds custom clips as they were, without GoGoLoco's additive reference
        // pose (see NeedsReference), so in game those poses barely show until the deck is generated again. Returns the
        // GoGoLoco objects under root that carry such a Base, with the affected pose names.
        internal static (GameObject gogo, string[] poses)[] FindStaleDecks(GameObject root)
        {
            var found = new List<(GameObject, string[])>();
            if (!root) return found.ToArray();
            foreach (var merge in root.GetComponentsInChildren<ModularAvatarMergeAnimator>(true))
            {
                if (merge.layerType != VRCAvatarDescriptor.AnimLayerType.Base || !(merge.animator is AnimatorController controller) ||
                    Path.GetFileName(AssetDatabase.GetAssetPath(controller)) != GeneratedBaseName) continue;
                List<Slot> slots;
                try { slots = FindSlots(controller); }
                catch (InvalidOperationException) { continue; }
                var clips = slots.SelectMany(s => s.Clips).Where(c => c).Distinct().ToArray();
                var reference = AdditiveReference(clips);
                var stale = clips.Where(c => VendorRoot(AssetDatabase.GetAssetPath(c)) == null && NeedsReference(c, reference))
                    .Select(c => c.name).Distinct().ToArray();
                if (stale.Length > 0) found.Add((merge.gameObject, stale));
            }
            return found.ToArray();
        }

        // Moves a preset to the trash (recoverable, like replaced generated folders). Decks made from it keep working;
        // only generating them again needs the preset.
        internal static void TrashPreset(PoseDeckPreset preset)
        {
            string path = preset ? AssetDatabase.GetAssetPath(preset) : null;
            if (string.IsNullOrEmpty(path) || !path.StartsWith("Assets/", StringComparison.Ordinal) || !PoseDeckGeneratedCleanup.Trash(path))
                throw new IOException($"프리셋 ‘{(preset ? preset.name : "?")}’을 휴지통으로 옮기지 못했습니다.");
        }

        // The PoseDeck_Generated folder holding a generated installer menu, or null.
        internal static string GeneratedFolderOf(VRCExpressionsMenu menu)
        {
            string path = menu ? AssetDatabase.GetAssetPath(menu) : "";
            int slash = path.LastIndexOf('/');
            if (slash < 0 || path.Substring(slash + 1) != GeneratedMenuName) return null;
            string folder = path.Substring(0, slash);
            return folder.Substring(folder.LastIndexOf('/') + 1).StartsWith(GeneratedFolderPrefix, StringComparison.Ordinal) ? folder : null;
        }

        // Saves rendered pose icons as PNGs in the generated folder, imported for the VRChat menu (256 px, alpha).
        private static Dictionary<AnimationClip, Texture2D> SaveIcons(string folder, PoseDeckPreset preset,
            IReadOnlyDictionary<AnimationClip, Texture2D> icons)
        {
            var saved = new Dictionary<AnimationClip, Texture2D>();
            if (icons == null || icons.Count == 0) return saved;
            AssetDatabase.CreateFolder(folder, "Icons");
            int n = 0;
            foreach (var clip in preset.poses.Select(p => p.clip).Where(c => c).Distinct())
            {
                if (!icons.TryGetValue(clip, out var texture) || !texture) continue;
                string path = $"{folder}/Icons/{++n:00}_{SafeFileName(clip.name)}.png";
                File.WriteAllBytes(path, texture.EncodeToPNG());
                AssetDatabase.ImportAsset(path, ImportAssetOptions.ForceSynchronousImport);
                if (AssetImporter.GetAtPath(path) is TextureImporter importer)
                {
                    importer.textureType = TextureImporterType.Default;
                    importer.alphaIsTransparency = true;
                    importer.mipmapEnabled = false;
                    importer.wrapMode = TextureWrapMode.Clamp;
                    importer.maxTextureSize = 256;
                    importer.textureCompression = TextureImporterCompression.CompressedHQ;
                    importer.SaveAndReimport();
                }
                var asset = AssetDatabase.LoadAssetAtPath<Texture2D>(path);
                if (asset) saved[clip] = asset;
            }
            return saved;
        }

        private static void EnsureInAsset(Object item, Object owner)
        {
            if (item && !EditorUtility.IsPersistent(item)) AssetDatabase.AddObjectToAsset(item, owner);
        }

        // Each slot goes Init → (button released) → Left/Right. A one-frame "Left Height"/"Right Height" step between them
        // sets Go/Float to the pose's start height, after GoGoLoco's Action layer has set its own value on the press.
        // The step is skipped once ▲/▼ was used (Go/PosePlaySpace), like GoGoLoco's own presets.
        private static void ApplyStartHeights(AnimatorController controller, IReadOnlyDictionary<int, Slot> slots,
            PoseDeckPreset preset, Assignment[] rows)
        {
            bool hasPlaySpace = controller.parameters.Any(p => p.name == PlaySpace && p.type == AnimatorControllerParameterType.Bool);
            var done = new HashSet<int>();
            for (int i = 0; i < preset.poses.Count; i++)
            {
                var row = preset.poses[i];
                // A stock slot shared by two rows gets the first row's height.
                if (!row.overrideHeight || !done.Add(rows[i].Number)) continue;
                var slot = slots[rows[i].Number];
                foreach (var side in new[] { "Left", "Right" })
                {
                    var pose = slot.States.First(s => s.name == side);
                    var init = slot.States.First(s => s.name == side + " Init");
                    var position = slot.Machine.states.FirstOrDefault(c => c.state == pose).position + new Vector3(0, 60, 0);
                    var step = slot.Machine.AddState(side + HeightStateSuffix, position);
                    EnsureInAsset(step, controller);
                    step.motion = pose.motion;
                    step.mirror = pose.mirror;
                    step.speed = pose.speed;
                    step.iKOnFeet = pose.iKOnFeet;
                    step.writeDefaultValues = pose.writeDefaultValues;
                    var driver = step.AddStateMachineBehaviour<VRCAvatarParameterDriver>();
                    EnsureInAsset(driver, controller);
                    driver.localOnly = false;
                    driver.parameters.Add(new VRC.SDKBase.VRC_AvatarParameterDriver.Parameter
                    {
                        type = VRC.SDKBase.VRC_AvatarParameterDriver.ChangeType.Set, name = Float, value = Mathf.Clamp01(row.height),
                    });

                    var enter = init.AddTransition(step);
                    EnsureInAsset(enter, controller);
                    enter.hasExitTime = false;
                    enter.hasFixedDuration = true;
                    enter.duration = 0f;
                    enter.exitTime = 0f;
                    enter.AddCondition(AnimatorConditionMode.Equals, 0, Emote);
                    if (hasPlaySpace) enter.AddCondition(AnimatorConditionMode.IfNot, 0, PlaySpace);
                    // Checked before Init's own "VRCEmote == 0 → Left", which still handles the play-space case.
                    init.transitions = new[] { enter }.Concat(init.transitions.Where(t => t != enter)).ToArray();

                    var leave = step.AddTransition(pose);
                    EnsureInAsset(leave, controller);
                    leave.hasExitTime = true;
                    leave.exitTime = 0f;
                    leave.hasFixedDuration = true;
                    leave.duration = 0f;
                    foreach (var o in new Object[] { step, driver, enter, leave, init }) EditorUtility.SetDirty(o);
                }
            }
        }

        private static IEnumerable<BlendTree> TreeAndChildren(BlendTree tree)
        {
            yield return tree;
            foreach (var child in tree.children)
                if (child.motion is BlendTree nested)
                    foreach (var descendant in TreeAndChildren(nested)) yield return descendant;
        }

        // The copied Base still holds the stock trees of the slots that now play a custom clip. Remove only those,
        // and only when no state, including a synced layer override, still reaches them.
        private static void RemoveUnusedTrees(AnimatorController controller, IEnumerable<BlendTree> replaced)
        {
            var reachable = new HashSet<Motion>();
            void Reach(Motion motion)
            {
                if (!motion || !reachable.Add(motion) || !(motion is BlendTree tree)) return;
                foreach (var child in tree.children) Reach(child.motion);
            }
            var layers = controller.layers;
            foreach (var layer in layers)
            {
                foreach (var machine in Machines(layer.stateMachine))
                    foreach (var child in machine.states) Reach(child.state.motion);
                if (layer.syncedLayerIndex < 0 || layer.syncedLayerIndex >= layers.Length) continue;
                foreach (var machine in Machines(layers[layer.syncedLayerIndex].stateMachine))
                    foreach (var child in machine.states) Reach(layer.GetOverrideMotion(child.state));
            }
            string path = AssetDatabase.GetAssetPath(controller);
            foreach (var tree in replaced.SelectMany(TreeAndChildren).Distinct().ToArray())
            {
                if (!tree || reachable.Contains(tree) || AssetDatabase.GetAssetPath(tree) != path) continue;
                AssetDatabase.RemoveObjectFromAsset(tree);
                Object.DestroyImmediate(tree, true);
            }
        }

        // PoseDeck_Generated folders that no scene, prefab or asset in Assets refers to. Requires saved scenes so
        // that the files on disk match what is open.
        internal static string[] FindUnusedGeneratedFolders()
        {
            var stage = UnityEditor.SceneManagement.PrefabStageUtility.GetCurrentPrefabStage();
            if (Enumerable.Range(0, SceneManager.sceneCount).Any(i => SceneManager.GetSceneAt(i).isDirty) ||
                (stage != null && stage.scene.isDirty))
                throw new InvalidOperationException("저장하지 않은 씬이나 프리팹이 있습니다. 먼저 저장한 뒤 정리해 주세요.");
            var all = AssetDatabase.GetAllAssetPaths().Where(p => p.StartsWith("Assets/", StringComparison.Ordinal)).ToArray();
            var folders = all.Where(p => p.EndsWith("/" + GeneratedMenuName, StringComparison.Ordinal))
                .Select(p => p.Substring(0, p.LastIndexOf('/')))
                .Where(f => f.Substring(f.LastIndexOf('/') + 1).StartsWith(GeneratedFolderPrefix, StringComparison.Ordinal) &&
                    AssetDatabase.LoadMainAssetAtPath(f + "/" + GeneratedBaseName) is AnimatorController)
                .Distinct().ToArray();
            if (folders.Length == 0) return folders;
            bool Inside(string path) => folders.Any(f => path.StartsWith(f + "/", StringComparison.Ordinal));
            var owners = all.Where(p => !Inside(p) && (p.EndsWith(".unity", StringComparison.OrdinalIgnoreCase) ||
                p.EndsWith(".prefab", StringComparison.OrdinalIgnoreCase) || p.EndsWith(".asset", StringComparison.OrdinalIgnoreCase) ||
                p.EndsWith(".controller", StringComparison.OrdinalIgnoreCase) ||
                p.EndsWith(".overrideController", StringComparison.OrdinalIgnoreCase))).ToArray();
            var used = AssetDatabase.GetDependencies(owners, false).Where(Inside).ToArray();
            return folders.Where(f => !used.Any(u => u.StartsWith(f + "/", StringComparison.Ordinal))).ToArray();
        }

        private static AnimatorController CopyController(AnimatorController stock, string path)
        {
            string source = AssetDatabase.GetAssetPath(stock);
            if (!AssetDatabase.CopyAsset(source, path))
            {
                const string prefix = "Packages/";
                var package = UnityEditor.PackageManager.PackageInfo.FindForAssetPath(source);
                if (package == null || !source.StartsWith(prefix + package.name + "/", StringComparison.Ordinal))
                    throw new IOException("Base 컨트롤러를 복제할 수 없습니다: " + source);
                string absoluteSource = Path.Combine(package.resolvedPath, source.Substring(prefix.Length + package.name.Length + 1));
                File.Copy(absoluteSource, path);
                AssetDatabase.ImportAsset(path, ImportAssetOptions.ForceSynchronousImport);
            }
            return AssetDatabase.LoadAssetAtPath<AnimatorController>(path) ??
                throw new IOException("복제한 Base 컨트롤러를 열 수 없습니다.");
        }

        private static Control Submenu(string name, VRCExpressionsMenu menu, Texture2D icon = null) =>
            new Control { name = name, type = Control.ControlType.SubMenu, subMenu = menu, icon = icon };

        private static Control CopyControl(Control source, string title) => new Control
        {
            name = title, type = source.type, icon = source.icon, value = source.value,
            parameter = new Control.Parameter { name = source.parameter?.name ?? "" },
            subParameters = source.subParameters?.Select(p => new Control.Parameter { name = p?.name ?? "" }).ToArray()
        };

        private static VRCExpressionsMenu MenuAsset(string folder, string name, IEnumerable<Control> controls)
        {
            var menu = ScriptableObject.CreateInstance<VRCExpressionsMenu>();
            menu.name = name;
            menu.controls = controls.ToList();
            if (menu.controls.Count > 8) throw new InvalidOperationException("메뉴당 8개 컨트롤을 초과했습니다.");
            AssetDatabase.CreateAsset(menu, $"{folder}/{name}.asset");
            return menu;
        }

        // `header` supplies fresh copies of the controls placed at the top of every page (reset and height, or none).
        private static VRCExpressionsMenu Pages(string folder, string key, List<Control> controls,
            Func<List<Control>> header, int page = 1)
        {
            var top = header();
            int room = VRCExpressionsMenu.MAX_CONTROLS - top.Count;
            if (controls.Count <= room) return MenuAsset(folder, $"{key}_{page}", top.Concat(controls));
            top.AddRange(controls.Take(room - 1));
            top.Add(Submenu("다음 페이지", Pages(folder, key, controls.Skip(room - 1).ToList(), header, page + 1)));
            return MenuAsset(folder, $"{key}_{page}", top);
        }

        private static VRCExpressionsMenu BuildMenu(PoseDeckPreset preset, string folder, VRCExpressionsMenu original,
            Control reset, Control height, Assignment[] rows, IReadOnlyDictionary<AnimationClip, Texture2D> icons)
        {
            List<Control> Controls() => new List<Control> { CopyControl(reset, "초기화"), CopyControl(height, "높이 조절") };
            Func<List<Control>> header = preset.controlsOnEveryPage ? Controls : (Func<List<Control>>)(() => new List<Control>());
            var root = Controls();
            foreach (var group in preset.poses.Select((p, i) => (p, i)).GroupBy(x => x.p.category).OrderBy(g => g.Key))
            {
                var controls = group.Select(x =>
                {
                    var control = rows[x.i].NativeControl != null
                        ? CopyControl(rows[x.i].NativeControl, Title(x.p))
                        : new Control
                        {
                            name = Title(x.p), type = Control.ControlType.Button,
                            parameter = new Control.Parameter { name = Emote }, value = rows[x.i].Number
                        };
                    bool keepNative = rows[x.i].NativeControl != null && preset.keepNativeIcons && control.icon;
                    if (x.p.icon) control.icon = x.p.icon;
                    else if (!keepNative && x.p.clip && icons.TryGetValue(x.p.clip, out var icon)) control.icon = icon;
                    return control;
                }).ToList();
                root.Add(Submenu(CategoryNames[(int)group.Key], Pages(folder, group.Key.ToString(), controls, header)));
            }
            var stockLink = original.controls.FirstOrDefault(c => c?.type == Control.ControlType.SubMenu && c.subMenu);
            if (preset.keepStockMenu && stockLink != null)
                root.Add(Submenu("기존 GoGoLoco", stockLink.subMenu, stockLink.icon));
            var inner = MenuAsset(folder, "PoseDeckMenu", root);
            return MenuAsset(folder, "PoseDeckInstaller", new[] { Submenu(preset.menuTitle.Trim(), inner, stockLink?.icon) });
        }

        internal static void Wire(Target target, AnimatorController controller, VRCExpressionsMenu menu)
        {
            Undo.RecordObjects(new Object[] { target.Base, target.Menu }, "Change Personal Pose Deck");
            target.Base.animator = controller;
            target.Menu.menuToAppend = menu;
            PrefabUtility.RecordPrefabInstancePropertyModifications(target.Base);
            PrefabUtility.RecordPrefabInstancePropertyModifications(target.Menu);
            EditorUtility.SetDirty(target.Base);
            EditorUtility.SetDirty(target.Menu);
            EditorSceneManager.MarkSceneDirty(target.Base.gameObject.scene);
        }

        internal static string GenerateAndApply(PoseDeckPreset preset, GameObject go,
            IReadOnlyDictionary<AnimationClip, Texture2D> icons = null)
        {
            var target = ExistingTarget(go);
            var (stock, original, _, _) = Sources(preset, target);
            string previous = GeneratedFolderOf(target.Menu.menuToAppend);
            var (folder, copy, wrapper) = GenerateAssets(preset, stock, original, icons);
            Undo.IncrementCurrentGroup();
            int group = Undo.GetCurrentGroup();
            Undo.SetCurrentGroupName("Apply Personal Pose Deck");
            try
            {
                var marker = ScriptableObject.CreateInstance<PoseDeckExistingInstallation>();
                marker.preset = preset;
                marker.stockBase = stock;
                marker.stockMenu = original;
                marker.appliedBase = copy;
                marker.appliedMenu = wrapper;
                AssetDatabase.CreateAsset(marker, folder + "/" + ExistingInstallationName);
                Wire(target, copy, wrapper);
                AssetDatabase.SaveAssets();
                Undo.CollapseUndoOperations(group);
                PoseDeckGeneratedCleanup.Remember(previous);
                return folder;
            }
            catch
            {
                Undo.RevertAllDownToGroup(group);
                AssetDatabase.DeleteAsset(folder);
                throw;
            }
        }

        internal static (string folder, AnimatorController controller, VRCExpressionsMenu menu) GenerateAssets(
            PoseDeckPreset preset, AnimatorController stock, VRCExpressionsMenu original,
            IReadOnlyDictionary<AnimationClip, Texture2D> icons = null)
        {
            var controls = Controls(original, new HashSet<VRCExpressionsMenu>()).ToArray();
            var (reset, height) = HeightControls(controls);
            if (reset == null || height == null) throw new InvalidOperationException("GoGoLoco 원본 메뉴에서 초기화 또는 높이 조절을 찾을 수 없습니다." +
                VendorVersionNote(AssetDatabase.GetAssetPath(original)));
            ValidateRows(preset);
            var plan = PlanRows(preset, stock, controls);
            if (plan.Rows.Any(row => row == null))
                throw new InvalidOperationException($"원본 높이를 유지하는 포즈를 제외하면 커스텀 슬롯은 {plan.CustomCapacity}개입니다. 포즈를 줄여 주세요.");
            string presetPath = AssetDatabase.GetAssetPath(preset);
            if (!presetPath.StartsWith("Assets/", StringComparison.Ordinal))
                throw new InvalidOperationException("프리셋을 프로젝트 Assets 폴더에 저장해 주세요.");
            string parent = Path.GetDirectoryName(presetPath).Replace('\\', '/');
            string requested = AssetDatabase.GenerateUniqueAssetPath(parent + "/" + GeneratedFolderPrefix);
            string guid = AssetDatabase.CreateFolder(parent, Path.GetFileName(requested));
            string folder = AssetDatabase.GUIDToAssetPath(guid);
            if (string.IsNullOrEmpty(folder)) throw new IOException("생성 결과 폴더를 만들 수 없습니다.");
            AnimatorController copy;
            VRCExpressionsMenu wrapper;
            try
            {
                copy = CopyController(stock, folder + "/" + GeneratedBaseName);
                var slots = FindSlots(copy).ToDictionary(slot => slot.Number);
                var reference = AdditiveReference(slots.Values.SelectMany(s => s.Clips));
                var poses = new Dictionary<AnimationClip, AnimationClip>();
                // Custom clips go in as copies with GoGoLoco's reference pose, saved next to the generated Base.
                AnimationClip PoseClip(AnimationClip clip)
                {
                    if (!NeedsReference(clip, reference)) return clip;
                    if (poses.TryGetValue(clip, out var made)) return made;
                    if (!AssetDatabase.IsValidFolder(folder + "/Poses")) AssetDatabase.CreateFolder(folder, "Poses");
                    made = WithReference(clip, reference);
                    AssetDatabase.CreateAsset(made, AssetDatabase.GenerateUniqueAssetPath($"{folder}/Poses/{SafeFileName(clip.name)}.anim"));
                    return poses[clip] = made;
                }
                var replaced = new List<BlendTree>();
                for (int i = 0; i < preset.poses.Count; i++)
                {
                    if (plan.Rows[i].NativeControl != null) continue;
                    var slot = slots[plan.Rows[i].Number];
                    var tree = CloneTree(slot.Tree, PoseClip(preset.poses[i].clip), copy, new Dictionary<BlendTree, BlendTree>());
                    foreach (var state in slot.States) { state.motion = tree; EditorUtility.SetDirty(state); }
                    replaced.Add(slot.Tree);
                }
                ApplyStartHeights(copy, slots, preset, plan.Rows);
                RemoveUnusedTrees(copy, replaced);
                EditorUtility.SetDirty(copy);
                wrapper = BuildMenu(preset, folder, original, reset, height, plan.Rows, SaveIcons(folder, preset, icons));
                AssetDatabase.SaveAssets();
            }
            catch
            {
                AssetDatabase.DeleteAsset(folder);
                throw;
            }
            return (folder, copy, wrapper);
        }

        // Takes an array on purpose: it is searched twice, which a lazy Controls() sequence does not survive.
        private static (Control reset, Control height) HeightControls(Control[] controls) =>
            (controls.FirstOrDefault(c => c.type == Control.ControlType.Button && c.parameter?.name == Emote && c.value == 255),
             controls.FirstOrDefault(c => c.type == Control.ControlType.RadialPuppet &&
                 c.parameter?.name == Emote && c.value == 125 && c.subParameters?.FirstOrDefault()?.name == Float));

        internal static bool SupportsSource(AnimatorController controller, VRCExpressionsMenu menu)
        {
            // Materialize first: Controls() shares one visited set, so a second pass over the lazy sequence is empty.
            var (reset, height) = HeightControls(Controls(menu, new HashSet<VRCExpressionsMenu>()).ToArray());
            if (reset == null || height == null) return false;
            try { return FindSlots(controller).Count != 0; }
            catch (InvalidOperationException) { return false; }
        }

        // The preset whose generated result is wired to this GoGoLoco object ("기존 GoGoLoco에 적용"), or null.
        internal static PoseDeckPreset InstalledPreset(GameObject go)
        {
            if (!go) return null;
            try
            {
                var target = GetBindings(go);
                if (PoseDeckAvatarInstall.IsAvatarInstallation(go, target)) return null;
                return Sources(null, target).installedPreset;
            }
            catch (InvalidOperationException) { return null; }
        }

        private static Target ExistingTarget(GameObject go)
        {
            var target = GetTarget(go);
            if (PoseDeckAvatarInstall.IsAvatarInstallation(go, target))
                throw new InvalidOperationException("아바타에 새로 붙인 덱입니다. ‘아바타에 새로 적용’에서 갱신하거나 제거해 주세요.");
            return target;
        }

        internal static void Restore(PoseDeckPreset preset, GameObject go)
        {
            var target = ExistingTarget(go);
            if (!IsGenerated(target.Base.animator as AnimatorController, target.Menu.menuToAppend))
                throw new InvalidOperationException("이 GoGoLoco 오브젝트에 연결된 Pose Deck 생성본이 없습니다.");
            var (stock, original, _, _) = Sources(preset, target);
            Wire(target, stock, original);
        }
    }

    // A generated folder replaced by re-applying a deck. Once the scenes are saved and nothing in the project refers to
    // it any more, it is moved to the trash (recoverable). Restoring and removing leave folders for the manual cleanup.
    [InitializeOnLoad]
    internal static class PoseDeckGeneratedCleanup
    {
        private const string Candidates = "PersonalPoseDeck.ReplacedFolders";
        // EditorPrefs are shared by every project on this PC; the log belongs to this one.
        private static string TrashLog => "PersonalPoseDeck.TrashedFolders." + Application.dataPath;

        // The last folders the cleanup moved to the trash, newest first, as "MM-dd HH:mm  path".
        internal static string[] Trashed => EditorPrefs.GetString(TrashLog, "")
            .Split(new[] { '\n' }, StringSplitOptions.RemoveEmptyEntries);

        // Moves a folder to the trash; tests swap in a permanent delete so runs do not fill the system trash.
        internal static Func<string, bool> Trash = AssetDatabase.MoveAssetToTrash;
        private const string Preference = "PersonalPoseDeck.AutoCleanReplaced";

        static PoseDeckGeneratedCleanup() =>
            EditorSceneManager.sceneSaved += _ => { if (Pending.Count != 0) EditorApplication.delayCall += () => Clean(); };

        internal static bool Enabled
        {
            get => EditorPrefs.GetBool(Preference, true);
            set => EditorPrefs.SetBool(Preference, value);
        }

        private static List<string> Pending => SessionState.GetString(Candidates, "")
            .Split(new[] { '\n' }, StringSplitOptions.RemoveEmptyEntries).ToList();

        internal static void Remember(string folder)
        {
            if (!Enabled || string.IsNullOrEmpty(folder)) return;
            var list = Pending;
            if (!list.Contains(folder)) list.Add(folder);
            SessionState.SetString(Candidates, string.Join("\n", list));
        }

        // Returns the folders moved to the trash.
        internal static string[] Clean()
        {
            var list = Pending.Where(AssetDatabase.IsValidFolder).ToList();
            if (list.Count == 0 || !Enabled)
            {
                SessionState.EraseString(Candidates);
                return Array.Empty<string>();
            }
            string[] unused;
            try { unused = PoseDeckBuilder.FindUnusedGeneratedFolders(); }
            catch (InvalidOperationException) { return Array.Empty<string>(); } // unsaved scenes: wait for the next save
            var moved = list.Where(unused.Contains).Where(f => Trash(f)).ToArray();
            foreach (var folder in moved)
                Debug.Log("[Personal Pose Deck] 다시 적용해 쓰지 않게 된 생성본을 휴지통으로 옮겼습니다: " + folder);
            if (moved.Length != 0)
            {
                string stamp = DateTime.Now.ToString("MM-dd HH:mm");
                var log = moved.Select(f => stamp + "  " + f).Concat(Trashed).Take(5);
                EditorPrefs.SetString(TrashLog, string.Join("\n", log));
            }
            // Folders something still refers to (a prefab, another scene) are left alone and no longer tracked.
            SessionState.EraseString(Candidates);
            return moved;
        }
    }
}
