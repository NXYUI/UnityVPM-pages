using System;
using System.Collections.Generic;
using System.Linq;
using nadena.dev.modular_avatar.core;
using UnityEditor;
using UnityEngine;
using VRC.SDK3.Avatars.Components;
using static NXYUI.AssetManager.AssetGui;
using Object = UnityEngine.Object;

namespace NXYUI.AssetManager
{
    // The Booth link of one asset: the linked product, or candidates to choose. In the window it also has the search
    // box and the address field; in the Inspector (compact) it shows three candidates and a way to the window.
    [Serializable]
    internal sealed class BoothForm
    {
        [SerializeField] private string query = "", address = "";
        [NonSerialized] private string queryFor;
        [NonSerialized] private string message;
        [NonSerialized] private MessageType messageType;

        internal void Draw(AssetRecord asset, bool compact, Action repaint)
        {
            if (asset.boothId > 0)
            {
                DrawLinked(asset, compact, repaint);
                return;
            }
            if (asset.noBooth)
            {
                using (new EditorGUILayout.HorizontalScope())
                {
                    GUILayout.Label("Booth에서 산 것이 아니라고 표시했어요.", EditorStyles.wordWrappedMiniLabel);
                    if (GUILayout.Button(new GUIContent("다시 찾기", "표시를 풀고 Booth 후보를 다시 찾아요."), EditorStyles.miniButton, GUILayout.Width(64)))
                        // What it draws changes: the next pass, not this one.
                        Later(() =>
                        {
                            asset.noBooth = false;
                            AssetStore.SaveProject();
                        }, repaint);
                }
                return;
            }
            var cache = AssetStore.SearchFor(asset.id);
            var searching = BoothLinker.NeedsSearch(cache) || BoothLinker.IsSearching(asset.id);
            // Started after this GUI pass, so Layout and Repaint draw the same candidates.
            if (BoothLinker.NeedsSearch(cache) && !BoothLinker.IsSearching(asset.id))
                BoothLinker.SearchSoon(asset.id, asset.name, AssetFolders.ExistingFolders(asset), asset.package);
            if (queryFor != asset.id)
            {
                queryFor = asset.id;
                query = cache?.query ?? BoothClient.QueryFrom(asset.name);
                address = "";
                message = null;
            }
            GUILayout.Label(compact
                ? "Booth 상품과 아직 연결하지 않았어요. 맞는 후보의 ‘연결’을 누르세요."
                : "아직 Booth 상품과 연결하지 않았어요. 아래 후보에서 맞는 상품을 고르거나, 직접 검색하거나, 상품 주소를 넣으세요.",
                EditorStyles.wordWrappedMiniLabel);
            if (searching) EditorGUILayout.HelpBox("Booth에서 찾고 있어요…", MessageType.None);
            else if (cache.error.Length > 0) EditorGUILayout.HelpBox("검색하지 못했어요: " + cache.error, MessageType.Warning);
            else if (cache.results.Count == 0)
                EditorGUILayout.HelpBox($"‘{cache.query}’(으)로 찾은 상품이 없어요. " +
                                        (compact ? "‘더 찾기…’에서 검색어를 바꾸거나 주소를 넣으세요." : "검색어를 바꾸거나 주소를 넣으세요."), MessageType.None);
            var limit = compact ? 3 : 8;
            if (cache != null)
                foreach (var candidate in cache.results.Take(limit).ToList())
                    if (DrawCandidate(asset, cache, candidate, compact, repaint)) return;
            var more = cache?.results.Count - limit ?? 0;
            if (compact)
            {
                using (new EditorGUILayout.HorizontalScope())
                {
                    if (more > 0) GUILayout.Label($"후보 {more}개 더", EditorStyles.miniLabel);
                    GUILayout.FlexibleSpace();
                    if (GUILayout.Button(new GUIContent("더 찾기…", "Asset Manager 창에서 직접 검색하거나 상품 주소로 연결해요."), EditorStyles.miniButton))
                        AssetManagerWindow.ShowAsset(asset);
                }
                return;
            }
            if (more > 0) GUILayout.Label($"후보 {more}개가 더 있어요. 검색어를 좁혀 보세요.", EditorStyles.miniLabel);
            DrawSearch(asset, repaint);
        }

        private void DrawLinked(AssetRecord asset, bool compact, Action repaint)
        {
            var item = AssetStore.Item(asset.boothId);
            var name = item?.name.Length > 0 ? item.name : asset.boothName.Length > 0 ? asset.boothName : $"상품 {asset.boothId}";
            using (new EditorGUILayout.HorizontalScope(EditorStyles.helpBox))
            {
                if (!compact) DrawThumbnail(item != null ? AssetStore.Thumbnail(item.thumbnail, repaint) : null, 56, "Booth");
                using (new EditorGUILayout.VerticalScope())
                {
                    if (compact) ClippedLabel("Booth: " + name, EditorStyles.label);
                    else GUILayout.Label(name, WrappedLabel);
                    if (item != null && item.shop.Length > 0) ClippedLabel(item.shop, EditorStyles.miniLabel);
                    if (item == null || item.name.Length == 0) GUILayout.Label("Booth에서 상품 정보를 받지 못해 번호로만 연결했어요.", EditorStyles.wordWrappedMiniLabel);
                    using (new EditorGUILayout.HorizontalScope())
                    {
                        if (GUILayout.Button("Booth 페이지", EditorStyles.miniButton)) Application.OpenURL(BoothUrl(asset.boothId));
                        if (GUILayout.Button(new GUIContent("다른 상품으로 바꾸기", "연결을 풀고 후보를 다시 보여 줘요."), EditorStyles.miniButton))
                        {
                            BoothLinker.Unlink(asset);
                            repaint?.Invoke();
                            return;
                        }
                        GUILayout.FlexibleSpace();
                    }
                }
            }
        }

        // One candidate row; true when it was linked (the rest of the pass is skipped).
        private bool DrawCandidate(AssetRecord asset, SearchCache cache, BoothItem candidate, bool compact, Action repaint)
        {
            using (new EditorGUILayout.HorizontalScope(EditorStyles.helpBox))
            {
                DrawThumbnail(AssetStore.Thumbnail(candidate.thumbnail, repaint), compact ? 32 : 48, "Booth");
                using (new EditorGUILayout.VerticalScope())
                {
                    if (compact) ClippedLabel(candidate.name, EditorStyles.label);
                    else GUILayout.Label(candidate.name, WrappedLabel);
                    using (new EditorGUILayout.HorizontalScope())
                    {
                        if (candidate.id == cache.recommended) DrawBadge("추천", "good", "가장 맞아 보이는 후보예요. 연결은 직접 눌러야 해요.");
                        if (candidate.id == cache.readmeItem) DrawBadge("설명서 링크", "good", "에셋 폴더의 설명서에 적힌 Booth 상품");
                        else if (AssetStore.HintFor(asset.package) == candidate.id || AssetStore.HintFor(asset.name) == candidate.id)
                            DrawBadge("이전 연결", "good", "다른 프로젝트에서 같은 이름으로 연결한 상품");
                        else if (cache.shopItems.Contains(candidate.id)) DrawBadge("같은 샵", "accent", "에셋 폴더로 짐작한 샵의 상품");
                        ClippedLabel(candidate.shop, EditorStyles.miniLabel);
                    }
                }
                using (new EditorGUILayout.VerticalScope(GUILayout.Width(compact ? 44 : 64)))
                {
                    if (GUILayout.Button(new GUIContent("연결", $"‘{candidate.name}’에 연결해요.")))
                    {
                        BoothLinker.Link(asset, candidate);
                        message = null;
                        repaint?.Invoke();
                        return true;
                    }
                    if (GUILayout.Button(new GUIContent("보기", "브라우저에서 상품 페이지를 열어 확인해요."), EditorStyles.miniButton))
                        Application.OpenURL(candidate.Url);
                }
            }
            return false;
        }

        private void DrawSearch(AssetRecord asset, Action repaint)
        {
            using (new EditorGUILayout.HorizontalScope())
            {
                query = EditorGUILayout.TextField("직접 검색", query);
                var searching = BoothLinker.IsSearching(asset.id);
                using (new EditorGUI.DisabledScope(string.IsNullOrWhiteSpace(query)))
                    if (GUILayout.Button(new GUIContent("검색", string.IsNullOrWhiteSpace(query) ? "검색어를 넣으세요." : searching ? "지금 찾는 것을 멈추고 이 검색어로 찾아요." : ""), GUILayout.Width(56)))
                    {
                        BoothLinker.Search(asset.id, query.Trim(), AssetFolders.ExistingFolders(asset), new[] { asset.package, asset.name }, false);
                        repaint?.Invoke();
                        return;
                    }
            }
            using (new EditorGUILayout.HorizontalScope())
            {
                address = EditorGUILayout.TextField(new GUIContent("상품·샵 주소", "booth.pm 상품 주소나 상품 번호, 또는 샵 주소(샵이름.booth.pm)"), address);
                var id = BoothClient.ParseItemId(address);
                var shop = id <= 0 ? BoothClient.ShopFromUrl(address) : null;
                using (new EditorGUI.DisabledScope(id <= 0 && shop == null))
                    if (shop != null && GUILayout.Button(new GUIContent("찾기", $"‘{shop}’ 샵의 상품을 후보로 보여 줘요."), GUILayout.Width(56)))
                    {
                        message = null;
                        BoothLinker.SearchShop(asset, shop);
                        repaint?.Invoke();
                        return;
                    }
                    else if (shop == null && GUILayout.Button(new GUIContent("연결", id <= 0 ? "Booth 상품 주소나 번호, 또는 샵 주소를 넣으세요." : $"상품 {id}에 연결해요."), GUILayout.Width(56)))
                    {
                        message = "상품 정보를 받고 있어요…";
                        messageType = MessageType.None;
                        BoothLinker.LinkById(asset, id, error =>
                        {
                            message = error;
                            messageType = MessageType.Warning;
                            repaint?.Invoke();
                        });
                        repaint?.Invoke();
                        return;
                    }
            }
            if (!string.IsNullOrEmpty(message)) EditorGUILayout.HelpBox(message, messageType);
        }
    }

    // The 조립 form: avatar, where the asset goes (its submenu), prefab, 옷 입히기 or 뼈에 붙이기, then one button. The
    // window lets the user pick the asset's prefab; the Inspector panel is for the selected prefab (fixed).
    [Serializable]
    internal sealed class AssemblyForm
    {
        [SerializeField] private VRCAvatarDescriptor avatar;
        [SerializeField] private Transform parent;
        [SerializeField] private string newParentName = "";
        [SerializeField] private GameObject prefab;
        [SerializeField] private AssemblyMode mode;
        [SerializeField] private Transform bone;
        [SerializeField] private BoneProxyAttachmentMode attach = BoneProxyAttachmentMode.AsChildAtRoot;
        [SerializeField] private string toggleName = "";
        [SerializeField] private string forAsset;
        // The avatar remembered for this prefab is gone: say so instead of quietly taking another one.
        [NonSerialized] private string lostAvatar;
        [NonSerialized] private string message;
        [NonSerialized] private MessageType messageType;
        [NonSerialized] private GameObject result;
        [NonSerialized] private bool hasResult;

        private static readonly (BoneProxyAttachmentMode Mode, string Label)[] AttachModes =
        {
            (BoneProxyAttachmentMode.AsChildAtRoot, "뼈 위치로 옮기기"),
            (BoneProxyAttachmentMode.AsChildKeepWorldPose, "지금 위치·회전 유지"),
            (BoneProxyAttachmentMode.AsChildKeepRotation, "회전만 유지"),
            (BoneProxyAttachmentMode.AsChildKeepPosition, "위치만 유지"),
        };

        // ---- Caches: the scene and the project are read once per change, not on every repaint. ----

        private static VRCAvatarDescriptor[] avatarCache;
        private static int avatarVersion = -1;

        internal static VRCAvatarDescriptor[] Avatars()
        {
            if (avatarCache == null || avatarVersion != HierarchyVersion || avatarCache.Any(a => !a))
            {
                avatarCache = Object.FindObjectsByType<VRCAvatarDescriptor>(FindObjectsInactive.Include, FindObjectsSortMode.None)
                    .Where(a => a.gameObject.scene.IsValid() && !EditorUtility.IsPersistent(a))
                    .OrderBy(a => a.gameObject.scene.name).ThenBy(a => a.name).ToArray();
                avatarVersion = HierarchyVersion;
            }
            return avatarCache;
        }

        private List<GameObject> prefabList;
        private string prefabListFor;
        private int prefabListVersion = -1;

        private List<GameObject> PrefabsOf(AssetRecord asset)
        {
            if (prefabList == null || prefabListFor != asset.id || prefabListVersion != ProjectVersion || prefabList.Any(p => !p))
            {
                prefabList = AssetFolders.Prefabs(asset);
                prefabListFor = asset.id;
                prefabListVersion = ProjectVersion;
            }
            return prefabList;
        }

        private List<Transform> placeList;
        private Transform placeListFor;
        private int placeListVersion = -1;

        private List<Transform> PlacesOf(Transform root)
        {
            if (placeList == null || placeListFor != root || placeListVersion != HierarchyVersion)
            {
                placeList = Places(root);
                placeListFor = root;
                placeListVersion = HierarchyVersion;
            }
            return placeList;
        }

        private List<BoneTarget> boneList;
        private string boneListKey;

        private List<BoneTarget> BonesOf(AssetRecord asset, Transform root)
        {
            var key = $"{root.GetInstanceID()}|{(prefab ? prefab.GetInstanceID() : 0)}|{HierarchyVersion}";
            if (boneList == null || boneListKey != key)
            {
                boneList = BoneTargets.For(root, asset.name + " " + (prefab ? prefab.name : ""), AssetStore.RecentBonesFor(AvatarKey(avatar)));
                boneListKey = key;
            }
            return boneList;
        }

        private string planKey;
        private bool planToggle;
        private string planMenu;
        private List<string> planProblems, planWarnings;

        // What the plan would do and what stops it, worked out again only when a choice or the scene changes.
        private void Review(AssemblyPlan plan)
        {
            var key = $"{(plan.Avatar ? plan.Avatar.GetInstanceID() : 0)}|{(plan.Parent ? plan.Parent.GetInstanceID() : 0)}|{plan.NewParentName}|" +
                      $"{(plan.Prefab ? plan.Prefab.GetInstanceID() : 0)}|{plan.Mode}|{(plan.BoneTarget ? plan.BoneTarget.GetInstanceID() : 0)}|" +
                      $"{plan.Attach}|{plan.ToggleName}|{HierarchyVersion}|{ProjectVersion}";
            if (key == planKey) return;
            planKey = key;
            planToggle = AssetAssembler.WillMakeToggle(plan.Prefab);
            planMenu = AssetAssembler.DescribeMenu(plan);
            planProblems = AssetAssembler.Problems(plan);
            planWarnings = AssetAssembler.Warnings(plan);
        }

        // ---- Drawing ----

        internal void Draw(AssetRecord asset, GameObject fixedPrefab, bool compact, Action repaint, Action changed = null)
        {
            if (forAsset != asset.id || fixedPrefab && prefab != fixedPrefab) Reset(asset, fixedPrefab);
            if (hasResult && !result)
            {
                // Undone: the result and its message go with it.
                hasResult = false;
                message = null;
            }
            var avatars = Avatars();
            if (avatars.Length == 0)
            {
                EditorGUILayout.HelpBox("씬에 아바타(VRC Avatar Descriptor)가 없어요. 아바타를 씬에 놓으면 여기서 바로 조립할 수 있어요.", MessageType.Info);
                return;
            }
            if (EditorApplication.isPlayingOrWillChangePlaymode)
            {
                EditorGUILayout.HelpBox("플레이 모드에서는 조립할 수 없어요. 편집 모드로 돌아오면 할 수 있어요.", MessageType.Info);
                return;
            }
            if (avatar && !avatars.Contains(avatar)) avatar = null;
            if (!avatar && lostAvatar == null) avatar = avatars[0];

            var labelWidth = EditorGUIUtility.labelWidth;
            EditorGUIUtility.labelWidth = compact ? 72 : labelWidth;
            try { DrawChoices(asset, fixedPrefab, compact, avatars, repaint, changed); }
            finally { EditorGUIUtility.labelWidth = labelWidth; }
        }

        private void DrawChoices(AssetRecord asset, GameObject fixedPrefab, bool compact, VRCAvatarDescriptor[] avatars, Action repaint, Action changed)
        {
            void Change(Action apply) => Later(() =>
            {
                apply();
                changed?.Invoke();
            }, repaint);

            // Avatar
            var names = avatars.Select(a => avatars.Count(b => b.name == a.name) > 1 ? $"{a.name} ({a.gameObject.scene.name})" : a.name).ToList();
            var index = avatar ? Array.IndexOf(avatars, avatar) : -1;
            var options = index < 0 ? new[] { "아바타를 고르세요" }.Concat(names).ToArray() : names.ToArray();
            var shown = Math.Max(index, 0);
            var picked = EditorGUILayout.Popup(new GUIContent("아바타", "에셋을 넣을 아바타예요. 열린 씬의 아바타만 보여요."), shown, options);
            if (picked != shown && !(index < 0 && picked == 0))
            {
                var chosen = avatars[index < 0 ? picked - 1 : picked];
                Change(() =>
                {
                    avatar = chosen;
                    parent = null;
                    bone = null;
                    lostAvatar = null;
                    message = null;
                });
            }
            if (lostAvatar != null) GUILayout.Label(lostAvatar, EditorStyles.wordWrappedMiniLabel);
            if (!avatar) return;
            var root = avatar.transform;

            // Where it goes: an existing object (its submenu) or a new one under the avatar root.
            var places = PlacesOf(root);
            var placeNames = new[] { "새로 만들기…" }.Concat(places.Select(p => Breadcrumb(root, p))).ToList();
            var placeIndex = parent ? places.IndexOf(parent) + 1 : 0;
            var shownPlaces = places;
            if (parent && placeIndex == 0)
            {
                // Dragged in from the Hierarchy: shown as its own entry.
                shownPlaces = places.Concat(new[] { parent }).ToList();
                placeNames.Add(Breadcrumb(root, parent));
                placeIndex = placeNames.Count - 1;
            }
            var placeTip = new GUIContent("넣을 위치", "에셋이 들어갈 오브젝트예요. 이 오브젝트가 에셋 메뉴를 담는 하위 메뉴가 돼요.");
            int chosenPlace;
            Transform dropped;
            if (compact)
            {
                chosenPlace = EditorGUILayout.Popup(placeTip, placeIndex, placeNames.ToArray());
                dropped = (Transform)EditorGUILayout.ObjectField(new GUIContent("직접 지정", "Hierarchy에서 끌어다 놓아도 돼요."), parent, typeof(Transform), true);
            }
            else
                using (new EditorGUILayout.HorizontalScope())
                {
                    chosenPlace = EditorGUILayout.Popup(placeTip, placeIndex, placeNames.ToArray());
                    dropped = (Transform)EditorGUILayout.ObjectField(parent, typeof(Transform), true, GUILayout.Width(110));
                }
            if (chosenPlace != placeIndex || dropped != parent)
            {
                var next = dropped != parent ? dropped : chosenPlace == 0 ? null : shownPlaces[chosenPlace - 1];
                Change(() => parent = next);
            }
            if (!parent)
            {
                if (string.IsNullOrWhiteSpace(newParentName)) newParentName = asset.kind == AssetKind.Outfit ? "의상" : "액세서리";
                newParentName = EditorGUILayout.TextField(new GUIContent("새 이름", "아바타 루트 바로 아래에 이 이름으로 만들어요."), newParentName);
            }

            // Prefab
            if (!fixedPrefab)
            {
                var prefabs = PrefabsOf(asset);
                if (prefabs.Count == 0)
                {
                    EditorGUILayout.HelpBox("이 에셋 폴더에 프리팹이 없어요. 프리팹이 든 폴더를 ‘폴더’에 넣으세요.", MessageType.Warning);
                    return;
                }
                var ordered = OrderForAvatar(prefabs, avatar);
                if (!prefab || !ordered.Contains(prefab)) prefab = ordered[0];
                var prefabIndex = ordered.IndexOf(prefab);
                using (new EditorGUILayout.HorizontalScope())
                {
                    var chosenPrefab = EditorGUILayout.Popup(new GUIContent("프리팹", "고른 아바타의 이름이 든 프리팹을 먼저 보여 줘요."), prefabIndex,
                        ordered.Select(p => PrefabLabel(asset, p)).ToArray());
                    if (chosenPrefab != prefabIndex)
                    {
                        var next = ordered[chosenPrefab];
                        Change(() =>
                        {
                            prefab = next;
                            mode = Recommended(next);
                            attach = RecommendedAttach(next, avatar);
                        });
                    }
                    if (GUILayout.Button("보기", EditorStyles.miniButton, GUILayout.Width(40))) EditorGUIUtility.PingObject(prefab);
                }
            }

            // Mode: the plain words first, Modular Avatar's names in the tooltip and the line under it.
            var recommended = Recommended(prefab);
            var modes = new[]
            {
                new GUIContent("옷 입히기" + (recommended == AssemblyMode.Outfit ? " (추천)" : ""), "의상의 뼈를 아바타의 뼈에 합쳐요 (MA Setup Outfit)."),
                new GUIContent("뼈에 붙이기" + (recommended == AssemblyMode.BoneProxy ? " (추천)" : ""), "뼈 하나에 붙여 따라 움직이게 해요 (MA Bone Proxy)."),
            };
            var newMode = (AssemblyMode)GUILayout.Toolbar((int)mode, modes);
            if (newMode != mode) Change(() => mode = newMode);
            GUILayout.Label(mode == AssemblyMode.Outfit
                ? "의상의 뼈를 아바타의 뼈에 합쳐요(MA Setup Outfit)."
                : "에셋을 아바타의 뼈 하나에 붙여 따라 움직이게 해요(MA Bone Proxy).", EditorStyles.wordWrappedMiniLabel);
            if (mode == AssemblyMode.BoneProxy) DrawBone(asset, root, compact, Change);

            // Menu
            var plan = Plan();
            Review(plan);
            if (planToggle)
            {
                if (string.IsNullOrWhiteSpace(toggleName)) toggleName = asset.name;
                toggleName = EditorGUILayout.TextField(new GUIContent("토글 이름", "메뉴에 보일 이름이에요."), toggleName);
            }
            GUILayout.Label("메뉴: " + planMenu, EditorStyles.wordWrappedMiniLabel);
            foreach (var warning in planWarnings) EditorGUILayout.HelpBox(warning, MessageType.Warning);
            using (new EditorGUI.DisabledScope(planProblems.Count > 0))
            {
                var tooltip = planProblems.Count > 0 ? planProblems[0] : "한 번 누르면 조립돼요. Ctrl+Z로 한 번에 되돌릴 수 있어요.";
                // The one main button, in the window's accent.
                var previous = GUI.backgroundColor;
                if (planProblems.Count == 0) GUI.backgroundColor = Accent;
                var pressed = GUILayout.Button(new GUIContent("조립", tooltip), GUILayout.Height(26));
                GUI.backgroundColor = previous;
                if (pressed)
                {
                    Assemble(plan, repaint, changed);
                    return;
                }
            }
            if (planProblems.Count > 0) GUILayout.Label("조립할 수 없어요: " + planProblems[0], EditorStyles.wordWrappedMiniLabel);
            if (!string.IsNullOrEmpty(message))
            {
                EditorGUILayout.HelpBox(message, messageType);
                if (result && GUILayout.Button(new GUIContent("씬에서 보기", "조립한 오브젝트를 Hierarchy에서 골라요."), EditorStyles.miniButton))
                {
                    Selection.activeGameObject = result;
                    EditorGUIUtility.PingObject(result);
                }
            }
        }

        private void DrawBone(AssetRecord asset, Transform root, bool compact, Action<Action> change)
        {
            var targets = BonesOf(asset, root);
            var labels = targets.Select(t => $"{t.Group}/{t.Label}").ToArray();
            var index = targets.FindIndex(t => t.Bone == bone);
            if (!bone && targets.Count > 0 && targets[0].Group == BoneTargets.Suggested)
            {
                bone = targets[0].Bone;
                index = 0;
            }
            var shownLabels = index < 0 && bone ? labels.Concat(new[] { "직접 고름/" + bone.name }).ToArray() : labels;
            var shownIndex = index >= 0 ? index : bone ? shownLabels.Length - 1 : -1;
            var tip = new GUIContent("붙일 뼈", "에셋 이름으로 추천한 뼈, 자주 쓰는 뼈, 아바타 고유 뼈, 최근 쓴 뼈 순이에요.");
            int chosen;
            Transform dropped;
            if (compact)
            {
                chosen = EditorGUILayout.Popup(tip, shownIndex, shownLabels);
                dropped = (Transform)EditorGUILayout.ObjectField(new GUIContent("직접 지정", "Hierarchy에서 뼈를 끌어다 놓아도 돼요."), bone, typeof(Transform), true);
            }
            else
                using (new EditorGUILayout.HorizontalScope())
                {
                    chosen = EditorGUILayout.Popup(tip, shownIndex, shownLabels);
                    dropped = (Transform)EditorGUILayout.ObjectField(bone, typeof(Transform), true, GUILayout.Width(110));
                }
            if (chosen != shownIndex && chosen >= 0 && chosen < targets.Count)
            {
                var next = targets[chosen].Bone;
                change(() => bone = next);
            }
            else if (dropped != bone) change(() => bone = dropped);
            var recommended = RecommendedAttach(prefab, avatar);
            var attachLabels = AttachModes.Select(m => m.Mode == recommended ? m.Label + " (추천)" : m.Label).ToArray();
            var attachIndex = Math.Max(0, Array.FindIndex(AttachModes, m => m.Mode == attach));
            var newAttach = EditorGUILayout.Popup(new GUIContent("붙이는 방식", "아바타용으로 만든 프리팹은 지금 위치를 유지하고, 범용 액세서리는 뼈 위치로 옮기는 게 보통이에요."),
                attachIndex, attachLabels);
            if (newAttach != attachIndex) change(() => attach = AttachModes[newAttach].Mode);
        }

        private AssemblyPlan Plan() => new AssemblyPlan
        {
            Avatar = avatar,
            Parent = parent,
            NewParentName = newParentName ?? "",
            Prefab = prefab,
            Mode = mode,
            BoneTarget = bone,
            Attach = attach,
            ToggleName = toggleName ?? "",
        };

        private void Assemble(AssemblyPlan plan, Action repaint, Action changed)
        {
            try
            {
                var done = AssetAssembler.Assemble(plan);
                var place = done.Instance.transform.parent ? done.Instance.transform.parent.name : plan.Avatar.name;
                var lines = new List<string>
                {
                    $"‘{done.Instance.name}’을(를) {plan.Avatar.name}({plan.Avatar.gameObject.scene.name} 씬)의 ‘{place}’에 조립했어요. Ctrl+Z로 한 번에 되돌릴 수 있어요.",
                };
                lines.AddRange(done.Notes);
                message = string.Join("\n", lines);
                messageType = MessageType.Info;
                result = done.Instance;
                hasResult = true;
                if (plan.Mode == AssemblyMode.BoneProxy && plan.BoneTarget)
                    AssetStore.RememberBone(AvatarKey(plan.Avatar), RelativePath(plan.Avatar.transform, plan.BoneTarget));
                if (!plan.Parent)
                {
                    // The new parent exists now: later assemblies go into the same submenu.
                    parent = done.Instance.transform.parent;
                    while (parent && parent.parent != plan.Avatar.transform && !parent.GetComponent<ModularAvatarMenuItem>()) parent = parent.parent;
                }
                // The selection stays where the user works (the prefab); the Hierarchy only flashes the new object.
                EditorGUIUtility.PingObject(done.Instance);
            }
            catch (Exception e) when (!(e is ExitGUIException))
            {
                // The assembly was already undone; anything unexpected (from Modular Avatar too) also lands in the Console.
                if (!(e is InvalidOperationException)) Debug.LogException(e);
                message = "조립하지 못했어요: " + e.Message;
                messageType = MessageType.Error;
                result = null;
                hasResult = false;
            }
            changed?.Invoke();
            repaint?.Invoke();
        }

        private void Reset(AssetRecord asset, GameObject fixedPrefab)
        {
            forAsset = asset.id;
            prefab = fixedPrefab;
            if (!prefab)
            {
                var prefabs = PrefabsOf(asset);
                prefab = prefabs.Count > 0 ? OrderForAvatar(prefabs, avatar)[0] : null;
            }
            bone = null;
            toggleName = "";
            newParentName = "";
            message = null;
            result = null;
            hasResult = false;
            mode = Recommended(prefab);
            attach = RecommendedAttach(prefab, avatar);
        }

        // ---- Remembered per prefab for the session (the Inspector panel) ----

        [Serializable]
        private sealed class Saved
        {
            public string avatar = "", parent = "", bone = "", newParentName = "", toggleName = "";
            public int mode, attach;
        }

        private static string Key(string prefabGuid) => "NXYUI.AssetManager.Assembly." + prefabGuid;

        internal void Save(string prefabGuid)
        {
            string Id(Object o) => o ? GlobalObjectId.GetGlobalObjectIdSlow(o).ToString() : "";
            SessionState.SetString(Key(prefabGuid), JsonUtility.ToJson(new Saved
            {
                avatar = Id(avatar), parent = Id(parent), bone = Id(bone), newParentName = newParentName ?? "", toggleName = toggleName ?? "",
                mode = (int)mode, attach = (int)attach,
            }));
        }

        internal static AssemblyForm Load(string prefabGuid, AssetRecord asset, GameObject prefab)
        {
            var form = new AssemblyForm();
            form.Reset(asset, prefab);
            var json = SessionState.GetString(Key(prefabGuid), "");
            if (json.Length == 0) return form;
            var saved = JsonUtility.FromJson<Saved>(json);
            T Find<T>(string id) where T : Object =>
                GlobalObjectId.TryParse(id, out var gid) ? GlobalObjectId.GlobalObjectIdentifierToObjectSlow(gid) as T : null;
            form.avatar = Find<VRCAvatarDescriptor>(saved.avatar);
            if (!form.avatar && saved.avatar.Length > 0) form.lostAvatar = "전에 고른 아바타를 열린 씬에서 찾지 못했어요. 다시 골라 주세요.";
            form.parent = form.avatar ? Find<Transform>(saved.parent) : null;
            form.bone = form.avatar ? Find<Transform>(saved.bone) : null;
            if (form.parent && !form.parent.IsChildOf(form.avatar.transform)) form.parent = null;
            if (form.bone && !form.bone.IsChildOf(form.avatar.transform)) form.bone = null;
            form.newParentName = saved.newParentName;
            form.toggleName = saved.toggleName;
            form.mode = (AssemblyMode)saved.mode;
            form.attach = (BoneProxyAttachmentMode)saved.attach;
            return form;
        }

        // ---- Helpers ----

        private static readonly Dictionary<GameObject, AssemblyMode> RecommendedModes = new Dictionary<GameObject, AssemblyMode>();

        private static AssemblyMode Recommended(GameObject prefab)
        {
            if (!prefab) return AssemblyMode.BoneProxy;
            if (!RecommendedModes.TryGetValue(prefab, out var mode))
                RecommendedModes[prefab] = mode = AssetFolders.HasArmature(prefab) ? AssemblyMode.Outfit : AssemblyMode.BoneProxy;
            return mode;
        }

        // Prefabs named for the chosen avatar first, then the ones nearest the asset's top folder.
        internal static List<GameObject> OrderForAvatar(List<GameObject> prefabs, VRCAvatarDescriptor avatar)
        {
            var words = AvatarWords(avatar);
            return prefabs.OrderByDescending(p => words.Any(w => AssetDatabase.GetAssetPath(p).IndexOf(w, StringComparison.OrdinalIgnoreCase) >= 0))
                .ThenBy(p => AssetDatabase.GetAssetPath(p).Count(c => c == '/'))
                .ThenBy(p => p.name, StringComparer.OrdinalIgnoreCase).ToList();
        }

        private static List<string> AvatarWords(VRCAvatarDescriptor avatar)
        {
            if (!avatar) return new List<string>();
            var names = new List<string> { avatar.name };
            var source = PrefabUtility.GetCorrespondingObjectFromOriginalSource(avatar.gameObject);
            if (source) names.Add(source.name);
            return names.SelectMany(n => n.Split(new[] { ' ', '_', '-', '(', ')', '.' }, StringSplitOptions.RemoveEmptyEntries))
                .Where(w => w.Length >= 3 && !w.Equals("variant", StringComparison.OrdinalIgnoreCase) && !w.All(char.IsDigit))
                .Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        }

        private static BoneProxyAttachmentMode RecommendedAttach(GameObject prefab, VRCAvatarDescriptor avatar)
        {
            if (!prefab) return BoneProxyAttachmentMode.AsChildAtRoot;
            var words = AvatarWords(avatar);
            var path = AssetDatabase.GetAssetPath(prefab);
            return words.Any(w => path.IndexOf(w, StringComparison.OrdinalIgnoreCase) >= 0)
                ? BoneProxyAttachmentMode.AsChildKeepWorldPose
                : BoneProxyAttachmentMode.AsChildAtRoot;
        }

        internal static string PrefabLabel(AssetRecord asset, GameObject prefab)
        {
            var path = AssetDatabase.GetAssetPath(prefab);
            foreach (var folder in AssetFolders.ExistingFolders(asset))
                if (path.StartsWith(folder + "/", StringComparison.Ordinal))
                    return path.Substring(folder.Length + 1).Replace("/", " › ");
            return prefab.name;
        }

        // Objects that can hold an asset: the avatar root's children that are not its body or armature, and every
        // object already made into a children-source submenu.
        private static List<Transform> Places(Transform root)
        {
            var hips = AssetFolders.FindHips(root);
            var armature = hips ? hips.parent : null;
            var list = new List<Transform>();
            foreach (Transform child in root)
            {
                if (child == armature || child.GetComponent<SkinnedMeshRenderer>() && !child.GetComponent<ModularAvatarMenuItem>()) continue;
                list.Add(child);
            }
            foreach (var item in root.GetComponentsInChildren<ModularAvatarMenuItem>(true))
                if (item.transform != root && item.MenuSource == SubmenuSource.Children && item.Control != null &&
                    item.Control.type == VRC.SDK3.Avatars.ScriptableObjects.VRCExpressionsMenu.Control.ControlType.SubMenu && !list.Contains(item.transform))
                    list.Add(item.transform);
            return list;
        }

        private static string Breadcrumb(Transform root, Transform t)
        {
            var parts = new List<string>();
            for (var p = t; p && p != root; p = p.parent) parts.Insert(0, p.name);
            var text = string.Join(" › ", parts);
            if (t.GetComponent<ModularAvatarMenuItem>()) text += "  (하위 메뉴)";
            return text.Replace("/", "／");
        }

        private static string RelativePath(Transform root, Transform t)
        {
            var parts = new List<string>();
            for (var p = t; p && p != root; p = p.parent) parts.Insert(0, p.name);
            return string.Join("/", parts);
        }

        private static string AvatarKey(VRCAvatarDescriptor avatar)
        {
            if (!avatar) return "";
            var source = PrefabUtility.GetCorrespondingObjectFromOriginalSource(avatar.gameObject);
            return source ? AssetDatabase.GetAssetPath(source) : avatar.gameObject.scene.path + "/" + avatar.name;
        }
    }
}
