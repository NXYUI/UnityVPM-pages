using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace PersonalPoseDeck
{
    // The browser's preview panel: playback, GoGoLoco start height, floor, tracking mode and the lighting radial menu.
    internal sealed partial class PoseDeckPoseBrowser
    {
        private static readonly float[] Speeds = { .25f, .5f, 1f, 2f };
        private static readonly string[] SpeedLabels = { "0.25×", "0.5×", "1×", "2×" };
        // Orbit angles: yaw 0 looks at the avatar's front (+Z), 90 at its right side.
        private static readonly (string Label, float Yaw, float Pitch)[] Views =
            { ("정면", 0f, -8f), ("측면", 90f, -8f), ("뒤", 180f, -8f), ("위", 0f, -85f) };
        [SerializeField] private float playbackSpeed = 1f;
        [SerializeField] private bool loopPlayback = true, mirrorPreview, showFloor = true, gogoPreview = true, thumbnailsInGame;
        [SerializeField] private int previewTracking;
        private static readonly string[] TrackingLabels = { "VR (3점)", "데스크톱", "풀바디" };
        private PoseDeckBuilder.PreviewSource gogoSource;
        private bool gogoSearched;
        private string gogoSearchError;
        private GUIStyle floorTouching, floorFloating, floorSinking;

        // Found once per project change: the stock GoGoLoco whose Base the preview runs.
        private PoseDeckBuilder.PreviewSource GoGoLocoSource()
        {
            if (gogoSearched) return gogoSource;
            gogoSearched = true;
            gogoSource = null;
            gogoSearchError = null;
            try { gogoSource = PoseDeckAvatarInstall.FindPreviewSource(); }
            catch (Exception e) { gogoSearchError = e.Message; }
            return gogoSource;
        }

        // Start height given to the poses added from the preview ("현재 클립 추가", "선택 목록 추가"). Off keeps GoGoLoco's own.
        [SerializeField] private bool addOverrideHeight;
        [SerializeField] private float addHeight = PoseDeckBuilder.DefaultStartHeight;

        // The start height the preview runs GoGoLoco with, and where it comes from. The shown clip, while it is not in
        // the deck yet, uses the height it would be added with (`pending`; thumbnails leave that out).
        private float PreviewStartHeight(AnimationClip clip, out string source, bool pending = true)
        {
            int count = preset ? preset.poses.Count : 0;
            int row = selectedPose >= 0 && selectedPose < count && preset.poses[selectedPose].clip == clip ? selectedPose : DeckIndexOf(clip);
            if (row >= 0 && preset.poses[row].overrideHeight)
            {
                source = $"덱 {row + 1}번 시작 높이";
                return preset.poses[row].height;
            }
            if (pending && row < 0 && addOverrideHeight && preset && clip && clip == active?.Clip)
            {
                source = "추가할 시작 높이";
                return Mathf.Clamp01(addHeight);
            }
            if (gogoSource != null && gogoSource.SlotFor(clip) >= 0)
            {
                source = "GoGoLoco 원본 포즈 값";
                return gogoSource.StartHeightFor(clip);
            }
            source = "GoGoLoco 기본값";
            return PoseDeckBuilder.DefaultStartHeight;
        }

        [SerializeField] private PoseDeckPreviewLighting lighting = new PoseDeckPreviewLighting();
        [SerializeField] private bool lightMenuOpen;
        private readonly List<int> lightMenuPath = new List<int>();
        private int lightMenuPage, lightPuppet = -1;
        private List<PoseDeckMaterialControl> lightControls = new List<PoseDeckMaterialControl>();
        private string lightSource;
        private PoseDeckLightFilter lightFilter;
        private GameObject lightControlsFor;
        private bool lightControlsRead;

        private sealed class LightItem
        {
            public string Label;
            public bool Axis;
            public Func<float> Get;
            public Action<float> Set;
            public Func<string> Text;
            public List<LightItem> Children;
            public Action Click;
        }

        private static LightItem Radial(string label, Func<float> get, Action<float> set, Func<string> text) =>
            new LightItem { Label = label, Get = get, Set = set, Text = text };

        private List<LightItem> LightMenuItems()
        {
            var items = new List<LightItem>
            {
                new LightItem { Label = "조명 위치", Axis = true },
                Radial("빛 세기", () => lighting.intensity / 3f, v => lighting.intensity = v * 3f, () => $"{lighting.intensity:0.00}"),
                Radial("색온도", () => lighting.temperature, v => lighting.temperature = v, () => $"{lighting.Kelvin} K"),
                Radial("보조광", () => lighting.fill / 3f, v => lighting.fill = v * 3f, () => $"{lighting.fill:0.00}"),
                Radial("환경광", () => lighting.ambient / 2f, v => lighting.ambient = v * 2f, () => $"{lighting.ambient:0.00}"),
                new LightItem
                {
                    Label = "프리셋",
                    Children = PoseDeckPreviewLighting.Presets.Select(p => new LightItem { Label = p.Label, Click = () => lighting.CopyFrom(p.Value) }).ToList(),
                },
            };
            if (lightControls.Count > 0)
                items.Add(new LightItem
                {
                    Label = "LLC",
                    Children = lightControls.Select(c => c.Toggle
                        ? new LightItem { Label = c.Label + (c.Value >= .5f ? " ✓" : ""), Click = () => c.Value = c.Value >= .5f ? 0f : 1f }
                        : Radial(c.Label, () => c.Normalized, v => c.Normalized = v, () => c.ValueText)).ToList(),
                });
            items.Add(new LightItem { Label = "초기화", Click = ResetLighting });
            return items;
        }

        private void ResetLighting()
        {
            lighting.CopyFrom(new PoseDeckPreviewLighting());
            foreach (var control in lightControls) control.Value = control.Initial;
        }

        // Light packages on the avatar are read once per avatar; their values start at what the avatar uses in game.
        private void RefreshLightControls()
        {
            if (lightControlsRead && lightControlsFor == avatar) return;
            lightControlsRead = true;
            lightControlsFor = avatar;
            lightControls = PoseDeckLightPackages.Detect(avatar, out lightSource, out lightFilter);
            ApplyRememberedLight();
            lightMenuPath.Clear();
            lightPuppet = -1;
        }

        private void ApplyPreviewLighting()
        {
            if (renderer == null) return;
            renderer.ApplyLighting(lighting);
            renderer.ApplyMaterialControls(lightControls, lightFilter);
            Repaint();
        }

        private Rect LightMenuRect(Rect preview)
        {
            float size = Mathf.Clamp(Mathf.Min(preview.width * .45f, preview.height - 40f), 140f, 230f);
            return new Rect(preview.xMax - size - 8f, preview.yMax - size - 8f, size, size);
        }

        // Called twice per event: before the preview for input (so the camera does not take the drag), after it to paint.
        private void DrawLightMenu(Rect preview)
        {
            if (!lightMenuOpen || renderer == null) return;
            var evt = Event.current;
            var circle = LightMenuRect(preview);
            var header = new Rect(circle.x, circle.y - 22f, circle.width, 20f);
            var items = LightMenuItems();
            var level = items;
            string title = "조명" + (lightSource != null ? " · " + lightSource : "");
            foreach (int i in lightMenuPath.ToArray())
            {
                if (i < 0 || i >= level.Count || level[i].Children == null) { lightMenuPath.Clear(); level = items; break; }
                title = level[i].Label;
                level = level[i].Children;
            }
            if (evt.type == EventType.Repaint) EditorGUI.DrawRect(header, new Color(.08f, .09f, .11f, .82f));
            if (lightPuppet >= 0 && lightPuppet < level.Count)
            {
                var item = level[lightPuppet];
                if (GUI.Button(new Rect(header.x + 2f, header.y + 2f, 50f, 16f), "◀ 뒤로", EditorStyles.miniButton)) { lightPuppet = -1; Repaint(); return; }
                GUI.Label(new Rect(header.x + 56f, header.y + 2f, header.width - 58f, 16f), item.Label, EditorStyles.whiteMiniLabel);
                int id = GUIUtility.GetControlID("PoseDeckLightPuppet".GetHashCode(), FocusType.Passive, circle);
                if (item.Axis)
                {
                    var axis = lighting.position;
                    if (PoseDeckRadialMenu.Axis(circle, id, ref axis, "앞",
                        $"높이 {lighting.Elevation:0}° · 방향 {lighting.Azimuth:+0;-0;0}°")) { lighting.position = axis; ApplyPreviewLighting(); }
                }
                else
                {
                    float value = item.Get();
                    if (PoseDeckRadialMenu.Radial(circle, id, ref value, item.Text())) { item.Set(value); ApplyPreviewLighting(); }
                }
                return;
            }
            // Pages of seven plus "다음" when a submenu holds more than VRChat's eight slots.
            const int perPage = 7;
            bool paged = level.Count > 8;
            int pages = paged ? (level.Count + perPage - 1) / perPage : 1;
            lightMenuPage = Mathf.Clamp(lightMenuPage, 0, pages - 1);
            int start = paged ? lightMenuPage * perPage : 0;
            var shown = level.Skip(start).Take(paged ? perPage : 8).ToList();
            var labels = shown.Select(x => x.Label).ToList();
            if (paged) labels.Add($"다음 ▸\n{lightMenuPage + 1}/{pages}");
            GUI.Label(new Rect(header.x + 6f, header.y + 2f, header.width - 8f, 16f), title, EditorStyles.whiteMiniLabel);
            int clicked = PoseDeckRadialMenu.Menu(circle, labels, lightMenuPath.Count == 0 ? "닫기" : "뒤로");
            if (clicked == -2)
            {
                if (lightMenuPath.Count == 0) lightMenuOpen = false;
                else lightMenuPath.RemoveAt(lightMenuPath.Count - 1);
                lightMenuPage = 0;
                Repaint();
            }
            else if (clicked >= 0)
            {
                if (paged && clicked == shown.Count) lightMenuPage = (lightMenuPage + 1) % pages;
                else
                {
                    int index = start + clicked;
                    var item = level[index];
                    if (item.Children != null) { lightMenuPath.Add(index); lightMenuPage = 0; }
                    else if (item.Click != null) { item.Click(); ApplyPreviewLighting(); }
                    else lightPuppet = index;
                }
                Repaint();
            }
            // Keep camera drags off the menu.
            if (evt.type == EventType.MouseDrag && GUIUtility.hotControl == 0 && Vector2.Distance(evt.mousePosition, circle.center) <= circle.width * .5f)
                evt.Use();
        }

        private void DrawFloorStatus(Rect rect, AnimationClip clip)
        {
            if (floorTouching == null)
            {
                GUIStyle Style(Color color) => new GUIStyle(EditorStyles.miniBoldLabel) { normal = { textColor = color } };
                floorTouching = Style(new Color(.55f, .9f, .6f));
                floorFloating = Style(new Color(.98f, .82f, .4f));
                floorSinking = Style(new Color(1f, .5f, .45f));
            }
            var lines = new List<(string Text, GUIStyle Style, string Tip)>();
            if (renderer.GoGoLocoReady)
            {
                PreviewStartHeight(clip, out string source);
                lines.Add(($"GoGoLoco 높이 반영 · Go/Float {renderer.StartHeight:0.000} · {source}", EditorStyles.whiteMiniLabel,
                    $"GoGoLoco Base를 그대로 실행해 게임과 같은 높이로 보여 줍니다({TrackingLabels[previewTracking]} 기준). " +
                    (VrShown ? "VRChat IK가 바꾸는 머리와 손은 ‘VR 손·머리’로 근사합니다." : "VRChat IK가 바꾸는 머리와 손은 ‘VR 손·머리’를 켜면 근사해 보여 줍니다.")));
            }
            else if (gogoPreview && renderer.Mode == PoseDeckPosePreview.Tracking.FullBody)
                lines.Add(("풀바디: GoGoLoco 포즈 없음 · 클립만 표시", floorFloating, renderer.GoGoLocoProblem ??
                    "풀바디(5점 이상)에서는 GoGoLoco가 포즈를 재생하지 않습니다. VR이나 데스크톱으로 바꾸면 게임 속 높이를 볼 수 있습니다."));
            else
                lines.Add(("클립만 표시 · GoGoLoco 높이 미반영", EditorStyles.whiteMiniLabel,
                    renderer.GoGoLocoProblem ?? gogoSearchError ?? "‘GoGoLoco 높이’를 켜면 게임 안의 시작 높이로 보여 줍니다."));
            if (showFloor && renderer.LowestPoint is float low)
            {
                const float touch = .015f;
                lines.Add(low > touch ? ($"바닥에서 {low:0.00} m 떠 있음", floorFloating, null) :
                    low < -touch ? ($"바닥 아래로 {-low:0.00} m 들어감", floorSinking, null) :
                    ($"바닥에 닿음 ({low:+0.00;-0.00;0.00} m)", floorTouching, (string)null));
            }
            if (VrStatus(clip) is var vr && vr.HasValue) lines.Add(vr.Value);
            float height = lines.Count * 16f + 6f;
            float wide = VrShown ? 420f : 360f;
            float width = Mathf.Min(rect.width - 12f, wide, lightMenuOpen ? rect.width - LightMenuRect(rect).width - 24f : wide);
            var box = new Rect(rect.x + 6f, rect.yMax - height - 6f, Mathf.Max(120f, width), height);
            EditorGUI.DrawRect(box, new Color(0f, 0f, 0f, .45f));
            for (int i = 0; i < lines.Count; i++)
                GUI.Label(new Rect(box.x + 6f, box.y + 3f + i * 16f, box.width - 12f, 16f), new GUIContent(lines[i].Text, lines[i].Tip), lines[i].Style);
        }

        // The start height the next added poses get, set before adding. The preview shows the current clip at it.
        private void DrawAddHeight(AnimationClip clip, int deckIndex)
        {
            bool addable = clip && active != null && active.Humanoid && deckIndex < 0;
            if (!preset || (!addable && queued.Count == 0)) return;
            using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
            {
                if (DrawStartHeight(ref addOverrideHeight, ref addHeight, (PoseCategory)category, addable,
                    new GUIContent("추가할 때 시작 높이 지정",
                        "‘현재 클립 추가’와 ‘선택 목록 추가’로 넣는 포즈가 이 시작 높이(Go/Float)로 들어갑니다. 끄면 GoGoLoco 기본값을 씁니다. 추가한 뒤에도 덱 탭에서 포즈마다 바꿀 수 있습니다."),
                    "덱에 이미 있는 클립은 덱에 정한 높이로 보여 줍니다. 덱에 없는 클립을 고르면 이 높이로 미리 보고 바닥에 맞출 수 있습니다.", compact: true))
                {
                    addHeight = Mathf.Clamp01(addHeight);
                    Repaint();
                }
                if (addOverrideHeight && queued.Count > 0)
                    EditorGUILayout.LabelField($"‘선택 목록 추가’로 넣는 {queued.Count}개도 모두 이 높이로 들어갑니다.", EditorStyles.wordWrappedMiniLabel);
            }
        }

        // The last preview settings are kept per project (PoseDeckPreviewStore): written while the window is open and on
        // closing, read when it opens. The camera survives other poses, avatars and reopening the window.
        [SerializeField] private bool hasPreviewCamera;
        [SerializeField] private PoseDeckCameraState previewCamera;
        private PoseDeckPreviewStore previewStore;
        // Light-package values changed from the avatar's own, by label; applied to every avatar with the same control.
        private readonly Dictionary<string, float> rememberedLight = new Dictionary<string, float>();
        private string savedPreviewJson, previewStoreError;
        private double previewCheckedAt;
        private bool namingPreset, focusPresetName;
        private string presetName = "";
        private const string PresetNameControl = "PoseDeckPreviewPresetName";

        private PoseDeckPreviewStore PreviewStore => previewStore ?? (previewStore = PoseDeckPreviewStore.Load());

        private void RememberCamera()
        {
            if (renderer == null || !cameraPlaced) return;
            previewCamera = renderer.CameraState;
            hasPreviewCamera = true;
        }

        private PoseDeckPreviewSettings CapturePreview()
        {
            RememberCamera();
            foreach (var control in lightControls)
            {
                if (Mathf.Approximately(control.Value, control.Initial)) rememberedLight.Remove(control.Label);
                else rememberedLight[control.Label] = control.Value;
            }
            return new PoseDeckPreviewSettings
            {
                playbackSpeed = playbackSpeed, loop = loopPlayback, mirror = mirrorPreview, floor = showFloor, gogoHeight = gogoPreview,
                thumbnailsInGame = thumbnailsInGame, tracking = previewTracking, vr = vrPreview, vrSettings = vrSettings,
                lighting = lighting.Clone(),
                lightControls = rememberedLight.OrderBy(x => x.Key, StringComparer.Ordinal)
                    .Select(x => new PoseDeckPreviewSettings.LightValue { label = x.Key, value = x.Value }).ToList(),
                hasCamera = hasPreviewCamera, camera = previewCamera,
            };
        }

        private void ApplyRememberedLight()
        {
            foreach (var control in lightControls)
                control.Value = !rememberedLight.TryGetValue(control.Label, out float value) ? control.Initial
                    : control.Toggle ? (value >= .5f ? 1f : 0f)
                    : Mathf.Clamp(value, Mathf.Min(control.Min, control.Max), Mathf.Max(control.Min, control.Max));
        }

        private void ApplyPreviewSettings(PoseDeckPreviewSettings settings)
        {
            settings = settings ?? new PoseDeckPreviewSettings();
            bool thumbnailsChange = thumbnailsInGame || settings.thumbnailsInGame;
            playbackSpeed = Speeds.Contains(settings.playbackSpeed) ? settings.playbackSpeed : 1f;
            loopPlayback = settings.loop;
            mirrorPreview = settings.mirror;
            showFloor = settings.floor;
            gogoPreview = settings.gogoHeight;
            thumbnailsInGame = settings.thumbnailsInGame;
            previewTracking = Mathf.Clamp(settings.tracking, 0, TrackingLabels.Length - 1);
            vrPreview = settings.vr;
            vrSettings = settings.vrSettings;
            vrSettings.hands = (PoseDeckVrPose.HandPlace)Mathf.Clamp((int)vrSettings.hands, 0, VrHandOptions.Length - 1);
            vrSettings.head = (PoseDeckVrPose.HeadMode)Mathf.Clamp((int)vrSettings.head, 0, VrHeadOptions.Length - 1);
            lighting.CopyFrom(settings.lighting ?? new PoseDeckPreviewLighting());
            rememberedLight.Clear();
            foreach (var value in settings.lightControls ?? new List<PoseDeckPreviewSettings.LightValue>())
                if (value != null && !string.IsNullOrEmpty(value.label)) rememberedLight[value.label] = value.value;
            ApplyRememberedLight();
            hasPreviewCamera = settings.hasCamera;
            previewCamera = settings.camera;
            if (renderer != null)
            {
                try
                {
                    renderer.ShowFloor = showFloor;
                    renderer.Mode = (PoseDeckPosePreview.Tracking)previewTracking;
                    renderer.Mirror = mirrorPreview;
                    renderer.UseGoGoLoco(gogoPreview ? GoGoLocoSource() : null);
                    if (cameraPlaced)
                    {
                        if (hasPreviewCamera) renderer.CameraState = previewCamera;
                        else renderer.Fit();
                    }
                }
                catch (Exception e) { previewError = "미리보기 설정을 적용할 수 없습니다: " + e.Message; }
                ApplyPreviewLighting();
            }
            if (thumbnailsChange) ClearThumbnails();
            sampleDirty = true;
            Repaint();
        }

        private void LoadPreviewSettings()
        {
            previewStore = PoseDeckPreviewStore.Load();
            if (previewStore.current != null) ApplyPreviewSettings(previewStore.current);
            savedPreviewJson = CapturePreview().Json;
        }

        // Writes the settings when they changed, at most twice a second unless forced (closing the window).
        private void SavePreviewSettings(bool force = false)
        {
            double now = EditorApplication.timeSinceStartup;
            if (!force && now - previewCheckedAt < .5) return;
            previewCheckedAt = now;
            var current = CapturePreview();
            string json = current.Json;
            if (json == savedPreviewJson) return;
            savedPreviewJson = json;
            WriteStore(current);
        }

        private bool WriteStore(PoseDeckPreviewSettings current)
        {
            var store = PreviewStore;
            store.current = current;
            try
            {
                store.Save();
                previewStoreError = null;
                return true;
            }
            catch (Exception e)
            {
                if (previewStoreError == null)
                    Debug.LogWarning($"[Personal Pose Deck] 미리보기 설정을 저장하지 못했습니다: {PoseDeckPreviewStore.FilePath}\n{e.Message}");
                previewStoreError = e.Message;
                return false;
            }
        }

        // GenericMenu turns "/" into submenus.
        private static string MenuText(string name) => name.Replace('/', '∕');

        private void ShowPreviewPresetMenu()
        {
            var store = PreviewStore;
            var now = CapturePreview();
            var menu = new GenericMenu();
            if (store.presets.Count == 0) menu.AddDisabledItem(new GUIContent("저장한 프리셋이 없습니다"));
            foreach (var item in store.presets)
            {
                var choice = item;
                menu.AddItem(new GUIContent(MenuText(item.name)), item.settings.SameAs(now), () => ApplyPreviewPreset(choice));
            }
            menu.AddSeparator("");
            menu.AddItem(new GUIContent("현재 설정을 새 프리셋으로 저장…"), false, () =>
            {
                namingPreset = true;
                focusPresetName = true;
                presetName = NextPresetName();
                Repaint();
            });
            foreach (var item in store.presets)
            {
                string name = item.name;
                menu.AddItem(new GUIContent("현재 설정으로 덮어쓰기/" + MenuText(name)), false, () => SavePreviewPreset(name, false));
            }
            foreach (var item in store.presets)
            {
                string name = item.name;
                menu.AddItem(new GUIContent("삭제/" + MenuText(name)), false, () => DeletePreviewPreset(name));
            }
            menu.AddSeparator("");
            menu.AddItem(new GUIContent("우클릭 시선 상하 반전"), invertRightDragVertical, () =>
            {
                invertRightDragVertical = !invertRightDragVertical;
                EditorPrefs.SetBool(InvertCameraPreference, invertRightDragVertical);
            });
            menu.AddItem(new GUIContent("기본 설정으로 되돌리기"), false, () =>
            {
                ApplyPreviewSettings(new PoseDeckPreviewSettings());
                message = "미리보기를 기본 설정으로 되돌렸어요. 카메라는 지금 포즈에 맞췄어요.";
            });
            menu.ShowAsContext();
        }

        private string NextPresetName()
        {
            for (int i = 1; ; i++)
                if (PreviewStore.Find("프리셋 " + i) == null) return "프리셋 " + i;
        }

        private void ApplyPreviewPreset(PoseDeckPreviewPreset item)
        {
            ApplyPreviewSettings(item.settings.Clone());
            message = $"‘{item.name}’ 프리셋을 적용했어요.";
        }

        // `ask`: confirm before replacing a preset of the same name.
        private void SavePreviewPreset(string name, bool ask)
        {
            var store = PreviewStore;
            if (ask && store.Find(name) != null && !EditorUtility.DisplayDialog("미리보기 프리셋",
                $"‘{name}’ 프리셋이 이미 있습니다. 지금 설정으로 덮어쓸까요?", "덮어쓰기", "취소")) return;
            var current = CapturePreview();
            store.Put(name, current);
            savedPreviewJson = current.Json;
            message = WriteStore(current) ? $"‘{name}’ 프리셋에 지금 미리보기 설정을 저장했어요."
                : "미리보기 프리셋을 파일에 저장하지 못했어요: " + previewStoreError;
            namingPreset = false;
            Repaint();
        }

        private void DeletePreviewPreset(string name)
        {
            if (!EditorUtility.DisplayDialog("미리보기 프리셋", $"‘{name}’ 프리셋을 삭제할까요? 되돌릴 수 없습니다.", "삭제", "취소")) return;
            if (!PreviewStore.Remove(name)) return;
            var current = CapturePreview();
            savedPreviewJson = current.Json;
            message = WriteStore(current) ? $"‘{name}’ 프리셋을 삭제했어요." : "미리보기 프리셋을 파일에 저장하지 못했어요: " + previewStoreError;
            Repaint();
        }

        private void DrawPresetNaming()
        {
            if (!namingPreset) return;
            var evt = Event.current;
            bool focused = GUI.GetNameOfFocusedControl() == PresetNameControl;
            bool enter = focused && evt.type == EventType.KeyDown && (evt.keyCode == KeyCode.Return || evt.keyCode == KeyCode.KeypadEnter);
            bool escape = focused && evt.type == EventType.KeyDown && evt.keyCode == KeyCode.Escape;
            using (new EditorGUILayout.HorizontalScope())
            {
                GUI.SetNextControlName(PresetNameControl);
                presetName = EditorGUILayout.TextField("새 프리셋 이름", presetName);
                if (focusPresetName)
                {
                    focusPresetName = false;
                    EditorGUI.FocusTextInControl(PresetNameControl);
                }
                string name = (presetName ?? "").Trim();
                bool save, cancel;
                using (new EditorGUI.DisabledScope(name.Length == 0))
                    save = GUILayout.Button("저장", EditorStyles.miniButton, GUILayout.Width(40)) || enter && name.Length > 0;
                cancel = GUILayout.Button("취소", EditorStyles.miniButton, GUILayout.Width(40)) || escape;
                if (enter || escape) evt.Use();
                if (save || cancel)
                {
                    GUI.FocusControl(null);
                    if (save) SavePreviewPreset(name, true);
                    else namingPreset = false;
                }
            }
        }

        private void TogglePlay()
        {
            var clip = active?.Clip;
            if (!playing && clip && !loopPlayback && time >= clip.length - .0001f) time = 0f;
            playing = !playing;
            lastPlayback = EditorApplication.timeSinceStartup;
            sampleDirty = true;
            Repaint();
        }

        private static float FrameRate(AnimationClip clip) => clip && clip.frameRate > 0 ? clip.frameRate : 60f;

        private void StepFrame(AnimationClip clip, int direction)
        {
            if (!clip) return;
            playing = false;
            float fps = FrameRate(clip);
            time = Mathf.Clamp((Mathf.Round(time * fps) + direction) / fps, 0f, clip.length);
            sampleDirty = true;
            Repaint();
        }

        private string FrameLabel(AnimationClip clip)
        {
            float fps = FrameRate(clip);
            return $"{time:0.00}s · {Mathf.RoundToInt(time * fps)}/{Mathf.RoundToInt(clip.length * fps)}f";
        }

        private void HandlePreviewKeys(AnimationClip clip)
        {
            var evt = Event.current;
            if (evt.type != EventType.KeyDown || !clip || focusedWindow != this ||
                GUIUtility.keyboardControl != 0 || EditorGUIUtility.editingTextField) return;
            if (evt.keyCode == KeyCode.Space) TogglePlay();
            else if (evt.keyCode == KeyCode.LeftArrow) StepFrame(clip, -1);
            else if (evt.keyCode == KeyCode.RightArrow) StepFrame(clip, 1);
            // F frames the pose, as in the Scene view.
            else if (evt.keyCode == KeyCode.F && evt.modifiers == EventModifiers.None && rendererIsReady) { renderer.Fit(); Repaint(); }
            else return;
            evt.Use();
        }

        private GUIStyle overlayHelp;

        // On the preview itself, so they take no rows: views and fit at the top left; floor, mirror and the mouse help
        // at the top right (under the views when the preview is narrow).
        private void DrawPreviewOverlay(Rect rect)
        {
            const float h = 18f, gap = 2f;
            float x = rect.x + 6f, y = rect.y + 6f;
            foreach (var (label, viewYaw, viewPitch) in Views)
            {
                if (GUI.Button(new Rect(x, y, 34f, h), label, EditorStyles.miniButton)) { renderer.SetView(viewYaw, viewPitch); Repaint(); }
                x += 34f + gap;
            }
            if (GUI.Button(new Rect(x + 4f, y, 38f, h), new GUIContent("맞춤", "지금 포즈에 맞춰 카메라를 다시 잡습니다(F). 포즈를 바꿔도 카메라는 그대로 둡니다."),
                EditorStyles.miniButton)) { renderer.Fit(); Repaint(); }
            float leftEnd = x + 46f;
            const float rightWidth = 38f + gap + 58f + gap + 20f;
            if (rect.xMax - 6f - rightWidth < leftEnd + 8f) y += h + gap;
            float r = rect.xMax - 6f;
            if (overlayHelp == null)
                overlayHelp = new GUIStyle(EditorStyles.miniButton) { alignment = TextAnchor.MiddleCenter, fontStyle = FontStyle.Bold };
            GUI.Label(new Rect(r - 20f, y, 20f, h), new GUIContent("?",
                "Scene 뷰와 같은 카메라입니다. 좌클릭(또는 Alt+좌클릭) 드래그: 회전 · 휠: 확대·축소 · 휠 버튼(또는 Ctrl+Alt+좌클릭) 드래그: 평행 이동 · Alt+우클릭 드래그: 확대·축소 · 우클릭 드래그: 시선, 누른 채 WASD/QE: 이동(Shift 빠르게, 휠로 속도) · F: 맞춤 · Space: 재생 · ←/→: 한 프레임"),
                overlayHelp);
            r -= 20f + gap;
            bool mirrorNext = GUI.Toggle(new Rect(r - 58f, y, 58f, h), mirrorPreview, new GUIContent("좌우 반전",
                "GoGoLoco의 미러 포즈(Right 상태)처럼 좌우를 바꿔 봅니다. Humanoid 클립에만 적용됩니다."), EditorStyles.miniButton);
            if (mirrorNext != mirrorPreview)
            {
                mirrorPreview = mirrorNext;
                try { if (renderer != null) renderer.Mirror = mirrorPreview; }
                catch (Exception e) { previewError = "좌우 반전 미리보기를 만들 수 없습니다: " + e.Message; }
                sampleDirty = true;
            }
            r -= 58f + gap;
            bool floorNext = GUI.Toggle(new Rect(r - 38f, y, 38f, h), showFloor, new GUIContent("바닥", "바닥 격자와 바닥 기준 최저점을 표시합니다."),
                EditorStyles.miniButton);
            if (floorNext != showFloor) { showFloor = floorNext; if (renderer != null) renderer.ShowFloor = showFloor; }
        }

        // The controls under the preview scroll when the window is too short for them, so the preview keeps at least
        // PreviewMinHeight and stays in view while they are used (start height, deck settings). Heights come from the
        // last repaint: the room from the panel's top to the window's bottom (not the panel's own height, which grows
        // past the window when its content overflows and then left the last controls out of reach), where the preview
        // starts in it, and how tall the controls are.
        private const float PreviewMinHeight = 235f;
        private const float MinControlsHeight = 120f;
        private float panelHeight, previewTop, controlsHeight = 300f;
        // Where the preview was drawn, in screen space (read by the GUI tests).
        internal Rect previewScreenRect;
        private Vector2 controlsScroll;

        private void DrawPreview()
        {
            using (var panel = new EditorGUILayout.VerticalScope(GUILayout.ExpandWidth(true), GUILayout.ExpandHeight(true)))
            {
                if (Event.current.type == EventType.Repaint) panelHeight = position.height - panel.rect.y - 2f;
                var clip = active?.Clip;
                int deckIndex = DeckIndexOf(clip);
                HandlePreviewKeys(clip);
                // One row above the preview: the clip (its path in the tooltip), its deck number, and the preview menus.
                using (new EditorGUILayout.HorizontalScope())
                {
                    GUILayout.Label(new GUIContent(clip ? clip.name : "클립을 선택하세요", clip ? active.Path : null), EditorStyles.boldLabel,
                        GUILayout.MinWidth(60), GUILayout.ExpandWidth(true));
                    if (deckIndex >= 0) GUILayout.Label($"덱 {deckIndex + 1}번", EditorStyles.miniBoldLabel, GUILayout.Width(46));
                    RefreshLightControls();
                    if (GUILayout.Button(new GUIContent("프리셋",
                        "카메라·조명·재생·표시 설정을 이름을 붙여 저장하고 다시 불러옵니다. 마지막으로 조정한 설정은 프리셋과 별개로 이 프로젝트에 자동 저장됩니다. 우클릭 시선의 상하 반전도 여기서 바꿉니다."),
                        EditorStyles.miniButtonLeft, GUILayout.Width(44))) ShowPreviewPresetMenu();
                    bool menuNext = GUILayout.Toggle(lightMenuOpen, new GUIContent("조명",
                        "미리보기 위에 원형 메뉴를 띄워 조명 위치·세기·색온도·보조광·환경광을 바꿉니다." +
                        (lightControls.Count > 0 ? $" 아바타의 {lightSource} 설정 {lightControls.Count}개도 ‘LLC’에서 조절할 수 있습니다." : "")),
                        EditorStyles.miniButtonMid, GUILayout.Width(36));
                    if (menuNext != lightMenuOpen) { lightMenuOpen = menuNext; lightMenuPath.Clear(); lightPuppet = -1; }
                    using (new EditorGUI.DisabledScope(!clip))
                        if (GUILayout.Button(new GUIContent("위치", "Project 창에서 이 클립을 보여 줍니다."), EditorStyles.miniButtonRight, GUILayout.Width(36)))
                            EditorGUIUtility.PingObject(clip);
                }
                DrawPresetNaming();
                var rect = GUILayoutUtility.GetRect(240, PreviewMinHeight, GUILayout.ExpandWidth(true), GUILayout.ExpandHeight(true));
                if (Event.current.type == EventType.Repaint) previewTop = rect.y - panel.rect.y;
                if (Event.current.type == EventType.Repaint) previewScreenRect = GUIUtility.GUIToScreenRect(rect);
                if (Event.current.type == EventType.Repaint)
                {
                    EditorGUI.DrawRect(rect, new Color(.19f, .21f, .24f));
                    var source = PreviewRoot;
                    if (source && clip && previewNeedsBuild)
                    {
                        previewNeedsBuild = false;
                        try
                        {
                            renderer = new PoseDeckPosePreview(source);
                            renderer.ShowFloor = showFloor;
                            renderer.Mirror = mirrorPreview;
                            renderer.Mode = (PoseDeckPosePreview.Tracking)previewTracking;
                            renderer.UseGoGoLoco(gogoPreview ? GoGoLocoSource() : null);
                            ApplyPreviewLighting();
                        }
                        catch (Exception e) { previewError = "아바타 미리보기를 만들 수 없습니다: " + e.Message; }
                    }
                }
                if (rendererIsReady && clip)
                {
                    renderer.ExactMeasure = !playing;
                    float startHeight = PreviewStartHeight(clip, out _);
                    if (!Mathf.Approximately(renderer.StartHeight, startHeight)) { renderer.StartHeight = startHeight; sampleDirty = true; }
                    SyncVrPreview(clip);
                }
                if (rendererIsReady && clip)
                {
                    try
                    {
                        if (sampleDirty && Event.current.type == EventType.Repaint)
                        {
                            renderer.SetClip(clip);
                            renderer.Sample(time);
                            if (!cameraPlaced)
                            {
                                if (hasPreviewCamera) renderer.CameraState = previewCamera;
                                else renderer.Fit();
                                cameraPlaced = true;
                            }
                            sampleDirty = false;
                        }
                        bool repaint = Event.current.type == EventType.Repaint;
                        if (!repaint) { DrawLightMenu(rect); VrHandles(rect, paint: false); }
                        renderer.Draw(rect, invertRightDragVertical);
                        if (repaint) { VrHandles(rect, paint: true); DrawLightMenu(rect); }
                        // After the camera, in every event: the camera does not take a left click, so the buttons get it.
                        DrawPreviewOverlay(rect);
                    }
                    catch (Exception e)
                    {
                        previewError = "클립을 미리 볼 수 없습니다: " + e.Message;
                        Debug.LogWarning($"[Personal Pose Deck] 미리보기 실패: {AssetDatabase.GetAssetPath(clip)} ({clip.name})\n{e}");
                        playing = false;
                    }
                }
                string overlay = previewError ?? (!avatar ? "상단에서 미리 볼 아바타를 지정하세요." :
                    (assemblePreview && assemblyPending ? "Modular Avatar 조립 중…" :
                    (!clip ? "카드나 덱의 번호를 클릭하면 포즈를 크게 보거나 재생할 수 있어요." :
                    (clip.legacy ? "Legacy 클립은 이 창에서 재생할 수 없습니다." :
                    (renderer != null && !renderer.HasRenderers ? "미리 볼 렌더러가 없습니다." :
                    (renderer != null && active.Humanoid && !renderer.HasHumanoidAvatar ? "유효한 Humanoid 아바타를 지정하세요." : null))))));
                if (!string.IsNullOrEmpty(overlay))
                    GUI.Label(new Rect(rect.x + 14, rect.y + 12, rect.width - 28, 54), overlay, EditorStyles.wordWrappedLabel);
                else if (rendererIsReady && clip && active.Humanoid && renderer.HasHumanoidAvatar) DrawFloorStatus(rect, clip);
                if (GUI.changed) Repaint();

                float room = Mathf.Max(MinControlsHeight, panelHeight - previewTop - PreviewMinHeight);
                using (var scroll = new EditorGUILayout.ScrollViewScope(controlsScroll, false, false, GUIStyle.none,
                    GUI.skin.verticalScrollbar, GUIStyle.none, GUILayout.Height(Mathf.Min(controlsHeight, room))))
                {
                    controlsScroll = scroll.scrollPosition;
                    bool canPlay = clip && !clip.legacy && rendererIsReady && (!active.Humanoid || renderer.HasHumanoidAvatar);
                    using (new EditorGUILayout.HorizontalScope())
                    {
                        using (new EditorGUI.DisabledScope(!canPlay))
                        {
                            if (GUILayout.Button(new GUIContent("◀", "이전 프레임 (←)"), EditorStyles.miniButtonLeft, GUILayout.Width(26))) StepFrame(clip, -1);
                            if (GUILayout.Button(new GUIContent(playing ? "일시 정지" : "재생", "재생 / 일시 정지 (Space)"),
                                EditorStyles.miniButtonMid, GUILayout.Width(64))) TogglePlay();
                            if (GUILayout.Button(new GUIContent("▶", "다음 프레임 (→)"), EditorStyles.miniButtonRight, GUILayout.Width(26))) StepFrame(clip, 1);
                            float next = EditorGUILayout.Slider(time, 0f, clip ? Mathf.Max(.001f, clip.length) : 1f, GUILayout.MinWidth(60));
                            if (!Mathf.Approximately(next, time)) { time = next; sampleDirty = true; Repaint(); }
                        }
                        GUILayout.Label(clip ? FrameLabel(clip) : "", EditorStyles.miniLabel, GUILayout.Width(78));
                        int speed = Mathf.Max(0, Array.IndexOf(Speeds, playbackSpeed));
                        int nextSpeed = EditorGUILayout.Popup(speed, SpeedLabels, GUILayout.Width(50));
                        if (nextSpeed != speed) playbackSpeed = Speeds[nextSpeed];
                        loopPlayback = GUILayout.Toggle(loopPlayback, new GUIContent("반복", "끝에 닿으면 처음부터 다시 재생합니다."),
                            EditorStyles.miniButton, GUILayout.Width(36));
                    }
                    using (new EditorGUILayout.HorizontalScope())
                    {
                        bool gogoNext = GUILayout.Toggle(gogoPreview, new GUIContent("GoGoLoco 높이",
                            "GoGoLoco Base를 실행해 시작 높이(Go/Float)를 반영한 게임 속 위치로 보여 줍니다. 끄면 클립만 재생합니다."),
                            EditorStyles.miniButton, GUILayout.Width(84));
                        if (gogoNext != gogoPreview)
                        {
                            gogoPreview = gogoNext;
                            try { renderer?.UseGoGoLoco(gogoPreview ? GoGoLocoSource() : null); }
                            catch (Exception e) { previewError = "GoGoLoco 높이 미리보기를 만들 수 없습니다: " + e.Message; }
                            sampleDirty = true;
                            if (thumbnailsInGame) ClearThumbnails();
                        }
                        using (new EditorGUI.DisabledScope(!gogoPreview))
                        {
                            int nextMode = EditorGUILayout.Popup(previewTracking, TrackingLabels, GUILayout.Width(80));
                            if (nextMode != previewTracking)
                            {
                                previewTracking = nextMode;
                                if (renderer != null) renderer.Mode = (PoseDeckPosePreview.Tracking)previewTracking;
                                sampleDirty = true;
                                if (thumbnailsInGame) ClearThumbnails();
                            }
                        }
                        bool thumbsNext = GUILayout.Toggle(thumbnailsInGame, new GUIContent("썸네일에도",
                            "갤러리 썸네일도 GoGoLoco 높이와 지금 조명·LLC 값으로 그립니다. 썸네일 생성이 느려집니다."),
                            EditorStyles.miniButton, GUILayout.Width(70));
                        if (thumbsNext != thumbnailsInGame) { thumbnailsInGame = thumbsNext; ClearThumbnails(); }
                    }
                    DrawVrRow();
                    // The end of the controls: their own height, even when the view is taller.
                    var end = GUILayoutUtility.GetRect(1f, 0f, GUILayout.ExpandWidth(true));
                    if (Event.current.type == EventType.Repaint && Mathf.Abs(end.y - controlsHeight) > .5f)
                    {
                        controlsHeight = end.y;
                        Repaint();
                    }
                }
            }
        }
    }
}
