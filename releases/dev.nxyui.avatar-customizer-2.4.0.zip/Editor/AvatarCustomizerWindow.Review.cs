#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;
using VRC.SDK3.Avatars.ScriptableObjects;
using Control = VRC.SDK3.Avatars.ScriptableObjects.VRCExpressionsMenu.Control;

namespace AvatarMenuTools
{
    internal sealed partial class AvatarCustomizerWindow
    {
        private sealed class PreviewPage
        {
            // Favorite: a favorites menu this tool built.
            internal readonly List<(string Name, Control.ControlType Type, PreviewPage Child, Texture2D Icon, bool Favorite)> Items =
                new List<(string, Control.ControlType, PreviewPage, Texture2D, bool)>();
            // A favorites menu is on this page or somewhere below it.
            internal bool HoldsFavorite;
        }

        private readonly HashSet<FavoriteMenuKey> batchSources = new HashSet<FavoriteMenuKey>();
        private readonly HashSet<FavoriteMenuEntry> batchEntries = new HashSet<FavoriteMenuEntry>();
        private readonly List<(string Name, PreviewPage Page)> previewPath = new List<(string, PreviewPage)>();
        private FavoriteMenuBuilder.Issue[] reviewIssues = Array.Empty<FavoriteMenuBuilder.Issue>();
        private FavoriteMenuBuilder.Issue repairIssue;
        private Vector2 previewScroll, issuesScroll;
        private bool reviewReady, reviewStale, reviewSuccessful;
        private string reviewConfig;

        private void QueueScan(bool compare = false)
        {
            scanning = true;
            var selected = avatar;
            EditorApplication.delayCall += () => { if (this) Scan(selected, compare); };
        }

        private void ClearReview()
        {
            reviewReady = false;
            repairIssue = null;
            previewPath.Clear();
            reviewIssues = Array.Empty<FavoriteMenuBuilder.Issue>();
        }

        private void SetReview(VRCExpressionsMenu root, List<FavoriteMenuBuilder.Issue> issues,
            ICollection<VRCExpressionsMenu> favorites, bool successful, AvatarCustomizer config)
        {
            ClearReview();
            reviewReady = true;
            reviewStale = false;
            reviewSuccessful = successful;
            reviewConfig = config ? EditorJsonUtility.ToJson(config) : "";
            reviewIssues = issues.ToArray();
            previewScroll = issuesScroll = Vector2.zero;
            if (!root) return;

            // Snapshot only strings and links before the temporary Unity objects are destroyed.
            var pages = new Dictionary<VRCExpressionsMenu, PreviewPage>();
            var pending = new Queue<VRCExpressionsMenu>();
            PreviewPage Snapshot(VRCExpressionsMenu menu)
            {
                if (!menu) return null;
                if (!pages.TryGetValue(menu, out var page))
                {
                    pages.Add(menu, page = new PreviewPage());
                    pending.Enqueue(menu);
                }
                return page;
            }
            previewPath.Add(("최상위", Snapshot(root)));
            while (pending.Count > 0)
            {
                var menu = pending.Dequeue();
                foreach (var item in menu.controls ?? Enumerable.Empty<Control>())
                    if (item != null)
                        pages[menu].Items.Add((item.name, item.type,
                            item.type == Control.ControlType.SubMenu ? Snapshot(item.subMenu) : null, item.icon,
                            item.type == Control.ControlType.SubMenu && item.subMenu && favorites.Contains(item.subMenu)));
            }
            // Mark the way to each favorites menu, so a menu behind "More" or inside a submenu can be followed.
            var visiting = new HashSet<PreviewPage>();
            var done = new HashSet<PreviewPage>();
            bool Holds(PreviewPage page)
            {
                if (done.Contains(page) || !visiting.Add(page)) return page.HoldsFavorite;
                page.HoldsFavorite = page.Items.Any(i => i.Favorite) | page.Items.Where(i => i.Child != null).Select(i => Holds(i.Child)).ToArray().Any(h => h);
                visiting.Remove(page);
                done.Add(page);
                return page.HoldsFavorite;
            }
            foreach (var page in pages.Values) Holds(page);
        }

        private void DrawReview(AvatarCustomizer config)
        {
            if (!reviewReady)
            {
                EditorGUILayout.HelpBox("‘빌드 메뉴 읽기’로 최종 메뉴와 연결 상태를 확인하세요.", MessageType.Info);
                return;
            }
            bool stale = reviewStale || reviewConfig != (config ? EditorJsonUtility.ToJson(config) : "");
            if (stale)
                EditorGUILayout.HelpBox("이전 빌드 결과입니다. 현재 설정으로 다시 읽어 주세요.", MessageType.Warning);
            else if (!reviewSuccessful)
                EditorGUILayout.HelpBox("빌드 오류가 있어 결과가 일부만 표시될 수 있습니다.", MessageType.Warning);
            else if (config && !config.enabled)
                EditorGUILayout.HelpBox("Avatar Customizer 컴포넌트가 꺼져 있어 설정이 빌드에 적용되지 않습니다.", MessageType.Info);

            using var columns = new EditorGUILayout.HorizontalScope();
            using (new EditorGUILayout.VerticalScope(GUILayout.Width(position.width * .48f)))
            {
                if (repairIssue == null) DrawPreviewPage();
                else DrawOptions(new MenuView(catalogue, config), null);
            }
            using (new EditorGUILayout.VerticalScope(GUILayout.ExpandWidth(true)))
            {
                if (repairIssue == null) DrawIssues(!stale && reviewSuccessful);
                else DrawRepair(config, !stale && reviewSuccessful);
            }
        }

        private void DrawPreviewPage()
        {
            EditorGUILayout.LabelField("최종 메뉴", EditorStyles.boldLabel);
            if (previewPath.Count == 0)
            {
                EditorGUILayout.LabelField("빌드에서 생성된 메뉴가 없습니다.", EditorStyles.wordWrappedMiniLabel);
                return;
            }
            var current = previewPath[previewPath.Count - 1].Page;
            using (new EditorGUILayout.HorizontalScope())
            {
                using (new EditorGUI.DisabledScope(previewPath.Count == 1))
                    if (GUILayout.Button("←", GUILayout.Width(28)))
                    {
                        previewPath.RemoveAt(previewPath.Count - 1);
                        previewScroll = Vector2.zero;
                        GUIUtility.ExitGUI();
                    }
                string path = string.Join(" › ", previewPath.Select(p => p.Name));
                EditorGUILayout.LabelField(new GUIContent(path, path), EditorStyles.miniLabel);
            }
            EditorGUILayout.LabelField($"{current.Items.Count} / {VRCExpressionsMenu.MAX_CONTROLS} 슬롯", EditorStyles.miniLabel);
            using var scroll = new EditorGUILayout.ScrollViewScope(previewScroll, GUILayout.ExpandHeight(true));
            previewScroll = scroll.scrollPosition;
            for (int i = 0; i < current.Items.Count; i++)
            {
                var item = current.Items[i];
                string name = string.IsNullOrWhiteSpace(item.Name) ? "(이름 없음)" : item.Name;
                using (new EditorGUILayout.HorizontalScope(EditorStyles.helpBox))
                {
                    // Icons made only for the build are gone with its temporary assets and show as empty.
                    var icon = GUILayoutUtility.GetRect(18f, 18f, GUILayout.Width(18f), GUILayout.Height(18f));
                    if (item.Icon) GUI.DrawTexture(icon, item.Icon, ScaleMode.ScaleToFit);
                    EditorGUILayout.LabelField(new GUIContent($"{i + 1}. {name}", $"{name} · {item.Type}"));
                    if (item.Favorite)
                        GUILayout.Label(new GUIContent("즐겨찾기", "이 도구가 만든 즐겨찾기 메뉴"), EditorStyles.miniBoldLabel, GUILayout.ExpandWidth(false));
                    else if (item.Child?.HoldsFavorite == true)
                        GUILayout.Label(new GUIContent("즐겨찾기 있음", "이 안에 즐겨찾기 메뉴가 있어요."), EditorStyles.miniLabel, GUILayout.ExpandWidth(false));
                    if (item.Child == null) continue;
                    using (new EditorGUI.DisabledScope(previewPath.Any(p => p.Page == item.Child)))
                        if (GUILayout.Button("열기", GUILayout.Width(48)))
                        {
                            previewPath.Add((name, item.Child));
                            previewScroll = Vector2.zero;
                            GUIUtility.ExitGUI();
                        }
                }
            }
        }

        private void DrawIssues(bool canRepair)
        {
            int warnings = reviewIssues.Count(i => i.Warning);
            EditorGUILayout.LabelField($"검토할 항목 · 경고 {warnings}개 · 안내 {reviewIssues.Length - warnings}개",
                EditorStyles.boldLabel);
            using var scroll = new EditorGUILayout.ScrollViewScope(issuesScroll, GUILayout.ExpandHeight(true));
            issuesScroll = scroll.scrollPosition;
            if (reviewIssues.Length == 0)
                EditorGUILayout.LabelField("표시할 변경이나 문제가 없습니다.", EditorStyles.wordWrappedMiniLabel);
            foreach (var issue in reviewIssues.OrderByDescending(i => i.Warning))
            {
                using var card = new EditorGUILayout.VerticalScope(EditorStyles.helpBox);
                EditorGUILayout.LabelField((issue.Warning ? "⚠ " : "") + issue.Title, EditorStyles.wordWrappedMiniLabel);
                EditorGUILayout.LabelField(issue.Detail, EditorStyles.wordWrappedMiniLabel);
                if (issue.Target == FavoriteMenuBuilder.RepairTarget.None) continue;
                using (new EditorGUI.DisabledScope(!canRepair))
                    if (GUILayout.Button("연결 확인", GUILayout.Width(88)))
                    {
                        repairIssue = issue;
                        selectedKey = issue.Current;
                        search = "";
                        optionsScroll = Vector2.zero;
                        GUIUtility.ExitGUI();
                    }
            }
        }

        private void DrawRepair(AvatarCustomizer config, bool canRepair)
        {
            if (GUILayout.Button("← 빌드 결과", GUILayout.Width(104)))
            {
                repairIssue = null;
                GUIUtility.ExitGUI();
            }
            var issue = repairIssue;
            EditorGUILayout.LabelField(issue.Title, EditorStyles.wordWrappedLabel);
            EditorGUILayout.HelpBox(issue.Detail, issue.Warning ? MessageType.Warning : MessageType.Info);
            EditorGUILayout.LabelField("저장된 원본", EditorStyles.boldLabel);
            EditorGUILayout.LabelField(FavoriteMenuBuilder.Describe(issue.Saved), EditorStyles.wordWrappedMiniLabel);
            EditorGUILayout.Space(8);
            EditorGUILayout.LabelField("선택한 원본", EditorStyles.boldLabel);
            EditorGUILayout.LabelField(selectedKey == null ? "왼쪽 목록에서 원본을 선택하세요." :
                FavoriteMenuBuilder.Describe(selectedKey), EditorStyles.wordWrappedMiniLabel);
            var view = new MenuView(catalogue, config);
            bool suitable = selectedKey != null && view.Resolve(selectedKey) != null;
            if (suitable && (issue.Target == FavoriteMenuBuilder.RepairTarget.Destination ||
                             issue.Target == FavoriteMenuBuilder.RepairTarget.MoveDestination))
                suitable = selectedKey.type == Control.ControlType.SubMenu;
            if (suitable && issue.Target == FavoriteMenuBuilder.RepairTarget.Move &&
                view.MoveByControl.TryGetValue(selectedKey.sharedControl, out int moving) && moving != issue.ItemIndex)
            {
                suitable = false;
                EditorGUILayout.LabelField("이미 이동이 등록된 항목입니다.", EditorStyles.wordWrappedMiniLabel);
            }
            if (suitable && issue.Target == FavoriteMenuBuilder.RepairTarget.NameOverride &&
                view.RuleByControl.TryGetValue(selectedKey.sharedControl, out int existing) && existing != issue.ItemIndex)
            {
                suitable = false;
                EditorGUILayout.LabelField("이미 이름 변경이 등록된 항목입니다.", EditorStyles.wordWrappedMiniLabel);
            }
            using (new EditorGUI.DisabledScope(!canRepair || !suitable))
                if (GUILayout.Button("선택한 원본으로 연결"))
                {
                    var key = selectedKey;
                    Change("Relink favorites setting", c =>
                    {
                        switch (issue.Target)
                        {
                            case FavoriteMenuBuilder.RepairTarget.Shortcut:
                                c.GetMenu(issue.MenuIndex).entries[issue.ItemIndex].source = key;
                                break;
                            case FavoriteMenuBuilder.RepairTarget.Destination:
                                if (issue.MenuIndex == 0) { c.useRoot = false; c.destination = key; }
                                else if (c.GetMenu(issue.MenuIndex) is FavoriteMenuGroup menu)
                                { menu.useRoot = false; menu.destination = key; }
                                break;
                            case FavoriteMenuBuilder.RepairTarget.NameOverride:
                                c.nameOverrides[issue.ItemIndex].source = key;
                                break;
                            case FavoriteMenuBuilder.RepairTarget.Move:
                                c.menuMoves[issue.ItemIndex].source = key;
                                break;
                            case FavoriteMenuBuilder.RepairTarget.MoveDestination:
                                c.menuMoves[issue.ItemIndex].newFolder = "";
                                c.menuMoves[issue.ItemIndex].destination = key;
                                break;
                        }
                    });
                    repairIssue = null;
                    QueueScan();
                    GUIUtility.ExitGUI();
                }
        }

        private void DrawBatchActions(MenuView view, List<FavoriteMenuEntry> entries)
        {
            batchEntries.IntersectWith(entries);
            using var row = new EditorGUILayout.HorizontalScope();
            using (new EditorGUI.DisabledScope(batchSources.Count == 0))
                if (GUILayout.Button($"선택 추가 ({batchSources.Count})"))
                {
                    var existing = entries.Where(e => e != null && !e.IsFolder && e.Parent == addParent)
                        .Select(e => view.Resolve(e.source)?.sharedControl ?? 0).ToHashSet();
                    var added = catalogue.Where(batchSources.Contains).Select(view.Resolve)
                        .Where(key => key != null && existing.Add(key.sharedControl))
                        .Select(key => new FavoriteMenuEntry { source = key, parentId = addParent }).ToArray();
                    if (added.Length > 0)
                    {
                        ChangeEntries("Add selected favorites", list => list.AddRange(added));
                        Reveal(addParent, entries);
                    }
                    batchSources.Clear();
                    GUIUtility.ExitGUI();
                }
            using (new EditorGUI.DisabledScope(batchEntries.Count == 0))
                if (GUILayout.Button($"선택 이동 ({batchEntries.Count})"))
                    ShowBatchMove(view, entries);
            using (new EditorGUI.DisabledScope(batchSources.Count + batchEntries.Count == 0))
                if (GUILayout.Button("선택 해제", GUILayout.Width(76)))
                {
                    batchSources.Clear();
                    batchEntries.Clear();
                }
        }

        private void ShowBatchMove(MenuView view, List<FavoriteMenuEntry> entries)
        {
            var config = avatar.GetComponent<AvatarCustomizer>();
            if (!config) return;
            var selected = entries.Where(batchEntries.Contains).ToArray();
            var targetMenu = new GenericMenu();
            var selectedAvatar = avatar;
            int sourceIndex = menuIndex;
            int count = config.additionalMenus?.Count ?? 0;
            for (int index = 0; index <= count; index++)
            {
                var group = config.GetMenu(index);
                if (group == null) continue;
                int destinationIndex = index;
                var choices = FolderChoices(group.entries ?? new List<FavoriteMenuEntry>(), group.DisplayName);
                foreach (var choice in choices)
                {
                    var label = new GUIContent($"{index + 1}. {group.DisplayName.Replace("/", "／")}/{choice.Path.Replace("/", "／")}");
                    if (index == sourceIndex && selected.All(e => e.Parent == choice.Id))
                        targetMenu.AddDisabledItem(label, true);
                    else
                        targetMenu.AddItem(label, false, () =>
                        {
                            if (avatar != selectedAvatar || menuIndex != sourceIndex) return;
                            int moved = 0, duplicates = 0;
                            Change("Move selected favorites", c =>
                            {
                                var source = c.GetMenu(sourceIndex)?.entries;
                                var destination = c.GetMenu(destinationIndex);
                                if (source == null || destination == null) return;
                                var target = destinationIndex == 0 ? (c.entries ??= new List<FavoriteMenuEntry>()) :
                                    (destination.entries ??= new List<FavoriteMenuEntry>());
                                if (choice.Id.Length > 0 && !target.Any(e => e != null && e.folderId == choice.Id)) return;
                                foreach (var entry in selected)
                                {
                                    if (!source.Contains(entry) || (source == target && entry.Parent == choice.Id)) continue;
                                    if (target.Any(e => e != null && !e.IsFolder && e.Parent == choice.Id && SameShortcut(view, e, entry)))
                                    {
                                        duplicates++;
                                        continue;
                                    }
                                    source.Remove(entry);
                                    entry.parentId = choice.Id;
                                    target.Add(entry);
                                    batchEntries.Remove(entry);
                                    moved++;
                                }
                            });
                            if (destinationIndex == sourceIndex) Reveal(choice.Id, entries);
                            status = $"선택한 항목 {moved}개를 이동했습니다." +
                                (duplicates > 0 ? $" 이미 같은 바로가기가 있는 {duplicates}개는 원래 위치에 남겼습니다." : "");
                            statusType = MessageType.Info;
                            Repaint();
                        });
                }
            }
            targetMenu.ShowAsContext();
        }

        private static bool SameShortcut(MenuView view, FavoriteMenuEntry left, FavoriteMenuEntry right)
        {
            if ((left.label ?? "").Trim() != (right.label ?? "").Trim() || left.source == null || right.source == null)
                return false;
            var match = view.Resolve(left.source);
            return (match != null && match.sharedControl == view.Resolve(right.source)?.sharedControl) ||
                (left.source.SamePath(right.source) && left.source.SameBinding(right.source));
        }
    }
}
#endif
