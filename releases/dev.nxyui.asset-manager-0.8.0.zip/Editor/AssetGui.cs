using System;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace NXYUI.AssetManager
{
    // Drawing helpers shared by the window and the Inspector panels, and the counters their caches watch.
    [InitializeOnLoad]
    internal static class AssetGui
    {
        // Raised when the scene objects or the project files change; caches of avatars, places, prefabs compare it.
        internal static int HierarchyVersion { get; private set; }
        internal static int ProjectVersion { get; private set; }

        static AssetGui()
        {
            EditorApplication.hierarchyChanged += () => HierarchyVersion++;
            EditorApplication.projectChanged += () => ProjectVersion++;
            AssetStore.Changed += () => ProjectVersion++;
        }

        // A change that alters which controls are drawn waits for the next GUI pass: drawn now, the pass that is
        // running would meet controls its Layout did not have. Used by the Inspector panels, which must not ExitGUI
        // (that would also skip the headers other tools draw after them).
        internal static void Later(Action change, Action repaint)
        {
            EditorApplication.delayCall += () =>
            {
                change();
                repaint?.Invoke();
            };
        }

        private static GUIStyle badgeStyle;
        private static GUIStyle Badge => badgeStyle ?? (badgeStyle = new GUIStyle(EditorStyles.miniBoldLabel)
        {
            padding = new RectOffset(4, 4, 0, 0),
            margin = new RectOffset(0, 4, 2, 2),
        });

        private static GUIStyle wrappedLabel;
        internal static GUIStyle WrappedLabel => wrappedLabel ?? (wrappedLabel = new GUIStyle(EditorStyles.label) { wordWrap = true });

        // Badge colours, the same as the window's chips (AssetManager.uss): a tinted fill with text of the same hue,
        // each with its own word so colour is never the only signal.
        private static (Color Fill, Color Text) Tint(string kind)
        {
            var pro = EditorGUIUtility.isProSkin;
            switch (kind)
            {
                case "good": return pro ? (new Color32(38, 64, 46, 255), new Color32(138, 224, 168, 255)) : (new Color32(224, 242, 229, 255), new Color32(27, 115, 55, 255));
                case "warn": return pro ? (new Color32(74, 61, 32, 255), new Color32(240, 200, 96, 255)) : (new Color32(250, 238, 207, 255), new Color32(133, 86, 0, 255));
                case "bad": return pro ? (new Color32(80, 38, 38, 255), new Color32(255, 143, 134, 255)) : (new Color32(250, 225, 225, 255), new Color32(198, 40, 40, 255));
                case "accent": return pro ? (new Color32(55, 50, 92, 255), new Color32(196, 187, 255, 255)) : (new Color32(229, 226, 249, 255), new Color32(67, 52, 181, 255));
                default: return pro ? (new Color32(48, 50, 56, 255), new Color32(168, 170, 178, 255)) : (new Color32(233, 233, 238, 255), new Color32(88, 91, 100, 255));
            }
        }

        // The accent of the window (AssetManager.uss --am-accent), for the one main button of a panel.
        internal static Color Accent => EditorGUIUtility.isProSkin ? (Color)new Color32(139, 124, 246, 255) : new Color32(91, 75, 219, 255);

        internal static void DrawBadge(string text, string kind = "", string tooltip = null)
        {
            var content = new GUIContent(text, tooltip);
            var rect = GUILayoutUtility.GetRect(content, Badge, GUILayout.ExpandWidth(false));
            DrawBadge(rect, content, kind);
        }

        internal static void DrawBadge(Rect rect, GUIContent content, string kind)
        {
            var (fill, text) = Tint(kind);
            if (Event.current.type == EventType.Repaint) EditorGUI.DrawRect(rect, fill);
            var previous = Badge.normal.textColor;
            Badge.normal.textColor = text;
            GUI.Label(rect, content, Badge);
            Badge.normal.textColor = previous;
        }

        internal static void DrawThumbnail(Texture texture, float size, string placeholder)
        {
            var rect = GUILayoutUtility.GetRect(size, size, GUILayout.Width(size), GUILayout.Height(size));
            DrawThumbnail(rect, texture, placeholder);
        }

        // The image, or a plain square of the same size with a word while there is none (so nothing jumps on load).
        internal static void DrawThumbnail(Rect rect, Texture texture, string placeholder)
        {
            if (Event.current.type != EventType.Repaint) return;
            if (texture) GUI.DrawTexture(rect, texture, ScaleMode.ScaleAndCrop);
            else
            {
                EditorGUI.DrawRect(rect, EditorGUIUtility.isProSkin ? new Color(.18f, .18f, .18f) : new Color(.86f, .86f, .86f));
                GUI.Label(rect, placeholder, new GUIStyle(EditorStyles.centeredGreyMiniLabel) { wordWrap = true });
            }
        }

        // A text that may not fit: it takes the room left in its row, is cut with "…" and shows whole in the tooltip.
        internal static void ClippedLabel(string text, GUIStyle style, params GUILayoutOption[] options)
        {
            text = text ?? "";
            // The caller's options come last so they win over these defaults.
            var layout = new[] { GUILayout.ExpandWidth(true), GUILayout.MinWidth(30) }.Concat(options).ToArray();
            var rect = GUILayoutUtility.GetRect(new GUIContent("…"), style, layout);
            GUI.Label(rect, new GUIContent(Fit(text, style, rect.width), text), style);
        }

        internal static string Fit(string text, GUIStyle style, float width)
        {
            if (width <= 0 || style.CalcSize(new GUIContent(text)).x <= width) return text;
            int low = 0, high = text.Length;
            while (low < high)
            {
                var middle = (low + high + 1) / 2;
                if (style.CalcSize(new GUIContent(text.Substring(0, middle) + "…")).x <= width) low = middle;
                else high = middle - 1;
            }
            return text.Substring(0, low) + "…";
        }

        internal static string KindName(AssetKind kind)
        {
            switch (kind)
            {
                case AssetKind.Avatar: return "아바타";
                case AssetKind.Outfit: return "의상";
                case AssetKind.Accessory: return "액세서리";
                case AssetKind.Tool: return "도구";
                default: return "기타";
            }
        }

        internal static readonly string[] KindNames = Enum.GetValues(typeof(AssetKind)).Cast<AssetKind>().Select(KindName).ToArray();

        internal static string BoothUrl(long id) => "https://booth.pm/ja/items/" + id;

        private static readonly System.Collections.Generic.Dictionary<string, GameObject> FirstPrefabs = new System.Collections.Generic.Dictionary<string, GameObject>();
        private static int firstPrefabsVersion = -1;

        // The asset's picture: its Booth image when linked, else the preview of its top-most prefab, else none.
        internal static Texture AssetTexture(AssetRecord asset, Action repaint)
        {
            var item = AssetStore.Item(asset.boothId);
            if (item != null && item.thumbnail.Length > 0)
            {
                var booth = AssetStore.Thumbnail(item.thumbnail, repaint);
                if (booth) return booth;
            }
            if (firstPrefabsVersion != ProjectVersion)
            {
                FirstPrefabs.Clear();
                firstPrefabsVersion = ProjectVersion;
            }
            if (!FirstPrefabs.TryGetValue(asset.id, out var prefab))
                FirstPrefabs[asset.id] = prefab = AssetFolders.Prefabs(asset).OrderBy(p => AssetDatabase.GetAssetPath(p).Count(c => c == '/')).FirstOrDefault();
            if (!prefab) return null;
            var preview = AssetPreview.GetAssetPreview(prefab);
            if (!preview && AssetPreview.IsLoadingAssetPreview(prefab.GetInstanceID())) repaint?.Invoke();
            return preview ? preview : AssetPreview.GetMiniThumbnail(prefab);
        }
    }
}
