using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;
using static NXYUI.AssetManager.AssetGui;

namespace NXYUI.AssetManager
{
    // The ‘Booth 연결’ window: unlinked assets one after another, each with its Booth candidates, to link, put off, or
    // mark as not sold on Booth. Booth is asked for the asset on screen and the next two only. Nothing links by itself:
    // the recommended candidate is only chosen in advance. A floating utility window, not modal, so Booth's answers
    // arrive and the Project window can be checked meanwhile.
    // Look: design-system/unityvpm/pages/asset-manager.md ("Booth link wizard"), Editor/AssetManager.uss.
    internal sealed class BoothLinkWizard : EditorWindow
    {
        private const string StylePath = "Packages/dev.nxyui.asset-manager/Editor/AssetManager.uss";
        private const int ShownCandidates = 6, Ahead = 2;

        [SerializeField] private List<string> queue = new List<string>();
        [SerializeField] private int index;
        // The candidate chosen for the asset on screen, and whether the user chose it (else the recommended one).
        [SerializeField] private long chosen;
        [SerializeField] private string chosenFor;
        [SerializeField] private bool userChose;
        [SerializeField] private string query = "", address = "";
        [NonSerialized] private string queryFor, message;
        [NonSerialized] private bool messageWarn;
        // The asset whose link by address is on its way: the window waits on it (nothing else links or moves meanwhile).
        [NonSerialized] private string linkingFor;
        // Enter links once per press: a held key's repeats would link the next asset's recommendation too.
        [NonSerialized] private bool enterArmed = true;
        // The candidate rows as drawn, so keys and clicks act on what is on screen.
        private readonly List<(long Id, VisualElement Row)> rows = new List<(long, VisualElement)>();
        // Searches this window started, to stop the ones it has moved past.
        private readonly HashSet<string> asked = new HashSet<string>();

        private VisualElement root, head, body, foot;
        private ScrollView scroll;
        private IVisualElementScheduledItem buildItem;

        internal static void Open(IEnumerable<string> assetIds)
        {
            var window = GetWindow<BoothLinkWizard>(true, "Booth 연결", true);
            window.queue = (assetIds ?? Enumerable.Empty<string>()).Distinct().ToList();
            window.index = 0;
            window.chosenFor = null;
            window.message = null;
            window.minSize = new Vector2(480, 520);
            var main = EditorGUIUtility.GetMainWindowPosition();
            window.position = new Rect(main.center.x - 280, main.center.y - 330, 560, 660);
            window.SkipDone();
            window.Build();
        }

        // Every unlinked asset that is sold on Booth, by name.
        internal static List<string> Unlinked() => AssetStore.Project.assets.Where(a => a.boothId == 0 && !a.noBooth)
            .OrderBy(a => a.name, StringComparer.CurrentCultureIgnoreCase).Select(a => a.id).ToList();

        private void OnEnable()
        {
            BoothLinker.Updated += ScheduleBuild;
            AssetStore.Changed += ScheduleBuild;
            AssetStore.ThumbnailsChanged += ScheduleBuild;
        }

        private void OnDisable()
        {
            foreach (var owner in asked) BoothLinker.Cancel(owner);
            asked.Clear();
            BoothLinker.Front = null;
            BoothLinker.Updated -= ScheduleBuild;
            AssetStore.Changed -= ScheduleBuild;
            AssetStore.ThumbnailsChanged -= ScheduleBuild;
        }

        private void CreateGUI()
        {
            root = rootVisualElement;
            root.Clear();
            root.AddToClassList("am-root");
            root.AddToClassList(EditorGUIUtility.isProSkin ? "am-dark" : "am-light");
            var style = AssetDatabase.LoadAssetAtPath<StyleSheet>(StylePath);
            if (style) root.styleSheets.Add(style);
            root.focusable = true;
            root.RegisterCallback<KeyDownEvent>(OnKey, TrickleDown.TrickleDown);
            root.RegisterCallback<KeyUpEvent>(e =>
            {
                if (e.keyCode == KeyCode.Return || e.keyCode == KeyCode.KeypadEnter) enterArmed = true;
            }, TrickleDown.TrickleDown);
            root.RegisterCallback<PointerDownEvent>(_ => enterArmed = true, TrickleDown.TrickleDown);
            head = new VisualElement();
            head.AddToClassList("am-wizard-head");
            root.Add(head);
            scroll = new ScrollView();
            scroll.AddToClassList("am-grow");
            body = new VisualElement();
            body.AddToClassList("am-wizard-body");
            scroll.Add(body);
            root.Add(scroll);
            foot = new VisualElement();
            foot.AddToClassList("am-wizard-foot");
            root.Add(foot);
            Build();
        }

        private AssetRecord Current => index >= 0 && index < queue.Count ? AssetStore.AssetById(queue[index]) : null;

        private static bool Done(AssetRecord asset) => asset == null || asset.boothId > 0 || asset.noBooth;

        // Going on passes over assets that were linked or marked meanwhile (in another window, or on the way back).
        private void SkipDone()
        {
            while (index < queue.Count && Done(Current)) index++;
        }

        // Booth's answers and new pictures rebuild the page once, after the notices settle, and not while the user types.
        private void ScheduleBuild()
        {
            if (root == null) return;
            buildItem?.Pause();
            buildItem = root.schedule.Execute(() =>
            {
                if (Typing()) buildItem = root.schedule.Execute(ScheduleBuild).StartingIn(800);
                else Build();
            });
        }

        private bool buildQueued;

        // A prefab preview still loading asks again a little later (AssetPreview has no notice of its own).
        private void BuildSoon()
        {
            if (buildQueued || root == null) return;
            buildQueued = true;
            root.schedule.Execute(() =>
            {
                buildQueued = false;
                ScheduleBuild();
            }).StartingIn(300);
        }

        private bool Typing() => root?.panel?.focusController?.focusedElement is VisualElement focused &&
                                 (focused is TextField || focused.GetFirstAncestorOfType<TextField>() != null);

        private void Build()
        {
            if (root == null || body == null) return;
            var offset = scroll.scrollOffset;
            head.Clear();
            body.Clear();
            foot.Clear();
            rows.Clear();
            // An asset removed meanwhile (also one restored after a reload) is passed over, not taken for the end.
            while (index < queue.Count && AssetStore.AssetById(queue[index]) == null) index++;
            var asset = Current;
            if (asset == null)
            {
                Summary();
                KeepKeys();
                return;
            }
            Ask();
            Head();
            AssetBlock(asset);
            Candidates(asset);
            SearchRows(asset);
            Foot(asset);
            if (asset.id == chosenFor) scroll.scrollOffset = offset;
            KeepKeys();
        }

        // The shortcuts need the focus inside this window: after a rebuild, or on opening, it goes to the window itself.
        private void KeepKeys()
        {
            var focused = root.panel?.focusController?.focusedElement as VisualElement;
            if (focused == null || focused.panel == null || !root.Contains(focused)) root.Focus();
        }

        // The asset on screen and the next two: Booth is asked for them now, the rest when they come up.
        private void Ask()
        {
            // The asset on screen is the one the user waits for: its requests go out before other automatic ones.
            BoothLinker.Front = index >= 0 && index < queue.Count ? queue[index] : null;
            // Searches this window started for assets now out of reach stop where they are.
            var reach = new HashSet<string>(queue.Skip(index).Take(1 + Ahead));
            foreach (var owner in asked.Where(o => !reach.Contains(o)).ToList())
            {
                BoothLinker.Cancel(owner);
                asked.Remove(owner);
            }
            for (var i = index; i < Math.Min(queue.Count, index + 1 + Ahead); i++)
            {
                // The next ones only once the one on screen has its answer, so going on quickly never queues the whole list.
                if (i > index && (BoothLinker.IsSearching(queue[index]) || BoothLinker.NeedsSearch(AssetStore.SearchFor(queue[index])))) break;
                var asset = AssetStore.AssetById(queue[i]);
                if (asset == null || asset.boothId > 0 || asset.noBooth) continue;
                if (!BoothLinker.NeedsSearch(AssetStore.SearchFor(asset.id)) || BoothLinker.IsSearching(asset.id)) continue;
                BoothLinker.SearchSoon(asset.id, asset.name, AssetFolders.ExistingFolders(asset), asset.package);
                asked.Add(asset.id);
            }
        }

        private void Head()
        {
            var top = new VisualElement();
            top.AddToClassList("am-wizard-top");
            top.Add(UiText("Booth 연결", "am-wizard-title"));
            top.Add(UiText($"{index + 1} / {queue.Count}", "am-count"));
            head.Add(top);
            var track = new VisualElement();
            track.AddToClassList("am-progress");
            var fill = new VisualElement();
            fill.AddToClassList("am-progress-fill");
            fill.style.width = Length.Percent(queue.Count == 0 ? 0 : 100f * index / queue.Count);
            track.Add(fill);
            head.Add(track);
        }

        private void AssetBlock(AssetRecord asset)
        {
            var row = new VisualElement();
            row.AddToClassList("am-detail-top");
            var image = new VisualElement();
            image.AddToClassList("am-detail-image");
            var texture = AssetTexture(asset, BuildSoon) as Texture2D;
            if (texture) image.style.backgroundImage = new StyleBackground(texture);
            else image.Add(UiText(KindName(asset.kind), "am-card-placeholder"));
            row.Add(image);
            var facts = new VisualElement();
            facts.AddToClassList("am-detail-facts");
            facts.Add(Tip(UiText(asset.name, "am-detail-title"), asset.name));
            var folder = AssetFolders.ExistingFolders(asset).FirstOrDefault() ?? "폴더를 찾지 못했어요";
            facts.Add(Tip(UiText(folder, "am-detail-meta"), folder));
            if (asset.package.Length > 0) facts.Add(Tip(UiText("패키지: " + asset.package, "am-detail-meta"), asset.package));
            var chips = new VisualElement();
            chips.AddToClassList("am-chips");
            chips.Add(UiChip(KindName(asset.kind), ""));
            facts.Add(chips);
            var actions = new VisualElement();
            actions.AddToClassList("am-actions");
            actions.Add(UiButton("폴더 보기", "am-button--quiet", () =>
            {
                var path = AssetFolders.ExistingFolders(asset).FirstOrDefault();
                if (path == null) return;
                var target = AssetDatabase.LoadAssetAtPath<DefaultAsset>(path);
                Selection.activeObject = target;
                EditorGUIUtility.PingObject(target);
            }, "Project 창에서 이 에셋의 폴더를 골라 보여 줘요."));
            facts.Add(actions);
            row.Add(facts);
            body.Add(row);
        }

        private List<BoothItem> Shown(SearchCache cache) => cache?.results.Take(ShownCandidates).ToList() ?? new List<BoothItem>();

        private void Candidates(AssetRecord asset)
        {
            var cache = AssetStore.SearchFor(asset.id);
            var searching = BoothLinker.NeedsSearch(cache) || BoothLinker.IsSearching(asset.id);
            var shown = Shown(cache);
            // A new asset starts on its recommended candidate, also when the answer arrives after it came up.
            if (chosenFor != asset.id)
            {
                chosenFor = asset.id;
                chosen = 0;
                userChose = false;
                query = cache?.query.Length > 0 ? cache.query : BoothClient.QueryFrom(asset.name);
                address = "";
                message = null;
            }
            if (!userChose && !searching) chosen = shown.Any(c => c.id == cache.recommended) ? cache.recommended : 0;
            if (chosen != 0 && shown.All(c => c.id != chosen)) chosen = 0;

            var section = UiSection("Booth 후보");
            if (asset.boothId > 0)
            {
                var item = AssetStore.Item(asset.boothId);
                section.Add(UiNote($"‘{(item?.name.Length > 0 ? item.name : asset.boothName)}’에 연결했어요. 다른 후보를 고르고 연결하면 바뀌어요.", false));
            }
            if (searching) section.Add(UiNote("Booth에서 찾고 있어요…", false));
            else if (cache.error.Length > 0)
            {
                section.Add(UiNote("검색하지 못했어요: " + cache.error, true));
                var again = new VisualElement();
                again.AddToClassList("am-actions");
                var retry = UiButton("다시 찾기", "", () => SearchNow(asset), "아래 검색어로 한 번 더 찾아요.");
                retry.SetEnabled(!string.IsNullOrWhiteSpace(query));
                again.Add(retry);
                section.Add(again);
            }
            else if (cache.results.Count == 0) section.Add(UiNote($"‘{cache.query}’(으)로 찾은 상품이 없어요. 검색어를 바꾸거나 상품·샵 주소를 넣으세요.", false));
            if (!searching && cache.shop.Length > 0) section.Add(UiText($"‘{cache.shop}’ 샵의 상품에서도 찾았어요.", "am-text"));
            if (!searching && cache.adultHidden > 0)
                section.Add(UiText($"연령 확인이 필요한 상품 {cache.adultHidden}개는 보여 주지 않아요. 그중 하나라면 상품 주소로 연결하세요.", "am-text"));
            for (var i = 0; i < shown.Count; i++) section.Add(CandidateRow(asset, cache, shown[i], i + 1));
            if (cache != null && cache.results.Count > ShownCandidates)
                section.Add(UiText($"후보 {cache.results.Count - ShownCandidates}개가 더 있어요. 아래에서 검색어를 좁혀 보세요.", "am-text"));
            body.Add(section);
        }

        private VisualElement CandidateRow(AssetRecord asset, SearchCache cache, BoothItem candidate, int number)
        {
            var row = new VisualElement();
            row.AddToClassList("am-wizard-row");
            row.EnableInClassList("am-wizard-row--on", candidate.id == chosen);
            row.Add(UiText(number.ToString(), "am-wizard-number"));
            var thumb = new VisualElement();
            thumb.AddToClassList("am-candidate-image");
            var picture = AssetStore.Thumbnail(candidate.thumbnail, ScheduleBuild);
            if (picture) thumb.style.backgroundImage = new StyleBackground(picture);
            row.Add(thumb);
            var text = new VisualElement();
            text.AddToClassList("am-candidate-text");
            text.Add(Tip(UiText(candidate.name, "am-candidate-name"), candidate.name));
            var line = new VisualElement();
            line.AddToClassList("am-candidate-line");
            // The chosen row says so in words too, not only by its colour.
            var picked = UiChip("고름", "am-chip--accent");
            picked.AddToClassList("am-wizard-picked");
            picked.EnableInClassList("am-hidden", candidate.id != chosen);
            line.Add(picked);
            if (candidate.id == cache.recommended) line.Add(Tip(UiChip("추천", "am-chip--ok"), "가장 맞아 보이는 후보예요. 연결은 직접 눌러야 해요."));
            var source = candidate.id == cache.readmeItem ? "설명서 링크"
                : AssetStore.HintFor(asset.package) == candidate.id || AssetStore.HintFor(asset.name) == candidate.id ? "이전 연결"
                : cache.shopItems.Contains(candidate.id) ? "같은 샵" : "";
            if (source.Length > 0) line.Add(UiChip(source, "am-chip--accent"));
            line.Add(Tip(UiText(candidate.shop, "am-candidate-shop"), candidate.shop));
            text.Add(line);
            row.Add(text);
            row.Add(UiButton("보기", "am-button--quiet", () => Application.OpenURL(candidate.Url), "브라우저에서 상품 페이지를 열어 확인해요."));
            row.tooltip = $"{number}번: 누르면 고르고, 두 번 누르면 연결해요.";
            // The row is not drawn again on a click, so a double click reaches it as one.
            row.RegisterCallback<ClickEvent>(e =>
            {
                if (e.target is Button) return;
                Choose(candidate.id);
                if (e.clickCount == 2) Link();
            });
            rows.Add((candidate.id, row));
            return row;
        }

        private void SearchRows(AssetRecord asset)
        {
            var section = UiSection("직접 찾기");
            var searchRow = new VisualElement();
            searchRow.AddToClassList("am-inline");
            var field = new TextField("검색어") { value = query, tooltip = "Booth의 3D모델 카테고리에서 찾아요." };
            field.AddToClassList("am-field");
            field.AddToClassList("am-grow");
            field.RegisterValueChangedCallback(e => query = e.newValue ?? "");
            OnEnter(field, () =>
            {
                // Enter held down must not go on to link a candidate once the rebuilt page has the focus: it has to be
                // let go first.
                enterArmed = false;
                SearchNow(asset);
            });
            searchRow.Add(field);
            searchRow.Add(UiButton("검색", "", () => SearchNow(asset), "이 검색어로 Booth를 다시 찾아요 (입력란에서 Enter)."));
            section.Add(searchRow);
            var linkRow = new VisualElement();
            linkRow.AddToClassList("am-inline");
            var addressField = new TextField("주소") { value = address, tooltip = "booth.pm 상품 주소나 상품 번호, 또는 샵 주소(샵이름.booth.pm)" };
            addressField.AddToClassList("am-field");
            addressField.AddToClassList("am-grow");
            addressField.RegisterValueChangedCallback(e => address = e.newValue ?? "");
            OnEnter(addressField, () =>
            {
                enterArmed = false;
                if (linkingFor == null) UseAddress(asset);
            });
            linkRow.Add(addressField);
            var byAddress = UiButton("주소로", "", () => UseAddress(asset), "상품 주소면 연결하고 다음으로, 샵 주소면 그 샵의 상품을 후보로 보여 줘요.");
            // While Booth answers for one address, a second press would link twice; the reason is the message below.
            byAddress.SetEnabled(linkingFor == null && !BoothLinker.IsLinking(asset.id));
            linkRow.Add(byAddress);
            section.Add(linkRow);
            if (!string.IsNullOrEmpty(message)) section.Add(UiNote(message, messageWarn));
            body.Add(section);
            body.Add(UiText("1–6 또는 ↑↓ 고르기 · Enter 연결 · → 나중에 · ← 이전 · Esc 닫기", "am-wizard-keys"));
        }

        private void SearchNow(AssetRecord asset)
        {
            if (string.IsNullOrWhiteSpace(query)) return;
            userChose = false;
            BoothLinker.Search(asset.id, query.Trim(), AssetFolders.ExistingFolders(asset), new[] { asset.package, asset.name }, false);
            Build();
        }

        private void UseAddress(AssetRecord asset)
        {
            var id = BoothClient.ParseItemId(address);
            var shop = id <= 0 ? BoothClient.ShopFromUrl(address) : null;
            if (shop != null)
            {
                message = $"‘{shop}’ 샵의 상품을 후보로 보여 줘요.";
                messageWarn = false;
                userChose = false;
                BoothLinker.SearchShop(asset, shop);
                Build();
                return;
            }
            if (id <= 0)
            {
                message = "Booth 상품 주소나 번호, 또는 샵 주소를 넣으세요.";
                messageWarn = true;
                Build();
                return;
            }
            // The window waits for the link: going on first would count the asset as put off, and a late answer could
            // replace a link made meanwhile.
            linkingFor = asset.id;
            message = "상품 정보를 받고 있어요…";
            messageWarn = false;
            Build();
            if (BoothLinker.LinkById(asset, id, error =>
                {
                    linkingFor = null;
                    // Linked even without Booth's details (an age-restricted product): said in the log, then on.
                    if (error != null) Debug.Log($"[Asset Manager] ‘{asset.name}’을(를) 상품 {id}에 번호로만 연결했어요: {error}");
                    if (Current?.id == asset.id) Next();
                    else Build();
                })) return;
            // Asked from the main window already: this window does not wait for an answer that is not coming to it.
            linkingFor = null;
            message = BoothLinker.LinkBusy;
            messageWarn = true;
            Build();
        }

        private void Foot(AssetRecord asset)
        {
            foot.Clear();
            var waiting = linkingFor != null;
            var back = UiButton("← 이전", "am-button--quiet", Previous, "앞 에셋으로 돌아가요 (←).");
            back.SetEnabled(index > 0 && !waiting);
            foot.Add(back);
            var notBooth = UiButton("Booth 상품 아님", "am-button--quiet", () => NotOnBooth(asset),
                asset.boothId > 0 ? "이미 Booth 상품과 연결한 에셋이에요." : "GitHub 도구나 직접 만든 것처럼 Booth에서 산 것이 아니에요. 다시 묻지 않아요(상세에서 되돌릴 수 있어요).");
            notBooth.SetEnabled(asset.boothId == 0 && !waiting);
            foot.Add(notBooth);
            var later = UiButton("나중에", "", Later, "연결하지 않고 다음으로 가요 (→ 또는 N). 다음에 이 창을 열면 다시 나와요.");
            later.SetEnabled(!waiting);
            foot.Add(later);
            foot.Add(Spacer());
            var target = Chosen(asset);
            if (waiting) foot.Add(UiText("상품 정보를 받는 중이에요…", "am-wizard-reason"));
            else if (target == null) foot.Add(UiText("후보를 고르면 연결할 수 있어요.", "am-wizard-reason"));
            var link = UiButton("연결", "am-button--primary", Link, target != null ? $"‘{target.name}’에 연결하고 다음으로 가요 (Enter)." : null);
            link.SetEnabled(target != null && !waiting);
            foot.Add(link);
        }

        // The chosen candidate among the rows on screen.
        private BoothItem Chosen(AssetRecord asset) =>
            rows.Any(r => r.Id == chosen) ? Shown(AssetStore.SearchFor(asset.id)).FirstOrDefault(c => c.id == chosen) : null;

        private void Summary()
        {
            var assets = queue.Select(AssetStore.AssetById).Where(a => a != null).ToList();
            var linked = assets.Count(a => a.boothId > 0);
            var notBooth = assets.Count(a => a.noBooth && a.boothId == 0);
            var later = assets.Count - linked - notBooth;
            var top = new VisualElement();
            top.AddToClassList("am-wizard-top");
            top.Add(UiText("Booth 연결", "am-wizard-title"));
            head.Add(top);
            body.Add(UiEmpty(queue.Count == 0 ? "연결할 에셋이 없어요" : "끝났어요",
                queue.Count == 0 ? "Booth와 연결하지 않은 에셋이 없어요." : $"연결 {linked}개 · 나중에 {later}개 · Booth 상품 아님 {notBooth}개"));
            foot.Add(Spacer());
            if (later > 0)
                foot.Add(UiButton($"남은 {later}개 다시 보기", "", () =>
                {
                    queue = assets.Where(a => !Done(a)).Select(a => a.id).ToList();
                    index = 0;
                    chosenFor = null;
                    Build();
                }, "나중에로 넘긴 에셋을 처음부터 다시 봐요."));
            var first = assets.FirstOrDefault(a => a.boothId > 0);
            if (first != null)
                foot.Add(UiButton("연결한 에셋 보기", "", () =>
                {
                    AssetManagerWindow.ShowAsset(first);
                    Close();
                }, "에셋 탭에서 연결한 에셋을 열어요. 거기서 아바타에 조립할 수 있어요."));
            foot.Add(UiButton("닫기", "am-button--primary", Close));
        }

        // ---- moves ----

        private void Link()
        {
            var asset = Current;
            if (asset == null || linkingFor != null) return;
            var target = Chosen(asset);
            if (target == null) return;
            BoothLinker.Link(asset, target);
            Next();
        }

        private void Later()
        {
            if (linkingFor == null) Next();
        }

        private void NotOnBooth(AssetRecord asset)
        {
            if (linkingFor != null || asset.boothId > 0) return;
            asset.noBooth = true;
            AssetStore.SaveProject();
            Next();
        }

        private void Next()
        {
            index++;
            SkipDone();
            chosenFor = null;
            Build();
            root?.Focus();
        }

        private void Previous()
        {
            if (index <= 0 || linkingFor != null) return;
            index--;
            chosenFor = null;
            Build();
            root?.Focus();
        }

        // Keys go to a text field while it has the focus, and Enter or Space to a focused button.
        private void OnKey(KeyDownEvent e)
        {
            if (Typing()) return;
            var focused = root.panel?.focusController?.focusedElement as VisualElement;
            if (focused is Button && (e.keyCode == KeyCode.Return || e.keyCode == KeyCode.KeypadEnter || e.keyCode == KeyCode.Space)) return;
            if (e.keyCode == KeyCode.Escape)
            {
                Close();
                Handled(e);
                return;
            }
            var asset = Current;
            if (asset == null) return;
            var shown = rows.Select(r => r.Id).ToList();
            var at = shown.IndexOf(chosen);
            int digit = e.keyCode >= KeyCode.Alpha1 && e.keyCode <= KeyCode.Alpha6 ? e.keyCode - KeyCode.Alpha1
                : e.keyCode >= KeyCode.Keypad1 && e.keyCode <= KeyCode.Keypad6 ? e.keyCode - KeyCode.Keypad1 : -1;
            if (digit >= 0)
            {
                if (digit < shown.Count) Choose(shown[digit]);
            }
            else if (e.keyCode == KeyCode.DownArrow || e.keyCode == KeyCode.UpArrow)
            {
                if (shown.Count == 0) return;
                var step = e.keyCode == KeyCode.DownArrow ? 1 : -1;
                Choose(shown[Mathf.Clamp(at < 0 ? 0 : at + step, 0, shown.Count - 1)]);
            }
            else if (e.keyCode == KeyCode.Return || e.keyCode == KeyCode.KeypadEnter)
            {
                if (enterArmed)
                {
                    enterArmed = false;
                    Link();
                }
            }
            else if (e.keyCode == KeyCode.RightArrow || e.keyCode == KeyCode.N) Later();
            else if (e.keyCode == KeyCode.LeftArrow) Previous();
            else return;
            Handled(e);
        }

        private void Choose(long id)
        {
            chosen = id;
            userChose = true;
            foreach (var (rowId, row) in rows)
            {
                row.EnableInClassList("am-wizard-row--on", rowId == id);
                row.Q(className: "am-wizard-picked")?.EnableInClassList("am-hidden", rowId != id);
            }
            if (Current != null) Foot(Current);
        }

        private static void Handled(KeyDownEvent e)
        {
            e.StopImmediatePropagation();
            e.PreventDefault();
        }

        // ---- small builders (the main window's look) ----

        // Enter in a one-line field does what the button beside it does. Not while an input method is composing
        // (Korean, Japanese): there Enter only confirms the letters.
        private static void OnEnter(TextField field, Action action) =>
            field.RegisterCallback<KeyDownEvent>(e =>
            {
                if (e.keyCode != KeyCode.Return && e.keyCode != KeyCode.KeypadEnter || Input.compositionString.Length > 0) return;
                e.StopPropagation();
                action();
            }, TrickleDown.TrickleDown);

        private static Label UiText(string text, string kind)
        {
            // Names from Booth and from files are shown as written: a name must not be able to style itself as a chip
            // or a warning through rich text tags.
            var label = new Label(text) { enableRichText = false };
            label.AddToClassList(kind);
            return label;
        }

        private static Label UiChip(string text, string kind)
        {
            var chip = new Label(text) { enableRichText = false };
            chip.AddToClassList("am-chip");
            if (kind.Length > 0) chip.AddToClassList(kind);
            return chip;
        }

        private static VisualElement UiSection(string title)
        {
            var section = new VisualElement();
            section.AddToClassList("am-section");
            section.Add(UiText(title, "am-section-title"));
            return section;
        }

        private static VisualElement UiNote(string text, bool warn)
        {
            var note = UiText(text, "am-note");
            note.EnableInClassList("am-note--warn", warn);
            return note;
        }

        private static Button UiButton(string text, string kind, Action click, string tooltip = null)
        {
            var button = new Button(click) { text = text, tooltip = tooltip, enableRichText = false };
            button.AddToClassList("am-button");
            if (kind.Length > 0) button.AddToClassList(kind);
            return button;
        }

        private static VisualElement UiEmpty(string title, string body)
        {
            var empty = new VisualElement();
            empty.AddToClassList("am-empty");
            empty.Add(UiText(title, "am-empty-title"));
            empty.Add(UiText(body, "am-empty-body"));
            return empty;
        }

        private static VisualElement Spacer()
        {
            var spacer = new VisualElement();
            spacer.AddToClassList("am-grow");
            return spacer;
        }

        private static T Tip<T>(T element, string tooltip) where T : VisualElement
        {
            element.tooltip = tooltip;
            return element;
        }
    }
}
