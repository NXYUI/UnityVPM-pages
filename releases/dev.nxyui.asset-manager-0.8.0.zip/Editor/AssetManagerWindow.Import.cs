using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;

namespace NXYUI.AssetManager
{
    // The 가져오기 tab (UI Toolkit): packages found in a folder (also inside zip archives) on the left, the chosen ones in
    // import order and the running queue on the right. Nothing is imported before the 임포트 button.
    // Look: design-system/unityvpm/pages/asset-manager.md ("Import tab").
    internal sealed partial class AssetManagerWindow
    {
        private sealed class ScanRow
        {
            public string Name = "";
            public long Size;
            public int Depth;
            public ImportSource Source;          // a package (file or archive entry)
            public string Zip;                   // an archive on disk
            public string NestedEntry;           // an archive inside Zip
            public bool Expanded;
            public Task<ZipListing> Listing;
            public List<ScanRow> Children;
            public bool Vpm;
            public string Error;
            public bool IsArchive => Source == null;
        }

        // One line of the found-packages list: a package or an archive, or a note under an open archive.
        private sealed class ScanLine
        {
            public ScanRow Row;
            public string Note;
            public int Depth;
        }

        private sealed class PreCheck
        {
            public Task<List<PackageEntry>> Reading;
            public string Error;
            public bool Ready;
            // The source file when the check was made (ImportQueue.StampOf): a file replaced since is checked again.
            public string Stamp = "";
            public List<string> Folders = new List<string>();
            public List<string> NewFolders = new List<string>();
            public bool Scripts, Shaders;
            public List<string> Overwrites = new List<string>();
            public List<string> PackageOverwrites = new List<string>();
            public HashSet<string> Files = new HashSet<string>();
        }

        private const float ScanLineHeight = 30;

        private List<ScanRow> scanRows;
        private string scanStatus;
        private readonly List<ImportSource> importOrder = new List<ImportSource>();
        private readonly HashSet<string> interactiveKeys = new HashSet<string>();
        private readonly Dictionary<string, PreCheck> preChecks = new Dictionary<string, PreCheck>();
        private readonly HashSet<string> openOverwrites = new HashSet<string>();
        private bool orderTouched;

        private readonly List<ScanLine> scanLines = new List<ScanLine>();
        private ListView scanList;
        private VisualElement scanNote, scanFooter, orderPane, orderTop, orderBody;
        private ScrollView orderScroll;
        private Label scanCount, orderCount, barNote;
        private Button readButton, pickAll, clearAll;
        private IVisualElementScheduledItem stateSave, importItem;
        private Vector2 orderScrollKept, scanScrollKept;

        // Background work still running; the editor loop looks only at these, not at every row.
        private readonly List<PreCheck> pendingChecks = new List<PreCheck>();
        private readonly List<ScanRow> pendingListings = new List<ScanRow>();

        // Background work (archive listings, package checks) finishes off the main thread; the page follows once.
        private void TickImportTab()
        {
            if (pendingChecks.Count == 0 && pendingListings.Count == 0) return;
            var changed = false;
            for (var i = pendingChecks.Count - 1; i >= 0; i--)
            {
                if (!pendingChecks[i].Reading.IsCompleted) continue;
                Complete(pendingChecks[i]);
                pendingChecks.RemoveAt(i);
                changed = true;
            }
            for (var i = pendingListings.Count - 1; i >= 0; i--)
            {
                if (!pendingListings[i].Listing.IsCompleted) continue;
                Expand(pendingListings[i]);
                pendingListings.RemoveAt(i);
                changed = true;
            }
            if (!changed) return;
            if (!orderTouched) SortOrder();
            if (tab == 1) ScheduleImportRefresh();
        }

        // Checks that finish one after another rebuild the order once, not once each.
        private void ScheduleImportRefresh()
        {
            if (scanList == null || root == null) return;
            importItem?.Pause();
            importItem = root.schedule.Execute(RefreshImportPage).StartingIn(100);
        }

        private void BuildImportPage(VisualElement into)
        {
            var state = AssetStore.State;
            var column = new VisualElement();
            column.AddToClassList("am-import");

            // The folder bar is built once per page; typing in it never rebuilds it.
            var bar = new VisualElement();
            bar.AddToClassList("am-import-bar");
            var folderField = new TextField("패키지 폴더") { value = state.lastImportFolder, tooltip = "패키지(.unitypackage, .zip)가 든 폴더" };
            folderField.AddToClassList("am-field");
            folderField.AddToClassList("am-grow");
            folderField.RegisterValueChangedCallback(e =>
            {
                state.lastImportFolder = e.newValue ?? "";
                UpdateReadButton();
                SaveStateSoon();
            });
            bar.Add(folderField);
            bar.Add(UiButton("찾아보기…", "am-button--quiet", () =>
            {
                var picked = EditorUtility.OpenFolderPanel("패키지가 든 폴더 고르기", state.lastImportFolder, "");
                if (string.IsNullOrEmpty(picked)) return;
                folderField.value = picked;
                AssetStore.SaveState();
            }));
            var recursive = new Toggle { text = "하위 폴더 포함", value = state.importRecursive, tooltip = "안쪽 폴더의 패키지도 찾아요." };
            recursive.AddToClassList("am-toggle");
            recursive.RegisterValueChangedCallback(e =>
            {
                state.importRecursive = e.newValue;
                AssetStore.SaveState();
            });
            bar.Add(recursive);
            readButton = UiButton("폴더 읽기", "am-button--primary", () =>
            {
                Scan(state.lastImportFolder, state.importRecursive);
                RefreshImportPage();
            });
            bar.Add(readButton);
            column.Add(bar);
            barNote = UiText("", "am-bar-note");
            column.Add(barNote);

            var panes = new VisualElement();
            panes.AddToClassList("am-panes");

            var left = Pane("찾은 패키지", "am-pane--left", out scanCount);
            scanNote = new VisualElement();
            left.Add(scanNote);
            // Single selection is the keyboard cursor: ↑ ↓ move it, Space or Enter picks the package, → ← open and close
            // an archive. A click picks as well.
            scanList = new ListView
            {
                makeItem = MakeScanLine,
                bindItem = BindScanLine,
                itemsSource = scanLines,
                fixedItemHeight = ScanLineHeight,
                selectionType = SelectionType.Single,
                virtualizationMethod = CollectionVirtualizationMethod.FixedHeight,
                tooltip = "방향키로 옮기고 Space로 골라요. →와 ←로 압축 파일을 펼치고 접어요.",
            };
            scanList.AddToClassList("am-list");
            scanList.AddToClassList("am-scan-list");
            scanList.RegisterCallback<KeyDownEvent>(OnScanKey, TrickleDown.TrickleDown);
            left.Add(scanList);
            scanFooter = new VisualElement();
            scanFooter.AddToClassList("am-actions");
            pickAll = UiButton("", "", () =>
            {
                foreach (var line in scanLines.Where(l => l.Row?.Source != null).ToList()) Choose(line.Row.Source, true);
                if (!orderTouched) SortOrder();
                RefreshImportPage();
            });
            clearAll = UiButton("고른 것 모두 풀기", "am-button--quiet", () =>
            {
                importOrder.Clear();
                orderTouched = false;
                RefreshImportPage();
            });
            scanFooter.Add(pickAll);
            scanFooter.Add(clearAll);
            left.Add(scanFooter);
            panes.Add(left);

            var right = Pane("가져올 순서", "am-pane--right", out orderCount);
            orderPane = right;
            orderTop = new VisualElement();
            orderTop.AddToClassList("am-order-top");
            right.Add(orderTop);
            orderScroll = new ScrollView();
            orderScroll.AddToClassList("am-grow");
            orderBody = new VisualElement();
            orderScroll.Add(orderBody);
            right.Add(orderScroll);
            panes.Add(right);

            column.Add(panes);
            into.Add(column);
            UpdateReadButton();
            RefreshImportPage();
            // Back on the tab, both lists are where the user left them.
            KeepScroll(orderScroll, orderScrollKept);
            KeepScroll(scanList.Q<ScrollView>(), scanScrollKept);
        }

        private void RememberImportScrolls()
        {
            if (scanList == null) return;
            orderScrollKept = orderScroll.scrollOffset;
            scanScrollKept = scanList.Q<ScrollView>()?.scrollOffset ?? Vector2.zero;
        }

        private void OnScanKey(KeyDownEvent e)
        {
            var index = scanList.selectedIndex;
            if (index < 0 || index >= scanLines.Count || scanLines[index].Row == null) return;
            var row = scanLines[index].Row;
            switch (e.keyCode)
            {
                case KeyCode.Space:
                case KeyCode.Return:
                case KeyCode.KeypadEnter:
                case KeyCode.RightArrow when row.IsArchive && !row.Expanded:
                case KeyCode.LeftArrow when row.IsArchive && row.Expanded:
                    ToggleLine(row);
                    break;
                default:
                    return;
            }
            e.StopImmediatePropagation();
            e.PreventDefault();
        }

        private static VisualElement Pane(string title, string side, out Label count)
        {
            var pane = new VisualElement();
            pane.AddToClassList("am-pane");
            pane.AddToClassList(side);
            var head = new VisualElement();
            head.AddToClassList("am-pane-head");
            head.Add(UiText(title, "am-pane-title"));
            count = UiText("", "am-count");
            head.Add(count);
            pane.Add(head);
            return pane;
        }

        private void UpdateReadButton()
        {
            if (readButton == null) return;
            var folder = AssetStore.State.lastImportFolder;
            var exists = folder.Length > 0 && Directory.Exists(folder);
            readButton.SetEnabled(exists);
            readButton.tooltip = exists ? "이 폴더의 패키지를 찾아요." : "있는 폴더를 고르세요.";
            // A disabled button shows no tooltip, so the reason is also written under the bar.
            barNote.text = exists ? "" : folder.Length == 0
                ? "패키지가 든 폴더를 적거나 ‘찾아보기…’로 고르면 ‘폴더 읽기’를 누를 수 있어요."
                : "이 폴더를 찾지 못했어요. 주소를 확인하거나 ‘찾아보기…’로 고르세요.";
            barNote.EnableInClassList("am-bar-note--warn", folder.Length > 0);
            barNote.EnableInClassList("am-hidden", exists);
        }

        // The typed folder is saved once typing pauses.
        private void SaveStateSoon()
        {
            if (root == null) return;
            stateSave?.Pause();
            stateSave = root.schedule.Execute(() => AssetStore.SaveState()).StartingIn(600);
        }

        private void RefreshImportPage()
        {
            if (scanList == null) return;

            scanLines.Clear();
            if (scanRows != null) Flatten(scanRows);
            scanNote.Clear();
            if (scanRows == null) scanNote.Add(UiNote("패키지가 든 폴더를 고르고 ‘폴더 읽기’를 누르세요. 압축 파일은 펼치면 안의 패키지를 보여 줘요.", false));
            else if (scanStatus != null) scanNote.Add(UiNote(scanStatus, false));
            scanNote.EnableInClassList("am-hidden", scanNote.childCount == 0);
            scanList.EnableInClassList("am-hidden", scanLines.Count == 0);
            scanList.RefreshItems();
            var selectable = scanLines.Count(l => l.Row?.Source != null);
            scanCount.text = scanRows == null ? "" : $"보이는 패키지 {selectable}개";
            pickAll.text = $"보이는 패키지 모두 고르기 ({selectable})";
            pickAll.SetEnabled(selectable > 0);
            pickAll.tooltip = selectable == 0 ? "보이는 패키지가 없어요. 압축 파일을 펼치면 안의 패키지가 보여요." : "접힌 압축 파일 안의 패키지는 고르지 않아요.";
            clearAll.SetEnabled(importOrder.Count > 0);
            scanFooter.EnableInClassList("am-hidden", scanRows == null || scanLines.Count == 0);

            orderCount.text = importOrder.Count > 0 ? $"{importOrder.Count}개" : "";
            var focus = FocusSlot(orderPane);
            BuildOrderTop();
            BuildOrderBody();
            RestoreFocus(orderPane, focus);
        }

        private void Flatten(IEnumerable<ScanRow> rows)
        {
            foreach (var row in rows)
            {
                scanLines.Add(new ScanLine { Row = row, Depth = row.Depth });
                if (!row.IsArchive || !row.Expanded) continue;
                if (row.Children == null)
                {
                    scanLines.Add(new ScanLine { Note = "압축 파일 목록을 읽고 있어요…", Depth = row.Depth + 1 });
                    continue;
                }
                if (row.Children.Count == 0)
                    scanLines.Add(new ScanLine
                    {
                        Note = row.Error ?? (row.Vpm ? "VCC·ALCOM으로 설치하는 패키지예요. 여기서는 가져오지 않아요." : "안에 .unitypackage가 없어요."),
                        Depth = row.Depth + 1,
                    });
                Flatten(row.Children);
            }
        }

        // ---- Found packages ----

        private VisualElement MakeScanLine()
        {
            var line = new VisualElement();
            line.AddToClassList("am-scan-line");
            line.Add(new VisualElement { name = "indent" });
            var arrow = new Label { name = "arrow" };
            arrow.AddToClassList("am-disclosure");
            line.Add(arrow);
            // The whole line is the hit area; the box only shows the state, so a click is never counted twice.
            var check = new Toggle { name = "check", focusable = false };
            check.AddToClassList("am-check");
            check.pickingMode = PickingMode.Ignore;
            check.Query<VisualElement>().ForEach(v => v.pickingMode = PickingMode.Ignore);
            line.Add(check);
            var icon = FolderIcon();
            icon.name = "icon";
            line.Add(icon);
            var name = new Label { name = "name", enableRichText = false };
            name.AddToClassList("am-scan-name");
            line.Add(name);
            var chips = new VisualElement { name = "chips" };
            chips.AddToClassList("am-chips-inline");
            line.Add(chips);
            var size = new Label { name = "size" };
            size.AddToClassList("am-scan-size");
            line.Add(size);
            line.RegisterCallback<ClickEvent>(_ =>
            {
                if (!(line.userData is ScanLine item) || item.Row == null) return;
                ToggleLine(item.Row);
            });
            return line;
        }

        private void ToggleLine(ScanRow row)
        {
            if (row.IsArchive)
            {
                row.Expanded = !row.Expanded;
                if (row.Expanded && row.Children == null && row.Listing == null) StartListing(row);
            }
            else Select(row.Source, !IsChosen(row.Source));
            RefreshImportPage();
        }

        private bool IsChosen(ImportSource source) => importOrder.Any(s => s.Key == source.Key);

        private void BindScanLine(VisualElement line, int index)
        {
            var item = scanLines[index];
            line.userData = item;
            line.Q("indent").style.width = item.Depth * 16;
            var arrow = line.Q<Label>("arrow");
            var check = line.Q<Toggle>("check");
            var icon = line.Q("icon");
            var name = line.Q<Label>("name");
            var chips = line.Q("chips");
            var size = line.Q<Label>("size");
            chips.Clear();
            var row = item.Row;
            line.EnableInClassList("am-scan-line--note", row == null);
            if (row == null)
            {
                arrow.AddToClassList("am-hidden");
                check.AddToClassList("am-hidden");
                icon.AddToClassList("am-hidden");
                name.text = item.Note;
                size.text = "";
                line.tooltip = item.Note;
                line.EnableInClassList("am-scan-line--on", false);
                return;
            }
            var archive = row.IsArchive;
            arrow.EnableInClassList("am-hidden", !archive);
            arrow.text = row.Expanded ? "▾" : "▸";
            icon.EnableInClassList("am-hidden", !archive);
            check.EnableInClassList("am-hidden", archive);
            var on = !archive && IsChosen(row.Source);
            check.SetValueWithoutNotify(on);
            line.EnableInClassList("am-scan-line--on", on);
            name.text = row.Name;
            if (archive) chips.Add(UiChip("압축", ""));
            if (row.Vpm) chips.Add(Tip(UiChip("VCC 패키지", "am-chip--warn"), "VCC·ALCOM으로 설치하는 패키지예요. 여기서는 가져오지 않아요."));
            if (row.Error != null) chips.Add(Tip(UiChip("열 수 없음", "am-chip--bad"), row.Error));
            if (row.Source != null && AlreadyImported(row.Source))
                chips.Add(Tip(UiChip("가져온 적 있음", ""), "이 프로젝트에 같은 이름·크기의 패키지를 가져온 기록이 있어요."));
            size.text = AssetFolders.FormatSize(row.Size);
            line.tooltip = row.Name + "\n" + (archive
                ? row.Expanded ? "누르면 접어요." : "누르면 안의 패키지를 보여 줘요."
                : on ? "누르면 가져올 순서에서 빼요." : "누르면 가져올 순서에 넣어요.");
        }

        private void Scan(string folder, bool recursive)
        {
            var files = ArchiveScanner.FindFiles(folder, recursive);
            scanRows = files.Select(f =>
            {
                long size = 0;
                try { size = new FileInfo(f).Length; }
                catch (IOException) { }
                var relative = f.Length > folder.Length ? f.Substring(folder.Length).TrimStart('\\', '/') : Path.GetFileName(f);
                return f.EndsWith(".zip", StringComparison.OrdinalIgnoreCase)
                    ? new ScanRow { Name = relative, Size = size, Zip = f }
                    : new ScanRow { Name = relative, Size = size, Source = new ImportSource { file = f, size = size } };
            }).ToList();
            scanStatus = files.Count == 0
                ? recursive
                    ? "이 폴더와 그 안쪽에서 .unitypackage나 .zip을 찾지 못했어요. 패키지를 내려받은 폴더를 고르세요."
                    : "이 폴더에서 .unitypackage나 .zip을 찾지 못했어요. ‘하위 폴더 포함’을 켜거나 다른 폴더를 고르세요."
                : null;
        }

        private static IEnumerable<ScanRow> AllRows(IEnumerable<ScanRow> rows)
        {
            foreach (var row in rows)
            {
                yield return row;
                if (row.Children != null)
                    foreach (var child in AllRows(row.Children)) yield return child;
            }
        }

        private void StartListing(ScanRow row)
        {
            var zip = row.Zip;
            var nested = row.NestedEntry;
            var temp = Path.Combine(AssetStore.TempFolder, "listing");
            row.Listing = Task.Run(() => nested == null ? ArchiveScanner.List(zip) : ArchiveScanner.ListNested(zip, nested, temp));
            pendingListings.Add(row);
        }

        private static void Expand(ScanRow row)
        {
            var listing = row.Listing.IsFaulted ? new ZipListing { Error = row.Listing.Exception?.InnerException?.Message } : row.Listing.Result;
            row.Error = listing.Error;
            row.Vpm = listing.VpmPackage;
            row.Children = new List<ScanRow>();
            foreach (var (entry, size) in listing.Packages)
            {
                var source = row.NestedEntry == null
                    ? new ImportSource { file = row.Zip, entry = entry, size = size }
                    : new ImportSource { file = row.Zip, entry = row.NestedEntry, nestedEntry = entry, size = size };
                row.Children.Add(new ScanRow { Name = entry, Size = size, Depth = row.Depth + 1, Source = source });
            }
            // One level of archives inside an archive.
            if (row.NestedEntry == null)
                foreach (var (entry, size) in listing.Archives)
                    row.Children.Add(new ScanRow { Name = entry, Size = size, Depth = row.Depth + 1, Zip = row.Zip, NestedEntry = entry });
        }

        private void Select(ImportSource source, bool selected)
        {
            Choose(source, selected);
            if (!orderTouched) SortOrder();
        }

        // Puts a package in the order (or takes it out) without sorting, so choosing many sorts once.
        private void Choose(ImportSource source, bool selected)
        {
            importOrder.RemoveAll(s => s.Key == source.Key);
            if (!selected) return;
            importOrder.Add(source);
            var stamp = ImportQueue.StampOf(source);
            if (preChecks.TryGetValue(source.Key, out var made) && made.Stamp == stamp) return;
            var check = new PreCheck { Stamp = stamp };
            if (source.nestedEntry.Length > 0) check.Error = "안쪽 압축 파일의 패키지는 가져올 때 내용을 확인해요.";
            else
            {
                check.Reading = Task.Run(() => ArchiveScanner.ReadEntries(source));
                pendingChecks.Add(check);
            }
            preChecks[source.Key] = check;
        }

        // What the package would do, worked out on the main thread once its list is read.
        private static void Complete(PreCheck check)
        {
            check.Ready = true;
            if (check.Reading.IsFaulted)
            {
                check.Error = "패키지 내용을 읽지 못했어요: " + (check.Reading.Exception?.InnerException?.Message ?? "");
                return;
            }
            var found = PackageCheck.Of(check.Reading.Result);
            check.Folders = found.Folders;
            check.NewFolders = found.NewFolders;
            check.Scripts = found.Scripts;
            check.Shaders = found.Shaders;
            check.Overwrites = found.Overwrites;
            check.PackageOverwrites = found.PackageOverwrites;
            check.Files = found.Files;
        }

        // How many files of the package at this place in the order an earlier package of the order brings too. The
        // check of each package knows the project as it is now, not what the ones before it will have put there.
        private int SameAsEarlier(int index)
        {
            if (!preChecks.TryGetValue(importOrder[index].Key, out var check) || !check.Ready || check.Error != null) return 0;
            var earlier = new HashSet<string>();
            for (var i = 0; i < index; i++)
                if (preChecks.TryGetValue(importOrder[i].Key, out var before) && before.Ready && before.Error == null) earlier.UnionWith(before.Files);
            return earlier.Count == 0 ? 0 : check.Files.Count(earlier.Contains);
        }

        // Tools and shaders first (other packages may need them to compile), then the order the user picked.
        private void SortOrder()
        {
            var sorted = importOrder.Select((s, i) => (s, i))
                .OrderBy(p => preChecks.TryGetValue(p.s.Key, out var c) && c.Ready && (c.Scripts || c.Shaders) ? 0 : 1)
                .ThenBy(p => p.i).Select(p => p.s).ToList();
            importOrder.Clear();
            importOrder.AddRange(sorted);
        }

        private static bool AlreadyImported(ImportSource source) =>
            AssetStore.State.history.Any(h => h.result == "completed" && h.package == source.PackageName && h.size == source.size);

        // ---- Order and queue ----

        // The import button and the progress stay above the scrolling part, however long it gets.
        private void BuildOrderTop()
        {
            orderTop.Clear();
            var queue = ImportQueue.Data;
            if (importOrder.Count > 0)
            {
                var reason = ImportQueue.HasUnknown ? "‘확인 필요’ 항목을 먼저 다시 시도하거나 건너뛰세요." : null;
                var note = reason ?? (ImportQueue.Current != null ? "지금 가져오는 패키지가 끝나면 이어서 가져와요." : null);
                var go = UiButton($"임포트 ({importOrder.Count}개)", "am-button--primary", StartImport, reason ?? "아래 순서대로 하나씩 가져와요.");
                go.AddToClassList("am-button--wide");
                go.SetEnabled(reason == null);
                orderTop.Add(go);
                if (note != null) orderTop.Add(UiNote(note, reason != null));
            }
            if (queue.jobs.Count > 0) orderTop.Add(QueueControls(queue));
            orderTop.EnableInClassList("am-hidden", orderTop.childCount == 0);
        }

        private void StartImport()
        {
            // Replacing files cannot be undone: asked once, here where it is started, with what the cards say added up.
            int replaced = 0, vpm = 0, shared = 0, packages = 0;
            for (var i = 0; i < importOrder.Count; i++)
            {
                if (!preChecks.TryGetValue(importOrder[i].Key, out var check) || !check.Ready || check.Error != null) continue;
                var again = SameAsEarlier(i);
                if (check.Overwrites.Count + check.PackageOverwrites.Count + again > 0) packages++;
                replaced += check.Overwrites.Count;
                vpm += check.PackageOverwrites.Count;
                shared += again;
            }
            if (packages > 0)
            {
                var parts = new List<string>();
                if (replaced > 0) parts.Add($"프로젝트에 있는 파일 {replaced}개");
                if (vpm > 0) parts.Add($"VCC로 설치한 패키지의 파일 {vpm}개");
                if (shared > 0) parts.Add($"앞 순서의 패키지가 가져올 파일 {shared}개");
                if (!EditorUtility.DisplayDialog("Asset Manager",
                        $"고른 패키지 {importOrder.Count}개 중 {packages}개가 파일을 덮어써요: {string.Join(", ", parts)}.\n\n" +
                        "덮어쓴 파일은 되돌릴 수 없어요. 어떤 파일인지는 각 패키지의 ‘덮어쓸 파일 보기’에서 볼 수 있어요.", "가져오기", "취소")) return;
            }
            foreach (var source in importOrder)
            {
                preChecks.TryGetValue(source.Key, out var check);
                // Shown to the user only when the check finished for the file as it is now; the queue checks the rest
                // itself before importing.
                var reviewed = check != null && check.Ready && check.Error == null && check.Stamp.Length > 0 && check.Stamp == ImportQueue.StampOf(source);
                ImportQueue.Add(source, interactiveKeys.Contains(source.Key), reviewed ? check.Folders : null, reviewed, reviewed ? check.Stamp : "");
            }
            importOrder.Clear();
            orderTouched = false;
            ImportQueue.Start();
            RefreshImportPage();
        }

        private VisualElement QueueControls(QueueData queue)
        {
            var box = new VisualElement();
            box.AddToClassList("am-queue");
            box.Add(UiText("가져오기 진행", "am-pane-subtitle"));
            var total = queue.jobs.Count;
            var finished = queue.jobs.Count(j => j.Finished);
            var current = ImportQueue.Current;
            if (current != null || queue.running)
            {
                box.Add(UiText(current != null ? $"{finished + 1}/{total} 가져오는 중: {current.source.PackageName}" : $"{finished}/{total} 끝남", "am-progress-label"));
                var track = new VisualElement();
                track.AddToClassList("am-progress");
                var fill = new VisualElement();
                fill.AddToClassList("am-progress-fill");
                fill.style.width = Length.Percent(total == 0 ? 0 : 100f * finished / total);
                track.Add(fill);
                box.Add(track);
                if (current != null && current.message.Length > 0) box.Add(UiText(current.message, "am-text"));
            }
            if (queue.pauseReason.Length > 0) box.Add(UiNote(queue.pauseReason, true));
            // Everything is in: what came of it, and the step that follows (the folders it made wait to be made assets).
            if (!queue.running && current == null && ImportQueue.Remaining == 0 && finished > 0 && !ImportQueue.HasUnknown)
            {
                var done = queue.jobs.Count(j => j.state == JobState.Done);
                var failed = queue.jobs.Count(j => j.state == JobState.Failed || j.state == JobState.Cancelled);
                box.Add(UiText(failed > 0 ? $"가져오기가 끝났어요. 완료 {done}개, 실패·취소 {failed}개(아래 목록에서 다시 시도할 수 있어요)." : $"가져오기가 끝났어요. 완료 {done}개.", "am-text"));
                var proposals = AssetStore.State.proposals.Count;
                if (proposals > 0)
                {
                    var next = new VisualElement();
                    next.AddToClassList("am-actions");
                    // The import button above is the primary one while packages are still chosen.
                    next.Add(UiButton($"에셋 후보 {proposals}개 보기", importOrder.Count == 0 ? "am-button--primary" : "", () => SetTab(2),
                        "새로 생긴 폴더를 ‘폴더 지정’에서 에셋으로 만들고 Booth 상품과 연결해요."));
                    box.Add(next);
                }
            }
            var actions = new VisualElement();
            actions.AddToClassList("am-actions");
            if (queue.running)
                actions.Add(UiButton("멈추기", "", () =>
                {
                    ImportQueue.Pause("멈췄어요. 이어서 가져오려면 시작을 누르세요.");
                    RefreshImportPage();
                }, "지금 가져오는 패키지가 끝나면 멈춰요."));
            else
            {
                var waiting = ImportQueue.Remaining;
                var reason = waiting == 0 ? "남은 패키지가 없어요." : ImportQueue.HasUnknown ? "‘확인 필요’ 항목을 먼저 다시 시도하거나 건너뛰세요." : null;
                var start = UiButton($"시작 ({waiting}개 남음)", "", () =>
                {
                    ImportQueue.Start();
                    RefreshImportPage();
                }, reason ?? "남은 패키지를 차례로 가져와요.");
                start.SetEnabled(reason == null);
                actions.Add(start);
            }
            var clear = UiButton("끝난 항목 지우기", "am-button--quiet", () =>
            {
                ImportQueue.ClearFinished();
                RefreshImportPage();
            }, finished == 0 ? "끝난 항목이 없어요." : null);
            clear.SetEnabled(finished > 0);
            actions.Add(clear);
            box.Add(actions);
            return box;
        }

        private void BuildOrderBody()
        {
            var offset = orderScroll.scrollOffset;
            orderBody.Clear();
            var queue = ImportQueue.Data;
            if (importOrder.Count > 0)
            {
                orderBody.Add(UiText("스크립트·셰이더가 든 패키지를 먼저 놓았어요. ▲▼로 바꿀 수 있어요.", "am-text"));
                for (var i = 0; i < importOrder.Count; i++) orderBody.Add(OrderCard(i));
            }
            else if (queue.jobs.Count == 0)
                orderBody.Add(UiEmpty("고른 패키지가 없어요", "왼쪽에서 가져올 패키지를 누르세요. 고른 순서대로 여기에 쌓이고, ‘임포트’를 누르면 하나씩 가져와요."));
            if (queue.jobs.Count > 0)
            {
                orderBody.Add(UiText("대기열", "am-pane-subtitle"));
                foreach (var job in queue.jobs.ToList()) orderBody.Add(JobRow(job));
            }
            orderScroll.scrollOffset = offset;
        }

        private VisualElement OrderCard(int index)
        {
            var source = importOrder[index];
            preChecks.TryGetValue(source.Key, out var check);
            var card = new VisualElement();
            card.AddToClassList("am-item");
            var head = new VisualElement();
            head.AddToClassList("am-item-head");
            head.Add(UiText($"{index + 1}", "am-item-number"));
            head.Add(Tip(UiText(source.Describe(), "am-item-name"), source.Describe()));
            var up = UiButton("▲", "am-button--icon", () =>
            {
                MoveOrder(index, -1);
                RefreshImportPage();
            }, "한 칸 앞으로");
            up.SetEnabled(index > 0);
            var down = UiButton("▼", "am-button--icon", () =>
            {
                MoveOrder(index, 1);
                RefreshImportPage();
            }, "한 칸 뒤로");
            down.SetEnabled(index < importOrder.Count - 1);
            head.Add(up);
            head.Add(down);
            head.Add(UiButton("×", "am-button--icon", () =>
            {
                importOrder.RemoveAt(index);
                RefreshImportPage();
            }, "순서에서 빼요."));
            card.Add(head);

            if (check == null || !check.Ready && check.Error == null)
                card.Add(Tip(UiText("내용 확인 중…", "am-text"), "확인이 끝나기 전에 임포트를 누르면, 가져올 때 확인해서 스크립트나 덮어쓰는 파일이 있으면 Unity 가져오기 창을 열어요."));
            else if (check.Error != null) card.Add(UiText(check.Error, "am-text"));
            else
            {
                var chips = new VisualElement();
                chips.AddToClassList("am-chips");
                if (check.Scripts) chips.Add(Tip(UiChip("스크립트", ""), "가져온 뒤 컴파일해요."));
                if (check.Shaders) chips.Add(UiChip("셰이더", ""));
                if (check.Overwrites.Count > 0)
                    chips.Add(Tip(UiChip($"덮어씀 {check.Overwrites.Count}개", "am-chip--warn"), "프로젝트에 이미 있는 파일을 같은 GUID로 덮어써요."));
                if (check.PackageOverwrites.Count > 0)
                    chips.Add(Tip(UiChip($"⚠ VPM 파일 {check.PackageOverwrites.Count}개", "am-chip--bad"), "VCC로 설치한 패키지의 파일과 GUID가 같아요."));
                var again = SameAsEarlier(index);
                if (again > 0)
                    chips.Add(Tip(UiChip($"앞 패키지와 같은 파일 {again}개", "am-chip--warn"),
                        "앞 순서의 패키지가 가져올 파일을 이 패키지의 것으로 덮어써요. 같은 샵의 공용 파일이면 보통 괜찮지만, 오래된 사본이 새 것을 덮을 수 있어요. 순서를 바꾸면 남는 쪽이 바뀌어요."));
                if (AlreadyImported(source)) chips.Add(UiChip("가져온 적 있음", ""));
                if (chips.childCount > 0) card.Add(chips);
                card.Add(UiText(check.NewFolders.Count > 0 ? "새 폴더: " + string.Join(", ", check.NewFolders.Select(Path.GetFileName)) : "새 폴더 없음", "am-text"));
                if (check.Overwrites.Count > 0 || check.PackageOverwrites.Count > 0) card.Add(OverwriteFold(source, check));
            }

            var interactive = new Toggle { text = "Unity 가져오기 창 열기", value = interactiveKeys.Contains(source.Key), tooltip = "가져올 파일을 Unity 창에서 직접 골라요." };
            interactive.AddToClassList("am-toggle");
            interactive.RegisterValueChangedCallback(e =>
            {
                if (e.newValue) interactiveKeys.Add(source.Key);
                else interactiveKeys.Remove(source.Key);
            });
            card.Add(interactive);
            return card;
        }

        private VisualElement OverwriteFold(ImportSource source, PreCheck check)
        {
            var key = source.Key;
            var fold = new Foldout { text = "덮어쓸 파일 보기", value = openOverwrites.Contains(key) };
            fold.AddToClassList("am-fold");
            fold.RegisterValueChangedCallback(e =>
            {
                if (e.target != fold) return;
                if (e.newValue) openOverwrites.Add(key);
                else openOverwrites.Remove(key);
            });
            foreach (var path in check.PackageOverwrites.Take(10)) fold.Add(Tip(UiText("⚠ " + path, "am-path"), path));
            foreach (var path in check.Overwrites.Take(10)) fold.Add(Tip(UiText(path, "am-path"), path));
            var more = check.Overwrites.Count + check.PackageOverwrites.Count - Math.Min(10, check.Overwrites.Count) - Math.Min(10, check.PackageOverwrites.Count);
            if (more > 0) fold.Add(UiText($"…그 밖에 {more}개", "am-path"));
            fold.Add(UiText("빼고 가져오려면 아래 ‘Unity 가져오기 창 열기’를 켜고, 창에서 그 파일의 체크를 푸세요.", "am-text"));
            return fold;
        }

        private void MoveOrder(int index, int delta)
        {
            var target = index + delta;
            if (target < 0 || target >= importOrder.Count) return;
            var item = importOrder[index];
            importOrder.RemoveAt(index);
            importOrder.Insert(target, item);
            orderTouched = true;
        }

        private VisualElement JobRow(ImportJob job)
        {
            var row = new VisualElement();
            row.AddToClassList("am-item");
            row.AddToClassList("am-item--row");
            var (word, kind) = StateChip(job.state);
            row.Add(UiChip(word, kind));
            var text = new VisualElement();
            text.AddToClassList("am-item-text");
            text.Add(Tip(UiText(job.source.Describe(), "am-item-name"), job.source.Describe()));
            if (job.message.Length > 0) text.Add(UiText(job.message, "am-text"));
            row.Add(text);
            void Act(Action action)
            {
                action();
                RefreshImportPage();
            }
            switch (job.state)
            {
                case JobState.Waiting:
                    row.Add(UiButton("▲", "am-button--icon", () => Act(() => ImportQueue.Move(job, -1)), "한 칸 앞으로"));
                    row.Add(UiButton("▼", "am-button--icon", () => Act(() => ImportQueue.Move(job, 1)), "한 칸 뒤로"));
                    row.Add(UiButton("×", "am-button--icon", () => Act(() => ImportQueue.Remove(job)), "대기열에서 빼요."));
                    break;
                case JobState.Preparing:
                    // Unpacking or reading a large package can take long; nothing has gone into the project yet.
                    row.Add(UiButton("×", "am-button--icon", () => Act(() => ImportQueue.Remove(job)), "아직 가져오기 전이에요. 대기열에서 빼요."));
                    break;
                case JobState.Unknown:
                    row.Add(UiButton("다시 시도", "", () => Act(() => ImportQueue.Retry(job))));
                    row.Add(UiButton("건너뛰기", "am-button--quiet", () => Act(() => ImportQueue.Skip(job))));
                    break;
                case JobState.Failed:
                case JobState.Cancelled:
                    row.Add(UiButton("다시 시도", "", () => Act(() => ImportQueue.Retry(job))));
                    break;
                case JobState.Done when job.proposed > 0:
                    row.Add(UiButton("에셋 후보 보기", "am-button--quiet", () => SetTab(2), "새로 생긴 폴더를 ‘폴더 지정’에서 에셋으로 만들 수 있어요."));
                    break;
            }
            return row;
        }

        // Each state has its word; the colour only repeats it.
        private static (string Word, string Kind) StateChip(JobState state)
        {
            switch (state)
            {
                case JobState.Waiting: return ("대기", "");
                case JobState.Preparing: return ("준비 중", "am-chip--accent");
                case JobState.Importing: return ("가져오는 중", "am-chip--accent");
                case JobState.Finalizing: return ("정리 중", "am-chip--accent");
                case JobState.Done: return ("완료", "am-chip--ok");
                case JobState.Failed: return ("실패", "am-chip--bad");
                case JobState.Cancelled: return ("취소", "am-chip--warn");
                case JobState.Unknown: return ("확인 필요", "am-chip--warn");
                default: return ("건너뜀", "");
            }
        }
    }
}
