using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using UnityEditor;
using UnityEngine;

namespace NXYUI.AssetManager
{
    internal enum JobState { Waiting, Preparing, Importing, Finalizing, Done, Failed, Cancelled, Unknown, Skipped }

    [Serializable]
    internal sealed class ImportJob
    {
        public string id = Guid.NewGuid().ToString("N");
        public ImportSource source = new ImportSource();
        public bool interactive;
        public JobState state;
        // Recorded before anything is written there, so a restart can clean it up.
        public string tempFolder = "";
        public string packageFile = "";
        public bool temporary;
        public bool callbackSeen;
        public string outcome = "";
        public string message = "";
        public List<string> expectedFolders = new List<string>();
        public List<string> existedBefore = new List<string>();
        public List<string> imported = new List<string>();
        public List<string> created = new List<string>();
        public double startedAt;
        public bool recorded;
        // The user saw what the package holds (scripts, files it replaces) on the import tab, for the source file as it
        // was then (stamp). Anything else is checked by the queue before it goes in.
        public bool reviewed;
        public string stamp = "";
        public string reviewNote = "";
        // Folders this import put up as an asset proposal.
        public int proposed;

        public bool Finished => state == JobState.Done || state == JobState.Failed || state == JobState.Cancelled || state == JobState.Skipped;
    }

    [Serializable]
    internal sealed class QueueData
    {
        public int version = 1;
        public List<ImportJob> jobs = new List<ImportJob>();
        public bool running;
        public string pauseReason = "";
        public string session = "";
    }

    // What a package would do to the project, from its list. The import tab shows it before importing; the queue works
    // it out again for a package the user was not shown it for (one inside a nested archive, one still being read when
    // the import started, a file replaced since).
    internal sealed class PackageCheck
    {
        public List<string> Folders = new List<string>();
        public List<string> NewFolders = new List<string>();
        public bool Scripts, Shaders;
        public List<string> Overwrites = new List<string>();
        public List<string> PackageOverwrites = new List<string>();
        // Every file the package brings, by GUID: two packages chosen together can bring the same file.
        public HashSet<string> Files = new HashSet<string>();

        // Main thread only: the asset database says which GUIDs the project already has.
        public static PackageCheck Of(List<PackageEntry> entries)
        {
            var check = new PackageCheck();
            check.Folders = UnityPackageReader.Folders(entries).OrderBy(f => f, StringComparer.Ordinal).ToList();
            check.NewFolders = UnityPackageReader.Topmost(check.Folders.Where(f => !AssetDatabase.IsValidFolder(f)));
            foreach (var entry in entries.Where(e => e.IsFile))
            {
                check.Files.Add(entry.Guid);
                var extension = Path.GetExtension(entry.Path).ToLowerInvariant();
                // Code, and what decides how code is compiled (assembly definitions and references, compiler options).
                if (extension == ".cs" || extension == ".dll" || extension == ".asmdef" || extension == ".asmref" || extension == ".rsp") check.Scripts = true;
                if (extension == ".shader" || extension == ".cginc" || extension == ".hlsl") check.Shaders = true;
                var existing = AssetDatabase.GUIDToAssetPath(entry.Guid);
                if (existing.Length == 0 || AssetDatabase.IsValidFolder(existing) || !File.Exists(existing)) continue;
                (existing.StartsWith("Packages/", StringComparison.Ordinal) ? check.PackageOverwrites : check.Overwrites).Add(existing);
            }
            return check;
        }

        // What the user has to see before this package goes in, or null: code that runs once imported, and files it
        // would replace.
        public string Concern()
        {
            var parts = new List<string>();
            if (Scripts) parts.Add("스크립트");
            if (PackageOverwrites.Count > 0) parts.Add($"VCC로 설치한 패키지와 겹치는 파일 {PackageOverwrites.Count}개");
            if (Overwrites.Count > 0) parts.Add($"이미 있는 파일을 덮어쓰는 파일 {Overwrites.Count}개");
            return parts.Count == 0 ? null : string.Join(", ", parts);
        }
    }

    // Imports queued packages one at a time. Each step is written to Library/NXYUI/AssetManager/ImportQueue.json before
    // it happens, so a domain reload (a package with scripts compiles) picks the queue up where it was. A result that
    // cannot be told for sure (no callback, the editor restarted mid-import) pauses the queue as "확인 필요" and is never
    // imported again on its own; compile errors pause before the next import. A new editor session never resumes a
    // queue by itself.
    [InitializeOnLoad]
    internal static class ImportQueue
    {
        private const string QueueFile = "Library/NXYUI/AssetManager/ImportQueue.json";
        private const string SessionKey = "NXYUI.AssetManager.Session";
        private const double CallbackWait = 10;
        private const double ReloadGrace = 3;
        // How long after a job was marked "확인 필요" a callback of its name still counts as its own late answer.
        private const double LateCallback = 120;

        private static QueueData data;
        private static readonly double LoadedAt;
        private static Task<(string File, List<PackageEntry> Entries)> reading;
        private static string readingJob;
        // Paths Unity reports while a package import runs, for the job (or for an import from outside the queue).
        private static List<string> collecting;
        private static string collectingJob;
        // The job marked "확인 필요" in this session for want of a callback, and until when its answer may still come.
        private static string lateJob;
        private static double lateUntil;
        // The job's source file and review state as they were when its reading began (see Prepare).
        private static string readingStamp;
        private static bool readingUnreviewed;
        // Readings let go of while they ran (their job was taken out of the queue), with the folder to clear once done.
        private static readonly List<(Task Work, string Folder)> abandoned = new List<(Task, string)>();

        public static event Action Changed;

        static ImportQueue()
        {
            LoadedAt = EditorApplication.timeSinceStartup;
            AssetDatabase.importPackageStarted += OnStarted;
            AssetDatabase.importPackageCompleted += OnCompleted;
            AssetDatabase.importPackageFailed += OnFailed;
            AssetDatabase.importPackageCancelled += OnCancelled;
            EditorApplication.update += Tick;
            EditorApplication.delayCall += Recover;
        }

        public static QueueData Data
        {
            get
            {
                if (data != null) return data;
                data = AssetStore.Load<QueueData>(QueueFile) ?? new QueueData();
                // The file is plain JSON in Library, and a job's id becomes a folder name under Temp: it has to be one
                // this class made.
                foreach (var job in data.jobs.Where(j => !ValidId(j.id)))
                {
                    job.id = Guid.NewGuid().ToString("N");
                    job.tempFolder = "";
                }
                return data;
            }
        }

        public static bool Running => Data.running;
        public static ImportJob Current => Data.jobs.FirstOrDefault(j => j.state == JobState.Preparing || j.state == JobState.Importing || j.state == JobState.Finalizing);
        public static int Waiting => Data.jobs.Count(j => j.state == JobState.Waiting);
        // Jobs the start button would go on with: those waiting, and one stopped while it was being prepared.
        public static int Remaining => Data.jobs.Count(j => j.state == JobState.Waiting || j.state == JobState.Preparing);

        private static bool ValidId(string id) => id != null && id.Length == 32 && id.All(Uri.IsHexDigit);

        // The source file as it is now (size and time of writing), to notice a file replaced under the same name.
        internal static string StampOf(ImportSource source)
        {
            try
            {
                var info = new FileInfo(source.file);
                return info.Exists ? info.Length + ":" + info.LastWriteTimeUtc.Ticks : "";
            }
            catch (Exception e) when (e is IOException || e is UnauthorizedAccessException || e is ArgumentException || e is NotSupportedException)
            {
                return "";
            }
        }

        private static bool Reviewed(ImportJob job) => job.reviewed && job.stamp.Length > 0 && job.stamp == StampOf(job.source);

        private static bool Save()
        {
            var ok = AssetStore.Write(QueueFile, JsonUtility.ToJson(Data, true));
            Changed?.Invoke();
            return ok;
        }

        // ---- Commands from the window ----

        // reviewed: the import tab showed the user this package's check, made when the source file had this stamp.
        public static void Add(ImportSource source, bool interactive, IEnumerable<string> expectedFolders, bool reviewed, string stamp)
        {
            if (Data.jobs.Any(j => !j.Finished && j.source.Key == source.Key)) return;
            Data.jobs.Add(new ImportJob
            {
                source = source, interactive = interactive, expectedFolders = expectedFolders?.ToList() ?? new List<string>(),
                reviewed = reviewed, stamp = stamp ?? "",
            });
            Save();
        }

        public static void Remove(ImportJob job)
        {
            if (job.state == JobState.Preparing)
            {
                // Nothing was handed to Unity yet. The reading in the background is let go; its result is never used.
                // It may still be writing into the temp folder (unpacking a large archive): the folder is cleared again
                // once it has ended (Sweep).
                if (readingJob == job.id)
                {
                    if (reading != null && OwnTemp(job)) abandoned.Add((reading, job.tempFolder));
                    reading = null;
                    readingJob = null;
                }
                Cleanup(job);
            }
            else if (job.state != JobState.Waiting && !job.Finished && job.state != JobState.Unknown) return;
            Data.jobs.Remove(job);
            Save();
        }

        public static void Move(ImportJob job, int delta)
        {
            var list = Data.jobs;
            var index = list.IndexOf(job);
            var target = index + delta;
            if (index < 0 || target < 0 || target >= list.Count || list[target].state != JobState.Waiting || job.state != JobState.Waiting) return;
            list.RemoveAt(index);
            list.Insert(target, job);
            Save();
        }

        public static bool HasUnknown => Data.jobs.Any(j => j.state == JobState.Unknown);

        // Refused while a job waits for the user's decision: a later package of the same name could otherwise be
        // taken for it.
        public static bool Start()
        {
            if (HasUnknown)
            {
                Data.pauseReason = "‘확인 필요’ 항목을 먼저 다시 시도하거나 건너뛰세요.";
                Save();
                return false;
            }
            Data.running = true;
            Data.pauseReason = "";
            Data.session = Session;
            Save();
            return true;
        }

        public static void Pause(string reason)
        {
            Data.running = false;
            Data.pauseReason = reason ?? "";
            Save();
        }

        public static void ClearFinished()
        {
            Data.jobs.RemoveAll(j => j.Finished);
            Save();
        }

        // A job whose result was not confirmed: the user decides whether to queue it again or leave it.
        public static void Retry(ImportJob job)
        {
            if (job.state != JobState.Unknown && job.state != JobState.Failed && job.state != JobState.Cancelled) return;
            if (Data.jobs.Any(j => j != job && !j.Finished && j.source.Key == job.source.Key))
            {
                // Put in the queue again from the list meanwhile: that entry imports it, and two would import it twice.
                job.message = "같은 패키지가 이미 대기열에 있어요. 그 항목이 가져와요.";
                Save();
                return;
            }
            Cleanup(job);
            job.state = JobState.Waiting;
            job.callbackSeen = false;
            job.outcome = job.message = "";
            job.recorded = false;
            job.imported.Clear();
            job.created.Clear();
            Save();
        }

        public static void Skip(ImportJob job)
        {
            if (job.state != JobState.Unknown) return;
            Cleanup(job);
            job.state = JobState.Skipped;
            job.message = "결과를 확인하지 못해 건너뛰었어요.";
            Save();
        }

        // ---- Session and recovery ----

        private static string Session
        {
            get
            {
                var id = SessionState.GetString(SessionKey, "");
                if (id.Length == 0)
                {
                    id = Guid.NewGuid().ToString("N");
                    SessionState.SetString(SessionKey, id);
                }
                return id;
            }
        }

        private static void Recover()
        {
            var queue = Data;
            if (queue.session == Session) return;
            // The editor was closed and opened again.
            queue.session = Session;
            foreach (var job in queue.jobs.Where(j => j.state == JobState.Preparing))
            {
                // Still being unpacked or read when the editor closed: nothing was handed to Unity, so it only waits again.
                Cleanup(job);
                job.tempFolder = "";
                job.state = JobState.Waiting;
                job.message = "";
            }
            // What the file says about a package's contents was true for the session that wrote it. Jobs carried over
            // are checked again by the queue before they go in (Reviewed), whatever the file claims.
            foreach (var job in queue.jobs.Where(j => !j.Finished))
            {
                job.reviewed = false;
                job.stamp = "";
            }
            foreach (var job in queue.jobs.Where(j => j.state == JobState.Importing))
            {
                if (job.callbackSeen) job.state = JobState.Finalizing;
                else
                {
                    job.state = JobState.Unknown;
                    job.message = "에디터가 다시 열려 가져오기 결과를 확인하지 못했어요. 프로젝트를 확인한 뒤 다시 시도하거나 건너뛰세요.";
                }
            }
            if (queue.running) queue.pauseReason = "에디터를 다시 열어 대기열을 멈췄어요. 이어서 가져오려면 시작을 누르세요.";
            queue.running = false;
            // Temporary copies from the last session that no job still needs.
            var keep = new HashSet<string>(queue.jobs.Where(j => !j.Finished && OwnTemp(j)).Select(j => Path.GetFullPath(j.tempFolder)));
            if (Directory.Exists(AssetStore.TempFolder))
                foreach (var folder in Directory.GetDirectories(AssetStore.TempFolder))
                    if (!keep.Contains(Path.GetFullPath(folder))) TryDeleteFolder(folder);
            Save();
        }

        // ---- The loop ----

        // Clears the temp folders of readings that were let go, once they have stopped writing.
        private static void Sweep()
        {
            for (var i = abandoned.Count - 1; i >= 0; i--)
            {
                if (!abandoned[i].Work.IsCompleted) continue;
                TryDeleteFolder(abandoned[i].Folder);
                abandoned.RemoveAt(i);
            }
        }

        private static void Tick()
        {
            if (abandoned.Count > 0) Sweep();
            var queue = data;
            if (queue == null && !File.Exists(QueueFile)) return;
            queue = Data;
            // A new editor session is recovered first, whichever of update and delayCall comes first.
            if (queue.session != Session)
            {
                Recover();
                return;
            }
            if (EditorApplication.isCompiling || EditorApplication.isUpdating || EditorApplication.isPlayingOrWillChangePlaymode) return;
            var now = EditorApplication.timeSinceStartup;
            var current = Current;
            if (current != null)
            {
                switch (current.state)
                {
                    case JobState.Preparing:
                        if (queue.running) Prepare(current);
                        break;
                    case JobState.Importing:
                        if (current.callbackSeen)
                        {
                            current.state = JobState.Finalizing;
                            Save();
                        }
                        else if (now - LoadedAt > ReloadGrace && NoCallbackComing(current, now))
                        {
                            current.state = JobState.Unknown;
                            lateJob = current.id;
                            lateUntil = now + LateCallback;
                            current.message = "Unity가 가져오기 결과를 알려 주지 않았어요. 프로젝트를 확인한 뒤 다시 시도하거나 건너뛰세요.";
                            Pause("가져오기 결과를 확인해야 해요.");
                        }
                        break;
                    case JobState.Finalizing:
                        // Recording a result imports nothing, so it runs even while the queue is paused.
                        Finalize(current);
                        break;
                }
                return;
            }
            if (!queue.running) return;
            var next = queue.jobs.FirstOrDefault(j => j.state == JobState.Waiting);
            if (next == null)
            {
                queue.running = false;
                queue.pauseReason = "";
                Save();
                return;
            }
            if (EditorUtility.scriptCompilationFailed)
            {
                Pause("스크립트 컴파일 오류가 있어 멈췄어요. Console에서 오류를 고친 뒤 시작을 누르세요.");
                return;
            }
            Begin(next);
        }

        private static bool NoCallbackComing(ImportJob job, double now)
        {
            if (job.interactive)
            {
                // The import dialog is open while the user picks files; it also closes when Import is pressed, so a
                // closed dialog alone is not a result.
                var dialog = typeof(Editor).Assembly.GetType("UnityEditor.PackageImport");
                if (dialog != null && Resources.FindObjectsOfTypeAll(dialog).Length > 0)
                {
                    job.startedAt = now;
                    return false;
                }
            }
            return now - job.startedAt > CallbackWait;
        }

        private static void Begin(ImportJob job)
        {
            job.tempFolder = Path.Combine(AssetStore.TempFolder, job.id).Replace('\\', '/');
            job.state = JobState.Preparing;
            job.message = "";
            if (!Save())
            {
                Fail(job, "대기열 기록을 저장하지 못해 가져오지 않았어요.");
                return;
            }
            Prepare(job);
        }

        // Copying the package out of its archive and reading its list run off the main thread; Tick comes back here
        // until they are done. A domain reload in between only starts them again.
        private static void Prepare(ImportJob job)
        {
            try
            {
                if (reading == null || readingJob != job.id)
                {
                    if (job.packageFile.Length == 0 && job.source.InArchive)
                    {
                        var problem = ArchiveScanner.ExtractProblem(job.source.size, job.tempFolder);
                        if (problem != null) throw new IOException(problem);
                    }
                    var source = job.source;
                    var temp = job.tempFolder;
                    var known = KnownFile(job);
                    // Decided once, for the file as it is now, and used when the reading ends: deciding again then
                    // would find a file changed meanwhile "not reviewed" with no list read to review it by.
                    readingStamp = StampOf(job.source);
                    readingUnreviewed = !(job.reviewed && job.stamp.Length > 0 && job.stamp == readingStamp);
                    var needList = job.expectedFolders.Count == 0 || readingUnreviewed;
                    readingJob = job.id;
                    reading = Task.Run(() =>
                    {
                        var file = known.Length > 0 ? known : ArchiveScanner.Materialize(source, temp, out _);
                        var entries = needList ? UnityPackageReader.Read(file) : new List<PackageEntry>();
                        return (file.Replace('\\', '/'), entries);
                    });
                    job.message = job.source.InArchive && known.Length == 0 ? "압축을 풀고 있어요…" : "패키지 내용을 확인하고 있어요…";
                    Changed?.Invoke();
                    return;
                }
                if (!reading.IsCompleted) return;
                var task = reading;
                reading = null;
                readingJob = null;
                var (packageFile, list) = task.Result;
                if (StampOf(job.source) != readingStamp)
                {
                    // Replaced while it was being read: what was read is not what would go in. Read again.
                    if (job.source.InArchive) Cleanup(job);
                    return;
                }
                job.packageFile = packageFile;
                job.temporary = job.source.InArchive;
                if (!File.Exists(job.packageFile)) throw new FileNotFoundException("패키지 파일이 없어요: " + job.packageFile);
                if (job.expectedFolders.Count == 0 || readingUnreviewed)
                {
                    job.expectedFolders = UnityPackageReader.Folders(list).OrderBy(f => f, StringComparer.Ordinal).ToList();
                    Review(job, list);
                }
                job.existedBefore = job.expectedFolders.Where(AssetDatabase.IsValidFolder).ToList();
                job.state = JobState.Importing;
                job.startedAt = EditorApplication.timeSinceStartup;
                job.callbackSeen = false;
                job.message = job.reviewNote;
                if (!Save())
                {
                    Fail(job, "대기열 기록을 저장하지 못해 가져오지 않았어요.");
                    return;
                }
                collecting = new List<string>();
                collectingJob = job.id;
                AssetDatabase.ImportPackage(job.packageFile, job.interactive);
            }
            catch (Exception e) when (!(e is OutOfMemoryException))
            {
                reading = null;
                readingJob = null;
                var inner = e is AggregateException aggregate && aggregate.InnerException != null ? aggregate.InnerException : e;
                Fail(job, "가져오지 못했어요: " + inner.Message);
            }
        }

        // The package file a job already has, when it is the one the job is for: the file itself for a package on disk,
        // a copy inside the job's own temp folder for one from an archive. Anything else in the queue file is ignored
        // (the file is plain JSON; what it names would be imported under another package's name).
        private static string KnownFile(ImportJob job)
        {
            if (job.packageFile.Length == 0) return "";
            try
            {
                var file = Path.GetFullPath(job.packageFile);
                if (!job.source.InArchive)
                    return string.Equals(file, Path.GetFullPath(job.source.file), StringComparison.OrdinalIgnoreCase) ? job.packageFile : "";
                var own = Path.GetFullPath(Path.Combine(AssetStore.TempFolder, job.id)) + Path.DirectorySeparatorChar;
                return OwnTemp(job) && file.StartsWith(own, StringComparison.OrdinalIgnoreCase) && File.Exists(file) ? job.packageFile : "";
            }
            catch (Exception e) when (e is ArgumentException || e is NotSupportedException || e is IOException)
            {
                return "";
            }
        }

        // A package whose contents the user was not shown is not imported unseen when it brings scripts or replaces
        // files: Unity's own import window opens for it, where the user sees the list and decides.
        internal static void Review(ImportJob job, List<PackageEntry> entries)
        {
            // The queue's own earlier switch (the job is tried again) is decided anew; the user's own choice of Unity's
            // window stays as it is.
            if (job.reviewNote.Length > 0) job.interactive = false;
            job.reviewNote = "";
            if (job.interactive) return;
            var concern = PackageCheck.Of(entries).Concern();
            if (concern == null) return;
            job.interactive = true;
            job.reviewNote = $"미리 내용을 확인하지 못한 패키지라 Unity 가져오기 창을 열었어요({concern}). 내용을 보고 가져오세요.";
        }

        private static void Fail(ImportJob job, string message)
        {
            job.state = JobState.Finalizing;
            job.outcome = "failed";
            job.message = message;
            job.callbackSeen = true;
            Save();
        }

        // ---- Unity callbacks ----

        private static ImportJob Matching(string packageName)
        {
            // Unity reports the file name without its extension. Only one job imports at a time and it is matched
            // first; a late callback for a job already marked unconfirmed is taken only when nothing is importing.
            bool Named(ImportJob j) => j.packageFile.Length > 0 &&
                                       (packageName == Path.GetFileNameWithoutExtension(j.packageFile) || packageName == Path.GetFileName(j.packageFile));
            // The unconfirmed job is the one that just went unanswered in this session, for a short while: a package of
            // the same name imported by hand later (or after the editor was opened again) is not this job's result.
            bool Late(ImportJob j) => j.state == JobState.Unknown && j.id == lateJob && EditorApplication.timeSinceStartup < lateUntil && Named(j);
            return Data.jobs.FirstOrDefault(j => j.state == JobState.Importing && Named(j)) ??
                   (Data.jobs.Any(j => j.state == JobState.Importing) ? null : Data.jobs.FirstOrDefault(Late));
        }

        private static void OnStarted(string packageName)
        {
            var job = Matching(packageName);
            if (job != null && job.state == JobState.Unknown)
            {
                // The job's own import had started before it went unanswered. An import that starts now, by the same
                // name, is another one (by hand): neither it nor its result is the answer the job is owed.
                lateJob = null;
                job = null;
            }
            collecting = new List<string>();
            collectingJob = job?.id;
        }

        private static void OnCompleted(string packageName) => Record(packageName, "completed", "");
        private static void OnFailed(string packageName, string error) => Record(packageName, "failed", error);
        private static void OnCancelled(string packageName) => Record(packageName, "cancelled", "");

        private static void Record(string packageName, string outcome, string error)
        {
            var job = Matching(packageName);
            var paths = collecting ?? new List<string>();
            var forJob = job != null && (collectingJob == null || collectingJob == job.id);
            collecting = null;
            collectingJob = null;
            if (job == null)
            {
                // Imported from outside the queue (double-clicked, dragged in): its new folders become proposals, without
                // claiming which package made them.
                if (outcome == "completed") ProposeFrom(Products(Topmost(paths.Where(AssetDatabase.IsValidFolder))), packageName, "");
                return;
            }
            job.callbackSeen = true;
            job.outcome = outcome;
            if (error.Length > 0) job.message = error;
            if (forJob) job.imported = paths.Distinct().ToList();
            if (job.state == JobState.Unknown) job.message = "늦게 온 결과를 받았어요.";
            job.state = JobState.Finalizing;
            Save();
        }

        internal sealed class Collector : AssetPostprocessor
        {
            private static void OnPostprocessAllAssets(string[] imported, string[] deleted, string[] moved, string[] movedFrom)
            {
                collecting?.AddRange(imported);
            }
        }

        // ---- Finishing a job ----

        private static double finalizeRetry;
        private const string RecordFailed = "가져오기 결과를 저장하지 못해 멈췄어요. 디스크와 권한을 확인하면 다시 시도해요.";

        // The result is saved before the temporary copy goes and before the job counts as finished: if saving fails,
        // the queue stops here and tries again a few seconds later instead of moving on without a record.
        private static void Finalize(ImportJob job)
        {
            var now = EditorApplication.timeSinceStartup;
            if (now < finalizeRetry) return;
            if (!job.recorded)
            {
                if (job.outcome == "completed")
                {
                    var created = job.expectedFolders.Where(f => !job.existedBefore.Contains(f) && AssetDatabase.IsValidFolder(f))
                        .Concat(job.imported.Where(AssetDatabase.IsValidFolder).Where(f => !job.existedBefore.Contains(f)));
                    job.created = Topmost(created);
                    // Not lower than before: when saving the result failed and this runs again, the proposal made the
                    // first time is already there and counts as nothing new.
                    job.proposed = Math.Max(job.proposed, ProposeFrom(Products(job.created), Path.GetFileNameWithoutExtension(job.source.PackageName), job.source.PackageName));
                }
                var history = AssetStore.State.history;
                if (history.All(h => h.job != job.id))
                {
                    history.Add(new ImportRecord
                    {
                        job = job.id,
                        package = job.source.PackageName,
                        source = job.source.Describe(),
                        size = job.source.size,
                        time = AssetStore.Now,
                        result = job.outcome,
                        createdFolders = job.created.ToList(),
                    });
                    if (history.Count > 200) history.RemoveRange(0, history.Count - 200);
                }
                job.recorded = true;
                if (!AssetStore.SaveState() || !Save())
                {
                    job.recorded = false;
                    finalizeRetry = now + 5;
                    data.running = false;
                    data.pauseReason = RecordFailed;
                    Changed?.Invoke();
                    return;
                }
            }
            Cleanup(job);
            switch (job.outcome)
            {
                case "completed":
                    job.state = JobState.Done;
                    if (job.message.Length == 0 || job.message == job.reviewNote)
                        job.message = job.proposed > 0 ? $"새 폴더 {job.proposed}개를 에셋 후보로 올렸어요."
                            : job.created.Count > 0 ? "새 폴더가 이미 있는 에셋이나 후보의 것이라 후보로 올리지 않았어요."
                            : "기존 폴더 안으로 가져왔어요.";
                    break;
                case "cancelled":
                    job.state = JobState.Cancelled;
                    job.message = "가져오기 창에서 취소했어요.";
                    break;
                default:
                    job.state = JobState.Failed;
                    if (job.message.Length == 0) job.message = "가져오지 못했어요.";
                    break;
            }
            if (!Save())
            {
                // Recorded already: the job is not imported again, only its finished state waits to be written.
                finalizeRetry = now + 5;
                data.running = false;
                data.pauseReason = RecordFailed;
                Changed?.Invoke();
            }
            else if (data.pauseReason == RecordFailed)
            {
                data.pauseReason = "결과를 저장했어요. 시작을 누르면 이어서 가져와요.";
                Save();
            }
        }

        private static void Cleanup(ImportJob job)
        {
            // Only the job's own folder under Temp is ever deleted, whatever path the queue file carries.
            if (OwnTemp(job)) TryDeleteFolder(job.tempFolder);
            if (job.temporary) job.packageFile = "";
        }

        private static bool OwnTemp(ImportJob job)
        {
            if (job.tempFolder.Length == 0 || !ValidId(job.id)) return false;
            try
            {
                return string.Equals(Path.GetFullPath(job.tempFolder), Path.GetFullPath(Path.Combine(AssetStore.TempFolder, job.id)),
                    StringComparison.OrdinalIgnoreCase);
            }
            catch (Exception e) when (e is ArgumentException || e is NotSupportedException || e is IOException)
            {
                return false;
            }
        }

        private static void TryDeleteFolder(string folder)
        {
            try { if (Directory.Exists(folder)) Directory.Delete(folder, true); }
            catch (IOException) { }
            catch (UnauthorizedAccessException) { }
        }

        private static List<string> Topmost(IEnumerable<string> folders) =>
            UnityPackageReader.Topmost(folders.Where(f => f.StartsWith("Assets/", StringComparison.Ordinal)));

        // The product folders among what an import made: a new folder that only holds other folders (a shop's folder
        // made along with its first product) is not the product, and proposing it would take the whole shop for one
        // asset, with every later product of that shop landing inside it.
        private static List<string> Products(List<string> created) => created.SelectMany(FolderProposals.Products).Distinct().ToList();

        // One proposal per import: a package that makes two folders is still one product. Folders that already belong
        // to an asset or a proposal are left out, so reimporting adds nothing. Returns how many folders it proposed.
        private static int ProposeFrom(List<string> folders, string name, string package)
        {
            var guids = folders.Select(AssetDatabase.AssetPathToGUID).Where(g => g.Length > 0)
                .Where(g => AssetStore.OwnerOf(g) == null && AssetStore.Project.assets.All(a => !a.sharedFolders.Contains(g)))
                .Where(g => AssetStore.State.proposals.All(p => !p.folders.Contains(g)))
                .Where(g => !AssetStore.State.ignoredFolders.Contains(g)).ToList();
            if (guids.Count == 0) return 0;
            var proposal = new Proposal
            {
                name = string.IsNullOrWhiteSpace(name) ? Path.GetFileName(AssetDatabase.GUIDToAssetPath(guids[0])) : name,
                folders = guids,
                package = package ?? "",
                time = AssetStore.Now,
            };
            AssetStore.State.proposals.Add(proposal);
            AssetStore.SaveState();
            BoothLinker.SearchOnce(proposal.id, proposal.name, guids.Select(AssetDatabase.GUIDToAssetPath), proposal.package);
            return guids.Count;
        }
    }
}
