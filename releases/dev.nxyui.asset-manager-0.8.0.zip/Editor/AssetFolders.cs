using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;
using VRC.SDK3.Avatars.Components;

namespace NXYUI.AssetManager
{
    // Which folders make an asset. The user decides; found folders only become proposals until confirmed.
    internal static class AssetFolders
    {
        // Why a folder cannot become (part of) an asset, or null when it can.
        public static string Problem(string folderPath, AssetRecord except = null, bool shared = false)
        {
            if (!AssetDatabase.IsValidFolder(folderPath)) return "프로젝트의 폴더가 아니에요.";
            if (folderPath == "Assets" || !folderPath.StartsWith("Assets/", StringComparison.Ordinal))
                return "Assets 안의 폴더만 에셋으로 지정할 수 있어요.";
            var guid = AssetDatabase.AssetPathToGUID(folderPath);
            if (shared) return null;
            var owner = AssetStore.OwnerOf(guid);
            if (owner != null && owner != except) return $"이미 '{owner.name}' 에셋의 폴더예요.";
            foreach (var asset in AssetStore.Project.assets)
            {
                if (asset == except) continue;
                foreach (var path in asset.folders.Select(AssetDatabase.GUIDToAssetPath).Where(p => p.Length > 0))
                {
                    if (folderPath.StartsWith(path + "/", StringComparison.Ordinal)) return $"'{asset.name}' 에셋의 폴더 안에 있어요.";
                    if (path.StartsWith(folderPath + "/", StringComparison.Ordinal)) return $"안에 '{asset.name}' 에셋의 폴더가 있어요.";
                }
            }
            return null;
        }

        public static AssetRecord Create(IEnumerable<string> folderPaths, string name, string package = "")
        {
            var paths = folderPaths.Distinct().ToList();
            var problem = paths.Select(p => Problem(p)).FirstOrDefault(p => p != null);
            if (problem != null) throw new InvalidOperationException(problem);
            var asset = new AssetRecord
            {
                name = string.IsNullOrWhiteSpace(name) ? Path.GetFileName(paths.FirstOrDefault() ?? "") : name.Trim(),
                folders = paths.Select(AssetDatabase.AssetPathToGUID).ToList(),
                package = package ?? "",
                added = AssetStore.Now,
            };
            asset.kind = GuessKind(asset);
            AssetStore.Project.assets.Add(asset);
            // The record first: if it cannot be written, the asset is not made and its proposal stays.
            if (!AssetStore.SaveProject())
            {
                AssetStore.Project.assets.Remove(asset);
                throw new InvalidOperationException("에셋 기록(ProjectSettings/Packages/dev.nxyui.asset-manager/Settings.json)을 저장하지 못했어요. 디스크와 권한을 확인해 주세요.");
            }
            // Folders confirmed here are no longer proposed; a proposal keeps the folders that were not taken.
            var guids = new HashSet<string>(asset.folders);
            foreach (var proposal in AssetStore.State.proposals) proposal.folders.RemoveAll(guids.Contains);
            AssetStore.State.proposals.RemoveAll(p => p.folders.Count == 0);
            AssetStore.SaveState();
            return asset;
        }

        public static void AddFolder(AssetRecord asset, string folderPath, bool shared)
        {
            var problem = Problem(folderPath, asset, shared);
            if (problem != null) throw new InvalidOperationException(problem);
            var guid = AssetDatabase.AssetPathToGUID(folderPath);
            var list = shared ? asset.sharedFolders : asset.folders;
            if (!list.Contains(guid)) list.Add(guid);
            (shared ? asset.folders : asset.sharedFolders).Remove(guid);
            AssetStore.SaveProject();
        }

        public static void RemoveFolder(AssetRecord asset, string guid)
        {
            asset.folders.Remove(guid);
            asset.sharedFolders.Remove(guid);
            AssetStore.SaveProject();
        }

        public static void Delete(AssetRecord asset)
        {
            AssetStore.Project.assets.Remove(asset);
            AssetStore.State.searches.RemoveAll(s => s.owner == asset.id);
            AssetStore.SaveState();
            AssetStore.SaveProject();
        }

        public static string[] ExistingFolders(AssetRecord asset) =>
            asset.AllFolders.Select(AssetDatabase.GUIDToAssetPath).Where(AssetDatabase.IsValidFolder).ToArray();

        public static List<GameObject> Prefabs(AssetRecord asset)
        {
            var folders = asset.folders.Select(AssetDatabase.GUIDToAssetPath).Where(AssetDatabase.IsValidFolder).ToArray();
            if (folders.Length == 0) return new List<GameObject>();
            return AssetDatabase.FindAssets("t:Prefab", folders)
                .Select(AssetDatabase.GUIDToAssetPath).Distinct()
                .Select(AssetDatabase.LoadAssetAtPath<GameObject>).Where(p => p).ToList();
        }

        // A first guess at what the asset is, from its prefabs and files. The user can change it.
        public static AssetKind GuessKind(AssetRecord asset)
        {
            var folders = asset.folders.Select(AssetDatabase.GUIDToAssetPath).Where(AssetDatabase.IsValidFolder).ToArray();
            if (folders.Length == 0) return AssetKind.Other;
            var prefabs = Prefabs(asset);
            if (prefabs.Any(p => p.GetComponent<VRCAvatarDescriptor>())) return AssetKind.Avatar;
            if (prefabs.Any(HasArmature)) return AssetKind.Outfit;
            if (prefabs.Count > 0) return AssetKind.Accessory;
            var code = AssetDatabase.FindAssets("t:MonoScript t:Shader", folders);
            return code.Length > 0 ? AssetKind.Tool : AssetKind.Other;
        }

        // An outfit carries its own armature: a Hips bone with skinned meshes next to it.
        public static bool HasArmature(GameObject prefab)
        {
            if (!prefab || !prefab.GetComponentInChildren<SkinnedMeshRenderer>(true)) return false;
            return FindHips(prefab.transform) != null;
        }

        public static Transform FindHips(Transform root)
        {
            var animator = root.GetComponent<Animator>();
            if (animator && animator.isHuman)
            {
                var hips = animator.GetBoneTransform(HumanBodyBones.Hips);
                if (hips) return hips;
            }
            foreach (Transform child in root)
                foreach (Transform bone in child)
                    if (bone.name.IndexOf("hips", StringComparison.OrdinalIgnoreCase) >= 0) return bone;
            return null;
        }

        private static readonly Dictionary<string, (long Bytes, int Files, double Time)> Sizes = new Dictionary<string, (long, int, double)>();

        // Total size of the asset's own folders on disk, cached for a minute.
        public static (long Bytes, int Files) Size(AssetRecord asset)
        {
            var now = EditorApplication.timeSinceStartup;
            if (Sizes.TryGetValue(asset.id, out var cached) && now - cached.Time < 60) return (cached.Bytes, cached.Files);
            long bytes = 0;
            var files = 0;
            foreach (var folder in ExistingFolders(asset).Where(f => asset.folders.Contains(AssetDatabase.AssetPathToGUID(f))))
            {
                try
                {
                    foreach (var file in Directory.EnumerateFiles(folder, "*", SearchOption.AllDirectories))
                    {
                        if (file.EndsWith(".meta", StringComparison.OrdinalIgnoreCase)) continue;
                        bytes += new FileInfo(file).Length;
                        files++;
                    }
                }
                catch (IOException) { }
                // A subfolder that may not be read: the size counts what could be read, and drawing goes on.
                catch (UnauthorizedAccessException) { }
            }
            Sizes[asset.id] = (bytes, files, now);
            return (bytes, files);
        }

        public static void ForgetSizes() => Sizes.Clear();

        public static string FormatSize(long bytes)
        {
            if (bytes >= 1L << 30) return $"{bytes / (double)(1L << 30):0.0} GB";
            if (bytes >= 1L << 20) return $"{bytes / (double)(1L << 20):0.0} MB";
            return $"{Math.Max(1, bytes / 1024)} KB";
        }
    }
}
