using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using UnityEditor;
using UnityEngine;

namespace NXYUI.AssetManager
{
    internal enum AssetKind { Other, Avatar, Outfit, Accessory, Tool }

    // One purchased product as the user confirmed it: the folders it owns and, when linked, its Booth product.
    [Serializable]
    internal sealed class AssetRecord
    {
        public string id = Guid.NewGuid().ToString("N");
        public string name = "";
        public AssetKind kind;
        // Folders that belong to this asset alone, and shared folders (a shop's common folder) that several assets use.
        public List<string> folders = new List<string>();
        public List<string> sharedFolders = new List<string>();
        public long boothId;
        public string boothName = "";
        public string package = "";
        public long added;
        // The user said it is not sold on Booth (a GitHub tool, their own work): no search, not in the link wizard.
        public bool noBooth;

        public IEnumerable<string> AllFolders => folders.Concat(sharedFolders);
    }

    // What the user confirmed, kept with the project: ProjectSettings/Packages/dev.nxyui.asset-manager/Settings.json.
    [Serializable]
    internal sealed class ProjectData
    {
        public int version = 1;
        public List<AssetRecord> assets = new List<AssetRecord>();
    }

    // A folder the tool found but the user has not confirmed as an asset yet.
    [Serializable]
    internal sealed class Proposal
    {
        public string id = Guid.NewGuid().ToString("N");
        public string name = "";
        public List<string> folders = new List<string>();
        public string package = "";
        public long time;
    }

    // Booth search results kept per asset or proposal so a window reopen does not search again.
    [Serializable]
    internal sealed class SearchCache
    {
        public string owner = "";
        public string query = "";
        public long readmeItem;
        // Candidates that came from (or belong to) the asset's shop, and that shop's name, for the "같은 샵" label.
        public List<long> shopItems = new List<long>();
        public string shop = "";
        // Products of that shop left out because they need Booth's age check (they are linked by address).
        public int adultHidden;
        // How the search was made (BoothLinker.SearchScope); an older one is made again once, automatically.
        public int scope;
        // The candidate to choose in advance (BoothLinker.Recommend); 0 when none stands out. Never linked by itself.
        public long recommended;
        public List<BoothItem> results = new List<BoothItem>();
        public string error = "";
        public long time;
        // False while the search runs: a search cut off by a domain reload is started again instead of reading as
        // "nothing found".
        public bool done;
    }

    [Serializable]
    internal sealed class ImportRecord
    {
        public string job = "";
        public string package = "";
        public string source = "";
        public long size;
        public long time;
        public string result = "";
        public List<string> createdFolders = new List<string>();
    }

    [Serializable]
    internal sealed class RecentBones
    {
        public string avatar = "";
        public List<string> paths = new List<string>();
    }

    // Per-project working state that can be rebuilt or dropped: Library/NXYUI/AssetManager/State.json.
    [Serializable]
    internal sealed class LocalState
    {
        public int version = 1;
        public List<Proposal> proposals = new List<Proposal>();
        public List<string> ignoredFolders = new List<string>();
        public List<SearchCache> searches = new List<SearchCache>();
        public List<ImportRecord> history = new List<ImportRecord>();
        public List<RecentBones> recentBones = new List<RecentBones>();
        public string lastImportFolder = "";
        public bool importRecursive = true;
        // The folder the 폴더 지정 tab looks for product folders under.
        public string scanRoot = "Assets";
    }

    // A hint shared by all projects on this PC: this package file or folder name was linked to this Booth product.
    // Only a search hint: it never links an asset by itself.
    [Serializable]
    internal sealed class LinkHint
    {
        public string key = "";
        public long boothId;
        public long time;
    }

    [Serializable]
    internal sealed class SharedData
    {
        public int version = 1;
        public List<BoothItem> items = new List<BoothItem>();
        public List<LinkHint> hints = new List<LinkHint>();
    }

    internal static class AssetStore
    {
        private const string ProjectFile = "ProjectSettings/Packages/dev.nxyui.asset-manager/Settings.json";
        private const string StateFile = "Library/NXYUI/AssetManager/State.json";
        public const string TempFolder = "Temp/NXYUIAssetManager";

        private static ProjectData project;
        // The project file as last read or written here, to notice a change from outside (a pull, another tool).
        private static DateTime projectStamp;
        private static double projectChecked = -10;
        // The file was there but could not be opened: nothing is saved over it until it reads again.
        private static bool projectUnread;
        private static LocalState state;
        private static SharedData shared;
        private static DateTime sharedStamp;

        public static event Action Changed;

        // The settings file is the record: when it changes on disk while the editor is open (version control, a copy from
        // another machine), it is taken in instead of being overwritten by the next save. Looked at every two seconds,
        // and before every save.
        public static ProjectData Project =>
            project != null && EditorApplication.timeSinceStartup - projectChecked < 2 ? project : Follow();

        // Each asset as the file had it when it was last read or written (JSON by id). It tells a change made here from
        // a change made on disk when the two have to be put together.
        private static Dictionary<string, string> projectBase = new Dictionary<string, string>();

        private static void RememberBase(ProjectData on) =>
            projectBase = on.assets.GroupBy(a => a.id).ToDictionary(g => g.Key, g => JsonUtility.ToJson(g.First()));

        // Looks at the file now: read on first use, put together with what is in memory when it changed on disk.
        private static ProjectData Follow()
        {
            projectChecked = EditorApplication.timeSinceStartup;
            var stamp = Stamp(ProjectFile);
            if (project != null && stamp == projectStamp && !projectUnread) return project;
            var first = project == null;
            // While it stays unreadable it is tried again on every look, but said only once.
            var loaded = Load<ProjectData>(ProjectFile, out var unread, projectUnread);
            if (unread)
            {
                // Its content is unknown for now: nothing is saved over it until it reads (SaveProject).
                projectUnread = true;
                return project ?? (project = new ProjectData());
            }
            // Also for a file that is not valid JSON: it was copied aside once, and is not read again every time.
            projectStamp = stamp;
            projectUnread = false;
            if (loaded != null)
            {
                if (first)
                {
                    project = loaded;
                    RememberBase(loaded);
                }
                else
                {
                    Merge(loaded);
                    EditorApplication.delayCall += () => Changed?.Invoke();
                }
            }
            return project ?? (project = new ProjectData());
        }

        // Puts what the file holds now together with what is in memory, asset by asset, and keeps the objects the
        // windows hold (a detail pane keeps editing the record it shows). An asset changed only on disk takes the
        // disk's values; one changed, added or removed here since the last read or write stands as it is here, also
        // over a change on disk: it is the user's latest action, and it is about to be saved.
        private static void Merge(ProjectData disk)
        {
            var theirs = disk.assets.GroupBy(a => a.id).ToDictionary(g => g.Key, g => g.First());
            var mine = project.assets;
            for (var i = mine.Count - 1; i >= 0; i--)
            {
                var asset = mine[i];
                var changedHere = !projectBase.TryGetValue(asset.id, out var was) || JsonUtility.ToJson(asset) != was;
                if (changedHere) continue;
                if (theirs.TryGetValue(asset.id, out var other)) JsonUtility.FromJsonOverwrite(JsonUtility.ToJson(other), asset);
                else mine.RemoveAt(i);
            }
            var have = new HashSet<string>(mine.Select(a => a.id));
            // New on disk. One that was known before and is gone from memory was removed here, and stays removed.
            foreach (var other in disk.assets)
                if (!projectBase.ContainsKey(other.id) && have.Add(other.id)) mine.Add(other);
            RememberBase(disk);
        }

        public static LocalState State => state ?? (state = Load<LocalState>(StateFile) ?? new LocalState());

        private static DateTime Stamp(string path)
        {
            try { return File.Exists(path) ? File.GetLastWriteTimeUtc(path) : DateTime.MinValue; }
            catch (IOException) { return DateTime.MinValue; }
            catch (UnauthorizedAccessException) { return DateTime.MinValue; }
        }

        // Set by the tests: their made-up products and links must not go into the data every project on this PC shares
        // (a real asset of the same name would be offered them as an earlier link).
        internal static string SharedFolderOverride;
        public static string SharedFolder => SharedFolderOverride ??
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "NXYUI", "AssetManager");
        private static string SharedFile => Path.Combine(SharedFolder, "Shared.json");
        public static string ThumbnailFolder => Path.Combine(SharedFolder, "Thumbnails");

        private static double sharedChecked = -10;

        // Another project's editor may update the shared file; it is looked at again at most every two seconds.
        public static SharedData Shared
        {
            get
            {
                var now = EditorApplication.timeSinceStartup;
                if (shared != null && now - sharedChecked < 2) return shared;
                sharedChecked = now;
                var stamp = File.Exists(SharedFile) ? File.GetLastWriteTimeUtc(SharedFile) : DateTime.MinValue;
                if (shared == null || stamp != sharedStamp)
                {
                    shared = Load<SharedData>(SharedFile) ?? new SharedData();
                    sharedStamp = stamp;
                }
                return shared;
            }
        }

        // False when the record could not be written (callers that must not go on without it check).
        public static bool SaveProject()
        {
            // The file is looked at now, whatever the getter's rhythm: a save never goes over a change on disk that
            // has not been taken in.
            Follow();
            if (projectUnread)
            {
                Debug.LogWarning($"[Asset Manager] {ProjectFile}을(를) 아직 읽을 수 없어 저장하지 않았어요. 파일을 다른 프로그램이 쓰고 있는지 확인해 주세요.");
                Changed?.Invoke();
                return false;
            }
            var ok = Write(ProjectFile, JsonUtility.ToJson(project, true));
            if (ok)
            {
                projectStamp = Stamp(ProjectFile);
                projectChecked = EditorApplication.timeSinceStartup;
                RememberBase(project);
            }
            Changed?.Invoke();
            return ok;
        }

        public static bool SaveState()
        {
            var ok = Write(StateFile, JsonUtility.ToJson(State, true));
            Changed?.Invoke();
            return ok;
        }

        // Another project's editor may write the shared file too: take a lock file, merge what is on disk, then
        // replace it. Without the lock (another editor holding it for long) the merge still runs.
        public static void SaveShared()
        {
            using (AcquireLock(SharedFile + ".lock"))
            {
                // The object in memory, not a fresh look at the disk: waiting for the lock can outlast the two seconds
                // after which the getter reads the file again, and that would drop what was just added.
                var mine = shared ?? Shared;
                var theirs = Load<SharedData>(SharedFile);
                if (theirs != null && !ReferenceEquals(theirs, mine))
                {
                    foreach (var item in theirs.items)
                    {
                        var known = mine.items.FirstOrDefault(i => i.id == item.id);
                        if (known == null) mine.items.Add(item);
                        else if (string.IsNullOrEmpty(known.name) && !string.IsNullOrEmpty(item.name)) mine.items[mine.items.IndexOf(known)] = item;
                    }
                    foreach (var hint in theirs.hints)
                    {
                        var known = mine.hints.FirstOrDefault(h => h.key == hint.key);
                        if (known == null) mine.hints.Add(hint);
                        else if (hint.time > known.time) { known.boothId = hint.boothId; known.time = hint.time; }
                    }
                }
                Write(SharedFile, JsonUtility.ToJson(mine, true));
                if (File.Exists(SharedFile)) sharedStamp = File.GetLastWriteTimeUtc(SharedFile);
            }
            Changed?.Invoke();
        }

        private static FileStream AcquireLock(string path)
        {
            for (var attempt = 0; attempt < 20; attempt++)
            {
                try
                {
                    Directory.CreateDirectory(Path.GetDirectoryName(path) ?? ".");
                    return new FileStream(path, FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.None, 1, FileOptions.DeleteOnClose);
                }
                catch (IOException) { System.Threading.Thread.Sleep(50); }
                catch (UnauthorizedAccessException) { return null; }
            }
            return null;
        }

        public static void Reload()
        {
            project = null;
            projectBase = new Dictionary<string, string>();
            projectUnread = false;
            projectChecked = -10;
            state = null;
            shared = null;
        }

        public static long Now => DateTimeOffset.UtcNow.ToUnixTimeSeconds();

        // ---- Lookups ----

        public static AssetRecord AssetById(string id) => Project.assets.FirstOrDefault(a => a.id == id);

        public static AssetRecord OwnerOf(string folderGuid) =>
            Project.assets.FirstOrDefault(a => a.folders.Contains(folderGuid));

        // The asset whose own folder holds this project path (the deepest one wins).
        public static AssetRecord AssetAt(string path)
        {
            AssetRecord best = null;
            var bestLength = -1;
            foreach (var asset in Project.assets)
                foreach (var guid in asset.folders)
                {
                    var folder = AssetDatabase.GUIDToAssetPath(guid);
                    if (folder.Length > bestLength && (path == folder || path.StartsWith(folder + "/", StringComparison.Ordinal)))
                    {
                        best = asset;
                        bestLength = folder.Length;
                    }
                }
            return best;
        }

        public static BoothItem Item(long id) => id > 0 ? Shared.items.FirstOrDefault(i => i.id == id) : null;

        // Only products with details are kept: a link made with the ID alone (Booth gave nothing back) must not hide
        // the details another try or another project gets later.
        public static void Remember(BoothItem item)
        {
            if (item == null || item.id <= 0 || string.IsNullOrEmpty(item.name)) return;
            var items = Shared.items;
            items.RemoveAll(i => i.id == item.id);
            items.Add(item);
            SaveShared();
        }

        public static string HintKey(string name) => (name ?? "").Trim().ToLowerInvariant();

        public static void Hint(string name, long boothId)
        {
            var key = HintKey(name);
            if (key.Length == 0 || boothId <= 0) return;
            var hints = Shared.hints;
            hints.RemoveAll(h => h.key == key);
            hints.Add(new LinkHint { key = key, boothId = boothId, time = Now });
            SaveShared();
        }

        public static long HintFor(string name)
        {
            var key = HintKey(name);
            return Shared.hints.FirstOrDefault(h => h.key == key)?.boothId ?? 0;
        }

        public static SearchCache SearchFor(string owner) => State.searches.FirstOrDefault(s => s.owner == owner);

        public static SearchCache NewSearch(string owner)
        {
            State.searches.RemoveAll(s => s.owner == owner);
            var cache = new SearchCache { owner = owner, time = Now };
            State.searches.Add(cache);
            return cache;
        }

        public static List<string> RecentBonesFor(string avatar) =>
            State.recentBones.FirstOrDefault(r => r.avatar == avatar)?.paths ?? new List<string>();

        public static void RememberBone(string avatar, string path)
        {
            var entry = State.recentBones.FirstOrDefault(r => r.avatar == avatar);
            if (entry == null) State.recentBones.Add(entry = new RecentBones { avatar = avatar });
            entry.paths.Remove(path);
            entry.paths.Insert(0, path);
            if (entry.paths.Count > 5) entry.paths.RemoveRange(5, entry.paths.Count - 5);
            SaveState();
        }

        // ---- Thumbnails (shared cache; never written into the project) ----

        private static readonly Dictionary<string, Texture2D> Textures = new Dictionary<string, Texture2D>();
        private static readonly HashSet<string> Downloading = new HashSet<string>();
        private static readonly HashSet<string> FailedThumbnails = new HashSet<string>();

        // An image finished loading or failed: every view that showed a placeholder for it draws again.
        public static event Action ThumbnailsChanged;

        private static void TryDelete(string file)
        {
            try { File.Delete(file); }
            catch (IOException) { }
            catch (UnauthorizedAccessException) { }
        }

        // Booth's image host, over HTTPS on its usual port.
        internal static bool PictureHost(string url) =>
            Uri.TryCreate(url, UriKind.Absolute, out var uri) && uri.Scheme == Uri.UriSchemeHttps && uri.IsDefaultPort &&
            string.Equals(uri.Host, "booth.pximg.net", StringComparison.OrdinalIgnoreCase);

        public static Texture2D Thumbnail(string url, Action repaint)
        {
            if (string.IsNullOrEmpty(url) || FailedThumbnails.Contains(url)) return null;
            if (Textures.TryGetValue(url, out var texture) && texture) return texture;
            var file = Path.Combine(ThumbnailFolder, Hash(url) + ".img");
            if (File.Exists(file))
            {
                texture = Decode(File.ReadAllBytes(file));
                if (texture)
                {
                    Textures[url] = texture;
                    return texture;
                }
                TryDelete(file);
            }
            // The address comes from a Booth page or from a cache file: showing a card must not send a request to
            // any other place (another site, a service on this PC or in its network).
            if (!PictureHost(url))
            {
                FailedThumbnails.Add(url);
                return null;
            }
            // One try per editor session: a failed image is not asked for again on every repaint.
            if (Downloading.Add(url))
                BoothClient.Download(url, bytes =>
                {
                    Downloading.Remove(url);
                    var decoded = bytes != null && bytes.Length > 0 ? Decode(bytes) : null;
                    if (!decoded)
                    {
                        FailedThumbnails.Add(url);
                        ThumbnailsChanged?.Invoke();
                        return;
                    }
                    try
                    {
                        Directory.CreateDirectory(ThumbnailFolder);
                        File.WriteAllBytes(file, bytes);
                    }
                    catch (IOException) { }
                    catch (UnauthorizedAccessException) { }
                    Textures[url] = decoded;
                    repaint?.Invoke();
                    ThumbnailsChanged?.Invoke();
                });
            return null;
        }

        private static Texture2D Decode(byte[] bytes)
        {
            var texture = new Texture2D(2, 2, TextureFormat.RGBA32, false) { hideFlags = HideFlags.HideAndDontSave };
            if (texture.LoadImage(bytes)) return texture;
            UnityEngine.Object.DestroyImmediate(texture);
            return null;
        }

        private static string Hash(string text)
        {
            using (var sha = SHA1.Create())
                return string.Concat(sha.ComputeHash(Encoding.UTF8.GetBytes(text)).Select(b => b.ToString("x2")));
        }

        // ---- Files ----

        internal static T Load<T>(string path) where T : class => Load<T>(path, out _);

        // unread: the file exists but could not be opened (locked, no permission), so its content is still unknown.
        // A file that opens but is not valid JSON (a merge conflict, a cut-off write) is copied aside under another name
        // first, so the next save never destroys the only copy of what it held.
        internal static T Load<T>(string path, out bool unread, bool quiet = false) where T : class
        {
            unread = false;
            try
            {
                if (!File.Exists(path)) return null;
                return JsonUtility.FromJson<T>(File.ReadAllText(path, Encoding.UTF8));
            }
            catch (ArgumentException e)
            {
                var kept = KeepBroken(path);
                Debug.LogWarning($"[Asset Manager] {path}의 내용을 읽을 수 없어요({e.Message}). " +
                                 (kept != null ? $"원래 파일은 {kept}(으)로 남겨 뒀어요." : "원래 파일의 사본을 만들지 못했어요."));
                return null;
            }
            catch (Exception e) when (e is IOException || e is UnauthorizedAccessException)
            {
                unread = true;
                if (!quiet) Debug.LogWarning($"[Asset Manager] {path}을(를) 읽지 못했어요: {e.Message}");
                return null;
            }
        }

        private static string KeepBroken(string path)
        {
            try
            {
                var copy = path + ".broken-" + DateTime.Now.ToString("yyyyMMdd-HHmmss");
                File.Copy(path, copy, false);
                return copy;
            }
            catch (IOException) { return null; }
            catch (UnauthorizedAccessException) { return null; }
        }

        // Written next to the target and then swapped in, so a crash never leaves a half-written file. Returns whether
        // the file was saved; callers that must not go on without the record (the import queue) check it.
        internal static bool Write(string path, string text)
        {
            string temporary = null;
            try
            {
                var folder = Path.GetDirectoryName(path);
                if (!string.IsNullOrEmpty(folder)) Directory.CreateDirectory(folder);
                // Its own temporary name: two editors saving the shared file must not write into one file.
                temporary = path + "." + Guid.NewGuid().ToString("N").Substring(0, 8) + ".tmp";
                File.WriteAllText(temporary, text, new UTF8Encoding(false));
                // A virus scanner or the indexer can hold a file it just saw for a moment: try again a few times
                // (under a quarter of a second in all) before giving up.
                for (var attempt = 0; ; attempt++)
                    try
                    {
                        if (File.Exists(path)) File.Replace(temporary, path, null);
                        else File.Move(temporary, path);
                        return true;
                    }
                    catch (Exception e) when ((e is IOException || e is UnauthorizedAccessException) && attempt < 5)
                    {
                        System.Threading.Thread.Sleep(15 * (attempt + 1));
                    }
            }
            catch (Exception e) when (e is IOException || e is UnauthorizedAccessException)
            {
                Debug.LogWarning($"[Asset Manager] {path}에 저장하지 못했어요: {e.Message}");
                try
                {
                    if (temporary != null && File.Exists(temporary)) File.Delete(temporary);
                }
                catch (IOException) { }
                catch (UnauthorizedAccessException) { }
                return false;
            }
        }
    }
}
