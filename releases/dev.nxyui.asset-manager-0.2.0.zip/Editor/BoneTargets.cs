using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace NXYUI.AssetManager
{
    // A bone a Bone Proxy can follow, as offered in the assembly section.
    internal readonly struct BoneTarget
    {
        public readonly Transform Bone;
        public readonly string Label;
        public readonly string Group;

        public BoneTarget(Transform bone, string label, string group)
        {
            Bone = bone;
            Label = label;
            Group = group;
        }
    }

    // The bones accessories are usually attached to, best guess first: a guess from the asset's name, the bones used
    // most, bones the avatar has beyond the humanoid ones (ears, tail, chest, hair roots), then recent choices.
    internal static class BoneTargets
    {
        public const string Suggested = "추천";
        public const string Common = "자주 쓰는 뼈";
        public const string Extra = "아바타 고유 뼈";
        public const string Recent = "최근";

        private static readonly (string[] Words, HumanBodyBones[] Bones)[] NameHints =
        {
            (new[] { "帽子", "ハット", "キャップ", "hat", "cap", "beret", "ベレー", "ヘアピン", "ヘアクリップ", "hairpin", "髪飾り", "ヘアアクセ",
                     "メガネ", "眼鏡", "glasses", "megane", "ピアス", "イヤリング", "earring", "pierce", "カチューシャ", "headband",
                     "ヘッドドレス", "ティアラ", "tiara", "crown", "角", "ツノ", "horn", "halo", "ヘイロー", "マスク", "mask",
                     "모자", "안경", "귀걸이", "머리핀", "헤어핀", "머리띠", "뿔", "왕관", "헤일로" },
                new[] { HumanBodyBones.Head }),
            (new[] { "チョーカー", "choker", "ネックレス", "necklace", "首輪", "collar", "マフラー", "scarf", "초커", "목걸이", "목도리" },
                new[] { HumanBodyBones.Neck }),
            (new[] { "羽", "翼", "wing", "リュック", "バッグ", "bag", "backpack", "ランドセル", "ブローチ", "brooch", "날개", "가방", "배낭", "브로치" },
                new[] { HumanBodyBones.UpperChest, HumanBodyBones.Chest }),
            (new[] { "しっぽ", "尻尾", "シッポ", "tail", "ベルト", "belt", "꼬리", "벨트" },
                new[] { HumanBodyBones.Hips }),
            (new[] { "手袋", "グローブ", "glove", "指輪", "リング", "ring", "ブレスレット", "bracelet", "腕輪", "ネイル", "nail", "장갑", "반지", "팔찌" },
                new[] { HumanBodyBones.LeftHand, HumanBodyBones.RightHand }),
            (new[] { "靴", "シューズ", "shoe", "boots", "ブーツ", "アンクレット", "anklet", "신발", "부츠", "발찌" },
                new[] { HumanBodyBones.LeftFoot, HumanBodyBones.RightFoot }),
        };

        private static readonly HumanBodyBones[] CommonBones =
        {
            HumanBodyBones.Head, HumanBodyBones.Neck, HumanBodyBones.UpperChest, HumanBodyBones.Chest, HumanBodyBones.Hips,
            HumanBodyBones.LeftHand, HumanBodyBones.RightHand, HumanBodyBones.LeftLowerArm, HumanBodyBones.RightLowerArm,
            HumanBodyBones.LeftFoot, HumanBodyBones.RightFoot, HumanBodyBones.LeftUpperLeg, HumanBodyBones.RightUpperLeg,
            HumanBodyBones.Spine,
        };

        private static readonly (string[] Words, string Label)[] ExtraBones =
        {
            (new[] { "ear", "耳", "mimi" }, "귀"),
            (new[] { "tail", "しっぽ", "尻尾", "shippo" }, "꼬리"),
            (new[] { "breast", "bust", "mune", "胸" }, "가슴"),
            (new[] { "hair", "髪", "kami" }, "머리카락"),
        };

        public static List<BoneTarget> For(Transform avatarRoot, string assetName, IEnumerable<string> recentPaths)
        {
            var list = new List<BoneTarget>();
            var seen = new HashSet<Transform>();
            void Add(Transform bone, string label, string group)
            {
                if (bone && seen.Add(bone)) list.Add(new BoneTarget(bone, label, group));
            }

            var animator = avatarRoot ? avatarRoot.GetComponent<Animator>() : null;
            var humanoid = animator && animator.isHuman;
            Transform BoneOf(HumanBodyBones b) => humanoid ? animator.GetBoneTransform(b) : null;

            var name = (assetName ?? "").ToLowerInvariant();
            foreach (var (words, bones) in NameHints)
            {
                if (!words.Any(w => name.Contains(w.ToLowerInvariant()))) continue;
                foreach (var bone in bones)
                {
                    var t = BoneOf(bone);
                    if (!t) continue;
                    Add(t, HumanLabel(bone), Suggested);
                    // Chest stands in for UpperChest only when the avatar has none.
                    if (bone == HumanBodyBones.UpperChest) break;
                }
            }
            foreach (var bone in CommonBones)
            {
                if (bone == HumanBodyBones.Chest && BoneOf(HumanBodyBones.UpperChest)) continue;
                Add(BoneOf(bone), HumanLabel(bone), Common);
            }
            if (humanoid)
            {
                var mapped = new HashSet<Transform>(Enumerable.Range(0, (int)HumanBodyBones.LastBone)
                    .Select(i => animator.GetBoneTransform((HumanBodyBones)i)).Where(t => t));
                var hips = animator.GetBoneTransform(HumanBodyBones.Hips);
                foreach (var (words, label) in ExtraBones)
                    foreach (var bone in TopmostMatches(hips, words, mapped).Take(4))
                        Add(bone, label + " › " + bone.name, Extra);
            }
            if (avatarRoot != null)
                foreach (var path in recentPaths ?? Enumerable.Empty<string>())
                {
                    var bone = avatarRoot.Find(path);
                    if (bone) Add(bone, bone.name, Recent);
                }
            return list;
        }

        // Bones whose names hold one of the words, skipping those whose parent already matched (a chain counts once)
        // and bones Unity maps as humanoid ("UpperChest" is not a breast bone).
        private static IEnumerable<Transform> TopmostMatches(Transform root, string[] words, HashSet<Transform> mapped)
        {
            if (!root) yield break;
            var stack = new Stack<Transform>();
            stack.Push(root);
            while (stack.Count > 0)
            {
                var t = stack.Pop();
                var lower = t.name.ToLowerInvariant();
                if (!mapped.Contains(t) && words.Any(w => Contains(lower, w)))
                {
                    yield return t;
                    continue;
                }
                for (var i = t.childCount - 1; i >= 0; i--) stack.Push(t.GetChild(i));
            }
        }

        // "ear" must not match "Hear" or "Wear": Latin words need a word start (or a separator) before them.
        private static bool Contains(string name, string word)
        {
            if (word.Any(c => c > 127)) return name.Contains(word);
            for (var i = name.IndexOf(word, StringComparison.Ordinal); i >= 0; i = name.IndexOf(word, i + 1, StringComparison.Ordinal))
                if (i == 0 || !char.IsLetter(name[i - 1])) return true;
            return false;
        }

        public static string HumanLabel(HumanBodyBones bone)
        {
            switch (bone)
            {
                case HumanBodyBones.Head: return "머리 (Head)";
                case HumanBodyBones.Neck: return "목 (Neck)";
                case HumanBodyBones.UpperChest: return "윗가슴 (UpperChest)";
                case HumanBodyBones.Chest: return "가슴 (Chest)";
                case HumanBodyBones.Spine: return "척추 (Spine)";
                case HumanBodyBones.Hips: return "엉덩이 (Hips)";
                case HumanBodyBones.LeftHand: return "왼손 (LeftHand)";
                case HumanBodyBones.RightHand: return "오른손 (RightHand)";
                case HumanBodyBones.LeftLowerArm: return "왼쪽 아래팔 (LeftLowerArm)";
                case HumanBodyBones.RightLowerArm: return "오른쪽 아래팔 (RightLowerArm)";
                case HumanBodyBones.LeftFoot: return "왼발 (LeftFoot)";
                case HumanBodyBones.RightFoot: return "오른발 (RightFoot)";
                case HumanBodyBones.LeftUpperLeg: return "왼쪽 허벅지 (LeftUpperLeg)";
                case HumanBodyBones.RightUpperLeg: return "오른쪽 허벅지 (RightUpperLeg)";
                default: return bone.ToString();
            }
        }
    }
}
