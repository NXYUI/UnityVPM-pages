using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text.RegularExpressions;
using UnityEditor;
using UnityEngine;
using UnityEngine.Networking;

namespace NXYUI.AssetManager
{
    // A Booth product as this tool keeps it: enough to show a card and open its page.
    [Serializable]
    internal sealed class BoothItem
    {
        public long id;
        public string name = "";
        public string shop = "";
        public string shopUrl = "";
        public string thumbnail = "";
        public bool adult;
        public string[] tags = Array.Empty<string>();

        public string Url => "https://booth.pm/ja/items/" + id;
    }

    // Booth has no public API. Search reads the public search page and product details come from the item page's
    // ".json" form, both as a browser would. Requests go out one at a time, at least a second apart, and only when the
    // user adds an asset or asks; results are cached by the caller. Age-restricted products are not searched for (the
    // search page leaves them out) and the age check is never bypassed: such products are linked by URL.
    internal static class BoothClient
    {
        private const string Origin = "https://booth.pm/ja/";
        private const double Spacing = 1.0;
        private static readonly Queue<(string Url, Action<UnityWebRequest> Done)> Pending = new Queue<(string, Action<UnityWebRequest>)>();
        private static UnityWebRequest running;
        private static double nextSend;

        public static bool Busy => running != null || Pending.Count > 0;

        // Set by the tests: no request leaves the editor.
        internal static bool Offline;
        private const string OfflineMessage = "Booth에 연결하지 않는 상태예요.";

        public static void Search(string query, Action<List<BoothItem>, string> done)
        {
            if (Offline)
            {
                done(null, OfflineMessage);
                return;
            }
            query = (query ?? "").Replace('/', ' ').Trim();
            if (query.Length == 0)
            {
                done(new List<BoothItem>(), null);
                return;
            }
            Send(Origin + "search/" + Uri.EscapeDataString(query), request =>
            {
                if (request.result != UnityWebRequest.Result.Success) done(null, Failure(request));
                else done(ParseSearch(request.downloadHandler.text), null);
            });
        }

        public static void Fetch(long id, Action<BoothItem, string> done)
        {
            if (Offline)
            {
                done(null, OfflineMessage);
                return;
            }
            Send(Origin + "items/" + id + ".json", request =>
            {
                if (request.result != UnityWebRequest.Result.Success) done(null, Failure(request));
                else
                {
                    var item = ParseItem(request.downloadHandler.text);
                    done(item, item == null ? "상품 정보를 읽지 못했어요." : null);
                }
            });
        }

        public static void Download(string url, Action<byte[]> done)
        {
            if (Offline)
            {
                done(null);
                return;
            }
            Send(url, request => done(request.result == UnityWebRequest.Result.Success ? request.downloadHandler.data : null));
        }

        private static string Failure(UnityWebRequest request)
        {
            if (request.responseCode == 404) return "Booth에서 상품 정보를 받지 못했어요. 주소가 맞으면 정보 없이 연결할 수 있어요.";
            return "Booth에 연결하지 못했어요: " + request.error;
        }

        private static void Send(string url, Action<UnityWebRequest> done)
        {
            Pending.Enqueue((url, done));
            EditorApplication.update -= Pump;
            EditorApplication.update += Pump;
        }

        private static void Pump()
        {
            if (running != null || Pending.Count == 0)
            {
                if (running == null) EditorApplication.update -= Pump;
                return;
            }
            if (EditorApplication.timeSinceStartup < nextSend) return;
            var (url, done) = Pending.Dequeue();
            var request = UnityWebRequest.Get(url);
            request.timeout = 20;
            running = request;
            request.SendWebRequest().completed += _ =>
            {
                running = null;
                nextSend = EditorApplication.timeSinceStartup + Spacing;
                try { done(request); }
                catch (Exception e) { Debug.LogException(e); }
                finally { request.Dispose(); }
            };
        }

        // ---- Parsing (pure; covered by tests with saved pages) ----

        private static readonly Regex Card = new Regex(@"<li\b[^>]*\bclass=""item-card\b[^>]*>", RegexOptions.Compiled);
        private static readonly Regex Attribute = new Regex(@"\b(data-product-[a-z]+)=""([^""]*)""", RegexOptions.Compiled);
        private static readonly Regex Title = new Regex(@"class=""item-card__title-anchor[^""]*""[^>]*>([^<]*)<", RegexOptions.Compiled);
        private static readonly Regex ShopName = new Regex(@"class=""item-card__shop-name""[^>]*>([^<]*)<", RegexOptions.Compiled);
        private static readonly Regex Thumbnail = new Regex(@"data-original=""([^""]+)""", RegexOptions.Compiled);

        public static List<BoothItem> ParseSearch(string html)
        {
            var items = new List<BoothItem>();
            var cards = Card.Matches(html ?? "");
            for (var i = 0; i < cards.Count; i++)
            {
                var start = cards[i].Index;
                var end = i + 1 < cards.Count ? cards[i + 1].Index : html.Length;
                var card = html.Substring(start, end - start);
                var attributes = Attribute.Matches(cards[i].Value).Cast<Match>()
                    .GroupBy(m => m.Groups[1].Value).ToDictionary(g => g.Key, g => Decode(g.First().Groups[2].Value));
                if (!attributes.TryGetValue("data-product-id", out var idText) || !long.TryParse(idText, out var id)) continue;
                var title = Title.Match(card);
                var shop = ShopName.Match(card);
                var thumbnail = Thumbnail.Match(card);
                items.Add(new BoothItem
                {
                    id = id,
                    // The attribute cuts long names with "..."; the title link has them whole.
                    name = title.Success ? Decode(title.Groups[1].Value) : attributes.TryGetValue("data-product-name", out var n) ? n : "",
                    shop = shop.Success ? Decode(shop.Groups[1].Value) : attributes.TryGetValue("data-product-brand", out var b) ? b : "",
                    shopUrl = attributes.TryGetValue("data-product-brand", out var brand) && brand.Length > 0 ? $"https://{brand}.booth.pm/" : "",
                    thumbnail = thumbnail.Success ? Decode(thumbnail.Groups[1].Value) : "",
                });
            }
            return items.GroupBy(item => item.id).Select(g => g.First()).ToList();
        }

        [Serializable] private sealed class ItemJson { public long id; public string name; public bool is_adult; public ShopJson shop; public ImageJson[] images; public TagJson[] tags; }
        [Serializable] private sealed class ShopJson { public string name; public string url; }
        [Serializable] private sealed class ImageJson { public string original; public string resized; }
        [Serializable] private sealed class TagJson { public string name; }

        public static BoothItem ParseItem(string json)
        {
            ItemJson data;
            try { data = JsonUtility.FromJson<ItemJson>(json); }
            catch (ArgumentException) { return null; }
            if (data == null || data.id <= 0) return null;
            var image = data.images?.FirstOrDefault()?.original ?? "";
            return new BoothItem
            {
                id = data.id,
                name = data.name ?? "",
                shop = data.shop?.name ?? "",
                shopUrl = data.shop?.url ?? "",
                thumbnail = Sized(image),
                adult = data.is_adult,
                tags = data.tags?.Select(t => t.name).Where(t => !string.IsNullOrEmpty(t)).ToArray() ?? Array.Empty<string>(),
            };
        }

        // Booth serves a 300×300 copy of a product image under "/c/300x300_a2_g5/"; the original can be large.
        private static string Sized(string url)
        {
            const string host = "https://booth.pximg.net/";
            if (!url.StartsWith(host, StringComparison.Ordinal) || url.StartsWith(host + "c/", StringComparison.Ordinal)) return url;
            return host + "c/300x300_a2_g5/" + url.Substring(host.Length);
        }

        private static readonly Regex ItemLink = new Regex(
            @"(?:\bbooth\.pm/(?:[a-z]{2}(?:-[a-z]+)?/)?items/|[a-z0-9-]+\.booth\.pm/items/)(\d{3,12})",
            RegexOptions.Compiled | RegexOptions.IgnoreCase);

        // The product ID in a Booth URL (any language path or a shop's own address), or a bare ID.
        public static long ParseItemId(string text)
        {
            text = (text ?? "").Trim();
            if (long.TryParse(text, out var bare) && bare > 0) return bare;
            var match = ItemLink.Match(text);
            return match.Success && long.TryParse(match.Groups[1].Value, out var id) ? id : 0;
        }

        // Every product ID linked in a text (readme files often carry the product's own page).
        public static IEnumerable<long> FindItemIds(string text)
        {
            foreach (Match m in ItemLink.Matches(text ?? ""))
                if (long.TryParse(m.Groups[1].Value, out var id)) yield return id;
        }

        private static readonly Regex Bracketed = new Regex(@"【[^】]*】|\[[^\]]*\]|［[^］]*］|\([^)]*\)|（[^）]*）", RegexOptions.Compiled);
        private static readonly Regex Version = new Regex(
            @"(?i)(?:\bver(?:sion)?\.?\s*\d+(?:[._]\d+)*[a-z]?|\bv\d+(?:[._]\d+)*[a-z]?\b|\b\d+(?:\.\d+){1,3}\b)", RegexOptions.Compiled);
        private static readonly Regex Noise = new Regex(@"(?i)\b(?:unity\s*package|unitypackage|package)\b", RegexOptions.Compiled);

        // A search query from a file or folder name: no extension, version, bracketed notes or separators.
        public static string QueryFrom(string name)
        {
            var text = name ?? "";
            foreach (var extension in new[] { ".unitypackage", ".zip" })
                if (text.EndsWith(extension, StringComparison.OrdinalIgnoreCase)) text = text.Substring(0, text.Length - extension.Length);
            var stripped = Bracketed.Replace(text, " ");
            // A name that is only a bracketed note keeps its words.
            if (string.IsNullOrWhiteSpace(Clean(stripped))) stripped = Regex.Replace(text, @"[【】\[\]［］()（）]", " ");
            return Clean(stripped);
        }

        private static string Clean(string text)
        {
            // Separators first: "_" is a word character, so "Name_v1.2" would hide its version from \b.
            text = Regex.Replace(text, @"[_+＿・/\\|]+", " ");
            text = Version.Replace(text, " ");
            text = Noise.Replace(text, " ");
            text = Regex.Replace(text, @"(?<=\s|^)[-.]+|[-.]+(?=\s|$)", " ");
            return Regex.Replace(text, @"\s+", " ").Trim();
        }

        // A shorter query for a second try when the first finds nothing: the first two words.
        public static string Shorter(string query)
        {
            var words = (query ?? "").Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            return words.Length > 2 ? string.Join(" ", words.Take(2)) : words.Length == 2 ? words[0] : null;
        }

        private static string Decode(string text) => WebUtility.HtmlDecode(text ?? "").Trim();
    }
}
