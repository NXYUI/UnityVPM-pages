using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using UnityEditor;
using UnityEngine;
using UnityEngine.SceneManagement;
using VRC.SDK3.Avatars.Components;

namespace NXYUI.AssetManager
{
    // The folders under Assets that look like one product each, for the 폴더 지정 tab. A folder is judged by what it
    // holds, not by its name: a product holds asset files itself, or its subfolders are its parts (FBX, Material,
    // Texture, Prefab…, an internal "_Core", one variant per avatar, or variants sharing a name). A folder of other
    // folders is a shop or collection, and each of those is judged the same way. These are only proposals: the user
    // confirms each one, can join a whole group, or check folders by hand.
    internal static class FolderProposals
    {
        internal sealed class Group
        {
            // The folder right under Assets the proposals were found in; it may be one of them.
            internal string Top;
            internal readonly List<string> Paths = new List<string>();
        }

        internal sealed class Result
        {
            internal readonly List<Group> Groups = new List<Group>();
            internal readonly List<(string Path, string Reason)> Hidden = new List<(string, string)>();
            internal int Count => Groups.Sum(g => g.Paths.Count);
        }

        private const int MaxDepth = 4;

        private static readonly HashSet<string> ContentExtensions = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        {
            ".fbx", ".obj", ".blend", ".prefab", ".mat", ".png", ".psd", ".jpg", ".jpeg", ".tga", ".exr", ".anim", ".controller",
            ".overrideController", ".mask", ".asset", ".shader", ".cginc", ".hlsl", ".shadergraph", ".unity", ".unitypackage",
            ".cs", ".wav", ".mp3", ".ogg", ".vrm", ".mesh",
        };

        private static readonly HashSet<string> TextExtensions = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
            { ".txt", ".md", ".url", ".html", ".htm", ".rtf" };

        // Folder names that are a part of a product, not a product of their own.
        private static readonly HashSet<string> Roles = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        {
            "fbx", "model", "mesh", "mat", "material", "matcap", "tex", "texture", "png", "psd", "prefab", "anim", "animation",
            "animator", "controller", "shader", "sdr", "scene", "script", "editor", "runtime", "icon", "sound", "audio", "data",
            "ex", "extra", "sample", "demo", "doc", "document", "readme", "common", "core", "shared", "resource", "plugin", "image",
            "mask", "option", "setup", "fx", "vfx", "particle", "menu", "param", "expression", "acc", "etc", "blender", "preset",
            "install_instruction", "共通", "マテリアル", "テクスチャ", "プレハブ", "モデル",
        };

        // Part names written many ways ("Texures", "Matrerials", "Prefabs_Quest"): the start is enough.
        private static readonly string[] RolePrefixes = { "tex", "mat", "prefab", "anim", "model", "mesh", "shader", "sound", "icon", "script", "image", "preset" };

        // Unity's own special folders, right under Assets.
        private static readonly HashSet<string> Special = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
            { "Editor", "Plugins", "Resources", "Gizmos", "StreamingAssets", "Standard Assets", "Editor Default Resources" };

        // Folders tools write into the project (Modular Avatar, Gradation Baker, these packages…), by name.
        private static readonly Regex Generated = new Regex(
            @"^(ZZZ_GeneratedAssets|_DTGeneratedAssets|GeneratedGradation|PoseDeck_Generated( \d+)?|__AssemblyCheckerBuild_[0-9a-f]+|NXYUI)$",
            RegexOptions.IgnoreCase);

        internal static Result Find()
        {
            var owned = new HashSet<string>(AssetStore.Project.assets.SelectMany(a => a.AllFolders));
            var ignored = new HashSet<string>(AssetStore.State.ignoredFolders);
            var avatars = AvatarWords();
            var result = new Result();
            foreach (var top in AssetDatabase.GetSubFolders("Assets").OrderBy(p => p, StringComparer.OrdinalIgnoreCase))
            {
                var name = Path.GetFileName(top);
                var guid = AssetDatabase.AssetPathToGUID(top);
                if (owned.Contains(guid) || ignored.Contains(guid)) continue;
                if (Special.Contains(name)) { result.Hidden.Add((top, "Unity 특수 폴더예요.")); continue; }
                var group = new Group { Top = top };
                Judge(top, 1, group, result, owned, ignored, avatars);
                if (group.Paths.Count > 0) result.Groups.Add(group);
            }
            return result;
        }

        private static void Judge(string folder, int depth, Group group, Result result, HashSet<string> owned, HashSet<string> ignored,
            List<string> avatars)
        {
            var name = Path.GetFileName(folder);
            if (Generated.IsMatch(name)) { result.Hidden.Add((folder, "도구가 만든 폴더예요.")); return; }
            if (Empty(folder)) { result.Hidden.Add((folder, "빈 폴더예요.")); return; }
            var parts = AssetDatabase.GetSubFolders(folder)
                .Where(p => !Generated.IsMatch(Path.GetFileName(p)) && !Empty(p)).ToList();
            // Part of it already belongs to an asset: the rest is judged one by one.
            var blocked = AssetFolders.Problem(folder) != null;
            if (!blocked && IsProduct(folder, depth, parts, avatars))
            {
                group.Paths.Add(folder);
                return;
            }
            foreach (var part in parts.OrderBy(p => p, StringComparer.OrdinalIgnoreCase))
            {
                var guid = AssetDatabase.AssetPathToGUID(part);
                if (owned.Contains(guid) || ignored.Contains(guid)) continue;
                Judge(part, depth + 1, group, result, owned, ignored, avatars);
            }
        }

        private static bool IsProduct(string folder, int depth, List<string> parts, List<string> avatars)
        {
            if (depth >= MaxDepth || parts.Count == 0) return true;
            var files = Files(folder);
            if (files.Any(f => ContentExtensions.Contains(Path.GetExtension(f)))) return true;
            if (ReadmeProducts(files) == 1) return true;
            var names = parts.Select(Path.GetFileName).ToList();
            if (names.Any(n => IsRole(n) || n.StartsWith("_", StringComparison.Ordinal) || IsAvatarVariant(n, avatars))) return true;
            if (SharedStem(names.Where(n => !n.StartsWith("_", StringComparison.Ordinal)).ToList())) return true;
            // One product split into folders of its own names (GoGo › GoLoco, GoModel): its prefabs use the other parts.
            return parts.Count > 1 && UsesSiblings(parts);
        }

        internal static bool IsRole(string name)
        {
            var word = Regex.Replace(name, @"^[\s!@#_\-.0-9]+", "").Trim().ToLowerInvariant();
            word = Regex.Replace(word, @"[\s_\-]*(ver\.?\s*)?[0-9.]+$", "");
            if (word.Length == 0) return false;
            var first = word.Split(' ', '_', '-')[0];
            return Roles.Contains(word) || Roles.Contains(word.TrimEnd('s')) || Roles.Contains(first) || Roles.Contains(first.TrimEnd('s')) ||
                   RolePrefixes.Any(p => word.StartsWith(p, StringComparison.Ordinal));
        }

        private static bool IsAvatarVariant(string name, List<string> avatars)
        {
            var low = name.ToLowerInvariant();
            return avatars.Any(a => low == a || low.EndsWith("_" + a, StringComparison.Ordinal) || low.EndsWith(" " + a, StringComparison.Ordinal) ||
                                    low.EndsWith("-" + a, StringComparison.Ordinal));
        }

        // Variants of one product: every name starts with the same words ("Wasakura_sailor_…", "Type-…").
        private static bool SharedStem(List<string> names)
        {
            if (names.Count < 2) return false;
            var stem = names.Select(n => n.ToLowerInvariant()).Aggregate((a, b) =>
            {
                int i = 0;
                while (i < a.Length && i < b.Length && a[i] == b[i]) i++;
                return a.Substring(0, i);
            });
            var cut = stem.LastIndexOfAny(new[] { '_', '-', ' ' });
            return cut >= 3;
        }

        private static bool UsesSiblings(List<string> parts)
        {
            foreach (var part in parts)
            {
                var others = parts.Where(p => p != part).Select(p => p + "/").ToList();
                foreach (var prefab in AssetDatabase.FindAssets("t:Prefab", new[] { part }).Take(3).Select(AssetDatabase.GUIDToAssetPath))
                    if (AssetDatabase.GetDependencies(prefab, false).Any(d => others.Any(o => d.StartsWith(o, StringComparison.Ordinal))))
                        return true;
            }
            return false;
        }

        // How many Booth products the folder's own readme files link (0 when none or not readable).
        private static int ReadmeProducts(IEnumerable<string> files)
        {
            var ids = new HashSet<long>();
            foreach (var file in files.Where(f => TextExtensions.Contains(Path.GetExtension(f))).Take(10))
            {
                try
                {
                    if (new FileInfo(file).Length > 1 << 20) continue;
                    ids.UnionWith(BoothClient.FindItemIds(File.ReadAllText(file)));
                }
                catch (IOException) { }
                catch (UnauthorizedAccessException) { }
            }
            return ids.Count;
        }

        private static string[] Files(string folder)
        {
            try { return Directory.GetFiles(folder).Where(f => !f.EndsWith(".meta", StringComparison.OrdinalIgnoreCase)).ToArray(); }
            catch (IOException) { return Array.Empty<string>(); }
            catch (UnauthorizedAccessException) { return Array.Empty<string>(); }
        }

        private static bool Empty(string folder)
        {
            try { return !Directory.EnumerateFiles(folder, "*", SearchOption.AllDirectories).Any(f => !f.EndsWith(".meta", StringComparison.OrdinalIgnoreCase)); }
            catch (IOException) { return false; }
            catch (UnauthorizedAccessException) { return false; }
        }

        // Words naming the avatars in the open scenes and the avatar assets, for folders that hold one variant per avatar.
        private static List<string> AvatarWords()
        {
            var names = new List<string>();
            for (int i = 0; i < SceneManager.sceneCount; i++)
            {
                var scene = SceneManager.GetSceneAt(i);
                if (!scene.isLoaded) continue;
                foreach (var root in scene.GetRootGameObjects())
                    foreach (var avatar in root.GetComponentsInChildren<VRCAvatarDescriptor>(true))
                    {
                        names.Add(avatar.name);
                        var source = PrefabUtility.GetCorrespondingObjectFromOriginalSource(avatar.gameObject);
                        if (source) names.Add(source.name);
                    }
            }
            names.AddRange(AssetStore.Project.assets.Where(a => a.kind == AssetKind.Avatar).Select(a => a.name));
            return names.SelectMany(n => n.Split(new[] { ' ', '_', '-', '(', ')', '.', '[', ']' }, StringSplitOptions.RemoveEmptyEntries))
                .Select(w => w.ToLowerInvariant())
                .Where(w => w.Length >= 3 && w != "variant" && !w.All(char.IsDigit) && !Roles.Contains(w))
                .Distinct().ToList();
        }
    }
}
