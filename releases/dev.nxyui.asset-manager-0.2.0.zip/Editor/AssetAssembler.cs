using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using nadena.dev.modular_avatar.core;
using nadena.dev.modular_avatar.core.editor;
using nadena.dev.modular_avatar.core.menu;
using UnityEditor;
using UnityEngine;
using VRC.SDK3.Avatars.Components;
using VRC.SDK3.Avatars.ScriptableObjects;
using Control = VRC.SDK3.Avatars.ScriptableObjects.VRCExpressionsMenu.Control;
using Object = UnityEngine.Object;

namespace NXYUI.AssetManager
{
    internal enum AssemblyMode { Outfit, BoneProxy }

    internal sealed class AssemblyPlan
    {
        public VRCAvatarDescriptor Avatar;
        // An object inside the avatar (not its root) that becomes the asset's submenu, or null to create NewParentName.
        public Transform Parent;
        public string NewParentName = "";
        public GameObject Prefab;
        public AssemblyMode Mode;
        public Transform BoneTarget;
        public BoneProxyAttachmentMode Attach = BoneProxyAttachmentMode.AsChildAtRoot;
        public string ToggleName = "";
    }

    internal sealed class AssemblyResult
    {
        public GameObject Instance;
        public readonly List<string> Notes = new List<string>();
    }

    // Puts an asset's prefab on an avatar in one Undo step: as an outfit through Modular Avatar's Setup Outfit, or
    // following a bone through a Bone Proxy. The chosen parent becomes an MA submenu (children source); the asset's own
    // menus that would land in the avatar's root menu are moved into it with Menu Install Targets, and an asset without
    // any menu gets an on/off toggle there that starts on.
    internal static class AssetAssembler
    {
        // ---- Checks ----

        public static List<string> Problems(AssemblyPlan plan)
        {
            var problems = new List<string>();
            if (!plan.Avatar) problems.Add("아바타를 고르세요.");
            if (!plan.Prefab) problems.Add("넣을 프리팹을 고르세요.");
            if (problems.Count > 0) return problems;
            var root = plan.Avatar.transform;
            if (plan.Parent)
            {
                if (plan.Parent == root) problems.Add("아바타 루트가 아니라 그 아래의 오브젝트를 고르세요.");
                else if (!plan.Parent.IsChildOf(root)) problems.Add("넣을 위치는 고른 아바타 안의 오브젝트여야 해요.");
                else
                {
                    var menuProblem = ParentMenuProblem(plan.Parent.gameObject);
                    if (menuProblem != null) problems.Add(menuProblem);
                }
            }
            else if (string.IsNullOrWhiteSpace(plan.NewParentName)) problems.Add("넣을 위치를 고르거나 새로 만들 이름을 적으세요.");
            if (plan.Mode == AssemblyMode.Outfit && AssetFolders.FindHips(plan.Prefab.transform) == null)
                problems.Add("이 프리팹에는 아마추어(Hips)가 없어 Outfit으로 입힐 수 없어요. Bone Proxy를 고르세요.");
            if (plan.Mode == AssemblyMode.BoneProxy)
            {
                if (!plan.BoneTarget) problems.Add("Bone Proxy로 붙일 뼈를 고르세요.");
                else if (!plan.BoneTarget.IsChildOf(root) || plan.BoneTarget == root) problems.Add("붙일 뼈는 고른 아바타 안에 있어야 해요.");
            }
            return problems;
        }

        // Things worth knowing that do not stop the assembly.
        public static List<string> Warnings(AssemblyPlan plan)
        {
            var warnings = new List<string>();
            if (!plan.Prefab) return warnings;
            if (plan.Prefab.GetComponentsInChildren<ModularAvatarMergeAnimator>(true).Any(m => m.pathMode == MergeAnimatorPathMode.Absolute))
                warnings.Add("⚠ 아바타 루트 기준 경로로 움직이는 애니메이션(Merge Animator, Absolute)이 있어요. 넣을 위치 아래에서는 맞지 않을 수 있어요.");
            if (HasVrcFury(plan.Prefab))
                warnings.Add("VRCFury 메뉴는 하위 메뉴로 옮기지 못하고 VRCFury가 정한 곳에 생겨요. 필요하면 Avatar Customizer의 ‘옮길 위치’로 옮기세요.");
            if (plan.Mode == AssemblyMode.Outfit && plan.Avatar && plan.Prefab.GetComponent<VRCAvatarDescriptor>())
                warnings.Add("⚠ 이 프리팹은 아바타 자체(VRC Avatar Descriptor가 있음)예요.");
            return warnings;
        }

        // Why the chosen parent cannot hold the asset's submenu, or null.
        private static string ParentMenuProblem(GameObject parent)
        {
            var item = parent.GetComponent<ModularAvatarMenuItem>();
            if (item && !IsChildrenSubmenu(item))
                return $"‘{parent.name}’에는 이미 다른 메뉴(토글이나 메뉴 에셋 하위 메뉴)가 있어요. 다른 오브젝트를 고르세요.";
            if (parent.GetComponent<ModularAvatarMenuGroup>())
                return $"‘{parent.name}’에는 MA Menu Group이 있어 하위 메뉴로 만들 수 없어요. 다른 오브젝트를 고르세요.";
            if (MenuInstallTargetType != null && parent.GetComponent(MenuInstallTargetType))
                return $"‘{parent.name}’에는 MA Menu Install Target이 있어요. 다른 오브젝트를 고르세요.";
            if (item) return null;
            // From here the parent would become a new submenu. MA prefers a menu item over the installer's menu asset on
            // the same object, so that menu would vanish; and the parent's children with menus would move into it.
            var installer = parent.GetComponent<ModularAvatarMenuInstaller>();
            if (installer && installer.menuToAppend != null)
                return $"‘{parent.name}’에는 메뉴 에셋을 설치하는 MA Menu Installer가 있어요. 하위 메뉴로 바꾸면 그 메뉴가 사라지니 다른 오브젝트를 고르세요.";
            foreach (Transform child in parent.transform)
                if (child.GetComponent<MenuSource>() != null)
                    return $"‘{parent.name}’ 바로 아래 ‘{child.name}’에 이미 MA 메뉴가 있어요. 하위 메뉴로 바꾸면 그 메뉴가 옮겨지니 빈 오브젝트를 고르거나 새로 만드세요.";
            return null;
        }

        private static bool IsChildrenSubmenu(ModularAvatarMenuItem item) =>
            item.Control != null && item.Control.type == Control.ControlType.SubMenu && item.MenuSource == SubmenuSource.Children &&
            item.menuSource_otherObjectChildren == null;

        // Whether the asset brings a menu of its own (an installer with content or a menu item at its root).
        public static bool HasOwnMenu(GameObject prefab) =>
            prefab && (prefab.GetComponent<MenuSource>() != null || prefab.GetComponentsInChildren<ModularAvatarMenuInstaller>(true).Any(HasContent));

        public static bool WillMakeToggle(GameObject prefab) => prefab && !HasOwnMenu(prefab) && !HasVrcFury(prefab);

        // A short description of what the menu will look like after assembly, for the card.
        public static string DescribeMenu(AssemblyPlan plan)
        {
            if (!plan.Prefab) return "";
            var parentName = plan.Parent ? plan.Parent.name : string.IsNullOrWhiteSpace(plan.NewParentName) ? "새 오브젝트" : plan.NewParentName.Trim();
            if (HasOwnMenu(plan.Prefab))
                return $"에셋의 메뉴를 ‘{parentName}’ 하위 메뉴 안으로 넣어요.";
            if (HasVrcFury(plan.Prefab)) return $"‘{parentName}’ 하위 메뉴를 만들고, VRCFury 메뉴는 그대로 둬요.";
            var name = string.IsNullOrWhiteSpace(plan.ToggleName) ? plan.Prefab.name : plan.ToggleName.Trim();
            return $"‘{parentName}’ 하위 메뉴에 ‘{name}’ On/Off 토글을 만들어요(켜진 채 시작, 값 저장).";
        }

        // ---- Assembly ----

        public static AssemblyResult Assemble(AssemblyPlan plan)
        {
            var problems = Problems(plan);
            if (problems.Count > 0) throw new InvalidOperationException(problems[0]);
            const string undoName = "Asset Manager: 조립";
            Undo.IncrementCurrentGroup();
            var group = Undo.GetCurrentGroup();
            Undo.SetCurrentGroupName(undoName);
            var result = new AssemblyResult();
            try
            {
                var avatar = plan.Avatar;
                var root = avatar.transform;
                var parent = plan.Parent ? plan.Parent : CreateChild(root, plan.NewParentName.Trim());

                var instance = (GameObject)PrefabUtility.InstantiatePrefab(plan.Prefab, root.gameObject.scene);
                if (!instance) throw new InvalidOperationException("프리팹을 씬에 놓지 못했어요.");
                Undo.RegisterCreatedObjectUndo(instance, undoName);
                // Placed as the prefab was made, relative to the avatar root, then moved under the parent in place.
                instance.transform.SetParent(root, false);
                Undo.SetTransformParent(instance.transform, parent, true, undoName);
                result.Instance = instance;

                // An asset whose root is a menu item and installs itself would show twice once it sits directly under
                // the submenu (collected as a child and installed to the root menu): keep it one level down.
                var holder = instance;
                var rootInstaller = instance.GetComponent<ModularAvatarMenuInstaller>();
                if (instance.GetComponent<MenuSource>() != null && rootInstaller && HasContent(rootInstaller) && !IsTargeted(rootInstaller, root))
                {
                    holder = CreateChild(parent, instance.name).gameObject;
                    Undo.SetTransformParent(instance.transform, holder.transform, true, undoName);
                    result.Notes.Add($"메뉴가 두 번 생기지 않도록 ‘{holder.name}’ 오브젝트 안에 넣었어요.");
                }

                if (plan.Mode == AssemblyMode.Outfit) SetUpOutfit(instance, avatar, result);
                else
                {
                    // A prefab made for Bone Proxy may carry one already (only one is allowed): it follows the chosen bone.
                    var proxy = instance.GetComponent<ModularAvatarBoneProxy>();
                    if (proxy)
                    {
                        Undo.RecordObject(proxy, undoName);
                        result.Notes.Add("프리팹에 있던 Bone Proxy를 고른 뼈로 맞췄어요.");
                    }
                    else proxy = Undo.AddComponent<ModularAvatarBoneProxy>(instance);
                    if (!proxy) throw new InvalidOperationException("Bone Proxy를 붙이지 못했어요.");
                    proxy.target = plan.BoneTarget;
                    proxy.attachmentMode = plan.Attach;
                    if (proxy.target != plan.BoneTarget) throw new InvalidOperationException("Bone Proxy가 고른 뼈를 찾지 못했어요.");
                    EditorUtility.SetDirty(proxy);
                }
                Undo.SetCurrentGroupName(undoName);

                ConnectMenus(plan, parent.gameObject, instance, result);
                Undo.CollapseUndoOperations(group);
                return result;
            }
            catch
            {
                Undo.RevertAllDownToGroup(group);
                throw;
            }
        }

        private static Transform CreateChild(Transform parent, string name)
        {
            // "/" would split Modular Avatar's object paths.
            var go = new GameObject(name.Replace('/', '／'));
            Undo.RegisterCreatedObjectUndo(go, "Asset Manager: 조립");
            go.transform.SetParent(parent, false);
            return go.transform;
        }

        private static void SetUpOutfit(GameObject instance, VRCAvatarDescriptor avatar, AssemblyResult result)
        {
            var avatarHips = AssetFolders.FindHips(avatar.transform);
            if (!avatarHips) throw new InvalidOperationException("아바타의 Hips를 찾지 못했어요.");
            var avatarArmature = avatarHips.parent;
            var outfitHips = AssetFolders.FindHips(instance.transform);
            var existing = outfitHips ? outfitHips.parent.GetComponent<ModularAvatarMergeArmature>() : null;
            if (existing && !string.IsNullOrEmpty(existing.mergeTarget?.referencePath))
            {
                // Already set up by its maker: Setup Outfit would only confirm what is there.
                if (existing.mergeTargetObject == null)
                    throw new InvalidOperationException("이 의상은 이미 MA 설정이 돼 있지만, 합칠 대상이 이 아바타에 없어요.");
                result.Notes.Add("이미 MA 설정이 된 의상이라 Setup Outfit은 건너뛰었어요.");
                return;
            }
            SetupOutfit.SetupOutfitUI(instance);
            var outfitRoot = instance.GetComponent<ModularAvatarOutfitRoot>();
            var merge = outfitRoot && outfitRoot.armatureRoot ? outfitRoot.armatureRoot.GetComponent<ModularAvatarMergeArmature>() : null;
            if (!merge || merge.mergeTargetObject != avatarArmature.gameObject)
                throw new InvalidOperationException("Setup Outfit이 끝나지 않았어요. Modular Avatar가 띄운 안내를 확인하세요.");
        }

        private static void ConnectMenus(AssemblyPlan plan, GameObject parent, GameObject instance, AssemblyResult result)
        {
            var avatar = plan.Avatar;
            var root = avatar.transform;
            var submenu = EnsureSubmenu(parent);

            var moved = 0;
            var kept = 0;
            var hasMenu = instance.GetComponent<MenuSource>() != null;
            foreach (var installer in instance.GetComponentsInChildren<ModularAvatarMenuInstaller>(true))
            {
                if (!HasContent(installer)) continue;
                hasMenu = true;
                if (IsTargeted(installer, root)) continue;
                if (installer.installTargetMenu != null && !InAvatarMenuTree(installer.installTargetMenu, avatar))
                {
                    // It installs into a menu of its own asset: an internal link, left as it is.
                    kept++;
                    continue;
                }
                var target = CreateChild(parent.transform, UniqueName(root, installer.gameObject.name + " 메뉴")).gameObject;
                AddInstallTarget(target, installer);
                moved++;
            }
            if (moved > 0) result.Notes.Add($"에셋 메뉴 {moved}개를 ‘{parent.name}’ 안으로 옮겼어요.");
            if (kept > 0) result.Notes.Add($"에셋 안의 자기 메뉴로 들어가는 설치기 {kept}개는 그대로 뒀어요.");

            if (!hasMenu && !HasVrcFury(instance))
            {
                var label = string.IsNullOrWhiteSpace(plan.ToggleName) ? instance.name : plan.ToggleName.Trim();
                var toggle = CreateChild(parent.transform, UniqueName(root, label)).gameObject;
                var item = Undo.AddComponent<ModularAvatarMenuItem>(toggle);
                item.Control = new Control { type = Control.ControlType.Toggle, name = label, value = 1 };
                item.label = label;
                item.isSynced = true;
                item.isSaved = true;
                item.isDefault = true;
                item.automaticValue = true;
                var objectToggle = Undo.AddComponent<ModularAvatarObjectToggle>(toggle);
                var reference = new AvatarObjectReference();
                reference.Set(instance);
                objectToggle.Objects.Add(new ToggledObject { Object = reference, Active = true });
                // Off in the scene, on by default in the menu: the toggle's "on" really turns the asset on.
                Undo.RecordObject(instance, "Asset Manager: 조립");
                instance.SetActive(false);
                EditorUtility.SetDirty(item);
                EditorUtility.SetDirty(objectToggle);
                result.Notes.Add($"‘{label}’ 토글을 만들었어요. 씬에서는 꺼 두고, 메뉴에서 켜진 채 시작해요.");
            }

            // The submenu needs its own installer only when no menu already leads to it.
            var listed = IsListed(avatar, parent);
            if (listed != true)
            {
                if (listed == null && HasChildrenSubmenuAncestor(parent.transform, root))
                    result.Notes.Add("메뉴 연결을 확인하지 못했어요. 빌드 메뉴에서 하위 메뉴가 보이는지 확인하세요.");
                else if (!parent.GetComponent<ModularAvatarMenuInstaller>()) Undo.AddComponent<ModularAvatarMenuInstaller>(parent);
            }
            EditorUtility.SetDirty(submenu);
        }

        private static ModularAvatarMenuItem EnsureSubmenu(GameObject parent)
        {
            var item = parent.GetComponent<ModularAvatarMenuItem>();
            if (item) return item;
            item = Undo.AddComponent<ModularAvatarMenuItem>(parent);
            item.Control = new Control { type = Control.ControlType.SubMenu, name = parent.name };
            item.MenuSource = SubmenuSource.Children;
            item.label = "";
            item.isSynced = true;
            item.isSaved = true;
            item.automaticValue = true;
            return item;
        }

        private static bool HasContent(ModularAvatarMenuInstaller installer) =>
            installer && (installer.menuToAppend != null || installer.GetComponent<MenuSource>() != null);

        private static bool HasVrcFury(GameObject go) =>
            go.GetComponentsInChildren<Component>(true).Any(c => c && c.GetType().FullName != null && c.GetType().FullName.IndexOf("VRCFury", StringComparison.Ordinal) >= 0);

        // A name no other menu item of the avatar uses: MA names automatic parameters after the object.
        private static string UniqueName(Transform root, string name)
        {
            name = name.Replace('/', '／');
            var taken = new HashSet<string>(root.GetComponentsInChildren<Transform>(true).Select(t => t.name));
            if (!taken.Contains(name)) return name;
            for (var i = 2; ; i++)
                if (!taken.Contains($"{name} {i}")) return $"{name} {i}";
        }

        private static bool HasChildrenSubmenuAncestor(Transform t, Transform root)
        {
            for (var p = t.parent; p && p != root; p = p.parent)
            {
                var item = p.GetComponent<ModularAvatarMenuItem>();
                if (item && IsChildrenSubmenu(item)) return true;
            }
            return false;
        }

        // Whether a menu the avatar's root menu leads to is made of the parent's children, as Modular Avatar builds
        // its menu (its own preview graph). Null when that graph cannot be read (another MA version).
        private static bool? IsListed(VRCAvatarDescriptor avatar, GameObject parent)
        {
            try
            {
                var type = typeof(SetupOutfit).Assembly.GetType("nadena.dev.modular_avatar.core.editor.menu.VirtualMenu");
                var forAvatar = type?.GetMethod("ForAvatar", BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic);
                var rootProperty = type?.GetProperty("RootMenuNode", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                if (forAvatar == null || rootProperty == null) return null;
                var arguments = forAvatar.GetParameters()
                    .Select(p => p.ParameterType == typeof(VRCAvatarDescriptor) ? avatar : p.HasDefaultValue ? p.DefaultValue : null).ToArray();
                var menu = forAvatar.Invoke(null, arguments);
                if (!(rootProperty.GetValue(menu) is VirtualMenuNode start)) return null;
                // Children-source submenus are keyed by MA's internal MenuNodesUnder(root).
                var keyType = typeof(MenuSource).Assembly.GetType("nadena.dev.modular_avatar.core.menu.MenuNodesUnder");
                var keyRoot = keyType?.GetField("root", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                if (keyRoot == null) return null;
                var seen = new HashSet<VirtualMenuNode>();
                var queue = new Queue<VirtualMenuNode>();
                queue.Enqueue(start);
                while (queue.Count > 0)
                {
                    var node = queue.Dequeue();
                    if (!seen.Add(node)) continue;
                    if (node.NodeKey != null && node.NodeKey.GetType() == keyType && ReferenceEquals(keyRoot.GetValue(node.NodeKey), parent)) return true;
                    foreach (var control in node.Controls)
                        if (control.SubmenuNode != null) queue.Enqueue(control.SubmenuNode);
                }
                return false;
            }
            catch (Exception e) when (e is TargetInvocationException || e is ArgumentException || e is MemberAccessException || e is InvalidCastException)
            {
                return null;
            }
        }

        private static bool InAvatarMenuTree(VRCExpressionsMenu menu, VRCAvatarDescriptor avatar)
        {
            var seen = new HashSet<VRCExpressionsMenu>();
            var stack = new Stack<VRCExpressionsMenu>();
            if (avatar.expressionsMenu) stack.Push(avatar.expressionsMenu);
            while (stack.Count > 0)
            {
                var current = stack.Pop();
                if (!current || !seen.Add(current)) continue;
                if (current == menu) return true;
                foreach (var control in current.controls)
                    if (control.type == Control.ControlType.SubMenu && control.subMenu) stack.Push(control.subMenu);
            }
            return false;
        }

        // ---- Menu Install Target (internal to MA: reached by reflection, set through serialization) ----

        private static Type menuInstallTargetType;
        private static bool menuInstallTargetLooked;

        private static Type MenuInstallTargetType
        {
            get
            {
                if (!menuInstallTargetLooked)
                {
                    menuInstallTargetLooked = true;
                    menuInstallTargetType = typeof(ModularAvatarMenuInstaller).Assembly.GetType("nadena.dev.modular_avatar.core.ModularAvatarMenuInstallTarget");
                }
                return menuInstallTargetType;
            }
        }

        private static void AddInstallTarget(GameObject go, ModularAvatarMenuInstaller installer)
        {
            if (MenuInstallTargetType == null) throw new InvalidOperationException("이 Modular Avatar 버전에서 Menu Install Target을 찾지 못했어요.");
            var component = Undo.AddComponent(go, MenuInstallTargetType);
            var serialized = new SerializedObject(component);
            var property = serialized.FindProperty("installer");
            if (property == null) throw new InvalidOperationException("Menu Install Target의 설치기 칸을 찾지 못했어요.");
            property.objectReferenceValue = installer;
            serialized.ApplyModifiedProperties();
        }

        private static bool IsTargeted(ModularAvatarMenuInstaller installer, Transform root)
        {
            if (MenuInstallTargetType == null) return false;
            foreach (var target in root.GetComponentsInChildren(MenuInstallTargetType, true))
            {
                var property = new SerializedObject(target).FindProperty("installer");
                if (property != null && property.objectReferenceValue == installer) return true;
            }
            return false;
        }
    }
}
