using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;

namespace NXYUI.AssetManager
{
    // Finds Booth candidates for an asset or proposal and links the one the user picks. Candidates come, best first,
    // from a Booth link in the asset's own readme files, from a link made for the same package or folder name in any
    // project on this PC, and from a Booth search by name. Nothing is linked without the user's choice.
    internal static class BoothLinker
    {
        private static readonly HashSet<string> Running = new HashSet<string>();
        private static readonly string[] TextExtensions = { ".txt", ".md", ".url", ".html", ".htm", ".rtf" };

        public static event Action Updated;

        public static bool IsSearching(string owner) => Running.Contains(owner);

        private static readonly HashSet<string> Scheduled = new HashSet<string>();

        // The same, started after the current GUI pass: a window must not change what it draws in the middle of one.
        public static void SearchSoon(string owner, string name, IEnumerable<string> folderPaths, string package)
        {
            if (!Scheduled.Add(owner)) return;
            var folders = folderPaths?.ToList() ?? new List<string>();
            EditorApplication.delayCall += () =>
            {
                Scheduled.Remove(owner);
                SearchOnce(owner, name, folders, package);
            };
        }

        // The automatic search when an asset or proposal appears; it runs once per owner unless asked again (or cut
        // off by a domain reload before it finished).
        public static void SearchOnce(string owner, string name, IEnumerable<string> folderPaths, string package)
        {
            var cache = AssetStore.SearchFor(owner);
            if (cache != null && cache.done || Running.Contains(owner)) return;
            // A package file name usually names the product; one that says nothing ("Package.unitypackage") does not.
            var query = BoothClient.QueryFrom(package);
            if (query.Length < 2 || string.Equals(query, "package", StringComparison.OrdinalIgnoreCase)) query = BoothClient.QueryFrom(name);
            Search(owner, query, folderPaths, new[] { package, name }, true);
        }

        public static void Search(string owner, string query, IEnumerable<string> folderPaths, IEnumerable<string> hintKeys, bool retryShorter)
        {
            if (Running.Contains(owner)) return;
            Running.Add(owner);
            var cache = AssetStore.NewSearch(owner);
            cache.query = query ?? "";
            var ids = new List<long>();
            var readme = ReadmeItem(folderPaths);
            if (readme > 0)
            {
                cache.readmeItem = readme;
                ids.Add(readme);
            }
            foreach (var key in hintKeys ?? Enumerable.Empty<string>())
            {
                var hinted = AssetStore.HintFor(key);
                if (hinted > 0 && !ids.Contains(hinted)) ids.Add(hinted);
            }
            AssetStore.SaveState();
            Updated?.Invoke();

            void Finish(string error)
            {
                cache.error = error ?? "";
                cache.time = AssetStore.Now;
                cache.done = true;
                Running.Remove(owner);
                AssetStore.SaveState();
                Updated?.Invoke();
            }

            void SearchByName(string text, bool canRetry)
            {
                if (string.IsNullOrWhiteSpace(text))
                {
                    Finish(cache.results.Count == 0 ? "검색할 이름이 없어요. 직접 검색하거나 URL을 넣어 주세요." : null);
                    return;
                }
                BoothClient.Search(text, (results, error) =>
                {
                    if (results != null)
                        foreach (var item in results)
                            if (cache.results.All(r => r.id != item.id)) cache.results.Add(item);
                    var shorter = canRetry ? BoothClient.Shorter(text) : null;
                    if (error == null && (results == null || results.Count == 0) && shorter != null)
                    {
                        cache.query = shorter;
                        SearchByName(shorter, false);
                        return;
                    }
                    Finish(error);
                });
            }

            // Linked candidates first (readme, hints), then the search results.
            void FetchNext(int index)
            {
                if (index >= ids.Count)
                {
                    SearchByName(query, retryShorter);
                    return;
                }
                var known = AssetStore.Item(ids[index]);
                if (known != null)
                {
                    cache.results.Add(known);
                    FetchNext(index + 1);
                    return;
                }
                BoothClient.Fetch(ids[index], (item, _) =>
                {
                    if (item != null)
                    {
                        cache.results.Add(item);
                        AssetStore.Remember(item);
                    }
                    FetchNext(index + 1);
                });
            }

            FetchNext(0);
        }

        public static void Link(AssetRecord asset, BoothItem item)
        {
            asset.boothId = item.id;
            asset.boothName = item.name ?? "";
            AssetStore.Remember(item);
            foreach (var key in new[] { asset.package, asset.name }.Concat(AssetFolders.ExistingFolders(asset).Select(Path.GetFileName)))
                AssetStore.Hint(key, item.id);
            AssetStore.SaveProject();
            Updated?.Invoke();
        }

        // Links by URL or ID; when Booth gives no details (for example an age-restricted product) the link is kept
        // with the ID alone and the user's own asset name.
        public static void LinkById(AssetRecord asset, long id, Action<string> done)
        {
            var known = AssetStore.Item(id);
            if (known != null)
            {
                Link(asset, known);
                done?.Invoke(null);
                return;
            }
            BoothClient.Fetch(id, (item, error) =>
            {
                Link(asset, item ?? new BoothItem { id = id });
                done?.Invoke(item == null ? error : null);
            });
        }

        public static void Unlink(AssetRecord asset)
        {
            asset.boothId = 0;
            asset.boothName = "";
            AssetStore.SaveProject();
            Updated?.Invoke();
        }

        // Results found for a proposal carry over to the asset made from it.
        public static void Transfer(string fromOwner, string toOwner)
        {
            var cache = AssetStore.SearchFor(fromOwner);
            if (cache == null) return;
            AssetStore.State.searches.RemoveAll(s => s.owner == toOwner);
            cache.owner = toOwner;
            AssetStore.SaveState();
        }

        // The first Booth product linked in the asset's readme-like files (small text files only).
        private static long ReadmeItem(IEnumerable<string> folderPaths)
        {
            foreach (var folder in folderPaths ?? Enumerable.Empty<string>())
            {
                if (!Directory.Exists(folder)) continue;
                IEnumerable<string> files;
                try { files = Directory.EnumerateFiles(folder, "*", SearchOption.AllDirectories).Take(4000).ToList(); }
                catch (IOException) { continue; }
                foreach (var file in files.Where(f => TextExtensions.Contains(Path.GetExtension(f).ToLowerInvariant()))
                             .OrderBy(f => f.Count(c => c == '/' || c == '\\')).Take(40))
                {
                    try
                    {
                        if (new FileInfo(file).Length > 1 << 20) continue;
                        var id = BoothClient.FindItemIds(File.ReadAllText(file)).FirstOrDefault();
                        if (id > 0) return id;
                    }
                    catch (IOException) { }
                    catch (UnauthorizedAccessException) { }
                }
            }
            return 0;
        }
    }
}
