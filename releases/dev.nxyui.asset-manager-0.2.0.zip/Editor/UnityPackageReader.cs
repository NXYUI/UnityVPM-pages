using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;

namespace NXYUI.AssetManager
{
    // One asset inside a .unitypackage: its GUID, the project path it imports to, and whether it is a file (a folder
    // entry carries only its pathname).
    internal readonly struct PackageEntry
    {
        public readonly string Guid;
        public readonly string Path;
        public readonly bool IsFile;

        public PackageEntry(string guid, string path, bool isFile)
        {
            Guid = guid;
            Path = path;
            IsFile = isFile;
        }
    }

    // Lists a .unitypackage without importing it. The file is a gzip-compressed tar holding, per asset,
    // "<guid>/pathname" (the project path), "<guid>/asset" (files only) and "<guid>/asset.meta". Pure file IO, so it
    // may run off the main thread; reading a large package still has to inflate all of it.
    internal static class UnityPackageReader
    {
        private const int Block = 512;

        public static List<PackageEntry> Read(string file)
        {
            using (var stream = File.OpenRead(file)) return Read(stream);
        }

        public static List<PackageEntry> Read(Stream stream)
        {
            var paths = new Dictionary<string, string>(StringComparer.Ordinal);
            var files = new HashSet<string>(StringComparer.Ordinal);
            using (var gzip = new GZipStream(stream, CompressionMode.Decompress, leaveOpen: true))
            {
                var header = new byte[Block];
                string longName = null;
                while (ReadExactly(gzip, header, Block))
                {
                    if (header.All(b => b == 0)) break;
                    var size = ParseSize(header);
                    var padded = (size + Block - 1) / Block * Block;
                    var type = (char)header[156];
                    if (type == 'L')
                    {
                        // GNU long name: the next entry's name is this entry's data.
                        longName = Text(ReadData(gzip, size, padded)).TrimEnd('\0');
                        continue;
                    }
                    var name = longName ?? HeaderName(header);
                    longName = null;
                    if (type == 'x' || type == 'g')
                    {
                        // PAX headers; asset entry names are short, so the records are not needed.
                        Skip(gzip, padded);
                        continue;
                    }
                    name = name.Replace('\\', '/');
                    if (name.StartsWith("./", StringComparison.Ordinal)) name = name.Substring(2);
                    var slash = name.IndexOf('/');
                    var guid = slash > 0 ? name.Substring(0, slash) : null;
                    var leaf = slash > 0 ? name.Substring(slash + 1) : null;
                    if (leaf == "pathname")
                    {
                        var path = FirstLine(Text(ReadData(gzip, size, padded)));
                        if (path.Length > 0) paths[guid] = path.Replace('\\', '/').TrimEnd('/');
                        continue;
                    }
                    if (leaf == "asset") files.Add(guid);
                    Skip(gzip, padded);
                }
            }
            return paths.Select(p => new PackageEntry(p.Key, p.Value, files.Contains(p.Key)))
                .OrderBy(e => e.Path, StringComparer.Ordinal).ToList();
        }

        // Every folder the package's entries live in or are, including folders the package lists only implicitly.
        public static HashSet<string> Folders(IEnumerable<PackageEntry> entries)
        {
            var folders = new HashSet<string>(StringComparer.Ordinal);
            foreach (var entry in entries)
            {
                var path = entry.IsFile ? ParentOf(entry.Path) : entry.Path;
                for (; !string.IsNullOrEmpty(path) && path != "Assets" && path != "Packages"; path = ParentOf(path))
                    if (!folders.Add(path)) break;
            }
            return folders;
        }

        // The highest folders among the given ones: none of them sits inside another.
        public static List<string> Topmost(IEnumerable<string> folders)
        {
            var set = new HashSet<string>(folders, StringComparer.Ordinal);
            return set.Where(f => !Ancestors(f).Any(set.Contains)).OrderBy(f => f, StringComparer.Ordinal).ToList();
        }

        public static string ParentOf(string path)
        {
            var slash = path.LastIndexOf('/');
            return slash > 0 ? path.Substring(0, slash) : "";
        }

        private static IEnumerable<string> Ancestors(string path)
        {
            for (var p = ParentOf(path); p.Length > 0; p = ParentOf(p)) yield return p;
        }

        private static string HeaderName(byte[] header)
        {
            var name = CString(header, 0, 100);
            // ustar keeps long paths split into prefix (offset 345) and name.
            if (CString(header, 257, 5) == "ustar")
            {
                var prefix = CString(header, 345, 155);
                if (prefix.Length > 0) name = prefix + "/" + name;
            }
            return name;
        }

        private static long ParseSize(byte[] header)
        {
            if ((header[124] & 0x80) != 0)
            {
                // Base-256 size for entries of 8 GiB and more.
                long value = header[124] & 0x7f;
                for (var i = 125; i < 136; i++) value = (value << 8) | header[i];
                return value;
            }
            long size = 0;
            for (var i = 124; i < 136; i++)
            {
                var c = header[i];
                if (c == 0 || c == ' ') { if (size > 0) break; continue; }
                if (c < '0' || c > '7') throw new InvalidDataException("unitypackage 헤더를 읽지 못했습니다.");
                size = size * 8 + (c - '0');
            }
            return size;
        }

        private static string CString(byte[] buffer, int offset, int length)
        {
            var end = offset;
            while (end < offset + length && buffer[end] != 0) end++;
            return Encoding.UTF8.GetString(buffer, offset, end - offset);
        }

        private static string Text(byte[] data)
        {
            var start = data.Length >= 3 && data[0] == 0xEF && data[1] == 0xBB && data[2] == 0xBF ? 3 : 0;
            return Encoding.UTF8.GetString(data, start, data.Length - start);
        }

        private static string FirstLine(string text)
        {
            var end = text.IndexOfAny(new[] { '\r', '\n' });
            return (end >= 0 ? text.Substring(0, end) : text).Trim();
        }

        private static byte[] ReadData(Stream stream, long size, long padded)
        {
            if (size > 1 << 20) throw new InvalidDataException("unitypackage 항목 이름이 너무 깁니다.");
            var data = new byte[size];
            if (!ReadExactly(stream, data, (int)size)) throw new EndOfStreamException();
            Skip(stream, padded - size);
            return data;
        }

        private static readonly byte[] Discard = new byte[81920];

        private static void Skip(Stream stream, long count)
        {
            while (count > 0)
            {
                var read = stream.Read(Discard, 0, (int)Math.Min(Discard.Length, count));
                if (read <= 0) throw new EndOfStreamException();
                count -= read;
            }
        }

        private static bool ReadExactly(Stream stream, byte[] buffer, int count)
        {
            var total = 0;
            while (total < count)
            {
                var read = stream.Read(buffer, total, count - total);
                if (read <= 0) return false;
                total += read;
            }
            return true;
        }
    }
}
