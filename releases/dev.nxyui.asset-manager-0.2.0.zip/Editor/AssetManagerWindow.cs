using System;
using System.Linq;
using UnityEditor;
using UnityEngine;
using static NXYUI.AssetManager.AssetGui;

namespace NXYUI.AssetManager
{
    // Window shell: menu entry, tabs and shared drawing helpers. The tabs live in the partial files next to this one.
    internal sealed partial class AssetManagerWindow : EditorWindow
    {
        // Every NXYUI package puts its windows under the top-level "NXYUI" menu (checked by tools/test_build_repo.py).
        private const string MenuPath = "NXYUI/Asset Manager";
        private static readonly string[] TabNames = { "에셋", "가져오기", "폴더 지정" };

        [SerializeField] private int tab;

        [MenuItem(MenuPath)]
        private static void OpenFromMenu() => Open();

        internal static AssetManagerWindow Open()
        {
            // Docked next to the Inspector when it is open, like the other panels the user works beside.
            var inspector = typeof(Editor).Assembly.GetType("UnityEditor.InspectorWindow");
            var window = inspector != null ? GetWindow<AssetManagerWindow>("Asset Manager", true, inspector) : GetWindow<AssetManagerWindow>("Asset Manager");
            window.minSize = new Vector2(740, 420);
            window.Show();
            return window;
        }

        internal static void ShowAsset(AssetRecord asset)
        {
            var window = Open();
            window.tab = 0;
            window.selectedAsset = asset?.id;
            window.scrollToSelection = true;
            window.Repaint();
        }

        internal static void ShowFolders()
        {
            var window = Open();
            window.tab = 2;
            window.Repaint();
        }

        private void OnEnable()
        {
            AssetStore.Changed += Repaint;
            AssetStore.ThumbnailsChanged += Repaint;
            BoothLinker.Updated += Repaint;
            ImportQueue.Changed += Repaint;
            EditorApplication.projectChanged += OnProjectChanged;
            EditorApplication.hierarchyChanged += OnHierarchyChanged;
            EditorApplication.update += TickImportTab;
        }

        private void OnDisable()
        {
            AssetStore.Changed -= Repaint;
            AssetStore.ThumbnailsChanged -= Repaint;
            BoothLinker.Updated -= Repaint;
            ImportQueue.Changed -= Repaint;
            EditorApplication.projectChanged -= OnProjectChanged;
            EditorApplication.hierarchyChanged -= OnHierarchyChanged;
            EditorApplication.update -= TickImportTab;
        }

        private void OnProjectChanged()
        {
            AssetFolders.ForgetSizes();
            unassignedCache = null;
            Repaint();
        }

        private void OnHierarchyChanged() => Repaint();

        private void OnGUI()
        {
            using (new EditorGUILayout.HorizontalScope(EditorStyles.toolbar))
            {
                var proposals = AssetStore.State.proposals.Count;
                var labels = new[]
                {
                    $"에셋 {AssetStore.Project.assets.Count}개",
                    ImportQueue.Running ? "가져오기 (진행 중)" : "가져오기",
                    proposals > 0 ? $"폴더 지정 (제안 {proposals}개)" : "폴더 지정",
                };
                var chosen = GUILayout.Toolbar(tab, labels, EditorStyles.toolbarButton, GUILayout.ExpandWidth(false));
                GUILayout.FlexibleSpace();
                if (chosen != tab)
                {
                    // Another tab draws other controls: end this pass so Layout and the event see the same ones.
                    tab = chosen;
                    GUIUtility.ExitGUI();
                }
            }
            switch (tab)
            {
                case 0: DrawAssetsTab(); break;
                case 1: DrawImportTab(); break;
                default: DrawFoldersTab(); break;
            }
        }
    }
}
