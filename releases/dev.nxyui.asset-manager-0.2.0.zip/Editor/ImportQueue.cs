using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using UnityEditor;
using UnityEngine;

namespace NXYUI.AssetManager
{
    internal enum JobState { Waiting, Preparing, Importing, Finalizing, Done, Failed, Cancelled, Unknown, Skipped }

    [Serializable]
    internal sealed class ImportJob
    {
        public string id = Guid.NewGuid().ToString("N");
        public ImportSource source = new ImportSource();
        public bool interactive;
        public JobState state;
        // Recorded before anything is written there, so a restart can clean it up.
        public string tempFolder = "";
        public string packageFile = "";
        public bool temporary;
        public bool callbackSeen;
        public string outcome = "";
        public string message = "";
        public List<string> expectedFolders = new List<string>();
        public List<string> existedBefore = new List<string>();
        public List<string> imported = new List<string>();
        public List<string> created = new List<string>();
        public double startedAt;
        public bool recorded;

        public bool Finished => state == JobState.Done || state == JobState.Failed || state == JobState.Cancelled || state == JobState.Skipped;
    }

    [Serializable]
    internal sealed class QueueData
    {
        public int version = 1;
        public List<ImportJob> jobs = new List<ImportJob>();
        public bool running;
        public string pauseReason = "";
        public string session = "";
    }

    // Imports queued packages one at a time. Each step is written to Library/NXYUI/AssetManager/ImportQueue.json before
    // it happens, so a domain reload (a package with scripts compiles) picks the queue up where it was. A result that
    // cannot be told for sure (no callback, the editor restarted mid-import) pauses the queue as "확인 필요" and is never
    // imported again on its own; compile errors pause before the next import. A new editor session never resumes a
    // queue by itself.
    [InitializeOnLoad]
    internal static class ImportQueue
    {
        private const string QueueFile = "Library/NXYUI/AssetManager/ImportQueue.json";
        private const string SessionKey = "NXYUI.AssetManager.Session";
        private const double CallbackWait = 10;
        private const double ReloadGrace = 3;

        private static QueueData data;
        private static readonly double LoadedAt;
        private static Task<(string File, List<PackageEntry> Entries)> reading;
        private static string readingJob;
        // Paths Unity reports while a package import runs, for the job (or for an import from outside the queue).
        private static List<string> collecting;
        private static string collectingJob;

        public static event Action Changed;

        static ImportQueue()
        {
            LoadedAt = EditorApplication.timeSinceStartup;
            AssetDatabase.importPackageStarted += OnStarted;
            AssetDatabase.importPackageCompleted += OnCompleted;
            AssetDatabase.importPackageFailed += OnFailed;
            AssetDatabase.importPackageCancelled += OnCancelled;
            EditorApplication.update += Tick;
            EditorApplication.delayCall += Recover;
        }

        public static QueueData Data => data ?? (data = AssetStore.Load<QueueData>(QueueFile) ?? new QueueData());
        public static bool Running => Data.running;
        public static ImportJob Current => Data.jobs.FirstOrDefault(j => j.state == JobState.Preparing || j.state == JobState.Importing || j.state == JobState.Finalizing);
        public static int Waiting => Data.jobs.Count(j => j.state == JobState.Waiting);

        private static bool Save()
        {
            var ok = AssetStore.Write(QueueFile, JsonUtility.ToJson(Data, true));
            Changed?.Invoke();
            return ok;
        }

        // ---- Commands from the window ----

        public static void Add(ImportSource source, bool interactive, IEnumerable<string> expectedFolders)
        {
            if (Data.jobs.Any(j => !j.Finished && j.source.Key == source.Key)) return;
            Data.jobs.Add(new ImportJob { source = source, interactive = interactive, expectedFolders = expectedFolders?.ToList() ?? new List<string>() });
            Save();
        }

        public static void Remove(ImportJob job)
        {
            if (job.state != JobState.Waiting && !job.Finished && job.state != JobState.Unknown) return;
            Data.jobs.Remove(job);
            Save();
        }

        public static void Move(ImportJob job, int delta)
        {
            var list = Data.jobs;
            var index = list.IndexOf(job);
            var target = index + delta;
            if (index < 0 || target < 0 || target >= list.Count || list[target].state != JobState.Waiting || job.state != JobState.Waiting) return;
            list.RemoveAt(index);
            list.Insert(target, job);
            Save();
        }

        public static bool HasUnknown => Data.jobs.Any(j => j.state == JobState.Unknown);

        // Refused while a job waits for the user's decision: a later package of the same name could otherwise be
        // taken for it.
        public static bool Start()
        {
            if (HasUnknown)
            {
                Data.pauseReason = "‘확인 필요’ 항목을 먼저 다시 시도하거나 건너뛰세요.";
                Save();
                return false;
            }
            Data.running = true;
            Data.pauseReason = "";
            Data.session = Session;
            Save();
            return true;
        }

        public static void Pause(string reason)
        {
            Data.running = false;
            Data.pauseReason = reason ?? "";
            Save();
        }

        public static void ClearFinished()
        {
            Data.jobs.RemoveAll(j => j.Finished);
            Save();
        }

        // A job whose result was not confirmed: the user decides whether to queue it again or leave it.
        public static void Retry(ImportJob job)
        {
            if (job.state != JobState.Unknown && job.state != JobState.Failed && job.state != JobState.Cancelled) return;
            Cleanup(job);
            job.state = JobState.Waiting;
            job.callbackSeen = false;
            job.outcome = job.message = "";
            job.recorded = false;
            job.imported.Clear();
            job.created.Clear();
            Save();
        }

        public static void Skip(ImportJob job)
        {
            if (job.state != JobState.Unknown) return;
            Cleanup(job);
            job.state = JobState.Skipped;
            job.message = "결과를 확인하지 못해 건너뛰었어요.";
            Save();
        }

        // ---- Session and recovery ----

        private static string Session
        {
            get
            {
                var id = SessionState.GetString(SessionKey, "");
                if (id.Length == 0)
                {
                    id = Guid.NewGuid().ToString("N");
                    SessionState.SetString(SessionKey, id);
                }
                return id;
            }
        }

        private static void Recover()
        {
            var queue = Data;
            if (queue.session == Session) return;
            // The editor was closed and opened again.
            queue.session = Session;
            foreach (var job in queue.jobs.Where(j => j.state == JobState.Preparing || j.state == JobState.Importing))
            {
                if (job.callbackSeen) job.state = JobState.Finalizing;
                else
                {
                    job.state = JobState.Unknown;
                    job.message = "에디터가 다시 열려 가져오기 결과를 확인하지 못했어요. 프로젝트를 확인한 뒤 다시 시도하거나 건너뛰세요.";
                }
            }
            if (queue.running) queue.pauseReason = "에디터를 다시 열어 대기열을 멈췄어요. 이어서 가져오려면 시작을 누르세요.";
            queue.running = false;
            // Temporary copies from the last session that no job still needs.
            var keep = new HashSet<string>(queue.jobs.Where(j => !j.Finished).Select(j => Path.GetFullPath(j.tempFolder.Length > 0 ? j.tempFolder : ".")));
            if (Directory.Exists(AssetStore.TempFolder))
                foreach (var folder in Directory.GetDirectories(AssetStore.TempFolder))
                    if (!keep.Contains(Path.GetFullPath(folder))) TryDeleteFolder(folder);
            Save();
        }

        // ---- The loop ----

        private static void Tick()
        {
            var queue = data;
            if (queue == null && !File.Exists(QueueFile)) return;
            queue = Data;
            // A new editor session is recovered first, whichever of update and delayCall comes first.
            if (queue.session != Session)
            {
                Recover();
                return;
            }
            if (EditorApplication.isCompiling || EditorApplication.isUpdating || EditorApplication.isPlayingOrWillChangePlaymode) return;
            var now = EditorApplication.timeSinceStartup;
            var current = Current;
            if (current != null)
            {
                switch (current.state)
                {
                    case JobState.Preparing:
                        if (queue.running) Prepare(current);
                        break;
                    case JobState.Importing:
                        if (current.callbackSeen)
                        {
                            current.state = JobState.Finalizing;
                            Save();
                        }
                        else if (now - LoadedAt > ReloadGrace && NoCallbackComing(current, now))
                        {
                            current.state = JobState.Unknown;
                            current.message = "Unity가 가져오기 결과를 알려 주지 않았어요. 프로젝트를 확인한 뒤 다시 시도하거나 건너뛰세요.";
                            Pause("가져오기 결과를 확인해야 해요.");
                        }
                        break;
                    case JobState.Finalizing:
                        // Recording a result imports nothing, so it runs even while the queue is paused.
                        Finalize(current);
                        break;
                }
                return;
            }
            if (!queue.running) return;
            var next = queue.jobs.FirstOrDefault(j => j.state == JobState.Waiting);
            if (next == null)
            {
                queue.running = false;
                queue.pauseReason = "";
                Save();
                return;
            }
            if (EditorUtility.scriptCompilationFailed)
            {
                Pause("스크립트 컴파일 오류가 있어 멈췄어요. Console에서 오류를 고친 뒤 시작을 누르세요.");
                return;
            }
            Begin(next);
        }

        private static bool NoCallbackComing(ImportJob job, double now)
        {
            if (job.interactive)
            {
                // The import dialog is open while the user picks files; it also closes when Import is pressed, so a
                // closed dialog alone is not a result.
                var dialog = typeof(Editor).Assembly.GetType("UnityEditor.PackageImport");
                if (dialog != null && Resources.FindObjectsOfTypeAll(dialog).Length > 0)
                {
                    job.startedAt = now;
                    return false;
                }
            }
            return now - job.startedAt > CallbackWait;
        }

        private static void Begin(ImportJob job)
        {
            job.tempFolder = Path.Combine(AssetStore.TempFolder, job.id).Replace('\\', '/');
            job.state = JobState.Preparing;
            job.message = "";
            if (!Save())
            {
                Fail(job, "대기열 기록을 저장하지 못해 가져오지 않았어요.");
                return;
            }
            Prepare(job);
        }

        // Copying the package out of its archive and reading its list run off the main thread; Tick comes back here
        // until they are done. A domain reload in between only starts them again.
        private static void Prepare(ImportJob job)
        {
            try
            {
                if (reading == null || readingJob != job.id)
                {
                    if (job.packageFile.Length == 0 && job.source.InArchive)
                    {
                        var problem = ArchiveScanner.ExtractProblem(job.source.size, job.tempFolder);
                        if (problem != null) throw new IOException(problem);
                    }
                    var source = job.source;
                    var temp = job.tempFolder;
                    var known = job.packageFile;
                    var needList = job.expectedFolders.Count == 0;
                    readingJob = job.id;
                    reading = Task.Run(() =>
                    {
                        var file = known.Length > 0 ? known : ArchiveScanner.Materialize(source, temp, out _);
                        var entries = needList ? UnityPackageReader.Read(file) : new List<PackageEntry>();
                        return (file.Replace('\\', '/'), entries);
                    });
                    job.message = job.source.InArchive && known.Length == 0 ? "압축을 풀고 있어요…" : "패키지 내용을 확인하고 있어요…";
                    Changed?.Invoke();
                    return;
                }
                if (!reading.IsCompleted) return;
                var task = reading;
                reading = null;
                readingJob = null;
                var (packageFile, list) = task.Result;
                job.packageFile = packageFile;
                job.temporary = job.source.InArchive;
                if (job.expectedFolders.Count == 0)
                    job.expectedFolders = UnityPackageReader.Folders(list).OrderBy(f => f, StringComparer.Ordinal).ToList();
                if (!File.Exists(job.packageFile)) throw new FileNotFoundException("패키지 파일이 없어요: " + job.packageFile);
                job.existedBefore = job.expectedFolders.Where(AssetDatabase.IsValidFolder).ToList();
                job.state = JobState.Importing;
                job.startedAt = EditorApplication.timeSinceStartup;
                job.callbackSeen = false;
                job.message = "";
                if (!Save())
                {
                    Fail(job, "대기열 기록을 저장하지 못해 가져오지 않았어요.");
                    return;
                }
                collecting = new List<string>();
                collectingJob = job.id;
                AssetDatabase.ImportPackage(job.packageFile, job.interactive);
            }
            catch (Exception e) when (!(e is OutOfMemoryException))
            {
                reading = null;
                readingJob = null;
                var inner = e is AggregateException aggregate && aggregate.InnerException != null ? aggregate.InnerException : e;
                Fail(job, "가져오지 못했어요: " + inner.Message);
            }
        }

        private static void Fail(ImportJob job, string message)
        {
            job.state = JobState.Finalizing;
            job.outcome = "failed";
            job.message = message;
            job.callbackSeen = true;
            Save();
        }

        // ---- Unity callbacks ----

        private static ImportJob Matching(string packageName)
        {
            // Unity reports the file name without its extension. Only one job imports at a time and it is matched
            // first; a late callback for a job already marked unconfirmed is taken only when nothing is importing.
            bool Named(ImportJob j) => j.packageFile.Length > 0 &&
                                       (packageName == Path.GetFileNameWithoutExtension(j.packageFile) || packageName == Path.GetFileName(j.packageFile));
            return Data.jobs.FirstOrDefault(j => j.state == JobState.Importing && Named(j)) ??
                   (Data.jobs.Any(j => j.state == JobState.Importing) ? null : Data.jobs.FirstOrDefault(j => j.state == JobState.Unknown && Named(j)));
        }

        private static void OnStarted(string packageName)
        {
            var job = Matching(packageName);
            collecting = new List<string>();
            collectingJob = job?.id;
        }

        private static void OnCompleted(string packageName) => Record(packageName, "completed", "");
        private static void OnFailed(string packageName, string error) => Record(packageName, "failed", error);
        private static void OnCancelled(string packageName) => Record(packageName, "cancelled", "");

        private static void Record(string packageName, string outcome, string error)
        {
            var job = Matching(packageName);
            var paths = collecting ?? new List<string>();
            var forJob = job != null && (collectingJob == null || collectingJob == job.id);
            collecting = null;
            collectingJob = null;
            if (job == null)
            {
                // Imported from outside the queue (double-clicked, dragged in): its new folders become proposals, without
                // claiming which package made them.
                if (outcome == "completed") ProposeFrom(Topmost(paths.Where(AssetDatabase.IsValidFolder)), packageName, "");
                return;
            }
            job.callbackSeen = true;
            job.outcome = outcome;
            if (error.Length > 0) job.message = error;
            if (forJob) job.imported = paths.Distinct().ToList();
            if (job.state == JobState.Unknown) job.message = "늦게 온 결과를 받았어요.";
            job.state = JobState.Finalizing;
            Save();
        }

        internal sealed class Collector : AssetPostprocessor
        {
            private static void OnPostprocessAllAssets(string[] imported, string[] deleted, string[] moved, string[] movedFrom)
            {
                collecting?.AddRange(imported);
            }
        }

        // ---- Finishing a job ----

        private static double finalizeRetry;
        private const string RecordFailed = "가져오기 결과를 저장하지 못해 멈췄어요. 디스크와 권한을 확인하면 다시 시도해요.";

        // The result is saved before the temporary copy goes and before the job counts as finished: if saving fails,
        // the queue stops here and tries again a few seconds later instead of moving on without a record.
        private static void Finalize(ImportJob job)
        {
            var now = EditorApplication.timeSinceStartup;
            if (now < finalizeRetry) return;
            if (!job.recorded)
            {
                if (job.outcome == "completed")
                {
                    var created = job.expectedFolders.Where(f => !job.existedBefore.Contains(f) && AssetDatabase.IsValidFolder(f))
                        .Concat(job.imported.Where(AssetDatabase.IsValidFolder).Where(f => !job.existedBefore.Contains(f)));
                    job.created = Topmost(created);
                    ProposeFrom(job.created, Path.GetFileNameWithoutExtension(job.source.PackageName), job.source.PackageName);
                }
                var history = AssetStore.State.history;
                if (history.All(h => h.job != job.id))
                {
                    history.Add(new ImportRecord
                    {
                        job = job.id,
                        package = job.source.PackageName,
                        source = job.source.Describe(),
                        size = job.source.size,
                        time = AssetStore.Now,
                        result = job.outcome,
                        createdFolders = job.created.ToList(),
                    });
                    if (history.Count > 200) history.RemoveRange(0, history.Count - 200);
                }
                job.recorded = true;
                if (!AssetStore.SaveState() || !Save())
                {
                    job.recorded = false;
                    finalizeRetry = now + 5;
                    data.running = false;
                    data.pauseReason = RecordFailed;
                    Changed?.Invoke();
                    return;
                }
            }
            Cleanup(job);
            switch (job.outcome)
            {
                case "completed":
                    job.state = JobState.Done;
                    if (job.message.Length == 0)
                        job.message = job.created.Count > 0 ? $"새 폴더 {job.created.Count}개를 에셋 후보로 올렸어요." : "기존 폴더 안으로 가져왔어요.";
                    break;
                case "cancelled":
                    job.state = JobState.Cancelled;
                    job.message = "가져오기 창에서 취소했어요.";
                    break;
                default:
                    job.state = JobState.Failed;
                    if (job.message.Length == 0) job.message = "가져오지 못했어요.";
                    break;
            }
            if (!Save())
            {
                // Recorded already: the job is not imported again, only its finished state waits to be written.
                finalizeRetry = now + 5;
                data.running = false;
                data.pauseReason = RecordFailed;
                Changed?.Invoke();
            }
            else if (data.pauseReason == RecordFailed)
            {
                data.pauseReason = "결과를 저장했어요. 시작을 누르면 이어서 가져와요.";
                Save();
            }
        }

        private static void Cleanup(ImportJob job)
        {
            if (job.tempFolder.Length > 0) TryDeleteFolder(job.tempFolder);
            if (job.temporary) job.packageFile = "";
        }

        private static void TryDeleteFolder(string folder)
        {
            try { if (Directory.Exists(folder)) Directory.Delete(folder, true); }
            catch (IOException) { }
            catch (UnauthorizedAccessException) { }
        }

        private static List<string> Topmost(IEnumerable<string> folders) =>
            UnityPackageReader.Topmost(folders.Where(f => f.StartsWith("Assets/", StringComparison.Ordinal)));

        // One proposal per import: a package that makes two folders is still one product. Folders that already belong
        // to an asset or a proposal are left out, so reimporting adds nothing.
        private static void ProposeFrom(List<string> folders, string name, string package)
        {
            var guids = folders.Select(AssetDatabase.AssetPathToGUID).Where(g => g.Length > 0)
                .Where(g => AssetStore.OwnerOf(g) == null && AssetStore.Project.assets.All(a => !a.sharedFolders.Contains(g)))
                .Where(g => AssetStore.State.proposals.All(p => !p.folders.Contains(g)))
                .Where(g => !AssetStore.State.ignoredFolders.Contains(g)).ToList();
            if (guids.Count == 0) return;
            var proposal = new Proposal
            {
                name = string.IsNullOrWhiteSpace(name) ? Path.GetFileName(AssetDatabase.GUIDToAssetPath(guids[0])) : name,
                folders = guids,
                package = package ?? "",
                time = AssetStore.Now,
            };
            AssetStore.State.proposals.Add(proposal);
            AssetStore.SaveState();
            BoothLinker.SearchOnce(proposal.id, proposal.name, guids.Select(AssetDatabase.GUIDToAssetPath), proposal.package);
        }
    }
}
