using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;
using static NXYUI.AssetManager.AssetGui;

namespace NXYUI.AssetManager
{
    // The 폴더 지정 tab: folders found by imports (proposals) and folders no asset owns yet. A folder becomes an asset
    // only when the user confirms it here, in the Project window's context menu or in the folder's Inspector card.
    internal sealed partial class AssetManagerWindow
    {
        private Vector2 foldersScroll;
        private FolderProposals.Result unassignedCache;
        private readonly HashSet<string> checkedFolders = new HashSet<string>();
        private string groupName = "";
        private string foldersMessage;
        private MessageType foldersMessageType;
        private bool showIgnored, showHidden;

        private void DrawFoldersTab()
        {
            foldersScroll = EditorGUILayout.BeginScrollView(foldersScroll);
            GUILayout.Label("어떤 폴더를 에셋 하나로 볼지 정해요. Project 창에서 폴더를 우클릭하고 ‘NXYUI › 에셋으로 지정’을 눌러도 돼요.",
                EditorStyles.wordWrappedMiniLabel);
            if (!string.IsNullOrEmpty(foldersMessage)) EditorGUILayout.HelpBox(foldersMessage, foldersMessageType);
            DrawProposals();
            DrawUnassigned();
            DrawIgnored();
            EditorGUILayout.EndScrollView();
        }

        private void DrawProposals()
        {
            var proposals = AssetStore.State.proposals;
            Section($"가져오면서 찾은 후보 ({proposals.Count}개)");
            if (proposals.Count == 0)
            {
                GUILayout.Label("패키지를 가져오면 새로 생긴 폴더가 여기에 올라와요.", EditorStyles.wordWrappedMiniLabel);
                return;
            }
            foreach (var proposal in proposals.ToList())
            {
                var paths = proposal.folders.Select(AssetDatabase.GUIDToAssetPath).Where(AssetDatabase.IsValidFolder).ToList();
                using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
                {
                    using (new EditorGUILayout.HorizontalScope())
                    {
                        EditorGUI.BeginChangeCheck();
                        var name = EditorGUILayout.DelayedTextField(proposal.name);
                        if (EditorGUI.EndChangeCheck() && !string.IsNullOrWhiteSpace(name))
                        {
                            proposal.name = name.Trim();
                            AssetStore.SaveState();
                        }
                        using (new EditorGUI.DisabledScope(paths.Count == 0))
                            if (GUILayout.Button(new GUIContent("에셋으로 만들기", paths.Count == 0 ? "폴더가 없어졌어요." : ""), GUILayout.Width(110)))
                            {
                                MakeAsset(paths, proposal.name, proposal.package, proposal.id);
                                GUIUtility.ExitGUI();
                            }
                        if (GUILayout.Button(new GUIContent("무시", "다시 제안하지 않아요. 아래 ‘무시한 폴더’에서 되돌릴 수 있어요."), GUILayout.Width(44)))
                        {
                            AssetStore.State.ignoredFolders.AddRange(proposal.folders.Where(g => !AssetStore.State.ignoredFolders.Contains(g)));
                            proposals.Remove(proposal);
                            AssetStore.SaveState();
                            unassignedCache = null;
                            GUIUtility.ExitGUI();
                        }
                    }
                    foreach (var path in paths) ClippedLabel("› " + path, EditorStyles.miniLabel);
                    if (paths.Count == 0) GUILayout.Label("⚠ 폴더를 찾지 못했어요(지웠거나 옮김). ‘무시’로 지우세요.", EditorStyles.miniLabel);
                    using (new EditorGUILayout.HorizontalScope())
                    {
                        if (proposal.package.Length > 0) GUILayout.Label("가져온 패키지: " + proposal.package, EditorStyles.miniLabel);
                        var cache = AssetStore.SearchFor(proposal.id);
                        if (BoothLinker.IsSearching(proposal.id)) GUILayout.Label("Booth에서 찾는 중…", EditorStyles.miniLabel);
                        else if (cache != null && cache.results.Count > 0)
                            DrawBadge($"Booth 후보 {cache.results.Count}개", "good", "에셋으로 만든 뒤 에셋 탭에서 골라 연결해요. 첫 후보: " + cache.results[0].name);
                        GUILayout.FlexibleSpace();
                    }
                }
            }
        }

        private void DrawUnassigned()
        {
            var found = unassignedCache ?? (unassignedCache = FolderProposals.Find());
            Section($"상품으로 보이는 폴더 ({found.Count}개)");
            if (found.Count == 0)
                GUILayout.Label("Assets 안의 상품 폴더는 모두 에셋이거나 무시한 폴더예요. 다른 폴더는 Project 창에서 우클릭해 지정할 수 있어요.",
                    EditorStyles.wordWrappedMiniLabel);
            else
            {
                GUILayout.Label("폴더에 든 파일로 상품 폴더를 짐작했어요. 맞으면 ‘에셋으로 만들기’를 누르세요. 한 상품이 여러 폴더로 나뉘어 보이면 " +
                                "묶음 맨 위의 ‘전체를 에셋 하나로’를 누르거나, 폴더를 체크한 뒤 맨 아래에서 하나로 묶으세요.", EditorStyles.wordWrappedMiniLabel);
                foreach (var group in found.Groups) DrawProposalGroup(group);
                DrawCheckedGroup(found);
            }
            DrawHiddenFolders(found);
        }

        // The proposals found in one folder under Assets: the folder itself, or a header with the products inside it.
        private void DrawProposalGroup(FolderProposals.Group group)
        {
            var single = group.Paths.Count == 1 && group.Paths[0] == group.Top;
            if (!single)
            {
                GUILayout.Space(4);
                var problem = AssetFolders.Problem(group.Top);
                using (new EditorGUILayout.HorizontalScope())
                {
                    GUILayout.Label(EditorGUIUtility.IconContent("Folder Icon"), GUILayout.Width(18), GUILayout.Height(18));
                    ClippedLabel(Path.GetFileName(group.Top), EditorStyles.boldLabel, GUILayout.MinWidth(60));
                    GUILayout.Label($"상품 {group.Paths.Count}개", EditorStyles.miniLabel, GUILayout.ExpandWidth(false));
                    if (GUILayout.Button("보기", EditorStyles.miniButton, GUILayout.Width(40)))
                        EditorGUIUtility.PingObject(AssetDatabase.LoadAssetAtPath<DefaultAsset>(group.Top));
                    using (new EditorGUI.DisabledScope(problem != null))
                        if (GUILayout.Button(new GUIContent("전체를 에셋 하나로", problem ??
                                    $"‘{Path.GetFileName(group.Top)}’ 폴더 전체를 에셋 하나로 만들어요. 아래 {group.Paths.Count}개가 모두 들어가요."),
                                EditorStyles.miniButton, GUILayout.Width(110)))
                        {
                            MakeAsset(new List<string> { group.Top }, Path.GetFileName(group.Top), "", null);
                            GUIUtility.ExitGUI();
                        }
                }
                if (problem != null) GUILayout.Label("전체를 묶을 수 없어요: " + problem, EditorStyles.wordWrappedMiniLabel);
            }
            foreach (var path in group.Paths) DrawProposalRow(group, path, !single);
        }

        private void DrawProposalRow(FolderProposals.Group group, string path, bool inGroup)
        {
            var guid = AssetDatabase.AssetPathToGUID(path);
            using (new EditorGUILayout.HorizontalScope(EditorStyles.helpBox))
            {
                if (inGroup) GUILayout.Space(12);
                var on = checkedFolders.Contains(guid);
                var toggled = GUILayout.Toggle(on, new GUIContent("", "체크한 폴더를 맨 아래에서 에셋 하나로 묶을 수 있어요."), GUILayout.Width(16));
                if (toggled != on)
                {
                    if (toggled) checkedFolders.Add(guid);
                    else checkedFolders.Remove(guid);
                }
                GUILayout.Label(EditorGUIUtility.IconContent("Folder Icon"), GUILayout.Width(18), GUILayout.Height(18));
                // Inside a group, the path from the group's folder ("샵 › 상품"); alone, the folder's name.
                var shown = inGroup ? path.Substring(group.Top.Length + 1).Replace("/", " › ") : Path.GetFileName(path);
                ClippedLabel(shown, EditorStyles.label, GUILayout.MinWidth(60));
                if (GUILayout.Button(new GUIContent("보기", path), EditorStyles.miniButton, GUILayout.Width(40)))
                    EditorGUIUtility.PingObject(AssetDatabase.LoadAssetAtPath<DefaultAsset>(path));
                if (GUILayout.Button(new GUIContent("에셋으로 만들기", $"‘{Path.GetFileName(path)}’ 폴더를 상품 하나로 등록해요."), EditorStyles.miniButton, GUILayout.Width(96)))
                {
                    MakeAsset(new List<string> { path }, Path.GetFileName(path), "", null);
                    GUIUtility.ExitGUI();
                }
                if (GUILayout.Button(new GUIContent("무시", "도구·SDK 폴더처럼 상품이 아닌 폴더는 목록에서 숨겨요."), EditorStyles.miniButton, GUILayout.Width(40)))
                {
                    AssetStore.State.ignoredFolders.Add(guid);
                    checkedFolders.Remove(guid);
                    AssetStore.SaveState();
                    unassignedCache = null;
                    GUIUtility.ExitGUI();
                }
            }
        }

        private void DrawCheckedGroup(FolderProposals.Result found)
        {
            var chosen = found.Groups.SelectMany(g => g.Paths).Concat(found.Hidden.Select(h => h.Path))
                .Where(p => checkedFolders.Contains(AssetDatabase.AssetPathToGUID(p))).Distinct().ToList();
            GUILayout.Space(8);
            using (new EditorGUILayout.HorizontalScope())
            {
                groupName = EditorGUILayout.TextField("에셋 이름", groupName);
                var reason = chosen.Count < 1 ? "폴더를 하나 이상 체크하세요." : string.IsNullOrWhiteSpace(groupName) ? "에셋 이름을 적으세요." : null;
                using (new EditorGUI.DisabledScope(reason != null))
                    if (GUILayout.Button(new GUIContent($"체크한 폴더로 에셋 하나 만들기 ({chosen.Count})", reason ?? ""), GUILayout.Width(210)))
                    {
                        MakeAsset(chosen, groupName, "", null);
                        groupName = "";
                        checkedFolders.Clear();
                        GUIUtility.ExitGUI();
                    }
            }
        }

        // Folders left out on their own (empty, written by tools, Unity's special folders), with the reason. They can
        // still be made into an asset from here.
        private void DrawHiddenFolders(FolderProposals.Result found)
        {
            if (found.Hidden.Count == 0) return;
            GUILayout.Space(8);
            var open = EditorGUILayout.Foldout(showHidden, $"자동으로 숨긴 폴더 ({found.Hidden.Count}개)", true);
            if (open != showHidden)
            {
                showHidden = open;
                GUIUtility.ExitGUI();
            }
            if (!showHidden) return;
            foreach (var (path, reason) in found.Hidden)
                using (new EditorGUILayout.HorizontalScope())
                {
                    ClippedLabel(path.Substring("Assets/".Length), EditorStyles.miniLabel, GUILayout.MinWidth(60));
                    GUILayout.Label(reason, EditorStyles.miniLabel, GUILayout.ExpandWidth(false));
                    var problem = AssetFolders.Problem(path);
                    using (new EditorGUI.DisabledScope(problem != null))
                        if (GUILayout.Button(new GUIContent("에셋으로 만들기", problem ?? "그래도 상품이라면 에셋으로 등록해요."), EditorStyles.miniButton, GUILayout.Width(96)))
                        {
                            MakeAsset(new List<string> { path }, Path.GetFileName(path), "", null);
                            GUIUtility.ExitGUI();
                        }
                }
        }

        private void DrawIgnored()
        {
            var ignored = AssetStore.State.ignoredFolders;
            if (ignored.Count == 0) return;
            GUILayout.Space(8);
            var open = EditorGUILayout.Foldout(showIgnored, $"무시한 폴더 ({ignored.Count}개)", true);
            if (open != showIgnored)
            {
                showIgnored = open;
                GUIUtility.ExitGUI();
            }
            if (!showIgnored) return;
            foreach (var guid in ignored.ToList())
                using (new EditorGUILayout.HorizontalScope())
                {
                    var path = AssetDatabase.GUIDToAssetPath(guid);
                    ClippedLabel(path.Length > 0 ? path : "(없어진 폴더)", EditorStyles.miniLabel, GUILayout.MinWidth(60));
                    if (GUILayout.Button("다시 보이기", EditorStyles.miniButton, GUILayout.Width(72)))
                    {
                        ignored.Remove(guid);
                        AssetStore.SaveState();
                        unassignedCache = null;
                        GUIUtility.ExitGUI();
                    }
                }
        }

        private void MakeAsset(List<string> paths, string name, string package, string proposalId)
        {
            try
            {
                var asset = AssetFolders.Create(paths, name, package);
                if (proposalId != null) BoothLinker.Transfer(proposalId, asset.id);
                BoothLinker.SearchOnce(asset.id, asset.name, AssetFolders.ExistingFolders(asset), asset.package);
                foldersMessage = $"‘{asset.name}’ 에셋을 만들었어요. 에셋 탭에서 Booth 연결과 조립을 할 수 있어요.";
                foldersMessageType = MessageType.Info;
                selectedAsset = asset.id;
                unassignedCache = null;
            }
            catch (InvalidOperationException e)
            {
                foldersMessage = "에셋으로 만들지 못했어요: " + e.Message;
                foldersMessageType = MessageType.Warning;
            }
        }
    }
}
