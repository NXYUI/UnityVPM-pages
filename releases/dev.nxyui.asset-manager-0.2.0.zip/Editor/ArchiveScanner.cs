using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;

namespace NXYUI.AssetManager
{
    // A .unitypackage that can be put in the import queue: a file on disk, or an entry of a zip archive (at most one
    // zip inside another).
    [Serializable]
    internal sealed class ImportSource
    {
        public string file = "";
        public string entry = "";
        public string nestedEntry = "";
        public long size;

        public bool InArchive => entry.Length > 0;
        public string PackageName => Path.GetFileName((nestedEntry.Length > 0 ? nestedEntry : entry.Length > 0 ? entry : file).Replace('\\', '/'));
        public string Key => file + "|" + entry + "|" + nestedEntry;

        public string Describe()
        {
            var where = Path.GetFileName(file);
            if (entry.Length > 0) where += " › " + entry;
            if (nestedEntry.Length > 0) where += " › " + nestedEntry;
            return where;
        }
    }

    // What a zip archive holds that matters here. Only the central directory is read, so listing a large archive is
    // quick; files kept online-only by a cloud drive are still downloaded once opened, so callers list a zip only when
    // the user opens or picks it.
    internal sealed class ZipListing
    {
        public readonly List<(string Entry, long Size)> Packages = new List<(string, long)>();
        public readonly List<(string Entry, long Size)> Archives = new List<(string, long)>();
        public bool VpmPackage;
        public string Error;
    }

    internal static class ArchiveScanner
    {
        public static List<string> FindFiles(string folder, bool recursive)
        {
            var option = recursive ? SearchOption.AllDirectories : SearchOption.TopDirectoryOnly;
            var found = new List<string>();
            foreach (var pattern in new[] { "*.unitypackage", "*.zip" })
            {
                try { found.AddRange(Directory.EnumerateFiles(folder, pattern, option)); }
                catch (UnauthorizedAccessException) { }
                catch (IOException) { }
            }
            return found.Distinct(StringComparer.OrdinalIgnoreCase).OrderBy(f => f, StringComparer.OrdinalIgnoreCase).ToList();
        }

        public static ZipListing List(string zipFile)
        {
            try
            {
                using (var stream = File.OpenRead(zipFile)) return List(stream);
            }
            catch (Exception e) when (e is IOException || e is InvalidDataException || e is UnauthorizedAccessException)
            {
                return new ZipListing { Error = "압축 파일을 열지 못했어요: " + e.Message };
            }
        }

        public static ZipListing List(Stream stream)
        {
            var listing = new ZipListing();
            using (var zip = Open(stream))
            {
                foreach (var entry in zip.Entries)
                {
                    var name = entry.FullName.Replace('\\', '/');
                    if (name.EndsWith("/", StringComparison.Ordinal) || IsMacMetadata(name)) continue;
                    if (name.EndsWith(".unitypackage", StringComparison.OrdinalIgnoreCase)) listing.Packages.Add((entry.FullName, entry.Length));
                    else if (name.EndsWith(".zip", StringComparison.OrdinalIgnoreCase)) listing.Archives.Add((entry.FullName, entry.Length));
                    // A VCC/ALCOM package carries package.json at its root or one folder down.
                    else if (Path.GetFileName(name) == "package.json" && name.Count(c => c == '/') <= 1) listing.VpmPackage = true;
                }
            }
            return listing;
        }

        // Lists a zip stored inside another one by copying it out to a temporary file first.
        public static ZipListing ListNested(string zipFile, string entry, string tempFolder)
        {
            string copy = null;
            try
            {
                copy = CopyEntry(zipFile, entry, tempFolder, ".zip");
                return List(copy);
            }
            catch (Exception e) when (e is IOException || e is InvalidDataException || e is UnauthorizedAccessException)
            {
                return new ZipListing { Error = "안쪽 압축 파일을 열지 못했어요: " + e.Message };
            }
            finally
            {
                if (copy != null) TryDelete(copy);
            }
        }

        // The package's entry list without unpacking it to disk: a zip entry is inflated as a stream. A package inside
        // a zip inside a zip is read when it is imported instead.
        public static List<PackageEntry> ReadEntries(ImportSource source)
        {
            if (!source.InArchive) return UnityPackageReader.Read(source.file);
            if (source.nestedEntry.Length > 0) throw new NotSupportedException("안쪽 압축 파일의 패키지는 가져올 때 확인해요.");
            using (var stream = File.OpenRead(source.file))
            using (var zip = Open(stream))
            {
                var entry = zip.GetEntry(source.entry) ?? zip.Entries.FirstOrDefault(e => e.FullName == source.entry);
                if (entry == null) throw new FileNotFoundException("압축 파일 안에서 항목을 찾지 못했어요: " + source.entry);
                using (var input = entry.Open()) return UnityPackageReader.Read(input);
            }
        }

        // The .unitypackage of a source as a file on disk: the file itself, or a temporary copy of the archive entry.
        public static string Materialize(ImportSource source, string tempFolder, out bool temporary)
        {
            temporary = source.InArchive;
            if (!source.InArchive) return source.file;
            if (source.nestedEntry.Length == 0) return CopyEntry(source.file, source.entry, tempFolder, ".unitypackage");
            var outer = CopyEntry(source.file, source.entry, tempFolder, ".zip");
            try { return CopyEntry(outer, source.nestedEntry, tempFolder, ".unitypackage"); }
            finally { TryDelete(outer); }
        }

        public const long MaxExtract = 32L << 30;

        // Why an entry of this size must not be unpacked into the temporary folder, or null. Every copy out of an
        // archive (listing a zip inside a zip too) checks it, so a large archive cannot fill the project's drive.
        public static string ExtractProblem(long size, string tempFolder)
        {
            if (size > MaxExtract) return "압축을 풀 항목이 너무 커요(32 GB 초과).";
            try
            {
                var root = Path.GetPathRoot(Path.GetFullPath(tempFolder));
                if (!string.IsNullOrEmpty(root) && new DriveInfo(root).AvailableFreeSpace < size + (512L << 20))
                    return "임시 폴더가 있는 드라이브에 빈 공간이 부족해요.";
            }
            catch (Exception e) when (e is IOException || e is ArgumentException || e is UnauthorizedAccessException) { }
            return null;
        }

        private static string CopyEntry(string zipFile, string entryName, string tempFolder, string extension)
        {
            using (var stream = File.OpenRead(zipFile))
            using (var zip = Open(stream))
            {
                var entry = zip.GetEntry(entryName) ?? zip.Entries.FirstOrDefault(e => e.FullName == entryName);
                if (entry == null) throw new FileNotFoundException("압축 파일 안에서 항목을 찾지 못했어요: " + entryName);
                var problem = ExtractProblem(entry.Length, tempFolder);
                if (problem != null) throw new IOException(problem);
                Directory.CreateDirectory(tempFolder);
                var target = Path.Combine(tempFolder, Guid.NewGuid().ToString("N") + extension);
                try
                {
                    using (var input = entry.Open())
                    using (var output = File.Create(target)) CopyLimited(input, output, entry.Length);
                }
                catch
                {
                    TryDelete(target);
                    throw;
                }
                return target;
            }
        }

        // Stops when an entry inflates past the size its header declares.
        private static void CopyLimited(Stream input, Stream output, long declared)
        {
            var buffer = new byte[81920];
            long total = 0;
            int read;
            while ((read = input.Read(buffer, 0, buffer.Length)) > 0)
            {
                total += read;
                if (total > declared + (1L << 20)) throw new InvalidDataException("압축 항목이 적힌 크기보다 커요.");
                output.Write(buffer, 0, read);
            }
        }

        public static void TryDelete(string file)
        {
            try { if (File.Exists(file)) File.Delete(file); }
            catch (IOException) { }
            catch (UnauthorizedAccessException) { }
        }

        private static bool IsMacMetadata(string name) =>
            name.StartsWith("__MACOSX/", StringComparison.Ordinal) || Path.GetFileName(name).StartsWith("._", StringComparison.Ordinal);

        private static ZipArchive Open(Stream stream) => new ZipArchive(stream, ZipArchiveMode.Read, false, ZipNameEncoding.Instance);
    }

    // Zip entry names without the UTF-8 flag are in the packer's code page. Booth archives are mostly made on Japanese
    // Windows (Shift_JIS), some tools write UTF-8 without the flag: take UTF-8 when the bytes are valid UTF-8, else
    // Shift_JIS (the Unity editor's Mono ships its I18N tables), else the system default.
    internal sealed class ZipNameEncoding : Encoding
    {
        public static readonly ZipNameEncoding Instance = new ZipNameEncoding();
        private static readonly Encoding Strict = new UTF8Encoding(false, true);
        private static readonly Encoding Fallback = LoadShiftJis();

        private static Encoding LoadShiftJis()
        {
            try { return GetEncoding(932); }
            catch (Exception e) when (e is ArgumentException || e is NotSupportedException) { return Default; }
        }

        public override string GetString(byte[] bytes, int index, int count)
        {
            try { return Strict.GetString(bytes, index, count); }
            catch (DecoderFallbackException) { return Fallback.GetString(bytes, index, count); }
        }

        public override int GetCharCount(byte[] bytes, int index, int count) => GetString(bytes, index, count).Length;

        public override int GetChars(byte[] bytes, int byteIndex, int byteCount, char[] chars, int charIndex)
        {
            var text = GetString(bytes, byteIndex, byteCount);
            text.CopyTo(0, chars, charIndex, text.Length);
            return text.Length;
        }

        public override int GetByteCount(char[] chars, int index, int count) => UTF8.GetByteCount(chars, index, count);
        public override int GetBytes(char[] chars, int charIndex, int charCount, byte[] bytes, int byteIndex) => UTF8.GetBytes(chars, charIndex, charCount, bytes, byteIndex);
        public override int GetMaxByteCount(int charCount) => UTF8.GetMaxByteCount(charCount);
        public override int GetMaxCharCount(int byteCount) => byteCount;
    }
}
