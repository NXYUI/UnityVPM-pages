using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using UnityEditor;
using UnityEngine;
using static NXYUI.AssetManager.AssetGui;

namespace NXYUI.AssetManager
{
    // The 가져오기 tab: packages found in a folder (also inside zip archives) on the left, the chosen ones in import
    // order and the running queue on the right. Nothing is imported before the 임포트 button.
    internal sealed partial class AssetManagerWindow
    {
        private sealed class ScanRow
        {
            public string Name = "";
            public long Size;
            public int Depth;
            public ImportSource Source;          // a package (file or archive entry)
            public string Zip;                   // an archive on disk
            public string NestedEntry;           // an archive inside Zip
            public bool Expanded;
            public Task<ZipListing> Listing;
            public List<ScanRow> Children;
            public bool Vpm;
            public string Error;
            public bool IsArchive => Source == null;
        }

        private sealed class PreCheck
        {
            public Task<List<PackageEntry>> Reading;
            public string Error;
            public bool Ready;
            public List<string> Folders = new List<string>();
            public List<string> NewFolders = new List<string>();
            public bool Scripts, Shaders;
            public List<string> Overwrites = new List<string>();
            public List<string> PackageOverwrites = new List<string>();
        }

        private List<ScanRow> scanRows;
        private string scanStatus;
        private Vector2 scanScroll, orderScroll;
        private readonly List<ImportSource> importOrder = new List<ImportSource>();
        private readonly HashSet<string> interactiveKeys = new HashSet<string>();
        private readonly Dictionary<string, PreCheck> preChecks = new Dictionary<string, PreCheck>();
        private bool orderTouched;
        private string openDetails;

        private void TickImportTab()
        {
            var changed = false;
            foreach (var check in preChecks.Values.Where(c => !c.Ready && c.Reading != null && c.Reading.IsCompleted).ToList())
            {
                Complete(check);
                changed = true;
            }
            if (scanRows != null && AllRows(scanRows).Any(r => r.Listing != null && r.Listing.IsCompleted && r.Children == null))
            {
                foreach (var row in AllRows(scanRows).Where(r => r.Listing != null && r.Listing.IsCompleted && r.Children == null).ToList()) Expand(row);
                changed = true;
            }
            if (changed)
            {
                if (!orderTouched) SortOrder();
                Repaint();
            }
        }

        private void DrawImportTab()
        {
            var state = AssetStore.State;
            using (new EditorGUILayout.HorizontalScope())
            {
                EditorGUI.BeginChangeCheck();
                var folder = EditorGUILayout.TextField("패키지 폴더", state.lastImportFolder);
                if (GUILayout.Button("찾아보기…", GUILayout.Width(80)))
                {
                    var picked = EditorUtility.OpenFolderPanel("패키지가 든 폴더 고르기", state.lastImportFolder, "");
                    if (!string.IsNullOrEmpty(picked))
                    {
                        // Saved before the pass ends; the folder panel also breaks the GUI pass.
                        state.lastImportFolder = picked;
                        AssetStore.SaveState();
                    }
                    GUIUtility.ExitGUI();
                }
                var recursive = GUILayout.Toggle(state.importRecursive, "하위 폴더 포함", GUILayout.Width(100));
                if (EditorGUI.EndChangeCheck())
                {
                    state.lastImportFolder = folder;
                    state.importRecursive = recursive;
                    AssetStore.SaveState();
                }
                using (new EditorGUI.DisabledScope(!Directory.Exists(state.lastImportFolder)))
                    if (GUILayout.Button(new GUIContent("폴더 읽기", Directory.Exists(state.lastImportFolder) ? "" : "있는 폴더를 고르세요."), GUILayout.Width(72)))
                    {
                        Scan(state.lastImportFolder, state.importRecursive);
                        GUIUtility.ExitGUI();
                    }
            }
            using (new EditorGUILayout.HorizontalScope())
            {
                using (new EditorGUILayout.VerticalScope(GUILayout.Width(position.width * .48f))) DrawScanList();
                using (new EditorGUILayout.VerticalScope()) DrawOrderAndQueue();
            }
        }

        // ---- Found packages ----

        private void Scan(string folder, bool recursive)
        {
            var files = ArchiveScanner.FindFiles(folder, recursive);
            scanRows = files.Select(f =>
            {
                long size = 0;
                try { size = new FileInfo(f).Length; }
                catch (IOException) { }
                var relative = f.Length > folder.Length ? f.Substring(folder.Length).TrimStart('\\', '/') : Path.GetFileName(f);
                return f.EndsWith(".zip", StringComparison.OrdinalIgnoreCase)
                    ? new ScanRow { Name = relative, Size = size, Zip = f }
                    : new ScanRow { Name = relative, Size = size, Source = new ImportSource { file = f, size = size } };
            }).ToList();
            scanStatus = files.Count == 0
                ? recursive
                    ? "이 폴더와 그 안쪽에서 .unitypackage나 .zip을 찾지 못했어요. 패키지를 내려받은 폴더를 고르세요."
                    : "이 폴더에서 .unitypackage나 .zip을 찾지 못했어요. ‘하위 폴더 포함’을 켜거나 다른 폴더를 고르세요."
                : null;
        }

        // The rows on screen: children of collapsed archives are left out.
        private static IEnumerable<ScanRow> VisibleRows(IEnumerable<ScanRow> rows)
        {
            foreach (var row in rows)
            {
                yield return row;
                if (row.Expanded && row.Children != null)
                    foreach (var child in VisibleRows(row.Children)) yield return child;
            }
        }

        private static IEnumerable<ScanRow> AllRows(IEnumerable<ScanRow> rows)
        {
            foreach (var row in rows)
            {
                yield return row;
                if (row.Children != null)
                    foreach (var child in AllRows(row.Children)) yield return child;
            }
        }

        private void DrawScanList()
        {
            GUILayout.Label("찾은 패키지", EditorStyles.boldLabel);
            if (scanRows == null)
            {
                EditorGUILayout.HelpBox("패키지가 든 폴더를 고르고 ‘폴더 읽기’를 누르세요. 압축 파일은 펼치면 안의 패키지를 보여 줘요.", MessageType.Info);
                return;
            }
            if (scanStatus != null) EditorGUILayout.HelpBox(scanStatus, MessageType.None);
            scanScroll = EditorGUILayout.BeginScrollView(scanScroll);
            foreach (var row in scanRows.ToList()) DrawScanRow(row);
            EditorGUILayout.EndScrollView();
            var selectable = VisibleRows(scanRows).Where(r => r.Source != null).ToList();
            using (new EditorGUILayout.HorizontalScope())
            {
                using (new EditorGUI.DisabledScope(selectable.Count == 0))
                    if (GUILayout.Button(new GUIContent($"보이는 패키지 모두 고르기 ({selectable.Count})",
                            selectable.Count == 0 ? "보이는 패키지가 없어요. 압축 파일을 펼치면 안의 패키지가 보여요." : "접힌 압축 파일 안의 패키지는 고르지 않아요.")))
                    {
                        foreach (var row in selectable) Select(row.Source, true);
                        GUIUtility.ExitGUI();
                    }
                using (new EditorGUI.DisabledScope(importOrder.Count == 0))
                    if (GUILayout.Button("고른 것 모두 풀기"))
                    {
                        importOrder.Clear();
                        GUIUtility.ExitGUI();
                    }
            }
        }

        private void DrawScanRow(ScanRow row)
        {
            using (new EditorGUILayout.HorizontalScope(EditorStyles.helpBox))
            {
                GUILayout.Space(row.Depth * 16);
                if (row.IsArchive)
                {
                    var arrow = GUILayoutUtility.GetRect(14, 18, GUILayout.Width(14));
                    var expanded = EditorGUI.Foldout(arrow, row.Expanded, GUIContent.none, true);
                    if (expanded != row.Expanded)
                    {
                        row.Expanded = expanded;
                        if (expanded && row.Children == null && row.Listing == null) StartListing(row);
                        GUIUtility.ExitGUI();
                    }
                    GUILayout.Label(EditorGUIUtility.IconContent("Folder Icon"), GUILayout.Width(18), GUILayout.Height(18));
                }
                else
                {
                    var selected = importOrder.Any(s => s.Key == row.Source.Key);
                    var toggled = GUILayout.Toggle(selected, GUIContent.none, GUILayout.Width(16));
                    if (toggled != selected)
                    {
                        Select(row.Source, toggled);
                        GUIUtility.ExitGUI();
                    }
                }
                ClippedLabel(row.Name, EditorStyles.label, GUILayout.MinWidth(60));
                if (row.IsArchive) DrawBadge("압축");
                if (row.Vpm) DrawBadge("VCC 패키지", "warn", "VCC·ALCOM으로 설치하는 패키지예요. 여기서는 가져오지 않아요.");
                if (row.Error != null) DrawBadge("열 수 없음", "bad", row.Error);
                if (row.Source != null && AlreadyImported(row.Source)) DrawBadge("가져온 적 있음", "", "이 프로젝트에 같은 이름·크기의 패키지를 가져온 기록이 있어요.");
                GUILayout.Label(AssetFolders.FormatSize(row.Size), EditorStyles.miniLabel, GUILayout.Width(56));
            }
            if (!row.IsArchive || !row.Expanded) return;
            if (row.Children == null)
            {
                using (new EditorGUILayout.HorizontalScope())
                {
                    GUILayout.Space(row.Depth * 16 + 24);
                    GUILayout.Label("압축 파일 목록을 읽고 있어요…", EditorStyles.miniLabel);
                }
                return;
            }
            if (row.Children.Count == 0)
                using (new EditorGUILayout.HorizontalScope())
                {
                    GUILayout.Space(row.Depth * 16 + 24);
                    GUILayout.Label(row.Error ?? (row.Vpm ? "VCC·ALCOM으로 설치하는 패키지예요. 여기서는 가져오지 않아요." : "안에 .unitypackage가 없어요."),
                        EditorStyles.wordWrappedMiniLabel);
                }
            foreach (var child in row.Children.ToList()) DrawScanRow(child);
        }

        private void StartListing(ScanRow row)
        {
            var zip = row.Zip;
            var nested = row.NestedEntry;
            var temp = Path.Combine(AssetStore.TempFolder, "listing");
            row.Listing = Task.Run(() => nested == null ? ArchiveScanner.List(zip) : ArchiveScanner.ListNested(zip, nested, temp));
        }

        private static void Expand(ScanRow row)
        {
            var listing = row.Listing.IsFaulted ? new ZipListing { Error = row.Listing.Exception?.InnerException?.Message } : row.Listing.Result;
            row.Error = listing.Error;
            row.Vpm = listing.VpmPackage;
            row.Children = new List<ScanRow>();
            foreach (var (entry, size) in listing.Packages)
            {
                var source = row.NestedEntry == null
                    ? new ImportSource { file = row.Zip, entry = entry, size = size }
                    : new ImportSource { file = row.Zip, entry = row.NestedEntry, nestedEntry = entry, size = size };
                row.Children.Add(new ScanRow { Name = entry, Size = size, Depth = row.Depth + 1, Source = source });
            }
            // One level of archives inside an archive.
            if (row.NestedEntry == null)
                foreach (var (entry, size) in listing.Archives)
                    row.Children.Add(new ScanRow { Name = entry, Size = size, Depth = row.Depth + 1, Zip = row.Zip, NestedEntry = entry });
        }

        private void Select(ImportSource source, bool selected)
        {
            importOrder.RemoveAll(s => s.Key == source.Key);
            if (!selected) return;
            importOrder.Add(source);
            if (!preChecks.ContainsKey(source.Key))
            {
                var check = new PreCheck();
                if (source.nestedEntry.Length > 0) check.Error = "안쪽 압축 파일의 패키지는 가져올 때 내용을 확인해요.";
                else check.Reading = Task.Run(() => ArchiveScanner.ReadEntries(source));
                preChecks[source.Key] = check;
            }
            if (!orderTouched) SortOrder();
        }

        // What the package would do, worked out on the main thread once its list is read.
        private static void Complete(PreCheck check)
        {
            check.Ready = true;
            if (check.Reading.IsFaulted)
            {
                check.Error = "패키지 내용을 읽지 못했어요: " + (check.Reading.Exception?.InnerException?.Message ?? "");
                return;
            }
            var entries = check.Reading.Result;
            check.Folders = UnityPackageReader.Folders(entries).OrderBy(f => f, StringComparer.Ordinal).ToList();
            check.NewFolders = UnityPackageReader.Topmost(check.Folders.Where(f => !AssetDatabase.IsValidFolder(f)));
            foreach (var entry in entries.Where(e => e.IsFile))
            {
                var extension = Path.GetExtension(entry.Path).ToLowerInvariant();
                if (extension == ".cs" || extension == ".dll" || extension == ".asmdef") check.Scripts = true;
                if (extension == ".shader" || extension == ".cginc" || extension == ".hlsl") check.Shaders = true;
                var existing = AssetDatabase.GUIDToAssetPath(entry.Guid);
                if (existing.Length == 0 || AssetDatabase.IsValidFolder(existing) || !File.Exists(existing)) continue;
                (existing.StartsWith("Packages/", StringComparison.Ordinal) ? check.PackageOverwrites : check.Overwrites).Add(existing);
            }
        }

        // Tools and shaders first (other packages may need them to compile), then the order the user picked.
        private void SortOrder()
        {
            var sorted = importOrder.Select((s, i) => (s, i))
                .OrderBy(p => preChecks.TryGetValue(p.s.Key, out var c) && c.Ready && (c.Scripts || c.Shaders) ? 0 : 1)
                .ThenBy(p => p.i).Select(p => p.s).ToList();
            importOrder.Clear();
            importOrder.AddRange(sorted);
        }

        private static bool AlreadyImported(ImportSource source) =>
            AssetStore.State.history.Any(h => h.result == "completed" && h.package == source.PackageName && h.size == source.size);

        // ---- Order and queue ----

        private void DrawOrderAndQueue()
        {
            var queue = ImportQueue.Data;
            // The buttons and the progress stay above the scrolling lists, however long they get.
            if (importOrder.Count > 0) DrawImportButton();
            if (queue.jobs.Count > 0) DrawQueueControls(queue);
            orderScroll = EditorGUILayout.BeginScrollView(orderScroll);
            if (importOrder.Count > 0) DrawImportOrder();
            else if (queue.jobs.Count == 0)
                EditorGUILayout.HelpBox("왼쪽에서 가져올 패키지를 체크하세요. 고른 순서대로 여기에 쌓이고, ‘임포트’를 누르면 하나씩 가져와요.", MessageType.Info);
            if (queue.jobs.Count > 0) DrawQueueJobs(queue);
            EditorGUILayout.EndScrollView();
        }

        private void DrawImportButton()
        {
            var reason = ImportQueue.HasUnknown ? "‘확인 필요’ 항목을 먼저 다시 시도하거나 건너뛰세요." : null;
            var note = reason ?? (ImportQueue.Current != null ? "지금 가져오는 패키지가 끝나면 이어서 가져와요." : null);
            using (new EditorGUI.DisabledScope(reason != null))
                if (GUILayout.Button(new GUIContent($"임포트 ({importOrder.Count}개)", reason ?? "아래 순서대로 하나씩 가져와요."), GUILayout.Height(26)))
                {
                    foreach (var source in importOrder)
                    {
                        preChecks.TryGetValue(source.Key, out var check);
                        ImportQueue.Add(source, interactiveKeys.Contains(source.Key), check != null && check.Ready && check.Error == null ? check.Folders : null);
                    }
                    importOrder.Clear();
                    orderTouched = false;
                    ImportQueue.Start();
                    GUIUtility.ExitGUI();
                }
            if (note != null) GUILayout.Label(note, EditorStyles.wordWrappedMiniLabel);
        }

        private void DrawImportOrder()
        {
            GUILayout.Label($"가져올 순서 ({importOrder.Count}개)", EditorStyles.boldLabel);
            GUILayout.Label("스크립트·셰이더가 든 패키지를 먼저 놓았어요. ▲▼로 바꿀 수 있어요.", EditorStyles.wordWrappedMiniLabel);
            for (var i = 0; i < importOrder.Count; i++)
            {
                var source = importOrder[i];
                preChecks.TryGetValue(source.Key, out var check);
                using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
                {
                    using (new EditorGUILayout.HorizontalScope())
                    {
                        GUILayout.Label($"{i + 1}.", GUILayout.Width(22));
                        ClippedLabel(source.Describe(), EditorStyles.label, GUILayout.MinWidth(60));
                        using (new EditorGUI.DisabledScope(i == 0))
                            if (GUILayout.Button(new GUIContent("▲", i == 0 ? "이미 맨 앞이에요." : "한 칸 앞으로"), EditorStyles.miniButtonLeft, GUILayout.Width(22)))
                            {
                                MoveOrder(i, -1);
                                GUIUtility.ExitGUI();
                            }
                        using (new EditorGUI.DisabledScope(i == importOrder.Count - 1))
                            if (GUILayout.Button(new GUIContent("▼", i == importOrder.Count - 1 ? "이미 맨 뒤예요." : "한 칸 뒤로"), EditorStyles.miniButtonMid, GUILayout.Width(22)))
                            {
                                MoveOrder(i, 1);
                                GUIUtility.ExitGUI();
                            }
                        if (GUILayout.Button(new GUIContent("×", "순서에서 빼요."), EditorStyles.miniButtonRight, GUILayout.Width(22)))
                        {
                            importOrder.RemoveAt(i);
                            GUIUtility.ExitGUI();
                        }
                    }
                    using (new EditorGUILayout.HorizontalScope())
                    {
                        GUILayout.Space(26);
                        if (check == null || !check.Ready && check.Error == null) GUILayout.Label("내용 확인 중…", EditorStyles.miniLabel);
                        else if (check.Error != null) GUILayout.Label(check.Error, EditorStyles.wordWrappedMiniLabel);
                        else
                        {
                            if (check.Scripts) DrawBadge("스크립트", "", "가져온 뒤 컴파일해요.");
                            if (check.Shaders) DrawBadge("셰이더");
                            if (check.Overwrites.Count > 0) DrawBadge($"덮어씀 {check.Overwrites.Count}개", "warn", "프로젝트에 이미 있는 파일을 같은 GUID로 덮어써요.");
                            if (check.PackageOverwrites.Count > 0) DrawBadge($"⚠ VPM 파일 {check.PackageOverwrites.Count}개", "bad", "VCC로 설치한 패키지의 파일과 GUID가 같아요.");
                            if (AlreadyImported(source)) DrawBadge("가져온 적 있음");
                            GUILayout.Label(check.NewFolders.Count > 0 ? "새 폴더: " + string.Join(", ", check.NewFolders.Select(Path.GetFileName)) : "새 폴더 없음",
                                EditorStyles.miniLabel);
                        }
                        GUILayout.FlexibleSpace();
                    }
                    if (check != null && check.Ready && (check.Overwrites.Count > 0 || check.PackageOverwrites.Count > 0))
                    {
                        var open = openDetails == source.Key;
                        var toggled = EditorGUILayout.Foldout(open, "덮어쓸 파일 보기", true);
                        if (toggled != open)
                        {
                            openDetails = toggled ? source.Key : null;
                            GUIUtility.ExitGUI();
                        }
                        if (open)
                        {
                            foreach (var path in check.PackageOverwrites.Take(10)) GUILayout.Label("⚠ " + path, EditorStyles.miniLabel);
                            foreach (var path in check.Overwrites.Take(10)) GUILayout.Label(path, EditorStyles.miniLabel);
                            var more = check.Overwrites.Count + check.PackageOverwrites.Count - Math.Min(10, check.Overwrites.Count) - Math.Min(10, check.PackageOverwrites.Count);
                            if (more > 0) GUILayout.Label($"…그 밖에 {more}개", EditorStyles.miniLabel);
                            GUILayout.Label("빼고 가져오려면 아래 ‘Unity 가져오기 창 열기’를 켜고, 창에서 그 파일의 체크를 푸세요.", EditorStyles.wordWrappedMiniLabel);
                        }
                    }
                    var interactive = interactiveKeys.Contains(source.Key);
                    var newInteractive = EditorGUILayout.ToggleLeft(new GUIContent("Unity 가져오기 창 열기", "가져올 파일을 Unity 창에서 직접 골라요."), interactive, EditorStyles.miniLabel);
                    if (newInteractive != interactive)
                    {
                        if (newInteractive) interactiveKeys.Add(source.Key);
                        else interactiveKeys.Remove(source.Key);
                    }
                }
            }
        }

        private void MoveOrder(int index, int delta)
        {
            var target = index + delta;
            if (target < 0 || target >= importOrder.Count) return;
            var item = importOrder[index];
            importOrder.RemoveAt(index);
            importOrder.Insert(target, item);
            orderTouched = true;
        }

        private void DrawQueueControls(QueueData queue)
        {
            GUILayout.Label("가져오기 진행", EditorStyles.boldLabel);
            var total = queue.jobs.Count;
            var finished = queue.jobs.Count(j => j.Finished);
            var current = ImportQueue.Current;
            if (current != null || queue.running)
            {
                var label = current != null ? $"{finished + 1}/{total} 가져오는 중: {current.source.PackageName}" : $"{finished}/{total} 끝남";
                var rect = GUILayoutUtility.GetRect(18, 18, GUILayout.ExpandWidth(true));
                EditorGUI.ProgressBar(rect, total == 0 ? 0 : finished / (float)total, label);
                if (current != null && current.message.Length > 0) GUILayout.Label(current.message, EditorStyles.miniLabel);
            }
            if (queue.pauseReason.Length > 0) EditorGUILayout.HelpBox(queue.pauseReason, MessageType.Warning);
            using (new EditorGUILayout.HorizontalScope())
            {
                if (queue.running)
                {
                    if (GUILayout.Button(new GUIContent("멈추기", "지금 가져오는 패키지가 끝나면 멈춰요.")))
                    {
                        ImportQueue.Pause("멈췄어요. 이어서 가져오려면 시작을 누르세요.");
                        GUIUtility.ExitGUI();
                    }
                }
                else
                {
                    var waiting = ImportQueue.Waiting;
                    var reason = waiting == 0 ? "남은 패키지가 없어요." : ImportQueue.HasUnknown ? "‘확인 필요’ 항목을 먼저 다시 시도하거나 건너뛰세요." : null;
                    using (new EditorGUI.DisabledScope(reason != null))
                        if (GUILayout.Button(new GUIContent($"시작 ({waiting}개 남음)", reason ?? "남은 패키지를 차례로 가져와요.")))
                        {
                            ImportQueue.Start();
                            GUIUtility.ExitGUI();
                        }
                }
                using (new EditorGUI.DisabledScope(finished == 0))
                    if (GUILayout.Button(new GUIContent("끝난 항목 지우기", finished == 0 ? "끝난 항목이 없어요." : "")))
                    {
                        ImportQueue.ClearFinished();
                        GUIUtility.ExitGUI();
                    }
            }
        }

        private void DrawQueueJobs(QueueData queue)
        {
            GUILayout.Space(8);
            foreach (var job in queue.jobs.ToList())
            {
                using (new EditorGUILayout.HorizontalScope(EditorStyles.helpBox))
                {
                    var (word, kind) = StateBadge(job.state);
                    DrawBadge(word, kind);
                    using (new EditorGUILayout.VerticalScope())
                    {
                        ClippedLabel(job.source.Describe(), EditorStyles.label);
                        if (job.message.Length > 0) GUILayout.Label(job.message, EditorStyles.wordWrappedMiniLabel);
                    }
                    if (job.state == JobState.Waiting)
                    {
                        if (GUILayout.Button("▲", EditorStyles.miniButtonLeft, GUILayout.Width(22))) { ImportQueue.Move(job, -1); GUIUtility.ExitGUI(); }
                        if (GUILayout.Button("▼", EditorStyles.miniButtonMid, GUILayout.Width(22))) { ImportQueue.Move(job, 1); GUIUtility.ExitGUI(); }
                        if (GUILayout.Button("×", EditorStyles.miniButtonRight, GUILayout.Width(22))) { ImportQueue.Remove(job); GUIUtility.ExitGUI(); }
                    }
                    else if (job.state == JobState.Unknown)
                    {
                        if (GUILayout.Button("다시 시도", EditorStyles.miniButton, GUILayout.Width(64))) { ImportQueue.Retry(job); GUIUtility.ExitGUI(); }
                        if (GUILayout.Button("건너뛰기", EditorStyles.miniButton, GUILayout.Width(64))) { ImportQueue.Skip(job); GUIUtility.ExitGUI(); }
                    }
                    else if (job.state == JobState.Failed || job.state == JobState.Cancelled)
                    {
                        if (GUILayout.Button("다시 시도", EditorStyles.miniButton, GUILayout.Width(64))) { ImportQueue.Retry(job); GUIUtility.ExitGUI(); }
                    }
                    else if (job.state == JobState.Done && job.created.Count > 0)
                    {
                        if (GUILayout.Button("에셋 후보 보기", EditorStyles.miniButton, GUILayout.Width(90))) { tab = 2; GUIUtility.ExitGUI(); }
                    }
                }
            }
        }

        private static (string, string) StateBadge(JobState state)
        {
            switch (state)
            {
                case JobState.Waiting: return ("대기", "");
                case JobState.Preparing: return ("준비 중", "");
                case JobState.Importing: return ("가져오는 중", "");
                case JobState.Finalizing: return ("정리 중", "");
                case JobState.Done: return ("완료", "good");
                case JobState.Failed: return ("실패", "bad");
                case JobState.Cancelled: return ("취소", "warn");
                case JobState.Unknown: return ("확인 필요", "warn");
                default: return ("건너뜀", "");
            }
        }
    }
}
