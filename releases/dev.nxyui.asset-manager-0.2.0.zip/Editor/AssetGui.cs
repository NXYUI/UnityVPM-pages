using System;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace NXYUI.AssetManager
{
    // Drawing helpers shared by the window and the Inspector panels, and the counters their caches watch.
    [InitializeOnLoad]
    internal static class AssetGui
    {
        // Raised when the scene objects or the project files change; caches of avatars, places, prefabs compare it.
        internal static int HierarchyVersion { get; private set; }
        internal static int ProjectVersion { get; private set; }

        static AssetGui()
        {
            EditorApplication.hierarchyChanged += () => HierarchyVersion++;
            EditorApplication.projectChanged += () => ProjectVersion++;
            AssetStore.Changed += () => ProjectVersion++;
        }

        // A change that alters which controls are drawn waits for the next GUI pass: drawn now, the pass that is
        // running would meet controls its Layout did not have. Used by the Inspector panels, which must not ExitGUI
        // (that would also skip the headers other tools draw after them).
        internal static void Later(Action change, Action repaint)
        {
            EditorApplication.delayCall += () =>
            {
                change();
                repaint?.Invoke();
            };
        }

        private static GUIStyle badgeStyle;
        private static GUIStyle Badge => badgeStyle ?? (badgeStyle = new GUIStyle(EditorStyles.miniBoldLabel)
        {
            padding = new RectOffset(4, 4, 0, 0),
            margin = new RectOffset(0, 4, 2, 2),
            normal = { background = Texture2D.whiteTexture },
        });

        private static GUIStyle wrappedLabel;
        internal static GUIStyle WrappedLabel => wrappedLabel ?? (wrappedLabel = new GUIStyle(EditorStyles.label) { wordWrap = true });

        private static GUIStyle wrappedBold;
        internal static GUIStyle WrappedBold => wrappedBold ?? (wrappedBold = new GUIStyle(EditorStyles.boldLabel) { wordWrap = true });

        // Badge colours: one tint per meaning, each with its own word so colour is never the only signal.
        private static Color Tint(string kind)
        {
            var pro = EditorGUIUtility.isProSkin;
            switch (kind)
            {
                case "good": return pro ? new Color(.20f, .40f, .25f) : new Color(.72f, .88f, .74f);
                case "warn": return pro ? new Color(.48f, .36f, .12f) : new Color(.98f, .86f, .58f);
                case "bad": return pro ? new Color(.50f, .20f, .20f) : new Color(.96f, .72f, .72f);
                default: return pro ? new Color(.28f, .28f, .30f) : new Color(.82f, .82f, .84f);
            }
        }

        internal static void DrawBadge(string text, string kind = "", string tooltip = null)
        {
            var content = new GUIContent(text, tooltip);
            var rect = GUILayoutUtility.GetRect(content, Badge, GUILayout.ExpandWidth(false));
            DrawBadge(rect, content, kind);
        }

        internal static void DrawBadge(Rect rect, GUIContent content, string kind)
        {
            var previous = GUI.backgroundColor;
            GUI.backgroundColor = Tint(kind);
            GUI.Label(rect, content, Badge);
            GUI.backgroundColor = previous;
        }

        internal static Vector2 BadgeSize(string text) => Badge.CalcSize(new GUIContent(text));

        // The selection mark, one per skin; the selected item's name is also bold, so colour is not the only sign.
        internal static Color SelectedRow => EditorGUIUtility.isProSkin ? new Color(.17f, .36f, .53f, .55f) : new Color(.23f, .45f, .85f, .25f);
        internal static Color SelectedFrame => EditorGUIUtility.isProSkin ? new Color(.30f, .55f, .85f) : new Color(.15f, .40f, .80f);

        internal static void Highlight(Rect rect, bool selected)
        {
            if (selected && Event.current.type == EventType.Repaint) EditorGUI.DrawRect(rect, SelectedRow);
        }

        // A frame of the given width inside rect.
        internal static void Frame(Rect rect, Color color, float width)
        {
            if (Event.current.type != EventType.Repaint) return;
            EditorGUI.DrawRect(new Rect(rect.x, rect.y, rect.width, width), color);
            EditorGUI.DrawRect(new Rect(rect.x, rect.yMax - width, rect.width, width), color);
            EditorGUI.DrawRect(new Rect(rect.x, rect.y, width, rect.height), color);
            EditorGUI.DrawRect(new Rect(rect.xMax - width, rect.y, width, rect.height), color);
        }

        internal static void DrawThumbnail(Texture texture, float size, string placeholder)
        {
            var rect = GUILayoutUtility.GetRect(size, size, GUILayout.Width(size), GUILayout.Height(size));
            DrawThumbnail(rect, texture, placeholder);
        }

        // The image, or a plain square of the same size with a word while there is none (so nothing jumps on load).
        internal static void DrawThumbnail(Rect rect, Texture texture, string placeholder)
        {
            if (Event.current.type != EventType.Repaint) return;
            if (texture) GUI.DrawTexture(rect, texture, ScaleMode.ScaleAndCrop);
            else
            {
                EditorGUI.DrawRect(rect, EditorGUIUtility.isProSkin ? new Color(.18f, .18f, .18f) : new Color(.86f, .86f, .86f));
                GUI.Label(rect, placeholder, new GUIStyle(EditorStyles.centeredGreyMiniLabel) { wordWrap = true });
            }
        }

        // A text that may not fit: it takes the room left in its row, is cut with "…" and shows whole in the tooltip.
        internal static void ClippedLabel(string text, GUIStyle style, params GUILayoutOption[] options)
        {
            text = text ?? "";
            // The caller's options come last so they win over these defaults.
            var layout = new[] { GUILayout.ExpandWidth(true), GUILayout.MinWidth(30) }.Concat(options).ToArray();
            var rect = GUILayoutUtility.GetRect(new GUIContent("…"), style, layout);
            GUI.Label(rect, new GUIContent(Fit(text, style, rect.width), text), style);
        }

        internal static string Fit(string text, GUIStyle style, float width)
        {
            if (width <= 0 || style.CalcSize(new GUIContent(text)).x <= width) return text;
            int low = 0, high = text.Length;
            while (low < high)
            {
                var middle = (low + high + 1) / 2;
                if (style.CalcSize(new GUIContent(text.Substring(0, middle) + "…")).x <= width) low = middle;
                else high = middle - 1;
            }
            return text.Substring(0, low) + "…";
        }

        internal static string KindName(AssetKind kind)
        {
            switch (kind)
            {
                case AssetKind.Avatar: return "아바타";
                case AssetKind.Outfit: return "의상";
                case AssetKind.Accessory: return "액세서리";
                case AssetKind.Tool: return "도구";
                default: return "기타";
            }
        }

        internal static readonly string[] KindNames = Enum.GetValues(typeof(AssetKind)).Cast<AssetKind>().Select(KindName).ToArray();

        internal static void Section(string title)
        {
            GUILayout.Space(8);
            GUILayout.Label(title, EditorStyles.boldLabel);
        }

        internal static string BoothUrl(long id) => "https://booth.pm/ja/items/" + id;

        private static readonly System.Collections.Generic.Dictionary<string, GameObject> FirstPrefabs = new System.Collections.Generic.Dictionary<string, GameObject>();
        private static int firstPrefabsVersion = -1;

        // The asset's picture: its Booth image when linked, else the preview of its top-most prefab, else none.
        internal static Texture AssetTexture(AssetRecord asset, Action repaint)
        {
            var item = AssetStore.Item(asset.boothId);
            if (item != null && item.thumbnail.Length > 0)
            {
                var booth = AssetStore.Thumbnail(item.thumbnail, repaint);
                if (booth) return booth;
            }
            if (firstPrefabsVersion != ProjectVersion)
            {
                FirstPrefabs.Clear();
                firstPrefabsVersion = ProjectVersion;
            }
            if (!FirstPrefabs.TryGetValue(asset.id, out var prefab))
                FirstPrefabs[asset.id] = prefab = AssetFolders.Prefabs(asset).OrderBy(p => AssetDatabase.GetAssetPath(p).Count(c => c == '/')).FirstOrDefault();
            if (!prefab) return null;
            var preview = AssetPreview.GetAssetPreview(prefab);
            if (!preview && AssetPreview.IsLoadingAssetPreview(prefab.GetInstanceID())) repaint?.Invoke();
            return preview ? preview : AssetPreview.GetMiniThumbnail(prefab);
        }
    }
}
