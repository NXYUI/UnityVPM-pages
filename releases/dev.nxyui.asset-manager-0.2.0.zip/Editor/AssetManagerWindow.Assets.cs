using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;
using static NXYUI.AssetManager.AssetGui;

namespace NXYUI.AssetManager
{
    // The 에셋 tab: a gallery of the confirmed assets on the left, the selected one's Booth link, folders and assembly
    // on the right (the same forms as the Inspector panels).
    internal sealed partial class AssetManagerWindow
    {
        [SerializeField] private string selectedAsset;
        [SerializeField] private string assetSearch = "";
        [SerializeField] private int kindFilter = -1;
        [SerializeField] private bool unlinkedOnly;
        [SerializeField] private float cardSize = 112;
        [SerializeField] private BoothForm booth = new BoothForm();
        [SerializeField] private AssemblyForm assembly = new AssemblyForm();
        private Vector2 galleryScroll, assetDetailScroll;
        private string folderMessage;
        private int galleryControl;
        private bool scrollToSelection;

        private const float CardGap = 8, CardText = 30, CardBadges = 18, ScrollBar = 16;

        private AssetRecord SelectedAsset => AssetStore.AssetById(selectedAsset);

        private static GUIStyle cardName, cardNameBold;
        private static GUIStyle CardName => cardName ?? (cardName = new GUIStyle(EditorStyles.wordWrappedMiniLabel) { alignment = TextAnchor.UpperCenter, clipping = TextClipping.Clip });
        private static GUIStyle CardNameBold => cardNameBold ?? (cardNameBold = new GUIStyle(CardName) { fontStyle = FontStyle.Bold });

        private void DrawAssetsTab()
        {
            var assets = AssetStore.Project.assets;
            if (assets.Count == 0)
            {
                EditorGUILayout.HelpBox("아직 에셋이 없어요. ‘폴더 지정’에서 이미 있는 상품 폴더를 에셋으로 지정하거나, ‘가져오기’에서 패키지를 가져오세요.", MessageType.Info);
                using (new EditorGUILayout.HorizontalScope())
                {
                    if (GUILayout.Button("폴더 지정 열기", GUILayout.Width(120))) tab = 2;
                    if (GUILayout.Button("가져오기 열기", GUILayout.Width(120))) tab = 1;
                }
                return;
            }
            var galleryWidth = Mathf.Floor(position.width * .6f);
            using (new EditorGUILayout.HorizontalScope())
            {
                using (new EditorGUILayout.VerticalScope(GUILayout.Width(galleryWidth))) DrawGallery(assets, galleryWidth);
                using (new EditorGUILayout.VerticalScope())
                {
                    assetDetailScroll = EditorGUILayout.BeginScrollView(assetDetailScroll);
                    var asset = SelectedAsset;
                    if (asset == null) EditorGUILayout.HelpBox("왼쪽 갤러리에서 에셋을 고르면 Booth 연결, 폴더, 조립을 볼 수 있어요.", MessageType.None);
                    else DrawAssetDetail(asset);
                    EditorGUILayout.EndScrollView();
                }
            }
        }

        // ---- Gallery ----

        private List<AssetRecord> Shown(List<AssetRecord> assets) => assets
            .Where(a => kindFilter < 0 || (int)a.kind == kindFilter)
            .Where(a => !unlinkedOnly || a.boothId <= 0)
            .Where(a => string.IsNullOrEmpty(assetSearch) || Matches(a, assetSearch))
            .OrderBy(a => a.name, StringComparer.CurrentCultureIgnoreCase).ToList();

        private void DrawGallery(List<AssetRecord> assets, float width)
        {
            using (new EditorGUILayout.HorizontalScope(EditorStyles.toolbar))
            {
                var search = EditorGUILayout.TextField(assetSearch, EditorStyles.toolbarSearchField, GUILayout.MinWidth(60));
                var filter = EditorGUILayout.Popup(kindFilter + 1, new[] { "모든 종류" }.Concat(KindNames).ToArray(), EditorStyles.toolbarPopup, GUILayout.Width(76)) - 1;
                var unlinked = GUILayout.Toggle(unlinkedOnly, new GUIContent("미연결만", "Booth 상품과 아직 연결하지 않은 에셋만 보여 줘요."), EditorStyles.toolbarButton, GUILayout.Width(56));
                GUILayout.Label(new GUIContent("크기", "카드 크기"), EditorStyles.miniLabel, GUILayout.Width(26));
                var size = Mathf.Round(GUILayout.HorizontalSlider(cardSize, 72, 160, GUILayout.Width(56)));
                if (search != assetSearch || filter != kindFilter || unlinked != unlinkedOnly || !Mathf.Approximately(size, cardSize))
                {
                    // The gallery below changes: end the pass before drawing it.
                    assetSearch = search;
                    kindFilter = filter;
                    unlinkedOnly = unlinked;
                    cardSize = size;
                    scrollToSelection = true;
                    GUIUtility.ExitGUI();
                }
            }
            var shown = Shown(assets);
            GUILayout.Label("Project 창에서 에셋 폴더나 프리팹을 고르면 인스펙터에서 바로 연결·조립할 수 있어요.", EditorStyles.wordWrappedMiniLabel);
            GUILayout.Label($"{shown.Count}개 표시 · 전체 {assets.Count}개" + (shown.Count > 0 ? " · 카드를 누른 뒤 방향키로 옮겨요" : ""), EditorStyles.miniLabel);

            // Columns from the room really there: the gallery's width less the scroll bar and the frame's margins.
            var inner = width - ScrollBar - 8;
            var columns = Mathf.Max(1, Mathf.FloorToInt((inner + CardGap) / (cardSize + CardGap)));
            var rowHeight = cardSize + CardText + CardBadges + CardGap;
            var rows = (shown.Count + columns - 1) / columns;
            galleryControl = GUIUtility.GetControlID("NXYUI.AssetGallery".GetHashCode(), FocusType.Keyboard);
            var view = Mathf.Max(rowHeight, position.height - 110);
            Keys(shown, columns);
            if (scrollToSelection && Event.current.type == EventType.Layout)
            {
                scrollToSelection = false;
                var at = shown.FindIndex(a => a.id == selectedAsset);
                if (at >= 0)
                {
                    var top = at / columns * rowHeight;
                    if (top < galleryScroll.y) galleryScroll.y = top;
                    else if (top + rowHeight > galleryScroll.y + view) galleryScroll.y = top + rowHeight - view;
                }
            }

            galleryScroll = EditorGUILayout.BeginScrollView(galleryScroll);
            if (shown.Count == 0)
            {
                var hidden = new List<string>();
                if (!string.IsNullOrEmpty(assetSearch)) hidden.Add($"검색어 ‘{assetSearch}’");
                if (kindFilter >= 0) hidden.Add($"종류 ‘{KindNames[kindFilter]}’");
                if (unlinkedOnly) hidden.Add("‘미연결만’");
                EditorGUILayout.HelpBox($"보이는 에셋이 없어요. {string.Join(", ", hidden)} 때문에 숨겨졌어요. 조건을 풀어 보세요.", MessageType.None);
            }
            else
            {
                // Only the rows in view are drawn (and ask for their images); the rest is empty space of the same height.
                var first = Mathf.Clamp(Mathf.FloorToInt(galleryScroll.y / rowHeight), 0, rows - 1);
                var last = Mathf.Clamp(Mathf.FloorToInt((galleryScroll.y + view) / rowHeight), first, rows - 1);
                GUILayout.Space(first * rowHeight);
                var focused = GUIUtility.keyboardControl == galleryControl;
                for (var row = first; row <= last; row++)
                {
                    var rect = GUILayoutUtility.GetRect(inner, rowHeight, GUILayout.Width(inner), GUILayout.Height(rowHeight));
                    for (var column = 0; column < columns; column++)
                    {
                        var index = row * columns + column;
                        if (index >= shown.Count) break;
                        var card = new Rect(rect.x + 4 + column * (cardSize + CardGap), rect.y + CardGap / 2, cardSize, rowHeight - CardGap);
                        DrawCard(card, shown[index], shown[index].id == selectedAsset, focused);
                    }
                }
                GUILayout.Space((rows - last - 1) * rowHeight);
            }
            EditorGUILayout.EndScrollView();
        }

        private void DrawCard(Rect card, AssetRecord asset, bool selected, bool focused)
        {
            var image = new Rect(card.x, card.y, cardSize, cardSize);
            DrawThumbnail(image, AssetTexture(asset, Repaint), KindName(asset.kind));
            var style = selected ? CardNameBold : CardName;
            var nameRect = new Rect(card.x, image.yMax + 2, cardSize, CardText - 2);
            GUI.Label(nameRect, new GUIContent(TwoLines(asset.name, style, cardSize), asset.name), style);
            var x = card.x;
            var y = nameRect.yMax;
            void Badge(string text, string kind, string tip)
            {
                var badgeSize = BadgeSize(text);
                var rect = new Rect(x, y, Mathf.Min(badgeSize.x, card.xMax - x), 16);
                if (rect.width > 8) DrawBadge(rect, new GUIContent(text, tip), kind);
                x += badgeSize.x + 2;
            }
            Badge(KindName(asset.kind), "", "종류");
            if (asset.boothId > 0) Badge("Booth", "good", "Booth 상품과 연결됨");
            else Badge("미연결", "warn", "Booth 상품과 아직 연결하지 않음");
            if (selected)
            {
                // Selected: a frame and a bold name; with the keyboard on the gallery the frame is thicker.
                Frame(new Rect(card.x - 3, card.y - 3, card.width + 6, card.height + 4), SelectedFrame, focused ? 3 : 2);
            }
            var e = Event.current;
            if (e.type == EventType.MouseDown && e.button == 0 && card.Contains(e.mousePosition))
            {
                GUIUtility.keyboardControl = galleryControl;
                if (selectedAsset != asset.id) SelectAsset(asset);
                else if (e.clickCount == 2)
                {
                    // Double click: show the asset's folder in the Project window (the Inspector shows its panel).
                    var folder = AssetFolders.ExistingFolders(asset).FirstOrDefault();
                    if (folder != null)
                    {
                        var target = AssetDatabase.LoadAssetAtPath<DefaultAsset>(folder);
                        Selection.activeObject = target;
                        EditorGUIUtility.PingObject(target);
                    }
                }
                e.Use();
                Repaint();
            }
        }

        // Arrow keys move the selection while the gallery has the keyboard.
        private void Keys(List<AssetRecord> shown, int columns)
        {
            var e = Event.current;
            if (e.type != EventType.KeyDown || GUIUtility.keyboardControl != galleryControl || shown.Count == 0) return;
            int step;
            switch (e.keyCode)
            {
                case KeyCode.LeftArrow: step = -1; break;
                case KeyCode.RightArrow: step = 1; break;
                case KeyCode.UpArrow: step = -columns; break;
                case KeyCode.DownArrow: step = columns; break;
                default: return;
            }
            var index = shown.FindIndex(a => a.id == selectedAsset);
            index = index < 0 ? 0 : Mathf.Clamp(index + step, 0, shown.Count - 1);
            SelectAsset(shown[index]);
            scrollToSelection = true;
            e.Use();
            Repaint();
        }

        private void SelectAsset(AssetRecord asset)
        {
            selectedAsset = asset.id;
            folderMessage = null;
        }

        // The name in at most two lines of the card, cut with "…".
        private static string TwoLines(string text, GUIStyle style, float width)
        {
            text = text ?? "";
            var limit = style.lineHeight * 2 + 2;
            if (style.CalcHeight(new GUIContent(text), width) <= limit) return text;
            int low = 0, high = text.Length;
            while (low < high)
            {
                var middle = (low + high + 1) / 2;
                if (style.CalcHeight(new GUIContent(text.Substring(0, middle) + "…"), width) <= limit) low = middle;
                else high = middle - 1;
            }
            return text.Substring(0, low) + "…";
        }

        private static bool Matches(AssetRecord asset, string text)
        {
            var item = AssetStore.Item(asset.boothId);
            return asset.name.IndexOf(text, StringComparison.CurrentCultureIgnoreCase) >= 0 ||
                   asset.boothName.IndexOf(text, StringComparison.CurrentCultureIgnoreCase) >= 0 ||
                   item != null && (item.shop.IndexOf(text, StringComparison.CurrentCultureIgnoreCase) >= 0 ||
                                    item.tags.Any(t => t.IndexOf(text, StringComparison.CurrentCultureIgnoreCase) >= 0));
        }

        // ---- Detail ----

        private void DrawAssetDetail(AssetRecord asset)
        {
            using (new EditorGUILayout.HorizontalScope())
            {
                DrawThumbnail(AssetTexture(asset, Repaint), 56, KindName(asset.kind));
                using (new EditorGUILayout.VerticalScope())
                {
                    var labelWidth = EditorGUIUtility.labelWidth;
                    EditorGUIUtility.labelWidth = 40;
                    EditorGUI.BeginChangeCheck();
                    var name = EditorGUILayout.DelayedTextField("이름", asset.name);
                    var kind = (AssetKind)EditorGUILayout.Popup("종류", (int)asset.kind, KindNames);
                    if (EditorGUI.EndChangeCheck())
                    {
                        if (!string.IsNullOrWhiteSpace(name)) asset.name = name.Trim();
                        asset.kind = kind;
                        AssetStore.SaveProject();
                    }
                    EditorGUIUtility.labelWidth = labelWidth;
                    var (bytes, files) = AssetFolders.Size(asset);
                    GUILayout.Label($"파일 {files}개 · {AssetFolders.FormatSize(bytes)}" + (asset.package.Length > 0 ? $" · 가져온 패키지: {asset.package}" : ""),
                        EditorStyles.wordWrappedMiniLabel);
                }
            }
            Section("Booth");
            booth.Draw(asset, false, Repaint);
            DrawFolderSection(asset);
            Section("조립");
            assembly.Draw(asset, null, true, Repaint);

            GUILayout.Space(16);
            using (new EditorGUILayout.HorizontalScope())
            {
                GUILayout.FlexibleSpace();
                if (GUILayout.Button(new GUIContent("에셋 목록에서 빼기", "에셋 지정만 풀어요. 파일은 지우지 않아요."), GUILayout.Width(140)) &&
                    EditorUtility.DisplayDialog("에셋 목록에서 빼기", $"‘{asset.name}’을(를) 에셋 목록에서 뺄까요?\n파일은 지우지 않고, Booth 연결과 폴더 지정만 사라져요.", "빼기", "취소"))
                {
                    AssetFolders.Delete(asset);
                    selectedAsset = null;
                    GUIUtility.ExitGUI();
                }
            }
        }

        // ---- Folders ----

        private void DrawFolderSection(AssetRecord asset)
        {
            Section("폴더");
            foreach (var guid in asset.folders.Concat(asset.sharedFolders).ToList())
            {
                var path = AssetDatabase.GUIDToAssetPath(guid);
                var shared = asset.sharedFolders.Contains(guid);
                using (new EditorGUILayout.HorizontalScope(EditorStyles.helpBox))
                {
                    GUILayout.Label(EditorGUIUtility.IconContent("Folder Icon"), GUILayout.Width(18), GUILayout.Height(18));
                    if (path.Length == 0 || !AssetDatabase.IsValidFolder(path)) GUILayout.Label("⚠ 폴더를 찾지 못했어요(지웠거나 프로젝트 밖으로 옮김)", EditorStyles.wordWrappedMiniLabel);
                    else ClippedLabel(path, EditorStyles.label);
                    if (shared) DrawBadge("공용", "", "여러 에셋이 함께 쓰는 폴더");
                    if (GUILayout.Button("보기", EditorStyles.miniButton, GUILayout.Width(40)) && path.Length > 0)
                        EditorGUIUtility.PingObject(AssetDatabase.LoadAssetAtPath<DefaultAsset>(path));
                    if (GUILayout.Button(new GUIContent("빼기", "이 폴더를 에셋에서 빼요. 파일은 지우지 않아요."), EditorStyles.miniButton, GUILayout.Width(40)))
                    {
                        AssetFolders.RemoveFolder(asset, guid);
                        GUIUtility.ExitGUI();
                    }
                }
            }
            if (asset.folders.Count == 0) EditorGUILayout.HelpBox("이 에셋의 폴더가 없어요. Project 창에서 폴더를 고른 뒤 ‘고른 폴더 넣기’를 누르세요.", MessageType.Warning);
            var selected = Selection.assetGUIDs.Select(AssetDatabase.GUIDToAssetPath).Where(AssetDatabase.IsValidFolder).ToList();
            var reason = selected.Count == 0 ? "Project 창에서 폴더를 먼저 고르세요." : null;
            using (new EditorGUI.DisabledScope(reason != null))
            {
                if (GUILayout.Button(new GUIContent($"고른 폴더 넣기 ({selected.Count})", reason ?? "이 에셋만 쓰는 폴더로 넣어요."), EditorStyles.miniButton))
                    AddFolders(asset, selected, false);
                if (GUILayout.Button(new GUIContent("공용 폴더로 넣기", reason ?? "같은 샵의 Common 폴더처럼 여러 에셋이 함께 쓰는 폴더로 넣어요."), EditorStyles.miniButton))
                    AddFolders(asset, selected, true);
            }
            if (reason != null) GUILayout.Label(reason, EditorStyles.miniLabel);
            if (!string.IsNullOrEmpty(folderMessage)) EditorGUILayout.HelpBox(folderMessage, MessageType.Warning);
        }

        private void AddFolders(AssetRecord asset, List<string> paths, bool shared)
        {
            var problems = new List<string>();
            foreach (var path in paths)
            {
                try { AssetFolders.AddFolder(asset, path, shared); }
                catch (InvalidOperationException e) { problems.Add($"{Path.GetFileName(path)}: {e.Message}"); }
            }
            folderMessage = problems.Count > 0 ? string.Join("\n", problems) : null;
            GUIUtility.ExitGUI();
        }
    }
}
