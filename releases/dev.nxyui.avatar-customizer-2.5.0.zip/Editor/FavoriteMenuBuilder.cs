#if UNITY_EDITOR
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using nadena.dev.ndmf;
using nadena.dev.ndmf.platform;
using UnityEditor;
using UnityEngine;
using VRC.SDK3.Avatars.Components;
using VRC.SDK3.Avatars.ScriptableObjects;
using Control = VRC.SDK3.Avatars.ScriptableObjects.VRCExpressionsMenu.Control;
using Object = UnityEngine.Object;

[assembly: ExportsPlugin(typeof(AvatarMenuTools.FavoriteMenuPlugin))]

namespace AvatarMenuTools
{
    public sealed class FavoriteMenuPlugin : Plugin<FavoriteMenuPlugin>
    {
        public override string QualifiedName => "dev.nxyui.avatar-customizer";
        public override string DisplayName => "Avatar Customizer";

        protected override void Configure()
        {
            InPhase(BuildPhase.Resolving).Run("Read avatar menu settings", FavoriteMenuBuilder.ReadSettings);
            InPhase(BuildPhase.Generating)
                .BeforePlugin("nadena.dev.modular-avatar")
                .Run("Generate blendshape controls", BlendshapeControlBuilder.Generate);
            InPhase(BuildPhase.PlatformFinish)
                .AfterPlugin("nadena.dev.modular-avatar")
                .Run("Apply menu names and favorites", FavoriteMenuBuilder.Build);
        }
    }

    internal static class FavoriteMenuBuilder
    {
        // Modular Avatar names its overflow link "More" and gives it Runtime/Icons/Icon_More_A.png (MenuInstallHook).
        // Find the icon by GUID first, so a moved file still matches.
        private const string MoreIconGuid = "2509fbb49062a464dbb0843b7c4f59d8";
        private const string MoreIconPath = "Packages/nadena.dev.modular-avatar/Runtime/Icons/Icon_More_A.png";
        private const string ModularAvatarRoot = "Packages/nadena.dev.modular-avatar/";

        internal static Texture2D LoadMoreIcon()
        {
            var path = AssetDatabase.GUIDToAssetPath(MoreIconGuid);
            var icon = string.IsNullOrEmpty(path) ? null : AssetDatabase.LoadAssetAtPath<Texture2D>(path);
            return icon ? icon : AssetDatabase.LoadAssetAtPath<Texture2D>(MoreIconPath);
        }

        // Either signal is enough, so a change to only the label or only the icon keeps working.
        // A "More" link with the user's own icon is still treated as a normal submenu, as before.
        internal static bool IsMoreLink(Control c, Texture2D moreIcon) =>
            (moreIcon && c.icon == moreIcon) ||
            (c.name == "More" && (!c.icon || AssetDatabase.GetAssetPath(c.icon).StartsWith(ModularAvatarRoot, StringComparison.Ordinal)));

        private sealed class State
        {
            internal string PageLabel;
            internal FavoriteMenuGroup[] Menus;
            internal MenuNameOverride[] Overrides;
            internal MenuMoveRule[] Moves;
            internal MenuDefaultOverride[] Defaults;
        }

        internal sealed class Scan : IDisposable
        {
            internal readonly GameObject Avatar;
            internal FavoriteMenuKey[] Menu;
            // Expression parameter defaults before this tool changes any, by parameter name.
            internal Dictionary<string, float> Defaults;
            internal string Result;
            internal bool HasWarnings;
            internal readonly List<Issue> Issues = new List<Issue>();
            // The favorites menus this build made, so the review can point them out.
            internal readonly HashSet<VRCExpressionsMenu> FavoriteMenus = new HashSet<VRCExpressionsMenu>();
            // The menu after "원본 메뉴 정리" (renames and moves): what the favorites tab picks from.
            internal FavoriteMenuKey[] Organized;
            // A copy of the menu as the avatar's tools built it (Tree, with every menu in TreeMenus), kept apart from the
            // build's assets so the window can organize it again without building. The reader destroys TreeMenus.
            internal VRCExpressionsMenu Tree;
            internal List<VRCExpressionsMenu> TreeMenus;
            internal Scan(GameObject avatar) { Avatar = avatar; activeScan = this; }
            public void Dispose() { if (activeScan == this) activeScan = null; }
        }

        internal enum RepairTarget { None, Shortcut, Destination, NameOverride, Move, MoveDestination }

        internal sealed class Issue
        {
            internal string Title, Detail;
            internal bool Warning;
            internal RepairTarget Target;
            internal int MenuIndex, ItemIndex;
            internal FavoriteMenuKey Saved, Current;
        }

        internal static string Describe(FavoriteMenuKey key)
        {
            if (key == null) return "(없음)";
            if (key.type == Control.ControlType.SubMenu && key.Binding.Length == 0)
                return key.DisplayPath;
            var parameters = (key.subParameters ?? Array.Empty<string>())
                .Select(p => string.IsNullOrEmpty(p) ? "—" : p);
            string binding = string.Join(" · ", new[] { key.parameter }.Concat(parameters)
                .Where(p => !string.IsNullOrEmpty(p)));
            return $"{key.DisplayPath}  [{key.type} · {binding} · 값 {key.value}]";
        }

        private static Scan activeScan;

        internal static void ReadSettings(BuildContext context)
        {
            var c = context.AvatarRootObject.GetComponent<AvatarCustomizer>();
            if (!c || !c.enabled) return;
            var state = context.GetState<State>();
            state.Menus = new[] { c.GetMenu(0) }.Concat(c.additionalMenus ?? Enumerable.Empty<FavoriteMenuGroup>()).ToArray();
            state.Overrides = c.nameOverrides?.ToArray() ?? Array.Empty<MenuNameOverride>();
            state.Moves = c.menuMoves?.Where(m => m?.source != null).ToArray() ?? Array.Empty<MenuMoveRule>();
            state.Defaults = c.defaultOverrides?.Where(o => o?.source != null).ToArray() ?? Array.Empty<MenuDefaultOverride>();
            state.PageLabel = string.IsNullOrWhiteSpace(c.nextPageLabel) ? null : c.nextPageLabel.Trim();
        }

        internal static string MatchDetail(FavoriteMenuMatch match)
        {
            switch (match)
            {
                case FavoriteMenuMatch.Moved: return "경로가 바뀌었지만 같은 동작에 연결됩니다.";
                case FavoriteMenuMatch.Changed: return "같은 경로에서 동작이 바뀌었습니다. 아래 내용을 확인하세요.";
                case FavoriteMenuMatch.Ambiguous: return "원본 후보가 여러 개라 빌드에서 제외됩니다.";
                default: return "원본을 찾을 수 없어 빌드에서 제외됩니다.";
            }
        }

        internal static void Build(BuildContext context)
        {
            var avatar = context.AvatarRootObject;
            var descriptor = avatar.GetComponent<VRCAvatarDescriptor>();
            if (!descriptor) return;
            var scan = activeScan?.Avatar == avatar ? activeScan : null;
            var config = context.GetState<State>();
            bool configured = config.Menus != null &&
                (config.Menus.Any(m => (m?.entries?.Count ?? 0) > 0) || config.Overrides.Length > 0 || config.Defaults.Length > 0 ||
                 config.Moves.Length > 0 || config.PageLabel != null);
            if (!configured && scan == null) return;
            var root = descriptor.expressionsMenu;
            var parameters = descriptor.expressionParameters;

            var issues = scan?.Issues ?? new List<Issue>();
            void Report(string title, string detail, bool warning = true, RepairTarget target = RepairTarget.None,
                int menuIndex = -1, int itemIndex = -1, FavoriteMenuKey saved = null, FavoriteMenuKey current = null)
            {
                issues.Add(new Issue
                {
                    Title = title, Detail = detail, Warning = warning, Target = target,
                    MenuIndex = menuIndex, ItemIndex = itemIndex, Saved = saved, Current = current,
                });
            }

            if (scan != null)
            {
                scan.TreeMenus = new List<VRCExpressionsMenu>();
                scan.Tree = MenuOrganizer.Snapshot(root, scan.TreeMenus);
                scan.Defaults = (parameters ? parameters.parameters : null)?.Where(p => p != null && !string.IsNullOrEmpty(p.name))
                    .GroupBy(p => p.name).ToDictionary(g => g.Key, g => g.First().defaultValue) ?? new Dictionary<string, float>();
            }
            // First edit ("원본 메뉴 정리"): renames and moves, on a copy of the finished menu.
            var organizer = new MenuOrganizer(root, LoadMoreIcon(), configured ? config.PageLabel : null,
                configured ? config.Overrides : null, configured ? config.Moves : null,
                (title, detail, warning, target, index, saved, current) => Report(title, detail, warning, target, -1, index, saved, current));
            if (scan != null)
            {
                scan.Menu = organizer.Original;
                scan.Organized = organizer.Organized;
            }
            if (!configured)
            {
                foreach (var unused in organizer.Created) Object.DestroyImmediate(unused);
                return;
            }

            // Second edit: the favorites menus, made from the organized menu.
            var shapes = context.GetState<BlendshapeControlBuilder.State>();
            var keys = organizer.Organized;
            var items = organizer.OrganizedItems;
            var rootCopy = organizer.Root;
            Control Match(FavoriteMenuKey saved, string title, RepairTarget target, int menuIndex, int itemIndex)
            {
                var current = FavoriteMenuKey.Resolve(keys, saved, out var match);
                if (match != FavoriteMenuMatch.Exact)
                    Report(title, MatchDetail(match), match != FavoriteMenuMatch.Moved, target, menuIndex, itemIndex, saved, current);
                return current == null ? null : items[current];
            }

            int menuCount = 0, favoriteCount = 0, folderCount = 0, shapeCount = 0;
            // Favorites menus placed without a pin, to say afterwards when one ended up behind a page link.
            var placements = new List<(string Name, bool AtRoot, VRCExpressionsMenu First, Control Control)>();
            var pinCounts = new Dictionary<VRCExpressionsMenu, int>();
            var installedNames = new Dictionary<VRCExpressionsMenu, HashSet<string>>();
            for (int menuIndex = 0; menuIndex < config.Menus.Length; menuIndex++)
            {
                var menu = config.Menus[menuIndex];
                if ((menu?.entries?.Count ?? 0) == 0) continue;
                string menuName = menu.DisplayName;
                string location = $"{menuName} / 설치 위치";
                var destination = menu.useRoot ? rootCopy :
                    Match(menu.destination, location, RepairTarget.Destination, menuIndex, -1)?.subMenu;
                if (!destination)
                {
                    if (menu.useRoot || !issues.Any(i => i.Title == location && i.Current == null))
                        Report(location, "설치할 메뉴가 비어 있거나 찾을 수 없습니다.", true,
                            menu.useRoot ? RepairTarget.None : RepairTarget.Destination, menuIndex, -1, menu.destination);
                    continue;
                }
                var links = new HashSet<Control>(organizer.PageLinks.Values);
                var pages = organizer.Pages(destination).ToArray();
                bool duplicate = pages.SelectMany(p => p.controls).Any(c =>
                    c != null && !links.Contains(c) && c.type == Control.ControlType.SubMenu && c.name == menuName);
                if (duplicate || (installedNames.TryGetValue(destination, out var siblings) && siblings.Contains(menuName)))
                {
                    Report(menuName, "같은 위치에 이름이 같은 메뉴가 있어 생성을 건너뛰었습니다.");
                    continue;
                }

                var target = pages.Last();
                var children = menu.entries.Select((entry, index) => (entry, index))
                    .Where(x => x.entry != null).ToLookup(x => x.entry.Parent);
                var madeFolders = new HashSet<string>();
                List<Control> MakeChildren(string parent, string path, int depth)
                {
                    var controls = new List<Control>();
                    foreach (var (entry, index) in children[parent])
                    {
                        if (entry.IsFolder)
                        {
                            string label = string.IsNullOrWhiteSpace(entry.label) ? "새 폴더" : entry.label.Trim();
                            string folderPath = $"{path} / {label}";
                            if (depth >= 64 || !madeFolders.Add(entry.folderId))
                            {
                                Report(folderPath, "폴더 깊이를 초과했거나 폴더가 중복되어 제외됩니다.");
                                continue;
                            }
                            var contents = MakeChildren(entry.folderId, folderPath, depth + 1);
                            if (contents.Count == 0)
                            {
                                Report(folderPath, "사용할 수 있는 항목이 없어 빌드에서 생략됩니다.", false);
                                continue;
                            }
                            var sub = organizer.NewMenu(label);
                            sub.controls = contents;
                            organizer.Paginate(sub);
                            var folder = Submenu(label, sub);
                            folder.icon = entry.icon;
                            controls.Add(folder);
                            folderCount++;
                            continue;
                        }
                        if (entry.IsShape)
                        {
                            if (!shapes.Controls.TryGetValue(entry.shapeId, out var built))
                            {
                                Report($"{path} / {(string.IsNullOrWhiteSpace(entry.label) ? "블렌드쉐이프" : entry.label.Trim())}",
                                    (shapes.Problems.TryGetValue(entry.shapeId, out var problem) ? problem : "블렌드쉐이프 컨트롤을 만들 수 없습니다.") +
                                    " 이 항목은 빌드에서 제외됩니다.");
                                continue;
                            }
                            if (shapes.Notes.TryGetValue(entry.shapeId, out var note))
                                Report($"{path} / {(string.IsNullOrWhiteSpace(entry.label) ? built.Name : entry.label.Trim())}", note, false);
                            controls.Add(built.Reset ? new Control
                            {
                                name = string.IsNullOrWhiteSpace(entry.label) ? built.Name : entry.label.Trim(),
                                type = Control.ControlType.Button, icon = entry.icon, value = 1f,
                                parameter = new Control.Parameter { name = built.Parameter },
                                subParameters = new Control.Parameter[0], labels = new Control.Label[0],
                            } : new Control
                            {
                                name = string.IsNullOrWhiteSpace(entry.label) ? built.Name : entry.label.Trim(),
                                type = built.Radial ? Control.ControlType.RadialPuppet : Control.ControlType.Toggle,
                                icon = entry.icon, value = 1f,
                                parameter = new Control.Parameter { name = built.Radial ? "" : built.Parameter },
                                subParameters = built.Radial ? new[] { new Control.Parameter { name = built.Parameter } } : new Control.Parameter[0],
                                labels = new Control.Label[0],
                            });
                            shapeCount++;
                            continue;
                        }
                        string title = $"{path} / {entry.source?.DisplayPath ?? "(원본 없음)"}";
                        var control = Match(entry.source, title, RepairTarget.Shortcut, menuIndex, index);
                        if (control == null) continue;
                        // Check the build graph, including the menus already installed at other destinations.
                        if (control.type == Control.ControlType.SubMenu &&
                            (!control.subMenu || Reaches(control.subMenu, destination, target, new HashSet<VRCExpressionsMenu>())))
                        {
                            Report(title, control.subMenu ? "메뉴가 순환하므로 바로가기를 제외했습니다." :
                                "연결된 하위 메뉴가 없습니다.", true, RepairTarget.Shortcut, menuIndex, index, entry.source);
                            continue;
                        }
                        // The organized copy already has its shown name; a shortcut opens the same (organized) submenu.
                        var shortcut = Copy(control, string.IsNullOrWhiteSpace(entry.label) ? control.name : entry.label.Trim(), m => m);
                        if (entry.icon) shortcut.icon = entry.icon;
                        controls.Add(shortcut);
                        favoriteCount++;
                    }
                    return controls;
                }

                var chosen = MakeChildren("", menuName, 0);
                if (chosen.Count == 0) continue;
                var favorites = organizer.NewMenu(menuName);
                scan?.FavoriteMenus.Add(favorites);
                favorites.controls = chosen;
                organizer.Paginate(favorites);
                var installed = Submenu(menuName, favorites);
                installed.icon = menu.icon;
                pinCounts.TryGetValue(destination, out int slot);
                if (menu.pinToFirstPage && slot < VRCExpressionsMenu.MAX_CONTROLS - 1)
                {
                    var before = scan == null ? null : organizer.OriginalPages(destination);
                    organizer.InsertPinned(destination, slot, installed);
                    pinCounts[destination] = slot + 1;
                    if (before != null)
                    {
                        var after = organizer.OriginalPages(destination);
                        var pushed = before.Where(p => after.TryGetValue(p.Key, out int page) && p.Value != page)
                            .Select(p => $"{p.Key.name} ({p.Value} → {after[p.Key]}페이지)").ToArray();
                        if (pushed.Length > 0)
                            Report(menuName, "고정으로 이동한 기존 항목\n" + string.Join("\n", pushed), false);
                    }
                }
                else
                {
                    if (menu.pinToFirstPage) Report(menuName, "고정할 수 있는 자리가 가득 차 마지막 페이지에 배치됩니다.");
                    target.controls.Add(installed);
                    organizer.Paginate(target);
                }
                if (!menu.pinToFirstPage) placements.Add((menuName, menu.useRoot, destination, installed));
                if (!installedNames.TryGetValue(destination, out var used)) installedNames.Add(destination, used = new HashSet<string>());
                used.Add(menuName);
                menuCount++;
            }

            // Behind a page link a favorites menu is easy to miss, so say where it ended up.
            foreach (var placed in placements)
            {
                int placedPage = organizer.PageOf(placed.First, placed.Control);
                if (placedPage > 1)
                    Report(placed.Name, $"{(placed.AtRoot ? "최상위 메뉴" : "설치 위치")}의 {placedPage}페이지" +
                        (placedPage == 2 ? $"(‘{organizer.PageLabel}’ 안)" : "") + "에 들어갔어요. 앞 페이지가 가득 찼기 때문이에요. " +
                        "첫 페이지에 두려면 이 메뉴의 ‘첫 페이지에 고정’을 켜세요.", false);
            }

            // Default values: the starting value of the parameter behind a favorite, on a copy of the expression parameters.
            var defaults = new Dictionary<string, (float Value, string Title)>();
            void AddDefault(FavoriteMenuKey source, float stored, string title, bool reportMissing)
            {
                var key = FavoriteMenuKey.Resolve(keys, source);
                if (key == null)
                {
                    if (reportMissing) Report(title, "원본 메뉴 항목을 찾을 수 없어 기본값을 적용하지 못했습니다.");
                    return;
                }
                var control = items[key];
                string parameter;
                float value;
                if (control.type == Control.ControlType.Toggle)
                {
                    parameter = control.parameter?.name;
                    value = stored >= .5f ? control.value : 0f;
                }
                else if (control.type == Control.ControlType.RadialPuppet)
                {
                    parameter = control.subParameters?.FirstOrDefault()?.name;
                    value = Mathf.Clamp01(stored);
                }
                else
                {
                    Report(title, "토글과 래디얼만 기본값을 정할 수 있어 제외했습니다.", false);
                    return;
                }
                if (string.IsNullOrEmpty(parameter))
                {
                    Report(title, "파라미터가 없는 항목이라 기본값을 정할 수 없습니다.");
                    return;
                }
                if (defaults.TryGetValue(parameter, out var prior))
                {
                    if (!Mathf.Approximately(prior.Value, value))
                        Report(title, $"‘{parameter}’의 기본값은 먼저 정한 {prior.Title}을 따릅니다. 이 값은 제외했습니다.");
                    return;
                }
                defaults.Add(parameter, (value, title));
            }
            foreach (var rule in config.Defaults)
                AddDefault(rule.source, rule.value, $"기본값 / {rule.source.DisplayPath}", true);
            // Defaults saved on a favorite by 2.0.0. A missing original is already reported for the shortcut.
            foreach (var menu in config.Menus)
                foreach (var entry in menu?.entries ?? new List<FavoriteMenuEntry>())
                    if (entry != null && !entry.IsFolder && !entry.IsShape && entry.overrideDefault)
                        AddDefault(entry.source, entry.defaultValue, $"{menu.DisplayName} / {entry.source?.DisplayPath} · 기본값", false);
            int defaultCount = 0;
            if (defaults.Count > 0 && !parameters)
                Report("기본값", "Expression Parameters가 없어 기본값을 바꾸지 못했습니다.");
            else if (defaults.Count > 0)
            {
                // Never edit the project's asset: the build gets its own copy.
                var copy = Object.Instantiate(parameters);
                copy.name = parameters.name;
                foreach (var pair in defaults)
                {
                    var parameter = copy.parameters?.FirstOrDefault(x => x != null && x.name == pair.Key);
                    if (parameter == null)
                    {
                        Report(pair.Value.Title, $"‘{pair.Key}’이 Expression Parameters에 없어 기본값을 바꾸지 못했습니다.");
                        continue;
                    }
                    parameter.defaultValue = parameter.valueType == VRCExpressionParameters.ValueType.Bool ? (pair.Value.Value >= .5f ? 1f : 0f)
                        : parameter.valueType == VRCExpressionParameters.ValueType.Int ? Mathf.Round(pair.Value.Value) : pair.Value.Value;
                    defaultCount++;
                }
                if (defaultCount > 0)
                {
                    context.AssetSaver.SaveAsset(copy);
                    descriptor.expressionParameters = copy;
                }
                else Object.DestroyImmediate(copy);
            }

            int nameCount = organizer.NameCount, moveCount = organizer.MoveCount;
            if (rootCopy && (menuCount > 0 || nameCount > 0 || moveCount > 0 || config.PageLabel != null))
            {
                // All edits belong to this avatar's build copy.
                context.AssetSaver.SaveAssets(organizer.Created);
                descriptor.expressionsMenu = rootCopy;
            }
            else foreach (var unused in organizer.Created) Object.DestroyImmediate(unused);
            var warnings = issues.Where(i => i.Warning).Select(i => i.Title + " · " + i.Detail).ToArray();
            if (scan != null)
            {
                scan.HasWarnings = warnings.Length > 0;
                scan.Result = $"메뉴 {menuCount}개 · 즐겨찾기 {favoriteCount}개 · 폴더 {folderCount}개 · 이름 변경 {nameCount}개" +
                    (moveCount > 0 ? $" · 이동 {moveCount}개" : "") + (shapeCount > 0 ? $" · 블렌드쉐이프 {shapeCount}개" : "") + (defaultCount > 0 ? $" · 기본값 {defaultCount}개" : "");
                if (scan.HasWarnings) scan.Result += "\n" + string.Join("\n", warnings);
            }
            else foreach (var warning in warnings) Debug.LogWarning("[Avatar Customizer] " + warning, avatar);
        }

        // Runs every installed NDMF plug-in through the Transforming phase (where Modular Avatar installs menus),
        // then this tool's menu pass, skipping optimisers. Returns null, before touching the avatar, when this NDMF
        // version lacks the internals used here. assetFolder holds the build's generated assets, as in a full build:
        // many plug-ins store theirs next to the build's asset container (AssetDatabase.AddObjectToAsset) and fail
        // without one. The caller deletes the folder; null keeps everything in memory.
        internal static BuildContext ProcessFast(GameObject root, string assetFolder)
        {
            const BindingFlags all = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static;
            var asm = typeof(BuildContext).Assembly;
            var resolverType = asm.GetType("nadena.dev.ndmf.PluginResolver", false);
            var concreteType = asm.GetType("nadena.dev.ndmf.ConcretePass", false);
            var find = resolverType?.GetMethod("FindPluginTypes", all);
            var ctor = resolverType?.GetConstructor(all, null,
                new[] { typeof(IEnumerable<Type>), typeof(INDMFPlatformProvider), typeof(bool) }, null);
            var passesProperty = resolverType?.GetProperty("Passes", all);
            var run = concreteType == null ? null : typeof(BuildContext).GetMethod("RunPass", all, null, new[] { concreteType }, null);
            if (find == null || ctor == null || passesProperty == null || run == null ||
                !typeof(IEnumerable<Type>).IsAssignableFrom(find.ReturnType))
                return null;
            var platform = AmbientPlatform.DefaultPlatform;
            var plan = new List<object>();
            using (new AmbientPlatform.Scope(platform))
            {
                var resolver = ctor.Invoke(new[] { find.Invoke(null, null), platform, false });
                if (!(passesProperty.GetValue(resolver) is IEnumerable phases)) return null;
                foreach (var pair in phases)
                {
                    var type = pair?.GetType();
                    var phaseField = type?.GetField("Item1");
                    var passesField = type?.GetField("Item2");
                    if (phaseField?.FieldType != typeof(BuildPhase) || passesField == null || !(passesField.GetValue(pair) is IEnumerable passes))
                        return null;
                    var phase = (BuildPhase)phaseField.GetValue(pair);
                    if (phase == BuildPhase.Optimizing) break;
                    foreach (var pass in passes)
                    {
                        if (!concreteType.IsInstanceOfType(pass)) return null;
                        plan.Add(pass);
                    }
                    if (phase == BuildPhase.Transforming) break;
                }
            }
            var context = new BuildContext(root, assetFolder, platform);
            try
            {
                using (new AmbientPlatform.Scope(platform))
                {
                    foreach (var pass in plan) run.Invoke(context, new[] { pass });
                    Build(context);
                }
            }
            catch (TargetInvocationException e) when (e.InnerException != null)
            {
                throw new InvalidOperationException(e.InnerException.Message, e.InnerException);
            }
            finally
            {
                try { context.DeactivateAllExtensionContexts(); }
                finally { context.AssetSaver.Dispose(); }
            }
            return context;
        }

        internal static bool Reaches(VRCExpressionsMenu menu, VRCExpressionsMenu destination, VRCExpressionsMenu end,
            HashSet<VRCExpressionsMenu> seen)
        {
            if (!menu || !seen.Add(menu)) return false;
            if (menu == destination || menu == end) return true;
            return menu.controls != null && menu.controls.Any(c => c?.type == Control.ControlType.SubMenu &&
                Reaches(c.subMenu, destination, end, seen));
        }

        internal static Control Copy(Control c, string name, Func<VRCExpressionsMenu, VRCExpressionsMenu> map) => new Control
        {
            name = name, type = c.type, icon = c.icon, value = c.value, style = c.style,
            parameter = new Control.Parameter { name = c.parameter?.name ?? "" },
            subParameters = (c.subParameters ?? Array.Empty<Control.Parameter>())
                .Select(p => new Control.Parameter { name = p?.name ?? "" }).ToArray(),
            labels = (c.labels ?? Array.Empty<Control.Label>()).ToArray(),
            subMenu = c.type == Control.ControlType.SubMenu ? map(c.subMenu) : c.subMenu,
        };

        internal static Control Submenu(string name, VRCExpressionsMenu menu) => new Control
        {
            name = name, type = Control.ControlType.SubMenu, subMenu = menu, parameter = new Control.Parameter(),
        };

        internal static VRCExpressionsMenu NewMenu(string name, List<VRCExpressionsMenu> created)
        {
            var menu = ScriptableObject.CreateInstance<VRCExpressionsMenu>();
            menu.name = name;
            menu.controls = new List<Control>();
            created.Add(menu);
            return menu;
        }
    }
}
#endif
