using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using nadena.dev.ndmf;
using nadena.dev.ndmf.platform;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using Object = UnityEngine.Object;

namespace PersonalPoseDeck
{
    internal sealed class PoseDeckAssemblyPreview : IDisposable
    {
        private const BindingFlags All = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static;
        private Scene scene;
        private readonly HashSet<Object> generated = new HashSet<Object>();
        // Every object in memory before the assembly ran (instance IDs). Only objects made by the assembly are destroyed
        // with it: one that existed already belongs to the scene avatar, another object of the scene, or a cache, even
        // when a plug-in of the full NDMF build linked it into the copy.
        private HashSet<int> existed;
        internal GameObject Root { get; private set; }
        // True when the MA-only path was unavailable and every installed NDMF plug-in ran instead.
        internal bool UsedFullBuild { get; private set; }

        internal PoseDeckAssemblyPreview(GameObject source)
        {
            scene = EditorSceneManager.NewPreviewScene();
            var stage = EditorUtility.CreateGameObjectWithHideFlags("Pose Deck staging", HideFlags.HideAndDontSave);
            try
            {
                SceneManager.MoveGameObjectToScene(stage, scene);
                stage.SetActive(false);
                Root = Object.Instantiate(source, stage.transform, false);
                Root.name = source.name + " (Pose Deck Preview)";
                Root.SetActive(false);
                Root.transform.SetParent(null, false);
                Root.transform.SetPositionAndRotation(Vector3.zero, Quaternion.identity);
                Root.transform.localScale = source.transform.lossyScale;
                existed = new HashSet<int>(Resources.FindObjectsOfTypeAll<Object>().Select(o => o.GetInstanceID()));
                // Keep MA and SDK tags; prevent unrelated edit-mode scripts from running in the clone.
                foreach (var script in Root.GetComponentsInChildren<MonoBehaviour>(true))
                {
                    if (!script) continue;
                    var type = script.GetType();
                    var ns = type.Namespace ?? "";
                    if (ns.StartsWith("nadena.dev.", StringComparison.Ordinal) || ns.StartsWith("VRC.", StringComparison.Ordinal)) continue;
                    if (type.IsDefined(typeof(ExecuteAlways), true) || type.IsDefined(typeof(ExecuteInEditMode), true))
                        Object.DestroyImmediate(script);
                }
                Root.SetActive(true);
                if (!TryApplyModularAvatar(Root))
                {
                    UsedFullBuild = true;
                    ApplyFullBuild(Root);
                }
                Root.hideFlags = HideFlags.HideAndDontSave;
                CollectGenerated();
            }
            catch
            {
                CollectGenerated();
                Dispose();
                throw;
            }
        }

        // Returns false, before touching the avatar, when this NDMF version no longer has the internals used here.
        private static bool TryApplyModularAvatar(GameObject root)
        {
            // NDMF's public full bake runs all installed plug-ins. Resolve only its core and MA passes for preview.
            var asm = typeof(BuildContext).Assembly;
            var resolverType = asm.GetType("nadena.dev.ndmf.PluginResolver", false);
            var concreteType = asm.GetType("nadena.dev.ndmf.ConcretePass", false);
            var find = resolverType?.GetMethod("FindPluginTypes", All);
            var ctor = resolverType?.GetConstructor(All, null,
                new[] { typeof(IEnumerable<Type>), typeof(INDMFPlatformProvider), typeof(bool) }, null);
            var passesProperty = resolverType?.GetProperty("Passes", All);
            var run = concreteType == null ? null : typeof(BuildContext).GetMethod("RunPass", All, null, new[] { concreteType }, null);
            if (find == null || ctor == null || passesProperty == null || run == null ||
                !typeof(IEnumerable<Type>).IsAssignableFrom(find.ReturnType))
                return false;

            var pluginTypes = ((IEnumerable<Type>)find.Invoke(null, null)).Where(t =>
                (t.Assembly == asm && t.Name == "InternalPasses") ||
                (t.Namespace ?? "").StartsWith("nadena.dev.modular_avatar.", StringComparison.Ordinal)).ToArray();
            // MA's plug-in type name is internal too; if it moved, use the public full build instead.
            if (!pluginTypes.Any(t => t.Name == "PluginDefinition")) return false;

            // Read the whole pass list first. BuildContext marks the avatar, so create it only once the layout is known.
            var platform = AmbientPlatform.DefaultPlatform;
            var plan = new List<object>();
            using (new AmbientPlatform.Scope(platform))
            {
                var resolver = ctor.Invoke(new object[] { pluginTypes, platform, false });
                if (!(passesProperty.GetValue(resolver) is IEnumerable phases)) return false;
                foreach (var pair in phases)
                {
                    var pairType = pair?.GetType();
                    var phaseField = pairType?.GetField("Item1");
                    var passesField = pairType?.GetField("Item2");
                    if (phaseField?.FieldType != typeof(BuildPhase) || passesField == null ||
                        !(passesField.GetValue(pair) is IEnumerable passes))
                        return false;
                    var phase = (BuildPhase)phaseField.GetValue(pair);
                    if (phase == BuildPhase.Optimizing) break;
                    foreach (var pass in passes)
                    {
                        if (!concreteType.IsInstanceOfType(pass)) return false;
                        plan.Add(pass);
                    }
                    if (phase == BuildPhase.Transforming) break;
                }
            }
            if (plan.Count == 0) throw new InvalidOperationException("실행할 MA 조립 패스가 없습니다.");

            var context = new BuildContext(root, (string)null, platform);
            try
            {
                using (new AmbientPlatform.Scope(context.PlatformProvider))
                    foreach (var pass in plan) run.Invoke(context, new[] { pass });
            }
            catch (TargetInvocationException e) when (e.InnerException != null)
            {
                throw new InvalidOperationException(e.InnerException.Message, e.InnerException);
            }
            finally
            {
                try { context.DeactivateAllExtensionContexts(); }
                finally { context.AssetSaver.Dispose(); }
            }
            if (!context.Successful)
                throw new InvalidOperationException("Modular Avatar 조립 중 오류가 발생했습니다. Unity Console을 확인하세요.");
            return true;
        }

        // Public NDMF API. A null temporary directory keeps generated assets in memory, as in the MA-only path.
        private static void ApplyFullBuild(GameObject root)
        {
            BuildContext context;
            using (new OverrideTemporaryDirectoryScope(null))
                context = nadena.dev.ndmf.AvatarProcessor.ProcessAvatar(root, AmbientPlatform.DefaultPlatform);
            if (!context.Successful)
                throw new InvalidOperationException("NDMF 전체 빌드로 조립하던 중 오류가 발생했습니다. Unity Console을 확인하세요.");
        }

        // What the assembly made for the clone, followed from its components through every object reference to objects
        // that exist only in memory and did not exist before (`made`): merged animators with their state machines,
        // states, transitions, trees and clips, menus, parameters, meshes, materials. A real build saves these next to
        // the avatar and deletes them afterwards; here nothing did, and until 0.22.0 only the meshes, materials and the
        // Animator's own controller were destroyed, so every new assembly left the previous one's animators and menus in
        // memory. EditorUtility.CollectDependencies reports none of these objects (measured: not one of the merged
        // animators), so the references are read here. An object that existed before is neither taken nor walked
        // through: what it refers to is its owner's.
        private static HashSet<Object> InMemoryAssets(GameObject root, Func<Object, bool> made)
        {
            var found = new HashSet<Object>();
            var pending = new Stack<Object>(root.GetComponentsInChildren<Component>(true).Where(c => c));
            void Add(Object value)
            {
                if (value && !(value is GameObject) && !(value is Component) && !EditorUtility.IsPersistent(value) && made(value) &&
                    found.Add(value))
                    pending.Push(value);
            }
            while (pending.Count > 0)
            {
                var owner = pending.Pop();
                // Meshes and textures refer to nothing, and their data is too large to walk. A clip refers to objects
                // only through its object curves.
                if (owner is Mesh || owner is Texture) continue;
                if (owner is AnimationClip clip)
                {
                    foreach (var binding in AnimationUtility.GetObjectReferenceCurveBindings(clip))
                        foreach (var key in AnimationUtility.GetObjectReferenceCurve(clip, binding)) Add(key.value);
                    continue;
                }
                using (var serialized = new SerializedObject(owner))
                {
                    var property = serialized.GetIterator();
                    while (property.Next(true))
                        if (property.propertyType == SerializedPropertyType.ObjectReference) Add(property.objectReferenceValue);
                }
            }
            return found;
        }

        private void CollectGenerated()
        {
            if (!Root || existed == null) return;
            generated.UnionWith(InMemoryAssets(Root, asset => !existed.Contains(asset.GetInstanceID())));
        }

        public void Dispose()
        {
            if (scene.IsValid()) EditorSceneManager.ClosePreviewScene(scene);
            Root = null;
            foreach (var asset in generated) if (asset) Object.DestroyImmediate(asset);
            generated.Clear();
        }
    }
}
