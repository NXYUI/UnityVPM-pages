using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using nadena.dev.modular_avatar.core;
using UnityEditor;
using UnityEditor.Animations;
using UnityEditor.SceneManagement;
using UnityEngine;
using VRC.SDK3.Avatars.Components;
using VRC.SDK3.Avatars.ScriptableObjects;
using Layer = VRC.SDK3.Avatars.Components.VRCAvatarDescriptor.AnimLayerType;

namespace PersonalPoseDeck
{
    // Project metadata for recognising the scene instance without adding a script to the avatar.
    public sealed class PoseDeckAvatarInstallation : ScriptableObject
    {
        [SerializeField] internal GameObject sourcePrefab;
        [SerializeField] internal AnimatorController controller;
        [SerializeField] internal VRCExpressionsMenu menu;
        // Recorded since 0.9.0. Older installations are matched to the preset next to their generated folder.
        [SerializeField] internal PoseDeckPreset preset;
        // Since 0.22.0, when the deck put its start heights in a copy of the Action: the Action it was made from and the copy.
        [SerializeField] internal AnimatorController stockAction;
        [SerializeField] internal AnimatorController appliedAction;
        // PoseDeckBuilder.PresetState of the preset when this deck was made (empty before it was recorded).
        [SerializeField] internal string presetState;
        // See PoseDeckExistingInstallation.deckId.
        [SerializeField] internal string deckId;
    }

    internal static class PoseDeckAvatarInstall
    {
        private const string PrefabName = "GogoLoco All (Modular Avatar).prefab";
        internal const string Marker = "PoseDeckAvatarInstallation.asset";
        private const string InstanceName = "Personal Pose Deck (GoGoLoco)";
        private static readonly Layer[] ReplacedLayers = { Layer.Base, Layer.Action, Layer.Sitting };

        private sealed class Setup
        {
            public GameObject Prefab;
            public AnimatorController Controller;
            public VRCExpressionsMenu Menu;
            public GameObject Installed;
            public PoseDeckAvatarInstallation Marker;
        }

        private static VRCAvatarDescriptor GetAvatar(GameObject go)
        {
            if (!go || !go.scene.IsValid() || !go.scene.isLoaded || EditorUtility.IsPersistent(go) ||
                PrefabStageUtility.GetPrefabStage(go) != null || EditorSceneManager.IsPreviewScene(go.scene) ||
                !go.TryGetComponent<VRCAvatarDescriptor>(out var avatar))
                throw new InvalidOperationException("일반 씬의 Hierarchy에서 VRC Avatar Descriptor가 붙은 아바타 루트를 선택해 주세요.");
            return avatar;
        }

        private static PoseDeckAvatarInstallation GetMarker(VRCExpressionsMenu menu)
        {
            if (!menu) return null;
            string path = AssetDatabase.GetAssetPath(menu);
            const string suffix = "/PoseDeckInstaller.asset";
            if (!path.EndsWith(suffix, StringComparison.Ordinal)) return null;
            var marker = AssetDatabase.LoadAssetAtPath<PoseDeckAvatarInstallation>(
                path.Substring(0, path.Length - suffix.Length + 1) + Marker);
            return marker && marker.menu == menu ? marker : null;
        }

        internal static bool IsAvatarInstallation(GameObject go, PoseDeckBuilder.Target bindings) =>
            GetInstallation(go, bindings.Base.animator, bindings.Menu.menuToAppend);

        private static PoseDeckAvatarInstallation GetInstallation(
            GameObject go, RuntimeAnimatorController controller, VRCExpressionsMenu menu)
        {
            var marker = GetMarker(menu);
            if (!marker || !marker.sourcePrefab || !controller || marker.controller != controller ||
                PrefabUtility.GetCorrespondingObjectFromSource(go) != marker.sourcePrefab)
                return null;
            return marker;
        }

        private static IEnumerable<T> OnAvatar<T>(VRCAvatarDescriptor avatar) where T : Component =>
            avatar.GetComponentsInChildren<T>(true).Where(c => c.GetComponentInParent<VRCAvatarDescriptor>(true) == avatar);

        private static (GameObject go, PoseDeckAvatarInstallation marker) FindInstalled(VRCAvatarDescriptor avatar)
        {
            var installs = OnAvatar<ModularAvatarMenuInstaller>(avatar).Select(menu =>
            {
                var go = menu.gameObject;
                var bases = go.GetComponents<ModularAvatarMergeAnimator>().Where(x => x.layerType == Layer.Base).ToArray();
                return (go, marker: bases.Length == 1 ? GetInstallation(go, bases[0].animator, menu.menuToAppend) : null);
            }).Where(x => x.marker).ToArray();
            if (installs.Length > 1)
                throw new InvalidOperationException("이 아바타에 Pose Deck 설치본이 여러 개 있습니다. Hierarchy에서 중복 설치본을 정리해 주세요.");
            return installs.Length == 1 ? installs[0] : (null, null);
        }

        private static bool IsGoGoName(string value)
        {
            if (string.IsNullOrEmpty(value)) return false;
            var name = value.Replace(" ", "").Replace("-", "").Replace("_", "");
            return name.IndexOf("gogoloco", StringComparison.OrdinalIgnoreCase) >= 0 ||
                   name.IndexOf("golocobase", StringComparison.OrdinalIgnoreCase) >= 0;
        }

        private static bool HasGoGoParameters(IEnumerable<string> names)
        {
            var set = new HashSet<string>(names, StringComparer.Ordinal);
            return set.Contains("Go/Float") && set.Contains("Go/PoseRadial");
        }

        private static bool Ignored(Transform transform, Transform avatarRoot, GameObject installed)
        {
            if (installed && transform.IsChildOf(installed.transform)) return true;
            for (var node = transform; node && node != avatarRoot; node = node.parent)
                if (node.CompareTag("EditorOnly")) return true;
            return false;
        }

        private static void CheckConflicts(VRCAvatarDescriptor avatar, GameObject installed)
        {
            bool Skip(Component c) => Ignored(c.transform, avatar.transform, installed);
            var named = OnAvatar<Transform>(avatar).FirstOrDefault(t => t != avatar.transform && !Skip(t) &&
                (IsGoGoName(t.name) || (PrefabUtility.IsAnyPrefabInstanceRoot(t.gameObject) &&
                    IsGoGoName(Path.GetFileName(PrefabUtility.GetPrefabAssetPathOfNearestInstanceRoot(t.gameObject))))));
            var goGoParams = OnAvatar<ModularAvatarParameters>(avatar).FirstOrDefault(c => !Skip(c) &&
                HasGoGoParameters(c.parameters?.Select(p => p.nameOrPrefix) ?? Enumerable.Empty<string>()));
            if (named || goGoParams)
            {
                var name = named ? named.name : goGoParams.gameObject.name;
                throw new InvalidOperationException($"'{name}'에 기존 GoGoLoco가 있습니다. 개조한 구성을 유지하려면 ‘기존 GoGoLoco에 적용’을 선택해 주세요.");
            }
            if (avatar.customExpressions && avatar.expressionParameters && avatar.expressionParameters.parameters != null &&
                HasGoGoParameters(avatar.expressionParameters.parameters.Where(p => p != null).Select(p => p.name)))
                throw new InvalidOperationException("아바타의 Expression Parameters에 기존 GoGoLoco 파라미터가 있습니다. 중복 설치를 막기 위해 멈췄습니다.");

            var replace = OnAvatar<ModularAvatarMergeAnimator>(avatar).FirstOrDefault(c => !Skip(c) &&
                ReplacedLayers.Contains(c.layerType) && c.mergeAnimatorMode == MergeAnimatorMode.Replace);
            if (replace)
                throw new InvalidOperationException($"'{replace.gameObject.name}'이(가) 이미 {replace.layerType} 레이어를 교체합니다. 충돌을 막기 위해 설치를 멈췄습니다.");

            if (avatar.customizeAnimationLayers)
            {
                var layers = (avatar.baseAnimationLayers ?? Array.Empty<VRCAvatarDescriptor.CustomAnimLayer>())
                    .Concat(avatar.specialAnimationLayers ?? Array.Empty<VRCAvatarDescriptor.CustomAnimLayer>());
                var custom = layers.FirstOrDefault(l => ReplacedLayers.Contains(l.type) && !l.isDefault && l.animatorController);
                if (custom.animatorController)
                    throw new InvalidOperationException($"아바타의 {custom.type}에 '{custom.animatorController.name}'이(가) 지정되어 있습니다. 이 설정을 보호하기 위해 설치를 멈췄습니다.");
            }
        }

        private static Setup ReadStock(GameObject prefab)
        {
            if (!prefab || !prefab.activeSelf || prefab.transform.childCount == 0) return null;
            var layers = prefab.GetComponents<ModularAvatarMergeAnimator>();
            if (ReplacedLayers.Any(layer => layers.Count(c => c.layerType == layer && c.enabled && c.animator &&
                    c.mergeAnimatorMode == MergeAnimatorMode.Replace) != 1)) return null;
            var bases = layers.Where(c => c.layerType == Layer.Base && c.enabled).ToArray();
            var menus = prefab.GetComponents<ModularAvatarMenuInstaller>().Where(c => c.enabled).ToArray();
            if (bases.Length != 1 || !(bases[0].animator is AnimatorController controller) ||
                menus.Length != 1 || !menus[0].menuToAppend ||
                !prefab.GetComponents<ModularAvatarParameters>().Any(c =>
                    HasGoGoParameters(c.parameters?.Select(p => p.nameOrPrefix) ?? Enumerable.Empty<string>())) ||
                !PoseDeckBuilder.SupportsSource(controller, menus[0].menuToAppend)) return null;
            return new Setup { Prefab = prefab, Controller = controller, Menu = menus[0].menuToAppend };
        }

        private static Setup FindStock()
        {
            var known = PoseDeckBuilder.VendorRoots.Select(root => root + "Prefabs/Modular Avatar/" + PrefabName).ToArray();
            Setup TryPath(string path) => ReadStock(AssetDatabase.LoadAssetAtPath<GameObject>(path));
            foreach (var path in known)
                if (TryPath(path) is Setup stock) return stock;
            foreach (var path in AssetDatabase.GetAllAssetPaths().Where(path =>
                (path.StartsWith("Assets/", StringComparison.Ordinal) || path.StartsWith("Packages/", StringComparison.Ordinal)) &&
                path.EndsWith("/" + PrefabName, StringComparison.OrdinalIgnoreCase) && !known.Contains(path))
                .OrderBy(path => path, StringComparer.Ordinal))
                if (TryPath(path) is Setup stock) return stock;
            throw new InvalidOperationException("정상적으로 연결된 GoGoLoco All (Modular Avatar) 프리팹을 찾을 수 없습니다. 먼저 프로젝트에 GoGoLoco를 임포트해 주세요.");
        }

        // The stock GoGoLoco All (Modular Avatar) Base and Action, for the start-height preview. A deck's own Action copy
        // differs only in the slots whose rows set their own start height, which the preview takes from the rows.
        internal static PoseDeckBuilder.PreviewSource FindPreviewSource()
        {
            var stock = FindStock();
            var action = stock.Prefab.GetComponents<ModularAvatarMergeAnimator>()
                .FirstOrDefault(c => c.enabled && c.layerType == Layer.Action)?.animator as AnimatorController;
            return PoseDeckBuilder.PreviewSourceFor(stock.Controller, action);
        }

        private static Setup Resolve(GameObject avatar)
        {
            var descriptor = GetAvatar(avatar);
            var (installed, marker) = FindInstalled(descriptor);
            CheckConflicts(descriptor, installed);
            if (!installed) return FindStock();
            var source = ReadStock(marker.sourcePrefab);
            if (source == null)
                throw new InvalidOperationException("설치할 때 사용한 GoGoLoco 원본 프리팹을 사용할 수 없습니다. 원본을 다시 임포트해 주세요.");
            if (!installed.activeSelf || Ignored(installed.transform, avatar.transform, null))
                throw new InvalidOperationException("기존 Pose Deck 설치본이 비활성 상태입니다. 활성화하거나 ‘적용 제거’ 후 다시 설치해 주세요.");
            source.Installed = installed;
            source.Marker = marker;
            return source;
        }

        // The installed object's Action merge, or the stock prefab's before the first install.
        private static PoseDeckBuilder.Target ActionOwner(Setup source) =>
            PoseDeckBuilder.GetBindings(source.Installed ? source.Installed : source.Prefab);

        internal static string Preview(PoseDeckPreset preset, GameObject avatar)
        {
            var source = Resolve(avatar);
            return PoseDeckBuilder.Preview(preset, source.Controller, source.Menu, PoseDeckBuilder.ActionSource(ActionOwner(source))) +
                   "\n사용 원본: " + AssetDatabase.GetAssetPath(source.Prefab) +
                   string.Concat(Warnings(GetAvatar(avatar), source).Select(warning => "\n⚠ " + warning));
        }

        // The VRCEmote values GoGoLoco's pose buttons send.
        private const int FirstPose = 210, LastPose = 253;

        private static IEnumerable<AnimatorTransitionBase> Transitions(AnimatorStateMachine machine)
        {
            if (!machine) yield break;
            foreach (var transition in machine.anyStateTransitions) yield return transition;
            foreach (var transition in machine.entryTransitions) yield return transition;
            foreach (var child in machine.states)
                if (child.state)
                    foreach (var transition in child.state.transitions) yield return transition;
            foreach (var child in machine.stateMachines)
            {
                if (!child.stateMachine) continue;
                foreach (var transition in machine.GetStateMachineTransitions(child.stateMachine)) yield return transition;
                foreach (var transition in Transitions(child.stateMachine)) yield return transition;
            }
        }

        // The pose values an animator waits for (VRCEmote == N).
        private static IEnumerable<int> PoseValues(RuntimeAnimatorController source)
        {
            var values = new SortedSet<int>();
            if (source is AnimatorController controller)
                foreach (var layer in controller.layers)
                    foreach (var transition in Transitions(layer.stateMachine))
                        foreach (var condition in transition ? transition.conditions : Array.Empty<AnimatorCondition>())
                            if (condition.parameter == "VRCEmote" && condition.mode == AnimatorConditionMode.Equals &&
                                condition.threshold >= FirstPose && condition.threshold <= LastPose)
                                values.Add(Mathf.RoundToInt(condition.threshold));
            return values;
        }

        private static bool SendsPose(VRCExpressionsMenu.Control control) =>
            control?.parameter?.name == "VRCEmote" && control.value >= FirstPose && control.value <= LastPose;

        private static void PoseValues(VRCExpressionsMenu menu, HashSet<VRCExpressionsMenu> seen, SortedSet<int> values)
        {
            if (!menu || !seen.Add(menu) || menu.controls == null) return;
            foreach (var control in menu.controls)
            {
                if (control == null) continue;
                if (SendsPose(control)) values.Add(Mathf.RoundToInt(control.value));
                if (control.type == VRCExpressionsMenu.Control.ControlType.SubMenu) PoseValues(control.subMenu, seen, values);
            }
        }

        // What a first install of GoGoLoco on this avatar would run into, said before applying. CheckConflicts stops the
        // install for another GoGoLoco or a replaced layer; this names what it lets through: synced parameters past
        // VRChat's limit (the upload is refused only after the deck is in), a GoGoLoco parameter the avatar already has
        // with another type, and animators or menu buttons that use the VRCEmote values of GoGoLoco's pose buttons.
        // Bits are counted the way Modular Avatar's own display counts them (NDMF's ParameterInfo); what VRCFury adds or
        // compresses at build is not in them. Empty for an avatar that carries the deck already.
        private static string[] Warnings(VRCAvatarDescriptor avatar, Setup source)
        {
            if (source.Installed) return Array.Empty<string>();
            var warnings = new List<string>();
            try
            {
                var info = nadena.dev.ndmf.ParameterInfo.ForUI;
                bool Named(nadena.dev.ndmf.ProvidedParameter parameter) => parameter.Namespace == nadena.dev.ndmf.ParameterNamespace.Animator;
                var existing = info.GetParametersForObject(avatar.gameObject).Where(Named).ToArray();
                // GoGoLoco goes right under the avatar root, so the root's renames (an MA Parameters there that maps
                // Go/Float onto a parameter the avatar has) apply to it too. Until 0.23.0 its names were taken as they
                // are in the prefab, and a renamed Go/Float was counted as one more parameter.
                var renames = info.GetParameterRemappingsAt(avatar.gameObject);
                string Final(nadena.dev.ndmf.ProvidedParameter parameter) =>
                    renames.TryGetValue((parameter.Namespace, parameter.EffectiveName), out var rename) ? rename.ParameterName : parameter.EffectiveName;
                var added = info.GetParametersForObject(source.Prefab).Where(Named).Select(parameter => (Parameter: parameter, Name: Final(parameter))).ToArray();
                var byName = new Dictionary<string, nadena.dev.ndmf.ProvidedParameter>();
                foreach (var parameter in existing)
                    if (!byName.ContainsKey(parameter.EffectiveName)) byName.Add(parameter.EffectiveName, parameter);
                int used = existing.Sum(parameter => parameter.BitUsage);
                // A synced parameter the avatar already syncs under the same name is shared, not added; so is one name
                // that GoGoLoco uses twice after the renames.
                var fresh = added.Where(x => x.Parameter.BitUsage > 0 && !(byName.TryGetValue(x.Name, out var same) && same.BitUsage > 0))
                    .GroupBy(x => x.Name).Select(g => (Name: g.Key, Bits: g.Max(x => x.Parameter.BitUsage))).ToArray();
                int extra = fresh.Sum(x => x.Bits);
                int limit = VRCExpressionParameters.MAX_PARAMETER_COST;
                if (extra > 0 && used + extra > limit)
                    warnings.Add($"동기화 파라미터가 VRChat 한도를 넘습니다: 지금 {used}비트 + GoGoLoco {extra}비트({string.Join(", ", fresh.Select(x => x.Name))}) = " +
                        $"{used + extra}비트, 한도 {limit}비트. 적용은 되지만 업로드가 막힙니다. 안 쓰는 메뉴나 파라미터를 줄인 뒤 적용하세요. (Modular Avatar 기준 계산이며 VRCFury가 빌드 때 더하거나 압축하는 양은 빠져 있습니다.)");
                var clashing = added.Where(x => byName.TryGetValue(x.Name, out var same) &&
                        same.ParameterType != null && x.Parameter.ParameterType != null && same.ParameterType != x.Parameter.ParameterType)
                    .Select(x => $"{x.Name}(아바타 {byName[x.Name].ParameterType}, GoGoLoco {x.Parameter.ParameterType})").ToArray();
                if (clashing.Length > 0)
                    warnings.Add($"GoGoLoco와 이름이 같고 종류가 다른 파라미터가 아바타에 이미 있습니다: {string.Join(", ", clashing)}. 빌드에서 오류가 나거나 포즈 높이가 맞지 않게 됩니다. 아바타 쪽 파라미터 이름을 바꾸거나 지워 주세요.");
            }
            catch (Exception e)
            {
                warnings.Add("동기화 파라미터 사용량을 계산하지 못했습니다(" + e.Message + "). 적용한 뒤 Modular Avatar의 파라미터 사용량 표시를 확인하세요.");
            }

            var users = new List<string>();
            void Note(string owner, IEnumerable<int> values)
            {
                var list = values.ToArray();
                if (list.Length > 0) users.Add($"{owner}: {string.Join(", ", list.Take(6))}{(list.Length > 6 ? $" 외 {list.Length - 6}개" : "")}");
            }
            if (avatar.customizeAnimationLayers)
                foreach (var layer in (avatar.baseAnimationLayers ?? Array.Empty<VRCAvatarDescriptor.CustomAnimLayer>())
                    .Concat(avatar.specialAnimationLayers ?? Array.Empty<VRCAvatarDescriptor.CustomAnimLayer>()))
                    if (!layer.isDefault && layer.animatorController && !ReplacedLayers.Contains(layer.type))
                        Note($"아바타의 {layer.type} ‘{layer.animatorController.name}’", PoseValues(layer.animatorController));
            bool Skip(Component component) => Ignored(component.transform, avatar.transform, null);
            foreach (var merge in OnAvatar<ModularAvatarMergeAnimator>(avatar))
                if (!Skip(merge) && merge.animator)
                    Note($"‘{merge.gameObject.name}’의 ‘{merge.animator.name}’", PoseValues(merge.animator));
            var buttons = new SortedSet<int>();
            var seen = new HashSet<VRCExpressionsMenu>();
            if (avatar.customExpressions) PoseValues(avatar.expressionsMenu, seen, buttons);
            foreach (var installer in OnAvatar<ModularAvatarMenuInstaller>(avatar))
                if (!Skip(installer)) PoseValues(installer.menuToAppend, seen, buttons);
            foreach (var item in OnAvatar<ModularAvatarMenuItem>(avatar))
                if (!Skip(item) && SendsPose(item.Control)) buttons.Add(Mathf.RoundToInt(item.Control.value));
            Note("메뉴 버튼", buttons);
            if (users.Count > 0)
                warnings.Add($"GoGoLoco 포즈 버튼과 같은 VRCEmote 값({FirstPose}–{LastPose})을 이미 쓰는 것이 아바타에 있습니다. {string.Join(" / ", users)}. " +
                    "포즈 버튼을 누르면 그것도 함께 동작합니다.");
            return warnings.ToArray();
        }

        // Throws, as applying would, when GoGoLoco cannot be installed on the avatar at all.
        internal static string[] InstallWarnings(GameObject avatar) => Warnings(GetAvatar(avatar), Resolve(avatar));

        // The state (PoseDeckBuilder.PresetState) of the preset when this avatar's "아바타에 새로 적용" deck was made.
        // Null without such a deck; "" for one made before the state was recorded.
        internal static string AppliedState(GameObject avatar)
        {
            if (!avatar || !avatar.TryGetComponent<VRCAvatarDescriptor>(out var descriptor)) return null;
            try
            {
                var (installed, marker) = FindInstalled(descriptor);
                return installed ? marker.presetState ?? "" : null;
            }
            catch (InvalidOperationException) { return null; }
        }

        internal static string Apply(PoseDeckPreset preset, GameObject avatar,
            IReadOnlyDictionary<AnimationClip, Texture2D> icons = null)
        {
            var source = Resolve(avatar);
            var owner = ActionOwner(source);
            var stockAction = PoseDeckBuilder.ActionSource(owner);
            string previous = source.Installed ? PoseDeckBuilder.GeneratedFolderOf(owner.Menu.menuToAppend) : null;
            string previousAction = source.Installed && owner.Action ? PoseDeckBuilder.GeneratedFolderOf(owner.Action.animator) : null;
            var (folder, controller, menu, action) = PoseDeckBuilder.GenerateAssets(preset, source.Controller, source.Menu, icons, stockAction);
            Undo.IncrementCurrentGroup();
            int group = Undo.GetCurrentGroup();
            Undo.SetCurrentGroupName("Install Personal Pose Deck on Avatar");
            try
            {
                var marker = ScriptableObject.CreateInstance<PoseDeckAvatarInstallation>();
                marker.sourcePrefab = source.Prefab;
                marker.controller = controller;
                marker.menu = menu;
                marker.preset = preset;
                marker.stockAction = action ? stockAction : null;
                marker.appliedAction = action;
                marker.presetState = PoseDeckBuilder.PresetState(preset);
                marker.deckId = Guid.NewGuid().ToString("N");
                AssetDatabase.CreateAsset(marker, folder + "/" + Marker);

                var instance = source.Installed;
                if (!instance)
                {
                    instance = PrefabUtility.InstantiatePrefab(source.Prefab, avatar.transform) as GameObject;
                    if (!instance) throw new InvalidOperationException("아바타 아래에 GoGoLoco 프리팹을 배치하지 못했습니다.");
                    instance.name = GameObjectUtility.GetUniqueNameForSibling(avatar.transform, InstanceName);
                    Undo.RegisterCreatedObjectUndo(instance, "Add Personal Pose Deck");
                    PrefabUtility.RecordPrefabInstancePropertyModifications(instance);
                }
                var target = PoseDeckBuilder.GetTarget(instance);
                PoseDeckBuilder.Wire(target, controller, menu, action ? action : stockAction);
                if (source.Marker)
                    PoseDeckBuilder.RelinkActionCopy(instance, source.Marker.appliedAction, source.Marker.stockAction, target.Action);
                PoseDeckBuilder.SaveGenerated(folder, preset);
                Undo.CollapseUndoOperations(group);
                PoseDeckGeneratedCleanup.Remember(previous);
                PoseDeckGeneratedCleanup.Remember(previousAction);
                return folder;
            }
            catch
            {
                Undo.RevertAllDownToGroup(group);
                AssetDatabase.DeleteAsset(folder);
                throw;
            }
        }

        // The installation added by "아바타에 새로 적용" and the preset it was generated from (null when unknown).
        internal static (GameObject installed, PoseDeckPreset preset) FindApplied(GameObject avatar)
        {
            if (!avatar || !avatar.TryGetComponent<VRCAvatarDescriptor>(out var descriptor)) return (null, null);
            try
            {
                var (installed, marker) = FindInstalled(descriptor);
                if (!installed) return (null, null);
                if (marker.preset) return (installed, marker.preset);
                // Generated folders are created next to their preset; use it when that folder holds exactly one.
                var folder = Path.GetDirectoryName(Path.GetDirectoryName(AssetDatabase.GetAssetPath(marker)))?.Replace('\\', '/');
                var nearby = string.IsNullOrEmpty(folder) ? Array.Empty<string>() :
                    AssetDatabase.FindAssets("t:PoseDeckPreset", new[] { folder })
                        .Select(AssetDatabase.GUIDToAssetPath)
                        .Where(p => Path.GetDirectoryName(p)?.Replace('\\', '/') == folder).ToArray();
                return (installed, nearby.Length == 1 ? AssetDatabase.LoadAssetAtPath<PoseDeckPreset>(nearby[0]) : null);
            }
            catch (InvalidOperationException) { return (null, null); }
        }

        internal static void Remove(GameObject avatar)
        {
            var descriptor = GetAvatar(avatar);
            var (installed, _) = FindInstalled(descriptor);
            if (!installed)
                throw new InvalidOperationException("이 아바타에 ‘아바타에 새로 적용’으로 설치한 Pose Deck이 없습니다.");
            Undo.DestroyObjectImmediate(installed);
            EditorSceneManager.MarkSceneDirty(avatar.scene);
        }
    }
}
