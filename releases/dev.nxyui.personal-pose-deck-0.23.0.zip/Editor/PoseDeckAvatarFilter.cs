using System;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using UnityEditor;
using UnityEngine;

namespace PersonalPoseDeck
{
    internal sealed partial class PoseDeckPoseBrowser
    {
        private sealed class AvatarAlias
        {
            public readonly string Name;
            public readonly Regex Pattern;
            public AvatarAlias(string name, string roman, string japanese)
            {
                Name = name;
                Pattern = new Regex("(?<![a-z0-9])(?:" + roman + ")(?![a-z0-9])|(?:" + japanese + ")",
                    RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);
            }
        }

        // The kana normalizer treats hiragana and katakana spellings as the same alias.
        private static readonly AvatarAlias[] AvatarAliases =
        {
            new AvatarAlias("Rurune", "rurune|lulune", "ルルネ"),
            new AvatarAlias("Milfy", "milfy|milfie|milfee", "ミルフィ(?:ー)?"),
            new AvatarAlias("Manuka", "manuka", "マヌカ"),
            new AvatarAlias("Shinano", "shinano|sinano", "シナノ|信濃"),
            new AvatarAlias("Selestia", "selestia|celestia", "セレスティア"),
            new AvatarAlias("Shinra", "shinra|sinra", "シンラ|森羅"),
            new AvatarAlias("Kikyo", "kikyo|kikyou", "キキョウ|桔梗"),
            new AvatarAlias("Moe", "moe", "モエ|(?<![\\p{L}])萌(?![\\p{L}])"),
            new AvatarAlias("Maya", "maya", "マヤ|舞夜"),
            new AvatarAlias("Airi", "airi|aily", "アイリ|愛莉"),
            new AvatarAlias("Minase", "minase", "ミナセ|水瀬"),
            new AvatarAlias("Mafuyu", "mafuyu", "マフユ|真冬"),
            new AvatarAlias("Chiffon", "chiffon|shifon", "シフォン"),
            new AvatarAlias("Chocolat", "chocolat|shokora", "ショコラ"),
            new AvatarAlias("Lime", "lime|raimu", "ライム"),
            new AvatarAlias("Kipfel", "kipfel|kipferu", "キプフェル"),
            new AvatarAlias("Milltina", "milltina|miltina|mirutina", "ミルティナ"),
            new AvatarAlias("Lasyusha", "lasyusha|lasyusya|rashusha", "ラシューシャ"),
            new AvatarAlias("Lapwing", "lapwing|rappuingu", "ラップウィング"),
            new AvatarAlias("Mamehinata", "mamehinata", "マメヒナタ|豆雛太"),
            new AvatarAlias("Usasaki", "usasaki", "ウササキ"),
            new AvatarAlias("Mizuki", "mizuki|miduki", "ミズキ|瑞希"),
            new AvatarAlias("Karin", "karin", "カリン"),
            new AvatarAlias("Komano", "komano", "コマノ|狛乃"),
            new AvatarAlias("Sio", "sio|shio", "シオ"),
            new AvatarAlias("Rusk", "rusk|rasuku", "ラスク"),
            new AvatarAlias("Lillie", "lillie|lily", "リリィ|リリー")
        };
        private static readonly string[] AvatarFilterOptions = { "아바타: 전체", "선택 아바타 + 공용", "선택 아바타 전용", "공용만" };
        private static readonly string[] AvatarProfileOptions = new[] { "현재 아바타 자동 감지" }.Concat(AvatarAliases.Select(a => a.Name)).ToArray();
        private static readonly Regex CamelBoundary = new Regex("(?<=[a-z0-9])(?=[A-Z][a-z])", RegexOptions.CultureInvariant);
        [SerializeField] private int avatarFilterMode, avatarProfile;
        [SerializeField] private bool usePoseRegex;
        [SerializeField] private string poseRegexText = "";
        private GameObject lastTaggedAvatar;
        private ulong autoAvatarMask;
        private Regex poseRegex;
        private string compiledPoseRegexText, poseRegexError;
        // The error line as this GUI pass draws it, decided when the pass is laid out.
        private string shownPoseRegexError;

        internal static ulong DetectAvatarAliases(string input)
        {
            if (string.IsNullOrEmpty(input)) return 0;
            string normalized = CamelBoundary.Replace(input.Normalize(NormalizationForm.FormKC), " ");
            var chars = normalized.ToCharArray();
            for (int i = 0; i < chars.Length; i++)
                if (chars[i] >= '\u3041' && chars[i] <= '\u3096') chars[i] = (char)(chars[i] + 0x60);
            string key = new string(chars);
            ulong mask = 0;
            for (int i = 0; i < AvatarAliases.Length; i++) if (AvatarAliases[i].Pattern.IsMatch(key)) mask |= 1UL << i;
            return mask;
        }

        private ulong SelectedAvatarMask()
        {
            if (avatarProfile > 0 && avatarProfile <= AvatarAliases.Length) return 1UL << (avatarProfile - 1);
            if (lastTaggedAvatar != avatar)
            {
                lastTaggedAvatar = avatar;
                var animator = avatar ? avatar.GetComponent<Animator>() : null;
                var rig = animator ? animator.avatar : null;
                autoAvatarMask = avatar ? DetectAvatarAliases(avatar.name + " " + (rig ? rig.name + " " + AssetDatabase.GetAssetPath(rig) : "")) : 0;
            }
            return autoAvatarMask;
        }

        // One row: avatar filter (and which avatar), then the regex toggle and its pattern.
        private void DrawAvatarFilters()
        {
            // The pattern is compiled before the row is laid out. Filter runs after this row, and an error first found
            // there in a Layout event (a bad pattern kept across a script reload, or a search that timed out) added its
            // line only at Repaint: one control more than was laid out.
            if (Event.current.type == EventType.Layout)
            {
                PreparePoseRegex();
                shownPoseRegexError = usePoseRegex ? poseRegexError : null;
            }
            EditorGUI.BeginChangeCheck();
            using (new EditorGUILayout.HorizontalScope())
            {
                avatarFilterMode = EditorGUILayout.Popup(avatarFilterMode, AvatarFilterOptions, GUILayout.MinWidth(70));
                if (avatarFilterMode == 1 || avatarFilterMode == 2)
                    avatarProfile = EditorGUILayout.Popup(avatarProfile, AvatarProfileOptions, GUILayout.MinWidth(60));
                usePoseRegex = GUILayout.Toggle(usePoseRegex, new GUIContent("정규식", "클립 이름이나 경로를 정규식으로 거릅니다. 예: (Rurune|るるね|ルルネ)"),
                    EditorStyles.miniButton, GUILayout.Width(48));
                if (usePoseRegex) poseRegexText = EditorGUILayout.TextField(poseRegexText ?? "", GUILayout.MinWidth(60));
            }
            if (EditorGUI.EndChangeCheck()) { refreshFilter = true; galleryScroll = Vector2.zero; }
            if ((avatarFilterMode == 1 || avatarFilterMode == 2) && SelectedAvatarMask() == 0)
                EditorGUILayout.LabelField("아바타 이름을 감지하지 못했어요. 오른쪽 목록에서 선택하세요.", EditorStyles.miniLabel);
            if (shownPoseRegexError != null) EditorGUILayout.LabelField("⚠ " + shownPoseRegexError, EditorStyles.miniLabel);
        }

        private void PreparePoseRegex()
        {
            if (!usePoseRegex || compiledPoseRegexText == (poseRegexText ?? "")) return;
            compiledPoseRegexText = poseRegexText ?? "";
            poseRegex = null;
            poseRegexError = null;
            if (string.IsNullOrWhiteSpace(compiledPoseRegexText)) return;
            try { poseRegex = new Regex(compiledPoseRegexText, RegexOptions.IgnoreCase | RegexOptions.CultureInvariant, TimeSpan.FromMilliseconds(30)); }
            catch (ArgumentException) { poseRegexError = "정규식 문법을 확인하세요."; }
        }

        private bool MatchesPoseRegex(Item item)
        {
            if (!usePoseRegex || poseRegex == null) return true;
            return poseRegex.IsMatch(item.Name) || poseRegex.IsMatch(item.Path);
        }

        private bool MatchesAvatarMode(Item item, ulong targetMask)
        {
            if (avatarFilterMode == 3) return item.AvatarMask == 0;
            if (targetMask == 0) return true; // Never hide unnamed custom avatar rigs silently.
            if (avatarFilterMode == 1) return item.AvatarMask == 0 || (item.AvatarMask & targetMask) != 0;
            if (avatarFilterMode == 2) return (item.AvatarMask & targetMask) != 0;
            return true;
        }
    }
}
