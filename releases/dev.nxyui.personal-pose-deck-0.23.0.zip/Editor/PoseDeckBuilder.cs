using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using nadena.dev.modular_avatar.core;
using UnityEditor;
using UnityEditor.Animations;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using VRC.SDK3.Avatars.Components;
using VRC.SDK3.Avatars.ScriptableObjects;
using Object = UnityEngine.Object;
using Control = VRC.SDK3.Avatars.ScriptableObjects.VRCExpressionsMenu.Control;

namespace PersonalPoseDeck
{
    internal static class PoseDeckBuilder
    {
        internal static readonly string[] CategoryNames = { "앉기", "눕기", "서기", "기타" };
        private static readonly string[] SlotStates = { "Left", "Right", "Left Init", "Right Init" };
        private const string Emote = "VRCEmote";
        private const string Float = "Go/Float";
        private const string PoseMachine = "VRCEmote 210 -253";
        private const string GeneratedBaseName = "PoseDeckBase.controller";
        private const string GeneratedMenuName = "PoseDeckInstaller.asset";
        // The copy of the GoGoLoco object's Action that carries the deck's start heights (see PatchAction).
        private const string GeneratedActionName = "PoseDeckAction.controller";
        private const string FloatDriver = "Float Driver";
        private const string ExistingInstallationName = "PoseDeckExistingInstallation.asset";
        private const string GeneratedFolderPrefix = "PoseDeck_Generated";
        // GoGoLoco's Action layer sets Go/Float when a pose button is pressed (0.25 on custom slots). Pressing ▲/▼ during a
        // pose sets Go/PosePlaySpace, after which GoGoLoco stops applying start heights; the deck follows the same rule.
        internal const float DefaultStartHeight = 0.25f;
        private const string PlaySpace = "Go/PosePlaySpace";
        private const string HeightStateSuffix = " Height";
        // GoGoLoco's Init states enter VRChat's pose space this long after a pose starts: in VR the view (and the hips,
        // which follow the headset) are placed from where the animated head is at that moment.
        internal const float PoseSpaceDelay = .26f;
        // GoGoLoco 1.8.6 sets its own poses higher than the start height at which each one touches the floor. Measured in
        // the preview over its 31 stock poses (GoBone, VR 3-point, 2026-11-16): sitting and floor poses by a median 10.3 %
        // of that height, lying ones by about 1 %; 1.1 times the touching height lands on 24 of the 27 still poses' presets
        // within 0.007 (the rest are chair and motion poses). Those presets were tuned in game, and decks fitted to the exact
        // floor sat lower in VR than GoGoLoco's own poses, so "바닥에 맞추기" can add the same share.
        internal const float GoGoLocoFitMargin = .1f;

        // The start height GoGoLoco would give a pose that touches the floor at `touching`. Above 0.25 GoGoLoco scales
        // heights differently and none of its own poses sit there, so the margin stops growing at 0.25.
        internal static float LikeGoGoLoco(float touching) =>
            Mathf.Clamp01(touching + GoGoLocoFitMargin * Mathf.Clamp(touching, 0f, DefaultStartHeight));
        // Medians of GoGoLoco 1.8.6's own presets per pose menu (Sit, Floor, Prone/Laydown) and its custom-slot value.
        internal static readonly (string Label, float Value)[] HeightPresets =
            { ("서기", .25f), ("의자", .19f), ("바닥", .12f), ("눕기", .06f) };
        // The slot layout, clip names and parameters below match this GoGoLoco release only.
        internal const string SupportedVendorVersion = "1.8.6";
        internal static readonly string[] VendorRoots = { "Assets/GoGo/GoLoco/", "Packages/gogoloco/Runtime/GoGo/GoLoco/" };
        private static readonly string[] VendorPoseMenus =
        {
            "GoMenuPoseFloor", "GoMenuPoseProne", "GoMenuPoseSit",
            "SubMenuPoses/GoMenuPoseFloor+", "SubMenuPoses/GoMenuPoseLaydown+", "SubMenuPoses/GoMenuPoseSit+"
        };

        internal sealed class Target
        {
            public ModularAvatarMergeAnimator Base;
            public ModularAvatarMenuInstaller Menu;
            // The object's one enabled Action merge, or null (start heights then stay in the Base).
            public ModularAvatarMergeAnimator Action;
        }

        private sealed class Slot
        {
            public int Number;
            public AnimatorStateMachine Machine;
            public AnimatorState[] States;
            public BlendTree Tree;
            public bool Blank;
            public AnimationClip[] Clips;
        }

        private sealed class Assignment
        {
            public int Number;
            public Control NativeControl;
            // A custom pose in one of GoGoLoco's own button slots (the empty slots ran out).
            public bool Borrowed;
        }

        private sealed class Plan
        {
            public Assignment[] Rows;
            public int NativeCount;
            public int CustomCapacity;
            public int BlankCapacity;
        }

        internal static Target GetTarget(GameObject go)
        {
            if (!go || !go.scene.IsValid() || EditorUtility.IsPersistent(go) ||
                !go.GetComponentInParent<VRCAvatarDescriptor>(true))
                throw new InvalidOperationException("Hierarchy에서 아바타 아래의 GoGoLoco MA 오브젝트를 선택해 주세요.");
            return GetBindings(go);
        }

        // The prefab file open in Prefab Mode that holds `go`, or null for an object in an ordinary scene. Applying
        // there changes the prefab itself, and with it every scene that uses the prefab.
        internal static string PrefabStagePath(GameObject go)
        {
            var stage = go ? PrefabStageUtility.GetPrefabStage(go) : null;
            return stage != null ? stage.assetPath : null;
        }

        internal static Target GetBindings(GameObject go)
        {
            var bases = go.GetComponents<ModularAvatarMergeAnimator>()
                .Where(x => x.enabled && x.layerType == VRCAvatarDescriptor.AnimLayerType.Base).ToArray();
            var installers = go.GetComponents<ModularAvatarMenuInstaller>().Where(x => x.enabled).ToArray();
            if (bases.Length != 1 || installers.Length != 1)
                throw new InvalidOperationException("활성 MA Merge Animator (Base)와 MA Menu Installer가 하나씩 붙은 GoGoLoco 오브젝트를 선택해 주세요.");
            var actions = go.GetComponents<ModularAvatarMergeAnimator>()
                .Where(x => x.enabled && x.layerType == VRCAvatarDescriptor.AnimLayerType.Action).ToArray();
            return new Target { Base = bases[0], Menu = installers[0], Action = actions.Length == 1 ? actions[0] : null };
        }

        // The Action a deck is made from on this GoGoLoco object: the controller its Action merge links (GoGoLoco's own,
        // or one another package modified, e.g. NEKO AFK Cushion's), or, when that is a deck's copy, the Action the copy
        // was made from, recorded next to it. Null when the object has no single enabled Action merge.
        internal static AnimatorController ActionSource(Target target)
        {
            var current = target.Action ? target.Action.animator as AnimatorController : null;
            if (!current || Path.GetFileName(AssetDatabase.GetAssetPath(current)) != GeneratedActionName) return current;
            var (applied, original) = RecordedAction(FolderOf(current));
            if (applied != current || !original || Path.GetFileName(AssetDatabase.GetAssetPath(original)) == GeneratedActionName)
                throw new InvalidOperationException($"‘{target.Action.gameObject.name}’의 MA Merge Animator (Action)에 연결된 Pose Deck 복사본이 어느 Action에서 만들어졌는지 찾지 못했습니다. 원래 쓰던 Action 컨트롤러를 그 칸에 다시 연결한 뒤 시도해 주세요.");
            return original;
        }

        // The asset's folder with a trailing slash, or "" for none.
        private static string FolderOf(Object asset)
        {
            string path = asset ? AssetDatabase.GetAssetPath(asset) : "";
            return path.Substring(0, path.LastIndexOf('/') + 1);
        }

        // What the installation recorded in a generated folder ("기존 GoGoLoco에 적용" or "아바타에 새로 적용") says about
        // the Action: the copy it linked and the Action that copy was made from. Nulls for none, and before 0.22.0.
        private static (AnimatorController Applied, AnimatorController Stock) RecordedAction(string folder)
        {
            if (string.IsNullOrEmpty(folder)) return (null, null);
            var existing = AssetDatabase.LoadAssetAtPath<PoseDeckExistingInstallation>(folder + ExistingInstallationName);
            if (existing) return (existing.appliedAction, existing.stockAction);
            var avatar = AssetDatabase.LoadAssetAtPath<PoseDeckAvatarInstallation>(folder + PoseDeckAvatarInstall.Marker);
            return avatar ? (avatar.appliedAction, avatar.stockAction) : (null, null);
        }

        // Links one Action merge to a controller, with undo.
        private static void LinkAction(ModularAvatarMergeAnimator merge, AnimatorController action)
        {
            if (merge.animator == action) return;
            Undo.RecordObject(merge, "Change Personal Pose Deck");
            merge.animator = action;
            PrefabUtility.RecordPrefabInstancePropertyModifications(merge);
            EditorUtility.SetDirty(merge);
        }

        // Links the Action merges on `go` that hold an installation's copy (`applied`) back to the Action it was made from,
        // enabled or not, except `keep`. Action links made since by hand or by another tool are left alone.
        internal static void RelinkActionCopy(GameObject go, AnimatorController applied, AnimatorController stock,
            ModularAvatarMergeAnimator keep = null)
        {
            if (!go || !applied || !stock) return;
            foreach (var merge in go.GetComponents<ModularAvatarMergeAnimator>())
                if (merge != keep && merge.layerType == VRCAvatarDescriptor.AnimLayerType.Action && merge.animator == applied)
                    LinkAction(merge, stock);
        }

        private static bool IsGenerated(AnimatorController controller, VRCExpressionsMenu menu) =>
            (controller && Path.GetFileName(AssetDatabase.GetAssetPath(controller)) == GeneratedBaseName) ||
            (menu && Path.GetFileName(AssetDatabase.GetAssetPath(menu)) == GeneratedMenuName);

        private static (AnimatorController controller, VRCExpressionsMenu menu, PoseDeckPreset installedPreset, bool legacy)
            Sources(PoseDeckPreset preset, Target target)
        {
            var currentBase = target.Base.animator as AnimatorController;
            var currentMenu = target.Menu.menuToAppend;
            if (!currentBase || !currentMenu)
                throw new InvalidOperationException("GoGoLoco Base 컨트롤러와 설치 메뉴가 모두 연결되어 있어야 합니다.");

            var menuPath = AssetDatabase.GetAssetPath(currentMenu);
            if (Path.GetFileName(menuPath) == GeneratedMenuName)
            {
                var marker = AssetDatabase.LoadAssetAtPath<PoseDeckExistingInstallation>(
                    menuPath.Substring(0, menuPath.LastIndexOf('/') + 1) + ExistingInstallationName);
                if (marker)
                {
                    if (marker.appliedBase != currentBase || marker.appliedMenu != currentMenu ||
                        !marker.stockBase || !marker.stockMenu || IsGenerated(marker.stockBase, marker.stockMenu))
                        throw new InvalidOperationException("현재 생성본의 Base·메뉴 연결 또는 GoGoLoco 원본 참조를 확인할 수 없습니다.");
                    return (marker.stockBase, marker.stockMenu, marker.preset, false);
                }
            }
            if (!IsGenerated(currentBase, currentMenu)) return (currentBase, currentMenu, null, false);

            bool MatchesLegacy(PoseDeckPreset p) => p && p.appliedBase == currentBase && p.appliedMenu == currentMenu &&
                p.stockBase && p.stockMenu && !IsGenerated(p.stockBase, p.stockMenu);
            var matches = AssetDatabase.FindAssets("t:PoseDeckPreset", new[] { "Assets" })
                .Select(guid => AssetDatabase.LoadAssetAtPath<PoseDeckPreset>(AssetDatabase.GUIDToAssetPath(guid)))
                .Prepend(preset).Where(MatchesLegacy).Distinct().ToArray();
            if (matches.Length == 0)
                throw new InvalidOperationException("예전 생성본의 원래 Base·메뉴를 찾지 못했습니다. 그 생성본을 만든 프리셋과 GoGoLoco 원본 파일이 프로젝트에 있는지 확인해 주세요.");
            var previous = matches[0];
            if (matches.Any(p => p.stockBase != previous.stockBase || p.stockMenu != previous.stockMenu))
                throw new InvalidOperationException("같은 예전 생성본에 서로 다른 GoGoLoco 원본이 기록되어 있어 연결을 바꾸지 않았습니다.");
            return (previous.stockBase, previous.stockMenu, previous, true);
        }

        private static IEnumerable<Control> Controls(VRCExpressionsMenu menu, HashSet<VRCExpressionsMenu> seen)
        {
            if (!menu || !seen.Add(menu) || menu.controls == null) yield break;
            foreach (var c in menu.controls)
            {
                if (c == null) continue;
                yield return c;
                if (c.type == Control.ControlType.SubMenu)
                    foreach (var child in Controls(c.subMenu, seen)) yield return child;
            }
        }

        private static IEnumerable<AnimatorStateMachine> Machines(AnimatorStateMachine machine)
        {
            yield return machine;
            foreach (var child in machine.stateMachines)
                foreach (var nested in Machines(child.stateMachine)) yield return nested;
        }

        private static IEnumerable<BlendTree> PoseBranches(BlendTree tree)
        {
            if (tree.blendParameter == "VRModeProxy" && tree.children.Length == 2 &&
                tree.children.All(c => c.motion is AnimationClip))
            {
                yield return tree;
                yield break;
            }
            foreach (var child in tree.children)
                if (child.motion is BlendTree nested)
                    foreach (var branch in PoseBranches(nested)) yield return branch;
        }

        // Names the installed GoGoLoco package version when it differs from the supported one. Empty for Assets installs.
        internal static string VendorVersionNote(string assetPath)
        {
            var package = string.IsNullOrEmpty(assetPath) ? null : UnityEditor.PackageManager.PackageInfo.FindForAssetPath(assetPath);
            if (package == null || package.version == SupportedVendorVersion) return "";
            return $" 설치된 {(string.IsNullOrEmpty(package.displayName) ? package.name : package.displayName)} {package.version}은(는) 지원 버전 {SupportedVendorVersion}과 다릅니다.";
        }

        private static List<Slot> FindSlots(AnimatorController controller)
        {
            var machine = controller.layers.SelectMany(l => Machines(l.stateMachine))
                .SingleOrDefault(m => m.name == PoseMachine);
            if (!machine) throw new InvalidOperationException($"GoGoLoco {SupportedVendorVersion} 포즈 구조를 찾지 못했습니다. 지원되는 All (Modular Avatar) 프리팹과 Base를 확인해 주세요." +
                VendorVersionNote(AssetDatabase.GetAssetPath(controller)));
            var slots = new List<Slot>();
            foreach (var child in machine.stateMachines)
            {
                if (!int.TryParse(child.stateMachine.name, out int n) || n < 210 || n > 253) continue;
                var states = child.stateMachine.states.Select(s => s.state).Where(s => SlotStates.Contains(s.name)).ToArray();
                if (states.Length != SlotStates.Length || states.Select(s => s.name).Distinct().Count() != SlotStates.Length ||
                    !(states[0].motion is BlendTree tree) || tree.name != "go_" + n || states.Any(s => s.motion != tree)) continue;
                var branches = PoseBranches(tree).ToArray();
                if (branches.Length != 1) continue;
                var clips = branches[0].children.Select(c => (AnimationClip)c.motion).Distinct().ToArray();
                bool blank = clips.All(c => c.name == "go_pose_desktop" || c.name == "go_pose_vr");
                slots.Add(new Slot { Number = n, Machine = child.stateMachine, States = states, Tree = tree, Blank = blank, Clips = clips });
            }
            return slots.OrderByDescending(s => s.Blank).ThenBy(s => s.Number).ToList();
        }

        // What the start-height preview needs from a stock GoGoLoco: its Base, an empty slot to borrow, the stock clips
        // with their slots, and the start height GoGoLoco's Action layer gives each slot (read only).
        internal sealed class PreviewSource
        {
            public AnimatorController Base;
            public int BlankSlot;
            public AnimationClip[] BlankClips;
            public Dictionary<AnimationClip, int> NativeSlots;
            public Dictionary<int, float> StartHeights;
            // GoGoLoco's additive reference pose (go_additive_reference_pose); see NeedsReference.
            public AnimationClip Reference;
            private readonly Dictionary<AnimationClip, int> copies = new Dictionary<AnimationClip, int>();

            // The stock slot a clip plays in game, like PlanRows: the stock clip itself or an unedited copy of it
            // from the other GoGoLoco install location. -1 for a custom clip.
            internal int SlotFor(AnimationClip clip)
            {
                if (!clip) return -1;
                if (NativeSlots.TryGetValue(clip, out int slot) || copies.TryGetValue(clip, out slot)) return slot;
                string path = AssetDatabase.GetAssetPath(clip);
                slot = NativeSlots.Where(n => IsSameVendorClip(path, AssetDatabase.GetAssetPath(n.Key)))
                    .Select(n => n.Value).DefaultIfEmpty(-1).First();
                copies[clip] = slot;
                return slot;
            }

            internal float StartHeightFor(AnimationClip clip) =>
                SlotFor(clip) is int slot && slot >= 0 && StartHeights.TryGetValue(slot, out float value) ? value : DefaultStartHeight;
        }

        internal static PreviewSource PreviewSourceFor(AnimatorController stock, AnimatorController action)
        {
            var slots = FindSlots(stock);
            var blank = slots.FirstOrDefault(s => s.Blank) ?? throw new InvalidOperationException("GoGoLoco에서 빈 포즈 슬롯을 찾지 못했습니다.");
            var native = new Dictionary<AnimationClip, int>();
            foreach (var slot in slots.Where(s => !s.Blank))
                foreach (var clip in slot.Clips)
                    if (clip && !native.ContainsKey(clip)) native.Add(clip, slot.Number);
            var heights = FloatDriverSlots(action).ToDictionary(x => x.Key, x => x.Value.Set.value);
            return new PreviewSource
            {
                Base = stock, BlankSlot = blank.Number, BlankClips = blank.Clips, NativeSlots = native, StartHeights = heights,
                Reference = AdditiveReference(slots.SelectMany(s => s.Clips)),
            };
        }

        // GoGoLoco's Action layer gives a pose its start height when the button is pressed: its "Float Driver" machine is
        // entered for pose values (GoGoLoco 1.8.6 leaves out 214 there; its Base has no slot 214), state N inside when
        // VRCEmote == N, both skipped after ▲/▼ (Go/PosePlaySpace), and state N sets Go/Float once. The slots found that
        // way, with the driver and its one parameter that sets Go/Float; the driver must belong to this controller and to
        // that state alone, so writing it changes nothing else. Slots not found here keep the Base's height step.
        private static Dictionary<int, (VRCAvatarParameterDriver Driver, VRC.SDKBase.VRC_AvatarParameterDriver.Parameter Set)>
            FloatDriverSlots(AnimatorController action)
        {
            var found = new Dictionary<int, (VRCAvatarParameterDriver, VRC.SDKBase.VRC_AvatarParameterDriver.Parameter)>();
            var all = action ? action.layers.SelectMany(l => Machines(l.stateMachine)).ToArray() : Array.Empty<AnimatorStateMachine>();
            var machines = all.Where(m => m.name == FloatDriver).ToArray();
            if (machines.Length != 1) return found;
            var machine = machines[0];
            bool root = action.layers.Any(l => l.stateMachine == machine);
            var into = all.SelectMany(m => m.entryTransitions.Cast<AnimatorTransitionBase>().Concat(m.anyStateTransitions)
                    .Concat(m.states.SelectMany(c => c.state.transitions))
                    .Concat(m.stateMachines.SelectMany(c => m.GetStateMachineTransitions(c.stateMachine))))
                .Where(t => t && t.destinationStateMachine == machine).ToArray();
            var uses = all.SelectMany(m => m.states).SelectMany(c => c.state.behaviours).GroupBy(b => b).ToDictionary(g => g.Key, g => g.Count());
            string path = AssetDatabase.GetAssetPath(action);
            bool Guarded(AnimatorTransitionBase t) => t.conditions.Any(c => c.parameter == PlaySpace && c.mode == AnimatorConditionMode.IfNot);
            foreach (var named in machine.states.Select(c => c.state).GroupBy(s => s.name))
            {
                if (named.Count() != 1 || !int.TryParse(named.Key, out int n) || n < 210 || n > 253) continue;
                var state = named.Single();
                var sets = state.behaviours.OfType<VRCAvatarParameterDriver>().SelectMany(d =>
                    (d.parameters ?? new List<VRC.SDKBase.VRC_AvatarParameterDriver.Parameter>())
                    .Where(p => p != null && p.name == Float).Select(p => (Driver: d, Set: p))).ToArray();
                if (sets.Length != 1 || sets[0].Set.type != VRC.SDKBase.VRC_AvatarParameterDriver.ChangeType.Set ||
                    AssetDatabase.GetAssetPath(sets[0].Driver) != path || uses[sets[0].Driver] != 1) continue;
                var inside = machine.entryTransitions.Where(t => t.destinationState == state && Admits(t, n) && t.conditions.Any(c =>
                    c.parameter == Emote && c.mode == AnimatorConditionMode.Equals && Mathf.Approximately(c.threshold, n))).ToArray();
                var outside = into.Where(t => Admits(t, n)).ToArray();
                if (inside.Length == 0 || (!root && outside.Length == 0)) continue;
                // Every way in must skip after ▲/▼, inside or on the way to the machine.
                if (inside.Any(t => !Guarded(t)) && (root || outside.Any(t => !Guarded(t)))) continue;
                found[n] = sets[0];
            }
            return found;
        }

        // Whether an unmuted transition's VRCEmote conditions let VRCEmote == n through.
        private static bool Admits(AnimatorTransitionBase transition, int n) =>
            !transition.mute && transition.conditions.Where(c => c.parameter == Emote).All(c =>
                c.mode == AnimatorConditionMode.Equals ? Mathf.Approximately(c.threshold, n)
                : c.mode == AnimatorConditionMode.NotEqual ? !Mathf.Approximately(c.threshold, n)
                : c.mode == AnimatorConditionMode.Greater ? n > c.threshold
                : c.mode == AnimatorConditionMode.Less && n < c.threshold);

        // GoGoLoco's "Poses" layer is additive over its locomotion, and its pose clips are measured against
        // go_additive_reference_pose (their additive reference pose). A clip with no reference is measured against its
        // own first frame, which turns a still pose into no change at all, and a clip made for another system (e.g. an
        // avatar's own pose menu) carries that system's reference. Such clips play as copies that carry GoGoLoco's.
        internal static AnimationClip AdditiveReference(IEnumerable<AnimationClip> stockClips) =>
            stockClips.Where(c => c).Select(AnimationUtility.GetAnimationClipSettings)
                .Where(s => s.hasAdditiveReferencePose && s.additiveReferencePoseClip)
                .GroupBy(s => s.additiveReferencePoseClip).OrderByDescending(g => g.Count()).Select(g => g.Key).FirstOrDefault();

        internal static bool NeedsReference(AnimationClip clip, AnimationClip reference)
        {
            if (!clip || !reference || !clip.humanMotion || clip == reference) return false;
            var settings = AnimationUtility.GetAnimationClipSettings(clip);
            return !settings.hasAdditiveReferencePose || settings.additiveReferencePoseClip != reference ||
                   !Mathf.Approximately(settings.additiveReferencePoseTime, 0f);
        }

        // An unsaved copy of the clip that uses GoGoLoco's reference pose; the clip itself is left alone.
        internal static AnimationClip WithReference(AnimationClip clip, AnimationClip reference)
        {
            var copy = Object.Instantiate(clip);
            copy.name = clip.name;
            var settings = AnimationUtility.GetAnimationClipSettings(copy);
            settings.hasAdditiveReferencePose = true;
            settings.additiveReferencePoseClip = reference;
            settings.additiveReferencePoseTime = 0f;
            AnimationUtility.SetAnimationClipSettings(copy, settings);
            return copy;
        }

        // Holds every curve's value at 0 for one frame (1/60 s), like GoGoLoco's own pose clips.
        private static void OneFrame(AnimationClip clip)
        {
            var bindings = AnimationUtility.GetCurveBindings(clip);
            var curves = bindings.Select(b => AnimationCurve.Constant(0f, 1f / 60f, AnimationUtility.GetEditorCurve(clip, b).Evaluate(0f))).ToArray();
            AnimationUtility.SetEditorCurves(clip, bindings, curves);
        }

        private static string SafeFileName(string name)
        {
            var invalid = Path.GetInvalidFileNameChars();
            return new string(name.Select(ch => invalid.Contains(ch) ? '_' : ch).ToArray());
        }

        private static bool IsPoseControl(Control c) =>
            c.parameter?.name == Emote && c.value >= 210 && c.value <= 253 && c.value == (int)c.value &&
            (c.type == Control.ControlType.Button || (c.type == Control.ControlType.RadialPuppet &&
                c.subParameters?.FirstOrDefault()?.name == "Go/PoseRadial"));

        private static string VendorRoot(string path) =>
            VendorRoots.FirstOrDefault(root => path.StartsWith(root, StringComparison.Ordinal));

        private static IEnumerable<Control> AdditionalPoseControls(AnimatorController controller)
        {
            var root = VendorRoot(AssetDatabase.GetAssetPath(controller));
            if (root == null) yield break;
            var seen = new HashSet<VRCExpressionsMenu>();
            foreach (var name in VendorPoseMenus)
            {
                var menu = AssetDatabase.LoadAssetAtPath<VRCExpressionsMenu>(root + "MainMenu/Menu/SubMenu/" + name + ".asset");
                foreach (var control in Controls(menu, seen))
                    if (IsPoseControl(control)) yield return control;
            }
        }

        // Where an asset's file is: in the project for Assets, in the package's own folder for Packages. Null for neither.
        private static string ClipPathOnDisk(string path)
        {
            if (path.StartsWith("Assets/", StringComparison.Ordinal)) return path;
            var package = UnityEditor.PackageManager.PackageInfo.FindForAssetPath(path);
            return package == null ? null : Path.Combine(package.resolvedPath,
                path.Substring(("Packages/" + package.name + "/").Length));
        }

        private static bool IsSameVendorClip(string left, string right)
        {
            var leftRoot = VendorRoot(left);
            var rightRoot = VendorRoot(right);
            if (leftRoot == null || rightRoot == null || leftRoot == rightRoot ||
                !left.EndsWith(".anim", StringComparison.OrdinalIgnoreCase) ||
                !string.Equals(left.Substring(leftRoot.Length), right.Substring(rightRoot.Length), StringComparison.Ordinal))
                return false;
            // A locally edited copy at the same vendor path is still a custom clip.
            try
            {
                var leftFile = ClipPathOnDisk(left);
                var rightFile = ClipPathOnDisk(right);
                return leftFile != null && rightFile != null &&
                    string.Equals(File.ReadAllText(leftFile).Replace("\r\n", "\n"),
                        File.ReadAllText(rightFile).Replace("\r\n", "\n"), StringComparison.Ordinal);
            }
            catch (IOException) { return false; }
            catch (UnauthorizedAccessException) { return false; }
        }

        private static Plan PlanRows(PoseDeckPreset preset, AnimatorController controller, Control[] controls)
        {
            var slots = FindSlots(controller);
            var menuControls = controls.Where(IsPoseControl).OrderByDescending(c => c.type == Control.ControlType.RadialPuppet)
                .Concat(AdditionalPoseControls(controller)).ToLookup(c => (int)c.value);
            var native = slots.Where(s => !s.Blank && menuControls[s.Number].Any())
                .SelectMany(s => s.Clips.Select(clip => (s.Number, Clip: clip, Path: AssetDatabase.GetAssetPath(clip))))
                .ToArray();
            var rows = new Assignment[preset.poses.Count];
            var reserved = new HashSet<int>();
            int nativeCount = 0;
            // Reserve the original slot before assigning any custom clips, regardless of menu order.
            for (int i = 0; i < rows.Length; i++)
            {
                var clip = preset.poses[i].clip;
                if (!clip) continue;
                var match = Array.Find(native, x => x.Clip == clip);
                if (!match.Clip)
                {
                    var path = AssetDatabase.GetAssetPath(clip);
                    match = Array.Find(native, x => IsSameVendorClip(path, x.Path));
                }
                if (!match.Clip) continue;
                rows[i] = new Assignment { Number = match.Number, NativeControl = menuControls[match.Number].First() };
                reserved.Add(match.Number);
                nativeCount++;
            }

            var buttons = new HashSet<int>(controls.Where(c => IsPoseControl(c) && c.type == Control.ControlType.Button)
                .Select(c => (int)c.value));
            var custom = slots.Where(s => !reserved.Contains(s.Number) && (s.Blank || buttons.Contains(s.Number))).ToArray();
            int next = 0;
            for (int i = 0; i < rows.Length && next < custom.Length; i++)
                if (rows[i] == null)
                {
                    var slot = custom[next++];
                    rows[i] = new Assignment { Number = slot.Number, Borrowed = !slot.Blank };
                }
            return new Plan { Rows = rows, NativeCount = nativeCount, CustomCapacity = custom.Length, BlankCapacity = custom.Count(s => s.Blank) };
        }

        // Rows that play the same GoGoLoco stock pose share its slot in game, and with it one start height (the first
        // row that sets its own: StartHeights) and one set of VR holds (the first row: ApplyHeld). For row `index`: the
        // other rows of its slot, the row whose start height the slot takes (-1: GoGoLoco's own) and the row whose VR
        // holds it takes. `Others` is empty for a row with a slot of its own. `slotOf` gives a clip's stock slot, or -1.
        internal static (int[] Others, int HeightRow, int HeldRow) SharedSlot(PoseDeckPreset preset, int index, Func<AnimationClip, int> slotOf)
        {
            var own = (Array.Empty<int>(), index, index);
            if (!preset || index < 0 || index >= preset.poses.Count || preset.poses[index] == null || !preset.poses[index].clip) return own;
            int slot = slotOf(preset.poses[index].clip);
            if (slot < 0) return own;
            var rows = Enumerable.Range(0, preset.poses.Count)
                .Where(i => preset.poses[i] != null && preset.poses[i].clip && slotOf(preset.poses[i].clip) == slot).ToArray();
            if (rows.Length < 2) return own;
            int height = Array.FindIndex(rows, i => preset.poses[i].overrideHeight);
            return (rows.Where(i => i != index).ToArray(), height < 0 ? -1 : rows[height], rows[0]);
        }

        // What generating reads from a preset, as one value: recorded with each deck, so the window can tell when the
        // preset was edited after its deck was made (the avatar and the build keep the deck as generated).
        internal static string PresetState(PoseDeckPreset preset)
        {
            // By reference: only the preset's own values are read, and Unity reports a preset as gone once it was
            // unloaded (Resources.UnloadUnusedAssets), although its values are still there.
            if (preset is null) return "";
            string Id(Object asset) => asset && AssetDatabase.TryGetGUIDAndLocalFileIdentifier(asset, out string guid, out long id) ? guid + ":" + id : "";
            var text = new System.Text.StringBuilder();
            text.Append(preset.menuTitle).Append('|').Append(preset.keepStockMenu).Append('|').Append(preset.controlsOnEveryPage).Append('|')
                .Append(preset.generateIcons).Append('|').Append(preset.iconView).Append('|').Append(preset.keepNativeIcons);
            foreach (var pose in preset.poses)
                if (pose != null)
                    text.Append('\n').Append(pose.label).Append('|').Append(Id(pose.clip)).Append('|').Append((int)pose.category).Append('|')
                        // Invariant: the state is compared on whatever PC opens the project next.
                        .Append(pose.overrideHeight ? pose.height.ToString("R", System.Globalization.CultureInfo.InvariantCulture) : "")
                        .Append('|').Append(Id(pose.icon)).Append('|')
                        .Append(pose.vrHands).Append('|').Append(pose.vrLegs);
            using (var md5 = System.Security.Cryptography.MD5.Create())
                return BitConverter.ToString(md5.ComputeHash(System.Text.Encoding.UTF8.GetBytes(text.ToString()))).Replace("-", "");
        }

        // The state (PresetState) of the preset when the deck on this GoGoLoco object was made ("기존 GoGoLoco에 적용").
        // Null when the object carries no such deck; "" for a deck made before the state was recorded.
        internal static string AppliedState(GameObject go)
        {
            if (!go) return null;
            foreach (var installer in go.GetComponents<ModularAvatarMenuInstaller>())
            {
                string folder = FolderOf(installer.menuToAppend);
                var marker = folder.Length == 0 ? null : AssetDatabase.LoadAssetAtPath<PoseDeckExistingInstallation>(folder + ExistingInstallationName);
                if (marker && marker.appliedMenu == installer.menuToAppend) return marker.presetState ?? "";
            }
            return null;
        }

        // A deck made before 0.23.0, which recorded no preset state, as it plays the preset's rows that differ in 0.23.0:
        // custom poses in one of GoGoLoco's own button slots (Borrowed) without a start height of their own. Such a deck
        // starts them at the slot's own height from the Action (0.205 in slot 228), 0.23.0 at 0.25.
        internal sealed class LegacyDeck
        {
            // The clip of each such row whose slot in the deck was found to hold it, and the height the deck starts it at.
            public readonly Dictionary<AnimationClip, float> Heights = new Dictionary<AnimationClip, float>();
            // Such rows in all, and those whose place in the deck could not be confirmed (the preset changed since).
            public int Borrowed, Unconfirmed;
        }

        // The deck on the GoGoLoco object `go` ("기존 GoGoLoco에" or the object "아바타에 새로" added) when it was made
        // before 0.23.0 from `preset`, read from the deck itself; null for a deck that recorded its state, or none.
        internal static LegacyDeck FindLegacyDeck(PoseDeckPreset preset, GameObject go)
        {
            if (!preset || !go) return null;
            try
            {
                var bindings = GetBindings(go);
                var menu = bindings.Menu.menuToAppend;
                string folder = FolderOf(menu);
                if (folder.Length == 0) return null;
                string state;
                AnimatorController stockBase;
                VRCExpressionsMenu stockMenu;
                var existing = AssetDatabase.LoadAssetAtPath<PoseDeckExistingInstallation>(folder + ExistingInstallationName);
                var avatarMarker = AssetDatabase.LoadAssetAtPath<PoseDeckAvatarInstallation>(folder + PoseDeckAvatarInstall.Marker);
                if (existing && existing.appliedMenu == menu)
                    (state, stockBase, stockMenu) = (existing.presetState, existing.stockBase, existing.stockMenu);
                else if (avatarMarker && avatarMarker.menu == menu && avatarMarker.sourcePrefab)
                {
                    var stock = GetBindings(avatarMarker.sourcePrefab);
                    (state, stockBase, stockMenu) = (avatarMarker.presetState, stock.Base.animator as AnimatorController, stock.Menu.menuToAppend);
                }
                else return null;
                if (!string.IsNullOrEmpty(state) || !stockBase || !stockMenu || !(bindings.Base.animator is AnimatorController applied)) return null;

                var legacy = new LegacyDeck();
                var plan = PlanRows(preset, stockBase, Controls(stockMenu, new HashSet<VRCExpressionsMenu>()).ToArray());
                var slots = FindSlots(applied).ToDictionary(slot => slot.Number);
                // The Action the object links now: the deck's copy changed only the slots of rows with their own height.
                var heights = FloatDriverSlots(bindings.Action ? bindings.Action.animator as AnimatorController : null);
                for (int i = 0; i < preset.poses.Count; i++)
                {
                    var row = plan.Rows[i];
                    var clip = preset.poses[i]?.clip;
                    if (row == null || !row.Borrowed || !clip || preset.poses[i].overrideHeight) continue;
                    legacy.Borrowed++;
                    // Custom clips play as copies that keep their name (GenerateAssets).
                    if (slots.TryGetValue(row.Number, out var slot) && slot.Clips.Any(c => c && c.name == clip.name) &&
                        heights.TryGetValue(row.Number, out var set))
                        legacy.Heights[clip] = set.Set.value;
                    else legacy.Unconfirmed++;
                }
                return legacy;
            }
            catch (InvalidOperationException) { return null; }
        }

        private static string Title(PoseEntry row) => string.IsNullOrWhiteSpace(row.label) ? row.clip.name : row.label.Trim();

        private static void ValidateRows(PoseDeckPreset preset)
        {
            string problem = PresetProblem(preset);
            if (problem != null) throw new InvalidOperationException(problem);
        }

        // What in the preset stops generating, said the way generating would say it, or null. The window shows it next to
        // ‘생성 및 적용’ before anything is rendered or copied.
        internal static string PresetProblem(PoseDeckPreset preset)
        {
            if (string.IsNullOrWhiteSpace(preset.menuTitle)) return "메뉴 이름을 입력해 주세요.";
            if (preset.poses.Count == 0) return "포즈를 하나 이상 추가해 주세요.";
            for (int i = 0; i < preset.poses.Count; i++)
            {
                var clip = preset.poses[i]?.clip;
                if (!clip || !clip.humanMotion || clip.legacy || !EditorUtility.IsPersistent(clip))
                    return $"포즈 {i + 1}: 프로젝트에 저장된 Humanoid 애니메이션 클립을 지정해 주세요. FBX는 Rig를 Humanoid로 임포트해야 합니다.";
            }
            var twice = preset.poses.GroupBy(p => (p.category, Title(p))).FirstOrDefault(g => g.Count() > 1);
            if (twice != null)
                return $"같은 분류({CategoryNames[(int)twice.Key.category]})에 이름이 ‘{twice.Key.Item2}’인 포즈가 {twice.Count()}개 있습니다. 포즈 이름을 구분해 주세요.";
            return null;
        }

        internal static string Preview(PoseDeckPreset preset, GameObject go)
        {
            var target = ExistingTarget(go);
            var (controller, menu, installed, legacy) = Sources(preset, target);
            var summary = Preview(preset, controller, menu, ActionSource(target));
            if (legacy)
                return $"현재 연결: 예전 생성본 ‘{installed.name}’. 생성 및 적용을 누르면 ‘{preset.name}’으로 갱신합니다.\n" + summary;
            if (installed && installed != preset)
                return $"현재 연결: ‘{installed.name}’. 생성 및 적용을 누르면 ‘{preset.name}’으로 바뀝니다.\n" + summary;
            return summary;
        }

        internal static string Preview(PoseDeckPreset preset, AnimatorController controller, VRCExpressionsMenu menu,
            AnimatorController action = null)
        {
            var plan = PlanRows(preset, controller, Controls(menu, new HashSet<VRCExpressionsMenu>()).ToArray());
            int custom = plan.Rows.Length - plan.NativeCount;
            int heights = preset.poses.Count(p => p.overrideHeight);
            int hands = preset.poses.Count(p => p.vrHands), legs = preset.poses.Count(p => p.vrLegs);
            int borrowed = plan.Rows.Count(row => row != null && row.Borrowed);
            var summary = $"원본 높이 유지: {plan.NativeCount}개. 커스텀 포즈: {custom}/{plan.CustomCapacity}개 (빈 슬롯 {plan.BlankCapacity}개)." +
                (heights > 0 ? $" 시작 높이 직접 지정: {heights}개." : "") + (hands > 0 ? $" VR에서 손도 포즈대로: {hands}개." : "") +
                (legs > 0 ? $" VR에서 다리도 포즈대로: {legs}개." : "") +
                (borrowed > 0 ? $" 빈 슬롯이 모자라 커스텀 포즈 {borrowed}개는 GoGoLoco 원본 포즈 자리를 씁니다(그 원본 포즈 버튼은 이 포즈로 바뀌고, 높이를 지정하지 않으면 {DefaultStartHeight:0.00}로 시작)." : "");
            // Rows of one stock pose share its slot, and with it one start height and one set of VR holds (SharedSlot).
            var sharing = plan.Rows.Select((row, i) => (row, i)).Where(x => x.row?.NativeControl != null).GroupBy(x => x.row.Number)
                .Where(g => g.Count() > 1).Select(g => $"{string.Join("·", g.Select(x => x.i + 1))}번(슬롯 {g.Key})").ToArray();
            if (sharing.Length > 0)
                summary += $"\n같은 GoGoLoco 원본 포즈를 넣은 줄은 게임에서 슬롯 하나를 함께 씁니다: {string.Join(", ", sharing)}. " +
                    "시작 높이는 직접 지정한 첫 줄, VR 설정은 첫 줄의 것이 모두에 적용됩니다.";
            var startHeights = StartHeights(preset, plan.Rows);
            if (startHeights.Count > 0)
            {
                var inAction = FloatDriverSlots(action);
                var late = startHeights.Keys.Where(n => !inAction.ContainsKey(n)).OrderBy(n => n).ToArray();
                summary += !action ? " Action을 찾지 못해 시작 높이는 버튼을 뗀 뒤 맞춥니다."
                    : late.Length == 0 ? " 시작 높이는 GoGoLoco 원래 포즈처럼 누르는 순간 적용합니다(Action 복사본)."
                    : $" 슬롯 {string.Join(", ", late)}은(는) Action에서 높이 설정을 찾지 못해 버튼을 뗀 뒤 맞춥니다.";
            }
            var root = VendorRoot(AssetDatabase.GetAssetPath(controller));
            var unmatched = preset.poses.Select((row, i) => (row, i))
                .Where(x => x.row.clip && plan.Rows[x.i]?.NativeControl == null)
                .Select(x => (label: Title(x.row), root: VendorRoot(AssetDatabase.GetAssetPath(x.row.clip))))
                .Where(x => x.root != null).ToArray();
            if (unmatched.Length == 0) return summary;
            var labels = string.Join(", ", unmatched.Take(3).Select(x => x.label)) +
                (unmatched.Length > 3 ? $" 외 {unmatched.Length - 3}개" : "");
            return summary + $"\n원본 높이 프리셋이 연결되지 않은 GoGoLoco 클립: {labels}."
                + (root != null && unmatched.Any(x => x.root != root)
                    ? $" 다른 경로에서 가져왔다면 현재 Base가 사용하는 {root} 쪽도 확인해 주세요." : "");
        }

        private static BlendTree CloneTree(BlendTree source, AnimationClip pose, AnimatorController destination,
            Dictionary<BlendTree, BlendTree> cache)
        {
            if (cache.TryGetValue(source, out var previous)) return previous;
            var copy = Object.Instantiate(source);
            copy.name = source.name;
            copy.hideFlags = HideFlags.HideInHierarchy;
            AssetDatabase.AddObjectToAsset(copy, destination);
            cache.Add(source, copy);
            var children = source.children;
            bool replace = source.blendParameter == "VRModeProxy" && children.Length == 2 &&
                children.All(c => c.motion is AnimationClip);
            for (int i = 0; i < children.Length; i++)
            {
                if (replace) children[i].motion = pose;
                else if (children[i].motion is BlendTree child) children[i].motion = CloneTree(child, pose, destination, cache);
            }
            copy.children = children;
            EditorUtility.SetDirty(copy);
            return copy;
        }

        // GoGoLoco objects (with a menu installer and a Base merge) under root whose Base or Action controller or installer
        // menu points at an asset that no longer exists, e.g. a generated folder that went to the trash before an undo
        // brought the old link back. Other gimmicks' merges are not the deck's to report.
        internal static GameObject[] FindBrokenLinks(GameObject root)
        {
            if (!root) return Array.Empty<GameObject>();
            return root.GetComponentsInChildren<ModularAvatarMenuInstaller>(true)
                .Where(menu => menu.GetComponents<ModularAvatarMergeAnimator>().Any(m => m.layerType == VRCAvatarDescriptor.AnimLayerType.Base) &&
                    (IsMissing(menu, "menuToAppend") || menu.GetComponents<ModularAvatarMergeAnimator>().Any(m => Linked(m) && IsMissing(m, "animator"))))
                .Select(menu => menu.gameObject).Distinct().ToArray();
        }

        // The merges a deck links to its generated files: the Base and, since 0.22.0, the Action.
        private static bool Linked(ModularAvatarMergeAnimator merge) =>
            merge.layerType == VRCAvatarDescriptor.AnimLayerType.Base || merge.layerType == VRCAvatarDescriptor.AnimLayerType.Action;

        private static bool IsMissing(Object component, string property)
        {
            var value = new SerializedObject(component).FindProperty(property);
            return value != null && value.propertyType == SerializedPropertyType.ObjectReference &&
                   !value.objectReferenceValue && value.objectReferenceInstanceIDValue != 0;
        }

        // Puts the broken links back. A missing Action copy goes back to the Action its installation recorded (NEKO AFK's,
        // say) while that record is still there next to the menu; the rest go back to the GoGoLoco prefab's own values,
        // which for the Action is GoGoLoco's own. Returns what actually changed: "Base", "Action", "메뉴", or
        // "Action(원래 Action)" for the recorded one.
        internal static string[] RevertBrokenLinks(GameObject go)
        {
            var recorded = go.GetComponents<ModularAvatarMenuInstaller>().Select(m => RecordedAction(FolderOf(m.menuToAppend)).Stock)
                .FirstOrDefault(a => a);
            var fromRecord = go.GetComponents<ModularAvatarMergeAnimator>()
                .Where(m => recorded && m.layerType == VRCAvatarDescriptor.AnimLayerType.Action && IsMissing(m, "animator")).ToArray();
            var broken = go.GetComponents<ModularAvatarMergeAnimator>()
                .Where(m => Linked(m) && !fromRecord.Contains(m) && IsMissing(m, "animator"))
                .Select(m => ((Object)m, "animator", m.layerType.ToString()))
                .Concat(go.GetComponents<ModularAvatarMenuInstaller>().Where(m => IsMissing(m, "menuToAppend"))
                    .Select(m => ((Object)m, "menuToAppend", "메뉴"))).ToArray();
            if (broken.Any(b => !PrefabUtility.IsPartOfPrefabInstance(b.Item1)))
                throw new InvalidOperationException($"‘{go.name}’은 GoGoLoco 프리팹 인스턴스가 아니라 원본 값을 알 수 없습니다. Inspector에서 Base, Action과 메뉴를 직접 연결해 주세요.");
            var done = new List<string>();
            foreach (var merge in fromRecord)
            {
                LinkAction(merge, recorded);
                done.Add("Action(원래 Action)");
            }
            foreach (var (component, property, label) in broken)
            {
                var value = new SerializedObject(component).FindProperty(property);
                if (!value.prefabOverride) continue; // the prefab's own value is the missing one: nothing to put back
                PrefabUtility.RevertPropertyOverride(value, InteractionMode.UserAction);
                done.Add(label);
            }
            EditorSceneManager.MarkSceneDirty(go.scene);
            return done.ToArray();
        }

        // A Pose Deck Base generated before 0.15.0 holds custom clips as they were, without GoGoLoco's additive reference
        // pose (see NeedsReference), so in game those poses barely show until the deck is generated again. Returns the
        // GoGoLoco objects under root that carry such a Base, with the affected pose names.
        internal static (GameObject gogo, string[] poses)[] FindStaleDecks(GameObject root)
        {
            var found = new List<(GameObject, string[])>();
            if (!root) return found.ToArray();
            foreach (var merge in root.GetComponentsInChildren<ModularAvatarMergeAnimator>(true))
            {
                if (merge.layerType != VRCAvatarDescriptor.AnimLayerType.Base || !(merge.animator is AnimatorController controller) ||
                    Path.GetFileName(AssetDatabase.GetAssetPath(controller)) != GeneratedBaseName) continue;
                List<Slot> slots;
                try { slots = FindSlots(controller); }
                catch (InvalidOperationException) { continue; }
                var clips = slots.SelectMany(s => s.Clips).Where(c => c).Distinct().ToArray();
                var reference = AdditiveReference(clips);
                var stale = clips.Where(c => VendorRoot(AssetDatabase.GetAssetPath(c)) == null && NeedsReference(c, reference))
                    .Select(c => c.name).Distinct().ToArray();
                if (stale.Length > 0) found.Add((merge.gameObject, stale));
            }
            return found.ToArray();
        }

        // Moves a preset to the trash (recoverable, like replaced generated folders). Decks made from it keep working;
        // only generating them again needs the preset.
        internal static void TrashPreset(PoseDeckPreset preset)
        {
            string path = preset ? AssetDatabase.GetAssetPath(preset) : null;
            if (string.IsNullOrEmpty(path) || !path.StartsWith("Assets/", StringComparison.Ordinal) || !PoseDeckGeneratedCleanup.Trash(path))
                throw new IOException($"프리셋 ‘{(preset ? preset.name : "?")}’을 휴지통으로 옮기지 못했습니다.");
        }

        // The id the installation in a generated folder was made with (PoseDeckExistingInstallation.deckId), or null for a
        // folder without one (no installation there, or made before the id was recorded).
        internal static string DeckId(string folder)
        {
            if (string.IsNullOrEmpty(folder) || !AssetDatabase.IsValidFolder(folder)) return null;
            var existing = AssetDatabase.LoadAssetAtPath<PoseDeckExistingInstallation>(folder + "/" + ExistingInstallationName);
            var avatar = AssetDatabase.LoadAssetAtPath<PoseDeckAvatarInstallation>(folder + "/" + PoseDeckAvatarInstall.Marker);
            string id = existing ? existing.deckId : avatar ? avatar.deckId : null;
            return string.IsNullOrEmpty(id) ? null : id;
        }

        // The PoseDeck_Generated folder holding a generated installer menu or Action copy, or null.
        internal static string GeneratedFolderOf(Object asset)
        {
            string path = asset ? AssetDatabase.GetAssetPath(asset) : "";
            int slash = path.LastIndexOf('/');
            string file = slash < 0 ? "" : path.Substring(slash + 1);
            if (file != GeneratedMenuName && file != GeneratedActionName) return null;
            string folder = path.Substring(0, slash);
            return folder.Substring(folder.LastIndexOf('/') + 1).StartsWith(GeneratedFolderPrefix, StringComparison.Ordinal) ? folder : null;
        }

        // Saves rendered pose icons as PNGs in the generated folder, imported for the VRChat menu (256 px, alpha).
        private static Dictionary<AnimationClip, Texture2D> SaveIcons(string folder, PoseDeckPreset preset,
            IReadOnlyDictionary<AnimationClip, Texture2D> icons)
        {
            var saved = new Dictionary<AnimationClip, Texture2D>();
            if (icons == null || icons.Count == 0) return saved;
            AssetDatabase.CreateFolder(folder, "Icons");
            int n = 0;
            foreach (var clip in preset.poses.Select(p => p.clip).Where(c => c).Distinct())
            {
                if (!icons.TryGetValue(clip, out var texture) || !texture) continue;
                string path = $"{folder}/Icons/{++n:00}_{SafeFileName(clip.name)}.png";
                File.WriteAllBytes(path, texture.EncodeToPNG());
                AssetDatabase.ImportAsset(path, ImportAssetOptions.ForceSynchronousImport);
                if (AssetImporter.GetAtPath(path) is TextureImporter importer)
                {
                    importer.textureType = TextureImporterType.Default;
                    importer.alphaIsTransparency = true;
                    importer.mipmapEnabled = false;
                    importer.wrapMode = TextureWrapMode.Clamp;
                    importer.maxTextureSize = 256;
                    importer.textureCompression = TextureImporterCompression.CompressedHQ;
                    importer.SaveAndReimport();
                }
                var asset = AssetDatabase.LoadAssetAtPath<Texture2D>(path);
                if (asset) saved[clip] = asset;
            }
            return saved;
        }

        private static void EnsureInAsset(Object item, Object owner)
        {
            if (item && !EditorUtility.IsPersistent(item)) AssetDatabase.AddObjectToAsset(item, owner);
        }

        // Each slot's own start height: the first row with "시작 높이 직접 지정" (two rows can share a stock slot). A
        // custom pose in one of GoGoLoco's own button slots (Borrowed) without its own height starts at the custom-slot
        // value, as the window says and its preview shows. Until 0.22.0 it started at the height GoGoLoco gives the pose
        // it replaced (0.205 in slot 228, 0.12 in 229, …), which no one had chosen for it.
        private static Dictionary<int, float> StartHeights(PoseDeckPreset preset, Assignment[] rows)
        {
            var heights = new Dictionary<int, float>();
            for (int i = 0; i < preset.poses.Count; i++)
            {
                if (rows[i] == null || heights.ContainsKey(rows[i].Number)) continue;
                if (preset.poses[i].overrideHeight) heights[rows[i].Number] = Mathf.Clamp01(preset.poses[i].height);
                else if (rows[i].Borrowed) heights[rows[i].Number] = DefaultStartHeight;
            }
            return heights;
        }

        // Start heights, since 0.22.0, go where GoGoLoco puts its own: into the Action's Float Driver (FloatDriverSlots),
        // which sets Go/Float when the button is pressed, in a copy of the Action the GoGoLoco object links (its own file
        // is left alone). Init enters VRChat's pose space PoseSpaceDelay after the press and so measures the head at the
        // pose's own height, as for GoGoLoco's poses. Until 0.21.1 the deck set the height in the Base when the button was
        // released (ApplyStartHeights); a press held past PoseSpaceDelay was measured at the press value (0.25 on custom
        // slots) and the pose sat off its floor in VR until a second, later entry fixed it. Returns the slots set here.
        private static HashSet<int> PatchAction(AnimatorController action, IReadOnlyDictionary<int, float> heights)
        {
            var slots = FloatDriverSlots(action);
            var done = new HashSet<int>();
            foreach (var pair in heights)
            {
                if (!slots.TryGetValue(pair.Key, out var found)) continue;
                found.Set.value = pair.Value;
                EditorUtility.SetDirty(found.Driver);
                done.Add(pair.Key);
            }
            if (done.Count != 0) EditorUtility.SetDirty(action);
            return done;
        }

        // The Base fallback for slots the Action cannot take (no Action merge, or a slot its Float Driver does not set as
        // GoGoLoco 1.8.6 does), as the deck did for every slot until 0.21.1. Each slot goes Init → (button released) →
        // Left/Right. A one-frame "Left Height"/"Right Height" step between them sets Go/Float to the pose's start height,
        // after GoGoLoco's Action layer has set its own value on the press. The step is skipped once ▲/▼ was used
        // (Go/PosePlaySpace), like GoGoLoco's own presets.
        // Init enters pose space PoseSpaceDelay after the press; the head can be measured there before the step has set
        // the pose's own height (at the press value, 0.25 on custom slots), and in VR the pose then sat off its floor until
        // the view was moved, or until GoGoLoco's height radial was opened, which enters pose space every frame while open.
        // So the pose state (Left/Right) enters pose space again PoseSpaceDelay after it starts, once the height is in.
        // It is on the pose state, not the one-frame step: 0.20.3 put the delayed entry on the step and it did not take
        // effect in game (a delayed entry seems to need its state still playing; GoGoLoco's one-frame states use delay 0).
        // In game this corrects the view a moment after the release.
        private static void ApplyStartHeights(AnimatorController controller, IReadOnlyDictionary<int, Slot> slots,
            IReadOnlyDictionary<int, float> heights)
        {
            bool hasPlaySpace = controller.parameters.Any(p => p.name == PlaySpace && p.type == AnimatorControllerParameterType.Bool);
            foreach (var pair in heights)
            {
                var slot = slots[pair.Key];
                foreach (var side in new[] { "Left", "Right" })
                {
                    var pose = slot.States.First(s => s.name == side);
                    var init = slot.States.First(s => s.name == side + " Init");
                    var position = slot.Machine.states.FirstOrDefault(c => c.state == pose).position + new Vector3(0, 60, 0);
                    var step = slot.Machine.AddState(side + HeightStateSuffix, position);
                    EnsureInAsset(step, controller);
                    step.motion = pose.motion;
                    step.mirror = pose.mirror;
                    step.speed = pose.speed;
                    // GoGoLoco's dial poses play at the dial's value (Go/PoseRadialSmooth); without it the step showed
                    // the start of the motion for its one frame.
                    step.timeParameter = pose.timeParameter;
                    step.timeParameterActive = pose.timeParameterActive;
                    step.iKOnFeet = pose.iKOnFeet;
                    step.writeDefaultValues = pose.writeDefaultValues;
                    var driver = step.AddStateMachineBehaviour<VRCAvatarParameterDriver>();
                    EnsureInAsset(driver, controller);
                    driver.localOnly = false;
                    driver.parameters.Add(new VRC.SDKBase.VRC_AvatarParameterDriver.Parameter
                    {
                        type = VRC.SDKBase.VRC_AvatarParameterDriver.ChangeType.Set, name = Float, value = pair.Value,
                    });
                    var space = pose.behaviours.OfType<VRCAnimatorTemporaryPoseSpace>().FirstOrDefault();
                    if (!space)
                    {
                        space = pose.AddStateMachineBehaviour<VRCAnimatorTemporaryPoseSpace>();
                        EnsureInAsset(space, controller);
                    }
                    space.enterPoseSpace = true;
                    space.fixedDelay = true;
                    space.delayTime = PoseSpaceDelay;

                    var enter = init.AddTransition(step);
                    EnsureInAsset(enter, controller);
                    enter.hasExitTime = false;
                    enter.hasFixedDuration = true;
                    enter.duration = 0f;
                    enter.exitTime = 0f;
                    enter.AddCondition(AnimatorConditionMode.Equals, 0, Emote);
                    if (hasPlaySpace) enter.AddCondition(AnimatorConditionMode.IfNot, 0, PlaySpace);
                    // Checked before Init's own "VRCEmote == 0 → Left", which still handles the play-space case.
                    init.transitions = new[] { enter }.Concat(init.transitions.Where(t => t != enter)).ToArray();

                    var leave = step.AddTransition(pose);
                    EnsureInAsset(leave, controller);
                    leave.hasExitTime = true;
                    leave.exitTime = 0f;
                    leave.hasFixedDuration = true;
                    leave.duration = 0f;
                    // A state played at a parameter's value has no time to count an exit time by: leave on a condition
                    // that always holds (see Always).
                    if (step.timeParameterActive)
                    {
                        leave.hasExitTime = false;
                        Always(leave);
                    }
                    foreach (var o in new Object[] { step, driver, space, pose, enter, leave, init }) EditorUtility.SetDirty(o);
                }
            }
        }

        // "VR에서 손도 / 다리도 포즈대로". In VR (3–4 points) GoGoLoco keeps the hands on the controllers and the hips on
        // Tracking during a pose (VRChat IK places them from the headset, or a 4-point waist tracker moves them); only the
        // feet follow the animation. It also sets tracking again on its own while the pose plays: when the pose starts,
        // when its head button is used and when the head height crosses its crouch thresholds. Other gimmicks do the same:
        // AvatarBasicTool's tracking layer puts the hands and feet on Tracking whenever its own poses are off, which gives
        // 3-point users VRChat's leg IK. A held pose therefore sets its parts to Animation (the hands; or the feet) when
        // its Left/Right state is entered and again from a "Left Hold"/"Right Hold" loop every HoldSeconds (whole plays
        // of an animated pose, so it does not jump). The hips are never held: GoGoLoco puts them on Animation only while
        // seated in a station (and in its "Hip Drift" joke emote), and a standing 3-point pose with the hips on the
        // animation and the head on the headset bends and drags the whole body when the head moves (0.18.0–0.19.0 did
        // this). With held hands anywhere in the deck, every other slot's Left/Right puts the hands back on Tracking, as
        // GoGoLoco has them during poses, so switching poses does not leave them held; the feet need nothing, GoGoLoco
        // already animates them during 3-point poses. Ending the pose restores tracking through GoGoLoco's own states
        // (reset, locomotion, the Action layer's restore states). The head, hips and fingers are left to GoGoLoco. No
        // parameters are added: the loop runs from time alone, on every client.
        internal const float HoldSeconds = 1f;
        private const string HoldStateSuffix = " Hold";

        [Flags]
        internal enum HeldParts { None = 0, Hands = 1, Legs = 2 }

        internal static HeldParts Held(PoseEntry row) =>
            (row.vrHands ? HeldParts.Hands : HeldParts.None) | (row.vrLegs ? HeldParts.Legs : HeldParts.None);

        private static void ApplyHeld(AnimatorController controller, IReadOnlyDictionary<int, Slot> slots,
            PoseDeckPreset preset, Assignment[] rows)
        {
            // A stock slot shared by two rows follows the first row, as with start heights.
            var held = new Dictionary<int, HeldParts>();
            for (int i = 0; i < preset.poses.Count; i++)
                if (!held.ContainsKey(rows[i].Number)) held[rows[i].Number] = Held(preset.poses[i]);
            var any = held.Values.Aggregate(HeldParts.None, (a, b) => a | b);
            if (any == HeldParts.None) return;
            foreach (var slot in slots.Values)
                foreach (var side in new[] { "Left", "Right" })
                {
                    var pose = slot.States.First(s => s.name == side);
                    var parts = held.TryGetValue(slot.Number, out var p) ? p : HeldParts.None;
                    Tracking(pose, controller, parts, any);
                    if (parts == HeldParts.None) continue;
                    var position = slot.Machine.states.FirstOrDefault(c => c.state == pose).position + new Vector3(0, 120, 0);
                    var hold = slot.Machine.AddState(side + HoldStateSuffix, position);
                    EnsureInAsset(hold, controller);
                    hold.motion = pose.motion;
                    hold.mirror = pose.mirror;
                    hold.mirrorParameter = pose.mirrorParameter;
                    hold.mirrorParameterActive = pose.mirrorParameterActive;
                    hold.speed = pose.speed;
                    hold.speedParameter = pose.speedParameter;
                    hold.speedParameterActive = pose.speedParameterActive;
                    hold.cycleOffset = pose.cycleOffset;
                    hold.cycleOffsetParameter = pose.cycleOffsetParameter;
                    hold.cycleOffsetParameterActive = pose.cycleOffsetParameterActive;
                    hold.timeParameter = pose.timeParameter;
                    hold.timeParameterActive = pose.timeParameterActive;
                    hold.iKOnFeet = pose.iKOnFeet;
                    hold.writeDefaultValues = pose.writeDefaultValues;
                    hold.tag = pose.tag;
                    Tracking(hold, controller, parts, any);
                    // Leaving works from the loop as from the pose: copy the pose's exits first, then add the loop.
                    foreach (var exit in pose.transitions) CopyTransition(exit, hold, controller);
                    var enter = pose.AddTransition(hold);
                    var again = hold.AddTransition(hold);
                    again.canTransitionToSelf = true;
                    if (pose.timeParameterActive)
                    {
                        TimedLoop(enter, controller);
                        TimedLoop(again, controller);
                    }
                    else
                    {
                        var (enterAt, againAt, offset) = HoldTiming(pose.motion);
                        Loop(enter, enterAt, offset, controller);
                        Loop(again, againAt, offset, controller);
                    }
                    foreach (var o in new Object[] { hold, pose }) EditorUtility.SetDirty(o);
                }
        }

        // Held parts on Animation (hands; feet, never the hips); hands held elsewhere in the deck back to Tracking, as
        // GoGoLoco has them during poses; the rest unchanged. Nothing is added to a state that changes nothing.
        private static void Tracking(AnimatorState state, AnimatorController controller, HeldParts held, HeldParts any)
        {
            const VRC.SDKBase.VRC_AnimatorTrackingControl.TrackingType animation = VRC.SDKBase.VRC_AnimatorTrackingControl.TrackingType.Animation;
            const VRC.SDKBase.VRC_AnimatorTrackingControl.TrackingType tracking = VRC.SDKBase.VRC_AnimatorTrackingControl.TrackingType.Tracking;
            bool hands = held.HasFlag(HeldParts.Hands) || any.HasFlag(HeldParts.Hands), feet = held.HasFlag(HeldParts.Legs);
            if (!hands && !feet) return;
            var control = state.AddStateMachineBehaviour<VRCAnimatorTrackingControl>();
            EnsureInAsset(control, controller);
            if (hands) control.trackingLeftHand = control.trackingRightHand = held.HasFlag(HeldParts.Hands) ? animation : tracking;
            if (feet) control.trackingLeftFoot = control.trackingRightFoot = animation;
            EditorUtility.SetDirty(control);
        }

        private static void Loop(AnimatorStateTransition transition, float exitTime, float offset, AnimatorController controller)
        {
            EnsureInAsset(transition, controller);
            transition.hasExitTime = true;
            transition.exitTime = exitTime;
            transition.offset = offset;
            transition.hasFixedDuration = true;
            transition.duration = 0f;
            transition.interruptionSource = TransitionInterruptionSource.None;
            EditorUtility.SetDirty(transition);
        }

        // VRChat's VRCEmote is 0–255, so this holds whenever it is asked. GoGoLoco's own pose exits carry the same condition.
        private static void Always(AnimatorStateTransition transition) => transition.AddCondition(AnimatorConditionMode.Less, 256, Emote);

        // The hold loop of a pose that plays at a parameter's value instead of in time: GoGoLoco's dial poses (slots 227,
        // 232–234, 236, 237, 239–241, 244, 250, 253; Go/PoseRadialSmooth). Such a state's normalized time is the dial's
        // value, so an exit time counts nothing there: until 0.22.0 these poses reached the loop only with the dial at its
        // end and never ran it again. Here the loop is a transition that is always allowed and lasts HoldSeconds. The hold
        // state is entered, and its tracking set, when each transition starts; both ends play the same dial position, so
        // nothing moves. The pose's exits come before the loop in the list and interrupt it.
        private static void TimedLoop(AnimatorStateTransition transition, AnimatorController controller)
        {
            EnsureInAsset(transition, controller);
            transition.hasExitTime = false;
            transition.hasFixedDuration = true;
            transition.duration = HoldSeconds;
            transition.offset = 0f;
            transition.interruptionSource = TransitionInterruptionSource.Source;
            transition.orderedInterruption = true;
            Always(transition);
            EditorUtility.SetDirty(transition);
        }

        private static void CopyTransition(AnimatorStateTransition source, AnimatorState from, AnimatorController controller)
        {
            var copy = source.isExit ? from.AddExitTransition()
                : source.destinationStateMachine ? from.AddTransition(source.destinationStateMachine)
                : from.AddTransition(source.destinationState);
            EnsureInAsset(copy, controller);
            copy.name = source.name;
            copy.hasExitTime = source.hasExitTime;
            copy.exitTime = source.exitTime;
            copy.hasFixedDuration = source.hasFixedDuration;
            copy.duration = source.duration;
            copy.offset = source.offset;
            copy.interruptionSource = source.interruptionSource;
            copy.orderedInterruption = source.orderedInterruption;
            copy.canTransitionToSelf = source.canTransitionToSelf;
            copy.mute = source.mute;
            copy.solo = source.solo;
            foreach (var condition in source.conditions) copy.AddCondition(condition.mode, condition.threshold, condition.parameter);
            EditorUtility.SetDirty(copy);
        }

        // Exit times (normalized, so in plays of the motion) for pose → hold and hold → hold, and where the hold starts.
        // Static poses repeat every HoldSeconds. An animated looping pose repeats on whole plays, so restarting is
        // seamless. An animated pose that plays once starts the hold on its last frame and repeats every HoldSeconds there.
        internal static (float Enter, float Again, float Offset) HoldTiming(Motion motion)
        {
            var clips = (motion is BlendTree tree ? TreeAndChildren(tree).SelectMany(t => t.children).Select(c => c.motion)
                : new[] { motion }).OfType<AnimationClip>().Where(c => c).ToArray();
            const float frame = 1f / 60f;
            float length = Mathf.Max(frame, clips.Select(c => c.length).DefaultIfEmpty(0f).Max());
            float plays = Mathf.Max(1f, Mathf.Ceil(HoldSeconds / length - .001f));
            bool once = length > 2f * frame && clips.Any(c => !AnimationUtility.GetAnimationClipSettings(c).loopTime);
            return once ? (1f, 1f + HoldSeconds / length, 1f) : (plays, plays, 0f);
        }

        private static IEnumerable<BlendTree> TreeAndChildren(BlendTree tree)
        {
            yield return tree;
            foreach (var child in tree.children)
                if (child.motion is BlendTree nested)
                    foreach (var descendant in TreeAndChildren(nested)) yield return descendant;
        }

        // The copied Base still holds the stock trees of the slots that now play a custom clip. Remove only those,
        // and only when no state, including a synced layer override, still reaches them.
        private static void RemoveUnusedTrees(AnimatorController controller, IEnumerable<BlendTree> replaced)
        {
            var reachable = new HashSet<Motion>();
            void Reach(Motion motion)
            {
                if (!motion || !reachable.Add(motion) || !(motion is BlendTree tree)) return;
                foreach (var child in tree.children) Reach(child.motion);
            }
            var layers = controller.layers;
            foreach (var layer in layers)
            {
                foreach (var machine in Machines(layer.stateMachine))
                    foreach (var child in machine.states) Reach(child.state.motion);
                if (layer.syncedLayerIndex < 0 || layer.syncedLayerIndex >= layers.Length) continue;
                foreach (var machine in Machines(layers[layer.syncedLayerIndex].stateMachine))
                    foreach (var child in machine.states) Reach(layer.GetOverrideMotion(child.state));
            }
            string path = AssetDatabase.GetAssetPath(controller);
            foreach (var tree in replaced.SelectMany(TreeAndChildren).Distinct().ToArray())
            {
                if (!tree || reachable.Contains(tree) || AssetDatabase.GetAssetPath(tree) != path) continue;
                AssetDatabase.RemoveObjectFromAsset(tree);
                Object.DestroyImmediate(tree, true);
            }
        }

        // PoseDeck_Generated folders that nothing in the project refers to. Requires saved scenes so that the files on
        // disk match what is open.
        internal static string[] FindUnusedGeneratedFolders()
        {
            var stage = UnityEditor.SceneManagement.PrefabStageUtility.GetCurrentPrefabStage();
            if (Enumerable.Range(0, SceneManager.sceneCount).Any(i => SceneManager.GetSceneAt(i).isDirty) ||
                (stage != null && stage.scene.isDirty))
                throw new InvalidOperationException("저장하지 않은 씬이나 프리팹이 있습니다. 먼저 저장한 뒤 정리해 주세요.");
            var all = AssetDatabase.GetAllAssetPaths().Where(p => p.StartsWith("Assets/", StringComparison.Ordinal)).ToArray();
            var folders = all.Where(p => p.EndsWith("/" + GeneratedMenuName, StringComparison.Ordinal))
                .Select(p => p.Substring(0, p.LastIndexOf('/')))
                .Where(f => f.Substring(f.LastIndexOf('/') + 1).StartsWith(GeneratedFolderPrefix, StringComparison.Ordinal) &&
                    AssetDatabase.LoadMainAssetAtPath(f + "/" + GeneratedBaseName) is AnimatorController)
                .Distinct().ToArray();
            if (folders.Length == 0) return folders;
            string FolderHolding(string path) => folders.FirstOrDefault(f => path.StartsWith(f + "/", StringComparison.Ordinal));
            // Every file in Assets outside the decks' folders, whatever its type: a Timeline .playable that plays a deck's
            // pose copy keeps the deck as a scene does, and a scene that plays the .playable reaches it through that file.
            // Until 0.23.0 only scenes, prefabs, .asset, controllers, materials and clips counted, and what was used
            // through any other file type went to the trash with the deck. A kept folder costs disk space; a trashed one
            // can cost the deck.
            var owners = all.Where(p => FolderHolding(p) == null && !AssetDatabase.IsValidFolder(p)).ToArray();
            var used = new HashSet<string>(AssetDatabase.GetDependencies(owners, false).Select(FolderHolding).Where(f => f != null));
            // A folder still in use keeps the folders its own files refer to: a deck's menu can show an icon, and its Base
            // play a pose copy, taken from another deck's folder. Until 0.22.0 only references from outside were counted,
            // and such a folder went to the trash under the deck that used it.
            var reached = new Queue<string>(used);
            while (reached.Count > 0)
            {
                string folder = reached.Dequeue();
                var files = all.Where(p => p.StartsWith(folder + "/", StringComparison.Ordinal)).ToArray();
                foreach (string other in AssetDatabase.GetDependencies(files, false).Select(FolderHolding))
                    if (other != null && used.Add(other)) reached.Enqueue(other);
            }
            return folders.Where(f => !used.Contains(f)).ToArray();
        }

        // Writes a generated folder's own files and the deck's preset. AssetDatabase.SaveAssets would also write every
        // other unsaved asset in the project (a material being tried out, another tool's settings).
        internal static void SaveGenerated(string folder, PoseDeckPreset preset)
        {
            foreach (string file in Directory.GetFiles(folder, "*", SearchOption.AllDirectories))
                if (!file.EndsWith(".meta", StringComparison.OrdinalIgnoreCase))
                    AssetDatabase.SaveAssetIfDirty(AssetDatabase.GUIDFromAssetPath(file.Replace('\\', '/')));
            if (preset) AssetDatabase.SaveAssetIfDirty(preset);
        }

        // A copy of the controller as the user has it, and nothing of the project written but the copy (see
        // SaveGenerated). Saved, it is copied as a file; AssetDatabase.CopyAsset, used until 0.22.0, first writes every
        // unsaved asset of the project (seen in the tests: copying a clip wrote GoGoLoco's edited Base and Action). With
        // unsaved changes (GoGoLoco's Base or a modified Action being edited) it is copied from memory: 0.23.0 wrote the
        // original to disk first, the user's unsaved edit with it.
        private static AnimatorController CopyController(AnimatorController stock, string path)
        {
            string source = AssetDatabase.GetAssetPath(stock);
            var parts = AssetDatabase.LoadAllAssetsAtPath(source).Where(part => part).ToArray();
            if (parts.Any(EditorUtility.IsDirty)) return CopyFromMemory(stock, parts, path);
            string file = ClipPathOnDisk(source);
            if (file == null || !File.Exists(file)) throw new IOException("컨트롤러를 복제할 수 없습니다: " + source);
            File.Copy(file, path);
            AssetDatabase.ImportAsset(path, ImportAssetOptions.ForceSynchronousImport);
            return AssetDatabase.LoadAssetAtPath<AnimatorController>(path) ??
                throw new IOException("복제한 컨트롤러를 열 수 없습니다: " + path);
        }

        // Every object of the controller's file (states, transitions, trees, behaviours, …) cloned, the clones' references
        // to each other pointed at the clones, and the clones saved as a new file. The original is not touched, and stays
        // as unsaved as it was.
        private static AnimatorController CopyFromMemory(AnimatorController stock, Object[] parts, string path)
        {
            var clones = new Dictionary<Object, Object>();
            foreach (var part in parts)
            {
                var clone = Object.Instantiate(part);
                clone.name = part.name;
                clone.hideFlags = part.hideFlags;
                clones[part] = clone;
            }
            foreach (var clone in clones.Values)
            {
                // A clip's curves refer to nothing of the controller, and are too long to walk.
                if (clone is AnimationClip) continue;
                var serialized = new SerializedObject(clone);
                var property = serialized.GetIterator();
                bool changed = false;
                while (property.Next(true))
                    if (property.propertyType == SerializedPropertyType.ObjectReference && property.objectReferenceValue &&
                        clones.TryGetValue(property.objectReferenceValue, out var mapped))
                    {
                        property.objectReferenceValue = mapped;
                        changed = true;
                    }
                if (changed) serialized.ApplyModifiedPropertiesWithoutUndo();
            }
            var copy = (AnimatorController)clones[stock];
            AssetDatabase.CreateAsset(copy, path);
            foreach (var clone in clones.Values)
                if (clone != copy) AssetDatabase.AddObjectToAsset(clone, copy);
            AssetDatabase.SaveAssetIfDirty(copy);
            return copy;
        }

        private static Control Submenu(string name, VRCExpressionsMenu menu, Texture2D icon = null) =>
            new Control { name = name, type = Control.ControlType.SubMenu, subMenu = menu, icon = icon };

        private static Control CopyControl(Control source, string title) => new Control
        {
            name = title, type = source.type, icon = source.icon, value = source.value,
            parameter = new Control.Parameter { name = source.parameter?.name ?? "" },
            subParameters = source.subParameters?.Select(p => new Control.Parameter { name = p?.name ?? "" }).ToArray()
        };

        private static VRCExpressionsMenu MenuAsset(string folder, string name, IEnumerable<Control> controls)
        {
            var menu = ScriptableObject.CreateInstance<VRCExpressionsMenu>();
            menu.name = name;
            menu.controls = controls.ToList();
            if (menu.controls.Count > 8) throw new InvalidOperationException("메뉴당 8개 컨트롤을 초과했습니다.");
            AssetDatabase.CreateAsset(menu, $"{folder}/{name}.asset");
            return menu;
        }

        // `header` supplies fresh copies of the controls placed at the top of every page (reset and height, or none).
        private static VRCExpressionsMenu Pages(string folder, string key, List<Control> controls,
            Func<List<Control>> header, int page = 1)
        {
            var top = header();
            int room = VRCExpressionsMenu.MAX_CONTROLS - top.Count;
            if (controls.Count <= room) return MenuAsset(folder, $"{key}_{page}", top.Concat(controls));
            top.AddRange(controls.Take(room - 1));
            top.Add(Submenu("다음 페이지", Pages(folder, key, controls.Skip(room - 1).ToList(), header, page + 1)));
            return MenuAsset(folder, $"{key}_{page}", top);
        }

        private static VRCExpressionsMenu BuildMenu(PoseDeckPreset preset, string folder, VRCExpressionsMenu original,
            Control reset, Control height, Assignment[] rows, IReadOnlyDictionary<AnimationClip, Texture2D> icons)
        {
            List<Control> Controls() => new List<Control> { CopyControl(reset, "초기화"), CopyControl(height, "높이 조절") };
            Func<List<Control>> header = preset.controlsOnEveryPage ? Controls : (Func<List<Control>>)(() => new List<Control>());
            var root = Controls();
            foreach (var group in preset.poses.Select((p, i) => (p, i)).GroupBy(x => x.p.category).OrderBy(g => g.Key))
            {
                var controls = group.Select(x =>
                {
                    var control = rows[x.i].NativeControl != null
                        ? CopyControl(rows[x.i].NativeControl, Title(x.p))
                        : new Control
                        {
                            name = Title(x.p), type = Control.ControlType.Button,
                            parameter = new Control.Parameter { name = Emote }, value = rows[x.i].Number
                        };
                    bool keepNative = rows[x.i].NativeControl != null && preset.keepNativeIcons && control.icon;
                    if (x.p.icon) control.icon = x.p.icon;
                    else if (!keepNative && x.p.clip && icons.TryGetValue(x.p.clip, out var icon)) control.icon = icon;
                    return control;
                }).ToList();
                root.Add(Submenu(CategoryNames[(int)group.Key], Pages(folder, group.Key.ToString(), controls, header)));
            }
            var stockLink = original.controls.FirstOrDefault(c => c?.type == Control.ControlType.SubMenu && c.subMenu);
            if (preset.keepStockMenu && stockLink != null)
                root.Add(Submenu("기존 GoGoLoco", stockLink.subMenu, stockLink.icon));
            var inner = MenuAsset(folder, "PoseDeckMenu", root);
            return MenuAsset(folder, "PoseDeckInstaller", new[] { Submenu(preset.menuTitle.Trim(), inner, stockLink?.icon) });
        }

        // Links the Base and the menu, and the Action when one is given and the object has an Action merge.
        internal static void Wire(Target target, AnimatorController controller, VRCExpressionsMenu menu, AnimatorController action = null)
        {
            Undo.RecordObjects(new Object[] { target.Base, target.Menu }, "Change Personal Pose Deck");
            target.Base.animator = controller;
            target.Menu.menuToAppend = menu;
            PrefabUtility.RecordPrefabInstancePropertyModifications(target.Base);
            PrefabUtility.RecordPrefabInstancePropertyModifications(target.Menu);
            EditorUtility.SetDirty(target.Base);
            EditorUtility.SetDirty(target.Menu);
            if (target.Action && action) LinkAction(target.Action, action);
            EditorSceneManager.MarkSceneDirty(target.Base.gameObject.scene);
        }

        internal static string GenerateAndApply(PoseDeckPreset preset, GameObject go,
            IReadOnlyDictionary<AnimationClip, Texture2D> icons = null)
        {
            var target = ExistingTarget(go);
            var (stock, original, _, _) = Sources(preset, target);
            var stockAction = ActionSource(target);
            var (previousCopy, previousStock) = RecordedAction(FolderOf(target.Menu.menuToAppend));
            string previous = GeneratedFolderOf(target.Menu.menuToAppend);
            string previousAction = GeneratedFolderOf(target.Action ? target.Action.animator : null);
            var (folder, copy, wrapper, action) = GenerateAssets(preset, stock, original, icons, stockAction);
            Undo.IncrementCurrentGroup();
            int group = Undo.GetCurrentGroup();
            Undo.SetCurrentGroupName("Apply Personal Pose Deck");
            try
            {
                var marker = ScriptableObject.CreateInstance<PoseDeckExistingInstallation>();
                marker.preset = preset;
                marker.stockBase = stock;
                marker.stockMenu = original;
                marker.appliedBase = copy;
                marker.appliedMenu = wrapper;
                marker.stockAction = action ? stockAction : null;
                marker.appliedAction = action;
                marker.presetState = PresetState(preset);
                marker.deckId = Guid.NewGuid().ToString("N");
                AssetDatabase.CreateAsset(marker, folder + "/" + ExistingInstallationName);
                // Without a copy (no start heights in the Action), a previous deck's copy goes back to its original.
                Wire(target, copy, wrapper, action ? action : stockAction);
                // So does the previous copy on any other Action merge (disabled since, or one of several).
                RelinkActionCopy(go, previousCopy, previousStock, target.Action);
                SaveGenerated(folder, preset);
                Undo.CollapseUndoOperations(group);
                PoseDeckGeneratedCleanup.Remember(previous);
                PoseDeckGeneratedCleanup.Remember(previousAction);
                return folder;
            }
            catch
            {
                Undo.RevertAllDownToGroup(group);
                AssetDatabase.DeleteAsset(folder);
                throw;
            }
        }

        // `stockAction` is the Action the GoGoLoco object links (ActionSource). The returned Action is its copy carrying
        // the deck's start heights, or null when no start height goes there (then the object keeps `stockAction`).
        internal static (string folder, AnimatorController controller, VRCExpressionsMenu menu, AnimatorController action) GenerateAssets(
            PoseDeckPreset preset, AnimatorController stock, VRCExpressionsMenu original,
            IReadOnlyDictionary<AnimationClip, Texture2D> icons = null, AnimatorController stockAction = null)
        {
            var controls = Controls(original, new HashSet<VRCExpressionsMenu>()).ToArray();
            var (reset, height) = HeightControls(controls);
            if (reset == null || height == null) throw new InvalidOperationException("GoGoLoco 원본 메뉴에서 초기화 또는 높이 조절을 찾을 수 없습니다." +
                VendorVersionNote(AssetDatabase.GetAssetPath(original)));
            ValidateRows(preset);
            var plan = PlanRows(preset, stock, controls);
            if (plan.Rows.Any(row => row == null))
                throw new InvalidOperationException($"원본 높이를 유지하는 포즈를 제외하면 커스텀 슬롯은 {plan.CustomCapacity}개입니다. 포즈를 줄여 주세요.");
            string presetPath = AssetDatabase.GetAssetPath(preset);
            if (!presetPath.StartsWith("Assets/", StringComparison.Ordinal))
                throw new InvalidOperationException("프리셋을 프로젝트 Assets 폴더에 저장해 주세요.");
            string parent = Path.GetDirectoryName(presetPath).Replace('\\', '/');
            string requested = AssetDatabase.GenerateUniqueAssetPath(parent + "/" + GeneratedFolderPrefix);
            string guid = AssetDatabase.CreateFolder(parent, Path.GetFileName(requested));
            string folder = AssetDatabase.GUIDToAssetPath(guid);
            if (string.IsNullOrEmpty(folder)) throw new IOException("생성 결과 폴더를 만들 수 없습니다.");
            AnimatorController copy, action = null;
            VRCExpressionsMenu wrapper;
            try
            {
                copy = CopyController(stock, folder + "/" + GeneratedBaseName);
                var slots = FindSlots(copy).ToDictionary(slot => slot.Number);
                var reference = AdditiveReference(slots.Values.SelectMany(s => s.Clips));
                var poses = new Dictionary<(AnimationClip, bool), AnimationClip>();
                // Custom clips go in as copies with GoGoLoco's reference pose, saved next to the generated Base. A held
                // pose (ApplyHeld) with a zero-length clip plays a one-frame copy: its hold loop counts plays of
                // the motion, and a zero-length motion never finishes one.
                AnimationClip PoseClip(AnimationClip clip, bool held)
                {
                    bool frame = held && clip.length <= 0f;
                    bool needsReference = NeedsReference(clip, reference);
                    if (!frame && !needsReference) return clip;
                    if (poses.TryGetValue((clip, frame), out var made)) return made;
                    if (!AssetDatabase.IsValidFolder(folder + "/Poses")) AssetDatabase.CreateFolder(folder, "Poses");
                    made = needsReference ? WithReference(clip, reference) : Object.Instantiate(clip);
                    made.name = clip.name;
                    if (frame) OneFrame(made);
                    AssetDatabase.CreateAsset(made, AssetDatabase.GenerateUniqueAssetPath($"{folder}/Poses/{SafeFileName(clip.name)}.anim"));
                    return poses[(clip, frame)] = made;
                }
                var replaced = new List<BlendTree>();
                for (int i = 0; i < preset.poses.Count; i++)
                {
                    if (plan.Rows[i].NativeControl != null) continue;
                    var slot = slots[plan.Rows[i].Number];
                    var tree = CloneTree(slot.Tree, PoseClip(preset.poses[i].clip, Held(preset.poses[i]) != HeldParts.None), copy,
                        new Dictionary<BlendTree, BlendTree>());
                    foreach (var state in slot.States) { state.motion = tree; EditorUtility.SetDirty(state); }
                    replaced.Add(slot.Tree);
                }
                var heights = StartHeights(preset, plan.Rows);
                if (stockAction && heights.Keys.Any(FloatDriverSlots(stockAction).ContainsKey))
                {
                    action = CopyController(stockAction, folder + "/" + GeneratedActionName);
                    foreach (int number in PatchAction(action, heights)) heights.Remove(number);
                }
                if (stockAction && heights.Count != 0)
                    Debug.LogWarning($"[Personal Pose Deck] ‘{stockAction.name}’에서 슬롯 {string.Join(", ", heights.Keys.OrderBy(n => n))}의 " +
                        "시작 높이 설정을 찾지 못해, 이 슬롯은 버튼을 뗀 뒤 높이를 맞춥니다.");
                ApplyStartHeights(copy, slots, heights);
                ApplyHeld(copy, slots, preset, plan.Rows);
                RemoveUnusedTrees(copy, replaced);
                EditorUtility.SetDirty(copy);
                wrapper = BuildMenu(preset, folder, original, reset, height, plan.Rows, SaveIcons(folder, preset, icons));
                SaveGenerated(folder, preset);
            }
            catch
            {
                AssetDatabase.DeleteAsset(folder);
                throw;
            }
            return (folder, copy, wrapper, action);
        }

        // Takes an array on purpose: it is searched twice, which a lazy Controls() sequence does not survive.
        private static (Control reset, Control height) HeightControls(Control[] controls) =>
            (controls.FirstOrDefault(c => c.type == Control.ControlType.Button && c.parameter?.name == Emote && c.value == 255),
             controls.FirstOrDefault(c => c.type == Control.ControlType.RadialPuppet &&
                 c.parameter?.name == Emote && c.value == 125 && c.subParameters?.FirstOrDefault()?.name == Float));

        internal static bool SupportsSource(AnimatorController controller, VRCExpressionsMenu menu)
        {
            // Materialize first: Controls() shares one visited set, so a second pass over the lazy sequence is empty.
            var (reset, height) = HeightControls(Controls(menu, new HashSet<VRCExpressionsMenu>()).ToArray());
            if (reset == null || height == null) return false;
            try { return FindSlots(controller).Count != 0; }
            catch (InvalidOperationException) { return false; }
        }

        // The preset whose generated result is wired to this GoGoLoco object ("기존 GoGoLoco에 적용"), or null.
        internal static PoseDeckPreset InstalledPreset(GameObject go)
        {
            if (!go) return null;
            try
            {
                var target = GetBindings(go);
                if (PoseDeckAvatarInstall.IsAvatarInstallation(go, target)) return null;
                return Sources(null, target).installedPreset;
            }
            catch (InvalidOperationException) { return null; }
        }

        private static Target ExistingTarget(GameObject go)
        {
            var target = GetTarget(go);
            if (PoseDeckAvatarInstall.IsAvatarInstallation(go, target))
                throw new InvalidOperationException("아바타에 새로 붙인 덱입니다. ‘아바타에 새로 적용’에서 갱신하거나 제거해 주세요.");
            return target;
        }

        internal static void Restore(PoseDeckPreset preset, GameObject go)
        {
            var target = ExistingTarget(go);
            if (!IsGenerated(target.Base.animator as AnimatorController, target.Menu.menuToAppend))
                throw new InvalidOperationException("이 GoGoLoco 오브젝트에 연결된 Pose Deck 생성본이 없습니다.");
            var (stock, original, _, _) = Sources(preset, target);
            var (applied, stockAction) = RecordedAction(FolderOf(target.Menu.menuToAppend));
            Wire(target, stock, original);
            // Only this installation's Action copy goes back, on any Action merge of the object, enabled or not.
            RelinkActionCopy(go, applied, stockAction);
        }
    }

    // A generated folder replaced by re-applying a deck. It is moved to the trash (recoverable) when nothing in the
    // project refers to it any more, but not before Unity is started the next time: until then one Undo links the avatar
    // to it again, and 0.22.0, which cleaned up as soon as the scene was saved, left such an Undo with links to files
    // in the trash. Restoring and removing leave folders for the manual cleanup.
    [InitializeOnLoad]
    internal static class PoseDeckGeneratedCleanup
    {
        // EditorPrefs are shared by every project on this PC; the candidates and the log belong to this one.
        private static string Candidates => "PersonalPoseDeck.ReplacedFolders." + Application.dataPath;
        private static string TrashLog => "PersonalPoseDeck.TrashedFolders." + Application.dataPath;
        // Set for as long as this run of the editor lasts, as its Undo history does.
        internal const string SessionStarted = "PersonalPoseDeck.CleanupSessionStarted";

        // The last folders the cleanup moved to the trash, newest first, as "MM-dd HH:mm  path".
        internal static string[] Trashed => EditorPrefs.GetString(TrashLog, "")
            .Split(new[] { '\n' }, StringSplitOptions.RemoveEmptyEntries);

        // Moves a folder to the trash; tests swap in a permanent delete so runs do not fill the system trash.
        internal static Func<string, bool> Trash = AssetDatabase.MoveAssetToTrash;
        private const string Preference = "PersonalPoseDeck.AutoCleanReplaced";

        static PoseDeckGeneratedCleanup() => EditorApplication.delayCall += () => OnEditorLoaded();

        // Cleans up once per run of the editor, the first time its scripts are loaded: what earlier runs replaced.
        // Returns the folders moved to the trash.
        internal static string[] OnEditorLoaded()
        {
            if (SessionState.GetBool(SessionStarted, false)) return Array.Empty<string>();
            SessionState.SetBool(SessionStarted, true);
            return Remembered.Count == 0 ? Array.Empty<string>() : Clean();
        }

        internal static bool Enabled
        {
            get => EditorPrefs.GetBool(Preference, true);
            set => EditorPrefs.SetBool(Preference, value);
        }

        // The replaced folders as "path|deck id" (PoseDeckBuilder.DeckId): a folder at that path is the one that was
        // replaced only while the installation in it still has that id. 0.23.0 kept paths alone, so a deck made later
        // at the same path (after the old folder was deleted by hand) went to the trash although it had never been
        // replaced. A random id made with the deck cannot come back with another folder. Folders without an id (made
        // before it was recorded) and 0.23.0's entries are kept.
        private static List<string> Remembered => EditorPrefs.GetString(Candidates, "")
            .Split(new[] { '\n' }, StringSplitOptions.RemoveEmptyEntries).ToList();

        // The replaced folders that are still there as the same deck.
        internal static List<string> Pending => Remembered.Select(entry => entry.Split('|'))
            .Where(parts => parts.Length == 2 && PoseDeckBuilder.DeckId(parts[0]) == parts[1]).Select(parts => parts[0]).ToList();

        internal static void Remember(string folder)
        {
            string id = Enabled ? PoseDeckBuilder.DeckId(folder) : null;
            if (id == null) return;
            var list = Remembered;
            string entry = folder + "|" + id;
            if (!list.Contains(entry)) list.Add(entry);
            EditorPrefs.SetString(Candidates, string.Join("\n", list));
        }

        // Returns the folders moved to the trash.
        internal static string[] Clean()
        {
            var list = Pending;
            if (list.Count == 0 || !Enabled)
            {
                EditorPrefs.DeleteKey(Candidates);
                return Array.Empty<string>();
            }
            string[] unused;
            try { unused = PoseDeckBuilder.FindUnusedGeneratedFolders(); }
            catch (InvalidOperationException) { return Array.Empty<string>(); } // unsaved scenes: wait for the next start
            var moved = list.Where(unused.Contains).Where(f => Trash(f)).ToArray();
            foreach (var folder in moved)
                Debug.Log("[Personal Pose Deck] 다시 적용해 쓰지 않게 된 생성본을 휴지통으로 옮겼습니다: " + folder);
            if (moved.Length != 0)
            {
                string stamp = DateTime.Now.ToString("MM-dd HH:mm");
                var log = moved.Select(f => stamp + "  " + f).Concat(Trashed).Take(5);
                EditorPrefs.SetString(TrashLog, string.Join("\n", log));
            }
            // Folders something still refers to (a prefab, another scene) are left alone and no longer tracked.
            EditorPrefs.DeleteKey(Candidates);
            return moved;
        }
    }
}
