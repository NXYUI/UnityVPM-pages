using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEditor.Animations;
using UnityEngine;
using UnityEngine.Animations;
using UnityEngine.Playables;
using UnityEngine.Rendering;
using UnityEngine.SceneManagement;
using VRC.SDK3.Avatars.Components;
using VRC.SDKBase;
using Object = UnityEngine.Object;

namespace PersonalPoseDeck
{
    // Copies the rig and renderers only. No scene behaviours are instantiated; the only controller ever run is
    // GoGoLoco's own Base, for the start-height preview.
    internal sealed class PoseDeckPosePreview : IDisposable
    {
        // GoGoLoco enters a pose through VRChat parameter drivers (Go/Pose, Go/Float, …). The editor does not run them,
        // so apply them here for preview rigs only, the way Gesture Manager emulates them.
        private static readonly HashSet<Animator> Simulated = new HashSet<Animator>();
        private static bool driverHooked;

        private static void ApplyDriver(VRC_AvatarParameterDriver driver, Animator target)
        {
            if (!target || !Simulated.Contains(target)) return;
            foreach (var p in driver.parameters)
            {
                if (p.type != VRC_AvatarParameterDriver.ChangeType.Set && p.type != VRC_AvatarParameterDriver.ChangeType.Add) continue;
                var param = target.parameters.FirstOrDefault(x => x.name == p.name);
                if (param == null) continue;
                float current = param.type == AnimatorControllerParameterType.Float ? target.GetFloat(p.name) :
                    param.type == AnimatorControllerParameterType.Int ? target.GetInteger(p.name) : target.GetBool(p.name) ? 1f : 0f;
                float value = p.type == VRC_AvatarParameterDriver.ChangeType.Add ? current + p.value : p.value;
                if (param.type == AnimatorControllerParameterType.Float) target.SetFloat(p.name, value);
                else if (param.type == AnimatorControllerParameterType.Int) target.SetInteger(p.name, Mathf.RoundToInt(value));
                else target.SetBool(p.name, value != 0f);
            }
        }

        private PoseDeckBuilder.PreviewSource gogo;
        private AnimatorOverrideController gogoOverride;
        private int gogoSlot, gogoLayer = -1, gogoState;
        private float startHeight = PoseDeckBuilder.DefaultStartHeight, eyeHeight = 1.3f;
        private bool gogoDirty, gogoReady;
        private string gogoProblem;
        private readonly PreviewRenderUtility preview;
        private readonly Dictionary<Transform, Transform> rig = new Dictionary<Transform, Transform>();
        private readonly List<Renderer> renderers = new List<Renderer>();
        private readonly List<(Transform bone, Vector3 position, Quaternion rotation, Vector3 scale)> rest =
            new List<(Transform, Vector3, Quaternion, Vector3)>();
        private Animator animator;
        private Transform previewRoot;
        private readonly PoseDeckPreviewConstraints constraints;
        private PlayableGraph graph;
        private AnimationClipPlayable playable;
        private AnimationClip clip;
        private Bounds frame;
        private float yaw = 45f, pitch = -25f, zoom = .90f;
        private bool freeLook, freeMouseHeld, panMouseHeld;
        private Vector3 orbitPan;
        private Vector3 freePosition;
        private float freeYaw, freePitch, freeFov;
        private double lastCameraTick;
        private readonly HashSet<KeyCode> movementKeys = new HashSet<KeyCode>();
        // Mirroring goes through a one-state, in-memory controller so Unity mirrors the pose exactly as GoGoLoco's
        // "Right" states (AnimatorState.mirror) do in game.
        private static readonly int MirrorStateHash = Animator.StringToHash("Pose");
        private AnimatorController mirrorController;
        private AnimatorControllerPlayable controllerPlayable;
        private bool mirror;
        private GameObject floor;
        private Mesh floorMesh;
        private Material floorMaterial;

        internal bool HasHumanoidAvatar => animator && animator.avatar && animator.avatar.isValid && animator.avatar.isHuman;
        internal bool HasRenderers => renderers.Count != 0;
        // Lowest point of the meshes above the avatar root (the floor). Exact when ExactMeasure is on, otherwise from
        // the skinned bounds after the last draw.
        internal float? LowestPoint { get; private set; }
        internal bool ExactMeasure { get; set; } = true;

        // True while the pose is shown as GoGoLoco places it in game for StartHeight (VR, 3-point tracking).
        internal bool SimulatingGoGoLoco => gogo != null && clip && clip.humanMotion && HasHumanoidAvatar;
        internal bool GoGoLocoReady => SimulatingGoGoLoco && gogoReady;
        internal string GoGoLocoProblem => gogoProblem;

        internal enum Tracking { VR, Desktop, FullBody }

        // VRChat's TrackingType / VRMode for the simulated user. GoGoLoco picks its desktop or VR pose variant from them.
        internal Tracking Mode
        {
            get => mode;
            set { if (mode != value) { mode = value; gogoDirty = true; } }
        }
        private Tracking mode = Tracking.VR;

        internal float StartHeight
        {
            get => startHeight;
            set
            {
                value = Mathf.Clamp01(value);
                if (Mathf.Approximately(startHeight, value)) return;
                startHeight = value;
                gogoDirty = true;
            }
        }

        // null turns the GoGoLoco preview off and shows the clip on its own again.
        internal void UseGoGoLoco(PoseDeckBuilder.PreviewSource source)
        {
            if (gogo == source) return;
            gogo = source;
            animator.runtimeAnimatorController = null;
            if (gogoOverride) { Object.DestroyImmediate(gogoOverride); gogoOverride = null; }
            var current = clip;
            clip = null;
            SetClip(current);
        }

        internal bool ShowFloor
        {
            get => floor && floor.activeSelf;
            set { if (floor) floor.SetActive(value); }
        }

        internal bool Mirror
        {
            get => mirror;
            set
            {
                if (mirror == value) return;
                mirror = value;
                var current = clip;
                clip = null;
                SetClip(current);
            }
        }

        internal PoseDeckPosePreview(GameObject avatar)
        {
            preview = new PreviewRenderUtility();
            try
            {
                Transform root = MakeNode(avatar.transform, null, true);
                previewRoot = root;
                CopyRenderers(avatar.transform, true);
                animator = root.gameObject.AddComponent<Animator>();
                var original = avatar.GetComponent<Animator>();
                if (original) animator.avatar = original.avatar;
                animator.applyRootMotion = false;
                animator.fireEvents = false;
                animator.cullingMode = AnimatorCullingMode.AlwaysAnimate;
                animator.Rebind();
                // VRChat reports the view height as EyeHeightAsMeters; GoGoLoco scales its upper height range with it.
                var descriptor = avatar.GetComponent<VRCAvatarDescriptor>();
                var head = HasHumanoidAvatar ? animator.GetBoneTransform(HumanBodyBones.Head) : null;
                eyeHeight = descriptor ? descriptor.ViewPosition.y * avatar.transform.lossyScale.y :
                    head ? (head.position.y - root.position.y) * 1.06f : eyeHeight;
                foreach (var bone in rig.Values) rest.Add((bone, bone.localPosition, bone.localRotation, bone.localScale));
                constraints = new PoseDeckPreviewConstraints(avatar, Map);
                constraints.Apply();
                preview.camera.clearFlags = CameraClearFlags.Color;
                preview.camera.backgroundColor = new Color(.24f, .26f, .29f, 1f);
                preview.camera.orthographic = true;
                preview.ambientColor = new Color(.65f, .65f, .65f, 1f);
                preview.lights[0].intensity = 1.55f;
                preview.lights[0].transform.rotation = Quaternion.Euler(34f, -151f, 0f);
                preview.lights[1].intensity = 1.10f;
                preview.lights[1].transform.rotation = Quaternion.Euler(17f, 143f, 0f);
                Fit();
                CreateFloor(Mathf.Max(1.5f, frame.size.y * 1.6f));
            }
            catch
            {
                Dispose();
                throw;
            }
        }

        private Transform MakeNode(Transform source, Transform parent, bool isRoot)
        {
            var obj = EditorUtility.CreateGameObjectWithHideFlags(source.name, HideFlags.HideAndDontSave);
            obj.layer = source.gameObject.layer;
            var node = obj.transform;
            if (isRoot)
            {
                preview.AddSingleGO(obj);
                node.localScale = source.lossyScale;
            }
            else
            {
                SceneManager.MoveGameObjectToScene(obj, parent.gameObject.scene);
                node.SetParent(parent, false);
                node.localPosition = source.localPosition;
                node.localRotation = source.localRotation;
                node.localScale = source.localScale;
                obj.SetActive(source.gameObject.activeSelf);
            }
            rig.Add(source, node);
            foreach (Transform child in source) MakeNode(child, node, false);
            return node;
        }

        private Transform Map(Transform source) => source && rig.TryGetValue(source, out var node) ? node : null;

        // A line grid on the avatar's floor (y = 0 under the root), so floating or sinking poses are visible.
        private void CreateFloor(float size)
        {
            var shader = Shader.Find("Hidden/Internal-Colored");
            if (!shader) return;
            floorMaterial = new Material(shader) { hideFlags = HideFlags.HideAndDontSave };
            floorMaterial.SetInt("_SrcBlend", (int)BlendMode.SrcAlpha);
            floorMaterial.SetInt("_DstBlend", (int)BlendMode.OneMinusSrcAlpha);
            floorMaterial.SetInt("_Cull", (int)CullMode.Off);
            floorMaterial.SetInt("_ZWrite", 1);
            var vertices = new List<Vector3>();
            var colors = new List<Color>();
            const int lines = 10;
            float half = size * .5f, step = size / lines;
            for (int i = 0; i <= lines; i++)
            {
                float o = -half + i * step;
                var color = i == lines / 2 ? new Color(.66f, .70f, .76f, .95f) : new Color(.46f, .49f, .55f, .55f);
                vertices.AddRange(new[] { new Vector3(o, 0, -half), new Vector3(o, 0, half), new Vector3(-half, 0, o), new Vector3(half, 0, o) });
                colors.AddRange(new[] { color, color, color, color });
            }
            int lineCount = vertices.Count;
            // A faint surface just under the lines: parts of the pose below the floor show through it dimmed.
            var fill = new Color(.42f, .47f, .55f, .28f);
            vertices.AddRange(new[] { new Vector3(-half, -.001f, -half), new Vector3(-half, -.001f, half),
                new Vector3(half, -.001f, half), new Vector3(half, -.001f, -half) });
            colors.AddRange(new[] { fill, fill, fill, fill });
            floorMesh = new Mesh { name = "Pose Deck floor", hideFlags = HideFlags.HideAndDontSave, subMeshCount = 2 };
            floorMesh.SetVertices(vertices);
            floorMesh.SetColors(colors);
            floorMesh.SetIndices(Enumerable.Range(0, lineCount).ToArray(), MeshTopology.Lines, 0);
            floorMesh.SetIndices(new[] { lineCount, lineCount + 1, lineCount + 2, lineCount, lineCount + 2, lineCount + 3 },
                MeshTopology.Triangles, 1);
            floorMaterial.renderQueue = (int)RenderQueue.Transparent;
            floor = EditorUtility.CreateGameObjectWithHideFlags("Pose Deck floor", HideFlags.HideAndDontSave,
                typeof(MeshFilter), typeof(MeshRenderer));
            floor.GetComponent<MeshFilter>().sharedMesh = floorMesh;
            var meshRenderer = floor.GetComponent<MeshRenderer>();
            meshRenderer.sharedMaterials = new[] { floorMaterial, floorMaterial };
            meshRenderer.shadowCastingMode = ShadowCastingMode.Off;
            meshRenderer.receiveShadows = false;
            preview.AddSingleGO(floor);
        }

        // Key light from the given position, fill light opposite it, ambient as a grey of the given strength.
        internal void ApplyLighting(PoseDeckPreviewLighting lighting)
        {
            if (lighting == null) return;
            var key = preview.lights[0];
            var towards = lighting.TowardsLight;
            key.transform.rotation = Quaternion.LookRotation(-towards, Vector3.up);
            key.intensity = lighting.intensity;
            key.color = lighting.LightColor;
            var fillLight = preview.lights[1];
            var opposite = new Vector3(-towards.x, Mathf.Max(.25f, towards.y * .5f), -towards.z).normalized;
            fillLight.transform.rotation = Quaternion.LookRotation(-opposite, Vector3.up);
            fillLight.intensity = lighting.fill;
            fillLight.color = Color.Lerp(Color.white, lighting.LightColor, .35f);
            preview.ambientColor = new Color(lighting.ambient, lighting.ambient, lighting.ambient, 1f);
        }

        internal float KeyIntensity => preview.lights[0].intensity;
        internal Vector3 KeyForward => preview.lights[0].transform.forward;

        // Material values from a lighting package (Light Limit Changer), set through property blocks so the materials
        // themselves are untouched. "_Name.x" style targets set one component of a vector property.
        internal int ApplyMaterialControls(IReadOnlyList<PoseDeckMaterialControl> controls, PoseDeckLightFilter filter = null)
        {
            int applied = 0;
            var block = new MaterialPropertyBlock();
            var vectors = new Dictionary<string, Vector4>();
            foreach (var r in renderers)
            {
                if (!r) continue;
                bool excluded = filter != null && filter.ExcludedPaths.Contains(AnimationUtility.CalculateTransformPath(r.transform, previewRoot));
                var materials = r.sharedMaterials;
                for (int i = 0; i < materials.Length; i++)
                {
                    block.Clear();
                    vectors.Clear();
                    var material = materials[i];
                    string key = material ? PoseDeckLightPackages.ShaderKey(material.shader) : null;
                    bool any = false;
                    if (key != null && controls != null && !excluded && (filter == null || filter.Allows(key, material)))
                        foreach (var control in controls)
                            foreach (var (shader, names) in control.Targets)
                            {
                                if (shader != key) continue;
                                foreach (var target in names)
                                {
                                    int dot = target.LastIndexOf('.');
                                    string property = dot > 0 ? target.Substring(0, dot) : target;
                                    int component = dot > 0 ? "xyzw".IndexOf(target[dot + 1]) : -1;
                                    if (!material.HasProperty(property)) continue;
                                    int index = material.shader.FindPropertyIndex(property);
                                    var type = index >= 0 ? material.shader.GetPropertyType(index) : ShaderPropertyType.Float;
                                    if (component >= 0 && type == ShaderPropertyType.Vector)
                                    {
                                        if (!vectors.TryGetValue(property, out var v)) v = material.GetVector(property);
                                        v[component] = control.Value;
                                        vectors[property] = v;
                                    }
                                    else if (component < 0 && (type == ShaderPropertyType.Float || type == ShaderPropertyType.Range))
                                        block.SetFloat(property, control.Value);
                                    else if (component < 0 && type == ShaderPropertyType.Int)
                                        block.SetInteger(property, Mathf.RoundToInt(control.Value));
                                    else continue;
                                    any = true;
                                }
                            }
                    foreach (var pair in vectors) block.SetVector(pair.Key, pair.Value);
                    r.SetPropertyBlock(block, i);
                    if (any) applied++;
                }
            }
            return applied;
        }

        internal void SetView(float viewYaw, float viewPitch)
        {
            yaw = viewYaw;
            pitch = Mathf.Clamp(viewPitch, -85f, 85f);
            orbitPan = Vector3.zero;
            freeLook = false;
            StopCameraDrag();
        }

        private void CopyRenderers(Transform source, bool visible)
        {
            var node = rig[source];
            foreach (var original in source.GetComponents<Light>())
            {
                var light = node.gameObject.AddComponent<Light>();
                EditorUtility.CopySerialized(original, light);
            }
            if (visible)
            {
                foreach (var old in source.GetComponents<SkinnedMeshRenderer>())
                {
                    if (!old.enabled || !old.sharedMesh) continue;
                    var oldBones = old.bones;
                    if (oldBones.Any(b => b && !rig.ContainsKey(b))) continue;
                    var copy = node.gameObject.AddComponent<SkinnedMeshRenderer>();
                    copy.sharedMesh = old.sharedMesh;
                    copy.sharedMaterials = old.sharedMaterials;
                    copy.bones = oldBones.Select(Map).ToArray();
                    copy.rootBone = Map(old.rootBone);
                    copy.localBounds = old.localBounds;
                    copy.updateWhenOffscreen = true;
                    copy.quality = old.quality;
                    for (int i = 0; i < old.sharedMesh.blendShapeCount; i++) copy.SetBlendShapeWeight(i, old.GetBlendShapeWeight(i));
                    renderers.Add(copy);
                }
                var oldFilter = source.GetComponent<MeshFilter>();
                var oldMesh = source.GetComponent<MeshRenderer>();
                if (oldFilter && oldFilter.sharedMesh && oldMesh && oldMesh.enabled)
                {
                    node.gameObject.AddComponent<MeshFilter>().sharedMesh = oldFilter.sharedMesh;
                    var copy = node.gameObject.AddComponent<MeshRenderer>();
                    copy.sharedMaterials = oldMesh.sharedMaterials;
                    renderers.Add(copy);
                }
            }
            foreach (Transform child in source) CopyRenderers(child, visible && child.gameObject.activeSelf);
        }

        internal void SetClip(AnimationClip value)
        {
            if (clip == value) return;
            if (graph.IsValid()) graph.Destroy();
            DestroyMirrorController();
            clip = value;
            animator.runtimeAnimatorController = null;
            Simulated.Remove(animator);
            gogoReady = false;
            gogoProblem = null;
            animator.Rebind();
            foreach (var (bone, pos, rot, scale) in rest)
            {
                bone.localPosition = pos;
                bone.localRotation = rot;
                bone.localScale = scale;
            }
            if (!clip || clip.legacy || (clip.humanMotion && !HasHumanoidAvatar)) return;
            if (SimulatingGoGoLoco)
            {
                // A stock pose plays its own slot; any other clip plays in an empty slot through an override.
                int native = gogo.SlotFor(clip);
                gogoSlot = native >= 0 ? native : gogo.BlankSlot;
                RuntimeAnimatorController controller = gogo.Base;
                if (gogoSlot == gogo.BlankSlot)
                {
                    if (!gogoOverride)
                        gogoOverride = new AnimatorOverrideController(gogo.Base)
                            { name = "Pose Deck GoGoLoco preview", hideFlags = HideFlags.HideAndDontSave };
                    foreach (var blank in gogo.BlankClips) gogoOverride[blank] = clip;
                    controller = gogoOverride;
                }
                animator.runtimeAnimatorController = controller;
                Simulated.Add(animator);
                if (!driverHooked)
                {
                    VRC_AvatarParameterDriver.OnApplySettings += ApplyDriver;
                    driverHooked = true;
                }
                gogoDirty = true;
                return;
            }
            graph = PlayableGraph.Create("Pose Deck preview");
            graph.SetTimeUpdateMode(DirectorUpdateMode.Manual);
            var output = AnimationPlayableOutput.Create(graph, "Pose Deck pose", animator);
            if (mirror)
            {
                mirrorController = new AnimatorController { name = "Pose Deck mirror", hideFlags = HideFlags.HideAndDontSave };
                mirrorController.AddLayer("Pose");
                var state = mirrorController.layers[0].stateMachine.AddState("Pose");
                state.motion = clip;
                state.mirror = true;
                state.iKOnFeet = false;
                state.writeDefaultValues = true;
                state.speed = 0f;
                controllerPlayable = AnimatorControllerPlayable.Create(graph, mirrorController);
                output.SetSourcePlayable(controllerPlayable);
            }
            else
            {
                playable = AnimationClipPlayable.Create(graph, clip);
                playable.SetApplyFootIK(false);
                playable.SetApplyPlayableIK(false);
                playable.SetSpeed(0);
                output.SetSourcePlayable(playable);
            }
            graph.Play();
        }

        private void DestroyMirrorController()
        {
            if (!mirrorController) return;
            var machine = mirrorController.layers.Length > 0 ? mirrorController.layers[0].stateMachine : null;
            if (machine)
            {
                foreach (var child in machine.states) if (child.state) Object.DestroyImmediate(child.state);
                Object.DestroyImmediate(machine);
            }
            Object.DestroyImmediate(mirrorController);
            mirrorController = null;
        }

        internal void Sample(float time)
        {
            constraints.ResetTargets();
            if (SimulatingGoGoLoco)
            {
                if (gogoDirty) SettleGoGoLoco();
                if (gogoReady)
                {
                    var t = Mathf.Clamp(time, 0, Mathf.Max(0, clip.length));
                    animator.Play(gogoState, gogoLayer, clip.length > 0 ? t / clip.length : 0f);
                    animator.Update(0f);
                }
            }
            else if (graph.IsValid())
            {
                var t = Mathf.Clamp(time, 0, Mathf.Max(0, clip.length));
                if (mirror && controllerPlayable.IsValid())
                    controllerPlayable.Play(MirrorStateHash, 0, clip.length > 0 ? t / clip.length : 0f);
                else
                    playable.SetTime(t);
                graph.Evaluate(0f);
            }
            constraints.Apply();
            if (ExactMeasure) LowestPoint = MeshLowest();
        }

        private void Step(float seconds)
        {
            for (float t = 0f; t < seconds; t += 1f / 60f) animator.Update(1f / 60f);
        }

        // Press the pose button and let go, as in game, then let GoGoLoco's smoothing settle.
        private void SettleGoGoLoco()
        {
            gogoDirty = false;
            gogoReady = false;
            gogoProblem = null;
            animator.Rebind();
            var types = animator.parameters.ToDictionary(p => p.name, p => p.type);
            void Set(string name, float value)
            {
                if (!types.TryGetValue(name, out var type)) return;
                if (type == AnimatorControllerParameterType.Float) animator.SetFloat(name, value);
                else if (type == AnimatorControllerParameterType.Int) animator.SetInteger(name, Mathf.RoundToInt(value));
                else if (type == AnimatorControllerParameterType.Bool) animator.SetBool(name, value != 0f);
            }
            bool vr = mode != Tracking.Desktop;
            Set("IsLocal", 1); Set("TrackingType", mode == Tracking.FullBody ? 6 : 3);
            Set("VRMode", vr ? 1 : 0); Set("VRModeProxy", vr ? 1 : 0); Set("Upright", 1);
            Set("Grounded", 1); Set("AvatarVersion", 3); Set("EyeHeightAsMeters", eyeHeight); Set("Go/Weight", 1);
            Set("Go/Mirror", mirror ? 1 : 0);
            Set("Go/Float", startHeight);
            Step(.6f);
            Set("VRCEmote", gogoSlot);
            Step(.15f);
            Set("Go/Float", startHeight); // GoGoLoco's Action layer writes the start height on the press
            Set("VRCEmote", 0);
            Step(1.2f);
            gogoLayer = Enumerable.Range(0, animator.layerCount).FirstOrDefault(i => animator.GetLayerName(i) == "Poses");
            var info = animator.GetCurrentAnimatorStateInfo(gogoLayer);
            if (animator.GetLayerName(gogoLayer) != "Poses" || !(info.IsName("Left") || info.IsName("Right")))
            {
                gogoProblem = "GoGoLoco 포즈 상태에 들어가지 못해 클립만 표시합니다.";
                return;
            }
            gogoState = info.fullPathHash;
            gogoReady = true;
        }

        private Mesh measureMesh;
        private readonly List<Vector3> measureVertices = new List<Vector3>();

        // Lowest vertex of the visible meshes above the floor, from the current pose.
        private float? MeshLowest()
        {
            if (renderers.Count == 0) return null;
            float min = float.PositiveInfinity;
            foreach (var r in renderers)
            {
                if (!r || !r.enabled || !r.gameObject.activeInHierarchy) continue;
                try
                {
                    Matrix4x4 toWorld;
                    if (r is SkinnedMeshRenderer skinned)
                    {
                        if (!measureMesh) measureMesh = new Mesh { name = "Pose Deck measure", hideFlags = HideFlags.HideAndDontSave };
                        skinned.BakeMesh(measureMesh, true);
                        measureMesh.GetVertices(measureVertices);
                        toWorld = Matrix4x4.TRS(skinned.transform.position, skinned.transform.rotation, Vector3.one);
                    }
                    else if (r.TryGetComponent<MeshFilter>(out var filter) && filter.sharedMesh && filter.sharedMesh.isReadable)
                    {
                        filter.sharedMesh.GetVertices(measureVertices);
                        toWorld = r.transform.localToWorldMatrix;
                    }
                    else { min = Mathf.Min(min, r.bounds.min.y); continue; }
                    foreach (var v in measureVertices) min = Mathf.Min(min, toWorld.MultiplyPoint3x4(v).y);
                }
                catch (Exception) { min = Mathf.Min(min, r.bounds.min.y); }
            }
            return float.IsPositiveInfinity(min) ? (float?)null : min - previewRoot.position.y;
        }

        // The start height at which the pose's lowest mesh point rests on the floor (within 3 mm), searched with the
        // GoGoLoco preview. Null when the preview is not running GoGoLoco.
        internal float? FitStartHeight(float time)
        {
            if (!SimulatingGoGoLoco) return null;
            bool exact = ExactMeasure;
            ExactMeasure = true;
            try
            {
                float height = startHeight;
                for (int i = 0; i < 6; i++)
                {
                    StartHeight = height;
                    Sample(time);
                    if (!gogoReady || LowestPoint == null) return null;
                    float low = LowestPoint.Value;
                    if (Mathf.Abs(low) < .003f) break;
                    float step = height < .97f ? .02f : -.02f;
                    StartHeight = height + step;
                    Sample(time);
                    if (!gogoReady || LowestPoint == null) return null;
                    float slope = (LowestPoint.Value - low) / step;
                    if (slope < .05f) break; // the pose does not move with Go/Float here
                    height = Mathf.Clamp01(height - low / slope);
                }
                StartHeight = height;
                Sample(time);
                return gogoReady ? height : (float?)null;
            }
            finally { ExactMeasure = exact; }
        }

        internal void Fit()
        {
            if (renderers.Count > 0)
            {
                frame = renderers[0].bounds;
                for (int i = 1; i < renderers.Count; i++) frame.Encapsulate(renderers[i].bounds);
            }
            else frame = new Bounds(Vector3.up * .8f, new Vector3(.8f, 1.6f, .5f));
            zoom = .90f;
            orbitPan = Vector3.zero;
            freeLook = false;
            StopCameraDrag();
        }

        internal void Draw(Rect rect, bool invertVertical)
        {
            HandleCamera(rect, invertVertical);
            var evt = Event.current;
            if (evt.type != EventType.Repaint || rect.width < 2 || rect.height < 2) return;
            if (freeLook)
            {
                var camera = preview.camera;
                camera.orthographic = false;
                camera.fieldOfView = freeFov;
                camera.transform.SetPositionAndRotation(freePosition, Quaternion.Euler(freePitch, freeYaw, 0f));
            }
            else Aim(rect.width / rect.height, yaw, pitch, zoom);
            preview.BeginPreview(rect, GUIStyle.none);
            try { preview.Render(true, false); }
            finally
            {
                var texture = preview.EndPreview();
                if (texture) GUI.DrawTexture(rect, texture, ScaleMode.StretchToFill, false);
            }
            // While playing, use the skinned bounds, which follow the pose once rendered (updateWhenOffscreen is on).
            if (!ExactMeasure) LowestPoint = renderers.Count == 0 ? (float?)null :
                renderers.Where(r => r && r.enabled && r.gameObject.activeInHierarchy).Select(r => r.bounds.min.y)
                    .DefaultIfEmpty(0f).Min() - previewRoot.position.y;
        }

        private void HandleCamera(Rect rect, bool invertVertical)
        {
            var evt = Event.current;
            int id = GUIUtility.GetControlID("PoseDeckPreviewCamera".GetHashCode(), FocusType.Passive, rect);
            if (GUIUtility.hotControl == id && !freeMouseHeld && !panMouseHeld) GUIUtility.hotControl = 0;
            if (evt.type == EventType.MouseDown && evt.button == 2 && rect.Contains(evt.mousePosition))
            {
                StopCameraDrag();
                panMouseHeld = true;
                GUIUtility.hotControl = id;
                evt.Use();
                return;
            }
            if (panMouseHeld && GUIUtility.hotControl == id)
            {
                if (evt.type == EventType.MouseUp && evt.button == 2 || evt.type == EventType.Ignore)
                {
                    StopCameraDrag();
                    GUIUtility.hotControl = 0;
                    if (evt.type != EventType.Ignore) evt.Use();
                    return;
                }
                if (evt.type == EventType.MouseDrag && evt.button == 2)
                {
                    var camera = preview.camera;
                    float halfHeight = freeLook
                        ? Mathf.Max(.05f, Vector3.Distance(freePosition, frame.center)) * Mathf.Tan(freeFov * Mathf.Deg2Rad * .5f)
                        : camera.orthographicSize;
                    var delta = (-camera.transform.right * evt.delta.x + camera.transform.up * evt.delta.y) *
                        (2f * halfHeight / Mathf.Max(1f, rect.height));
                    if (freeLook) freePosition += delta; else orbitPan += delta;
                    evt.Use();
                    GUI.changed = true;
                    return;
                }
            }
            if (evt.type == EventType.MouseDown && evt.button == 1 && rect.Contains(evt.mousePosition))
            {
                if (!freeLook)
                {
                    Aim(rect.width / Mathf.Max(1, rect.height), yaw, pitch, zoom);
                    var camera = preview.camera;
                    freePosition = camera.transform.position;
                    var angles = camera.transform.eulerAngles;
                    freePitch = Mathf.DeltaAngle(0, angles.x);
                    freeYaw = angles.y;
                    float distance = Mathf.Max(.01f, Vector3.Distance(freePosition, frame.center));
                    freeFov = Mathf.Clamp(Mathf.Atan(camera.orthographicSize / distance) * 2f * Mathf.Rad2Deg, 10f, 65f);
                    freeLook = true;
                }
                StopCameraDrag();
                freeMouseHeld = true;
                lastCameraTick = EditorApplication.timeSinceStartup;
                GUIUtility.hotControl = id;
                GUIUtility.keyboardControl = 0;
                evt.Use();
                GUI.changed = true;
                return;
            }
            if (freeMouseHeld && GUIUtility.hotControl == id)
            {
                if (evt.type == EventType.MouseUp && evt.button == 1 || evt.type == EventType.Ignore ||
                    evt.type == EventType.KeyDown && evt.keyCode == KeyCode.Escape)
                {
                    StopCameraDrag();
                    GUIUtility.hotControl = 0;
                    if (evt.type != EventType.Ignore) evt.Use();
                    return;
                }
                if (evt.type == EventType.MouseDrag && evt.button == 1)
                {
                    freeYaw += evt.delta.x * .25f;
                    freePitch = Mathf.Clamp(freePitch + evt.delta.y * (invertVertical ? -.25f : .25f), -88f, 88f);
                    evt.Use();
                    GUI.changed = true;
                    return;
                }
                if ((evt.type == EventType.KeyDown || evt.type == EventType.KeyUp) && IsCameraKey(evt.keyCode))
                {
                    if (evt.type == EventType.KeyDown) movementKeys.Add(evt.keyCode); else movementKeys.Remove(evt.keyCode);
                    evt.Use();
                    return;
                }
            }
            if (rect.Contains(evt.mousePosition) && evt.type == EventType.MouseDrag && evt.button == 0)
            {
                freeLook = false;
                yaw += evt.delta.x * .65f;
                pitch = Mathf.Clamp(pitch - evt.delta.y * .65f, -80f, 80f);
                evt.Use();
                GUI.changed = true;
            }
            else if (rect.Contains(evt.mousePosition) && evt.type == EventType.ScrollWheel)
            {
                if (freeLook) freeFov = Mathf.Clamp(freeFov * Mathf.Exp(evt.delta.y * .065f), 7f, 80f);
                else zoom = Mathf.Clamp(zoom * Mathf.Exp(evt.delta.y * .065f), .3f, 3.5f);
                evt.Use();
                GUI.changed = true;
            }
        }

        private static bool IsCameraKey(KeyCode key) => key == KeyCode.W || key == KeyCode.S ||
            key == KeyCode.A || key == KeyCode.D || key == KeyCode.Q || key == KeyCode.E ||
            key == KeyCode.LeftShift || key == KeyCode.RightShift;

        internal bool TickCamera()
        {
            if (!freeMouseHeld) return false;
            double now = EditorApplication.timeSinceStartup;
            float dt = Mathf.Clamp((float)(now - lastCameraTick), 0f, .08f);
            lastCameraTick = now;
            float Axis(KeyCode plus, KeyCode minus) => (movementKeys.Contains(plus) ? 1 : 0) - (movementKeys.Contains(minus) ? 1 : 0);
            var local = new Vector3(Axis(KeyCode.D, KeyCode.A), 0f, Axis(KeyCode.W, KeyCode.S));
            var move = Quaternion.Euler(freePitch, freeYaw, 0f) * local + Vector3.up * Axis(KeyCode.E, KeyCode.Q);
            if (move.sqrMagnitude < .001f) return false;
            float multiplier = movementKeys.Contains(KeyCode.LeftShift) || movementKeys.Contains(KeyCode.RightShift) ? 2.5f : 1f;
            freePosition += move.normalized * (Mathf.Max(.2f, frame.extents.magnitude) * .8f * multiplier * dt);
            return true;
        }

        internal void StopCameraDrag()
        {
            freeMouseHeld = false;
            panMouseHeld = false;
            movementKeys.Clear();
        }

        // readable keeps the pixels on the CPU (for saving as PNG); transparent clears the background to alpha 0.
        internal Texture2D CaptureThumbnail(AnimationClip animation, int size, bool readable = false, bool transparent = false)
        {
            SetClip(animation);
            Sample(animation.length * .5f);
            Fit();
            Aim(1f, 45f, -25f, 1f);
            bool showFloor = ShowFloor;
            ShowFloor = false;
            var background = preview.camera.backgroundColor;
            Texture2D result = null, black = null, white = null;
            try
            {
                if (!transparent) result = RenderStill(size);
                else
                {
                    // The static preview comes back without alpha: render on black and on white and recover the
                    // coverage from the difference.
                    preview.camera.backgroundColor = Color.black;
                    black = RenderStill(size);
                    preview.camera.backgroundColor = Color.white;
                    white = RenderStill(size);
                    if (black && white) result = Matte(black, white);
                }
            }
            finally
            {
                ShowFloor = showFloor;
                preview.camera.backgroundColor = background;
                if (black) Object.DestroyImmediate(black);
                if (white) Object.DestroyImmediate(white);
            }
            if (result)
            {
                result.hideFlags = HideFlags.HideAndDontSave;
                result.filterMode = FilterMode.Bilinear;
                result.Apply(false, !readable);
            }
            return result;
        }

        private Texture2D RenderStill(int size)
        {
            preview.BeginStaticPreview(new Rect(0, 0, size, size));
            Texture2D result = null;
            bool succeeded = false;
            try
            {
                preview.Render(true, false);
                succeeded = true;
            }
            finally
            {
                result = preview.EndStaticPreview();
                if (!succeeded && result) { Object.DestroyImmediate(result); result = null; }
            }
            return result;
        }

        // Pixels over black (b) and white (w) are a*F and a*F + (1 - a): the difference gives the coverage a, and b / a
        // the colour. Blending happens in linear space, so the sRGB values are converted first.
        private static Texture2D Matte(Texture2D black, Texture2D white)
        {
            bool linear = QualitySettings.activeColorSpace == ColorSpace.Linear;
            var toLinear = new float[256];
            for (int i = 0; i < 256; i++) toLinear[i] = linear ? Mathf.GammaToLinearSpace(i / 255f) : i / 255f;
            byte Encode(float v) => (byte)Mathf.RoundToInt(Mathf.Clamp01(linear ? Mathf.LinearToGammaSpace(Mathf.Clamp01(v)) : v) * 255f);
            var b = black.GetPixels32();
            var w = white.GetPixels32();
            var pixels = new Color32[b.Length];
            for (int i = 0; i < b.Length; i++)
            {
                float r = toLinear[b[i].r], g = toLinear[b[i].g], bl = toLinear[b[i].b];
                float alpha = Mathf.Clamp01(1f - (toLinear[w[i].r] - r + toLinear[w[i].g] - g + toLinear[w[i].b] - bl) / 3f);
                pixels[i] = alpha < .5f / 255f ? new Color32(0, 0, 0, 0)
                    : new Color32(Encode(r / alpha), Encode(g / alpha), Encode(bl / alpha), (byte)Mathf.RoundToInt(alpha * 255f));
            }
            var result = new Texture2D(black.width, black.height, TextureFormat.RGBA32, false);
            result.SetPixels32(pixels);
            return result;
        }

        private void Aim(float aspect, float viewYaw, float viewPitch, float viewZoom)
        {
            var size = frame.extents;
            float radius = Mathf.Max(.12f, size.magnitude);
            var rotation = Quaternion.Euler(viewPitch, viewYaw, 0);
            var cam = preview.camera;
            cam.orthographic = true;
            var center = frame.center + orbitPan;
            cam.transform.position = center + rotation * Vector3.forward * radius * 4;
            cam.transform.rotation = Quaternion.LookRotation(center - cam.transform.position, Vector3.up);
            cam.nearClipPlane = Mathf.Max(.001f, radius * .01f);
            cam.farClipPlane = radius * 16;
            // Enclose the bounds in camera space, including the vertical extent added by the elevated view.
            var right = cam.transform.right;
            var up = cam.transform.up;
            float HalfSpan(Vector3 axis) => Mathf.Abs(axis.x) * size.x + Mathf.Abs(axis.y) * size.y + Mathf.Abs(axis.z) * size.z;
            cam.orthographicSize = Mathf.Max(HalfSpan(up), HalfSpan(right) / Mathf.Max(.2f, aspect), .07f) * 1.10f * viewZoom;
        }

        public void Dispose()
        {
            StopCameraDrag();
            if (graph.IsValid()) graph.Destroy();
            DestroyMirrorController();
            if (animator) { Simulated.Remove(animator); animator.runtimeAnimatorController = null; }
            if (gogoOverride) Object.DestroyImmediate(gogoOverride);
            if (measureMesh) Object.DestroyImmediate(measureMesh);
            preview.Cleanup();
            if (floorMesh) Object.DestroyImmediate(floorMesh);
            if (floorMaterial) Object.DestroyImmediate(floorMaterial);
        }
    }
}
