#if UNITY_EDITOR
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;
using VRC.SDK3.Avatars.Components;

namespace NXYUI.AIExpression
{
    // A front view of the avatar's face as it is now, for Claude to look at: the avatar's renderers drawn in a preview
    // scene, with the working copies in place of the originals they stand for. Nothing in the scene is changed.
    internal static class FaceCapture
    {
        internal static byte[] Png(VRCAvatarDescriptor avatar, WorkSession session, int size = 512)
        {
            var root = avatar.transform;
            var replaced = session != null && session.Cloned ? new HashSet<Renderer>(session.Originals) : new HashSet<Renderer>();
            var renderers = root.GetComponentsInChildren<Renderer>(false)
                .Where(r => r.enabled && (r is SkinnedMeshRenderer || r is MeshRenderer) && !replaced.Contains(r)).ToList();
            var preview = new PreviewRenderUtility();
            var meshes = new List<Mesh>();
            try
            {
                // Framed on the face: the eyes a little above the middle, the face about two thirds of the height.
                var eyes = root.TransformPoint(avatar.ViewPosition);
                float height = Mathf.Max(0.05f, root.TransformVector(Vector3.up * avatar.ViewPosition.y).magnitude * 0.17f);
                var center = eyes - root.up * height * 0.15f;
                var camera = preview.camera;
                camera.fieldOfView = 25f;
                float distance = height * 0.5f / Mathf.Tan(12.5f * Mathf.Deg2Rad) * 1.1f;
                camera.transform.SetPositionAndRotation(center + root.forward * distance, Quaternion.LookRotation(-root.forward, root.up));
                camera.nearClipPlane = distance * 0.05f;
                camera.farClipPlane = distance * 20f;
                camera.clearFlags = CameraClearFlags.SolidColor;
                camera.backgroundColor = new Color(0.45f, 0.45f, 0.48f, 1f);
                preview.lights[0].intensity = 1.1f;
                preview.lights[0].transform.rotation = Quaternion.LookRotation(-root.forward + root.up * -0.4f + root.right * 0.3f, root.up);
                preview.lights[1].intensity = 0.5f;
                preview.ambientColor = new Color(0.4f, 0.4f, 0.4f, 1f);

                preview.BeginStaticPreview(new Rect(0, 0, size, size));
                foreach (var renderer in renderers)
                {
                    Mesh mesh;
                    Matrix4x4 matrix;
                    if (renderer is SkinnedMeshRenderer skinned)
                    {
                        if (!skinned.sharedMesh) continue;
                        mesh = new Mesh();
                        meshes.Add(mesh);
                        skinned.BakeMesh(mesh, true);
                        matrix = Matrix4x4.TRS(skinned.transform.position, skinned.transform.rotation, Vector3.one);
                    }
                    else
                    {
                        mesh = renderer.TryGetComponent<MeshFilter>(out var filter) ? filter.sharedMesh : null;
                        if (!mesh) continue;
                        matrix = renderer.transform.localToWorldMatrix;
                    }
                    var materials = renderer.sharedMaterials;
                    for (int sub = 0; sub < Mathf.Min(mesh.subMeshCount, materials.Length); sub++)
                        if (materials[sub]) preview.DrawMesh(mesh, matrix, materials[sub], sub);
                }
                preview.Render(true);
                var image = preview.EndStaticPreview();
                try { return image.EncodeToPNG(); }
                finally { Object.DestroyImmediate(image); }
            }
            finally
            {
                preview.Cleanup();
                foreach (var mesh in meshes) Object.DestroyImmediate(mesh);
            }
        }
    }
}
#endif
