#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using VRC.SDK3.Avatars.Components;

namespace NXYUI.AIExpression
{
    // "AI 표정": the avatar and its face dictionary and working copy on the left, the way to Claude on the right (the
    // Claude API from here, or MCP for Claude Code). Saving the expression as a clip ends the work.
    internal sealed class AIExpressionWindow : EditorWindow
    {
        private static readonly string[] Ways = { "Claude API", "MCP (Claude Code)" };
        private static readonly string[] Modes = { "가볍게", "직접 편집" };
        private static readonly string[] Efforts = { "low", "medium", "high" };
        private static readonly string[] EffortLabels = { "낮음", "보통", "높음" };

        private VRCAvatarDescriptor avatar;
        private int way, mode;
        private int effort;
        private int rounds = 8, tokens = 100000;
        private string request = "", clipName = "", keyDraft;
        private string modelId = ClaudeApi.DefaultModel;
        private List<ClaudeApi.Model> models;
        private bool refreshing, dictionaryOpen;
        private string message, savedPath;
        private MessageType messageType;
        private Vector2 leftScroll, rightScroll;

        private GUIStyle wrappedBold;
        private GUIStyle WrappedBold => wrappedBold ??= new GUIStyle(EditorStyles.boldLabel) { wordWrap = true };

        [MenuItem("NXYUI/AI Expression")]
        private static void Open() => GetWindow<AIExpressionWindow>("AI 표정");

        private void OnEnable()
        {
            minSize = new Vector2(740, 420);
            models = ClaudeApi.CachedModels();
            modelId = EditorPrefs.GetString("NXYUI.AIExpression.Model", ClaudeApi.DefaultModel);
            ExpressionCore.Changed += Repaint;
            ExpressionAgent.Changed += Repaint;
            McpServer.Changed += Repaint;
            if (!avatar) Pick(FromSelection() ?? FindObjectsOfType<VRCAvatarDescriptor>().FirstOrDefault(IsSceneAvatar));
        }

        private void OnDisable()
        {
            ExpressionCore.Changed -= Repaint;
            ExpressionAgent.Changed -= Repaint;
            McpServer.Changed -= Repaint;
        }

        private void OnSelectionChange()
        {
            var selected = FromSelection();
            if (selected && selected != avatar && ExpressionCore.Session == null)
            {
                Pick(selected);
                Repaint();
            }
        }

        private static VRCAvatarDescriptor FromSelection()
        {
            var go = Selection.activeGameObject;
            var d = go ? go.GetComponentInParent<VRCAvatarDescriptor>(true) : null;
            return d && IsSceneAvatar(d) ? d : null;
        }

        private static bool IsSceneAvatar(VRCAvatarDescriptor d) =>
            d && !EditorUtility.IsPersistent(d) && d.gameObject.scene.IsValid() && !EditorSceneManager.IsPreviewScene(d.gameObject.scene);

        private void Pick(VRCAvatarDescriptor next)
        {
            avatar = next;
            ExpressionCore.Select(next);
            message = null;
            savedPath = null;
        }

        private void Say(string text, MessageType type = MessageType.Info)
        {
            message = text;
            messageType = type;
        }

        // Runs an action that may fail with a message for the user.
        private void Try(Action action)
        {
            try { action(); }
            catch (Exception e)
            {
                Say(e.Message, MessageType.Warning);
                if (!(e is InvalidOperationException)) Debug.LogException(e);
            }
        }

        private void OnGUI()
        {
            ExpressionCore.Check();
            using (new EditorGUILayout.HorizontalScope())
            {
                using (new EditorGUI.DisabledScope(ExpressionCore.Session != null))
                {
                    var next = (VRCAvatarDescriptor)EditorGUILayout.ObjectField(new GUIContent("아바타",
                        ExpressionCore.Session != null ? "작업 중에는 아바타를 바꿀 수 없어요. 작업을 먼저 끝내 주세요." : null), avatar, typeof(VRCAvatarDescriptor), true);
                    if (next != avatar) Pick(next && IsSceneAvatar(next) ? next : null);
                }
            }
            if (!string.IsNullOrEmpty(message)) EditorGUILayout.HelpBox(message, messageType);
            var leftovers = WorkSession.Leftovers(ExpressionCore.Session);
            if (leftovers.Count > 0)
                using (new EditorGUILayout.HorizontalScope())
                {
                    EditorGUILayout.HelpBox($"⚠ 끝나지 않은 작업본이 {leftovers.Count}개 남아 있어요(편집기를 다시 켠 경우). 원본은 Scene 뷰에서만 숨겨져 있어요.", MessageType.Warning);
                    if (GUILayout.Button("정리", GUILayout.Width(60), GUILayout.Height(38)))
                    {
                        WorkSession.CleanUp(leftovers);
                        GUIUtility.ExitGUI();
                    }
                }
            if (!avatar)
            {
                EditorGUILayout.HelpBox("표정을 만들 아바타를 고르세요. Hierarchy에서 아바타를 고르면 자동으로 들어가요.", MessageType.Info);
                return;
            }
            using (new EditorGUILayout.HorizontalScope())
            {
                using (new EditorGUILayout.VerticalScope(GUILayout.Width(position.width * 0.48f)))
                using (var scroll = new EditorGUILayout.ScrollViewScope(leftScroll))
                {
                    leftScroll = scroll.scrollPosition;
                    DrawDictionary();
                    EditorGUILayout.Space(8);
                    DrawSession();
                }
                using (new EditorGUILayout.VerticalScope())
                using (var scroll = new EditorGUILayout.ScrollViewScope(rightScroll))
                {
                    rightScroll = scroll.scrollPosition;
                    way = GUILayout.Toolbar(way, Ways);
                    EditorGUILayout.Space(4);
                    if (way == 0) DrawApi();
                    else DrawMcp();
                }
            }
        }

        // ---- left ----------------------------------------------------------------------------------------------

        private void DrawDictionary()
        {
            EditorGUILayout.LabelField("얼굴 사전", EditorStyles.boldLabel);
            EditorGUILayout.LabelField("얼굴 쉐이프키마다 어디가 어느 쪽으로 움직이는지 정점 이동으로 읽어 둔 목록이에요. Claude는 이것을 보고 번호와 값으로 답해요.",
                EditorStyles.wordWrappedMiniLabel);
            var d = ExpressionCore.Dictionary != null && ExpressionCore.Dictionary.Avatar == avatar ? ExpressionCore.Dictionary : null;
            using (new EditorGUILayout.HorizontalScope())
            {
                using (new EditorGUI.DisabledScope(ExpressionCore.Session != null))
                if (GUILayout.Button(new GUIContent(d == null ? "사전 만들기" : "다시 만들기",
                        ExpressionCore.Session != null ? "작업 중에는 다시 만들 수 없어요. 작업을 먼저 끝내 주세요." : null), GUILayout.Width(100)))
                {
                    Try(() =>
                    {
                        var built = ExpressionCore.EnsureDictionary(true);
                        Say($"얼굴 쉐이프키 {built.Entries.Count}개를 읽었어요 (메시 {built.Renderers.Count}개, 뺀 것 {built.Skipped}개).");
                    });
                    GUIUtility.ExitGUI();
                }
                GUILayout.Label(d == null ? "아직 없어요." : $"{d.Entries.Count}개 · 메시 {d.Renderers.Count}개", EditorStyles.miniLabel);
            }
            bool names = EditorGUILayout.ToggleLeft(new GUIContent("쉐이프키 이름도 보내기",
                "이름은 토큰을 더 쓰지만(캐시로 대부분 아껴요) Claude가 훨씬 정확해져요. 끄면 번호와 움직임만 보내요."), ExpressionCore.SendNames);
            if (names != ExpressionCore.SendNames) ExpressionCore.SendNames = names;
            if (d == null) return;
            dictionaryOpen = EditorGUILayout.Foldout(dictionaryOpen, "목록 보기", true);
            if (!dictionaryOpen) return;
            foreach (var e in d.Entries.Take(60))
                EditorGUILayout.LabelField($"{e.Id}  {e.Name}", $"{e.Region} · {e.Motion} · {e.Strength}", EditorStyles.miniLabel);
            if (d.Entries.Count > 60) EditorGUILayout.LabelField($"… 외 {d.Entries.Count - 60}개", EditorStyles.miniLabel);
        }

        private void DrawSession()
        {
            EditorGUILayout.LabelField("작업", EditorStyles.boldLabel);
            var session = ExpressionCore.Session;
            using (new EditorGUI.DisabledScope(session != null))
            {
                bool copies = EditorGUILayout.ToggleLeft(new GUIContent("복제본에서 작업 (권장)",
                    "얼굴 메시를 EditorOnly 복제본으로 만들어 거기서 고쳐요. 원본은 Scene 뷰에서만 숨겨지고 바뀌지 않아요."), ExpressionCore.UseCopies);
                if (copies != ExpressionCore.UseCopies) ExpressionCore.UseCopies = copies;
            }
            if (session == null)
            {
                EditorGUILayout.LabelField("아직 작업 중이 아니에요. Claude가 처음 고칠 때 자동으로 시작해요.", EditorStyles.wordWrappedMiniLabel);
                if (GUILayout.Button("작업 시작", GUILayout.Width(100))) { Try(() => ExpressionCore.EnsureSession()); GUIUtility.ExitGUI(); }
            }
            else
            {
                EditorGUILayout.LabelField(session.Cloned ? $"작업본 {session.Working.Count}개에서 작업 중이에요." : "원본에서 바로 작업 중이에요. 고친 것마다 실행 취소할 수 있어요.",
                    EditorStyles.wordWrappedMiniLabel);
                using (new EditorGUILayout.HorizontalScope())
                {
                    if (GUILayout.Button("기본 표정으로")) { Try(() => ExpressionCore.ResetFace("창")); GUIUtility.ExitGUI(); }
                    if (session.Cloned && GUILayout.Button(new GUIContent("원본에 반영하고 끝내기", "지금 표정을 원본 메시에 넣고 작업본을 지워요.")))
                    {
                        Try(() => ExpressionCore.Finish(true));
                        GUIUtility.ExitGUI();
                    }
                }
                if (GUILayout.Button(new GUIContent(session.Cloned ? "버리고 끝내기" : "끝내기", session.Cloned ? "작업본을 지우고 원본을 다시 보여 줘요." : "작업을 끝내요. 바꾼 값은 그대로예요.")))
                {
                    Try(() => ExpressionCore.Finish(false));
                    GUIUtility.ExitGUI();
                }
            }
            EditorGUILayout.Space(8);
            EditorGUILayout.LabelField("표정 클립으로 저장", EditorStyles.boldLabel);
            using (new EditorGUILayout.HorizontalScope())
            {
                clipName = EditorGUILayout.TextField(clipName);
                using (new EditorGUI.DisabledScope(session == null || string.IsNullOrWhiteSpace(clipName)))
                    if (GUILayout.Button("저장", GUILayout.Width(50)))
                    {
                        Try(() =>
                        {
                            savedPath = ExpressionCore.Save(clipName.Trim(), "창");
                            Say("저장했어요: " + savedPath);
                        });
                        GUIUtility.ExitGUI();
                    }
            }
            EditorGUILayout.LabelField("기본 표정과 달라진 쉐이프키만 원본 메시 경로로 담아요. FX나 Gesture 레이어에 넣어 쓰세요.", EditorStyles.wordWrappedMiniLabel);
            if (!string.IsNullOrEmpty(savedPath) && GUILayout.Button("저장한 클립 선택", GUILayout.Width(120)))
                EditorGUIUtility.PingObject(AssetDatabase.LoadAssetAtPath<AnimationClip>(savedPath));
            if (!string.IsNullOrEmpty(ExpressionCore.Activity)) EditorGUILayout.LabelField(ExpressionCore.Activity, EditorStyles.wordWrappedMiniLabel);
        }

        // ---- right: API ----------------------------------------------------------------------------------------

        private void DrawApi()
        {
            EditorGUILayout.LabelField("Claude API", EditorStyles.boldLabel);
            using (new EditorGUILayout.HorizontalScope())
            {
                keyDraft ??= ClaudeApi.ApiKey;
                keyDraft = EditorGUILayout.PasswordField(new GUIContent("API 키", "이 컴퓨터의 Unity 설정(EditorPrefs)에만 저장돼요. 프로젝트에는 들어가지 않아요."), keyDraft);
                using (new EditorGUI.DisabledScope(keyDraft == ClaudeApi.ApiKey))
                    if (GUILayout.Button("저장", GUILayout.Width(50)))
                    {
                        ClaudeApi.ApiKey = keyDraft.Trim();
                        GUI.FocusControl(null);
                    }
            }
            mode = GUILayout.Toolbar(mode, Modes, EditorStyles.miniButton);
            EditorGUILayout.LabelField(mode == 0
                ? "가볍게: 사전만 보고 한 번에 번호와 값을 답해요. 토큰이 가장 적게 들어요."
                : "직접 편집: Claude가 고치고, 얼굴을 찍어 보고, 다시 고쳐요. 이미지를 볼 수 있는 모델만 되고 토큰을 더 써요.", EditorStyles.wordWrappedMiniLabel);

            var usable = (models ?? new List<ClaudeApi.Model>()).Where(m => mode == 0 || m.image).ToList();
            using (new EditorGUILayout.HorizontalScope())
            {
                if (usable.Count == 0) EditorGUILayout.LabelField("모델", modelId);
                else
                {
                    int index = Mathf.Max(0, usable.FindIndex(m => m.id == modelId));
                    int next = EditorGUILayout.Popup("모델", index, usable.Select(m => m.name).ToArray());
                    if (usable[next].id != modelId)
                    {
                        modelId = usable[next].id;
                        EditorPrefs.SetString("NXYUI.AIExpression.Model", modelId);
                    }
                }
                using (new EditorGUI.DisabledScope(refreshing || string.IsNullOrEmpty(ClaudeApi.ApiKey)))
                    if (GUILayout.Button(new GUIContent("목록", "이 키로 쓸 수 있는 모델을 불러와요."), GUILayout.Width(50))) RefreshModels();
            }
            if (models == null || models.Count == 0)
                EditorGUILayout.LabelField("API 키를 저장하고 ‘목록’을 누르면 쓸 수 있는 모델을 불러와요.", EditorStyles.wordWrappedMiniLabel);
            effort = EditorGUILayout.Popup(new GUIContent("생각하는 정도", "높을수록 신중하지만 토큰과 시간이 더 들어요."), effort, EffortLabels);
            if (mode == 1)
            {
                rounds = EditorGUILayout.IntSlider(new GUIContent("최대 반복", "Claude가 고치고 보는 일을 몇 번까지 할지예요."), rounds, 1, 20);
                tokens = Mathf.Max(5000, EditorGUILayout.IntField(new GUIContent("최대 토큰", "이 요청에서 쓸 토큰의 합(입력·캐시·출력)이 넘으면 멈춰요."), tokens));
            }
            EditorGUILayout.LabelField("어떤 표정을 원하세요?", EditorStyles.boldLabel);
            request = EditorGUILayout.TextArea(request, GUILayout.MinHeight(54));
            using (new EditorGUILayout.HorizontalScope())
            {
                var model = Current();
                bool can = !ExpressionAgent.Running && model != null && !string.IsNullOrWhiteSpace(request) && !string.IsNullOrEmpty(ClaudeApi.ApiKey) &&
                           (mode == 0 || model.image);
                string why = string.IsNullOrEmpty(ClaudeApi.ApiKey) ? "API 키를 먼저 저장해 주세요." :
                    model == null ? "모델 목록을 먼저 불러와 주세요." :
                    mode == 1 && !model.image ? "이 모델은 이미지를 볼 수 없어요." : null;
                using (new EditorGUI.DisabledScope(!can))
                    if (GUILayout.Button(new GUIContent("보내기", why)))
                    {
                        if (mode == 0) ExpressionAgent.RunLight(model, Efforts[effort], request.Trim());
                        else ExpressionAgent.RunDirect(model, Efforts[effort], request.Trim(), rounds, tokens);
                    }
                using (new EditorGUI.DisabledScope(!ExpressionAgent.Running))
                    if (GUILayout.Button("멈추기", GUILayout.Width(60))) ExpressionAgent.Stop();
            }
            if (!string.IsNullOrEmpty(ExpressionAgent.Status))
                EditorGUILayout.HelpBox(ExpressionAgent.Status, ExpressionAgent.Failed ? MessageType.Warning : MessageType.Info);
            if (ExpressionAgent.All.Calls > 0)
            {
                EditorGUILayout.LabelField("이번 요청: " + ExpressionAgent.Run, EditorStyles.wordWrappedMiniLabel);
                EditorGUILayout.LabelField("이번 세션 합계: " + ExpressionAgent.All, EditorStyles.wordWrappedMiniLabel);
            }
            EditorGUILayout.LabelField("사전은 캐시에 남아서, 같은 아바타로 이어서 물으면 입력 토큰 대부분이 싸게 처리돼요.", EditorStyles.wordWrappedMiniLabel);
        }

        private ClaudeApi.Model Current() =>
            models?.FirstOrDefault(m => m.id == modelId) ?? (models == null || models.Count == 0
                ? new ClaudeApi.Model { id = modelId, name = modelId, image = true, structured = true, effort = true } : null);

        private async void RefreshModels()
        {
            refreshing = true;
            try
            {
                models = await ClaudeApi.RefreshModels();
                Say($"모델 {models.Count}개를 불러왔어요.");
            }
            catch (Exception e) { Say(e.Message, MessageType.Warning); }
            finally
            {
                refreshing = false;
                Repaint();
            }
        }

        // ---- right: MCP ----------------------------------------------------------------------------------------

        private void DrawMcp()
        {
            EditorGUILayout.LabelField("MCP 서버", EditorStyles.boldLabel);
            EditorGUILayout.LabelField("Claude Code 같은 MCP 클라이언트가 이 창의 아바타 표정을 직접 고쳐요. 연결한 프로그램이 고른 모델을 쓰고, API 키는 필요 없어요. " +
                                       "이 컴퓨터(127.0.0.1)에서만 연결돼요.", EditorStyles.wordWrappedMiniLabel);
            bool on = EditorGUILayout.ToggleLeft("MCP 서버 켜기", McpServer.Enabled);
            if (on != McpServer.Enabled) McpServer.Enabled = on;
            using (new EditorGUI.DisabledScope(McpServer.Listening))
            {
                int port = EditorGUILayout.IntField(new GUIContent("포트", "다른 프로그램이 같은 포트를 쓰면 바꿔 주세요. 켜져 있을 때는 바꿀 수 없어요."), McpServer.Port);
                if (port != McpServer.Port) McpServer.Port = port;
            }
            if (McpServer.Enabled)
            {
                if (McpServer.Listening) EditorGUILayout.HelpBox("연결을 기다리고 있어요: " + McpServer.Url, MessageType.Info);
                else EditorGUILayout.HelpBox("⚠ 서버를 열지 못했어요: " + McpServer.Error, MessageType.Warning);
            }
            EditorGUILayout.Space(6);
            EditorGUILayout.LabelField("Claude Code에 추가하기", EditorStyles.boldLabel);
            EditorGUILayout.LabelField("터미널에서 한 번 실행하세요.", EditorStyles.wordWrappedMiniLabel);
            using (new EditorGUILayout.HorizontalScope())
            {
                EditorGUILayout.SelectableLabel(McpServer.AddCommand, EditorStyles.textField, GUILayout.Height(EditorGUIUtility.singleLineHeight));
                if (GUILayout.Button("복사", GUILayout.Width(50))) EditorGUIUtility.systemCopyBuffer = McpServer.AddCommand;
            }
            EditorGUILayout.LabelField("명령에 든 토큰이 있어야 연결돼요. 토큰을 새로 만들면 예전 명령으로 추가한 연결은 끊기니, 그때는 다시 추가하세요.",
                EditorStyles.wordWrappedMiniLabel);
            if (GUILayout.Button(new GUIContent("토큰 새로 만들기", "다른 사람에게 명령을 보여 줬다면 새로 만드세요."), GUILayout.Width(110)))
            {
                McpServer.RenewToken();
                if (McpServer.Enabled) McpServer.Start();
            }
            EditorGUILayout.LabelField("그다음 Claude Code에 ‘아바타를 웃는 표정으로 만들어 줘’처럼 말하면 사전을 읽고 고쳐요. 결과는 왼쪽에서 클립으로 저장하세요.",
                EditorStyles.wordWrappedMiniLabel);
            var log = McpServer.Log.ToList();
            if (log.Count > 0)
            {
                EditorGUILayout.Space(6);
                EditorGUILayout.LabelField("최근 요청", EditorStyles.boldLabel);
                foreach (var line in log) EditorGUILayout.LabelField(line, EditorStyles.miniLabel);
            }
        }
    }
}
#endif
