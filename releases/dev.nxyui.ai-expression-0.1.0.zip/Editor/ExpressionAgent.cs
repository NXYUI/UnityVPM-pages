#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using UnityEngine;

namespace NXYUI.AIExpression
{
    // The two ways the window asks Claude through the API. Light: one request, the answer is ids and values as JSON
    // (structured output). Direct edit: Claude sets shapes and looks at the face through two tools until it is satisfied,
    // within a number of rounds and tokens, and can be stopped. Every edit is one Undo step.
    internal static class ExpressionAgent
    {
        internal sealed class Usage
        {
            internal int Input, Output, CacheRead, CacheWrite, Calls;
            internal int Total => Input + Output + CacheRead + CacheWrite;

            internal void Add(JObject response)
            {
                var u = response["usage"];
                Input += (int?)u?["input_tokens"] ?? 0;
                Output += (int?)u?["output_tokens"] ?? 0;
                CacheRead += (int?)u?["cache_read_input_tokens"] ?? 0;
                CacheWrite += (int?)u?["cache_creation_input_tokens"] ?? 0;
                Calls++;
            }

            public override string ToString() =>
                $"입력 {Input:N0} · 캐시 읽기 {CacheRead:N0} · 캐시 쓰기 {CacheWrite:N0} · 출력 {Output:N0} (요청 {Calls}번)";
        }

        internal static bool Running { get; private set; }
        internal static string Status { get; private set; } = "";
        internal static bool Failed { get; private set; }
        // This run's tokens, and all runs' since the editor started.
        internal static Usage Run = new Usage(), All = new Usage();
        private static bool stop;
        internal static event Action Changed;

        private static void Say(string status, bool failed = false)
        {
            Status = status;
            Failed = failed;
            Changed?.Invoke();
        }

        internal static void Stop()
        {
            stop = true;
            ClaudeApi.Abort();
        }

        private static JObject Schema(JObject properties, params string[] required) => new JObject
        {
            ["type"] = "object", ["properties"] = properties, ["required"] = new JArray(required), ["additionalProperties"] = false,
        };

        private static JObject ChangesSchema() => Schema(new JObject
        {
            ["changes"] = new JObject
            {
                ["type"] = "array",
                ["items"] = Schema(new JObject { ["id"] = new JObject { ["type"] = "integer" }, ["value"] = new JObject { ["type"] = "number" } }, "id", "value"),
            },
            ["reset_others"] = new JObject { ["type"] = "boolean" },
        }, "changes", "reset_others");

        // Reads changes from an answer or a tool input; null when they are not there or not well formed.
        internal static List<(int Id, float Value)> Changes(JToken input, out bool reset)
        {
            reset = (bool?)input?["reset_others"] ?? false;
            if (!(input?["changes"] is JArray array)) return null;
            var list = new List<(int, float)>();
            foreach (var c in array)
            {
                int? id = (int?)c["id"];
                float? value = (float?)c["value"];
                if (id == null || value == null || float.IsNaN(value.Value)) return null;
                list.Add((id.Value, value.Value));
            }
            return list;
        }

        private static JObject User(string text) => new JObject { ["role"] = "user", ["content"] = text };

        private static string Ask(string request) => $"Current values (others are 0): {ExpressionCore.CurrentValues()}\nRequest: {request}";

        private static bool Refused(JObject response)
        {
            if ((string)response["stop_reason"] != "refusal") return false;
            string category = (string)response["stop_details"]?["category"];
            Say("Claude가 이 요청을 거절했어요" + (category != null ? $" ({category})" : "") + ". 표현을 바꿔 다시 해 주세요.", true);
            return true;
        }

        // ---- light ---------------------------------------------------------------------------------------------

        internal static async void RunLight(ClaudeApi.Model model, string effort, string request)
        {
            if (Running) return;
            Begin();
            try
            {
                string system = ExpressionCore.Instructions() +
                                "\nAnswer with the changes for the user's request: ids and values. Set reset_others to true when the request is a new " +
                                "expression rather than a change to the current one. note: one short sentence in the user's language.";
                var properties = (JObject)ChangesSchema()["properties"];
                properties["note"] = new JObject { ["type"] = "string" };
                var schema = Schema(properties, "changes", "reset_others", "note");
                JObject format = null;
                if (model.structured) format = new JObject { ["type"] = "json_schema", ["schema"] = schema };
                else system += "\nReply with only this JSON and nothing else: " + schema.ToString(Formatting.None);
                Say("Claude에게 묻는 중이에요…");
                var response = await ClaudeApi.Messages(model, effort, system, new JArray(User(Ask(request))), null, format);
                Count(response);
                if (Refused(response)) return;
                if ((string)response["stop_reason"] == "max_tokens") { Say("답이 너무 길어 잘렸어요. 다시 해 주세요.", true); return; }
                string text = ClaudeApi.Text(response);
                int start = text.IndexOf('{'), end = text.LastIndexOf('}');
                var answer = start >= 0 && end > start ? JObject.Parse(text.Substring(start, end - start + 1)) : null;
                var changes = Changes(answer, out bool reset);
                if (changes == null) { Say("답을 읽지 못했어요: " + Shorten(text), true); return; }
                ExpressionCore.Apply(changes, reset, "API");
                Say($"{(string)answer["note"]} · {Run}");
            }
            catch (Exception e) { Fail(e); }
            finally { End(); }
        }

        // ---- direct edit ---------------------------------------------------------------------------------------

        internal static async void RunDirect(ClaudeApi.Model model, string effort, string request, int maxRounds, int maxTokens)
        {
            if (Running) return;
            if (!model.image) { Say("직접 편집은 이미지를 볼 수 있는 모델만 돼요.", true); return; }
            Begin();
            try
            {
                string system = ExpressionCore.Instructions() +
                                "\nMake the face match the user's request. Use set_shapekeys to change it and capture_face to look at it, and repeat until " +
                                "it looks right; then answer with one short sentence in the user's language. Pictures cost tokens: look only when it helps.";
                var setShapes = new JObject
                {
                    ["name"] = "set_shapekeys",
                    ["description"] = "Set face blendshape weights by dictionary id, 0 to 100. reset_others true first puts every other face shape back to the avatar's default face. Returns the values now.",
                    ["input_schema"] = ChangesSchema(),
                };
                var capture = new JObject
                {
                    ["name"] = "capture_face",
                    ["description"] = "Take a front picture of the avatar's face as it is now.",
                    ["input_schema"] = Schema(new JObject()),
                };
                if (model.structured)
                {
                    setShapes["strict"] = true;
                    capture["strict"] = true;
                }
                var tools = new JArray(setShapes, capture);
                var messages = new JArray(User(Ask(request)));
                // Each request reads the whole conversation again, so the next one costs at least what the last one read and
                // wrote, plus a picture.
                int next = 0;
                for (int round = 1; ; round++)
                {
                    if (stop) { Say($"멈췄어요. · {Run}"); return; }
                    if (round > maxRounds) { Say($"반복 한도({maxRounds}번)에 닿아 멈췄어요. · {Run}"); return; }
                    if (Run.Total + next >= maxTokens) { Say($"다음 요청이 토큰 한도({maxTokens:N0})를 넘을 것 같아 멈췄어요. · {Run}"); return; }
                    var before = (Run.Input + Run.CacheRead + Run.CacheWrite, Run.Output);
                    Say($"Claude가 고치는 중이에요 ({round}번째)…");
                    var response = await ClaudeApi.Messages(model, effort, system, messages, tools);
                    Count(response);
                    if (Refused(response)) return;
                    // Over the limit: nothing more runs, not even the tools this answer asks for.
                    if (Run.Total >= maxTokens) { Say($"토큰 한도({maxTokens:N0})에 닿아 멈췄어요. · {Run}"); return; }
                    next = Run.Input + Run.CacheRead + Run.CacheWrite - before.Item1 + Run.Output - before.Item2 + 1500;
                    // Its whole answer goes back as it came (thinking blocks included).
                    messages.Add(new JObject { ["role"] = "assistant", ["content"] = response["content"] });
                    string reason = (string)response["stop_reason"];
                    if (reason != "tool_use")
                    {
                        Say(reason == "max_tokens" ? "답이 너무 길어 잘렸어요." : $"{Shorten(ClaudeApi.Text(response))} · {Run}", reason == "max_tokens");
                        return;
                    }
                    var results = new JArray();
                    foreach (var block in response["content"].Where(b => (string)b["type"] == "tool_use"))
                        results.Add(Execute(block));
                    messages.Add(new JObject { ["role"] = "user", ["content"] = results });
                }
            }
            catch (Exception e) { Fail(e); }
            finally { End(); }
        }

        private static JObject Execute(JToken block)
        {
            var result = new JObject { ["type"] = "tool_result", ["tool_use_id"] = (string)block["id"] };
            try
            {
                switch ((string)block["name"])
                {
                    case "set_shapekeys":
                        var changes = Changes(block["input"], out bool reset);
                        if (changes == null) throw new ArgumentException("changes must be a list of {id, value}.");
                        result["content"] = ExpressionCore.Apply(changes, reset, "API");
                        break;
                    case "capture_face":
                        var png = ExpressionCore.Capture("API");
                        result["content"] = new JArray(new JObject
                        {
                            ["type"] = "image",
                            ["source"] = new JObject { ["type"] = "base64", ["media_type"] = "image/png", ["data"] = Convert.ToBase64String(png) },
                        });
                        break;
                    default:
                        throw new ArgumentException("Unknown tool.");
                }
            }
            catch (Exception e)
            {
                result["content"] = e.Message;
                result["is_error"] = true;
            }
            return result;
        }

        // ---- shared --------------------------------------------------------------------------------------------

        private static void Begin()
        {
            Running = true;
            stop = false;
            ClaudeApi.ResetAbort();
            Run = new Usage();
            Changed?.Invoke();
        }

        private static void End()
        {
            Running = false;
            Changed?.Invoke();
        }

        private static void Count(JObject response)
        {
            Run.Add(response);
            All.Add(response);
        }

        private static void Fail(Exception e)
        {
            if (!(e is ClaudeApi.ApiException) && !(e is InvalidOperationException)) Debug.LogException(e);
            Say(e.Message, true);
        }

        private static string Shorten(string text)
        {
            text = (text ?? "").Trim();
            return text.Length > 300 ? text.Substring(0, 300) + "…" : text;
        }
    }
}
#endif
