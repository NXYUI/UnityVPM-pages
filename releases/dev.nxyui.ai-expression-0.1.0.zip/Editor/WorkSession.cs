#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using VRC.SDK3.Avatars.Components;
using Object = UnityEngine.Object;

namespace NXYUI.AIExpression
{
    // One expression being made. With copies (the default) each face mesh gets an EditorOnly working copy beside it, the
    // original is hidden in the Scene view only (its state is not changed), and AI edits go to the copy. Without copies
    // the edits go to the originals, each one an Undo step. The weights at the start are the baseline: "reset" goes back
    // to it, and the saved clip holds what differs from it.
    internal sealed class WorkSession
    {
        internal const string CopyPrefix = "[AI 작업본] ";

        internal VRCAvatarDescriptor Avatar;
        internal bool Cloned;
        // Each face mesh and the mesh the edits go to (itself without copies).
        internal readonly Dictionary<SkinnedMeshRenderer, SkinnedMeshRenderer> Working = new Dictionary<SkinnedMeshRenderer, SkinnedMeshRenderer>();
        private readonly Dictionary<(SkinnedMeshRenderer, int), float> baseline = new Dictionary<(SkinnedMeshRenderer, int), float>();
        // Each face mesh's mesh at the start: shape indices are only good for it.
        private readonly Dictionary<SkinnedMeshRenderer, Mesh> meshes = new Dictionary<SkinnedMeshRenderer, Mesh>();

        internal IEnumerable<SkinnedMeshRenderer> Originals => Working.Keys;

        // The copies are still there (Undo or the user can remove them) and the meshes are the ones it started with.
        internal bool Valid => Avatar && Working.All(p => p.Key && p.Value &&
            meshes.TryGetValue(p.Key, out var mesh) && p.Key.sharedMesh == mesh && p.Value.sharedMesh == mesh);

        internal static WorkSession Start(FaceDictionary dictionary, bool copies)
        {
            var session = new WorkSession { Avatar = dictionary.Avatar, Cloned = copies };
            Undo.SetCurrentGroupName("AI Expression: start");
            int group = Undo.GetCurrentGroup();
            foreach (var original in dictionary.Renderers)
            {
                var working = copies ? Copy(original, session.Avatar.transform) : original;
                session.Working[original] = working;
                session.Remember(original);
            }
            Undo.CollapseUndoOperations(group);
            return session;
        }

        // A session whose copies an earlier editor run left in the scene (after a script reload or a restart).
        internal static WorkSession Resume(VRCAvatarDescriptor avatar)
        {
            var copies = avatar.GetComponentsInChildren<AIExpressionWorkCopy>(true).Where(c => c.source).ToList();
            if (copies.Count == 0) return null;
            var session = new WorkSession { Avatar = avatar, Cloned = true };
            foreach (var copy in copies)
            {
                var working = copy.GetComponent<SkinnedMeshRenderer>();
                if (!working) continue;
                session.Working[copy.source] = working;
                session.Remember(copy.source);
                SceneVisibilityManager.instance.Hide(copy.source.gameObject, false);
            }
            return session;
        }

        private void Remember(SkinnedMeshRenderer original)
        {
            var mesh = original.sharedMesh;
            meshes[original] = mesh;
            for (int i = 0; i < mesh.blendShapeCount; i++) baseline[(original, i)] = original.GetBlendShapeWeight(i);
        }

        // A new object beside the original with a copy of its renderer (not its children), EditorOnly. A mesh on the avatar
        // root itself gets its copy below the root, so the copy stays inside the avatar.
        private static SkinnedMeshRenderer Copy(SkinnedMeshRenderer original, Transform avatar)
        {
            var go = new GameObject(CopyPrefix + original.name);
            Undo.RegisterCreatedObjectUndo(go, "AI Expression: start");
            if (original.transform == avatar) go.transform.SetParent(avatar, false);
            else
            {
                go.transform.SetParent(original.transform.parent, false);
                go.transform.localPosition = original.transform.localPosition;
                go.transform.localRotation = original.transform.localRotation;
                go.transform.localScale = original.transform.localScale;
            }
            go.tag = "EditorOnly";
            go.layer = original.gameObject.layer;
            var renderer = go.AddComponent<SkinnedMeshRenderer>();
            EditorUtility.CopySerialized(original, renderer);
            renderer.enabled = true;
            go.AddComponent<AIExpressionWorkCopy>().source = original;
            SceneVisibilityManager.instance.Hide(original.gameObject, false);
            return renderer;
        }

        internal float Baseline(FaceDictionary.Entry e) => baseline.TryGetValue((e.Renderer, e.Index), out float v) ? v : 0f;

        internal float Get(FaceDictionary.Entry e) =>
            Working.TryGetValue(e.Renderer, out var working) && working ? working.GetBlendShapeWeight(e.Index) : 0f;

        // Sets weights as one Undo step. resetOthers: every other dictionary shape goes back to the baseline first.
        internal int Apply(FaceDictionary dictionary, IEnumerable<(int Id, float Value)> changes, bool resetOthers, string action)
        {
            Undo.IncrementCurrentGroup();
            Undo.SetCurrentGroupName(action);
            int group = Undo.GetCurrentGroup();
            Undo.RecordObjects(Working.Values.Where(r => r).Cast<Object>().ToArray(), action);
            if (resetOthers)
                foreach (var e in dictionary.Entries) Set(e, Baseline(e));
            int applied = 0;
            foreach (var (id, value) in changes)
            {
                var e = dictionary.Find(id);
                if (e == null) continue;
                Set(e, Mathf.Clamp(value, 0f, 100f));
                applied++;
            }
            foreach (var r in Working.Values.Where(r => r)) EditorUtility.SetDirty(r);
            Undo.CollapseUndoOperations(group);
            return applied;
        }

        private void Set(FaceDictionary.Entry e, float value)
        {
            if (Working.TryGetValue(e.Renderer, out var working) && working) working.SetBlendShapeWeight(e.Index, value);
        }

        internal void Reset(FaceDictionary dictionary) =>
            Apply(dictionary, Enumerable.Empty<(int, float)>(), true, "AI Expression: reset");

        // The shapes that differ from the baseline now, as an expression clip on the original meshes' paths.
        internal string SaveClip(FaceDictionary dictionary, string name)
        {
            var changed = dictionary.Entries.Where(e => Mathf.Abs(Get(e) - Baseline(e)) > 0.01f).ToList();
            if (changed.Count == 0) throw new InvalidOperationException("기준 표정과 달라진 쉐이프키가 없어요.");
            var clip = new AnimationClip { name = name };
            foreach (var e in changed)
            {
                string path = AnimationUtility.CalculateTransformPath(e.Renderer.transform, Avatar.transform);
                var binding = EditorCurveBinding.FloatCurve(path, typeof(SkinnedMeshRenderer), "blendShape." + e.Name);
                AnimationUtility.SetEditorCurve(clip, binding, AnimationCurve.Constant(0f, 1f / 60f, Get(e)));
            }
            string folder = Folder(Avatar.name);
            string file = AssetDatabase.GenerateUniqueAssetPath($"{folder}/{Safe(name)}.anim");
            AssetDatabase.CreateAsset(clip, file);
            AssetDatabase.SaveAssets();
            return file;
        }

        // Puts the working weights on the originals, one Undo step; only meshes this session works on.
        internal void ApplyToOriginals(FaceDictionary dictionary)
        {
            if (!Valid) throw new InvalidOperationException("작업 중에 메시가 바뀌었어요. 원본에 반영하지 않고 끝내 주세요.");
            Undo.IncrementCurrentGroup();
            Undo.SetCurrentGroupName("AI Expression: apply to the original");
            Undo.RecordObjects(Working.Keys.Cast<Object>().ToArray(), "AI Expression: apply to the original");
            foreach (var e in dictionary.Entries.Where(e => Working.TryGetValue(e.Renderer, out var w) && w))
                e.Renderer.SetBlendShapeWeight(e.Index, Get(e));
            foreach (var r in Working.Keys) EditorUtility.SetDirty(r);
        }

        // Ends the session: copies go, originals are shown again.
        internal void End()
        {
            foreach (var pair in Working)
            {
                if (pair.Key) SceneVisibilityManager.instance.Show(pair.Key.gameObject, false);
                if (Cloned && pair.Value) Undo.DestroyObjectImmediate(pair.Value.gameObject);
            }
            Working.Clear();
            if (Avatar) EditorSceneManager.MarkSceneDirty(Avatar.gameObject.scene);
        }

        // Working copies in the open scenes that no session holds.
        internal static List<AIExpressionWorkCopy> Leftovers(WorkSession current) =>
            Object.FindObjectsOfType<AIExpressionWorkCopy>(true)
                .Where(c => current == null || !current.Working.Values.Any(w => w && w.gameObject == c.gameObject)).ToList();

        internal static void CleanUp(IEnumerable<AIExpressionWorkCopy> copies)
        {
            foreach (var copy in copies.Where(c => c))
            {
                if (copy.source) SceneVisibilityManager.instance.Show(copy.source.gameObject, false);
                Undo.DestroyObjectImmediate(copy.gameObject);
            }
        }

        internal static string Folder(string avatar)
        {
            string folder = "Assets/NXYUI/AI Expression/" + Safe(avatar);
            string at = "Assets";
            foreach (var part in folder.Split('/').Skip(1))
            {
                if (!AssetDatabase.IsValidFolder(at + "/" + part)) AssetDatabase.CreateFolder(at, part);
                at += "/" + part;
            }
            return folder;
        }

        internal static string Safe(string name)
        {
            string safe = string.Concat((name ?? "").Select(ch => Path.GetInvalidFileNameChars().Contains(ch) ? '_' : ch)).Trim();
            return string.IsNullOrEmpty(safe) ? "Expression" : safe;
        }
    }
}
#endif
