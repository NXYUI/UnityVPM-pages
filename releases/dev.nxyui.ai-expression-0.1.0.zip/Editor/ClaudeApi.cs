#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using UnityEditor;
using UnityEngine.Networking;

namespace NXYUI.AIExpression
{
    // The Claude API over plain HTTP (UnityWebRequest). The official C# SDK needs newer copies of assemblies the VRChat
    // SDK and NDMF already ship (System.Collections.Immutable, System.Memory, ...), which Unity cannot load twice.
    internal static class ClaudeApi
    {
        private const string Base = "https://api.anthropic.com/v1/";
        private const string Version = "2026-10-21";
        private const string KeyPref = "NXYUI.AIExpression.ApiKey";
        private const string ModelsPref = "NXYUI.AIExpression.Models";
        internal const string DefaultModel = "claude-opus-5-5";

        // Kept in this computer's editor settings, not in the project.
        internal static string ApiKey
        {
            get => EditorPrefs.GetString(KeyPref, "");
            set => EditorPrefs.SetString(KeyPref, value ?? "");
        }

        internal sealed class ApiException : Exception
        {
            internal readonly long Status;
            internal ApiException(long status, string message) : base(message) { Status = status; }
        }

        [Serializable]
        internal sealed class Model
        {
            public string id, name;
            public bool image, structured, effort;
        }

        private static UnityWebRequest current;
        private static bool aborted;

        // Stops the request on its way, and any retry waiting for its turn (the Stop button).
        internal static void Abort()
        {
            aborted = true;
            current?.Abort();
        }

        internal static void ResetAbort() => aborted = false;

        // stoppable: the Stop button can stop it (expression requests; a model list refresh is not).
        internal static async Task<JObject> Send(string method, string path, JObject body, string beta = null, bool stoppable = true)
        {
            if (string.IsNullOrEmpty(ApiKey)) throw new ApiException(0, "API 키를 넣어 주세요.");
            for (int attempt = 0; ; attempt++)
            {
                if (stoppable && aborted) throw new ApiException(0, "멈췄어요.");
                using (var request = new UnityWebRequest(Base + path, method))
                {
                    request.downloadHandler = new DownloadHandlerBuffer();
                    if (body != null)
                    {
                        request.uploadHandler = new UploadHandlerRaw(Encoding.UTF8.GetBytes(body.ToString(Formatting.None)));
                        request.SetRequestHeader("content-type", "application/json");
                    }
                    request.SetRequestHeader("x-api-key", ApiKey);
                    request.SetRequestHeader("anthropic-version", Version);
                    if (!string.IsNullOrEmpty(beta)) request.SetRequestHeader("anthropic-beta", beta);
                    request.timeout = 600;
                    var done = new TaskCompletionSource<bool>();
                    if (stoppable) current = request;
                    request.SendWebRequest().completed += _ => done.TrySetResult(true);
                    await done.Task;
                    if (stoppable && current == request) current = null;
                    string text = request.downloadHandler?.text ?? "";
                    if (request.result == UnityWebRequest.Result.Success) return JObject.Parse(text);
                    long status = request.responseCode;
                    // Busy or rate-limited: wait and try again, twice.
                    bool retry = status == 429 || status == 529 || status >= 500 || request.result == UnityWebRequest.Result.ConnectionError;
                    if (request.error == "Request aborted") throw new ApiException(0, "멈췄어요.");
                    if (retry && attempt < 2)
                    {
                        await Task.Delay(TimeSpan.FromSeconds(attempt == 0 ? 2 : 6));
                        continue;
                    }
                    throw new ApiException(status, Explain(status, text, request.error));
                }
            }
        }

        private static string Explain(long status, string body, string error)
        {
            string message = error;
            try
            {
                var json = JObject.Parse(body);
                message = (string)json["error"]?["message"] ?? message;
            }
            catch (JsonException) { }
            switch (status)
            {
                case 401: return "API 키가 맞지 않아요. " + message;
                case 403: return "이 키로는 쓸 수 없어요. " + message;
                case 404: return "모델이나 주소를 찾지 못했어요. " + message;
                case 429: return "요청 한도에 걸렸어요. 잠시 뒤에 다시 해 주세요. " + message;
                case 529: return "Claude가 붐벼요. 잠시 뒤에 다시 해 주세요. " + message;
                default: return status > 0 ? $"요청이 실패했어요 ({status}). {message}" : "연결하지 못했어요: " + message;
            }
        }

        // ---- models --------------------------------------------------------------------------------------------

        // The models this key can use, newest first, with what they support; kept for when the network is away.
        internal static async Task<List<Model>> RefreshModels()
        {
            var models = new List<Model>();
            string after = null;
            do
            {
                var page = await Send("GET", "models?limit=1000" + (after != null ? "&after_id=" + Uri.EscapeDataString(after) : ""), null, null, false);
                foreach (var m in page["data"] ?? new JArray())
                    models.Add(new Model
                    {
                        id = (string)m["id"],
                        name = (string)m["display_name"] ?? (string)m["id"],
                        image = Supported(m, "image_input"),
                        structured = Supported(m, "structured_outputs"),
                        effort = Supported(m, "effort"),
                    });
                after = (bool?)page["has_more"] == true ? (string)page["last_id"] : null;
            } while (after != null);
            EditorPrefs.SetString(ModelsPref, JsonConvert.SerializeObject(models));
            return models;
        }

        private static bool Supported(JToken model, string capability) => (bool?)model["capabilities"]?[capability]?["supported"] == true;

        internal static List<Model> CachedModels()
        {
            try { return JsonConvert.DeserializeObject<List<Model>>(EditorPrefs.GetString(ModelsPref, "[]")) ?? new List<Model>(); }
            catch (JsonException) { return new List<Model>(); }
        }

        // ---- messages ------------------------------------------------------------------------------------------

        // Models that can hand a declined request on to another model inside the same call.
        private static readonly HashSet<string> Fallbacks = new HashSet<string>
            { "claude-fable-5-2", "claude-fable-5-1", "claude-opus-5-5", "claude-opus-5", "claude-sonnet-5-5" };

        // A Messages request: the stable system prompt cached, the conversation cached as it grows.
        internal static Task<JObject> Messages(Model model, string effort, string system, JArray messages, JArray tools = null, JObject format = null)
        {
            var body = new JObject
            {
                ["model"] = model.id,
                ["max_tokens"] = 16000,
                ["system"] = new JArray(new JObject { ["type"] = "text", ["text"] = system, ["cache_control"] = new JObject { ["type"] = "ephemeral" } }),
                ["messages"] = messages,
                ["cache_control"] = new JObject { ["type"] = "ephemeral" },
            };
            var config = new JObject();
            if (model.effort && !string.IsNullOrEmpty(effort)) config["effort"] = effort;
            if (format != null) config["format"] = format;
            if (config.Count > 0) body["output_config"] = config;
            if (tools != null) body["tools"] = tools;
            string beta = null;
            if (Fallbacks.Contains(model.id))
            {
                body["fallbacks"] = "default";
                beta = "server-side-fallback-2026-07-01";
            }
            return Send("POST", "messages", body, beta);
        }

        internal static string Text(JObject response) =>
            string.Concat((response["content"] ?? new JArray()).Where(b => (string)b["type"] == "text").Select(b => (string)b["text"]));
    }
}
#endif
