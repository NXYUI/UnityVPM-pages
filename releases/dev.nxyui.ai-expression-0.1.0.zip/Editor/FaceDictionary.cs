#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;
using VRC.SDK3.Avatars.Components;
using Object = UnityEngine.Object;

namespace NXYUI.AIExpression
{
    // What each face blendshape of an avatar does, read from its vertex deltas once and written as one short line per
    // blendshape: the "face dictionary" Claude reads instead of trying shapekeys. Lines use ids, so the answer is ids and
    // values. Visemes, shapes that move nothing and shapes away from the face are left out.
    internal sealed class FaceDictionary
    {
        internal sealed class Entry
        {
            internal int Id;
            internal SkinnedMeshRenderer Renderer;
            internal int Index;
            internal string Name, Region, Motion, Strength;
            internal int Frames;
        }

        internal readonly List<Entry> Entries = new List<Entry>();
        internal readonly List<SkinnedMeshRenderer> Renderers = new List<SkinnedMeshRenderer>();
        internal VRCAvatarDescriptor Avatar;
        internal int Skipped;

        internal Entry Find(int id) => id >= 0 && id < Entries.Count ? Entries[id] : null;

        // The dictionary as Claude reads it. Stable for one avatar, so the prompt that holds it can be cached.
        internal string Text(bool names)
        {
            var text = new StringBuilder();
            text.Append(names ? "id|mesh|name|region|motion|strength|steps\n" : "id|mesh|region|motion|strength|steps\n");
            foreach (var e in Entries)
            {
                text.Append(e.Id).Append('|').Append(MeshKey(e.Renderer)).Append('|');
                if (names) text.Append(e.Name.Replace('|', '/')).Append('|');
                text.Append(e.Region).Append('|').Append(e.Motion).Append('|').Append(e.Strength).Append('|').Append(e.Frames > 1 ? e.Frames.ToString() : "1").Append('\n');
            }
            return text.ToString();
        }

        private string MeshKey(SkinnedMeshRenderer r) => "m" + Renderers.IndexOf(r);

        internal string Meshes() => string.Join(", ", Renderers.Select((r, i) => $"m{i}={r.name}"));

        // ---- building --------------------------------------------------------------------------------------------

        internal static FaceDictionary Build(VRCAvatarDescriptor avatar)
        {
            var dictionary = new FaceDictionary { Avatar = avatar };
            var root = avatar.transform;
            var animator = avatar.GetComponent<Animator>();
            Transform Bone(HumanBodyBones b) => animator && animator.isHuman ? animator.GetBoneTransform(b) : null;
            var head = Bone(HumanBodyBones.Head);
            var leftEye = Bone(HumanBodyBones.LeftEye);
            var rightEye = Bone(HumanBodyBones.RightEye);

            // The eyes' middle and the distance between them, in the avatar's own space; the face is measured in it.
            Vector3 eyes = avatar.ViewPosition;
            float span = 0f;
            if (leftEye && rightEye)
            {
                var l = root.InverseTransformPoint(leftEye.position);
                var r = root.InverseTransformPoint(rightEye.position);
                eyes = new Vector3((l.x + r.x) / 2f, (l.y + r.y) / 2f, eyes.z);
                span = Mathf.Abs(r.x - l.x);
            }
            if (span < 0.01f) span = Mathf.Max(0.02f, avatar.ViewPosition.y * 0.045f);

            var visemes = new HashSet<string>(avatar.lipSync == VRC.SDKBase.VRC_AvatarDescriptor.LipSyncStyle.VisemeBlendShape && avatar.VisemeBlendShapes != null
                ? avatar.VisemeBlendShapes.Where(n => !string.IsNullOrEmpty(n)) : Enumerable.Empty<string>());

            foreach (var renderer in Candidates(avatar, head))
            {
                var mesh = renderer.sharedMesh;
                var (positions, toAvatar, scale) = Rest(renderer, root);
                var deltas = new Vector3[mesh.vertexCount];
                bool used = false;
                for (int index = 0; index < mesh.blendShapeCount; index++)
                {
                    string name = mesh.GetBlendShapeName(index);
                    bool viseme = (renderer == avatar.VisemeSkinnedMesh && visemes.Contains(name)) ||
                                  name.StartsWith("vrc.v_", StringComparison.OrdinalIgnoreCase);
                    if (viseme) { dictionary.Skipped++; continue; }
                    int frames = mesh.GetBlendShapeFrameCount(index);
                    mesh.GetBlendShapeFrameVertices(index, frames - 1, deltas, null, null);
                    var entry = Describe(deltas, positions, toAvatar, scale, eyes, span);
                    if (entry == null) { dictionary.Skipped++; continue; }
                    entry.Renderer = renderer;
                    entry.Index = index;
                    entry.Name = name;
                    entry.Frames = frames;
                    entry.Id = dictionary.Entries.Count;
                    dictionary.Entries.Add(entry);
                    used = true;
                }
                if (used) dictionary.Renderers.Add(renderer);
            }
            return dictionary;
        }

        // Skinned meshes that can hold face shapes: the lip sync mesh, and any mesh with blendshapes moved by the head.
        private static IEnumerable<SkinnedMeshRenderer> Candidates(VRCAvatarDescriptor avatar, Transform head)
        {
            foreach (var renderer in avatar.GetComponentsInChildren<SkinnedMeshRenderer>(true))
            {
                if (!renderer.sharedMesh || renderer.sharedMesh.blendShapeCount == 0) continue;
                if (renderer.GetComponent<AIExpressionWorkCopy>()) continue;
                if (renderer == avatar.VisemeSkinnedMesh || (head && renderer.bones.Any(b => b && b.IsChildOf(head)))) yield return renderer;
            }
        }

        // The mesh's vertices in the avatar's space as it is posed now, the way from the posed mesh into that space, and how
        // much bigger the posed mesh is than the mesh file (an FBX at 0.01 with a scaled armature, say): blendshape deltas
        // are in the file's units.
        private static (Vector3[] Positions, Matrix4x4 ToAvatar, float Scale) Rest(SkinnedMeshRenderer renderer, Transform root)
        {
            var baked = new Mesh();
            try
            {
                renderer.BakeMesh(baked, true);
                var toAvatar = root.worldToLocalMatrix * Matrix4x4.TRS(renderer.transform.position, renderer.transform.rotation, Vector3.one);
                var vertices = baked.vertices;
                for (int i = 0; i < vertices.Length; i++) vertices[i] = toAvatar.MultiplyPoint3x4(vertices[i]);
                baked.RecalculateBounds();
                float file = renderer.sharedMesh.bounds.size.magnitude;
                float scale = file > 1e-6f ? baked.bounds.size.magnitude / file : 1f;
                return (vertices, toAvatar, scale);
            }
            finally { Object.DestroyImmediate(baked); }
        }

        // Where on the face a shape moves, which way, and how much; null for a shape that moves nothing or not the face.
        private static Entry Describe(Vector3[] deltas, Vector3[] positions, Matrix4x4 toAvatar, float scale, Vector3 eyes, float span)
        {
            float total = 0f, largest = 0f, left = 0f, right = 0f, spread = 0f;
            Vector3 center = Vector3.zero, mean = Vector3.zero;
            int n = Math.Min(deltas.Length, positions.Length);
            for (int i = 0; i < n; i++)
            {
                if (deltas[i].sqrMagnitude < 1e-12f) continue;
                var d = toAvatar.MultiplyVector(deltas[i] * scale);
                float m = d.magnitude;
                total += m;
                largest = Mathf.Max(largest, m);
                center += positions[i] * m;
                mean += d;
                float x = positions[i].x - eyes.x;
                spread += Mathf.Abs(x) * m;
                if (x < -0.15f * span) left += m;
                else if (x > 0.15f * span) right += m;
            }
            if (largest < 1e-5f || total <= 0f) return null;
            center /= total;
            // side: how far from the middle the movement is (both eyes move far from it, though their center is in it).
            float up = (center.y - eyes.y) / span, side = spread / total / span, depth = (center.z - eyes.z) / span;
            // Not the face: far below the chin, above the head, or out to the sides.
            if (up < -3.5f || up > 2.5f || side > 2.5f || depth < -3f) return null;

            string where;
            if (up > 0.45f) where = "brows";
            else if (up > -0.4f) where = side > 0.2f ? "eyes" : "between eyes";
            else if (up > -0.95f) where = side > 0.7f ? "cheeks" : "nose";
            else if (up > -1.9f) where = side > 0.95f ? "cheeks" : "mouth";
            else where = "chin";
            // An avatar faces +z, so its own left is -x: "L"/"R" are the avatar's left and right.
            string sides = left > 0.8f * (left + right) ? "L" : right > 0.8f * (left + right) ? "R" : "both";

            // How much the vertices move the same way: low for an opening mouth (lips apart), high for a lid closing.
            float coherence = mean.magnitude / total;
            string motion;
            var a = new Vector3(Mathf.Abs(mean.x), Mathf.Abs(mean.y), Mathf.Abs(mean.z));
            if (coherence < 0.35f) motion = "spread";
            else if (a.y >= a.x && a.y >= a.z) motion = mean.y > 0 ? "up" : "down";
            else if (a.z >= a.x) motion = mean.z > 0 ? "forward" : "back";
            else motion = "sideways";

            float relative = largest / span;
            string strength = relative < 0.05f ? "subtle" : relative < 0.15f ? "medium" : "strong";
            return new Entry { Region = (sides == "both" ? "" : sides + " ") + where, Motion = motion, Strength = strength };
        }
    }
}
#endif
