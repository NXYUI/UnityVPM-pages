#if UNITY_EDITOR
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using UnityEditor;

namespace NXYUI.AIExpression
{
    // An MCP server (Streamable HTTP, JSON responses) inside the editor, so Claude Code or another MCP client on this
    // computer can make expressions with the model it already uses. It listens on 127.0.0.1 only, refuses requests from
    // other origins and hosts, and is off until turned on in the window. Tools run on the main thread.
    [InitializeOnLoad]
    internal static class McpServer
    {
        private const string EnabledPref = "NXYUI.AIExpression.Mcp", PortPref = "NXYUI.AIExpression.McpPort", TokenPref = "NXYUI.AIExpression.McpToken";
        internal const int DefaultPort = 38380;
        private const string ServerName = "nxyui-ai-expression";
        private static readonly string[] Versions = { "2025-11-25", "2025-06-18", "2025-03-26", "2024-11-05" };

        internal static bool Enabled
        {
            get => EditorPrefs.GetBool(EnabledPref, false);
            set
            {
                EditorPrefs.SetBool(EnabledPref, value);
                if (value) Start();
                else Stop();
            }
        }

        internal static int Port
        {
            get => EditorPrefs.GetInt(PortPref, DefaultPort);
            set => EditorPrefs.SetInt(PortPref, Math.Max(1024, Math.Min(65535, value)));
        }

        internal static string Url => $"http://127.0.0.1:{Port}/mcp";

        // A secret the client sends with every request, so other programs on this computer cannot edit the face.
        internal static string Token
        {
            get
            {
                string token = EditorPrefs.GetString(TokenPref, "");
                if (token.Length < 32) EditorPrefs.SetString(TokenPref, token = NewToken());
                return token;
            }
        }

        internal static void RenewToken() => EditorPrefs.SetString(TokenPref, NewToken());

        private static string NewToken()
        {
            var bytes = new byte[24];
            using (var random = System.Security.Cryptography.RandomNumberGenerator.Create()) random.GetBytes(bytes);
            return string.Concat(bytes.Select(b => b.ToString("x2")));
        }

        internal static string AddCommand => $"claude mcp add --transport http {ServerName} {Url} --header \"Authorization: Bearer {Token}\"";
        internal static bool Listening => listener != null && listener.IsListening;
        internal static string Error { get; private set; }

        private static HttpListener listener;
        private static string token;
        // Goes up each time the server starts or stops: work from a request of an earlier run never runs.
        private static int generation;

        // Work for the main thread. A job runs only if nobody gave up on it: a request that timed out, or a server that
        // stopped, cancels the jobs still waiting, so a failed answer never edits the face later.
        private sealed class Job
        {
            internal Func<JArray> Work;
            internal int Generation;
            internal JArray Result;
            internal Exception Error;
            internal int State; // 0 waiting, 1 running, 2 cancelled, 3 done
            internal readonly ManualResetEventSlim Done = new ManualResetEventSlim();
        }

        private static readonly ConcurrentQueue<Job> jobs = new ConcurrentQueue<Job>();
        private static readonly ConcurrentQueue<Action> main = new ConcurrentQueue<Action>();
        private static readonly LinkedList<string> log = new LinkedList<string>();
        internal static event Action Changed;

        static McpServer()
        {
            EditorApplication.update += Pump;
            AssemblyReloadEvents.beforeAssemblyReload += Stop;
            EditorApplication.quitting += Stop;
            if (Enabled) EditorApplication.delayCall += Start;
        }

        internal static IEnumerable<string> Log
        {
            get { lock (log) return log.ToList(); }
        }

        private static void Record(string line)
        {
            lock (log)
            {
                log.AddFirst($"{DateTime.Now:HH:mm:ss} {line}");
                while (log.Count > 12) log.RemoveLast();
            }
            main.Enqueue(() => Changed?.Invoke());
        }

        internal static void Start()
        {
            Stop();
            try
            {
                token = Token;
                Interlocked.Increment(ref generation);
                listener = new HttpListener();
                listener.Prefixes.Add($"http://127.0.0.1:{Port}/");
                listener.Start();
                listener.BeginGetContext(OnContext, listener);
                Error = null;
            }
            catch (Exception e)
            {
                Error = e.Message;
                listener = null;
            }
            Changed?.Invoke();
        }

        internal static void Stop()
        {
            var old = listener;
            listener = null;
            Interlocked.Increment(ref generation);
            try { old?.Close(); }
            catch (ObjectDisposedException) { }
            while (jobs.TryDequeue(out var job)) Cancel(job, "MCP 서버가 꺼졌어요.");
            Changed?.Invoke();
        }

        private static void Pump()
        {
            while (main.TryDequeue(out var action)) action();
            while (jobs.TryDequeue(out var job))
            {
                if (job.Generation != Volatile.Read(ref generation) || listener == null)
                {
                    Cancel(job, "MCP 서버가 꺼졌거나 다시 켜졌어요.");
                    continue;
                }
                if (Interlocked.CompareExchange(ref job.State, 1, 0) != 0) continue;
                try { job.Result = job.Work(); }
                catch (Exception e) { job.Error = e; }
                finally
                {
                    job.State = 3;
                    job.Done.Set();
                }
            }
        }

        private static void Cancel(Job job, string why)
        {
            if (Interlocked.CompareExchange(ref job.State, 2, 0) != 0) return;
            job.Error = new OperationCanceledException(why);
            job.Done.Set();
        }

        // Runs on the main thread and waits for it (Unity's API is main-thread only). Not started in time, it is cancelled;
        // once started it is waited for, so the answer always says what happened.
        private static JArray OnMain(Func<JArray> work, int requested)
        {
            var job = new Job { Work = work, Generation = requested };
            jobs.Enqueue(job);
            if (!job.Done.Wait(TimeSpan.FromSeconds(90)))
            {
                Cancel(job, "Unity가 바빠서 답하지 못했어요. Unity 창을 한 번 눌러 주세요.");
                job.Done.Wait();
            }
            if (job.Error != null) throw job.Error;
            return job.Result;
        }

        private static void OnContext(IAsyncResult result)
        {
            var source = (HttpListener)result.AsyncState;
            HttpListenerContext context;
            try { context = source.EndGetContext(result); }
            catch (Exception) { return; }
            try { source.BeginGetContext(OnContext, source); }
            catch (Exception) { }
            try { Handle(context); }
            catch (Exception e)
            {
                try { Reply(context, 500, "text/plain", e.Message); }
                catch (Exception) { }
            }
        }

        private static bool Local(string host) => host == "127.0.0.1" || host == "localhost" || host == "[::1]";

        private static void Handle(HttpListenerContext context)
        {
            int requested = Volatile.Read(ref generation);
            var request = context.Request;
            // Only this computer: a page elsewhere could otherwise reach the editor through the browser (DNS rebinding).
            string origin = request.Headers["Origin"];
            if (!string.IsNullOrEmpty(origin) && (!Uri.TryCreate(origin, UriKind.Absolute, out var o) || !Local(o.Host)))
            {
                Reply(context, 403, "text/plain", "Forbidden origin");
                return;
            }
            string host = (request.Headers["Host"] ?? "").Split(':')[0];
            if (!Local(host))
            {
                Reply(context, 403, "text/plain", "Forbidden host");
                return;
            }
            if (request.Url.AbsolutePath.TrimEnd('/') != "/mcp")
            {
                Reply(context, 404, "text/plain", "Not found");
                return;
            }
            if (request.Headers["Authorization"] != "Bearer " + token)
            {
                Reply(context, 401, "text/plain", "Unauthorized");
                return;
            }
            // From 2025-06-18 on the client names the protocol version on every request; one this server does not
            // speak is refused, and so are batches, which those versions removed.
            string version = request.Headers["MCP-Protocol-Version"];
            if (!string.IsNullOrEmpty(version) && !Versions.Contains(version))
            {
                Reply(context, 400, "text/plain", "Unsupported MCP-Protocol-Version");
                return;
            }
            if (request.HttpMethod == "DELETE")
            {
                Reply(context, 200, "text/plain", "");
                return;
            }
            if (request.HttpMethod != "POST")
            {
                // No server-sent event stream: every answer comes back on its POST.
                Reply(context, 405, "text/plain", "Method not allowed");
                return;
            }
            string text;
            using (var reader = new StreamReader(request.InputStream, Encoding.UTF8)) text = reader.ReadToEnd();
            JToken message;
            try { message = JToken.Parse(text); }
            catch (JsonException)
            {
                Reply(context, 400, "application/json", Fault(null, -32700, "Parse error").ToString(Formatting.None));
                return;
            }
            JToken answer;
            if (message is JArray && !string.IsNullOrEmpty(version) && string.CompareOrdinal(version, "2025-06-18") >= 0)
            {
                Reply(context, 400, "application/json", Fault(null, -32600, "Batches are not supported in this protocol version").ToString(Formatting.None));
                return;
            }
            if (message is JArray batch)
            {
                var answers = new JArray(batch.OfType<JObject>().Select(m => Dispatch(m, requested)).Where(a => a != null));
                answer = answers.Count > 0 ? answers : null;
            }
            else answer = message is JObject single ? Dispatch(single, requested) : Fault(null, -32600, "Invalid request");
            if (answer == null) Reply(context, 202, "text/plain", "");
            else Reply(context, 200, "application/json", answer.ToString(Formatting.None));
        }

        private static void Reply(HttpListenerContext context, int status, string type, string body)
        {
            var bytes = Encoding.UTF8.GetBytes(body ?? "");
            context.Response.StatusCode = status;
            context.Response.ContentType = type + "; charset=utf-8";
            context.Response.ContentLength64 = bytes.Length;
            context.Response.OutputStream.Write(bytes, 0, bytes.Length);
            context.Response.OutputStream.Close();
        }

        private static JObject Fault(JToken id, int code, string message) => new JObject
        {
            ["jsonrpc"] = "2.0", ["id"] = id, ["error"] = new JObject { ["code"] = code, ["message"] = message },
        };

        // A request gets an answer; a notification or a client's response gets none.
        private static JObject Dispatch(JObject message, int requested)
        {
            var id = message["id"];
            string method = (string)message["method"];
            if (method == null || id == null) return null;
            try
            {
                JToken result;
                switch (method)
                {
                    case "initialize": result = Initialize(message["params"]); break;
                    case "ping": result = new JObject(); break;
                    case "tools/list": result = new JObject { ["tools"] = Tools() }; break;
                    case "tools/call": result = Call(message["params"], requested); break;
                    default: return Fault(id, -32601, "Method not found: " + method);
                }
                return new JObject { ["jsonrpc"] = "2.0", ["id"] = id, ["result"] = result };
            }
            catch (Exception e) { return Fault(id, -32603, e.Message); }
        }

        private static JObject Initialize(JToken parameters)
        {
            string asked = (string)parameters?["protocolVersion"];
            Record("연결됨 (" + ((string)parameters?["clientInfo"]?["name"] ?? "MCP 클라이언트") + ")");
            return new JObject
            {
                ["protocolVersion"] = Versions.Contains(asked) ? asked : Versions[1],
                ["capabilities"] = new JObject { ["tools"] = new JObject { ["listChanged"] = false } },
                ["serverInfo"] = new JObject { ["name"] = ServerName, ["version"] = "0.1.0" },
                ["instructions"] = "Edits the facial expression of the avatar chosen in Unity's AI Expression window. Call get_face_dictionary first, " +
                                   "then set_shapekeys with ids and values (0-100); capture_face shows the face; save_expression keeps it as a clip.",
            };
        }

        private static JObject Schema(JObject properties, params string[] required) => new JObject
        {
            ["type"] = "object", ["properties"] = properties, ["required"] = new JArray(required), ["additionalProperties"] = false,
        };

        private static JArray Tools()
        {
            JObject Tool(string name, string description, JObject schema) =>
                new JObject { ["name"] = name, ["description"] = description, ["inputSchema"] = schema };
            var changes = Schema(new JObject
            {
                ["changes"] = new JObject
                {
                    ["type"] = "array",
                    ["items"] = Schema(new JObject { ["id"] = new JObject { ["type"] = "integer" }, ["value"] = new JObject { ["type"] = "number" } }, "id", "value"),
                },
                ["reset_others"] = new JObject { ["type"] = "boolean", ["description"] = "Put every other face shape back to the avatar's default face first." },
            }, "changes");
            return new JArray(
                Tool("get_face_dictionary", "How to read the face dictionary, the dictionary (one line per face blendshape, by id) and the current values.", Schema(new JObject())),
                Tool("get_current_values", "The face blendshapes that are not at 0 now, as id=value.", Schema(new JObject())),
                Tool("set_shapekeys", "Set face blendshape weights by dictionary id, 0 to 100. One Undo step in Unity. Returns the values now.", changes),
                Tool("capture_face", "A front picture of the avatar's face as it is now.", Schema(new JObject())),
                Tool("reset_face", "Put every face shape back to the avatar's default face.", Schema(new JObject())),
                Tool("save_expression", "Save the current expression (what differs from the default face) as an animation clip.",
                    Schema(new JObject { ["name"] = new JObject { ["type"] = "string" } }, "name")));
        }

        private static JObject Call(JToken parameters, int requested)
        {
            string name = (string)parameters?["name"];
            var arguments = parameters?["arguments"] as JObject ?? new JObject();
            Record(name);
            try
            {
                var content = OnMain(() =>
                {
                    JObject Text(string text) => new JObject { ["type"] = "text", ["text"] = text };
                    switch (name)
                    {
                        case "get_face_dictionary":
                            return new JArray(Text(ExpressionCore.Instructions() + "\nCurrent values (others are 0): " + ExpressionCore.CurrentValues()));
                        case "get_current_values":
                            return new JArray(Text(ExpressionCore.CurrentValues()));
                        case "set_shapekeys":
                            var list = ExpressionAgent.Changes(arguments, out bool reset);
                            if (list == null) throw new ArgumentException("changes must be a list of {id, value}.");
                            return new JArray(Text(ExpressionCore.Apply(list, reset, "MCP")));
                        case "capture_face":
                            var png = ExpressionCore.Capture("MCP");
                            return new JArray(new JObject { ["type"] = "image", ["data"] = Convert.ToBase64String(png), ["mimeType"] = "image/png" });
                        case "reset_face":
                            return new JArray(Text(ExpressionCore.ResetFace("MCP")));
                        case "save_expression":
                            string clip = (string)arguments["name"];
                            if (string.IsNullOrWhiteSpace(clip)) throw new ArgumentException("name is required.");
                            return new JArray(Text("Saved: " + ExpressionCore.Save(clip, "MCP")));
                        default:
                            throw new ArgumentException("Unknown tool: " + name);
                    }
                }, requested);
                return new JObject { ["content"] = content, ["isError"] = false };
            }
            catch (Exception e)
            {
                return new JObject { ["content"] = new JArray(new JObject { ["type"] = "text", ["text"] = e.Message }), ["isError"] = true };
            }
        }
    }
}
#endif
