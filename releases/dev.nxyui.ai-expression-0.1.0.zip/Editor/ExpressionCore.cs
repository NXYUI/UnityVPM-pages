#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using VRC.SDK3.Avatars.Components;

namespace NXYUI.AIExpression
{
    // What both ways in (the Claude API from the window, and MCP from Claude Code) do to the face: one place, so they
    // behave the same. Runs on the main thread only.
    internal static class ExpressionCore
    {
        private const string Prefs = "NXYUI.AIExpression.";

        internal static bool UseCopies
        {
            get => EditorPrefs.GetBool(Prefs + "UseCopies", true);
            set => EditorPrefs.SetBool(Prefs + "UseCopies", value);
        }

        // Shapekey names cost tokens (once per cache window) but tell Claude much more than the geometry alone.
        internal static bool SendNames
        {
            get => EditorPrefs.GetBool(Prefs + "SendNames", true);
            set => EditorPrefs.SetBool(Prefs + "SendNames", value);
        }

        internal static VRCAvatarDescriptor Avatar { get; private set; }
        internal static FaceDictionary Dictionary { get; private set; }
        internal static WorkSession Session { get; private set; }
        // The last thing done to the face and by whom, for the window.
        internal static string Activity { get; private set; }
        internal static event Action Changed;

        internal static void Select(VRCAvatarDescriptor avatar)
        {
            if (avatar == Avatar) return;
            Avatar = avatar;
            Dictionary = null;
            Session = avatar ? WorkSession.Resume(avatar) : null;
            Changed?.Invoke();
        }

        private static void Note(string activity)
        {
            Activity = $"{DateTime.Now:HH:mm:ss} {activity}";
            Changed?.Invoke();
        }

        internal static FaceDictionary EnsureDictionary(bool rebuild = false)
        {
            if (!Avatar) throw new InvalidOperationException("AI Expression 창에서 아바타를 먼저 골라 주세요.");
            // A session's copies follow the dictionary it started with.
            if (rebuild && Session != null) throw new InvalidOperationException("작업 중에는 사전을 다시 만들 수 없어요. 작업을 먼저 끝내 주세요.");
            if (rebuild || Dictionary == null || Dictionary.Avatar != Avatar)
            {
                Dictionary = FaceDictionary.Build(Avatar);
                Changed?.Invoke();
            }
            if (Dictionary.Entries.Count == 0) throw new InvalidOperationException("얼굴 쉐이프키를 찾지 못했어요. 아바타의 Lip Sync 메시나 머리에 붙은 메시를 확인해 주세요.");
            return Dictionary;
        }

        internal static WorkSession EnsureSession()
        {
            var dictionary = EnsureDictionary();
            if (Session == null || !Session.Valid || Session.Avatar != Avatar)
            {
                Session?.End();
                Session = WorkSession.Start(dictionary, UseCopies);
                Note(UseCopies ? "작업본을 만들었어요" : "원본에서 바로 작업해요");
            }
            return Session;
        }

        // The prompt part both ways share: how to read the dictionary, then the dictionary. Stable for one avatar.
        internal static string Instructions()
        {
            var d = EnsureDictionary();
            bool names = SendNames;
            return "You edit the facial expression of a VRChat avatar by setting blendshape weights from 0 to 100.\n" +
                   "The face dictionary lists every face blendshape you may use, one per line: " +
                   (names ? "id|mesh|name|region|motion|strength|steps" : "id|mesh|region|motion|strength|steps") + ".\n" +
                   "region: where it moves (brows, eyes, between eyes, nose, cheeks, mouth, chin); L or R is the avatar's own left or right side, otherwise both sides.\n" +
                   "motion: the main way its vertices move (up, down, forward, back, sideways; spread means parts move apart, like a mouth opening).\n" +
                   "strength: how far it moves at 100 (subtle, medium, strong). steps above 1: it has in-between shapes.\n" +
                   (names ? "name: the avatar maker's name for it, often Japanese or English; trust it over the geometry when they disagree.\n" : "") +
                   "Use few shapes and natural values. Lip sync shapes (visemes) are left out: talking drives the mouth separately.\n" +
                   "Meshes: " + d.Meshes() + "\n\nFace dictionary:\n" + d.Text(names);
        }

        // The shapes that are not at 0 now, as id=value.
        internal static string CurrentValues()
        {
            var session = EnsureSession();
            var values = Dictionary.Entries.Select(e => (e.Id, Value: session.Get(e))).Where(v => v.Value > 0.01f)
                .Select(v => $"{v.Id}={v.Value:0.#}").ToList();
            return values.Count == 0 ? "(all 0)" : string.Join(", ", values);
        }

        internal static string Apply(IEnumerable<(int Id, float Value)> changes, bool resetOthers, string who)
        {
            var session = EnsureSession();
            var list = changes.ToList();
            int unknown = list.Count(c => Dictionary.Find(c.Id) == null);
            int applied = session.Apply(Dictionary, list, resetOthers, "AI Expression: " + who);
            Note($"{who}: 쉐이프키 {applied}개를 바꿨어요{(resetOthers ? " (나머지는 기본으로)" : "")}");
            return $"Applied {applied} change(s){(resetOthers ? " after resetting the others to the default face" : "")}." +
                   (unknown > 0 ? $" {unknown} id(s) are not in the dictionary and were skipped." : "") + " Now: " + CurrentValues();
        }

        internal static byte[] Capture(string who, int size = 512)
        {
            var session = EnsureSession();
            var png = FaceCapture.Png(Avatar, session, size);
            Note($"{who}: 얼굴을 찍었어요");
            return png;
        }

        internal static string ResetFace(string who)
        {
            EnsureSession().Reset(Dictionary);
            Note($"{who}: 기본 표정으로 되돌렸어요");
            return "Reset to the avatar's default face.";
        }

        internal static string Save(string name, string who)
        {
            string path = EnsureSession().SaveClip(Dictionary, name);
            Note($"{who}: 표정 클립을 저장했어요 · {path}");
            return path;
        }

        // Ends the session; keep: the working weights go to the originals first.
        internal static void Finish(bool keep)
        {
            if (Session == null) return;
            if (keep && Dictionary != null) Session.ApplyToOriginals(Dictionary);
            Session.End();
            Session = null;
            Note(keep ? "원본에 반영하고 작업을 끝냈어요" : "작업을 끝냈어요");
        }

        // A session whose copies Undo or the user removed is dropped, its originals shown again.
        internal static void Check()
        {
            // Ended without applying: a session whose meshes changed must not write to the originals.
            if (Session != null && !Session.Valid)
            {
                Session.End();
                Session = null;
                Changed?.Invoke();
            }
        }
    }
}
#endif
