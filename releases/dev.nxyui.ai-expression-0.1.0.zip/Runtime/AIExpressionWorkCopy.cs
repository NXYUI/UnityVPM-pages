using nadena.dev.ndmf;
using UnityEngine;

namespace NXYUI.AIExpression
{
    // Marks a working copy of a face mesh made by the AI Expression window. The copy is EditorOnly and never uploads; the
    // window finds copies left behind (an editor restart) and puts their originals back.
    [DisallowMultipleComponent]
    [AddComponentMenu("NXYUI/AI Expression Work Copy")]
    public sealed class AIExpressionWorkCopy : MonoBehaviour, INDMFEditorOnly
    {
        public SkinnedMeshRenderer source;
    }
}
