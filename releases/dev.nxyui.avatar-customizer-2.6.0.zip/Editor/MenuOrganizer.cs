#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using VRC.SDK3.Avatars.ScriptableObjects;
using Control = VRC.SDK3.Avatars.ScriptableObjects.VRCExpressionsMenu.Control;
using Object = UnityEngine.Object;

namespace AvatarMenuTools
{
    // The first edit of the avatar's finished menu ("원본 메뉴 정리"): renames, moves and hides, on a copy of the menu — the menu
    // assets are never changed. The build runs it before the favorites menus are made, so favorites see the organized
    // menu; the window runs the same code on a saved copy of the last read menu, so the favorites tab shows the
    // organized menu as soon as a rule changes, without building again.
    internal sealed class MenuOrganizer
    {
        internal delegate void ReportIssue(string title, string detail, bool warning, FavoriteMenuBuilder.RepairTarget target,
            int itemIndex, FavoriteMenuKey saved, FavoriteMenuKey current);

        private readonly Texture2D moreIcon;
        private readonly string pageLabel;
        private readonly HideFlags flags;
        private readonly ReportIssue report;

        // The menu as the avatar's tools built it: keys use its names and structure. Rules refer to these.
        internal readonly FavoriteMenuKey[] Original;
        internal readonly Dictionary<FavoriteMenuKey, Control> OriginalItems = new Dictionary<FavoriteMenuKey, Control>();
        // The organized copy (null without a menu) and its items. Keys keep each item's original name, so saved favorites
        // keep resolving; displayName carries the shown (renamed) name.
        internal readonly VRCExpressionsMenu Root;
        internal readonly FavoriteMenuKey[] Organized = Array.Empty<FavoriteMenuKey>();
        internal readonly Dictionary<FavoriteMenuKey, Control> OrganizedItems = new Dictionary<FavoriteMenuKey, Control>();
        // Every menu this organizer and later steps made: the build saves them, the window destroys them.
        internal readonly List<VRCExpressionsMenu> Created = new List<VRCExpressionsMenu>();
        // Each page of the copy that ends in a page link, and that link.
        internal readonly Dictionary<VRCExpressionsMenu, Control> PageLinks = new Dictionary<VRCExpressionsMenu, Control>();
        // Copies of the avatar's own items (not page links, not folders made here).
        internal readonly HashSet<Control> OriginalControls = new HashSet<Control>();
        internal readonly HashSet<Control> MovedControls = new HashSet<Control>();
        // Copies left out of the menu by "숨기기". They stay in OrganizedItems (marked hidden), so favorites can hold them.
        internal readonly HashSet<Control> HiddenControls = new HashSet<Control>();
        internal readonly string PageLabel;
        internal int NameCount => names.Count;
        internal int MoveCount => MovedControls.Count;
        internal int HideCount => HiddenControls.Count;

        private readonly Dictionary<FavoriteMenuKey, VRCExpressionsMenu> parentPages = new Dictionary<FavoriteMenuKey, VRCExpressionsMenu>();
        private readonly Dictionary<Control, string> names = new Dictionary<Control, string>();
        private readonly Dictionary<VRCExpressionsMenu, VRCExpressionsMenu> copies = new Dictionary<VRCExpressionsMenu, VRCExpressionsMenu>();
        private readonly Dictionary<Control, Control> controlCopies = new Dictionary<Control, Control>();
        private readonly Dictionary<Control, Control> originalOf = new Dictionary<Control, Control>();

        // pageLabel: the name for page links ("More"), or null to keep theirs. flags: for the menus made (a preview's
        // copies are kept out of the scene and assets).
        internal MenuOrganizer(VRCExpressionsMenu root, Texture2D moreIcon, string pageLabel,
            IReadOnlyList<MenuNameOverride> overrides, IReadOnlyList<MenuMoveRule> moves, IReadOnlyList<MenuHideRule> hides,
            ReportIssue report, HideFlags flags = HideFlags.None)
        {
            this.moreIcon = moreIcon;
            this.pageLabel = pageLabel;
            PageLabel = pageLabel ?? "More";
            this.flags = flags;
            this.report = report ?? ((t, d, w, target, i, s, c) => { });
            Original = WalkOriginal(root);

            for (int i = 0; i < (overrides?.Count ?? 0); i++)
            {
                var rule = overrides[i];
                if (rule?.source == null || string.IsNullOrWhiteSpace(rule.label)) continue;
                string title = $"이름 변경 / {rule.source.DisplayPath}";
                var key = Match(rule.source, title, FavoriteMenuBuilder.RepairTarget.NameOverride, i);
                if (key == null) continue;
                var control = OriginalItems[key];
                var label = rule.label.Trim();
                if (names.TryGetValue(control, out var prior) && prior != label)
                    this.report(title, $"공유 항목에 이미 ‘{prior}’ 이름이 적용되어 ‘{label}’ 변경을 제외했습니다.", true,
                        FavoriteMenuBuilder.RepairTarget.NameOverride, i, rule.source, null);
                else names[control] = label;
            }

            if (!root) return;
            Root = Clone(root);
            ApplyMoves(moves);
            FindHidden(hides);
            // Walked before hidden items leave their pages, so they keep their place (and paths) in the list.
            Organized = WalkOrganized();
            RemoveHidden();
            if (MoveCount > 0 || HideCount > 0) CloseGaps();
        }

        // ---------------------------------------------------------------- the original menu

        internal bool IsOriginalPage(VRCExpressionsMenu menu, Control c) =>
            menu.controls?.Count == VRCExpressionsMenu.MAX_CONTROLS &&
            c != null && c == menu.controls.LastOrDefault() && c.type == Control.ControlType.SubMenu &&
            c.subMenu && string.IsNullOrEmpty(c.parameter?.name) && FavoriteMenuBuilder.IsMoreLink(c, moreIcon);

        private FavoriteMenuKey[] WalkOriginal(VRCExpressionsMenu root)
        {
            var keys = new List<FavoriteMenuKey>();
            var groups = new Dictionary<Control, int>();
            void Walk(VRCExpressionsMenu menu, string[] path, HashSet<VRCExpressionsMenu> active, int depth)
            {
                if (!menu || menu.controls == null || depth > 64 || !active.Add(menu)) return;
                foreach (var c in menu.controls)
                {
                    if (c == null) continue;
                    if (IsOriginalPage(menu, c))
                    {
                        Walk(c.subMenu, path, active, depth);
                        continue;
                    }
                    var next = path.Concat(new[] { c.name ?? "" }).ToArray();
                    if (!groups.TryGetValue(c, out int group)) groups.Add(c, group = groups.Count + 1);
                    var key = KeyOf(c, next, group);
                    OriginalItems.Add(key, c);
                    parentPages.Add(key, menu);
                    keys.Add(key);
                    if (c.type == Control.ControlType.SubMenu) Walk(c.subMenu, next, active, depth + 1);
                }
                active.Remove(menu);
            }
            Walk(root, Array.Empty<string>(), new HashSet<VRCExpressionsMenu>(), 0);
            return keys.ToArray();
        }

        private static FavoriteMenuKey KeyOf(Control c, string[] path, int group) => new FavoriteMenuKey
        {
            path = path, type = c.type, value = c.value, sharedControl = group,
            parameter = c.parameter?.name ?? "",
            subParameters = (c.subParameters ?? Array.Empty<Control.Parameter>()).Select(p => p?.name ?? "").ToArray(),
        };

        private FavoriteMenuKey Match(FavoriteMenuKey saved, string title, FavoriteMenuBuilder.RepairTarget target, int index)
        {
            var current = FavoriteMenuKey.Resolve(Original, saved, out var match);
            if (match != FavoriteMenuMatch.Exact)
                report(title, FavoriteMenuBuilder.MatchDetail(match), match != FavoriteMenuMatch.Moved, target, index, saved, current);
            return current;
        }

        // ---------------------------------------------------------------- the copy

        internal string NameOf(Control original) => names.TryGetValue(original, out var label) ? label : original.name;

        private VRCExpressionsMenu Clone(VRCExpressionsMenu original)
        {
            if (!original) return null;
            if (copies.TryGetValue(original, out var existing)) return existing;
            var clone = Object.Instantiate(original);
            clone.name = original.name;
            clone.hideFlags = flags;
            copies.Add(original, clone);
            Created.Add(clone);
            clone.controls = new List<Control>();
            foreach (var c in original.controls ?? new List<Control>())
            {
                if (c == null) continue;
                bool isPage = IsOriginalPage(original, c);
                var copy = FavoriteMenuBuilder.Copy(c, isPage && pageLabel != null ? pageLabel : NameOf(c), Clone);
                clone.controls.Add(copy);
                if (isPage) PageLinks.Add(clone, copy);
                else
                {
                    OriginalControls.Add(copy);
                    controlCopies[c] = copy;
                    originalOf[copy] = c;
                }
            }
            return clone;
        }

        internal VRCExpressionsMenu NewMenu(string name)
        {
            var menu = FavoriteMenuBuilder.NewMenu(name, Created);
            menu.hideFlags = flags;
            return menu;
        }

        // The pages of a menu level, following its page links.
        internal IEnumerable<VRCExpressionsMenu> Pages(VRCExpressionsMenu first)
        {
            var seen = new HashSet<VRCExpressionsMenu>();
            for (var page = first; page && seen.Add(page); page = PageLinks.TryGetValue(page, out var link) ? link.subMenu : null)
                yield return page;
        }

        // Splits an overfull page into pages behind page links; returns the last page.
        internal VRCExpressionsMenu Paginate(VRCExpressionsMenu page)
        {
            int keep = VRCExpressionsMenu.MAX_CONTROLS - 1;
            while (page.controls.Count > VRCExpressionsMenu.MAX_CONTROLS)
            {
                var next = NewMenu(page.name + " (More)");
                next.controls.AddRange(page.controls.Skip(keep));
                page.controls.RemoveRange(keep, page.controls.Count - keep);
                var link = FavoriteMenuBuilder.Submenu(PageLabel, next);
                link.icon = moreIcon;
                page.controls.Add(link);
                PageLinks.Add(page, link);
                page = next;
            }
            return page;
        }

        // The page (1 = first) of a menu level that holds item; 0 when it is not there.
        internal int PageOf(VRCExpressionsMenu first, Control item)
        {
            int number = 1;
            foreach (var page in Pages(first))
            {
                if (page.controls.Contains(item)) return number;
                number++;
            }
            return 0;
        }

        // The page of each of the avatar's own items on a menu level.
        internal Dictionary<Control, int> OriginalPages(VRCExpressionsMenu first)
        {
            var result = new Dictionary<Control, int>();
            int number = 1;
            foreach (var page in Pages(first))
            {
                foreach (var control in page.controls)
                    if (OriginalControls.Contains(control)) result[control] = number;
                number++;
            }
            return result;
        }

        // Puts control at slot of the first page, pushing the rest along the pages; returns the last page.
        internal VRCExpressionsMenu InsertPinned(VRCExpressionsMenu first, int slot, Control control)
        {
            var page = first;
            page.controls.Insert(slot, control);
            int keep = VRCExpressionsMenu.MAX_CONTROLS - 1;
            while (PageLinks.TryGetValue(page, out var link))
            {
                if (page.controls.Count > VRCExpressionsMenu.MAX_CONTROLS)
                {
                    int count = page.controls.Count - keep - 1;
                    link.subMenu.controls.InsertRange(0, page.controls.GetRange(keep, count));
                    page.controls.RemoveRange(keep, count);
                }
                page = link.subMenu;
            }
            return Paginate(page);
        }

        // ---------------------------------------------------------------- moves

        // Each item leaves its page for the end of its new menu; pages left with gaps are filled from the pages after them.
        private void ApplyMoves(IReadOnlyList<MenuMoveRule> moves)
        {
            if ((moves?.Count ?? 0) == 0) return;
            var folders = new Dictionary<string, VRCExpressionsMenu>();
            // The top-level submenu of that name (as shown, so after renames), or a new one at the end of the top level.
            VRCExpressionsMenu Folder(string name)
            {
                if (folders.TryGetValue(name, out var folder)) return folder;
                var links = new HashSet<Control>(PageLinks.Values);
                var existing = Pages(Root).SelectMany(p => p.controls).FirstOrDefault(c =>
                    c != null && !links.Contains(c) && c.type == Control.ControlType.SubMenu && c.subMenu && c.name == name);
                if (existing != null) folder = existing.subMenu;
                else
                {
                    folder = NewMenu(name);
                    var last = Pages(Root).Last();
                    last.controls.Add(FavoriteMenuBuilder.Submenu(name, folder));
                    Paginate(last);
                }
                folders.Add(name, folder);
                return folder;
            }

            var moving = new HashSet<Control>();
            for (int i = 0; i < moves.Count; i++)
            {
                var rule = moves[i];
                if (rule?.source == null) continue;
                string title = $"이동 / {rule.source.DisplayPath}";
                var key = Match(rule.source, title, FavoriteMenuBuilder.RepairTarget.Move, i);
                if (key == null) continue;
                var original = OriginalItems[key];
                if (!moving.Add(original))
                {
                    report(title, "같은 항목을 옮기는 설정이 앞에 있어 이 설정은 제외했습니다.", true,
                        FavoriteMenuBuilder.RepairTarget.Move, i, rule.source, key);
                    continue;
                }
                VRCExpressionsMenu target;
                string where;
                if (rule.Folder != null)
                {
                    where = $"최상위 ‘{rule.Folder}’ 폴더";
                    target = Folder(rule.Folder);
                }
                else if (rule.ToRoot)
                {
                    where = "최상위 메뉴";
                    target = Root;
                }
                else
                {
                    var destinationKey = Match(rule.destination, title + " · 옮길 위치", FavoriteMenuBuilder.RepairTarget.MoveDestination, i);
                    if (destinationKey == null) continue;
                    var destination = OriginalItems[destinationKey];
                    if (destination.type != Control.ControlType.SubMenu || !destination.subMenu)
                    {
                        report(title, "옮길 위치가 하위 메뉴가 아니라 옮기지 않았습니다.", true,
                            FavoriteMenuBuilder.RepairTarget.MoveDestination, i, rule.destination, destinationKey);
                        continue;
                    }
                    where = $"‘{NameOf(destination)}’";
                    target = Clone(destination.subMenu);
                }
                var copy = controlCopies.TryGetValue(original, out var found) ? found : null;
                // Earlier moves only push items to later pages, so look from the original page on.
                var from = copy == null ? null : Pages(Clone(parentPages[key])).FirstOrDefault(p => p.controls.Contains(copy));
                if (from == null)
                {
                    report(title, "빌드 메뉴에서 이 항목의 자리를 찾지 못해 옮기지 않았습니다.", true,
                        FavoriteMenuBuilder.RepairTarget.None, i, null, null);
                    continue;
                }
                if (copy.type == Control.ControlType.SubMenu && copy.subMenu &&
                    FavoriteMenuBuilder.Reaches(copy.subMenu, target, null, new HashSet<VRCExpressionsMenu>()))
                {
                    report(title, $"옮길 위치({where})가 이 메뉴 자신이거나 그 안에 있어 옮길 수 없습니다.", true,
                        FavoriteMenuBuilder.RepairTarget.MoveDestination, i, rule.destination, null);
                    continue;
                }
                if (Pages(target).Contains(from))
                {
                    report(title, $"이미 {where}에 있어 옮기지 않았습니다.", false, FavoriteMenuBuilder.RepairTarget.None, i, null, null);
                    continue;
                }
                from.controls.Remove(copy);
                var end = Pages(target).Last();
                end.controls.Add(copy);
                Paginate(end);
                MovedControls.Add(copy);
            }
        }

        // ---------------------------------------------------------------- hides

        private void FindHidden(IReadOnlyList<MenuHideRule> hides)
        {
            for (int i = 0; i < (hides?.Count ?? 0); i++)
            {
                var rule = hides[i];
                if (rule?.source == null) continue;
                string title = $"숨기기 / {rule.source.DisplayPath}";
                var key = Match(rule.source, title, FavoriteMenuBuilder.RepairTarget.Hide, i);
                if (key == null) continue;
                if (controlCopies.TryGetValue(OriginalItems[key], out var copy)) HiddenControls.Add(copy);
                else report(title, "빌드 메뉴에서 이 항목의 자리를 찾지 못해 숨기지 않았습니다.", true,
                    FavoriteMenuBuilder.RepairTarget.None, i, null, null);
            }
        }

        // Each hidden item leaves the page it ended up on after the moves; CloseGaps fills the gap.
        private void RemoveHidden()
        {
            foreach (var copy in HiddenControls)
                Created.FirstOrDefault(m => m && m.controls != null && m.controls.Contains(copy))?.controls.Remove(copy);
        }

        // Pull items up from the next page while a page has room; a used-up page is dropped.
        private void CloseGaps()
        {
            var linked = new HashSet<VRCExpressionsMenu>(PageLinks.Values.Select(l => l.subMenu));
            foreach (var first in Created.Where(m => m && PageLinks.ContainsKey(m) && !linked.Contains(m)).ToArray())
            {
                var page = first;
                for (int guard = 0; guard < 4096 && PageLinks.TryGetValue(page, out var link); guard++)
                {
                    var next = link.subMenu;
                    bool nextLinks = PageLinks.TryGetValue(next, out var nextLink);
                    int keepLink = nextLinks ? 1 : 0;
                    while (page.controls.Count < VRCExpressionsMenu.MAX_CONTROLS && next.controls.Count > keepLink)
                    {
                        var item = next.controls[0];
                        next.controls.RemoveAt(0);
                        page.controls.Insert(page.controls.Count - 1, item);
                    }
                    if (next.controls.Count > keepLink) { page = next; continue; }
                    PageLinks.Remove(next);
                    if (nextLinks) link.subMenu = nextLink.subMenu;
                    else
                    {
                        page.controls.Remove(link);
                        PageLinks.Remove(page);
                    }
                }
            }
        }

        // ---------------------------------------------------------------- the organized menu

        private FavoriteMenuKey[] WalkOrganized()
        {
            var keys = new List<FavoriteMenuKey>();
            var groups = new Dictionary<Control, int>();
            void Walk(VRCExpressionsMenu menu, string[] path, HashSet<VRCExpressionsMenu> active, int depth, bool hidden)
            {
                if (!menu || menu.controls == null || depth > 64 || !active.Add(menu)) return;
                foreach (var c in menu.controls)
                {
                    if (c == null) continue;
                    if (PageLinks.TryGetValue(menu, out var link) && link == c)
                    {
                        Walk(c.subMenu, path, active, depth, hidden);
                        continue;
                    }
                    string name = originalOf.TryGetValue(c, out var original) ? original.name ?? "" : c.name ?? "";
                    var next = path.Concat(new[] { name }).ToArray();
                    if (!groups.TryGetValue(c, out int group)) groups.Add(c, group = groups.Count + 1);
                    var key = KeyOf(c, next, group);
                    key.displayName = c.name ?? "";
                    key.hidden = hidden || HiddenControls.Contains(c);
                    OrganizedItems.Add(key, c);
                    keys.Add(key);
                    if (c.type == Control.ControlType.SubMenu) Walk(c.subMenu, next, active, depth + 1, key.hidden);
                }
                active.Remove(menu);
            }
            Walk(Root, Array.Empty<string>(), new HashSet<VRCExpressionsMenu>(), 0, false);
            return keys.ToArray();
        }

        // A copy of a menu tree kept apart from the build's assets (so the window can organize it again later).
        // Page links stay recognizable: names, icons and order are kept.
        internal static VRCExpressionsMenu Snapshot(VRCExpressionsMenu root, List<VRCExpressionsMenu> made)
        {
            var map = new Dictionary<VRCExpressionsMenu, VRCExpressionsMenu>();
            VRCExpressionsMenu Copy(VRCExpressionsMenu menu)
            {
                if (!menu) return null;
                if (map.TryGetValue(menu, out var existing)) return existing;
                var copy = ScriptableObject.CreateInstance<VRCExpressionsMenu>();
                copy.name = menu.name;
                copy.hideFlags = HideFlags.HideAndDontSave;
                map.Add(menu, copy);
                made.Add(copy);
                copy.controls = (menu.controls ?? new List<Control>()).Where(c => c != null)
                    .Select(c => FavoriteMenuBuilder.Copy(c, c.name, Copy)).ToList();
                return copy;
            }
            return Copy(root);
        }
    }
}
#endif
