#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Linq;
using nadena.dev.ndmf;
using nadena.dev.ndmf.platform;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using VRC.SDK3.Avatars.Components;
using VRC.SDK3.Avatars.ScriptableObjects;
using Control = VRC.SDK3.Avatars.ScriptableObjects.VRCExpressionsMenu.Control;
using Object = UnityEngine.Object;

namespace AvatarMenuTools
{
    internal sealed partial class AvatarCustomizerWindow : EditorWindow
    {
        // Every NXYUI package puts its windows under the top-level "NXYUI" menu (checked by tools/test_build_repo.py).
        private const string MenuPath = "NXYUI/Avatar Customizer";
        [SerializeField] private VRCAvatarDescriptor avatar;
        [SerializeField] private string search = "";
        [SerializeField] private int tab;
        [SerializeField] private int menuIndex;
        [SerializeField] private bool fastScan = true;
        private string lastScanMode;
        // The read menu as the avatar's tools built it ("원본 메뉴 정리" works on it) ...
        private FavoriteMenuKey[] catalogue = Array.Empty<FavoriteMenuKey>();
        // ... and after its renames, moves and hides (the favorites tab works on it). Organized again from a copy of the read
        // menu (tree) whenever the component changes, so the favorites tab follows "원본 메뉴 정리" without a build.
        private FavoriteMenuKey[] organized = Array.Empty<FavoriteMenuKey>();
        private VRCExpressionsMenu tree;
        private List<VRCExpressionsMenu> treeMenus = new List<VRCExpressionsMenu>();
        private string organizedFor;
        private FavoriteMenuBuilder.Issue[] organizeIssues = Array.Empty<FavoriteMenuBuilder.Issue>();
        private int organizedNames, organizedMoves, organizedHides;
        private readonly List<(string Name, PreviewPage Page)> organizedPath = new List<(string, PreviewPage)>();
        private bool showOrganized;
        private Vector2 organizedScroll;
        private FavoriteMenuKey selectedKey;
        private string addParent = "";
        private readonly HashSet<string> collapsed = new HashSet<string>();
        private Vector2 optionsScroll, favoritesScroll;
        private bool scanning;
        private string status;
        private MessageType statusType;

        [MenuItem(MenuPath)]
        private static void Open()
        {
            var window = GetWindow<AvatarCustomizerWindow>("Avatar Customizer");
            window.minSize = new Vector2(740, 420);
            if (Selection.activeGameObject)
            {
                var selected = Selection.activeGameObject.GetComponentInParent<VRCAvatarDescriptor>(true);
                if (IsSceneAvatar(selected)) window.SelectAvatar(selected);
            }
            window.Show();
        }

        private static bool IsSceneAvatar(VRCAvatarDescriptor selected) =>
            selected && !EditorUtility.IsPersistent(selected) && selected.gameObject.scene.IsValid() &&
            selected.gameObject.scene.isLoaded && !EditorSceneManager.IsPreviewScene(selected.gameObject.scene) &&
            PrefabStageUtility.GetPrefabStage(selected.gameObject) == null;

        private void SelectAvatar(VRCAvatarDescriptor selected)
        {
            if (avatar == selected) return;
            avatar = selected;
            catalogue = Array.Empty<FavoriteMenuKey>();
            SetTree(null, null);
            ClearReview();
            batchSources.Clear();
            parameterDefaults = new Dictionary<string, float>();
            shapeRenderersDirty = true;
            selectedKey = null;
            SelectMenu(0);
            status = null;
            optionsScroll = Vector2.zero;
        }

        private void SelectMenu(int index)
        {
            menuIndex = index;
            addParent = "";
            collapsed.Clear();
            batchEntries.Clear();
            favoritesScroll = Vector2.zero;
        }

        private void Change(string action, Action<AvatarCustomizer> edit)
        {
            if (!IsSceneAvatar(avatar)) return;
            var config = avatar.GetComponent<AvatarCustomizer>();
            if (!config) config = Undo.AddComponent<AvatarCustomizer>(avatar.gameObject);
            Undo.RecordObject(config, action);
            edit(config);
            PrefabUtility.RecordPrefabInstancePropertyModifications(config);
            EditorUtility.SetDirty(config);
            EditorSceneManager.MarkSceneDirty(config.gameObject.scene);
            reviewStale = true;
        }

        private void ChangeEntries(string action, Action<List<FavoriteMenuEntry>> edit)
        {
            Change(action, c =>
            {
                if (menuIndex == 0) edit(c.entries ??= new List<FavoriteMenuEntry>());
                else if (c.GetMenu(menuIndex) is FavoriteMenuGroup menu)
                    edit(menu.entries ??= new List<FavoriteMenuEntry>());
            });
        }

        private void SetLocation(FavoriteMenuKey key)
        {
            Change("Move favorites menu", c =>
            {
                if (menuIndex == 0)
                {
                    c.useRoot = key == null;
                    if (key != null) c.destination = key;
                }
                else if (c.GetMenu(menuIndex) is FavoriteMenuGroup menu)
                {
                    menu.useRoot = key == null;
                    if (key != null) menu.destination = key;
                }
            });
        }

        private void DrawMenuSelector(AvatarCustomizer config)
        {
            int count = config ? config.additionalMenus?.Count ?? 0 : 0;
            if (menuIndex < 0 || menuIndex > count || (menuIndex != 0 && config.GetMenu(menuIndex) == null)) SelectMenu(0);
            var names = Enumerable.Range(0, count + 1).Select(i =>
                $"{i + 1}. {(config ? config.GetMenu(i)?.DisplayName ?? "이름 없는 메뉴" : "즐겨찾기")}").ToArray();
            using (new EditorGUILayout.HorizontalScope())
            {
                int index = EditorGUILayout.Popup("편집할 메뉴", menuIndex, names);
                if (index != menuIndex) { SelectMenu(index); GUIUtility.ExitGUI(); }
                if (GUILayout.Button(new GUIContent("가져오기", "열린 씬의 다른 아바타에 있는 즐겨찾기 설정을 이 아바타로 복사합니다."),
                    GUILayout.Width(64))) ShowImport();
                if (GUILayout.Button("+ 메뉴", GUILayout.Width(72)))
                {
                    var used = new HashSet<string>(Enumerable.Range(0, count + 1)
                        .Select(i => config ? config.GetMenu(i)?.DisplayName : "즐겨찾기"));
                    string label = "새 메뉴";
                    for (int i = 2; used.Contains(label); i++) label = "새 메뉴 " + i;
                    Change("Add favorites menu", c =>
                        (c.additionalMenus ??= new List<FavoriteMenuGroup>()).Add(new FavoriteMenuGroup { name = label }));
                    SelectMenu(count + 1);
                    GUIUtility.ExitGUI();
                }
                using (new EditorGUI.DisabledScope(menuIndex == 0))
                    if (GUILayout.Button("메뉴 삭제", GUILayout.Width(72)) && EditorUtility.DisplayDialog(
                        "메뉴 삭제", $"‘{config.GetMenu(menuIndex).DisplayName}’ 메뉴와 그 안의 즐겨찾기 설정을 삭제할까요?", "삭제", "취소"))
                    {
                        Change("Remove favorites menu", c => c.additionalMenus.RemoveAt(menuIndex - 1));
                        SelectMenu(Math.Max(0, menuIndex - 1));
                        GUIUtility.ExitGUI();
                    }
            }
        }

        private void OnGUI()
        {
            using (new EditorGUILayout.HorizontalScope())
            {
                using (new EditorGUI.DisabledScope(scanning))
                    SelectAvatar((VRCAvatarDescriptor)EditorGUILayout.ObjectField("아바타", avatar, typeof(VRCAvatarDescriptor), true));
                fastScan = GUILayout.Toggle(fastScan, new GUIContent("빠른 읽기",
                    "Modular Avatar가 메뉴를 설치하는 단계까지만 NDMF를 실행하고 최적화 단계는 건너뜁니다. " +
                    "끄면 실제 업로드처럼 전체 빌드로 읽습니다. 빠른 읽기가 실패하면 자동으로 전체 빌드로 읽습니다."),
                    EditorStyles.miniButton, GUILayout.Width(64));
                using (new EditorGUI.DisabledScope(!IsSceneAvatar(avatar) || scanning || EditorApplication.isPlayingOrWillChangePlaymode))
                {
                    if (GUILayout.Button(new GUIContent("비교", "빠른 읽기와 전체 빌드를 모두 실행해 결과가 같은지 확인합니다. " +
                        "다르면 ‘빠른 읽기’를 끄고 전체 빌드 결과를 보여 줍니다. 전체 빌드만큼 시간이 더 걸립니다."),
                        EditorStyles.miniButton, GUILayout.Width(40)))
                        QueueScan(compare: true);
                    if (GUILayout.Button("빌드 메뉴 읽기", GUILayout.Width(116)))
                        QueueScan();
                }
            }
            if (!IsSceneAvatar(avatar))
            {
                EditorGUILayout.HelpBox("Hierarchy에서 아바타를 선택하거나 위 필드에 Avatar Descriptor를 넣어 주세요.", MessageType.Info);
                return;
            }
            if (EditorApplication.isPlayingOrWillChangePlaymode)
            {
                EditorGUILayout.HelpBox("플레이 모드를 종료한 뒤 설정해 주세요.", MessageType.Info);
                return;
            }
            if (scanning)
                EditorGUILayout.HelpBox("복제본에서 빌드 메뉴를 읽고 있습니다.", MessageType.Info);
            else if (!string.IsNullOrEmpty(status))
                EditorGUILayout.HelpBox(status, statusType);

            var config = avatar.GetComponent<AvatarCustomizer>();
            using (new EditorGUI.DisabledScope(scanning))
            {
                // Shown in working order (organize first, then favorites); tab keeps its ids (0 favorites, 1 organize, ...).
                int[] order = { 1, 0, 2, 3 };
                int nextTab = order[GUILayout.Toolbar(Math.Max(0, Array.IndexOf(order, tab)),
                    new[] { "원본 메뉴 정리", "즐겨찾기 편집", "블렌드쉐이프", "빌드 결과" })];
                if (nextTab != tab)
                {
                    // The two tabs list different menus (as built / organized): follow the selected item across.
                    if (selectedKey != null && (tab == 1) != (nextTab == 1))
                        selectedKey = FavoriteMenuKey.Resolve(nextTab == 1 ? catalogue : organized, selectedKey);
                    tab = nextTab;
                    favoritesScroll = Vector2.zero;
                }
                Organize(config);
                if (tab == 3)
                {
                    DrawReview(config);
                    return;
                }
                if (tab == 2)
                {
                    DrawBlendshapes(config);
                    return;
                }
                if (tab == 0) DrawMenuSelector(config);
                var view = tab == 1 ? new MenuView(catalogue, config) : new MenuView(organized, config, organizedView: true);
                var activeMenu = config ? config.GetMenu(menuIndex) : null;
                if (tab == 0) DrawOrganizedNote();
                else EditorGUILayout.LabelField("왼쪽에서 빌드 메뉴를 고르세요. 이름 변경과 이동은 즐겨찾기 편집보다 먼저 적용돼요. " +
                                                "설정은 아바타별로 씬에 저장돼요.", EditorStyles.wordWrappedMiniLabel);
                using (new EditorGUILayout.HorizontalScope())
                {
                    using (new EditorGUILayout.VerticalScope(GUILayout.Width(position.width * .48f)))
                        if (tab == 0 && showOrganized && tree) DrawPreviewPage(organizedPath, ref organizedScroll, "정리된 메뉴 미리보기",
                            "읽은 메뉴가 비어 있어요.");
                        else DrawOptions(view, activeMenu);
                    using (new EditorGUILayout.VerticalScope(GUILayout.ExpandWidth(true)))
                        if (tab == 0) DrawFavorites(activeMenu, view);
                        else DrawNames(config, view);
                }
            }
        }

        private sealed class MenuView
        {
            private readonly FavoriteMenuKey[] keys;
            private readonly Dictionary<FavoriteMenuKey, (FavoriteMenuKey Key, FavoriteMenuMatch Match)> resolved =
                new Dictionary<FavoriteMenuKey, (FavoriteMenuKey, FavoriteMenuMatch)>();
            internal readonly Dictionary<int, int> RuleByControl = new Dictionary<int, int>();
            internal readonly Dictionary<int, int> MoveByControl = new Dictionary<int, int>();
            internal readonly Dictionary<int, int> HideByControl = new Dictionary<int, int>();
            private readonly List<MenuMoveRule> moves;
            private readonly Dictionary<int, string> labels = new Dictionary<int, string>();
            private readonly Dictionary<string, FavoriteMenuKey> paths;

            internal FavoriteMenuKey[] Keys => keys;

            internal MenuView(FavoriteMenuKey[] catalogue, AvatarCustomizer config) : this(catalogue, config, false) { }

            // organizedView: keys of the organized menu, whose shown names (displayName) already include the renames.
            internal MenuView(FavoriteMenuKey[] catalogue, AvatarCustomizer config, bool organizedView)
            {
                keys = catalogue;
                paths = keys.Where(x => x.type == Control.ControlType.SubMenu)
                    .GroupBy(x => string.Join("\u001f", x.path))
                    .Where(g => g.Count() == 1).ToDictionary(g => g.Key, g => g.First());
                if (!config || organizedView) return;
                for (int i = 0; i < (config.nameOverrides?.Count ?? 0); i++)
                {
                    var rule = config.nameOverrides[i];
                    var key = Resolve(rule?.source);
                    if (key == null || RuleByControl.ContainsKey(key.sharedControl)) continue;
                    RuleByControl.Add(key.sharedControl, i);
                    if (!string.IsNullOrWhiteSpace(rule.label)) labels.Add(key.sharedControl, rule.label.Trim());
                }
                moves = config.menuMoves;
                for (int i = 0; i < (moves?.Count ?? 0); i++)
                {
                    var key = Resolve(moves[i]?.source);
                    if (key != null && !MoveByControl.ContainsKey(key.sharedControl)) MoveByControl.Add(key.sharedControl, i);
                }
                var hides = config.hiddenItems;
                for (int i = 0; i < (hides?.Count ?? 0); i++)
                {
                    var key = Resolve(hides[i]?.source);
                    if (key != null && !HideByControl.ContainsKey(key.sharedControl)) HideByControl.Add(key.sharedControl, i);
                }
            }

            // "숨김" for a hidden item, "숨김(상위 메뉴)" inside a hidden submenu unless it is moved out; null otherwise.
            internal string HideOf(FavoriteMenuKey key)
            {
                if (HideByControl.ContainsKey(key.sharedControl)) return "숨김";
                if (MoveByControl.ContainsKey(key.sharedControl)) return null;
                for (int i = key.path.Length - 1; i > 0; i--)
                {
                    if (!paths.TryGetValue(string.Join("\u001f", key.path.Take(i)), out var parent)) continue;
                    if (HideByControl.ContainsKey(parent.sharedControl)) return "숨김(상위 메뉴)";
                    if (MoveByControl.ContainsKey(parent.sharedControl)) return null;
                }
                return null;
            }

            // Where a move rule takes its item, as the build menu names it.
            internal string MoveTarget(MenuMoveRule rule)
            {
                if (rule.Folder != null) return $"최상위 ‘{rule.Folder}’ 폴더";
                if (rule.ToRoot) return "최상위";
                var target = Resolve(rule.destination);
                if (target != null) return Display(target);
                string saved = rule.destination?.DisplayPath ?? "";
                return keys.Length == 0 ? saved : "⚠ " + saved + " (찾을 수 없음)";
            }

            // The move target of an item, or null when it stays.
            internal string MoveOf(FavoriteMenuKey key) =>
                MoveByControl.TryGetValue(key.sharedControl, out int i) && moves?[i] != null ? MoveTarget(moves[i]) : null;

            internal FavoriteMenuKey Resolve(FavoriteMenuKey key) => Resolve(key, out _);

            internal FavoriteMenuKey Resolve(FavoriteMenuKey key, out FavoriteMenuMatch match)
            {
                match = FavoriteMenuMatch.Missing;
                if (key == null) return null;
                if (!resolved.TryGetValue(key, out var result))
                {
                    var resolvedKey = FavoriteMenuKey.Resolve(keys, key, out match);
                    resolved.Add(key, result = (resolvedKey, match));
                }
                match = result.Match;
                return result.Key;
            }

            internal string Name(FavoriteMenuKey key) =>
                labels.TryGetValue(key.sharedControl, out var name) ? name : key.displayName ?? key.Name;

            internal string Display(FavoriteMenuKey key)
            {
                var parts = (string[])key.path.Clone();
                for (int i = 0; i < parts.Length - 1; i++)
                    if (paths.TryGetValue(string.Join("\u001f", key.path.Take(i + 1)), out var parent))
                        parts[i] = Name(parent);
                parts[parts.Length - 1] = Name(key);
                return string.Join(" / ", parts.Select(p => string.IsNullOrWhiteSpace(p) ? "(이름 없음)" : p));
            }
        }

        private void DrawOptions(MenuView view, FavoriteMenuGroup menu)
        {
            var catalogue = view.Keys;
            EditorGUILayout.LabelField(tab == 0 && tree ? $"정리된 빌드 메뉴 · {catalogue.Length}개" : $"빌드 메뉴 · {catalogue.Length}개",
                EditorStyles.boldLabel);
            search = EditorGUILayout.TextField(search, EditorStyles.toolbarSearchField);
            var terms = (search ?? "").Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            using var scroll = new EditorGUILayout.ScrollViewScope(optionsScroll, GUILayout.ExpandHeight(true));
            optionsScroll = scroll.scrollPosition;
            if (catalogue.Length == 0)
                EditorGUILayout.HelpBox("‘빌드 메뉴 읽기’로 생성된 메뉴를 불러오세요.", MessageType.Info);
            var currentFolder = menu?.entries?.Where(e => e != null && !e.IsFolder && e.Parent == addParent)
                .Select(e => view.Resolve(e.source)?.sharedControl ?? 0).ToHashSet() ?? new HashSet<int>();
            var itemStyle = new GUIStyle(EditorStyles.miniButton) { alignment = TextAnchor.MiddleLeft, clipping = TextClipping.Clip };

            foreach (var key in catalogue)
            {
                string path = view.Display(key);
                if (tab == 1 && view.MoveOf(key) is string moveTo) path += "  ⇢ " + moveTo;
                if (tab == 1 && view.HideOf(key) is string hide) path += "  · " + hide;
                if (tab == 0 && key.hidden) path += "  · 숨김";
                // Keep the filtered rows stable while the label field is being edited.
                var searchable = key.DisplayPath + " " + key.Binding;
                if (terms.Any(term => searchable.IndexOf(term, StringComparison.OrdinalIgnoreCase) < 0)) continue;
                using (new EditorGUILayout.HorizontalScope())
                {
                    if (tab == 0)
                    {
                        bool marked = batchSources.Contains(key);
                        using (new EditorGUI.DisabledScope(!marked && currentFolder.Contains(key.sharedControl)))
                        {
                            bool check = GUILayout.Toggle(marked, GUIContent.none, GUILayout.Width(16));
                            if (check != marked)
                            {
                                if (check && SelectUsable(view, key)) batchSources.Add(key);
                                else batchSources.Remove(key);
                            }
                        }
                    }
                    var tooltip = key.DisplayPath + "\n" + key.type + (key.Binding.Length == 0 ? "" : " · " + key.Binding) +
                        (tab == 0 ? "\n오른쪽 즐겨찾기로 끌어 놓으면 그 자리에 추가돼요." : "") +
                        (tab == 0 && key.hidden ? "\n원본 메뉴 정리에서 숨긴 항목이에요. 즐겨찾기에 넣으면 거기서는 보여요." : "");
                    bool selected = ReferenceEquals(selectedKey, key);
                    var content = new GUIContent(path, tooltip);
                    var row = GUILayoutUtility.GetRect(content, itemStyle, GUILayout.MinWidth(0), GUILayout.ExpandWidth(true));
                    if (tab == 0) SourceDrag(row, key, view);
                    if (GUI.Toggle(row, selected, content, itemStyle) && !selected)
                    {
                        selectedKey = key;
                        relinkNote = null;
                        if (tab == 1) favoritesScroll = Vector2.zero;
                    }
                    if (tab != 0) continue;
                    if (key.type == Control.ControlType.SubMenu)
                        using (new EditorGUI.DisabledScope(key.hidden))
                            if (GUILayout.Button(new GUIContent("위치", key.hidden ? "숨긴 메뉴에는 설치할 수 없어요." :
                                "편집 중인 메뉴를 이 서브메뉴에 설치"), GUILayout.Width(40)) && SelectUsable(view, key))
                                SetLocation(key);
                    bool exists = currentFolder.Contains(key.sharedControl);
                    using (new EditorGUI.DisabledScope(exists))
                        if (GUILayout.Button(new GUIContent(exists ? "✓" : "+", "선택한 즐겨찾기 폴더에 바로가기 추가"),
                            GUILayout.Width(26)) && SelectUsable(view, key))
                        {
                            string parent = addParent;
                            ChangeEntries("Add favorite", entries => entries.Add(new FavoriteMenuEntry { source = key, parentId = parent }));
                            Reveal(parent, menu?.entries);
                            GUIUtility.ExitGUI();
                        }
                }
            }
        }

        // The row whose "다시 연결" could not be applied, and why (shown under that row).
        private string relinkRow, relinkNote;

        private static string Short(string text, int length) =>
            string.IsNullOrEmpty(text) || text.Length <= length ? text : text.Substring(0, length - 1) + "…";

        // "다시 연결" for a row whose original went missing. It names the item selected on the left, so a wrong pair is
        // visible before clicking, and when that item cannot be used it says why under the row (DrawRelinkNote)
        // instead of doing nothing. problem: a reason this particular row cannot take the item, or null.
        private bool RelinkButton(string row, MenuView view, Func<FavoriteMenuKey, string> problem)
        {
            var target = selectedKey;
            var content = target == null
                ? new GUIContent("다시 연결", "왼쪽 목록에서 새 원본 항목을 먼저 선택하세요.")
                : new GUIContent("다시 연결 → " + Short(view.Name(target), 10), $"왼쪽에서 고른 ‘{target.DisplayPath}’에 연결합니다.");
            if (!GUILayout.Button(content, GUILayout.MaxWidth(160))) return false;
            string why = target == null ? "왼쪽 목록에서 연결할 원본 항목을 먼저 선택하세요."
                : view.Resolve(target) == null ? $"‘{target.DisplayPath}’와 경로·동작이 똑같은 항목이 여러 개라 구분할 수 없어요. 다른 항목을 고르세요."
                : problem?.Invoke(target);
            relinkRow = why == null ? null : row;
            relinkNote = why;
            return why == null;
        }

        private void DrawRelinkNote(string row)
        {
            if (relinkNote != null && relinkRow == row) EditorGUILayout.HelpBox(relinkNote, MessageType.Warning);
        }

        private bool SelectUsable(MenuView view, FavoriteMenuKey key)
        {
            if (view.Resolve(key) != null) return true;
            status = "경로와 동작 설정이 똑같은 항목이 여러 개라 안전하게 구분할 수 없어요.";
            statusType = MessageType.Warning;
            return false;
        }

        private sealed class FolderChoice
        {
            internal string Id, Path;
            internal FavoriteMenuEntry Entry;
        }

        private static List<FolderChoice> FolderChoices(IReadOnlyList<FavoriteMenuEntry> entries, string menuName)
        {
            var choices = new List<FolderChoice> { new FolderChoice { Id = "", Path = menuName + " 첫 화면" } };
            var folders = entries.Where(e => e != null && e.IsFolder).ToLookup(e => e.Parent);
            var visited = new HashSet<string>();
            void Walk(string parent, string prefix, int depth)
            {
                if (depth >= 64) return;
                foreach (var entry in folders[parent])
                {
                    if (!visited.Add(entry.folderId)) continue;
                    string name = string.IsNullOrWhiteSpace(entry.label) ? "새 폴더" : entry.label.Trim();
                    var path = prefix + name;
                    choices.Add(new FolderChoice { Id = entry.folderId, Path = path, Entry = entry });
                    Walk(entry.folderId, path + " › ", depth + 1);
                }
            }
            Walk("", "", 0);
            return choices;
        }

        private void DrawFavorites(FavoriteMenuGroup menu, MenuView view)
        {
            string previousName = menu != null ? menu.name ?? "" : "즐겨찾기";
            string name = EditorGUILayout.TextField("메뉴 이름", previousName);
            if (name != previousName) Change("Rename favorites menu", c =>
            {
                if (menuIndex == 0) c.menuName = name;
                else if (c.GetMenu(menuIndex) is FavoriteMenuGroup group) group.name = name;
            });
            var previousIcon = menu?.icon;
            var icon = (Texture2D)EditorGUILayout.ObjectField(new GUIContent("메뉴 아이콘", "빌드한 메뉴에서 이 즐겨찾기 메뉴 버튼에 표시할 아이콘"),
                previousIcon, typeof(Texture2D), false, GUILayout.Height(EditorGUIUtility.singleLineHeight));
            if (icon != previousIcon) Change("Change favorites menu icon", c =>
            {
                if (menuIndex == 0) c.menuIcon = icon;
                else if (c.GetMenu(menuIndex) is FavoriteMenuGroup group) group.icon = icon;
            });
            bool atRoot = menu == null || menu.useRoot;
            var destination = atRoot ? null : view.Resolve(menu.destination);
            using (new EditorGUILayout.HorizontalScope())
            {
                string path = atRoot ? "최상위" : destination != null ? view.Display(destination) : menu.destination?.DisplayPath ?? "";
                EditorGUILayout.LabelField("설치 위치", path);
                using (new EditorGUI.DisabledScope(atRoot))
                    if (GUILayout.Button("최상위로", GUILayout.Width(74)))
                    { SetLocation(null); GUIUtility.ExitGUI(); }
            }
            bool pin = menu?.pinToFirstPage ?? false;
            bool nextPin = EditorGUILayout.Toggle(new GUIContent("첫 페이지에 고정",
                "설치 위치의 첫 페이지 앞쪽에 이 메뉴를 둡니다. 빌드 결과에서 이동한 항목을 확인하세요."), pin);
            if (nextPin != pin)
                Change("Change favorites menu placement", c =>
                {
                    if (menuIndex == 0) c.pinToFirstPage = nextPin;
                    else if (c.GetMenu(menuIndex) is FavoriteMenuGroup group) group.pinToFirstPage = nextPin;
                });

            var entries = menu?.entries ?? new List<FavoriteMenuEntry>();
            var config = avatar.GetComponent<AvatarCustomizer>();
            var choices = FolderChoices(entries, menu?.DisplayName ?? "즐겨찾기");
            using (new EditorGUILayout.HorizontalScope())
            {
                int selected = Math.Max(0, choices.FindIndex(x => x.Id == addParent));
                int next = EditorGUILayout.Popup("추가할 위치", selected, choices.Select(x => x.Path).ToArray());
                addParent = choices[next].Id;
                if (GUILayout.Button("+ 폴더", GUILayout.Width(68)))
                {
                    string parent = addParent;
                    string id = Guid.NewGuid().ToString("N");
                    var names = new HashSet<string>(entries.Where(e => e != null && e.Parent == parent).Select(e => e.label));
                    string newName = "새 폴더";
                    for (int n = 2; names.Contains(newName); n++) newName = "새 폴더 " + n;
                    ChangeEntries("Create favorites folder", list =>
                        list.Add(new FavoriteMenuEntry { folderId = id, parentId = parent, label = newName }));
                    Reveal(parent, entries);
                    addParent = id;
                    GUIUtility.ExitGUI();
                }
            }
            DrawBatchActions(view, entries);
            using var scroll = new EditorGUILayout.ScrollViewScope(favoritesScroll, GUILayout.ExpandHeight(true));
            favoritesScroll = scroll.scrollPosition;
            var siblings = entries.Select((e, i) => (e, i)).Where(x => x.e != null).ToLookup(x => x.e.Parent);
            var drawn = new HashSet<string>();
            void DrawChildren(string parent, int depth)
            {
                if (depth > 64 || !drawn.Add(parent)) return;
                var rows = siblings[parent].ToArray();
                for (int n = 0; n < rows.Length; n++)
                {
                    var (entry, index) = rows[n];
                            var match = FavoriteMenuMatch.Exact;
                            var current = entry.IsFolder || entry.IsShape ? null : view.Resolve(entry.source, out match);
                    using (new EditorGUILayout.HorizontalScope())
                    {
                        GUILayout.Space(Math.Min(5, depth) * 12);
                        using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
                        {
                            using (new EditorGUILayout.HorizontalScope())
                            {
                                DragHandle(GUILayoutUtility.GetRect(14f, 18f, GUILayout.Width(14f)), entry);
                                if (!entry.IsFolder)
                                {
                                    bool marked = batchEntries.Contains(entry);
                                    bool check = GUILayout.Toggle(marked, GUIContent.none, GUILayout.Width(16));
                                    if (check != marked)
                                    {
                                        if (check) batchEntries.Add(entry);
                                        else batchEntries.Remove(entry);
                                    }
                                }
                                if (entry.IsFolder)
                                {
                                    bool expanded = !collapsed.Contains(entry.folderId);
                                    if (GUILayout.Button(expanded ? "▾" : "▸", GUILayout.Width(20)))
                                    {
                                        if (expanded) collapsed.Add(entry.folderId);
                                        else collapsed.Remove(entry.folderId);
                                        GUIUtility.ExitGUI();
                                    }
                                }
                                string previous = entry.label ?? "";
                                string label = EditorGUILayout.TextField(previous, GUILayout.MinWidth(48));
                                if (label != previous) ChangeEntries("Rename favorites item", list => list[index].label = label);
                                var itemIcon = (Texture2D)EditorGUILayout.ObjectField(GUIContent.none, entry.icon, typeof(Texture2D), false,
                                    GUILayout.Width(64), GUILayout.Height(EditorGUIUtility.singleLineHeight));
                                if (itemIcon != entry.icon) ChangeEntries("Change favorites item icon", list => list[index].icon = itemIcon);
                                if (GUILayout.Button("이동", GUILayout.Width(39))) ShowMove(entry, choices);
                                using (new EditorGUI.DisabledScope(n == 0))
                                    if (GUILayout.Button("↑", GUILayout.Width(23))) Move(index, rows[n - 1].i);
                                using (new EditorGUI.DisabledScope(n + 1 == rows.Length))
                                    if (GUILayout.Button("↓", GUILayout.Width(23))) Move(index, rows[n + 1].i);
                                if (GUILayout.Button(new GUIContent("×", entry.IsFolder ? "폴더만 삭제하고 내용은 한 단계 위로 이동" : "바로가기 삭제"),
                                    GUILayout.Width(23)))
                                {
                                    ChangeEntries("Remove favorites item", list => RemoveEntry(list, index));
                                    batchEntries.Remove(entry);
                                    GUIUtility.ExitGUI();
                                }
                            }
                            if (entry.IsShape) DrawShapeEntry(entry);
                            else if (!entry.IsFolder)
                            {
                                string path = current != null ? view.Display(current) : entry.source?.DisplayPath ?? "(원본 없음)";
                                bool missing = current == null && view.Keys.Length > 0;
                                string state = view.Keys.Length == 0 ? "" : match switch
                                {
                                    FavoriteMenuMatch.Changed => "⚠ 동작 변경 · ",
                                    FavoriteMenuMatch.Moved => "경로 이동 · ",
                                    FavoriteMenuMatch.Ambiguous => "⚠ 원본 후보 여러 개 · ",
                                    FavoriteMenuMatch.Missing => "⚠ 연결 필요 · ",
                                    _ => "",
                                } + (current?.hidden == true ? "원본 숨김 · " : "");
                                using (new EditorGUILayout.HorizontalScope())
                                {
                                    EditorGUILayout.LabelField(new GUIContent(state + path,
                                        FavoriteMenuBuilder.Describe(entry.source) + "\n→ " + FavoriteMenuBuilder.Describe(current)), EditorStyles.miniLabel);
                                    if (missing && RelinkButton($"favorite/{menuIndex}/{index}", view, null))
                                    {
                                        var target = selectedKey;
                                        ChangeEntries("Relink favorite", list => list[index].source = target);
                                        GUIUtility.ExitGUI();
                                    }
                                }
                                DrawRelinkNote($"favorite/{menuIndex}/{index}");
                                DrawDefault(view, config, current ?? entry.source, entry);
                                if (current?.type == Control.ControlType.SubMenu)
                                    DrawSubmenuItems(view, config, current, $"{menuIndex}/{index}", 0);
                            }
                        }
                    }
                    DropTarget(GUILayoutUtility.GetLastRect(), entry, entries);
                    if (entry.IsFolder && !collapsed.Contains(entry.folderId)) DrawChildren(entry.folderId, depth + 1);
                }
            }
            DrawChildren("", 0);
            if (Event.current.type == EventType.DragExited) { dropTarget = null; endHover = false; }
            var hint = new GUIContent(entries.Count == 0
                ? "왼쪽 항목을 여기로 끌어 놓거나 ‘+’를 누르면 빌드에 이 메뉴가 표시돼요."
                : "왼쪽 항목을 끌어 놓아 추가하고, ≡를 끌어 순서를 바꾸거나 폴더 가운데에 놓아 넣을 수 있어요. " +
                  "여기에 놓으면 ‘추가할 위치’의 맨 끝으로 가요. 별칭을 비우면 원본 이름을 따라가요.");
            var end = GUILayoutUtility.GetRect(hint, EditorStyles.wordWrappedMiniLabel, GUILayout.MinHeight(36f));
            EndDrop(end, entries);
            GUI.Label(end, hint, EditorStyles.wordWrappedMiniLabel);
        }

        private void DrawNames(AvatarCustomizer config, MenuView view)
        {
            string page = config ? config.nextPageLabel ?? "" : "";
            string next = EditorGUILayout.TextField(new GUIContent("‘More’ 이름", "자동으로 만들어진 다음 페이지 버튼의 이름. 비우면 기본값."),
                page);
            if (next != page) Change("Rename more pages", c => c.nextPageLabel = next);
            EditorGUILayout.HelpBox("빌드된 아바타에서만 항목의 이름과 위치를 바꾸거나 메뉴에서 숨겨요. 원본 에셋과 동작은 그대로 유지돼요.", MessageType.Info);
            var rules = (config ? config.nameOverrides : null) ?? new List<MenuNameOverride>();
            var moves = (config ? config.menuMoves : null) ?? new List<MenuMoveRule>();
            var hides = (config ? config.hiddenItems : null) ?? new List<MenuHideRule>();
            var problems = organizeIssues.Where(i => i.Warning).ToArray();
            if (problems.Length > 0)
                EditorGUILayout.HelpBox($"정리 미리보기에서 문제 {problems.Length}개: " +
                    string.Join(" / ", problems.Take(3).Select(i => i.Title + " · " + i.Detail)) +
                    (problems.Length > 3 ? " …" : ""), MessageType.Warning);
            var key = selectedKey;
            if (key != null)
            {
                bool hasRule = view.RuleByControl.TryGetValue(key.sharedControl, out int index);
                string old = hasRule ? rules[index].label ?? "" : "";
                EditorGUILayout.LabelField(new GUIContent("원래 경로", key.DisplayPath), new GUIContent(key.DisplayPath, key.DisplayPath));
                using (new EditorGUI.DisabledScope(view.Resolve(key) == null))
                using (new EditorGUILayout.HorizontalScope())
                {
                    string label = EditorGUILayout.TextField(new GUIContent("새 표시 이름", "비워 두면 원래 표시 이름"), old);
                    if (old != label)
                        Change("Rename built menu item", c =>
                        {
                            if (hasRule) c.nameOverrides[index].label = label;
                            else c.nameOverrides.Add(new MenuNameOverride { source = key, label = label });
                        });
                    using (new EditorGUI.DisabledScope(!hasRule))
                        if (GUILayout.Button("원래대로", GUILayout.Width(64)))
                        {
                            Change("Reset menu name", c => c.nameOverrides.RemoveAt(index));
                            GUIUtility.ExitGUI();
                        }
                }
                DrawMove(view, key, moves);
                DrawHide(view, key);
                if (catalogue.Count(x => x.sharedControl == key.sharedControl) > 1)
                    EditorGUILayout.LabelField("공유된 메뉴예요. 같은 항목을 보여 주는 다른 경로에도 반영돼요.", EditorStyles.wordWrappedMiniLabel);
            }
            else EditorGUILayout.LabelField("왼쪽 목록에서 이름을 바꾸거나 옮기거나 숨길 항목을 선택하세요.", EditorStyles.wordWrappedMiniLabel);

            using var scroll = new EditorGUILayout.ScrollViewScope(favoritesScroll, GUILayout.ExpandHeight(true));
            favoritesScroll = scroll.scrollPosition;
            EditorGUILayout.LabelField($"저장한 이름 변경 · {rules.Count(x => !string.IsNullOrWhiteSpace(x?.label))}개", EditorStyles.boldLabel);
            for (int i = 0; i < rules.Count; i++)
            {
                var rule = rules[i];
                if (string.IsNullOrWhiteSpace(rule?.label)) continue;
                int index = i;
                var current = view.Resolve(rule.source, out var match);
                string path = current?.DisplayPath ?? rule.source?.DisplayPath ?? "";
                bool missing = current == null && catalogue.Length > 0;
                string state = missing ? "⚠ " : match == FavoriteMenuMatch.Moved ? "경로 이동 · " : match == FavoriteMenuMatch.Changed ? "⚠ 동작 변경 · " : "";
                using (new EditorGUILayout.HorizontalScope())
                {
                    EditorGUILayout.LabelField(new GUIContent(state + path + " → " + rule.label,
                        match == FavoriteMenuMatch.Moved ? $"메뉴가 옮겨져 같은 이름의 항목에 이어서 적용돼요.\n저장된 경로: {rule.source?.DisplayPath}" : path));
                    if (missing && RelinkButton($"name/{index}", view, target =>
                            view.RuleByControl.TryGetValue(target.sharedControl, out int other) && other != index &&
                            !string.IsNullOrWhiteSpace(rules[other]?.label)
                                ? $"‘{view.Display(target)}’에는 이미 ‘{rules[other].label}’ 이름이 있어요. 그 이름을 지우거나 다른 항목을 고르세요."
                                : null))
                    {
                        var target = selectedKey;
                        // A rule on the target with no name is left over from clearing a name; it would block the link.
                        int empty = view.RuleByControl.TryGetValue(target.sharedControl, out int other) && other != index ? other : -1;
                        Change("Relink menu name", c =>
                        {
                            c.nameOverrides[index].source = target;
                            if (empty >= 0) c.nameOverrides.RemoveAt(empty);
                        });
                        GUIUtility.ExitGUI();
                    }
                    else using (new EditorGUI.DisabledScope(current == null))
                        if (GUILayout.Button("보기", GUILayout.Width(43))) selectedKey = current;
                    if (GUILayout.Button("×", GUILayout.Width(23)))
                    {
                        Change("Reset menu name", c => c.nameOverrides.RemoveAt(index));
                        GUIUtility.ExitGUI();
                    }
                }
                DrawRelinkNote($"name/{index}");
            }
            DrawMoveRules(view, moves);
            DrawHideRules(view, hides);
        }

        // "메뉴에서 숨기기" of the selected item.
        private void DrawHide(MenuView view, FavoriteMenuKey key)
        {
            bool hidden = view.HideByControl.ContainsKey(key.sharedControl);
            using (new EditorGUI.DisabledScope(view.Resolve(key) == null))
            {
                bool next = EditorGUILayout.Toggle(new GUIContent("메뉴에서 숨기기",
                    "빌드한 메뉴에서 이 항목을 빼요. 하위 메뉴는 안의 항목과 함께 빠져요. 기능과 값은 그대로 남고, " +
                    "즐겨찾기에 넣은 바로가기는 계속 보여요."), hidden);
                if (next != hidden)
                {
                    if (next)
                        Change("Hide built menu item", c => (c.hiddenItems ??= new List<MenuHideRule>()).Add(new MenuHideRule { source = key }));
                    else
                        Change("Show built menu item", c => c.hiddenItems.RemoveAll(r => view.Resolve(r?.source)?.sharedControl == key.sharedControl));
                    GUIUtility.ExitGUI();
                }
            }
            if (hidden)
                EditorGUILayout.LabelField("게임 메뉴에서 보이지 않아요. 기능은 그대로 남아 값은 바꿀 수 없고, 저장되는 값은 숨기기 전 마지막 값이 유지돼요. " +
                                           "즐겨찾기에 넣으면 거기서는 쓸 수 있어요.", EditorStyles.wordWrappedMiniLabel);
        }

        private void DrawHideRules(MenuView view, List<MenuHideRule> hides)
        {
            EditorGUILayout.Space(6);
            EditorGUILayout.LabelField($"저장한 숨기기 · {hides.Count(h => h != null)}개", EditorStyles.boldLabel);
            if (hides.Count == 0)
                EditorGUILayout.LabelField("왼쪽에서 항목을 고르고 ‘메뉴에서 숨기기’를 켜면, 빌드한 메뉴에서 빠져요. " +
                                           "하위 메뉴는 안의 항목과 함께 빠지고, 빈자리는 다음 페이지 항목으로 채워져요.",
                    EditorStyles.wordWrappedMiniLabel);
            for (int i = 0; i < hides.Count; i++)
            {
                var rule = hides[i];
                if (rule == null) continue;
                int index = i;
                var current = view.Resolve(rule.source, out var match);
                string path = current?.DisplayPath ?? rule.source?.DisplayPath ?? "";
                bool missing = current == null && catalogue.Length > 0;
                string state = missing ? "⚠ " : match == FavoriteMenuMatch.Moved ? "경로 이동 · " : match == FavoriteMenuMatch.Changed ? "⚠ 동작 변경 · " : "";
                using (new EditorGUILayout.HorizontalScope())
                {
                    string text = state + path;
                    EditorGUILayout.LabelField(new GUIContent(text, text));
                    if (missing && RelinkButton($"hide/{index}", view, target =>
                            view.HideByControl.TryGetValue(target.sharedControl, out int other) && other != index
                                ? $"‘{view.Display(target)}’은 이미 숨겼어요. 다른 항목을 고르세요."
                                : null))
                    {
                        var target = selectedKey;
                        Change("Relink menu hide", c => c.hiddenItems[index].source = target);
                        GUIUtility.ExitGUI();
                    }
                    else using (new EditorGUI.DisabledScope(current == null))
                        if (GUILayout.Button("보기", GUILayout.Width(43))) selectedKey = current;
                    if (GUILayout.Button(new GUIContent("×", "다시 메뉴에 보이기"), GUILayout.Width(23)))
                    {
                        Change("Show built menu item", c => c.hiddenItems.RemoveAt(index));
                        GUIUtility.ExitGUI();
                    }
                }
                DrawRelinkNote($"hide/{index}");
            }
        }

        // "옮길 위치" of the selected item: stay, the top level, a new top-level folder, or a built submenu.
        private void DrawMove(MenuView view, FavoriteMenuKey key, List<MenuMoveRule> moves)
        {
            bool hasMove = view.MoveByControl.TryGetValue(key.sharedControl, out int index);
            var rule = hasMove ? moves[index] : null;
            using (new EditorGUI.DisabledScope(view.Resolve(key) == null))
            {
                using (new EditorGUILayout.HorizontalScope())
                {
                    EditorGUILayout.PrefixLabel(new GUIContent("옮길 위치",
                        "빌드한 메뉴에서 이 항목을 옮길 곳. 하위 메뉴는 안의 항목과 함께 옮겨지고, 즐겨찾기와 이름 변경은 그대로 적용돼요."));
                    string label = rule == null ? "그대로" : view.MoveTarget(rule);
                    if (EditorGUILayout.DropdownButton(new GUIContent(label, label), FocusType.Keyboard, GUILayout.MinWidth(60)))
                        ShowMoveTargets(view, key, hasMove ? index : -1);
                    using (new EditorGUI.DisabledScope(!hasMove))
                        if (GUILayout.Button("원래대로", GUILayout.Width(64)))
                        {
                            Change("Reset menu move", c => c.menuMoves.RemoveAt(index));
                            GUIUtility.ExitGUI();
                        }
                }
                if (rule?.Folder == null) return;
                string old = rule.newFolder;
                string next = EditorGUILayout.DelayedTextField(new GUIContent("새 폴더 이름",
                    "최상위에 이 이름의 하위 메뉴가 있으면 그 안에, 없으면 만들어서 넣어요. 같은 이름을 고른 항목은 한 폴더에 모여요."), old);
                if (next != old && !string.IsNullOrWhiteSpace(next))
                    Change("Rename move folder", c => c.menuMoves[index].newFolder = next.Trim());
            }
        }

        private void ShowMoveTargets(MenuView view, FavoriteMenuKey key, int index)
        {
            var config = avatar ? avatar.GetComponent<AvatarCustomizer>() : null;
            var rule = index >= 0 && config && index < (config.menuMoves?.Count ?? 0) ? config.menuMoves[index] : null;
            void Set(Action<MenuMoveRule> apply)
            {
                Change("Move built menu item", c =>
                {
                    c.menuMoves ??= new List<MenuMoveRule>();
                    var target = index >= 0 && index < c.menuMoves.Count ? c.menuMoves[index] : null;
                    if (target == null)
                        c.menuMoves.Add(target = new MenuMoveRule { source = key, destination = new FavoriteMenuKey(), newFolder = "" });
                    apply(target);
                });
                Repaint();
            }
            var menu = new GenericMenu();
            menu.AddItem(new GUIContent("그대로 (옮기지 않음)"), rule == null, () =>
            {
                if (index < 0) return;
                Change("Reset menu move", c => c.menuMoves.RemoveAt(index));
                Repaint();
            });
            menu.AddItem(new GUIContent("최상위"), rule != null && rule.ToRoot, () => Set(r =>
            {
                r.newFolder = "";
                r.destination = new FavoriteMenuKey();
            }));
            menu.AddItem(new GUIContent("새 최상위 폴더…"), rule?.Folder != null, () => Set(r =>
            {
                if (r.Folder == null) r.newFolder = "새 폴더";
                r.destination = new FavoriteMenuKey();
            }));
            menu.AddSeparator("");
            var parent = key.path.Take(key.path.Length - 1).ToArray();
            var current = rule == null || rule.Folder != null || rule.ToRoot ? null : view.Resolve(rule.destination);
            foreach (var target in catalogue.Where(k => k.type == Control.ControlType.SubMenu))
            {
                // Not the item itself or anything inside it, and only submenus that can be told apart.
                if (target.sharedControl == key.sharedControl || Inside(target, key) || view.Resolve(target) == null) continue;
                // GenericMenu treats "/" as a submenu separator.
                string title = "하위 메뉴/" + view.Display(target).Replace("/", "／");
                if (target.path.SequenceEqual(parent))
                {
                    menu.AddDisabledItem(new GUIContent(title + " (지금 위치)"));
                    continue;
                }
                var chosen = target;
                menu.AddItem(new GUIContent(title), current != null && current.sharedControl == target.sharedControl, () => Set(r =>
                {
                    r.newFolder = "";
                    r.destination = chosen;
                }));
            }
            menu.ShowAsContext();
        }

        private static bool Inside(FavoriteMenuKey item, FavoriteMenuKey container) =>
            item.path.Length > container.path.Length && container.path.SequenceEqual(item.path.Take(container.path.Length));

        private void DrawMoveRules(MenuView view, List<MenuMoveRule> moves)
        {
            EditorGUILayout.Space(6);
            EditorGUILayout.LabelField($"저장한 이동 · {moves.Count(m => m != null)}개", EditorStyles.boldLabel);
            if (moves.Count == 0)
                EditorGUILayout.LabelField("왼쪽에서 항목을 고르고 ‘옮길 위치’를 정하면, 빌드한 메뉴에서 그곳으로 옮겨요. " +
                                           "하위 메뉴는 안의 항목과 함께 옮겨지고, 빈자리는 다음 페이지 항목으로 채워져요.",
                    EditorStyles.wordWrappedMiniLabel);
            for (int i = 0; i < moves.Count; i++)
            {
                var rule = moves[i];
                if (rule == null) continue;
                int index = i;
                var current = view.Resolve(rule.source, out var match);
                string path = current?.DisplayPath ?? rule.source?.DisplayPath ?? "";
                bool missing = current == null && catalogue.Length > 0;
                string state = missing ? "⚠ " : match == FavoriteMenuMatch.Moved ? "경로 이동 · " : match == FavoriteMenuMatch.Changed ? "⚠ 동작 변경 · " : "";
                using (new EditorGUILayout.HorizontalScope())
                {
                    string text = state + path + "  ⇢ " + view.MoveTarget(rule);
                    EditorGUILayout.LabelField(new GUIContent(text, text));
                    if (missing && RelinkButton($"move/{index}", view, target =>
                            view.MoveByControl.TryGetValue(target.sharedControl, out int other) && other != index
                                ? $"‘{view.Display(target)}’에는 이미 다른 이동 설정이 있어요. 그 설정을 지우거나 다른 항목을 고르세요."
                                : null))
                    {
                        var target = selectedKey;
                        Change("Relink menu move", c => c.menuMoves[index].source = target);
                        GUIUtility.ExitGUI();
                    }
                    else using (new EditorGUI.DisabledScope(current == null))
                        if (GUILayout.Button("보기", GUILayout.Width(43))) selectedKey = current;
                    if (GUILayout.Button("×", GUILayout.Width(23)))
                    {
                        Change("Remove menu move", c => c.menuMoves.RemoveAt(index));
                        GUIUtility.ExitGUI();
                    }
                }
                DrawRelinkNote($"move/{index}");
            }
        }

        private void ShowImport()
        {
            var menu = new GenericMenu();
            var sources = Enumerable.Range(0, SceneManager.sceneCount).Select(SceneManager.GetSceneAt).Where(s => s.isLoaded)
                .SelectMany(s => s.GetRootGameObjects()).SelectMany(r => r.GetComponentsInChildren<AvatarCustomizer>(true))
                .Where(c => c && avatar && c.gameObject != avatar.gameObject).ToArray();
            if (sources.Length == 0) menu.AddDisabledItem(new GUIContent("열린 씬에 즐겨찾기를 설정한 다른 아바타가 없어요"));
            foreach (var source in sources)
            {
                var from = source;
                int items = (from.entries?.Count ?? 0) + (from.additionalMenus?.Sum(m => m?.entries?.Count ?? 0) ?? 0);
                string label = $"{from.gameObject.name}  ·  메뉴 {1 + (from.additionalMenus?.Count ?? 0)}개, 항목 {items}개, " +
                               $"이름 변경 {from.nameOverrides?.Count ?? 0}개, 이동 {from.menuMoves?.Count ?? 0}개, 숨김 {from.hiddenItems?.Count ?? 0}개";
                // GenericMenu treats "/" as a submenu separator.
                menu.AddItem(new GUIContent(label.Replace("/", "／")), false, () => Import(from));
            }
            menu.ShowAsContext();
        }

        // Copies every setting of another avatar's component. Items are found again by menu path and parameter, so an
        // avatar with the same menus links at once; anything else shows as "연결 필요" after the next read.
        private void Import(AvatarCustomizer from)
        {
            if (!from || !IsSceneAvatar(avatar)) return;
            var own = avatar.GetComponent<AvatarCustomizer>();
            bool hasOwn = own && ((own.entries?.Count ?? 0) > 0 || (own.additionalMenus?.Count ?? 0) > 0 || (own.nameOverrides?.Count ?? 0) > 0 || (own.menuMoves?.Count ?? 0) > 0 ||
                (own.hiddenItems?.Count ?? 0) > 0);
            if (hasOwn && !EditorUtility.DisplayDialog("즐겨찾기 설정 가져오기",
                    $"‘{avatar.name}’의 지금 즐겨찾기 설정을 ‘{from.gameObject.name}’의 설정으로 바꿀까요?\n실행 취소(Ctrl+Z)로 되돌릴 수 있어요.",
                    "바꾸기", "취소"))
                return;
            string json = EditorJsonUtility.ToJson(from);
            Change("Import favorites settings", c =>
            {
                bool enabled = c.enabled;
                EditorJsonUtility.FromJsonOverwrite(json, c);
                c.enabled = enabled;
            });
            SelectMenu(0);
            batchSources.Clear();
            status = $"‘{from.gameObject.name}’의 즐겨찾기 설정을 복사했어요. ‘빌드 메뉴 읽기’로 이 아바타의 메뉴와 연결을 확인하세요. " +
                     "같은 경로와 파라미터의 항목은 바로 연결되고, 다른 항목은 ‘연결 필요’로 표시돼요.";
            statusType = MessageType.Info;
            Repaint();
        }

        private void Reveal(string id, IReadOnlyList<FavoriteMenuEntry> entries)
        {
            var seen = new HashSet<string>();
            while (!string.IsNullOrEmpty(id) && seen.Add(id))
            {
                collapsed.Remove(id);
                id = entries?.FirstOrDefault(e => e != null && e.folderId == id)?.Parent;
            }
        }

        private void ShowMove(FavoriteMenuEntry entry, List<FolderChoice> choices)
        {
            var menu = new GenericMenu();
            var parents = choices.ToDictionary(x => x.Id, x => x.Entry?.Parent);
            foreach (var choice in choices)
            {
                string target = choice.Id;
                if (entry.IsFolder)
                {
                    string id = target;
                    var seen = new HashSet<string>();
                    while (!string.IsNullOrEmpty(id) && id != entry.folderId && seen.Add(id))
                        id = parents.TryGetValue(id, out var parent) ? parent : null;
                    if (id == entry.folderId) continue;
                }
                var title = new GUIContent(choice.Path.Replace("/", "／"));
                if (target == entry.Parent) menu.AddDisabledItem(title, true);
                else
                {
                    var selectedAvatar = avatar;
                    var selectedMenuIndex = menuIndex;
                    menu.AddItem(title, false, () =>
                    {
                        if (avatar != selectedAvatar || menuIndex != selectedMenuIndex) return;
                        ChangeEntries("Move favorites item", list =>
                        {
                            if (!list.Remove(entry)) return;
                            entry.parentId = target;
                            list.Add(entry);
                            Reveal(target, list);
                        });
                        Repaint();
                    });
                }
            }
            menu.ShowAsContext();
        }

        private static void RemoveEntry(List<FavoriteMenuEntry> entries, int index)
        {
            var entry = entries[index];
            entries.RemoveAt(index);
            if (!entry.IsFolder) return;
            var children = entries.Where(e => e != null && e.Parent == entry.folderId).ToArray();
            var following = entries.Skip(index).FirstOrDefault(e => e != null && e.Parent == entry.Parent);
            foreach (var child in children) { entries.Remove(child); child.parentId = entry.Parent; }
            entries.InsertRange(following == null ? entries.Count : entries.IndexOf(following), children);
        }

        private void Move(int from, int to)
        {
            ChangeEntries("Reorder favorites", list => (list[to], list[from]) = (list[from], list[to]));
            GUIUtility.ExitGUI();
        }

        private void Scan(VRCAvatarDescriptor selected, bool compare = false)
        {
            FavoriteMenuBuilder.Scan readScan = null;
            Scene preview = default;
            var clones = new List<GameObject>();
            var temporaries = new List<string>();
            try
            {
                if (!IsSceneAvatar(selected) || EditorApplication.isPlayingOrWillChangePlaymode)
                    throw new InvalidOperationException("편집 모드에서 아바타를 선택해 주세요.");
                DeleteStaleScanFolders();
                preview = EditorSceneManager.NewPreviewScene();
                var scene = preview;
                GameObject MakeClone()
                {
                    var copy = Object.Instantiate(selected.gameObject);
                    SceneManager.MoveGameObjectToScene(copy, scene);
                    copy.SetActive(true);
                    clones.Add(copy);
                    return copy;
                }
                // A folder for one read's generated assets, deleted when the scan ends.
                string TemporaryFolder()
                {
                    var folder = AssetDatabase.GUIDToAssetPath(AssetDatabase.CreateFolder("Assets", ScanFolderPrefix + Guid.NewGuid().ToString("N")));
                    if (string.IsNullOrEmpty(folder))
                        throw new InvalidOperationException("임시 빌드 폴더를 만들 수 없습니다.");
                    temporaries.Add(folder);
                    return folder;
                }
                // One read on a fresh clone: the fast read when asked and possible, otherwise the full build.
                (FavoriteMenuBuilder.Scan Scan, BuildContext Context, GameObject Clone, bool Fast) Read(bool tryFast)
                {
                    var clone = MakeClone();
                    if (tryFast)
                    {
                        var quick = new FavoriteMenuBuilder.Scan(clone);
                        BuildContext quickContext = null;
                        try { quickContext = FavoriteMenuBuilder.ProcessFast(clone, TemporaryFolder()); }
                        catch (Exception e)
                        {
                            Debug.LogWarning("[Avatar Customizer] 빠른 읽기에 실패해 전체 빌드로 다시 읽습니다: " + e.Message, selected);
                            // The clone may be half processed; start the full build from a fresh one.
                            clone = MakeClone();
                        }
                        finally { quick.Dispose(); }
                        if (quickContext != null) return (quick, quickContext, clone, true);
                    }
                    var folder = TemporaryFolder();
                    var full = new FavoriteMenuBuilder.Scan(clone);
                    try
                    {
                        using (new OverrideTemporaryDirectoryScope(folder))
                            return (full, nadena.dev.ndmf.AvatarProcessor.ProcessAvatar(clone, AmbientPlatform.DefaultPlatform), clone, false);
                    }
                    finally { full.Dispose(); }
                }

                var read = Read(fastScan || compare);
                string[] differences = null;
                if (compare && read.Fast)
                {
                    var quickItems = Lines(read.Scan.Menu);
                    var quickFinal = FinalMenu(read.Clone);
                    DestroyMenus(read.Scan.TreeMenus);
                    read = Read(false);
                    differences = Differences(quickItems, Lines(read.Scan.Menu), "메뉴 목록")
                        .Concat(Differences(quickFinal, FinalMenu(read.Clone), "최종 메뉴")).ToArray();
                    if (differences.Length != 0)
                    {
                        fastScan = false;
                        Debug.LogWarning("[Avatar Customizer] 빠른 읽기와 전체 빌드의 차이:\n" + string.Join("\n", differences), selected);
                    }
                }
                var (scan, context, built, fast) = read;
                readScan = scan;
                lastScanMode = fast ? "빠른 읽기" : "전체 빌드";
                bool captured = scan.Menu != null;
                if (captured && avatar == selected)
                {
                    catalogue = scan.Menu;
                    SetTree(scan.Tree, scan.TreeMenus);
                    scan.TreeMenus = null;
                    Organize(selected.GetComponent<AvatarCustomizer>());
                    parameterDefaults = scan.Defaults ?? new Dictionary<string, float>();
                    batchSources.Clear();
                    selectedKey = FavoriteMenuKey.Resolve(catalogue, selectedKey);
                    var descriptor = built.GetComponent<VRCAvatarDescriptor>();
                    SetReview(descriptor ? descriptor.expressionsMenu : null, scan.Issues, scan.FavoriteMenus,
                        context.Successful, selected.GetComponent<AvatarCustomizer>());
                }
                else reviewStale = true;
                statusType = context.Successful && captured && !scan.HasWarnings ? MessageType.Info : MessageType.Warning;
                status = captured ? $"빌드 메뉴에서 {scan.Menu.Length}개 항목을 읽었어요 ({lastScanMode})." :
                    "빌드 메뉴를 읽지 못했어요. Unity Console 또는 NDMF 빌드 보고서를 확인해 주세요.";
                if (!context.Successful && captured) status += " 일부 에셋에 빌드 오류가 있어 메뉴가 빠질 수 있어요.";
                if (captured && !string.IsNullOrEmpty(scan.Result))
                    status += "\n" + scan.Result.Split('\n')[0] + (scan.HasWarnings ? " · 빌드 결과 탭에서 문제 확인" : "");
                if (compare && differences == null)
                    status += "\n빠른 읽기를 쓸 수 없어 전체 빌드로만 읽었어요.";
                else if (differences?.Length == 0)
                    status += "\n비교: 빠른 읽기와 전체 빌드 결과가 같아요. 빠른 읽기를 계속 써도 돼요.";
                else if (differences != null)
                {
                    statusType = MessageType.Warning;
                    status += $"\n비교: 빠른 읽기와 전체 빌드 결과가 {differences.Length}곳 달라 ‘빠른 읽기’를 껐어요. 위 결과는 전체 빌드 기준이에요.\n" +
                              string.Join("\n", differences.Take(4)) + (differences.Length > 4 ? $"\n외 {differences.Length - 4}곳 · 전체 목록은 Console" : "");
                }
            }
            catch (Exception e)
            {
                reviewStale = true;
                statusType = MessageType.Error;
                status = "메뉴 읽기 실패: " + e.Message;
                Debug.LogException(e);
            }
            finally
            {
                // A read the window did not take (another avatar, a failed read) leaves its copy of the menu behind.
                DestroyMenus(readScan?.TreeMenus);
                try
                {
                    foreach (var clone in clones) if (clone) Object.DestroyImmediate(clone);
                    if (preview.IsValid()) EditorSceneManager.ClosePreviewScene(preview);
                    foreach (var temporary in temporaries)
                        if (temporary.StartsWith("Assets/" + ScanFolderPrefix, StringComparison.Ordinal))
                            AssetDatabase.DeleteAsset(temporary);
                }
                finally { scanning = false; Repaint(); }
            }
        }

        private static void DestroyMenus(List<VRCExpressionsMenu> menus)
        {
            if (menus == null) return;
            foreach (var menu in menus) if (menu) DestroyImmediate(menu);
            menus.Clear();
        }

        // Takes over a read's copy of the menu (null clears it), and organizes it on the next draw.
        private void SetTree(VRCExpressionsMenu root, List<VRCExpressionsMenu> menus)
        {
            DestroyMenus(treeMenus);
            tree = root;
            treeMenus = menus ?? new List<VRCExpressionsMenu>();
            organized = Array.Empty<FavoriteMenuKey>();
            organizedFor = null;
            organizeIssues = Array.Empty<FavoriteMenuBuilder.Issue>();
            organizedNames = organizedMoves = organizedHides = 0;
            organizedPath.Clear();
        }

        // The favorites tab's menu: the read menu after "원본 메뉴 정리", worked out with the build's own code.
        // Runs again only when the component changed (its dirty count) or a new menu was read.
        private void Organize(AvatarCustomizer config)
        {
            string signature = (tree ? tree.GetInstanceID() : 0) + ":" +
                               (config ? config.GetInstanceID() + ":" + EditorUtility.GetDirtyCount(config) : "-");
            if (signature == organizedFor) return;
            organizedFor = signature;
            var issues = new List<FavoriteMenuBuilder.Issue>();
            string pageLabel = config && !string.IsNullOrWhiteSpace(config.nextPageLabel) ? config.nextPageLabel.Trim() : null;
            var organizer = new MenuOrganizer(tree, FavoriteMenuBuilder.LoadMoreIcon(), pageLabel,
                config ? config.nameOverrides : null, config ? config.menuMoves : null, config ? config.hiddenItems : null,
                (title, detail, warning, target, index, saved, current) => issues.Add(new FavoriteMenuBuilder.Issue
                {
                    Title = title, Detail = detail, Warning = warning, Target = target, MenuIndex = -1, ItemIndex = index,
                    Saved = saved, Current = current,
                }), HideFlags.HideAndDontSave);
            try
            {
                organized = tree ? organizer.Organized : Array.Empty<FavoriteMenuKey>();
                organizeIssues = issues.ToArray();
                organizedNames = organizer.NameCount;
                organizedMoves = organizer.MoveCount;
                organizedHides = organizer.HideCount;
                // Keys are new objects each time: keep the checked rows and, in the favorites tab, the selection.
                var checkedRows = batchSources.Select(k => FavoriteMenuKey.Resolve(organized, k)).Where(k => k != null).ToArray();
                batchSources.Clear();
                batchSources.UnionWith(checkedRows);
                if (tab != 1 && selectedKey != null) selectedKey = FavoriteMenuKey.Resolve(organized, selectedKey);
                // Keep the preview open at the same submenu when it is still there.
                var open = organizedPath.Skip(1).Select(p => p.Name).ToArray();
                organizedPath.Clear();
                if (organizer.Root)
                {
                    organizedPath.Add(("최상위", SnapshotPages(organizer.Root, null, organizer.MovedControls)));
                    foreach (var name in open)
                    {
                        var child = organizedPath[organizedPath.Count - 1].Page.Items.FirstOrDefault(i => i.Child != null && i.Name == name).Child;
                        if (child == null) break;
                        organizedPath.Add((name, child));
                    }
                }
            }
            finally
            {
                foreach (var menu in organizer.Created) if (menu) DestroyImmediate(menu);
            }
        }

        private void DrawOrganizedNote()
        {
            using (new EditorGUILayout.HorizontalScope())
            {
                string note = !tree ? "왼쪽에서 빌드 메뉴를 고르세요. 설정은 아바타별로 씬에 저장돼요." :
                    $"원본 메뉴 정리가 반영된 메뉴예요 · 이름 변경 {organizedNames}개 · 이동 {organizedMoves}개" +
                    (organizedHides > 0 ? $" · 숨김 {organizedHides}개" : "") +
                    (organizeIssues.Any(i => i.Warning) ? $" · 문제 {organizeIssues.Count(i => i.Warning)}개(원본 메뉴 정리 탭)" : "");
                EditorGUILayout.LabelField(note, EditorStyles.wordWrappedMiniLabel);
                using (new EditorGUI.DisabledScope(!tree))
                    showOrganized = GUILayout.Toolbar(showOrganized ? 1 : 0, new[] { "목록", "미리보기" }, EditorStyles.miniButton,
                        GUILayout.Width(110)) == 1;
            }
        }

        private static string[] Lines(FavoriteMenuKey[] keys) =>
            keys?.Select(k => $"{k.DisplayPath} [{k.type} {k.Binding} {k.value}]").ToArray() ?? Array.Empty<string>();

        // The built menu as one line per control, with its path.
        private static string[] FinalMenu(GameObject clone)
        {
            var lines = new List<string>();
            var seen = new HashSet<VRCExpressionsMenu>();
            void Walk(VRCExpressionsMenu menu, string prefix)
            {
                if (!menu || !seen.Add(menu) || menu.controls == null) return;
                foreach (var c in menu.controls)
                {
                    if (c == null) continue;
                    string path = prefix + (c.name ?? "");
                    lines.Add($"{path} [{c.type} {c.parameter?.name} {c.value}]");
                    if (c.type == Control.ControlType.SubMenu) Walk(c.subMenu, path + " / ");
                }
            }
            Walk(clone.GetComponent<VRCAvatarDescriptor>()?.expressionsMenu, "");
            return lines.ToArray();
        }

        private static IEnumerable<string> Differences(string[] fast, string[] full, string label)
        {
            var onlyFull = full.Except(fast).ToArray();
            var onlyFast = fast.Except(full).ToArray();
            foreach (var line in onlyFull) yield return $"{label}: 전체 빌드에만 있음 · {line}";
            foreach (var line in onlyFast) yield return $"{label}: 빠른 읽기에만 있음 · {line}";
            if (onlyFull.Length == 0 && onlyFast.Length == 0 && !fast.SequenceEqual(full)) yield return $"{label}: 순서가 달라요";
        }

        private const string ScanFolderPrefix = "__AvatarCustomizerScan_";
        private const string LegacyScanFolderPrefix = "__AvatarMenuFavoritesScan_"; // before the rename (1.x)

        // A scan runs synchronously, so any folder left at this point belongs to an interrupted session.
        private static void DeleteStaleScanFolders()
        {
            foreach (var folder in AssetDatabase.GetSubFolders("Assets"))
                if (folder.StartsWith("Assets/" + ScanFolderPrefix, StringComparison.Ordinal) ||
                    folder.StartsWith("Assets/" + LegacyScanFolderPrefix, StringComparison.Ordinal))
                    AssetDatabase.DeleteAsset(folder);
        }
    }
}
#endif
