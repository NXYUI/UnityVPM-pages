#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Linq;
using nadena.dev.modular_avatar.core;
using UnityEditor;
using UnityEngine;
using VRC.SDK3.Avatars.Components;
using VRC.SDKBase;

namespace AvatarMenuTools
{
    // What else on an avatar changes its blendshapes.
    // Blocked: another component sets the shape (VRChat lip sync and eyelids, Modular Avatar Shape Changer and
    // Blendshape Sync, and any component that refers to the mesh and names the shape, such as optimizer freeze or rename
    // tools). Editing it here or adding a menu control would fight that component, so both are turned off.
    // Animated: an animation already in the avatar moves the shape. That is only a warning: the base value still
    // matters, but a menu control would always win over that animation.
    internal sealed class BlendshapeConflicts
    {
        private readonly Transform root;
        private readonly Dictionary<SkinnedMeshRenderer, Dictionary<string, string>> blocked =
            new Dictionary<SkinnedMeshRenderer, Dictionary<string, string>>();
        private readonly Dictionary<(string Path, string Shape), string> animated = new Dictionary<(string, string), string>();

        private BlendshapeConflicts(Transform root) => this.root = root;

        // Why the shape must not be touched here, or null.
        internal string Blocked(SkinnedMeshRenderer r, string shape) =>
            r && shape != null && blocked.TryGetValue(r, out var shapes) && shapes.TryGetValue(shape, out var why) ? why : null;

        internal int BlockedCount(SkinnedMeshRenderer r) => r && blocked.TryGetValue(r, out var shapes) ? shapes.Count : 0;

        // Which animation already moves the shape, or null.
        internal string Animated(SkinnedMeshRenderer r, string shape)
        {
            if (!r || shape == null || !r.transform.IsChildOf(root)) return null;
            string path = r.transform == root ? "" : AnimationUtility.CalculateTransformPath(r.transform, root);
            return animated.TryGetValue((path, shape), out var what) ? what : null;
        }

        internal static BlendshapeConflicts Scan(Transform root)
        {
            var result = new BlendshapeConflicts(root);
            if (!root) return result;
            foreach (var component in root.GetComponentsInChildren<MonoBehaviour>(true))
            {
                if (!component || component is AvatarCustomizer) continue;
                switch (component)
                {
                    case VRCAvatarDescriptor descriptor:
                        result.ReadDescriptor(descriptor);
                        continue;
                    case ModularAvatarBlendshapeSync sync:
                        // Writes its own mesh from a reference mesh; the reference is only read.
                        var own = sync.GetComponent<SkinnedMeshRenderer>();
                        foreach (var binding in sync.Bindings ?? new List<BlendshapeBinding>())
                            result.Block(own, string.IsNullOrEmpty(binding.LocalBlendshape) ? binding.Blendshape : binding.LocalBlendshape,
                                Label(component));
                        continue;
                    case ModularAvatarMergeAnimator merge:
                        result.ReadAnimator(merge.animator, MergePrefix(merge, root), Label(component));
                        continue;
                }
                // VRChat physics and contacts never change blendshapes; their parameter names could look like shape names.
                string space = component.GetType().Namespace ?? "";
                if (space.StartsWith("VRC.SDK3.Dynamics", StringComparison.Ordinal) || space.StartsWith("VRC.Dynamics", StringComparison.Ordinal))
                    continue;
                result.ReadGeneric(component);
            }
            return result;
        }

        private static string Label(Component c) =>
            $"{ObjectNames.NicifyVariableName(c.GetType().Name)} ({c.gameObject.name})";

        private void Block(SkinnedMeshRenderer r, string shape, string why)
        {
            if (!r || !r.sharedMesh || string.IsNullOrEmpty(shape) || r.sharedMesh.GetBlendShapeIndex(shape) < 0) return;
            if (!blocked.TryGetValue(r, out var shapes)) blocked.Add(r, shapes = new Dictionary<string, string>());
            if (!shapes.TryGetValue(shape, out var prior)) shapes.Add(shape, why);
            else if (!prior.Contains(why)) shapes[shape] = prior + ", " + why;
        }

        private void ReadDescriptor(VRCAvatarDescriptor d)
        {
            if (d.lipSync == VRC_AvatarDescriptor.LipSyncStyle.VisemeBlendShape && d.VisemeSkinnedMesh)
                foreach (var shape in d.VisemeBlendShapes ?? Array.Empty<string>())
                    Block(d.VisemeSkinnedMesh, shape, "VRChat 립싱크 (Avatar Descriptor)");
            if (d.lipSync == VRC_AvatarDescriptor.LipSyncStyle.JawFlapBlendShape && d.VisemeSkinnedMesh)
                Block(d.VisemeSkinnedMesh, d.MouthOpenBlendShapeName, "VRChat 립싱크 (Avatar Descriptor)");
            var eyes = d.customEyeLookSettings;
            if (d.enableEyeLook && eyes.eyelidType == VRCAvatarDescriptor.EyelidType.Blendshapes && eyes.eyelidsSkinnedMesh &&
                eyes.eyelidsSkinnedMesh.sharedMesh)
            {
                var mesh = eyes.eyelidsSkinnedMesh.sharedMesh;
                foreach (int index in eyes.eyelidsBlendshapes ?? Array.Empty<int>())
                    if (index >= 0 && index < mesh.blendShapeCount)
                        Block(eyes.eyelidsSkinnedMesh, mesh.GetBlendShapeName(index), "VRChat 눈 깜빡임 (Avatar Descriptor)");
            }
            var layers = (d.baseAnimationLayers ?? Array.Empty<VRCAvatarDescriptor.CustomAnimLayer>())
                .Concat(d.specialAnimationLayers ?? Array.Empty<VRCAvatarDescriptor.CustomAnimLayer>());
            foreach (var layer in layers)
                if (!layer.isDefault && layer.animatorController)
                    ReadAnimator(layer.animatorController, "", $"{layer.type} 레이어 ({layer.animatorController.name})");
        }

        private void ReadAnimator(RuntimeAnimatorController controller, string prefix, string label)
        {
            if (!controller) return;
            foreach (var clip in controller.animationClips.Where(c => c).Distinct())
                foreach (var binding in AnimationUtility.GetCurveBindings(clip))
                {
                    if (binding.type != typeof(SkinnedMeshRenderer) || !binding.propertyName.StartsWith("blendShape.", StringComparison.Ordinal))
                        continue;
                    string path = prefix.Length == 0 ? binding.path : binding.path.Length == 0 ? prefix : prefix + "/" + binding.path;
                    var key = (path, binding.propertyName.Substring("blendShape.".Length));
                    if (!animated.ContainsKey(key)) animated.Add(key, $"{label} · {clip.name}");
                }
        }

        // Where a Merge Animator's relative paths start, from the avatar root.
        private static string MergePrefix(ModularAvatarMergeAnimator merge, Transform root)
        {
            if (merge.pathMode == MergeAnimatorPathMode.Absolute) return "";
            var reference = merge.relativePathRoot?.referencePath;
            var start = string.IsNullOrEmpty(reference) ? merge.transform
                : reference == AvatarObjectReference.AVATAR_ROOT ? root : root.Find(reference) ?? merge.transform;
            return start == root || !start.IsChildOf(root) ? "" : AnimationUtility.CalculateTransformPath(start, root);
        }

        // Any other component: the meshes it refers to (directly, by its own object, or by a path from the avatar root,
        // as Modular Avatar stores them) and the strings it holds. A string that names a blendshape of such a mesh
        // means the component changes that shape.
        private void ReadGeneric(MonoBehaviour component)
        {
            var renderers = new HashSet<SkinnedMeshRenderer>();
            var strings = new HashSet<string>();
            // Shapes the component changes on every mesh that has them, naming no mesh: VRCFury's blendshape action
            // ({ blendShape, allRenderers = true }, the default) inside a Toggle or other feature.
            var everywhere = new HashSet<string>();
            if (component.TryGetComponent<SkinnedMeshRenderer>(out var own)) renderers.Add(own);
            var serialized = new SerializedObject(component);
            var it = serialized.GetIterator();
            bool enter = true;
            for (int guard = 0; it.Next(enter) && guard < 50000; guard++)
            {
                enter = !(it.isArray && it.propertyType == SerializedPropertyType.Generic && it.arraySize > 4096);
                switch (it.propertyType)
                {
                    case SerializedPropertyType.String:
                        var text = it.stringValue;
                        if (string.IsNullOrEmpty(text) || text.Length >= 512) break;
                        strings.Add(text);
                        if (it.name == "blendShape" && Sibling(serialized, it, "allRenderers") is SerializedProperty all &&
                            all.propertyType == SerializedPropertyType.Boolean && all.boolValue) everywhere.Add(text);
                        break;
                    case SerializedPropertyType.ObjectReference:
                        var target = it.objectReferenceValue;
                        if (target is SkinnedMeshRenderer smr) renderers.Add(smr);
                        else if (target is GameObject go && go.TryGetComponent<SkinnedMeshRenderer>(out var onObject)) renderers.Add(onObject);
                        else if (target is Transform t && t.TryGetComponent<SkinnedMeshRenderer>(out var onTransform)) renderers.Add(onTransform);
                        break;
                }
            }
            string label = Label(component);
            if (everywhere.Count > 0)
                foreach (var r in root.GetComponentsInChildren<SkinnedMeshRenderer>(true))
                    foreach (var shape in everywhere)
                        Block(r, shape, label + " · 모든 메시");
            if (strings.Count == 0) return;
            foreach (var text in strings)
            {
                if (text.IndexOfAny(new[] { '\n', '\r' }) >= 0) continue;
                var found = root.Find(text);
                if (found && found.TryGetComponent<SkinnedMeshRenderer>(out var byPath)) renderers.Add(byPath);
            }
            if (renderers.Count == 0) return;
            foreach (var r in renderers)
                if (r && r.sharedMesh && r.transform.IsChildOf(root))
                    foreach (var text in strings)
                        Block(r, text, label);
        }

        private static SerializedProperty Sibling(SerializedObject serialized, SerializedProperty property, string name)
        {
            string path = property.propertyPath;
            int dot = path.LastIndexOf('.');
            return serialized.FindProperty(dot < 0 ? name : path.Substring(0, dot + 1) + name);
        }
    }
}
#endif
