using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace PersonalPoseDeck
{
    internal sealed partial class PoseDeckPoseBrowser
    {
        [SerializeField] private GameObject target;
        [SerializeField] private int applyMode;
        // The deck tab's "메뉴·아이콘 설정" section, open or folded.
        [SerializeField] private bool menuOptionsOpen;
        private Vector2 deckScroll;
        private string deckStatus;
        private MessageType deckStatusType;
        [SerializeField] private int selectedPose = -1;
        // The preset whose result is applied to the current avatar, marked in the preset list.
        private PoseDeckPreset appliedPreset;
        private readonly HashSet<AnimationClip> deckClips = new HashSet<AnimationClip>();

        // Window shell: menu entry, editor lifecycle and the top-level layout. Browsing lives in PoseDeckPoseBrowser.cs.
        // Every NXYUI package puts its windows under the top-level "NXYUI" menu (checked by tools/test_build_repo.py).
        [MenuItem("NXYUI/Personal Pose Deck")]
        private static void OpenStandalone() => OpenFor(Selection.activeGameObject, Selection.activeObject as PoseDeckPreset);

        internal static void OpenFor(GameObject target, PoseDeckPreset targetPreset)
        {
            var w = GetWindow<PoseDeckPoseBrowser>("Personal Pose Deck");
            w.minSize = new Vector2(850, 550);
            if (targetPreset) w.preset = targetPreset;
            var resolved = FindAvatar(target);
            if (resolved && resolved.GetComponent<Animator>()) w.ChangeAvatar(resolved);
            if (!w.target && w.avatar) w.target = FindDeckTarget(w.avatar);
            w.Show();
        }

        private void OnEnable()
        {
            startScan = true;
            previewNeedsBuild = true;
            splitRatio = EditorPrefs.GetFloat(SplitPreference, .55f);
            invertRightDragVertical = EditorPrefs.GetBool(InvertCameraPreference, false);
            LoadPreviewSettings();
            if (!target && avatar) target = FindDeckTarget(avatar);
            EditorApplication.update += Tick;
            EditorApplication.projectChanged += OnProjectChanged;
            EditorApplication.playModeStateChanged += PlayModeChanged;
        }

        private void OnDisable()
        {
            EditorApplication.update -= Tick;
            EditorApplication.projectChanged -= OnProjectChanged;
            EditorApplication.playModeStateChanged -= PlayModeChanged;
            SavePreviewSettings(force: true);
            ResetPreview();
        }

        private void OnProjectChanged() { scanStale = true; gogoSearched = false; Repaint(); }
        private void PlayModeChanged(PlayModeStateChange mode)
        {
            if (mode == PlayModeStateChange.ExitingEditMode || mode == PlayModeStateChange.EnteredEditMode) ResetPreview();
        }

        private void Tick()
        {
            if (EditorApplication.isPlayingOrWillChangePlaymode) return;
            SavePreviewSettings();
            RefreshStaleThumbnails();
            TickAssembly();
            if (startScan)
            {
                try { StartIndex(); }
                catch (Exception e) { startScan = false; pending = null; message = "검색을 시작하지 못했습니다: " + e.Message; Repaint(); }
            }
            if (pending != null) IndexStep();
            TickThumbnail();
            TickVrChecks();
            if (renderer != null && renderer.TickCamera()) Repaint();
            if (!playing || active == null || !active.Clip || !rendererIsReady) return;
            var now = EditorApplication.timeSinceStartup;
            if (now - lastPlayback < 1.0 / 30) return;
            float length = Mathf.Max(.001f, active.Clip.length);
            time += (float)(now - lastPlayback) * playbackSpeed;
            if (loopPlayback) time = Mathf.Repeat(time, length);
            else if (time >= length) { time = length; playing = false; }
            lastPlayback = now;
            sampleDirty = true;
            Repaint();
        }

        private void OnGUI()
        {
            if (EditorApplication.isPlayingOrWillChangePlaymode)
            {
                EditorGUILayout.HelpBox("플레이 모드를 끝낸 뒤 포즈 탐색기를 사용하세요.", MessageType.Info);
                return;
            }
            deckClips.Clear();
            if (preset) foreach (var pose in preset.poses) if (pose != null && pose.clip) deckClips.Add(pose.clip);
            // Header, two rows: the avatar and its preview; the preset and where it is applied.
            using (new EditorGUILayout.HorizontalScope())
            {
                GUILayout.Label(new GUIContent("아바타", "미리 볼 아바타입니다. ‘아바타에 새로 적용’에서는 적용 대상이기도 합니다."), GUILayout.Width(40));
                var next = (GameObject)EditorGUILayout.ObjectField(avatar, typeof(GameObject), true, GUILayout.MinWidth(120));
                if (next != avatar) ChangeAvatar(FindAvatar(next));
                if (GUILayout.Button(new GUIContent("선택", "Hierarchy에서 고른 오브젝트의 아바타로 바꿉니다."), EditorStyles.miniButton, GUILayout.Width(36)))
                    ChangeAvatar(FindAvatar(Selection.activeGameObject));
                var assemble = GUILayout.Toggle(assemblePreview, new GUIContent("MA 조립",
                    "Modular Avatar 조립 결과(Bone Proxy, 의상 합치기 등)로 미리 봅니다. 끄면 원본 그대로 보여 줍니다."), EditorStyles.miniButton, GUILayout.Width(56));
                if (assemble != assemblePreview) { assemblePreview = assemble; ResetPreview(); }
                using (new EditorGUI.DisabledScope(!avatar))
                    if (GUILayout.Button(new GUIContent("갱신", "옷이나 헤어를 바꾼 뒤 미리보기를 다시 만듭니다."), EditorStyles.miniButton, GUILayout.Width(36)))
                        ResetPreview();
                if (avatar)
                {
                    bool fullBuild = assembled != null && assembled.UsedFullBuild;
                    var status = !assemblePreview ? "원본" : assemblyPending ? "조립 대기 중…" : assemblyError != null ? "조립 실패 · 원본 표시" :
                        fullBuild ? "전체 빌드로 조립" : "MA 조립 완료";
                    var tip = assemblyError ?? (fullBuild
                        ? "이 NDMF 버전에서는 MA만 따로 실행할 수 없어 설치된 NDMF 플러그인 전체로 조립했습니다."
                        : null);
                    GUILayout.Label(new GUIContent(status, tip), EditorStyles.miniLabel, GUILayout.Width(90));
                }
            }
            DrawDeckBar();
            GUILayout.Space(2);
            using (new EditorGUILayout.HorizontalScope(GUILayout.ExpandHeight(true)))
            {
                DrawGallery(Mathf.Clamp(position.width * splitRatio, 270f, position.width - 325f));
                DrawSplitter();
                DrawPreview();
            }
        }

        private const string SplitPreference = "PersonalPoseDeck.SplitRatio";
        private float splitRatio = .55f;

        private void DrawSplitter()
        {
            var rect = GUILayoutUtility.GetRect(7f, 7f, 1f, 10000f, GUILayout.Width(7f), GUILayout.ExpandHeight(true));
            int id = GUIUtility.GetControlID("PoseDeckSplitter".GetHashCode(), FocusType.Passive, rect);
            var evt = Event.current;
            EditorGUIUtility.AddCursorRect(rect, MouseCursor.ResizeHorizontal);
            if (evt.type == EventType.Repaint)
                EditorGUI.DrawRect(new Rect(rect.center.x - 1f, rect.y, 2f, rect.height),
                    GUIUtility.hotControl == id ? new Color(.31f, .61f, .85f) : new Color(.35f, .36f, .39f));
            if (evt.type == EventType.MouseDown && evt.button == 0 && rect.Contains(evt.mousePosition))
            {
                if (evt.clickCount > 1) { splitRatio = .55f; EditorPrefs.SetFloat(SplitPreference, splitRatio); }
                else GUIUtility.hotControl = id;
                evt.Use();
                Repaint();
            }
            else if (GUIUtility.hotControl == id && evt.type == EventType.MouseDrag)
            {
                splitRatio = Mathf.Clamp(evt.mousePosition.x, 270f, position.width - 325f) / position.width;
                evt.Use();
                Repaint();
            }
            else if (GUIUtility.hotControl == id && (evt.type == EventType.MouseUp || evt.type == EventType.Ignore))
            {
                GUIUtility.hotControl = 0;
                EditorPrefs.SetFloat(SplitPreference, splitRatio);
                if (evt.type == EventType.MouseUp) evt.Use();
                Repaint();
            }
        }

        private void OnLostFocus() => renderer?.StopCameraDrag();

        private static GameObject FindDeckTarget(GameObject selected)
        {
            if (!selected) return null;
            var avatarRoot = FindAvatar(selected);
            if (selected != avatarRoot && selected.name.IndexOf("gogoloco", StringComparison.OrdinalIgnoreCase) >= 0) return selected;
            var child = avatarRoot.GetComponentsInChildren<Transform>(true).FirstOrDefault(t =>
                t.name.Equals("GogoLoco All (Modular Avatar)", StringComparison.OrdinalIgnoreCase));
            return child ? child.gameObject : null;
        }

        private void Do(Func<string> action)
        {
            try { deckStatus = action(); deckStatusType = MessageType.Info; }
            catch (Exception e) { deckStatus = e.Message; deckStatusType = MessageType.Error; }
        }

        private void NewPreset()
        {
            string path = EditorUtility.SaveFilePanelInProject("포즈 프리셋 저장", "MyPoseDeck", "asset", "프리셋을 Assets에 저장하세요.");
            if (string.IsNullOrEmpty(path)) return;
            preset = CreateInstance<PoseDeckPreset>();
            AssetDatabase.CreateAsset(preset, AssetDatabase.GenerateUniqueAssetPath(path));
            AssetDatabase.SaveAssets();
            selectedPose = -1;
            deckStatus = null;
        }

        // After choosing an avatar, open the preset applied to it and pick the matching apply mode.
        private void LoadAppliedPreset()
        {
            appliedPreset = null;
            if (!avatar) return;
            var (installed, avatarPreset) = PoseDeckAvatarInstall.FindApplied(avatar);
            if (installed) { applyMode = 1; appliedPreset = avatarPreset; }
            else
            {
                appliedPreset = PoseDeckBuilder.InstalledPreset(target);
                applyMode = target ? 0 : 1;
            }
            if (appliedPreset && appliedPreset != preset)
            {
                SelectPreset(appliedPreset);
                deckStatus = $"이 아바타에 적용된 ‘{appliedPreset.name}’ 프리셋을 불러왔습니다. 다른 프리셋은 ‘목록’에서 고를 수 있습니다.";
                deckStatusType = MessageType.Info;
            }
        }

        private void SelectPreset(PoseDeckPreset next)
        {
            if (preset == next) return;
            preset = next;
            selectedPose = -1;
            deckStatus = null;
            Repaint();
        }

        private void ShowPresetMenu()
        {
            var menu = new GenericMenu();
            var presets = AssetDatabase.FindAssets("t:PoseDeckPreset")
                .Select(AssetDatabase.GUIDToAssetPath).Distinct()
                .Select(p => (Path: p, Preset: AssetDatabase.LoadAssetAtPath<PoseDeckPreset>(p)))
                .Where(x => x.Preset)
                .OrderByDescending(x => x.Preset == appliedPreset).ThenBy(x => x.Path, StringComparer.OrdinalIgnoreCase).ToArray();
            if (presets.Length == 0) menu.AddDisabledItem(new GUIContent("프로젝트에 프리셋이 없습니다"));
            foreach (var (path, item) in presets)
            {
                // GenericMenu treats "/" as a submenu separator.
                string folder = (Path.GetDirectoryName(path) ?? "").Replace('\\', '/').Replace("/", " › ");
                string label = $"{item.name}{(item == appliedPreset ? "  (적용 중)" : "")}   —   {folder}  · 포즈 {item.poses.Count}개";
                var choice = item;
                menu.AddItem(new GUIContent(label), item == preset, () => SelectPreset(choice));
            }
            if (presets.Length > 0) menu.AddSeparator("");
            foreach (var (path, item) in presets)
            {
                string folder = (Path.GetDirectoryName(path) ?? "").Replace('\\', '/').Replace("/", " › ");
                var choice = item;
                menu.AddItem(new GUIContent($"삭제/{item.name}{(item == appliedPreset ? "  (적용 중)" : "")}   —   {folder}"), false, () => DeletePreset(choice));
            }
            menu.ShowAsContext();
        }

        private void DeletePreset(PoseDeckPreset item)
        {
            if (!item) return;
            string path = AssetDatabase.GetAssetPath(item);
            string name = item.name;
            string applied = item == appliedPreset
                ? "\n\n이 아바타에 적용된 프리셋입니다. 이미 적용된 덱은 그대로 동작하지만, 이 프리셋으로 다시 생성할 수는 없게 됩니다." : "";
            if (!EditorUtility.DisplayDialog("포즈 프리셋 삭제",
                $"‘{name}’ 프리셋(포즈 {item.poses.Count}개)을 휴지통으로 옮길까요?\n{path}{applied}", "휴지통으로", "취소")) return;
            bool selected = item == preset;
            Do(() =>
            {
                PoseDeckBuilder.TrashPreset(item);
                if (selected) { preset = null; selectedPose = -1; }
                if (appliedPreset == item || !appliedPreset) appliedPreset = null;
                deckProblemsCheckedAt = 0;
                return $"‘{name}’ 프리셋을 휴지통으로 옮겼습니다. 필요하면 시스템 휴지통에서 되살릴 수 있습니다.\n{path}";
            });
        }

        private int DeckIndexOf(AnimationClip clip) => preset && clip ? preset.poses.FindIndex(p => p != null && p.clip == clip) : -1;

        private void SyncDeckSelection()
        {
            int index = DeckIndexOf(active?.Clip);
            if (index >= 0) selectedPose = index;
        }

        // Preview a deck pose, even when the gallery filters currently hide its clip.
        private void ShowClip(AnimationClip clip)
        {
            if (!clip) return;
            var item = index.FirstOrDefault(i => i.Clip == clip);
            if (item == null)
            {
                string path = AssetDatabase.GetAssetPath(clip);
                item = new Item
                {
                    Clip = clip, Name = clip.name, Path = path, Humanoid = clip.humanMotion && !clip.legacy,
                    AvatarMask = DetectAvatarAliases(clip.name + " " + path), GroupRoot = GroupRootFor(path),
                };
            }
            Select(item);
            Repaint();
        }

        private static float SuggestedHeight(PoseCategory category) =>
            category == PoseCategory.Sit ? PoseDeckBuilder.HeightPresets[1].Value :
            category == PoseCategory.Lie ? PoseDeckBuilder.HeightPresets[3].Value : PoseDeckBuilder.DefaultStartHeight;

        private static readonly GUIContent[] ApplyModeOptions =
        {
            new GUIContent("기존 GoGoLoco에", "기존 GoGoLoco에 적용: 아바타에 달린 GoGoLoco MA 오브젝트의 Base와 메뉴만 바꿉니다. 기존 Action이나 AFK 개조는 유지됩니다."),
            new GUIContent("아바타에 새로", "아바타에 새로 적용: 프로젝트의 GoGoLoco 프리팹을 찾아 위의 아바타 아래에 배치합니다."),
        };

        // One row: the preset, where it goes, and the actions on it.
        private void DrawDeckBar()
        {
            bool onAvatar = applyMode == 1;
            using (new EditorGUILayout.HorizontalScope())
            {
                GUILayout.Label(new GUIContent("프리셋", appliedPreset ? $"포즈 프리셋. 이 아바타에 적용된 프리셋: {appliedPreset.name}" : "포즈 프리셋"),
                    GUILayout.Width(40));
                var picked = (PoseDeckPreset)EditorGUILayout.ObjectField(preset, typeof(PoseDeckPreset), false, GUILayout.MinWidth(100));
                if (picked != preset) SelectPreset(picked);
                if (GUILayout.Button(new GUIContent("목록", "프로젝트의 프리셋을 고르거나 삭제합니다. 이 아바타에 적용된 프리셋이 맨 위에 표시됩니다."),
                    EditorStyles.miniButtonLeft, GUILayout.Width(36))) ShowPresetMenu();
                if (GUILayout.Button(new GUIContent("새로", "새 프리셋을 Assets에 만듭니다."), EditorStyles.miniButtonRight, GUILayout.Width(36))) NewPreset();
                GUILayout.Space(6);
                int next = EditorGUILayout.Popup(applyMode, ApplyModeOptions, GUILayout.Width(108));
                if (next != applyMode) { applyMode = next; deckStatus = null; onAvatar = applyMode == 1; }
                if (onAvatar)
                    GUILayout.Label(new GUIContent(avatar ? "→ " + avatar.name : "→ 아바타를 고르세요", "왼쪽 위에서 고른 아바타에 적용합니다."),
                        EditorStyles.miniLabel, GUILayout.MinWidth(60));
                else
                {
                    target = (GameObject)EditorGUILayout.ObjectField(new GUIContent("", "아바타에 달린 GoGoLoco MA 오브젝트"), target, typeof(GameObject), true,
                        GUILayout.MinWidth(100));
                    if (GUILayout.Button(new GUIContent("찾기", "아바타에서 GoGoLoco 오브젝트를 찾습니다."), EditorStyles.miniButton, GUILayout.Width(36)))
                        target = FindDeckTarget(avatar);
                }
                GUILayout.Space(6);
                using (new EditorGUI.DisabledScope(!preset || !(onAvatar ? avatar : target)))
                {
                    if (GUILayout.Button(new GUIContent("슬롯 확인", "원본 높이가 유지되는 포즈 수와 커스텀 슬롯 수를 확인합니다."),
                        EditorStyles.miniButtonLeft, GUILayout.Width(60))) Do(() =>
                        onAvatar ? PoseDeckAvatarInstall.Preview(preset, avatar) : PoseDeckBuilder.Preview(preset, target));
                    if (GUILayout.Button(new GUIContent("생성 및 적용", "프리셋으로 덱을 만들어 아바타에 적용합니다."), EditorStyles.miniButtonMid,
                        GUILayout.Width(76))) GenerateAndApply();
                }
                using (new EditorGUI.DisabledScope(onAvatar ? !avatar : !target))
                {
                    if (GUILayout.Button(new GUIContent(onAvatar ? "적용 제거" : "원복",
                            onAvatar ? "이 아바타에 이 방식으로 붙인 Pose Deck을 제거합니다." : "GoGoLoco를 원래 Base와 메뉴로 되돌립니다."),
                        EditorStyles.miniButtonRight, GUILayout.Width(onAvatar ? 58 : 40))) Do(() =>
                    {
                        if (onAvatar) PoseDeckAvatarInstall.Remove(avatar);
                        else PoseDeckBuilder.Restore(preset, target);
                        ResetPreview();
                        return onAvatar ? "이 아바타에 추가한 Pose Deck을 제거했습니다. 씬을 저장하세요."
                            : "원래 Base와 메뉴로 복구했습니다. 씬을 저장하세요.";
                    });
                }
            }
            DrawDeckProblems(onAvatar ? avatar : target ? target : avatar);
            if (!string.IsNullOrEmpty(deckStatus)) EditorGUILayout.HelpBox(deckStatus, deckStatusType);
        }

        private void GenerateAndApply()
        {
            bool onAvatar = applyMode == 1;
            Do(() =>
            {
                string iconNote = null;
                var icons = preset.generateIcons ? RenderPoseIcons(out iconNote) : null;
                try
                {
                    string folder = onAvatar ? PoseDeckAvatarInstall.Apply(preset, avatar, icons)
                        : PoseDeckBuilder.GenerateAndApply(preset, target, icons);
                    ResetPreview();
                    deckProblemsCheckedAt = 0;
                    string note = !preset.generateIcons ? "" : icons == null ? "\n" + iconNote : $" 포즈 아이콘 {icons.Count}개를 만들었습니다.";
                    return $"‘{preset.name}’의 포즈 {preset.poses.Count}개를 적용했습니다.{note} 씬을 저장하고 Build & Test로 확인하세요.\n" + folder;
                }
                finally
                {
                    if (icons != null) foreach (var texture in icons.Values) if (texture) DestroyImmediate(texture);
                }
            });
        }

        private GameObject deckProblemsRoot;
        private GameObject[] broken = Array.Empty<GameObject>();
        private double deckProblemsCheckedAt;

        // A deck generated before 0.15.0 with custom poses, and the preset and apply mode that made it (preset null when unknown).
        private sealed class StaleDeck
        {
            public GameObject Gogo;
            public string[] Poses;
            public PoseDeckPreset Preset;
            public bool OnAvatar;
        }
        private StaleDeck[] stale = Array.Empty<StaleDeck>();

        private static StaleDeck[] FindStaleDecks(GameObject root)
        {
            var avatarRoot = FindAvatar(root);
            if (!avatarRoot || !avatarRoot.scene.IsValid()) return Array.Empty<StaleDeck>();
            var found = PoseDeckBuilder.FindStaleDecks(avatarRoot);
            if (found.Length == 0) return Array.Empty<StaleDeck>();
            var (installed, avatarPreset) = PoseDeckAvatarInstall.FindApplied(avatarRoot);
            return found.Select(x => x.gogo == installed
                ? new StaleDeck { Gogo = x.gogo, Poses = x.poses, Preset = avatarPreset, OnAvatar = true }
                : new StaleDeck { Gogo = x.gogo, Poses = x.poses, Preset = PoseDeckBuilder.InstalledPreset(x.gogo) }).ToArray();
        }

        // Problems with what is applied to the avatar: links to deleted generated files (cannot be applied or restored)
        // and decks made before 0.15.0 whose custom poses barely show in game. Explains each and offers the fix.
        private void DrawDeckProblems(GameObject root)
        {
            if (Event.current.type == EventType.Layout &&
                (root != deckProblemsRoot || EditorApplication.timeSinceStartup - deckProblemsCheckedAt > 1.0))
            {
                deckProblemsRoot = root;
                deckProblemsCheckedAt = EditorApplication.timeSinceStartup;
                bool inScene = root && root.scene.IsValid();
                broken = inScene ? PoseDeckBuilder.FindBrokenLinks(root) : Array.Empty<GameObject>();
                stale = inScene ? FindStaleDecks(root) : Array.Empty<StaleDeck>();
            }
            foreach (var deck in stale)
            {
                if (!deck.Gogo) continue;
                string names = string.Join(", ", deck.Poses.Take(4)) + (deck.Poses.Length > 4 ? $" 외 {deck.Poses.Length - 4}개" : "");
                using (new EditorGUILayout.HorizontalScope())
                {
                    EditorGUILayout.HelpBox($"‘{deck.Gogo.name}’의 덱은 0.15.0 이전에 만들어져, 커스텀 포즈 {deck.Poses.Length}개({names})에 GoGoLoco 기준 포즈가 " +
                        "지정돼 있지 않습니다. 게임에서 이 포즈들이 거의 적용되지 않습니다. " +
                        (deck.Preset ? $"오른쪽 버튼으로 ‘{deck.Preset.name}’ 프리셋을 다시 생성 및 적용하세요."
                            : "이 덱을 만든 프리셋을 골라 ‘생성 및 적용’을 다시 눌러 주세요."), MessageType.Warning);
                    using (new EditorGUI.DisabledScope(!deck.Preset))
                        if (GUILayout.Button(new GUIContent("다시 생성\n및 적용",
                            deck.Preset ? $"‘{deck.Preset.name}’ 프리셋으로 이 덱을 다시 만듭니다." : "이 덱을 만든 프리셋을 찾지 못했습니다."),
                            GUILayout.Width(80), GUILayout.Height(40)))
                        {
                            applyMode = deck.OnAvatar ? 1 : 0;
                            if (!deck.OnAvatar) target = deck.Gogo;
                            SelectPreset(deck.Preset);
                            GenerateAndApply();
                            GUIUtility.ExitGUI();
                        }
                }
            }
            foreach (var go in broken)
            {
                if (!go) continue;
                var trashed = PoseDeckGeneratedCleanup.Trashed;
                string recent = trashed.Length == 0 ? "" : "\n최근 자동 정리한 폴더:\n" + string.Join("\n", trashed.Take(3));
                using (new EditorGUILayout.HorizontalScope())
                {
                    EditorGUILayout.HelpBox($"‘{go.name}’의 GoGoLoco Base나 메뉴가 사라진 파일을 가리킵니다. 생성본 폴더를 지운 뒤 실행 취소했거나 " +
                        "자동 정리 후 되돌린 경우입니다. 휴지통에서 그 PoseDeck_Generated 폴더를 프로젝트의 원래 자리로 되살리면 그대로 다시 연결됩니다. " +
                        "아니면 오른쪽 버튼으로 GoGoLoco 원본 연결로 되돌린 뒤 다시 ‘생성 및 적용’하세요." + recent, MessageType.Warning);
                    if (GUILayout.Button(new GUIContent("원본으로\n되돌리기", "끊어진 Base와 메뉴만 GoGoLoco 프리팹의 값으로 되돌립니다."),
                        GUILayout.Width(80), GUILayout.Height(40)))
                    {
                        var fix = go;
                        Do(() =>
                        {
                            int count = PoseDeckBuilder.RevertBrokenLinks(fix);
                            deckProblemsCheckedAt = 0;
                            ResetPreview();
                            return $"‘{fix.name}’의 끊어진 연결 {count}개를 GoGoLoco 원본으로 되돌렸습니다. 다시 ‘생성 및 적용’하고 씬을 저장하세요.";
                        });
                    }
                }
            }
        }

        private Vector2 deckTabScroll;

        // The left column's deck tab: the menu options (folded away), the VR holds, the pose list and the chosen pose.
        private void DrawDeckTab()
        {
            if (!preset)
            {
                EditorGUILayout.HelpBox("위의 ‘프리셋’에서 프리셋을 고르거나 ‘새로’로 만드세요.", MessageType.Info);
                return;
            }
            using (var scroll = new EditorGUILayout.ScrollViewScope(deckTabScroll))
            {
                deckTabScroll = scroll.scrollPosition;
                DrawDeckSettings();
            }
        }

        private void DrawDeckSettings()
        {
            if (!preset) return;
            menuOptionsOpen = EditorGUILayout.Foldout(menuOptionsOpen, new GUIContent($"메뉴·아이콘 설정 · ‘{preset.menuTitle}’",
                "메뉴 이름, 기존 GoGoLoco 메뉴, 페이지마다 초기화·높이 조절, 포즈 아이콘, 이전 생성본 자동 정리"), true);
            using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
            {
                if (menuOptionsOpen) DrawMenuOptions();
                DrawVrBulk();
                DrawFitBulk();
                DrawPoseList();
            }
        }

        private void DrawMenuOptions()
        {
            EditorGUI.BeginChangeCheck();
            var title = EditorGUILayout.TextField("메뉴 이름", preset.menuTitle);
            var keep = EditorGUILayout.ToggleLeft("메뉴 안에 기존 GoGoLoco도 남기기", preset.keepStockMenu);
            var everyPage = EditorGUILayout.ToggleLeft(new GUIContent("분류 페이지마다 초기화·높이 조절 넣기",
                "각 분류(앉기·눕기 등) 페이지 맨 앞에 초기화와 높이 조절을 둡니다. 포즈를 고른 자리에서 바로 높이를 맞출 수 있습니다. 페이지당 포즈 자리는 5개가 됩니다."),
                preset.controlsOnEveryPage);
            var icons = EditorGUILayout.ToggleLeft(new GUIContent("포즈 아이콘 만들기",
                "‘생성 및 적용’ 때 미리보기 아바타로 포즈마다 배경이 투명한 메뉴 아이콘(256px)을 찍어 생성 폴더의 Icons에 저장합니다. 미리보기의 GoGoLoco 높이·트래킹 설정을 따릅니다. 포즈별로 직접 넣은 아이콘이 있으면 그것을 씁니다."),
                preset.generateIcons);
            int iconView = preset.iconView;
            bool keepNative = preset.keepNativeIcons;
            using (new EditorGUI.DisabledScope(!icons))
            using (new EditorGUILayout.HorizontalScope())
            {
                GUILayout.Space(16);
                EditorGUILayout.LabelField("시점", GUILayout.Width(28));
                iconView = EditorGUILayout.Popup(Mathf.Clamp(iconView, 0, IconViews.Length - 1),
                    IconViews.Select(v => v.Label).ToArray(), GUILayout.Width(80));
                keepNative = EditorGUILayout.ToggleLeft(new GUIContent("GoGoLoco 원본 포즈는 원래 아이콘",
                    "GoGoLoco 원본 슬롯을 그대로 쓰는 포즈는 찍은 아이콘 대신 GoGoLoco 메뉴의 아이콘을 씁니다."), keepNative);
            }
            if (EditorGUI.EndChangeCheck())
            {
                Undo.RecordObject(preset, "Edit Pose Deck Settings");
                preset.menuTitle = title;
                preset.keepStockMenu = keep;
                preset.controlsOnEveryPage = everyPage;
                preset.generateIcons = icons;
                preset.iconView = iconView;
                preset.keepNativeIcons = keepNative;
                EditorUtility.SetDirty(preset);
            }
            PoseDeckGeneratedCleanup.Enabled = EditorGUILayout.ToggleLeft(new GUIContent("다시 적용하면 이전 생성본 자동 정리",
                "다시 ‘생성 및 적용’해 바뀐 이전 PoseDeck_Generated 폴더를, 씬을 저장한 뒤 아무 곳에서도 쓰지 않으면 휴지통으로 옮깁니다. 이 PC의 Unity 전체 설정입니다."),
                PoseDeckGeneratedCleanup.Enabled);
        }

        private void DrawPoseList()
        {
            if (selectedPose >= preset.poses.Count) selectedPose = -1;
            var activeClip = active?.Clip;
            // As tall as the list, up to 40% of the window; the chosen pose's settings follow below it.
            float listHeight = Mathf.Clamp(preset.poses.Count * 21f + 4f, 46f, Mathf.Max(132f, position.height * .4f));
            using (var view = new EditorGUILayout.ScrollViewScope(deckScroll, GUILayout.Height(listHeight)))
            {
                deckScroll = view.scrollPosition;
                for (int i = 0; i < preset.poses.Count; i++)
                {
                    int index = i;
                    var row = preset.poses[i];
                    var line = EditorGUILayout.BeginHorizontal();
                    try
                    {
                        bool showing = row.clip && row.clip == activeClip;
                        if (Event.current.type == EventType.Repaint && (i == selectedPose || showing))
                            EditorGUI.DrawRect(line, showing ? new Color(.23f, .46f, .70f, .35f) : new Color(1f, 1f, 1f, .07f));
                        if (GUILayout.Button(new GUIContent((i + 1).ToString(), "클릭하면 오른쪽 미리보기에 이 포즈를 보여 주고 아래에서 높이를 설정합니다."),
                            EditorStyles.miniButton, GUILayout.Width(26)))
                        {
                            ShowClip(row.clip);
                            selectedPose = index; // after ShowClip, which selects the first row with that clip
                            GUI.FocusControl(null);
                        }
                        EditorGUI.BeginChangeCheck();
                        var label = EditorGUILayout.TextField(row.label ?? "", GUILayout.MinWidth(46));
                        var clip = (AnimationClip)EditorGUILayout.ObjectField(row.clip, typeof(AnimationClip), false, GUILayout.MinWidth(65));
                        var cat = EditorGUILayout.Popup((int)row.category, PoseDeckBuilder.CategoryNames, GUILayout.Width(52));
                        if (EditorGUI.EndChangeCheck())
                        {
                            Change("Edit Pose", () => { row.label = label; row.clip = clip; row.category = (PoseCategory)cat; });
                            if (index == selectedPose && clip) ShowClip(clip);
                        }
                        GUILayout.Label(new GUIContent(row.overrideHeight ? $"↕{row.height:0.00}" : "↕기본",
                            row.overrideHeight ? "시작 높이(Go/Float)를 직접 지정했습니다." : "GoGoLoco의 시작 높이를 씁니다."),
                            EditorStyles.miniLabel, GUILayout.Width(40));
                        DrawVrMark(row);
                        using (new EditorGUI.DisabledScope(i == 0))
                            if (GUILayout.Button("↑", GUILayout.Width(22)))
                            {
                                Change("Move Pose", () => { preset.poses.RemoveAt(index); preset.poses.Insert(index - 1, row); });
                                if (selectedPose == index) selectedPose = index - 1;
                                break;
                            }
                        using (new EditorGUI.DisabledScope(i == preset.poses.Count - 1))
                            if (GUILayout.Button("↓", GUILayout.Width(22)))
                            {
                                Change("Move Pose", () => { preset.poses.RemoveAt(index); preset.poses.Insert(index + 1, row); });
                                if (selectedPose == index) selectedPose = index + 1;
                                break;
                            }
                        if (GUILayout.Button("×", GUILayout.Width(22)))
                        {
                            Change("Remove Pose", () => preset.poses.RemoveAt(index));
                            if (selectedPose == index) selectedPose = -1;
                            else if (selectedPose > index) selectedPose--;
                            break;
                        }
                    }
                    finally { EditorGUILayout.EndHorizontal(); }
                }
            }
            using (new EditorGUILayout.HorizontalScope())
            {
                if (GUILayout.Button("+ 포즈 추가", EditorStyles.miniButtonLeft)) Change("Add Pose", () => preset.poses.Add(new PoseEntry()));
                if (GUILayout.Button(new GUIContent("+ Project 선택", "Project 창에서 고른 애니메이션 클립을 넣습니다."), EditorStyles.miniButtonMid))
                {
                    var clips = Selection.objects.OfType<AnimationClip>().ToArray();
                    if (clips.Length != 0) Change("Add Selected Poses", () =>
                        preset.poses.AddRange(clips.Select(c => new PoseEntry { clip = c })));
                    else { deckStatus = "Project 창에서 애니메이션 클립을 먼저 선택하세요."; deckStatusType = MessageType.Warning; }
                }
                if (GUILayout.Button(new GUIContent("저장", "목록과 메뉴 설정을 프리셋에 저장합니다. 아바타에 반영하려면 ‘생성 및 적용’을 누르세요."), EditorStyles.miniButtonMid)) Do(() =>
                {
                    AssetDatabase.SaveAssetIfDirty(preset);
                    return $"‘{preset.name}’에 포즈 {preset.poses.Count}개를 저장했습니다. 아바타에 반영하려면 ‘생성 및 적용’을 눌러 주세요.";
                });
                if (GUILayout.Button(new GUIContent("생성본 정리",
                    "씬·프리팹·프리셋 어디에서도 쓰지 않는 PoseDeck_Generated 폴더를 휴지통으로 옮깁니다."), EditorStyles.miniButtonRight)) Do(CleanUpGenerated);
            }
            DrawPoseDetail();
        }

        private void DrawPoseDetail()
        {
            if (selectedPose < 0 || selectedPose >= preset.poses.Count) return;
            var row = preset.poses[selectedPose];
            using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
            {
                string name = !string.IsNullOrWhiteSpace(row.label) ? row.label.Trim() : row.clip ? row.clip.name : "(클립 없음)";
                EditorGUILayout.LabelField($"{selectedPose + 1}. {name} · 시작 높이", EditorStyles.boldLabel);
                bool custom = row.overrideHeight;
                float height = row.height;
                if (DrawStartHeight(ref custom, ref height, row.category, row.clip && active?.Clip == row.clip,
                    new GUIContent("시작 높이 직접 지정", "포즈 버튼을 눌렀다 떼면 GoGoLoco 높이(Go/Float)를 이 값으로 맞춥니다. 끄면 GoGoLoco 기본값을 씁니다."),
                    "번호를 눌러 이 포즈를 미리보기에 띄우면 높이를 눈으로 확인하고 맞출 수 있습니다."))
                    Change("Edit Pose Start Height", () => { row.overrideHeight = custom; row.height = Mathf.Clamp01(height); });
                EditorGUILayout.LabelField(custom
                    ? "포즈를 고르면 이 높이에서 시작합니다. 같은 포즈를 다시 누르면 GoGoLoco 규칙대로 좌우가 바뀌고 높이도 이 값으로 다시 맞춰집니다. 포즈 중 ▲/▼로 직접 높이를 바꾼 뒤에는 GoGoLoco처럼 그 높이를 유지합니다. ‘생성 및 적용’ 후 반영됩니다."
                    : "GoGoLoco 기본값을 씁니다. 커스텀 슬롯은 서기 높이(0.25)로 시작하고, GoGoLoco 원본 포즈는 포즈별 값으로 시작합니다.",
                    EditorStyles.wordWrappedMiniLabel);

                EditorGUILayout.Space(2);
                var icon = (Texture2D)EditorGUILayout.ObjectField(new GUIContent("메뉴 아이콘",
                    "이 포즈 버튼에 쓸 아이콘입니다. 비우면 ‘포즈 아이콘 만들기’로 찍은 아이콘을 씁니다."),
                    row.icon, typeof(Texture2D), false, GUILayout.Height(EditorGUIUtility.singleLineHeight));
                if (icon != row.icon) Change("Edit Pose Icon", () => row.icon = icon);
                EditorGUILayout.LabelField(row.icon ? "직접 넣은 아이콘을 씁니다. ‘생성 및 적용’ 후 반영됩니다."
                    : preset.generateIcons ? "비워 두면 ‘생성 및 적용’ 때 미리보기로 찍은 아이콘을 씁니다."
                    : "비워 두면 아이콘 없이 만듭니다. GoGoLoco 원본 포즈는 원래 아이콘을 씁니다.", EditorStyles.wordWrappedMiniLabel);
                DrawVrDetail(row);
            }
        }

        // Where the last Go/Float slider was drawn, in screen space (read by the GUI tests).
        internal Rect heightSliderScreenRect;

        // Start-height controls for a deck pose and for the poses about to be added. `previewing` is true while the
        // preview shows the pose these values belong to; `notPreviewing` explains how to get there. True when changed.
        // `compact` shows only the toggle while it is off (under the gallery, where height is scarce).
        private bool DrawStartHeight(ref bool custom, ref float height, PoseCategory category, bool previewing,
            GUIContent toggle, string notPreviewing, bool compact = false)
        {
            bool changed = false;
            bool nextCustom = EditorGUILayout.ToggleLeft(toggle, custom);
            if (nextCustom != custom)
            {
                changed = true;
                custom = nextCustom;
                // First use: start from GoGoLoco's typical value for the category instead of the standing default.
                if (custom && Mathf.Approximately(height, PoseDeckBuilder.DefaultStartHeight)) height = SuggestedHeight(category);
            }
            if (compact && !custom) return changed;
            using (new EditorGUI.DisabledScope(!custom))
            {
                float slider = EditorGUILayout.Slider(new GUIContent("Go/Float", "0은 가장 낮게, 1은 가장 높게. GoGoLoco 커스텀 슬롯의 기본값은 0.25입니다."),
                    height, 0f, 1f);
                if (Event.current.type == EventType.Repaint) heightSliderScreenRect = GUIUtility.GUIToScreenRect(GUILayoutUtility.GetLastRect());
                if (!Mathf.Approximately(slider, height)) { height = slider; changed = true; }
                using (new EditorGUILayout.HorizontalScope())
                {
                    GUILayout.Label("GoGoLoco 기준", EditorStyles.miniLabel, GUILayout.Width(74));
                    foreach (var (label, value) in PoseDeckBuilder.HeightPresets)
                        if (GUILayout.Button($"{label} {value:0.00}", EditorStyles.miniButton)) { height = value; changed = true; }
                }
            }
            using (new EditorGUILayout.HorizontalScope())
            {
                bool canFit = previewing && renderer != null && renderer.SimulatingGoGoLoco &&
                    renderer.Mode != PoseDeckPosePreview.Tracking.FullBody;
                using (new EditorGUI.DisabledScope(!canFit))
                    if (GUILayout.Button(new GUIContent("바닥에 맞추기",
                        "미리보기에서 GoGoLoco를 실행해, 메시의 가장 낮은 점이 바닥에 닿는 시작 높이를 찾아 넣습니다. 좌우 반전과 현재 재생 위치를 따릅니다."),
                        GUILayout.Width(96)))
                    {
                        float? fit;
                        try
                        {
                            EditorUtility.DisplayProgressBar("바닥에 맞추기", "GoGoLoco로 시작 높이를 맞추는 중…", .5f);
                            fit = renderer.FitStartHeight(time);
                        }
                        finally { EditorUtility.ClearProgressBar(); }
                        if (fit is float value) { custom = true; height = fitLikeGoGoLoco ? PoseDeckBuilder.LikeGoGoLoco(value) : value; changed = true; }
                        else { deckStatus = "이 포즈는 바닥에 맞출 수 없습니다. GoGoLoco 높이 미리보기 상태를 확인하세요."; deckStatusType = MessageType.Warning; }
                        sampleDirty = true;
                    }
                fitLikeGoGoLoco = GUILayout.Toggle(fitLikeGoGoLoco, new GUIContent("GoGoLoco처럼", FitLikeGoGoLocoTip), GUILayout.Width(92));
                EditorGUILayout.LabelField(canFit ? $"미리보기와 같은 조건({TrackingLabels[previewTracking]})으로 맞춥니다."
                    : previewing && renderer?.Mode == PoseDeckPosePreview.Tracking.FullBody ? "풀바디에서는 GoGoLoco가 포즈를 재생하지 않아 맞출 수 없습니다. 트래킹을 VR이나 데스크톱으로 바꾸세요."
                    : previewing ? "미리보기 아래 ‘GoGoLoco 높이’를 켜면 쓸 수 있습니다."
                    : notPreviewing, EditorStyles.wordWrappedMiniLabel);
            }
            return changed;
        }

        // Renders each pose in the deck as a 256 px menu icon on a transparent background, following the preview's
        // GoGoLoco start height and tracking mode under neutral lighting. Null (with a note) when nothing can be rendered.
        internal static readonly (string Label, float Yaw, float Pitch)[] IconViews =
            { ("비스듬히", 45f, -25f), ("정면", 0f, -8f), ("측면", 90f, -8f) };

        private Dictionary<AnimationClip, Texture2D> RenderPoseIcons(out string note)
        {
            note = null;
            var source = PreviewRoot;
            if (!source)
            {
                note = "포즈 아이콘은 미리보기 아바타가 있어야 만들 수 있어 이번에는 건너뛰었습니다.";
                return null;
            }
            var icons = new Dictionary<AnimationClip, Texture2D>();
            try
            {
                using (var camera = new PoseDeckPosePreview(source))
                {
                    if (!camera.HasRenderers)
                    {
                        note = "미리보기 아바타에 렌더러가 없어 포즈 아이콘을 건너뛰었습니다.";
                        return null;
                    }
                    // GoGoLoco plays no poses in full body, so icons use the VR pose there.
                    camera.Mode = previewTracking == (int)PoseDeckPosePreview.Tracking.FullBody
                        ? PoseDeckPosePreview.Tracking.VR : (PoseDeckPosePreview.Tracking)previewTracking;
                    camera.UseGoGoLoco(gogoPreview ? GoGoLocoSource() : null);
                    var view = IconViews[Mathf.Clamp(preset.iconView, 0, IconViews.Length - 1)];
                    // Poses that all carry their own icon need no render.
                    foreach (var clip in preset.poses.Where(p => p.clip && !p.icon).Select(p => p.clip).Distinct())
                    {
                        if (clip.legacy || (clip.humanMotion && !camera.HasHumanoidAvatar)) continue;
                        camera.StartHeight = PreviewStartHeight(clip, out _);
                        var texture = camera.CaptureThumbnail(clip, 256, readable: true, transparent: true, view.Yaw, view.Pitch);
                        if (texture) icons[clip] = texture;
                    }
                }
            }
            catch (Exception e)
            {
                foreach (var texture in icons.Values) if (texture) DestroyImmediate(texture);
                note = "포즈 아이콘을 만들지 못했습니다: " + e.Message;
                return null;
            }
            return icons;
        }

        private static string CleanUpGenerated()
        {
            var folders = PoseDeckBuilder.FindUnusedGeneratedFolders();
            if (folders.Length == 0) return "정리할 생성본이 없습니다. 씬·프리팹·프리셋이 쓰는 폴더는 남겨 둡니다.";
            var list = string.Join("\n", folders.Take(12)) + (folders.Length > 12 ? $"\n외 {folders.Length - 12}개" : "");
            if (!EditorUtility.DisplayDialog("안 쓰는 생성본 정리",
                    $"Assets의 씬·프리팹·에셋 어디에서도 쓰지 않는 생성 폴더 {folders.Length}개를 휴지통으로 옮깁니다.\n\n{list}",
                    "휴지통으로 이동", "취소"))
                return "정리를 취소했습니다.";
            int moved = folders.Count(AssetDatabase.MoveAssetToTrash);
            return $"생성 폴더 {moved}개를 휴지통으로 옮겼습니다." +
                (moved < folders.Length ? $" {folders.Length - moved}개는 옮기지 못했습니다. Unity Console을 확인하세요." : "");
        }

        private const string FitLikeGoGoLocoTip = "‘바닥에 맞추기’가 GoGoLoco 기본 포즈와 같은 기준으로 맞춥니다. GoGoLoco 기본 포즈는 바닥에 닿는 시작 높이보다 약 10% 높게 만들어져 있습니다(기본 포즈 31개를 미리보기로 잰 값). 정확히 바닥에 닿는 높이는 VR에서 GoGoLoco 기본 포즈보다 낮게 앉습니다. 끄면 정확히 바닥에 닿게 맞춥니다.";

        // "바닥에 다시 맞추기 · 모든 포즈": every deck pose with its own start height that rests on the floor now (its lowest
        // point no higher than FloorTolerance above it, or below it) is fitted again at its first frame. Poses meant to float
        // or hang (ghosts, a seat above the floor) are left as they are.
        private void DrawFitBulk()
        {
            if (!preset || preset.poses.Count == 0) return;
            bool canFit = renderer != null && gogoPreview && renderer.HasHumanoidAvatar && renderer.Mode != PoseDeckPosePreview.Tracking.FullBody;
            using (new EditorGUILayout.HorizontalScope())
            {
                GUILayout.Label(new GUIContent("바닥 높이 · 모든 포즈",
                    "시작 높이를 직접 지정했고 지금 바닥에 닿아 있거나 바닥 아래로 들어간 포즈를 모두 다시 ‘바닥에 맞추기’ 합니다. " +
                    "바닥에서 떠 있게 만든 포즈(유령, 의자 위 등)는 그대로 둡니다. 각 클립의 첫 프레임으로 잽니다."),
                    EditorStyles.miniLabel, GUILayout.Width(132));
                using (new EditorGUI.DisabledScope(!canFit))
                    if (GUILayout.Button(new GUIContent("바닥에 다시 맞추기", canFit ? "미리보기와 같은 조건으로 맞춥니다."
                            : "미리보기 아래 ‘GoGoLoco 높이’를 켜고, 트래킹을 VR이나 데스크톱으로 두면 쓸 수 있습니다."),
                        EditorStyles.miniButton))
                        Do(FitAllPoses);
                fitLikeGoGoLoco = GUILayout.Toggle(fitLikeGoGoLoco, new GUIContent("GoGoLoco처럼 10% 띄우기", FitLikeGoGoLocoTip));
            }
        }

        // How far above the floor a pose may rest and still count as standing on it for "바닥에 다시 맞추기".
        private float FloorTolerance => Mathf.Max(.02f, renderer.EyeHeight * .05f);

        private string FitAllPoses()
        {
            float tolerance = FloorTolerance;
            var fitted = new List<(PoseEntry pose, float height)>();
            int floating = 0, failed = 0;
            try
            {
                for (int i = 0; i < preset.poses.Count; i++)
                {
                    var pose = preset.poses[i];
                    if (pose == null || !pose.overrideHeight || !pose.clip || !pose.clip.humanMotion) continue;
                    EditorUtility.DisplayProgressBar("바닥에 다시 맞추기", $"{pose.label} ({i + 1}/{preset.poses.Count})", (float)i / preset.poses.Count);
                    renderer.SetClip(pose.clip);
                    renderer.StartHeight = pose.height;
                    if (!(renderer.MeasureLowest(0f) is float low)) { failed++; continue; }
                    if (low > tolerance) { floating++; continue; }
                    if (renderer.FitStartHeight(0f) is float touching)
                        fitted.Add((pose, fitLikeGoGoLoco ? PoseDeckBuilder.LikeGoGoLoco(touching) : touching));
                    else failed++;
                }
            }
            finally
            {
                EditorUtility.ClearProgressBar();
                sampleDirty = true;
            }
            if (fitted.Count > 0) Change("Fit All Poses", () => { foreach (var (pose, height) in fitted) pose.height = height; });
            return $"포즈 {fitted.Count}개를 바닥에 다시 맞췄습니다{(fitLikeGoGoLoco ? "(GoGoLoco처럼 10% 띄움)" : "(바닥에 정확히)")}." +
                (floating > 0 ? $" 바닥에서 {tolerance * 100f:0}cm 넘게 떠 있는 포즈 {floating}개는 그대로 뒀습니다." : "") +
                (failed > 0 ? $" {failed}개는 맞추지 못했습니다(GoGoLoco 높이 미리보기 상태를 확인하세요)." : "") +
                " ‘생성 및 적용’을 눌러야 게임에 반영됩니다.";
        }

        private void Change(string undoName, Action edit)
        {
            Undo.RecordObject(preset, undoName);
            edit();
            EditorUtility.SetDirty(preset);
        }
    }
}
