#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEditor.Animations;
using UnityEngine;
using VRC.SDK3.Avatars.Components;

namespace AvatarMenuTools
{
    // What a menu toggle turns on in the built avatar, read from its FX animator: the objects to put in the toggle's menu
    // icon. Each layer that looks at one parameter alone is played out: it rests where 0 leaves it (its entry and
    // transitions in their order, exits re-entering), and the toggle's value moves it on from there. A blend tree folded
    // by an optimizer is weighed at both values. A layer that only holds fixed values (Modular Avatar 1.19's Reactive
    // Component base layer) is where objects rest, not another toggle. An object another layer also animates is left out,
    // and so is anything else that is not settled: the user picks it.
    internal static class ToggleTargets
    {
        // What a state or blend weight holds the whole time: an object (or its renderer) on or off, by its path in the
        // avatar before the build.
        internal sealed class Effect
        {
            internal readonly Dictionary<(string Path, bool Renderer), bool> On = new Dictionary<(string, bool), bool>();
        }

        internal sealed class Transition
        {
            internal (AnimatorConditionMode Mode, float Threshold)[] Conditions;
            // A state of the layer, or -1 for the exit (back through the entry).
            internal int To;

            internal bool Holds(float value) => Conditions.All(c => ToggleTargets.Holds(c.Mode, c.Threshold, value));
        }

        // One layer driven by one parameter, as far as it can be followed.
        internal sealed class Layer
        {
            internal string Parameter;
            // The layer's index in the FX controller.
            internal int Index;
            internal int Default;
            internal Effect[] States;
            internal Transition[][] Out;
            internal Transition[] Entry, Any;

            // The state the layer settles in with the parameter at value, from a state (or through the entry when -1);
            // -1 when it does not settle.
            private int Settle(float value, int state)
            {
                int Enter() => Entry.FirstOrDefault(t => t.Holds(value) && t.To >= 0)?.To ?? Default;
                if (state < 0) state = Enter();
                for (int step = 0; step < 16; step++)
                {
                    var next = Any.FirstOrDefault(t => t.Holds(value) && t.To != state) ?? Out[state].FirstOrDefault(t => t.Holds(value));
                    if (next == null) return state;
                    int to = next.To < 0 ? Enter() : next.To;
                    if (to == state) return state;
                    state = to;
                }
                return -1;
            }

            // What the layer holds with the parameter at value: it rests where 0 leaves it, and value moves it on from
            // there. Null when either does not settle.
            internal Effect Play(float value)
            {
                int rest = Settle(0f, -1);
                int state = rest < 0 || value == 0f ? rest : Settle(value, rest);
                return state < 0 ? null : States[state];
            }
        }

        // A blend tree optimizers fold toggles into, by the parameter that weighs it: (threshold, what it holds), in order.
        internal sealed class Folded
        {
            internal string Parameter;
            // The index of the layer the tree plays in.
            internal int Index;
            internal (float Threshold, Effect Effect)[] Children;
            // A direct child weighted by the parameter itself: it holds its effect at 1 and nothing at 0.
            internal bool Weighted;

            internal Effect At(float value)
            {
                if (Weighted) return value >= 1f ? Children[0].Effect : value <= 0f ? new Effect() : null;
                if (Children.Length == 0) return null;
                // A 1D tree holds its end children beyond its thresholds.
                if (value <= Children[0].Threshold) return Children[0].Effect;
                if (value >= Children[Children.Length - 1].Threshold) return Children[Children.Length - 1].Effect;
                for (int i = 0; i < Children.Length; i++)
                {
                    if (Mathf.Approximately(value, Children[i].Threshold)) return Children[i].Effect;
                    if (i + 1 < Children.Length && value > Children[i].Threshold && value < Children[i + 1].Threshold)
                        return Same(Children[i].Effect, Children[i + 1].Effect) ? Children[i].Effect : null;
                }
                return null;
            }
        }

        internal sealed class Result
        {
            internal readonly List<Layer> Layers = new List<Layer>();
            internal readonly List<Folded> Trees = new List<Folded>();
            // How many layers (or children of a folded tree) animate each object or renderer, played or not. Layers of
            // fixed values are not counted: they set Rest.
            internal readonly Dictionary<(string Path, bool Renderer), int> Sources = new Dictionary<(string, bool), int>();
            // What a layer of fixed values holds an object or renderer at while no later layer moves it, with that
            // layer's index (the last such layer wins).
            internal readonly Dictionary<(string Path, bool Renderer), (bool On, int Layer)> Rest = new Dictionary<(string, bool), (bool, int)>();

            internal int SourcesOf((string, bool) key) => Sources.TryGetValue(key, out int n) ? n : 0;

            // Whether an object or renderer is off when no toggle moves it: as a layer of fixed values holds it, or else
            // as the scene has it.
            internal bool OffAtRest(string path, bool renderer, Func<string, bool, bool> offInScene) =>
                Rest.TryGetValue((path, renderer), out var rest) ? !rest.On : offInScene(path, renderer);
        }

        private static bool Holds(AnimatorConditionMode mode, float threshold, float value)
        {
            switch (mode)
            {
                case AnimatorConditionMode.If: return value != 0f;
                case AnimatorConditionMode.IfNot: return value == 0f;
                case AnimatorConditionMode.Greater: return value > threshold;
                case AnimatorConditionMode.Less: return value < threshold;
                case AnimatorConditionMode.Equals: return Mathf.Approximately(value, threshold);
                case AnimatorConditionMode.NotEqual: return !Mathf.Approximately(value, threshold);
                default: return false;
            }
        }

        private static bool Same(Effect a, Effect b) =>
            a.On.Count == b.On.Count && a.On.All(p => b.On.TryGetValue(p.Key, out bool v) && v == p.Value);

        // The objects a parameter set to value surely turns on: on at value and shown there, at 0 either off or not
        // touched while the object is off in the scene (offInScene), and animated by nothing else. Paths are the avatar's
        // before the build.
        internal static string[] On(Result read, string parameter, float value, Func<string, bool, bool> offInScene)
        {
            if (read == null || string.IsNullOrEmpty(parameter) || value == 0f) return Array.Empty<string>();
            var found = new List<string>();
            void Compare(Effect on, Effect off, int index)
            {
                if (on == null || off == null) return;
                foreach (var pair in on.On)
                {
                    if (!pair.Value || read.SourcesOf(pair.Key) > 1) continue;
                    // A layer of fixed values after this one holds the object whatever the toggle does.
                    if (read.Rest.TryGetValue(pair.Key, out var rest) && rest.Layer > index) continue;
                    bool turnedOn = off.On.TryGetValue(pair.Key, out bool before) ? !before : read.OffAtRest(pair.Key.Path, pair.Key.Renderer, offInScene);
                    if (turnedOn && !found.Contains(pair.Key.Path) && Shown(read, on, pair.Key.Path, offInScene)) found.Add(pair.Key.Path);
                }
            }
            foreach (var layer in read.Layers.Where(l => l.Parameter == parameter)) Compare(layer.Play(value), layer.Play(0f), layer.Index);
            foreach (var tree in read.Trees.Where(t => t.Parameter == parameter)) Compare(tree.At(value), tree.At(0f), tree.Index);
            return found.ToArray();
        }

        // Whether an object is seen where an effect holds: it and its parents active and its renderer enabled, as the
        // effect has them or else where they rest. A part of the object itself that another layer animates is not known.
        private static bool Shown(Result read, Effect effect, string path, Func<string, bool, bool> offInScene)
        {
            bool Own(bool renderer) => effect.On.TryGetValue((path, renderer), out bool v) ? v :
                read.SourcesOf((path, renderer)) == 0 && !read.OffAtRest(path, renderer, offInScene);
            if (!Own(false) || !Own(true)) return false;
            for (int cut = path.LastIndexOf('/'); cut > 0; cut = path.LastIndexOf('/', cut - 1))
            {
                string parent = path.Substring(0, cut);
                if (effect.On.TryGetValue((parent, false), out bool on) ? !on : read.OffAtRest(parent, false, offInScene)) return false;
            }
            return true;
        }

        // Parameters VRChat sets itself, whatever their defaults in the controller.
        private static readonly HashSet<string> BuiltIn = new HashSet<string>
        {
            "IsLocal", "PreviewMode", "Viseme", "Voice", "GestureLeft", "GestureRight", "GestureLeftWeight", "GestureRightWeight",
            "AngularY", "VelocityX", "VelocityY", "VelocityZ", "VelocityMagnitude", "Upright", "Grounded", "Seated", "AFK",
            "TrackingType", "VRMode", "MuteSelf", "InStation", "Earmuffs", "IsOnFriendsList", "AvatarVersion", "IsAnimatorEnabled",
            "ScaleModified", "ScaleFactor", "ScaleFactorInverse", "EyeHeightAsMeters", "EyeHeightAsPercent", "VRCEmote",
            "VRCFaceBlendH", "VRCFaceBlendV",
        };

        // Reads the FX layer of a built avatar (root). before: each object's path in the avatar before the build, for
        // objects the build moved; an object with no such path is left out.
        internal static Result Read(GameObject root, IReadOnlyDictionary<Transform, string> before)
        {
            var result = new Result();
            var descriptor = root.GetComponent<VRCAvatarDescriptor>();
            var fx = descriptor ? descriptor.baseAnimationLayers?.FirstOrDefault(l => l.type == VRCAvatarDescriptor.AnimLayerType.FX) : null;
            if (fx == null || fx.Value.isDefault || !(fx.Value.animatorController is AnimatorController controller)) return result;
            var defaults = controller.parameters.GroupBy(p => p.name).ToDictionary(g => g.Key, g =>
            {
                var p = g.First();
                return p.type == AnimatorControllerParameterType.Float ? p.defaultFloat :
                    p.type == AnimatorControllerParameterType.Int ? p.defaultInt : p.defaultBool ? 1f : 0f;
            });
            // Parameters that stay at 1: nothing outside the animator sets them (not an Expression Parameter, not one
            // of VRChat's) and nothing inside writes them (no clip curve, no parameter driver). Modular Avatar weighs
            // its always-on blend trees by one ($$MA/RC/AlwaysOne).
            var written = new HashSet<string>(descriptor.expressionParameters?.parameters?.Where(p => p != null).Select(p => p.name) ??
                                              Enumerable.Empty<string>());
            written.UnionWith(BuiltIn);
            foreach (var clip in controller.animationClips.Where(c => c).Distinct())
                foreach (var binding in AnimationUtility.GetCurveBindings(clip))
                    if (binding.type == typeof(Animator)) written.Add(binding.propertyName);
            void Drivers(AnimatorStateMachine machine)
            {
                if (machine == null) return;
                foreach (var behaviour in machine.behaviours.Concat(machine.states.SelectMany(s => s.state.behaviours)))
                    if (behaviour is VRCAvatarParameterDriver driver)
                        written.UnionWith(driver.parameters.Select(p => p.name));
                foreach (var child in machine.stateMachines) Drivers(child.stateMachine);
            }
            foreach (var layer in controller.layers) Drivers(layer.stateMachine);
            bool One(string parameter) => !string.IsNullOrEmpty(parameter) && !written.Contains(parameter) &&
                                          defaults.TryGetValue(parameter, out float value) && Mathf.Approximately(value, 1f);
            var clips = new Dictionary<AnimationClip, Effect>();
            var touched = new Dictionary<AnimationClip, HashSet<(string, bool)>>();
            // The object or renderer a binding turns on or off, by its path before the build.
            bool KeyOf(EditorCurveBinding binding, out (string, bool) key)
            {
                key = default;
                bool active = binding.type == typeof(GameObject) && binding.propertyName == "m_IsActive";
                bool shown = binding.type != null && typeof(Renderer).IsAssignableFrom(binding.type) && binding.propertyName == "m_Enabled";
                if (!active && !shown) return false;
                var target = binding.path.Length == 0 ? root.transform : root.transform.Find(binding.path);
                if (!target || !before.TryGetValue(target, out var path)) return false;
                key = (path, shown);
                return true;
            }
            Effect Of(Motion motion)
            {
                if (!(motion is AnimationClip clip)) return null;
                if (clips.TryGetValue(clip, out var known)) return known;
                var effect = new Effect();
                foreach (var binding in AnimationUtility.GetCurveBindings(clip))
                {
                    if (!KeyOf(binding, out var key)) continue;
                    var curve = AnimationUtility.GetEditorCurve(clip, binding);
                    // A value that changes over time is not a toggle's state.
                    if (curve == null || curve.length == 0 || curve.keys.Any(k => !Mathf.Approximately(k.value, curve.keys[0].value))) continue;
                    effect.On[key] = curve.keys[0].value >= .5f;
                }
                clips.Add(clip, effect);
                return effect;
            }
            // Everything a motion animates, steady or not.
            HashSet<(string, bool)> Touched(Motion motion)
            {
                var keys = new HashSet<(string, bool)>();
                void Walk(Motion m)
                {
                    if (m is AnimationClip clip)
                    {
                        if (!touched.TryGetValue(clip, out var known))
                        {
                            known = new HashSet<(string, bool)>();
                            foreach (var binding in AnimationUtility.GetCurveBindings(clip))
                                if (KeyOf(binding, out var key)) known.Add(key);
                            touched.Add(clip, known);
                        }
                        keys.UnionWith(known);
                    }
                    else if (m is BlendTree tree)
                        foreach (var child in tree.children) Walk(child.motion);
                }
                Walk(motion);
                return keys;
            }
            void Count(IEnumerable<(string, bool)> keys)
            {
                foreach (var key in keys) result.Sources[key] = result.SourcesOf(key) + 1;
            }
            IEnumerable<AnimatorState> All(AnimatorStateMachine machine) =>
                machine.states.Select(s => s.state).Concat(machine.stateMachines.SelectMany(s => All(s.stateMachine)));
            // A motion that holds fixed values the whole time: steady clips, through direct trees weighed by one only.
            bool Fixed(Motion motion) =>
                motion is AnimationClip clip ? Touched(clip).All(Of(clip).On.ContainsKey) :
                motion is BlendTree tree && tree.blendType == BlendTreeType.Direct && tree.children.All(c => One(c.directBlendParameter) && Fixed(c.motion));
            void Rest(Motion motion, int index)
            {
                if (motion is AnimationClip clip)
                    foreach (var pair in Of(clip).On) result.Rest[pair.Key] = (pair.Value, index);
                else if (motion is BlendTree tree)
                    foreach (var child in tree.children) Rest(child.motion, index);
            }
            void Fold(BlendTree tree, int index)
            {
                if (tree.blendType == BlendTreeType.Direct)
                {
                    foreach (var child in tree.children)
                    {
                        string weight = child.directBlendParameter;
                        if (string.IsNullOrEmpty(weight)) continue;
                        // A tree inside counts only while its weight stays at 1: an optimizer weighs it by a constant.
                        if (child.motion is BlendTree inner)
                        {
                            if (defaults.TryGetValue(weight, out float w) && Mathf.Approximately(w, 1f)) Fold(inner, index);
                        }
                        else if (Of(child.motion) is Effect effect)
                            result.Trees.Add(new Folded { Parameter = weight, Index = index, Weighted = true, Children = new[] { (1f, effect) } });
                    }
                }
                else if (tree.blendType == BlendTreeType.Simple1D && tree.children.All(c => c.motion is AnimationClip))
                    result.Trees.Add(new Folded
                    {
                        Parameter = tree.blendParameter, Index = index,
                        Children = tree.children.OrderBy(c => c.threshold).Select(c => (c.threshold, Of(c.motion))).ToArray(),
                    });
            }
            for (int i = 0; i < controller.layers.Length; i++)
            {
                var layer = controller.layers[i];
                // A synced layer plays another layer's states with motions of its own: it is counted, not played.
                if (layer.syncedLayerIndex >= 0)
                {
                    if (layer.syncedLayerIndex < controller.layers.Length && controller.layers[layer.syncedLayerIndex].stateMachine is AnimatorStateMachine source)
                        Count(All(source).SelectMany(s => Touched(layer.GetOverrideMotion(s))).Distinct());
                    continue;
                }
                var machine = layer.stateMachine;
                if (machine == null) continue;
                // A layer with no weight does nothing until something raises it.
                bool plays = i == 0 || layer.defaultWeight > 0f;
                var lone = machine.states.Length == 1 && machine.stateMachines.Length == 0 ? machine.states[0].state.motion as BlendTree : null;
                if (lone != null && lone.blendType == BlendTreeType.Direct)
                {
                    // Fixed values only: where objects rest, not a toggle.
                    if (Fixed(lone))
                    {
                        if (plays) Rest(lone, i);
                        continue;
                    }
                    // Each toggle an optimizer folded in is a child of its own.
                    foreach (var child in lone.children) Count(Touched(child.motion));
                    if (plays) Fold(lone, i);
                    continue;
                }
                Count(All(machine).SelectMany(s => Touched(s.motion)).Distinct());
                if (!plays) continue;
                if (lone != null) Fold(lone, i);
                else if (Follow(machine, Of) is Layer read)
                {
                    read.Index = i;
                    result.Layers.Add(read);
                }
            }
            return result;
        }

        // The transitions Unity takes from a list: not muted, and only the solo ones when there are any.
        private static T[] Live<T>(T[] transitions) where T : AnimatorTransitionBase
        {
            var unmuted = transitions.Where(t => t && !t.mute).ToArray();
            return unmuted.Any(t => t.solo) ? unmuted.Where(t => t.solo).ToArray() : unmuted;
        }

        // A layer of plain states (no sub-state machines, no blend trees) whose transitions all look at one parameter.
        private static Layer Follow(AnimatorStateMachine machine, Func<Motion, Effect> of)
        {
            if (machine.stateMachines.Length > 0 || machine.states.Length < 2 || !machine.defaultState) return null;
            var states = machine.states.Select(s => s.state).ToList();
            var entry = Live(machine.entryTransitions);
            var any = Live(machine.anyStateTransitions);
            var outs = states.Select(s => Live(s.transitions)).ToArray();
            var all = entry.Cast<AnimatorTransitionBase>().Concat(any).Concat(outs.SelectMany(t => t)).ToArray();
            var parameters = all.SelectMany(t => t.conditions).Select(c => c.parameter).Distinct().ToArray();
            if (parameters.Length != 1) return null;
            Transition Make(AnimatorTransitionBase t) => t.isExit ? new Transition { To = -1, Conditions = Conditions(t) } :
                t.destinationState && states.Contains(t.destinationState) ? new Transition { To = states.IndexOf(t.destinationState), Conditions = Conditions(t) } : null;
            (AnimatorConditionMode, float)[] Conditions(AnimatorTransitionBase t) => t.conditions.Select(c => (c.mode, c.threshold)).ToArray();
            var effects = states.Select(s => of(s.motion)).ToArray();
            // A state with a blend tree, or one that goes elsewhere, cannot be read for sure.
            if (effects.Any(e => e == null) || all.Any(t => Make(t) == null)) return null;
            // A transition with no condition waits for exit time: the layer then plays a sequence, not a toggle.
            if (all.Any(t => t.conditions.Length == 0)) return null;
            return new Layer
            {
                Parameter = parameters[0], Default = states.IndexOf(machine.defaultState), States = effects,
                Out = outs.Select(o => o.Select(Make).ToArray()).ToArray(),
                Entry = entry.Select(Make).ToArray(), Any = any.Select(Make).ToArray(),
            };
        }
    }
}
#endif
