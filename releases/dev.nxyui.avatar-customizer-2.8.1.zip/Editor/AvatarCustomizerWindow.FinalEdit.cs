#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;
using VRC.SDK3.Avatars.Components;
using VRC.SDK3.Avatars.ScriptableObjects;
using Object = UnityEngine.Object;

namespace AvatarMenuTools
{
    // Editing in the "빌드 결과" tab: rename, move (drag, or "이동…"), delete, new folder and "원래대로". The rules are
    // worked out by FinalMenuEdits on a copy of the settings and kept only when the result is where it was asked.
    internal sealed partial class AvatarCustomizerWindow
    {
        private const string FinalDragKey = "NXYUI.AvatarCustomizer.FinalItem";
        private const string NameField = "NXYUI.AvatarCustomizer.FinalName";

        private sealed class FinalDrag
        {
            public VRCAvatarDescriptor Avatar;
            public FinalMenu Menu;
            public FinalMenu.Item Item;
        }

        // The row the mouse went down on (a drag starts from it), and where a drag is over now.
        private string finalPressed;
        private FinalMenu.Item dropOn;
        private DropZone dropHow;
        private bool dropEnd;
        private string dropReason;
        private bool focusName;

        private FinalContext Context() => new FinalContext { Tree = tree, Root = avatar ? avatar.transform : null, Parameters = parameterTypes };

        // Why the final menu cannot be edited now, or null.
        private string EditBlocked(AvatarCustomizer config) =>
            finalMenu == null || tree == null ? "‘빌드 메뉴 읽기’를 먼저 해 주세요." :
            config && !config.enabled ? "Avatar Customizer 컴포넌트가 꺼져 있어 편집할 수 없어요. 켠 뒤에 해 주세요." :
            !IsSceneAvatar(avatar) || EditorApplication.isPlayingOrWillChangePlaymode ? "편집 모드에서 아바타를 선택해 주세요." : null;

        // Keeps an edit (one Undo step) or says why there is none. inGui: called from this window's OnGUI, not a menu.
        // True when the edit was written to the component.
        private bool Apply(string action, FinalEdit edit, string error, bool inGui)
        {
            if (edit == null)
            {
                if (!string.IsNullOrEmpty(error))
                {
                    status = error;
                    statusType = MessageType.Warning;
                }
                Repaint();
                return false;
            }
            bool changed;
            try
            {
                changed = Change(action, edit.CopyTo);
                if (changed && edit.Select != null) finalSelected = edit.Select;
                status = changed ? edit.Note : "아바타가 씬에 없어서 바꾸지 못했어요. 아바타를 다시 골라 주세요.";
                statusType = changed ? MessageType.Info : MessageType.Warning;
            }
            finally { edit.Dispose(); }
            Repaint();
            if (inGui) GUIUtility.ExitGUI();
            return changed;
        }

        // A menu callback runs later; the final menu it was opened on must still be the one shown.
        private bool StillShown(FinalMenu menu)
        {
            if (menu == finalMenu && menu != null && FinalSignature(avatar ? avatar.GetComponent<AvatarCustomizer>() : null) == finalFor) return true;
            status = "메뉴가 그 사이에 바뀌었어요. 다시 해 주세요.";
            statusType = MessageType.Warning;
            Repaint();
            return false;
        }

        private static bool Renamable(FinalMenu.Item item) =>
            item.Origin.Kind != MenuOriginKind.Unknown && item.Origin.Kind != MenuOriginKind.PageLink;

        private static string DeleteLabel(FinalMenu.Item item)
        {
            switch (item.Origin.Kind)
            {
                case MenuOriginKind.Original: return "숨기기";
                case MenuOriginKind.FavoritesFolder:
                case MenuOriginKind.MadeFolder:
                case MenuOriginKind.LegacyFolder: return "폴더 풀기";
                case MenuOriginKind.FavoritesMenu: return "메뉴 삭제";
                default: return "삭제";
            }
        }

        private static string DeleteTip(FinalMenu.Item item)
        {
            switch (item.Origin.Kind)
            {
                case MenuOriginKind.Original: return "원본 메뉴 정리에서 숨겨요. ‘숨긴 항목’에서 다시 보이게 할 수 있어요.";
                case MenuOriginKind.FavoritesFolder:
                case MenuOriginKind.MadeFolder:
                case MenuOriginKind.LegacyFolder: return "폴더만 없애고, 안의 항목은 폴더가 있던 자리로 옮겨요.";
                case MenuOriginKind.FavoritesMenu: return "이 즐겨찾기 메뉴와 그 안의 설정을 지워요.";
                case MenuOriginKind.Shape: return "즐겨찾기에서 이 블렌드쉐이프 항목만 빼요. 컨트롤은 블렌드쉐이프 탭에 남아요.";
                default: return "즐겨찾기에서 이 바로가기를 빼요. 원본은 그대로예요.";
            }
        }

        // Something "원래대로" takes off: an original's rename or move, or a shortcut that moved an original.
        private bool CanRestore(AvatarCustomizer config, FinalMenu.Item item)
        {
            if (item.Origin.Kind == MenuOriginKind.Shortcut) return finalMenu != null && FinalMenuEdits.IsPairedShortcut(config, finalMenu, item);
            if (item.Origin.Kind != MenuOriginKind.Original || finalView?.Resolve(item.Origin.Key) is not FavoriteMenuKey key) return false;
            return finalView.RuleByControl.ContainsKey(key.sharedControl) || finalView.MoveByControl.ContainsKey(key.sharedControl);
        }

        private void RenameFinal(AvatarCustomizer config, FinalMenu.Item item, string name, bool inGui = true)
        {
            if (EditBlocked(config) is string blocked) { Apply(null, null, blocked, inGui); return; }
            Apply("Rename menu item", FinalMenuEdits.Rename(config, finalMenu, Context(), item, name, out string error), error, inGui);
        }

        private void DeleteFinal(AvatarCustomizer config, FinalMenu.Item item, bool inGui)
        {
            if (EditBlocked(config) is string blocked) { Apply(null, null, blocked, inGui); return; }
            if (item.Origin.Kind == MenuOriginKind.FavoritesMenu && !EditorUtility.DisplayDialog("즐겨찾기 메뉴 삭제",
                    item.Origin.MenuIndex == 0
                        ? $"‘{FinalMenu.Name(item.Control)}’ 메뉴의 항목을 모두 지울까요? 첫 번째 메뉴라 이름·아이콘·설치 위치는 남아요.\n실행 취소(Ctrl+Z)로 되돌릴 수 있어요."
                        : $"‘{FinalMenu.Name(item.Control)}’ 메뉴와 그 안의 즐겨찾기 설정을 지울까요?\n실행 취소(Ctrl+Z)로 되돌릴 수 있어요.",
                    "삭제", "취소"))
                return;
            Apply(DeleteLabel(item) == "숨기기" ? "Hide menu item" : "Remove menu item",
                FinalMenuEdits.Delete(config, finalMenu, Context(), item, out string error), error, inGui);
        }

        private void NewFolderFinal(AvatarCustomizer config, FinalMenu.Level level, FinalMenu.Item before, bool inGui)
        {
            if (EditBlocked(config) is string blocked) { Apply(null, null, blocked, inGui); return; }
            var edit = FinalMenuEdits.NewFolder(config, finalMenu, Context(), level, before, out string error);
            if (edit != null) { finalTab = 0; focusName = true; }
            Apply("Add menu folder", edit, error, inGui);
        }

        private void MoveFinal(AvatarCustomizer config, FinalMenu.Item item, FinalMenu.Level level, FinalMenu.Item before, bool inGui)
        {
            if (EditBlocked(config) is string blocked) { Apply(null, null, blocked, inGui); return; }
            Apply("Move menu item", FinalMenuEdits.Move(config, finalMenu, Context(), item, level, before, out string error), error, inGui);
        }

        private void RestoreFinal(AvatarCustomizer config, FinalMenu.Item item, bool inGui)
        {
            if (EditBlocked(config) is string blocked) { Apply(null, null, blocked, inGui); return; }
            Apply("Restore menu item", FinalMenuEdits.Restore(config, finalMenu, Context(), item, out string error), error, inGui);
        }

        // ---------------------------------------------------------------- menus

        // Every level of the final menu, by the way to it (each once), for "이동…" and "즐겨찾기에 추가".
        private List<(string Path, FinalMenu.Level Level)> LevelChoices()
        {
            var result = new List<(string, FinalMenu.Level)>();
            if (finalMenu?.Root == null) return result;
            var organizer = final.Organizer;
            var seen = new HashSet<VRCExpressionsMenu> { finalMenu.Root };
            var pending = new Queue<(string, VRCExpressionsMenu)>();
            pending.Enqueue(("최상위", finalMenu.Root));
            while (pending.Count > 0)
            {
                var (path, first) = pending.Dequeue();
                var level = finalMenu.LevelAt(first);
                result.Add((path, level));
                foreach (var item in level.Items)
                    if (item.Opens != null && seen.Add(organizer.FirstPage(item.Opens)))
                        pending.Enqueue(($"{path} › {FinalMenu.Name(item.Control)}", organizer.FirstPage(item.Opens)));
            }
            return result;
        }

        private static string MenuText(string path) => path.Replace("/", "／");

        private void ShowMoveMenu(AvatarCustomizer config, FinalMenu.Item item)
        {
            var menu = new GenericMenu();
            var shown = finalMenu;
            foreach (var (path, level) in LevelChoices())
            {
                string reason = FinalMenuEdits.CanMove(config, shown, item, level, null);
                var label = new GUIContent(MenuText(path) + (reason == null ? "" : "  (놓을 수 없음)"));
                if (reason != null) menu.AddDisabledItem(label, false);
                else menu.AddItem(label, false, () => { if (StillShown(shown)) MoveFinal(avatar.GetComponent<AvatarCustomizer>(), item, level, null, false); });
            }
            menu.ShowAsContext();
        }

        private void ShowAddMenu(AvatarCustomizer config, FinalMenu.Item item)
        {
            var menu = new GenericMenu();
            var shown = finalMenu;
            var choices = LevelChoices().Where(c => c.Level.Where.Kind == MenuLevelKind.Favorites).ToArray();
            if (choices.Length == 0) menu.AddDisabledItem(new GUIContent("즐겨찾기 메뉴가 없어요 (즐겨찾기 편집 탭에서 만들 수 있어요)"));
            foreach (var (path, level) in choices)
                menu.AddItem(new GUIContent(MenuText(path)), false, () =>
                {
                    if (!StillShown(shown)) return;
                    var c = avatar.GetComponent<AvatarCustomizer>();
                    if (EditBlocked(c) is string blocked) { Apply(null, null, blocked, false); return; }
                    Apply("Add favorite", FinalMenuEdits.AddShortcut(c, shown, Context(), item, level, out string error), error, false);
                });
            menu.ShowAsContext();
        }

        private void ShowItemMenu(AvatarCustomizer config, FinalMenu.Level level, FinalMenu.Item item)
        {
            var menu = new GenericMenu();
            var shown = finalMenu;
            void Add(string text, bool enabled, Action action)
            {
                if (enabled) menu.AddItem(new GUIContent(text), false, () => { if (StillShown(shown)) action(); });
                else menu.AddDisabledItem(new GUIContent(text));
            }
            AvatarCustomizer Settings() => avatar.GetComponent<AvatarCustomizer>();
            Add("이름 바꾸기 (F2)", Renamable(item), () => { finalSelected = item.Id; finalTab = 0; focusName = true; Repaint(); });
            Add("이동…", true, () => ShowMoveMenu(Settings(), item));
            if (item.Origin.Kind == MenuOriginKind.Original) Add("즐겨찾기에 추가…", true, () => ShowAddMenu(Settings(), item));
            Add("이 앞에 새 폴더", true, () => NewFolderFinal(Settings(), level, item, false));
            menu.AddSeparator("");
            Add(DeleteLabel(item) + " (Delete)", Renamable(item), () => DeleteFinal(Settings(), item, false));
            Add("원래대로", CanRestore(config, item), () => RestoreFinal(Settings(), item, false));
            menu.ShowAsContext();
        }

        // ---------------------------------------------------------------- drag and drop

        private FinalDrag DraggedFinal() =>
            DragAndDrop.GetGenericData(FinalDragKey) is FinalDrag d && d.Avatar == avatar && d.Menu == finalMenu ? d : null;

        private void FinalDragStart(Rect rect, FinalMenu.Item item)
        {
            var e = Event.current;
            if (e.type != EventType.MouseDrag || e.button != 0 || finalPressed != item.Id || !rect.Contains(e.mousePosition)) return;
            finalPressed = null;
            DragAndDrop.PrepareStartDrag();
            DragAndDrop.SetGenericData(FinalDragKey, new FinalDrag { Avatar = avatar, Menu = finalMenu, Item = item });
            DragAndDrop.objectReferences = Array.Empty<Object>();
            DragAndDrop.StartDrag(FinalMenu.Name(item.Control));
            e.Use();
        }

        // Over a row: the upper and lower quarter put the item before or after it; the middle half of a row that opens a
        // menu puts it inside, at the end.
        private void FinalDropRow(AvatarCustomizer config, Rect rect, FinalMenu.Level level, FinalMenu.Item row, FinalMenu.Item next)
        {
            var e = Event.current;
            var drag = DraggedFinal();
            if (drag == null) return;
            if (e.type == EventType.Repaint && dropOn == row)
            {
                var color = dropReason == null ? new Color(.33f, .67f, .93f, 1f) : new Color(.85f, .35f, .3f, 1f);
                if (dropHow == DropZone.Inside) EditorGUI.DrawRect(rect, new Color(color.r, color.g, color.b, .22f));
                else EditorGUI.DrawRect(new Rect(rect.x, dropHow == DropZone.Before ? rect.y - 1f : rect.yMax - 1f, rect.width, 2f), color);
            }
            if ((e.type != EventType.DragUpdated && e.type != EventType.DragPerform) || !rect.Contains(e.mousePosition)) return;
            float t = (e.mousePosition.y - rect.y) / Mathf.Max(1f, rect.height);
            bool opens = row.Opens != null;
            var zone = opens && t > .25f && t < .75f ? DropZone.Inside : t < .5f ? DropZone.Before : DropZone.After;
            var target = zone == DropZone.Inside ? finalMenu.LevelAt(final.Organizer.FirstPage(row.Opens)) : level;
            var before = zone == DropZone.Before ? row : zone == DropZone.After ? next : null;
            string reason = row.Control == drag.Item.Control ? FinalMenuEdits.NoChange : FinalMenuEdits.CanMove(config, finalMenu, drag.Item, target, before);
            DragAndDrop.visualMode = reason == null ? DragAndDropVisualMode.Move : DragAndDropVisualMode.Rejected;
            dropOn = row;
            dropHow = zone;
            dropEnd = false;
            dropReason = string.IsNullOrEmpty(reason) ? null : reason;
            if (e.type == EventType.DragPerform)
            {
                DragAndDrop.AcceptDrag();
                DragAndDrop.SetGenericData(FinalDragKey, null);
                dropOn = null;
                dropReason = null;
                e.Use();
                if (reason == null) MoveFinal(config, drag.Item, target, before, true);
                else if (reason.Length > 0) Apply(null, null, reason, true);
                return;
            }
            e.Use();
            Repaint();
        }

        // The space after the last row: the item goes to the end of the level shown.
        private void FinalDropEnd(AvatarCustomizer config, Rect area, FinalMenu.Level level)
        {
            var e = Event.current;
            var drag = DraggedFinal();
            if (drag == null) return;
            if (e.type == EventType.Repaint)
            {
                if (dropEnd) EditorGUI.DrawRect(area, dropReason == null ? new Color(.33f, .67f, .93f, .18f) : new Color(.85f, .35f, .3f, .18f));
                GUI.Label(area, "여기에 놓으면 맨 끝으로", EditorStyles.centeredGreyMiniLabel);
            }
            if ((e.type != EventType.DragUpdated && e.type != EventType.DragPerform) || !area.Contains(e.mousePosition)) return;
            string reason = FinalMenuEdits.CanMove(config, finalMenu, drag.Item, level, null);
            DragAndDrop.visualMode = reason == null ? DragAndDropVisualMode.Move : DragAndDropVisualMode.Rejected;
            dropOn = null;
            dropEnd = true;
            dropReason = string.IsNullOrEmpty(reason) ? null : reason;
            if (e.type == EventType.DragPerform)
            {
                DragAndDrop.AcceptDrag();
                DragAndDrop.SetGenericData(FinalDragKey, null);
                dropEnd = false;
                dropReason = null;
                e.Use();
                if (reason == null) MoveFinal(config, drag.Item, level, null, true);
                else if (reason.Length > 0) Apply(null, null, reason, true);
                return;
            }
            e.Use();
            Repaint();
        }

        // ---------------------------------------------------------------- keys

        // ↑↓ select, Enter or → open, Backspace or ← back, F2 rename, Delete delete: while no text field has the keys.
        private void FinalKeys(AvatarCustomizer config, List<(FinalMenu.Item Via, FinalMenu.Level Level)> levels)
        {
            var e = Event.current;
            if (e.type != EventType.KeyDown || GUIUtility.keyboardControl != 0 || focusedWindow != this) return;
            var level = levels[levels.Count - 1].Level;
            var items = level.Items;
            int at = items.FindIndex(i => i.Id == finalSelected);
            var selected = at >= 0 ? items[at] : null;
            switch (e.keyCode)
            {
                case KeyCode.UpArrow:
                case KeyCode.DownArrow:
                    if (items.Count == 0) return;
                    at = at < 0 ? 0 : Mathf.Clamp(at + (e.keyCode == KeyCode.UpArrow ? -1 : 1), 0, items.Count - 1);
                    finalSelected = items[at].Id;
                    finalTab = 0;
                    break;
                case KeyCode.Return:
                case KeyCode.KeypadEnter:
                case KeyCode.RightArrow:
                    if (selected?.Opens == null || levels.Any(l => l.Level.First == selected.Opens)) return;
                    finalPath.Add(selected.Id);
                    finalSelected = null;
                    finalScroll = Vector2.zero;
                    break;
                case KeyCode.Backspace:
                case KeyCode.LeftArrow:
                    if (finalPath.Count == 0) return;
                    finalSelected = finalPath[finalPath.Count - 1];
                    finalPath.RemoveAt(finalPath.Count - 1);
                    finalScroll = Vector2.zero;
                    break;
                case KeyCode.F2:
                    if (selected == null || !Renamable(selected)) return;
                    finalTab = 0;
                    focusName = true;
                    break;
                case KeyCode.Delete:
                    if (selected == null || !Renamable(selected)) return;
                    e.Use();
                    DeleteFinal(config, selected, true);
                    return;
                default: return;
            }
            e.Use();
            Repaint();
        }
    }
}
#endif
