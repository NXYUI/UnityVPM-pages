#if UNITY_EDITOR
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using VRC.SDK3.Avatars.ScriptableObjects;
using Control = VRC.SDK3.Avatars.ScriptableObjects.VRCExpressionsMenu.Control;

namespace AvatarMenuTools
{
    // The final menu as the window's "빌드 결과" tab shows it: each menu level's items over all of its pages (page links
    // become page breaks), where each item comes from, and every place a menu opens from. A menu opened from two places
    // is one menu, so an edit inside it shows in both.
    internal sealed class FinalMenu
    {
        internal sealed class Item
        {
            internal Control Control;
            internal MenuOrigin Origin;
            // Names the item within its level, the same after the menu is worked out again (ItemId).
            internal string Id;
            // The page it is on (1 = first); 0 for an empty made folder, which the build leaves out.
            internal int Page;
            // The first page of the menu it opens, or null.
            internal VRCExpressionsMenu Opens;
            internal bool Dropped => Page == 0;
        }

        internal sealed class Level
        {
            // The page the level is shown from: its first page, or a later one a submenu opens directly.
            internal VRCExpressionsMenu First;
            // That page's number in its level (1 = the level's first page).
            internal int FirstNumber = 1;
            internal MenuLevel Where;
            internal readonly List<Item> Items = new List<Item>();
            // Controls on each page, its page link included: the slots it uses of VRCExpressionsMenu.MAX_CONTROLS.
            internal readonly List<int> Slots = new List<int>();
            // The name of each page link, in order: the way to page 2, 3 and on.
            internal readonly List<string> Links = new List<string>();

            // The item with this id, or null when there is none or it is one of several alike (their order may have
            // changed, so the id could now name the other one).
            internal Item Find(string id)
            {
                if (id == null) return null;
                string kind = BaseId(id);
                var alike = Items.Where(i => BaseId(i.Id) == kind).Take(2).ToArray();
                return alike.Length == 1 && alike[0].Id == id ? alike[0] : null;
            }
        }

        // Marks the second and later of items alike in a level: id, Repeat, then 2, 3 and so on.
        internal const string Repeat = "\u0001";

        internal static string BaseId(string id)
        {
            int at = id.IndexOf(Repeat, System.StringComparison.Ordinal);
            return at < 0 ? id : id.Substring(0, at);
        }

        internal readonly MenuComposition Composition;
        // Every place a menu page opens from in the built menu, as the shown names on the way there (Places for a level).
        internal readonly Dictionary<VRCExpressionsMenu, List<string[]>> OpenedFrom = new Dictionary<VRCExpressionsMenu, List<string[]>>();
        private readonly Dictionary<VRCExpressionsMenu, Level> levels = new Dictionary<VRCExpressionsMenu, Level>();

        internal VRCExpressionsMenu Root => Composition.Root;

        internal FinalMenu(MenuComposition composition)
        {
            Composition = composition;
            if (!Root) return;
            var open = new HashSet<VRCExpressionsMenu>();
            void Walk(VRCExpressionsMenu first, string[] path)
            {
                if (!open.Add(first)) return;
                foreach (var item in LevelAt(first).Items)
                {
                    if (item.Opens == null || item.Dropped) continue;
                    var next = path.Append(item.Control.name ?? "").ToArray();
                    if (!OpenedFrom.TryGetValue(item.Opens, out var places)) OpenedFrom.Add(item.Opens, places = new List<string[]>());
                    places.Add(next);
                    Walk(item.Opens, next);
                }
                open.Remove(first);
            }
            Walk(Root, new string[0]);
        }

        // Every place the level a page belongs to opens from, by any of its pages: an edit inside changes it for all.
        internal List<string[]> Places(VRCExpressionsMenu page)
        {
            var organizer = Composition.Organizer;
            var first = organizer.FirstPage(page);
            return OpenedFrom.Where(p => organizer.FirstPage(p.Key) == first).SelectMany(p => p.Value).ToList();
        }

        // The level shown from page first: that page and the pages after it. Without a menu, an empty level.
        internal Level LevelAt(VRCExpressionsMenu first)
        {
            if (!first) return new Level { Where = new MenuLevel() };
            if (levels.TryGetValue(first, out var level)) return level;
            var organizer = Composition.Organizer;
            level = new Level { First = first, Where = Composition.LevelOf(first) };
            level.FirstNumber = organizer.Pages(organizer.FirstPage(first)).TakeWhile(p => p != first).Count() + 1;
            levels.Add(first, level);
            var seen = new Dictionary<string, int>();
            Item Make(Control c, int page)
            {
                var origin = Composition.OriginOf(c);
                string id = ItemId(origin, c);
                seen.TryGetValue(id, out int count);
                seen[id] = count + 1;
                return new Item
                {
                    Control = c, Origin = origin, Page = page, Id = count == 0 ? id : id + Repeat + (count + 1),
                    Opens = c.type == Control.ControlType.SubMenu && c.subMenu ? c.subMenu : null,
                };
            }
            int number = 0;
            foreach (var page in organizer.Pages(first))
            {
                number++;
                level.Slots.Add(page.controls.Count(c => c != null));
                if (organizer.PageLinks.TryGetValue(page, out var link)) level.Links.Add(Name(link));
                foreach (var c in page.controls)
                    if (c != null && c != link) level.Items.Add(Make(c, number));
            }
            // Empty made folders sit where they were, without a page: in reverse, so one in front of another dropped
            // folder finds it already in place. Shown from a later page, only those on the pages shown.
            var shownFirst = organizer.FirstPage(first);
            foreach (var dropped in Enumerable.Reverse(organizer.Dropped))
            {
                if (dropped.Level != shownFirst || !organizer.Folders.TryGetValue(dropped.Id, out var folder)) continue;
                int at = dropped.Before == null ? -1 : level.Items.FindIndex(i => i.Control == dropped.Before);
                if (at < 0 && dropped.Before != null && first != shownFirst) continue;
                level.Items.Insert(at < 0 ? level.Items.Count : at, Make(folder.Control, 0));
            }
            // Empty favorites folders and menus the same way, in entry order: several can sit before the same control.
            foreach (var ghost in Composition.FavoriteGhosts)
            {
                if (ghost.Level != shownFirst) continue;
                int at = ghost.Before == null ? -1 : level.Items.FindIndex(i => i.Control == ghost.Before);
                if (at < 0 && ghost.Before != null && first != shownFirst) continue;
                level.Items.Insert(at < 0 ? level.Items.Count : at, Make(ghost.Control, 0));
            }
            return level;
        }

        // A menu tree as text, every page and control with what it drives: two menus with the same text build the same.
        internal static string Text(VRCExpressionsMenu menu) => Text(menu, new HashSet<VRCExpressionsMenu>());

        private static string Text(VRCExpressionsMenu menu, HashSet<VRCExpressionsMenu> open)
        {
            if (!menu) return "-";
            if (!open.Add(menu)) return "@";
            var text = "[" + string.Join("|", (menu.controls ?? new List<Control>()).Where(c => c != null).Select(c =>
                $"{c.name}:{c.type}:{c.parameter?.name}:{string.Join("+", (c.subParameters ?? new Control.Parameter[0]).Select(p => p?.name))}:" +
                $"{c.value.ToString("R", CultureInfo.InvariantCulture)}:{(c.icon ? c.icon.GetInstanceID() : 0)}" +
                (c.type == Control.ControlType.SubMenu ? Text(c.subMenu, open) : ""))) + "]";
            open.Remove(menu);
            return text;
        }

        // How a level is shown in a path or header.
        internal static string Name(Control c) => string.IsNullOrWhiteSpace(c?.name) ? "(이름 없음)" : c.name;

        // An item's name within its level: what it is, not where it is on the page, so it is found again after an edit
        // moves things around. Two items alike are told apart by order (Repeat).
        internal static string ItemId(MenuOrigin origin, Control c)
        {
            switch (origin.Kind)
            {
                case MenuOriginKind.Original: return "o|" + KeyText(origin.Key);
                case MenuOriginKind.MadeFolder: return "f|" + origin.Id;
                case MenuOriginKind.LegacyFolder: return "l|" + origin.Id;
                case MenuOriginKind.FavoritesMenu: return $"m|{origin.MenuIndex}|{origin.MenuName}";
                case MenuOriginKind.FavoritesFolder: return $"mf|{origin.MenuIndex}|{origin.MenuName}|{origin.Id}";
                case MenuOriginKind.Shortcut: return $"s|{origin.MenuIndex}|{origin.MenuName}|{KeyText(origin.Key ?? origin.Target)}";
                case MenuOriginKind.Shape: return $"b|{origin.MenuIndex}|{origin.MenuName}|{origin.Id}";
                default: return $"u|{c?.type}|{c?.name}";
            }
        }

        private static string KeyText(FavoriteMenuKey key) => key == null ? "" :
            string.Join("\u001f", key.path ?? new string[0]) + "\u001e" + key.type + "\u001e" + key.parameter + "\u001e" +
            string.Join("\u001f", key.subParameters ?? new string[0]) + "\u001e" + key.value.ToString("R", CultureInfo.InvariantCulture);
    }
}
#endif
