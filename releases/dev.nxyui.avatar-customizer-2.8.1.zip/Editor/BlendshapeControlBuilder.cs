#if UNITY_EDITOR
using System.Collections.Generic;
using System.Linq;
using nadena.dev.modular_avatar.core;
using nadena.dev.ndmf;
using UnityEditor;
using UnityEditor.Animations;
using UnityEngine;
using VRC.SDK3.Avatars.Components;

namespace AvatarMenuTools
{
    // Turns the blendshape controls placed in a favorites menu into one FX layer (a direct blend tree holding a 1D tree
    // per control) and an expression parameter each. It adds Modular Avatar components to the build copy before
    // Modular Avatar runs, so MA merges the layer and the parameters like any other; the favorites pass then puts the
    // radial or toggle into the menu.
    internal static class BlendshapeControlBuilder
    {
        internal const string One = "NXYUI/Customizer/One";
        internal const string HolderName = "Avatar Customizer Blendshapes";
        internal const string ResetLayerName = "Avatar Customizer Reset";
        internal const string ResetName = "블렌드쉐이프 초기화";

        internal sealed class Built
        {
            internal string Parameter, Name;
            internal bool Radial;
            // The reset button (BlendshapeControl.ResetId).
            internal bool Reset;
        }

        internal sealed class State
        {
            internal readonly Dictionary<string, Built> Controls = new Dictionary<string, Built>();
            internal readonly Dictionary<string, string> Problems = new Dictionary<string, string>();
            // Built, but another animation also moves the shape.
            internal readonly Dictionary<string, string> Notes = new Dictionary<string, string>();
        }

        // A control's settings and the object it drives (by path below root), to tell whether it changed since a read.
        internal static string Fingerprint(BlendshapeControl s, Transform root) => s == null ? "" : string.Join("|",
            s.renderer ? AnimationUtility.CalculateTransformPath(s.renderer.transform, root) : "-", s.blendshape, s.type,
            s.min, s.max, s.defaultValue, s.synced, s.saved);

        // Why a control is missing from the menu (state of a plan or a build), or null when it is there.
        internal static string Verdict(State state, string id) =>
            state.Problems.TryGetValue(id, out var problem) ? problem : state.Controls.ContainsKey(id) ? null : "블렌드쉐이프 컨트롤을 만들지 못했어요.";

        internal static IEnumerable<string> UsedIds(AvatarCustomizer c) => c.AllMenus()
            .SelectMany(m => m.entries ?? new List<FavoriteMenuEntry>())
            .Where(e => e != null && e.IsShape).Select(e => e.shapeId).Distinct();

        // Why the control cannot be built on this avatar, or null.
        internal static string Problem(BlendshapeControl s, Transform root, BlendshapeConflicts conflicts = null)
        {
            if (s == null) return "삭제된 블렌드쉐이프 컨트롤입니다.";
            // In a build the EditorOnly objects are already gone, so both cases read the same there and in the scene.
            const string missing = "대상 오브젝트가 없거나 EditorOnly 오브젝트 안에 있습니다.";
            if (!s.renderer) return missing;
            if (!s.renderer.transform.IsChildOf(root)) return "아바타 안의 오브젝트가 아닙니다.";
            if (BlendshapeConflicts.RemovedAtBuild(s.renderer.transform, root)) return missing;
            if (!s.renderer.sharedMesh || s.renderer.sharedMesh.GetBlendShapeIndex(s.blendshape ?? "") < 0)
                return $"‘{s.blendshape}’ 블렌드쉐이프가 메시에 없습니다.";
            if (conflicts?.Blocked(s.renderer, s.blendshape) is string why)
                return $"다른 컴포넌트가 이 블렌드쉐이프를 바꿔서 막았습니다: {why}.";
            return null;
        }

        internal static string Note(BlendshapeControl s, BlendshapeConflicts conflicts) =>
            s?.renderer && conflicts?.Animated(s.renderer, s.blendshape) is string what
                ? $"{what}도 이 블렌드쉐이프를 움직입니다. 게임에서는 이 메뉴 값이 항상 우선합니다."
                : null;

        // Which of the controls the favorites menus hold can be built on this avatar (root), as the menu will show them:
        // fills state and returns the controls to build. The window runs it on the avatar in the scene; the build on
        // its copy before Modular Avatar, which has the same components.
        internal static List<BlendshapeControl> Plan(AvatarCustomizer c, Transform root, State state)
        {
            var controls = new List<BlendshapeControl>();
            if (!c || !c.enabled) return controls;
            var used = UsedIds(c).ToArray();
            bool reset = used.Contains(BlendshapeControl.ResetId);
            var ids = used.Where(id => id != BlendshapeControl.ResetId).ToArray();
            if (reset) state.Problems[BlendshapeControl.ResetId] = NothingToReset;
            if (ids.Length == 0) return controls;
            var conflicts = BlendshapeConflicts.Scan(root);
            foreach (var id in ids)
            {
                var shape = c.FindShape(id);
                var problem = Problem(shape, root, conflicts);
                if (problem != null) state.Problems[id] = problem;
                else
                {
                    controls.Add(shape);
                    if (Note(shape, conflicts) is string note) state.Notes[id] = note;
                }
            }
            if (controls.Count == 0) return controls;
            foreach (var s in controls)
                state.Controls[s.id] = new Built { Parameter = s.Parameter, Name = s.blendshape, Radial = s.type == BlendshapeControlType.Radial };
            if (reset)
            {
                state.Problems.Remove(BlendshapeControl.ResetId);
                state.Controls[BlendshapeControl.ResetId] = new Built { Parameter = BlendshapeControl.ResetParameter, Name = ResetName, Reset = true };
            }
            return controls;
        }

        private const string NothingToReset = "초기화할 블렌드쉐이프 컨트롤이 없습니다.";

        internal static void Generate(BuildContext context)
        {
            var root = context.AvatarRootObject;
            var c = root.GetComponent<AvatarCustomizer>();
            if (!c || !c.enabled) return;
            var state = context.GetState<State>();
            var planned = new State();
            List<BlendshapeControl> controls;
            try { controls = Plan(c, root.transform, planned); }
            finally
            {
                // Problems and notes now, even from a check that failed half way; the controls only once they are built,
                // so a failure below keeps them out of the menu.
                foreach (var problem in planned.Problems) state.Problems[problem.Key] = problem.Value;
                foreach (var note in planned.Notes) state.Notes[note.Key] = note.Value;
            }
            if (controls.Count == 0) return;
            bool reset = planned.Controls.ContainsKey(BlendshapeControl.ResetId);
            if (reset) state.Problems[BlendshapeControl.ResetId] = NothingToReset;

            var controller = new AnimatorController { name = HolderName };
            controller.parameters = new[] { new AnimatorControllerParameter { name = One, type = AnimatorControllerParameterType.Float, defaultFloat = 1f } }
                .Concat(controls.Select(s => new AnimatorControllerParameter
                {
                    // Float even for a toggle: VRChat drives a float animator parameter from a bool expression parameter.
                    name = s.Parameter, type = AnimatorControllerParameterType.Float, defaultFloat = s.StartValue,
                })).ToArray();
            var direct = new BlendTree { name = "Blendshapes", blendType = BlendTreeType.Direct, useAutomaticThresholds = false };
            direct.children = controls.Select(s =>
            {
                string path = AnimationUtility.CalculateTransformPath(s.renderer.transform, root.transform);
                var tree = new BlendTree
                {
                    name = s.blendshape, blendType = BlendTreeType.Simple1D, blendParameter = s.Parameter, useAutomaticThresholds = false,
                };
                tree.children = new[]
                {
                    new ChildMotion { motion = Clip(s, path, s.min), threshold = 0f, timeScale = 1f },
                    new ChildMotion { motion = Clip(s, path, s.max), threshold = 1f, timeScale = 1f },
                };
                return new ChildMotion { motion = tree, directBlendParameter = One, timeScale = 1f };
            }).ToArray();
            // Direct blend trees need write defaults on; this layer animates nothing else.
            var animate = new AnimatorState { name = "Blendshapes", motion = direct, writeDefaultValues = true };
            var machine = new AnimatorStateMachine
            {
                name = "Blendshapes",
                states = new[] { new ChildAnimatorState { state = animate, position = new Vector3(300f, 100f) } },
                defaultState = animate,
            };
            var layers = new List<AnimatorControllerLayer> { new AnimatorControllerLayer { name = HolderName, defaultWeight = 1f, stateMachine = machine } };
            if (reset)
            {
                // Pressing the button (Reset true) enters a state whose parameter driver sets every control back to its
                // default. It runs for the wearer only; synced controls then reach everyone as usual.
                controller.parameters = controller.parameters.Append(new AnimatorControllerParameter
                    { name = BlendshapeControl.ResetParameter, type = AnimatorControllerParameterType.Bool }).ToArray();
                var empty = new AnimationClip { name = ResetLayerName + " (empty)" };
                var idle = new AnimatorState { name = "Idle", motion = empty, writeDefaultValues = true };
                var apply = new AnimatorState { name = "Reset", motion = empty, writeDefaultValues = true };
                var driver = apply.AddStateMachineBehaviour<VRCAvatarParameterDriver>();
                driver.localOnly = true;
                driver.parameters = controls.Select(s => new VRC.SDKBase.VRC_AvatarParameterDriver.Parameter
                {
                    type = VRC.SDKBase.VRC_AvatarParameterDriver.ChangeType.Set, name = s.Parameter, value = s.StartValue,
                }).ToList();
                AnimatorStateTransition To(AnimatorState target, AnimatorConditionMode mode)
                {
                    var transition = new AnimatorStateTransition { destinationState = target, hasExitTime = false, duration = 0f, hasFixedDuration = true };
                    transition.AddCondition(mode, 0f, BlendshapeControl.ResetParameter);
                    return transition;
                }
                idle.transitions = new[] { To(apply, AnimatorConditionMode.If) };
                apply.transitions = new[] { To(idle, AnimatorConditionMode.IfNot) };
                layers.Add(new AnimatorControllerLayer
                {
                    name = ResetLayerName, defaultWeight = 1f,
                    stateMachine = new AnimatorStateMachine
                    {
                        name = "Reset", defaultState = idle,
                        states = new[]
                        {
                            new ChildAnimatorState { state = idle, position = new Vector3(300f, 100f) },
                            new ChildAnimatorState { state = apply, position = new Vector3(300f, 200f) },
                        },
                    },
                });
            }
            controller.layers = layers.ToArray();

            var holder = new GameObject(HolderName);
            holder.transform.SetParent(root.transform, false);
            var merge = holder.AddComponent<ModularAvatarMergeAnimator>();
            merge.animator = controller;
            merge.layerType = VRCAvatarDescriptor.AnimLayerType.FX;
            merge.pathMode = MergeAnimatorPathMode.Absolute;
            merge.matchAvatarWriteDefaults = false;
            var parameters = holder.AddComponent<ModularAvatarParameters>();
            parameters.parameters = controls.Select(s => new ParameterConfig
            {
                nameOrPrefix = s.Parameter,
                syncType = s.type == BlendshapeControlType.Radial ? ParameterSyncType.Float : ParameterSyncType.Bool,
                localOnly = !s.synced,
                saved = s.saved,
                defaultValue = s.StartValue,
                hasExplicitDefaultValue = true,
            }).ToList();
            if (reset)
                parameters.parameters.Add(new ParameterConfig
                {
                    nameOrPrefix = BlendshapeControl.ResetParameter, syncType = ParameterSyncType.Bool,
                    localOnly = true, saved = false, defaultValue = 0f, hasExplicitDefaultValue = true,
                });

            foreach (var built in planned.Controls) state.Controls[built.Key] = built.Value;
            if (reset) state.Problems.Remove(BlendshapeControl.ResetId);
        }

        private static AnimationClip Clip(BlendshapeControl s, string path, float weight)
        {
            var clip = new AnimationClip { name = $"{s.blendshape} {weight:0.#}" };
            AnimationUtility.SetEditorCurve(clip,
                EditorCurveBinding.FloatCurve(path, typeof(SkinnedMeshRenderer), "blendShape." + s.blendshape),
                AnimationCurve.Constant(0f, 1f / 60f, weight));
            return clip;
        }
    }
}
#endif
