#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using VRC.SDK3.Avatars.Components;

namespace NXYUI.AIExpression
{
    // "AI 표정": the avatar and its face dictionary and working copy on the left, the way to Claude on the right (the
    // Claude API from here, or MCP for Claude Code). Saving the expression as a clip ends the work.
    internal sealed class AIExpressionWindow : EditorWindow
    {
        private static readonly string[] Ways = { "Claude API", "MCP (Claude Code)" };
        private static readonly string[] Modes = { "가볍게", "직접 편집" };
        private static readonly string[] Efforts = { "low", "medium", "high" };
        private static readonly string[] EffortLabels = { "낮음", "보통", "높음" };

        private VRCAvatarDescriptor avatar;
        private int way, mode;
        private int effort;
        private int rounds = 8, tokens = 100000;
        private string request = "", clipName = "", keyDraft;
        private string modelId = ClaudeApi.DefaultModel;
        private List<ClaudeApi.Model> models;
        private bool refreshing, dictionaryOpen;
        private string message, savedPath;
        private MessageType messageType;
        private Vector2 leftScroll, rightScroll;

        private GUIStyle wrappedBold;
        private GUIStyle WrappedBold => wrappedBold ??= new GUIStyle(EditorStyles.boldLabel) { wordWrap = true };

        [MenuItem("NXYUI/AI Expression")]
        private static void Open() => GetWindow<AIExpressionWindow>("AI 표정");

        private void OnEnable()
        {
            minSize = new Vector2(740, 420);
            models = ClaudeApi.CachedModels();
            modelId = EditorPrefs.GetString("NXYUI.AIExpression.Model", ClaudeApi.DefaultModel);
            ExpressionCore.Changed += Repaint;
            ExpressionAgent.Changed += Repaint;
            McpServer.Changed += Repaint;
            // Undo changes the face without telling the core: saving turns on or off with it.
            Undo.undoRedoPerformed += Repaint;
            // After a script reload the window still has its avatar while the core (statics) has forgotten it: without
            // telling it again every button answered "choose an avatar first" under a filled avatar field.
            if (avatar && IsSceneAvatar(avatar)) ExpressionCore.Select(avatar);
            else Pick(FromSelection() ?? WithCopies() ?? FindObjectsOfType<VRCAvatarDescriptor>().FirstOrDefault(IsSceneAvatar));
        }

        private void OnDisable()
        {
            ExpressionCore.Changed -= Repaint;
            ExpressionAgent.Changed -= Repaint;
            McpServer.Changed -= Repaint;
            Undo.undoRedoPerformed -= Repaint;
        }

        private void OnSelectionChange()
        {
            var selected = FromSelection();
            if (selected && selected != avatar && ExpressionCore.Session == null && !ExpressionAgent.Running)
            {
                Pick(selected);
                Repaint();
            }
        }

        private static VRCAvatarDescriptor FromSelection()
        {
            var go = Selection.activeGameObject;
            var d = go ? go.GetComponentInParent<VRCAvatarDescriptor>(true) : null;
            return d && IsSceneAvatar(d) ? d : null;
        }

        // The avatar an earlier editor run left unfinished work on: opening the window goes on with it.
        private static VRCAvatarDescriptor WithCopies() =>
            FindObjectsOfType<AIExpressionWorkCopy>(true).Where(WorkSession.Own).Select(c => c.GetComponentInParent<VRCAvatarDescriptor>(true)).FirstOrDefault(IsSceneAvatar);

        private static bool IsSceneAvatar(VRCAvatarDescriptor d) =>
            d && !EditorUtility.IsPersistent(d) && d.gameObject.scene.IsValid() && !EditorSceneManager.IsPreviewScene(d.gameObject.scene);

        private void Pick(VRCAvatarDescriptor next)
        {
            avatar = next;
            ExpressionCore.Select(next);
            message = null;
            savedPath = null;
        }

        private void Say(string text, MessageType type = MessageType.Info)
        {
            message = text;
            messageType = type;
        }

        // Runs an action that may fail with a message for the user.
        private void Try(Action action)
        {
            try { action(); }
            catch (Exception e)
            {
                Say(e.Message, MessageType.Warning);
                if (!(e is InvalidOperationException)) Debug.LogException(e);
            }
        }

        private static string Short(string text, int limit) => text.Length > limit ? text.Substring(0, limit - 1) + "…" : text;

        private void OnGUI()
        {
            // In the Layout pass only: the passes after it must see the controls it counted.
            if (Event.current.type == EventType.Layout) ExpressionCore.Check();
            bool working = ExpressionCore.Session != null, busy = ExpressionAgent.Running;
            using (new EditorGUILayout.HorizontalScope())
            {
                using (new EditorGUI.DisabledScope(working || busy))
                {
                    var next = (VRCAvatarDescriptor)EditorGUILayout.ObjectField("아바타", avatar, typeof(VRCAvatarDescriptor), true);
                    if (next != avatar)
                    {
                        bool usable = !next || IsSceneAvatar(next);
                        Pick(usable ? next : null);
                        if (!usable) Say("씬에 놓인 아바타만 고를 수 있어요. 프리팹은 씬에 꺼내 놓은 뒤에 골라 주세요.", MessageType.Warning);
                        GUIUtility.ExitGUI();
                    }
                }
                // A disabled control shows no tooltip, so the reason stands beside it.
                if (working || busy)
                    GUILayout.Label(busy ? "Claude가 고치는 동안에는 바꿀 수 없어요" : "작업을 끝내면 바꿀 수 있어요", EditorStyles.miniLabel, GUILayout.ExpandWidth(false));
            }
            if (!string.IsNullOrEmpty(message)) EditorGUILayout.HelpBox(message, messageType);
            var leftovers = WorkSession.Leftovers(ExpressionCore.Session);
            if (leftovers.Count > 0)
                using (new EditorGUILayout.HorizontalScope())
                {
                    EditorGUILayout.HelpBox(LeftoverText(leftovers), MessageType.Warning);
                    if (GUILayout.Button(new GUIContent("정리", "남은 작업본을 지우고 원본을 다시 보여 줘요. Ctrl+Z로 되돌릴 수 있어요."), GUILayout.Width(60), GUILayout.Height(38)))
                    {
                        WorkSession.CleanUp(leftovers, ExpressionCore.Session);
                        GUIUtility.ExitGUI();
                    }
                }
            // Markers this tool did not make here: never adopted or deleted, but the user should know they are there.
            var strangers = WorkSession.Strangers();
            if (strangers.Count > 0)
                using (new EditorGUILayout.HorizontalScope())
                {
                    EditorGUILayout.HelpBox($"⚠ 이 프로젝트에서 이 창이 만들지 않은 작업본 표시(AI Expression Work Copy)가 {strangers.Count}개 있어요. " +
                                            "다른 프로젝트의 프리팹, 0.2.0 전에 만든 작업본, 무언가 붙은 작업본일 수 있어서 이 창은 고치거나 지우지 않아요. 필요 없으면 직접 지우세요.",
                        MessageType.Warning);
                    if (GUILayout.Button(new GUIContent("선택", "그 오브젝트들을 Hierarchy에서 선택해요."), GUILayout.Width(60), GUILayout.Height(38)))
                    {
                        Selection.objects = strangers.Select(c => (UnityEngine.Object)c.gameObject).ToArray();
                        GUIUtility.ExitGUI();
                    }
                }
            if (!avatar)
            {
                EditorGUILayout.HelpBox("표정을 만들 아바타를 고르세요. Hierarchy에서 아바타를 고르면 자동으로 들어가요.", MessageType.Info);
                return;
            }
            using (new EditorGUILayout.HorizontalScope())
            {
                using (new EditorGUILayout.VerticalScope(GUILayout.Width(position.width * 0.48f)))
                using (var scroll = new EditorGUILayout.ScrollViewScope(leftScroll))
                {
                    leftScroll = scroll.scrollPosition;
                    DrawDictionary();
                    EditorGUILayout.Space(8);
                    DrawSession();
                }
                using (new EditorGUILayout.VerticalScope())
                {
                    if (busy) DrawRunning();
                    using (var scroll = new EditorGUILayout.ScrollViewScope(rightScroll))
                    {
                        rightScroll = scroll.scrollPosition;
                        int nextWay = GUILayout.Toolbar(way, Ways);
                        if (nextWay != way)
                        {
                            // The two tabs hold different controls: this pass ends here, so no pass draws more controls
                            // than its Layout counted.
                            way = nextWay;
                            Repaint();
                            GUIUtility.ExitGUI();
                        }
                        EditorGUILayout.Space(4);
                        if (way == 0) DrawApi();
                        else DrawMcp();
                    }
                }
            }
        }

        // What the copies no session holds are, and what can be done with them.
        private string LeftoverText(List<AIExpressionWorkCopy> leftovers)
        {
            var others = leftovers.Select(c => c.GetComponentInParent<VRCAvatarDescriptor>(true)).Where(a => a && a != avatar).Distinct()
                .Select(a => a.name).ToList();
            string what = others.Count > 0
                ? $"아바타 ‘{Short(string.Join(", ", others), 30)}’에서 하던 작업이에요. 그 아바타를 고르면 이어서 하고,"
                : "지금 작업에 속하지 않은 작업본이에요(작업본을 복제했거나 원본이 없어진 경우).";
            return $"⚠ 끝나지 않은 작업본이 {leftovers.Count}개 남아 있어요. {what} ‘정리’를 누르면 지우고 원본을 다시 보여 줘요.";
        }

        // ---- left ----------------------------------------------------------------------------------------------

        private void DrawDictionary()
        {
            EditorGUILayout.LabelField("얼굴 사전", EditorStyles.boldLabel);
            EditorGUILayout.LabelField("얼굴 쉐이프키마다 어디가 어느 쪽으로 움직이는지 정점 이동으로 읽어 둔 목록이에요. Claude는 이것을 보고 번호와 값으로 답해요.",
                EditorStyles.wordWrappedMiniLabel);
            var d = ExpressionCore.Dictionary != null && ExpressionCore.Dictionary.Avatar == avatar ? ExpressionCore.Dictionary : null;
            bool working = ExpressionCore.Session != null, busy = ExpressionAgent.Running;
            using (new EditorGUILayout.HorizontalScope())
            {
                // A first dictionary can be read during work (a session found again after a restart has none yet).
                using (new EditorGUI.DisabledScope(busy || (working && d != null)))
                if (GUILayout.Button(d == null ? "사전 만들기" : "다시 만들기", GUILayout.Width(100)))
                {
                    Try(() =>
                    {
                        var built = ExpressionCore.EnsureDictionary(d != null);
                        Say($"얼굴 쉐이프키 {built.Entries.Count}개를 읽었어요 (메시 {built.Renderers.Count}개, 뺀 것 {built.Skipped}개).");
                    });
                    GUIUtility.ExitGUI();
                }
                GUILayout.Label(d == null ? "아직 없어요. 처음 요청할 때 자동으로 만들어요." : $"쉐이프키 {d.Entries.Count}개 · 메시 {d.Renderers.Count}개", EditorStyles.miniLabel);
            }
            if (busy || (working && d != null))
                EditorGUILayout.LabelField(busy ? "Claude가 고치는 동안에는 다시 만들 수 없어요." : "작업 중에는 다시 만들 수 없어요. 작업을 끝내면 할 수 있어요.",
                    EditorStyles.wordWrappedMiniLabel);
            bool names = EditorGUILayout.ToggleLeft(new GUIContent("쉐이프키 이름도 보내기",
                "이름은 토큰을 더 쓰지만(캐시로 대부분 아껴요) Claude가 훨씬 정확해져요. 끄면 번호와 움직임만 보내요."), ExpressionCore.SendNames);
            if (names != ExpressionCore.SendNames) ExpressionCore.SendNames = names;
            if (d == null) return;
            int off = d.Renderers.Count(r => !FaceDictionary.Shown(r));
            if (off > 0)
                EditorGUILayout.LabelField($"꺼져 있는 메시 {off}개의 쉐이프키도 들어 있어요. 그 메시는 작업본도 꺼진 채로 만들어져서, 고쳐도 화면과 사진에는 보이지 않아요.",
                    EditorStyles.wordWrappedMiniLabel);
            bool open = EditorGUILayout.Foldout(dictionaryOpen, "목록 보기", true);
            if (open != dictionaryOpen)
            {
                dictionaryOpen = open;
                Repaint();
                GUIUtility.ExitGUI();
            }
            if (!dictionaryOpen) return;
            foreach (var e in d.Entries.Take(60))
                EditorGUILayout.LabelField(new GUIContent($"{e.Id}  {e.Name}", e.Name), new GUIContent($"{e.Region} · {e.Motion} · {e.Strength}"), EditorStyles.miniLabel);
            if (d.Entries.Count > 60) EditorGUILayout.LabelField($"… 외 {d.Entries.Count - 60}개", EditorStyles.miniLabel);
        }

        private void DrawSession()
        {
            EditorGUILayout.LabelField("작업", EditorStyles.boldLabel);
            var session = ExpressionCore.Session;
            bool busy = ExpressionAgent.Running;
            using (new EditorGUI.DisabledScope(session != null))
            {
                bool copies = EditorGUILayout.ToggleLeft(new GUIContent("작업본에서 작업 (권장)",
                    "얼굴 메시의 복사본(EditorOnly)을 만들어 거기서 고쳐요. 원본은 Scene 뷰에서만 숨겨지고 바뀌지 않아요."), ExpressionCore.UseCopies);
                if (copies != ExpressionCore.UseCopies) ExpressionCore.UseCopies = copies;
            }
            if (session == null)
            {
                EditorGUILayout.LabelField("아직 작업 중이 아니에요. Claude가 처음 고칠 때 자동으로 시작해요. " + (ExpressionCore.UseCopies
                    ? "얼굴 메시의 작업본(EditorOnly 복사본)을 만들어 거기서 고치고, 원본은 Scene 뷰에서만 숨겨요."
                    : "작업본 없이 원본 메시의 값을 바로 바꿔요. 고친 것마다 Ctrl+Z로 되돌릴 수 있어요."), EditorStyles.wordWrappedMiniLabel);
                if (GUILayout.Button("작업 시작", GUILayout.Width(100))) { Try(() => ExpressionCore.EnsureSession()); GUIUtility.ExitGUI(); }
            }
            else
            {
                EditorGUILayout.LabelField((session.Cloned ? $"작업본 {session.Working.Count}개에서 작업 중이에요." : "원본에서 바로 작업 중이에요. 고친 것마다 Ctrl+Z로 되돌릴 수 있어요.") +
                                           " ‘작업본에서 작업’은 작업을 끝내면 바꿀 수 있어요.", EditorStyles.wordWrappedMiniLabel);
                using (new EditorGUI.DisabledScope(busy))
                {
                    using (new EditorGUILayout.HorizontalScope())
                    {
                        if (GUILayout.Button("기본 표정으로")) { Try(() => ExpressionCore.ResetFace("창")); GUIUtility.ExitGUI(); }
                        if (session.Cloned && GUILayout.Button(new GUIContent("원본에 반영하고 끝내기", "지금 표정을 원본 메시에 넣고 작업본을 지워요.")))
                        {
                            Try(() => ExpressionCore.Finish(true));
                            GUIUtility.ExitGUI();
                        }
                    }
                    if (GUILayout.Button(new GUIContent(session.Cloned ? "버리고 끝내기" : "끝내기", session.Cloned ? "작업본을 지우고 원본을 다시 보여 줘요." : "작업을 끝내요. 바꾼 값은 그대로예요.")))
                    {
                        Try(() => ExpressionCore.Finish(false));
                        GUIUtility.ExitGUI();
                    }
                }
                // What the buttons do stands here and not only in their tooltips; a disabled button shows none.
                EditorGUILayout.LabelField(busy ? "Claude가 고치는 동안에는 끝낼 수 없어요. 오른쪽 위의 ‘멈추기’를 먼저 눌러 주세요."
                    : session.Cloned ? "원본에 반영하고 끝내기: 지금 표정을 원본 메시에 넣어요. 버리고 끝내기: 원본은 그대로 둬요. 둘 다 작업본을 지우고, Ctrl+Z로 되돌릴 수 있어요."
                    : "끝내기: 바꾼 값은 원본에 그대로 남아요.", EditorStyles.wordWrappedMiniLabel);
            }
            EditorGUILayout.Space(8);
            EditorGUILayout.LabelField("표정 클립으로 저장", EditorStyles.boldLabel);
            string blocked = SaveBlocked(clipName);
            using (new EditorGUILayout.HorizontalScope())
            {
                float labelWidth = EditorGUIUtility.labelWidth;
                EditorGUIUtility.labelWidth = 40;
                clipName = EditorGUILayout.TextField("이름", clipName);
                EditorGUIUtility.labelWidth = labelWidth;
                using (new EditorGUI.DisabledScope(blocked != null))
                    if (GUILayout.Button("저장", GUILayout.Width(50)))
                    {
                        Try(() =>
                        {
                            savedPath = ExpressionCore.Save(clipName.Trim(), "창");
                            Say("저장했어요: " + savedPath + "\n다른 표정을 더 만들어도 되고, 다 됐으면 ‘작업’에서 끝내세요.");
                        });
                        GUIUtility.ExitGUI();
                    }
            }
            EditorGUILayout.LabelField((blocked != null ? blocked + " " : "") + "기본 표정과 달라진 쉐이프키만 원본 메시 경로로 담아요. FX나 Gesture 레이어에 넣어 쓰세요.",
                EditorStyles.wordWrappedMiniLabel);
            if (!string.IsNullOrEmpty(savedPath) && GUILayout.Button(new GUIContent("저장한 클립 보기", savedPath), GUILayout.Width(120)))
                EditorGUIUtility.PingObject(AssetDatabase.LoadAssetAtPath<AnimationClip>(savedPath));
            if (!string.IsNullOrEmpty(ExpressionCore.Activity)) EditorGUILayout.LabelField(ExpressionCore.Activity, EditorStyles.wordWrappedMiniLabel);
        }

        // Why saving is off, or null. Shown beside the button (a disabled button shows no tooltip). Not while Claude is
        // still editing: the clip would hold a half-made face. Not before the face differs from the default face.
        internal static string SaveBlocked(string clipName) =>
            ExpressionCore.Session == null ? "표정을 만든 뒤에 저장할 수 있어요." :
            ExpressionAgent.Running ? "Claude가 고치는 중이라 아직 저장할 수 없어요. 끝나거나 ‘멈추기’를 누른 뒤에 저장하세요." :
            !ExpressionCore.HasExpression ? "아직 기본 표정과 같아요. 표정을 바꾼 뒤에 저장할 수 있어요." :
            string.IsNullOrWhiteSpace(clipName) ? "클립 이름을 넣으면 저장할 수 있어요." : null;

        // While Claude works: what it is doing and the way to stop it, above the tabs and outside the scroll view, so
        // neither another tab nor scrolling hides them.
        private static void DrawRunning()
        {
            using (new EditorGUILayout.HorizontalScope())
            {
                EditorGUILayout.HelpBox(string.IsNullOrEmpty(ExpressionAgent.Status) ? "Claude에게 묻는 중이에요…" : ExpressionAgent.Status, MessageType.Info);
                if (GUILayout.Button(new GUIContent("멈추기", "지금 요청을 멈춰요. 이미 바꾼 값은 남고, 하나씩 Ctrl+Z로 되돌릴 수 있어요."), GUILayout.Width(60), GUILayout.Height(38)))
                    ExpressionAgent.Stop();
            }
            EditorGUILayout.Space(4);
        }

        // ---- right: API ----------------------------------------------------------------------------------------

        private void DrawApi()
        {
            EditorGUILayout.LabelField("Claude API", EditorStyles.boldLabel);
            using (new EditorGUILayout.HorizontalScope())
            {
                keyDraft ??= ClaudeApi.ApiKey;
                keyDraft = EditorGUILayout.PasswordField(new GUIContent("API 키", "이 컴퓨터의 Unity 설정(EditorPrefs)에만 저장돼요. 프로젝트에는 들어가지 않아요."), keyDraft);
                using (new EditorGUI.DisabledScope(keyDraft == ClaudeApi.ApiKey))
                    if (GUILayout.Button("저장", GUILayout.Width(50)))
                    {
                        ClaudeApi.ApiKey = keyDraft = keyDraft.Trim();
                        GUI.FocusControl(null);
                    }
            }
            // Always one line, so saving the key changes its words and not the number of controls.
            EditorGUILayout.LabelField(keyDraft != ClaudeApi.ApiKey ? "아직 저장하지 않았어요. ‘저장’을 눌러야 이 키를 써요."
                : string.IsNullOrEmpty(ClaudeApi.ApiKey) ? "Anthropic 콘솔에서 만든 API 키를 붙여 넣고 ‘저장’을 누르세요. 쓴 만큼 요금이 들어요. 키 없이 쓰려면 위에서 ‘MCP (Claude Code)’를 고르세요."
                : "키가 저장돼 있어요. 이 컴퓨터의 Unity 설정에만 있고 프로젝트에는 들어가지 않아요.", EditorStyles.wordWrappedMiniLabel);
            int nextMode = GUILayout.Toolbar(mode, Modes, EditorStyles.miniButton);
            if (nextMode != mode)
            {
                // Direct edit has two more controls: see the tabs above.
                mode = nextMode;
                Repaint();
                GUIUtility.ExitGUI();
            }
            EditorGUILayout.LabelField(mode == 0
                ? "가볍게: 사전만 보고 한 번에 번호와 값을 답해요. 토큰이 가장 적게 들어요."
                : "직접 편집: Claude가 고치고, 얼굴을 찍어 보고, 다시 고쳐요. 이미지를 볼 수 있는 모델만 되고 토큰을 더 써요.", EditorStyles.wordWrappedMiniLabel);

            var usable = (models ?? new List<ClaudeApi.Model>()).Where(m => mode == 0 || m.image).ToList();
            using (new EditorGUILayout.HorizontalScope())
            {
                if (usable.Count == 0) EditorGUILayout.LabelField("모델", modelId);
                else
                {
                    int index = Mathf.Max(0, usable.FindIndex(m => m.id == modelId));
                    int next = EditorGUILayout.Popup("모델", index, usable.Select(m => m.name).ToArray());
                    if (usable[next].id != modelId)
                    {
                        modelId = usable[next].id;
                        EditorPrefs.SetString("NXYUI.AIExpression.Model", modelId);
                    }
                }
                using (new EditorGUI.DisabledScope(refreshing || string.IsNullOrEmpty(ClaudeApi.ApiKey)))
                    if (GUILayout.Button(new GUIContent("불러오기", "이 키로 쓸 수 있는 모델을 불러와요."), GUILayout.Width(64)))
                    {
                        RefreshModels();
                        GUIUtility.ExitGUI();
                    }
            }
            if (refreshing) EditorGUILayout.LabelField("모델 목록을 불러오는 중이에요…", EditorStyles.wordWrappedMiniLabel);
            else if (models == null || models.Count == 0)
                EditorGUILayout.LabelField($"API 키를 저장하고 ‘불러오기’를 누르면 이 키로 쓸 수 있는 모델을 불러와요. 누르지 않으면 {modelId}(으)로 보내요.", EditorStyles.wordWrappedMiniLabel);
            effort = EditorGUILayout.Popup(new GUIContent("생각하는 정도", "높을수록 신중하지만 토큰과 시간이 더 들어요."), effort, EffortLabels);
            if (mode == 1)
            {
                rounds = EditorGUILayout.IntSlider(new GUIContent("최대 반복", "Claude가 고치고 보는 일을 몇 번까지 할지예요."), rounds, 1, 20);
                tokens = Mathf.Max(5000, EditorGUILayout.IntField(new GUIContent("최대 토큰",
                    "이 요청에서 쓸 토큰의 합(입력·캐시·출력)이 다음 요청으로 넘을 것 같으면 보내지 않고 멈춰요. 보내기 전에 어림하므로 조금 넘을 수 있어요."), tokens));
            }
            EditorGUILayout.LabelField("어떤 표정을 원하세요?", EditorStyles.boldLabel);
            request = EditorGUILayout.TextArea(request, GUILayout.MinHeight(54));
            var model = Current();
            bool running = ExpressionAgent.Running;
            string why = running ? null :
                string.IsNullOrEmpty(ClaudeApi.ApiKey) ? "API 키를 먼저 저장해 주세요." :
                model == null ? "쓸 수 있는 모델이 없어요. ‘불러오기’를 눌러 모델을 다시 불러와 주세요." :
                mode == 1 && !model.image ? "이 모델은 이미지를 볼 수 없어요. ‘가볍게’로 바꾸거나 다른 모델을 골라 주세요." :
                string.IsNullOrWhiteSpace(request) ? "원하는 표정을 적으면 보낼 수 있어요." : null;
            // While running, the status and ‘멈추기’ stand above the tabs (DrawRunning), not here a second time.
            using (new EditorGUI.DisabledScope(running || why != null))
                if (GUILayout.Button("보내기"))
                {
                    if (mode == 0) ExpressionAgent.RunLight(model, Efforts[effort], request.Trim());
                    else ExpressionAgent.RunDirect(model, Efforts[effort], request.Trim(), rounds, tokens);
                    // The status box appears with the run.
                    GUIUtility.ExitGUI();
                }
            // Why the button is off, or what it will do: a disabled button shows no tooltip.
            EditorGUILayout.LabelField(why ?? (running ? "Claude가 답하는 중이에요. 그만두려면 위의 ‘멈추기’를 누르세요."
                : "보내면 Claude가 얼굴 쉐이프키를 고쳐요. 결과는 Scene 뷰에서 보고, 고친 것마다 Ctrl+Z로 되돌릴 수 있어요."), EditorStyles.wordWrappedMiniLabel);
            if (!running && !string.IsNullOrEmpty(ExpressionAgent.Status))
                EditorGUILayout.HelpBox(ExpressionAgent.Status, ExpressionAgent.Failed ? MessageType.Warning : MessageType.Info);
            if (ExpressionAgent.All.Calls > 0)
            {
                EditorGUILayout.LabelField("이번 요청: " + ExpressionAgent.Run, EditorStyles.wordWrappedMiniLabel);
                EditorGUILayout.LabelField("이번 세션 합계: " + ExpressionAgent.All, EditorStyles.wordWrappedMiniLabel);
            }
            EditorGUILayout.LabelField("마음에 드는 표정이 되면 왼쪽 아래 ‘표정 클립으로 저장’에서 이름을 넣고 저장하세요. " +
                                       "사전은 캐시에 남아서, 같은 아바타로 이어서 물으면 입력 토큰 대부분이 싸게 처리돼요.", EditorStyles.wordWrappedMiniLabel);
        }

        private ClaudeApi.Model Current() =>
            models?.FirstOrDefault(m => m.id == modelId) ?? (models == null || models.Count == 0
                ? new ClaudeApi.Model { id = modelId, name = modelId, image = true, structured = true, effort = true } : null);

        private async void RefreshModels()
        {
            refreshing = true;
            try
            {
                models = await ClaudeApi.RefreshModels();
                Say($"모델 {models.Count}개를 불러왔어요.");
            }
            catch (Exception e) { Say(e.Message, MessageType.Warning); }
            finally
            {
                refreshing = false;
                Repaint();
            }
        }

        // ---- right: MCP ----------------------------------------------------------------------------------------

        private void DrawMcp()
        {
            EditorGUILayout.LabelField("MCP 서버", EditorStyles.boldLabel);
            EditorGUILayout.LabelField("Claude Code 같은 MCP 클라이언트가 이 창의 아바타 표정을 직접 고쳐요. 연결한 프로그램이 고른 모델을 쓰고, API 키는 필요 없어요. " +
                                       "이 컴퓨터(127.0.0.1)에서만 연결돼요.", EditorStyles.wordWrappedMiniLabel);
            bool on = EditorGUILayout.ToggleLeft("MCP 서버 켜기", McpServer.Enabled);
            if (on != McpServer.Enabled) McpServer.Enabled = on;
            using (new EditorGUI.DisabledScope(McpServer.Listening))
            {
                // Delayed: a port typed digit by digit is not taken (and clamped) at every key.
                int port = EditorGUILayout.DelayedIntField(new GUIContent("포트", "다른 프로그램이 같은 포트를 쓰면 바꿔 주세요. 켜져 있을 때는 바꿀 수 없어요."), McpServer.Port);
                if (port != McpServer.Port)
                {
                    McpServer.Port = port;
                    // Turned on but not listening (the port was taken): the new port is tried at once.
                    if (McpServer.Enabled) McpServer.Start();
                }
            }
            // Always one box: turning the server on or off changes its words and not the number of controls.
            if (!McpServer.Enabled) EditorGUILayout.HelpBox("꺼져 있어요. 켜면 아래 주소에서 Claude Code의 연결을 기다려요.", MessageType.None);
            else if (McpServer.Listening) EditorGUILayout.HelpBox("연결을 기다리고 있어요: " + McpServer.Url + "\n포트는 서버를 끈 뒤에 바꿀 수 있어요.", MessageType.Info);
            else
                EditorGUILayout.HelpBox("⚠ 서버를 열지 못했어요: " + McpServer.Error + "\n다른 프로그램이 이 포트를 쓰고 있을 수 있어요. 포트를 바꾸면 바로 다시 열어요. " +
                                        "그 프로그램이 Claude Code의 연결(토큰이 들어 있어요)을 받았을 수 있으니, 포트를 바꾼 뒤 토큰도 새로 만들고 Claude Code에 다시 추가하세요.",
                    MessageType.Warning);
            EditorGUILayout.Space(6);
            EditorGUILayout.LabelField("Claude Code에 추가하기", EditorStyles.boldLabel);
            EditorGUILayout.LabelField("터미널에서 한 번 실행하세요. 이미 추가했는데 포트나 토큰을 바꿨다면, 지우는 명령을 먼저 실행하고 다시 추가하세요.", EditorStyles.wordWrappedMiniLabel);
            using (new EditorGUILayout.HorizontalScope())
            {
                EditorGUILayout.SelectableLabel(McpServer.ShownCommand, EditorStyles.textField, GUILayout.Height(EditorGUIUtility.singleLineHeight));
                if (GUILayout.Button(new GUIContent("복사", "토큰까지 넣어 복사해요."), GUILayout.Width(50)))
                {
                    EditorGUIUtility.systemCopyBuffer = McpServer.AddCommand;
                    ShowNotification(new GUIContent("추가하는 명령을 복사했어요"), 1.5);
                }
            }
            EditorGUILayout.LabelField("토큰은 화면에 보이지 않게 가렸고, ‘복사’를 누르면 토큰까지 들어가요. 명령에 든 토큰이 있어야 연결되고, 토큰을 새로 만들면 예전 명령으로 추가한 연결은 끊겨요.",
                EditorStyles.wordWrappedMiniLabel);
            using (new EditorGUILayout.HorizontalScope())
            {
                if (GUILayout.Button(new GUIContent("토큰 새로 만들기", "다른 사람에게 명령을 보여 줬다면 새로 만드세요."), GUILayout.Width(110)))
                {
                    // Not something Undo takes back: the connection Claude Code has stops working.
                    if (EditorUtility.DisplayDialog("토큰 새로 만들기", "토큰을 새로 만들면 지금 Claude Code에 추가해 둔 연결이 끊겨요.\n지우는 명령을 실행한 뒤, 새 명령으로 다시 추가해야 해요.", "새로 만들기", "취소"))
                    {
                        McpServer.RenewToken();
                        if (McpServer.Enabled) McpServer.Start();
                    }
                    GUIUtility.ExitGUI();
                }
                if (GUILayout.Button(new GUIContent("지우는 명령 복사", McpServer.RemoveCommand), GUILayout.Width(110)))
                {
                    EditorGUIUtility.systemCopyBuffer = McpServer.RemoveCommand;
                    ShowNotification(new GUIContent("지우는 명령을 복사했어요"), 1.5);
                }
            }
            EditorGUILayout.LabelField("그다음 Claude Code에 ‘아바타를 웃는 표정으로 만들어 줘’처럼 말하면 사전을 읽고 고쳐요. 결과는 왼쪽에서 클립으로 저장하세요.",
                EditorStyles.wordWrappedMiniLabel);
            var log = McpServer.Log.ToList();
            if (log.Count > 0)
            {
                EditorGUILayout.Space(6);
                EditorGUILayout.LabelField("최근 요청", EditorStyles.boldLabel);
                foreach (var line in log) EditorGUILayout.LabelField(line, EditorStyles.miniLabel);
            }
        }
    }
}
#endif
