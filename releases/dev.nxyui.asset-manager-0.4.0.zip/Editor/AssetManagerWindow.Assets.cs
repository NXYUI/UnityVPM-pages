using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.UIElements;
using UnityEngine;
using UnityEngine.UIElements;
using static NXYUI.AssetManager.AssetGui;

namespace NXYUI.AssetManager
{
    // The 에셋 page (UI Toolkit): filters on the left, a gallery of two cards per row, the selected asset's detail on
    // the right (Booth link, folders, assembly). The assembly form is the IMGUI one the Inspector panel uses too.
    internal sealed partial class AssetManagerWindow
    {
        [SerializeField] private string selectedAsset;
        [SerializeField] private string assetSearch = "";
        [SerializeField] private int kindFilter = -1;
        // 0: every asset, 1: linked to Booth, 2: not linked yet.
        [SerializeField] private int boothFilter;
        [SerializeField] private string shopFilter = "";
        [SerializeField] private AssemblyForm assembly = new AssemblyForm();

        private readonly List<AssetRecord> shown = new List<AssetRecord>();
        private ScrollView sidebar;
        private ListView gallery;
        private Label countLabel;
        private VisualElement noMatch;
        private IVisualElementScheduledItem detailItem;
        private VisualElement detail;
        private float cardWidth = 150;
        private string boothQuery = "", boothQueryFor, boothAddress = "", boothMessage;
        private bool boothMessageWarn;

        private const float RowGap = 12, CardBody = 70, ScrollBarRoom = 14;

        private AssetRecord SelectedAsset => AssetStore.AssetById(selectedAsset);

        private void BuildAssetsPage(VisualElement into)
        {
            gallery = null;
            detail = null;
            sidebar = null;
            if (AssetStore.Project.assets.Count == 0)
            {
                into.Add(UiEmpty("아직 에셋이 없어요",
                    "‘폴더 지정’에서 이미 있는 상품 폴더를 에셋으로 지정하거나, ‘가져오기’에서 패키지를 가져오세요.",
                    ("폴더 지정 열기", () => SetTab(2)), ("가져오기 열기", () => SetTab(1))));
                return;
            }

            sidebar = new ScrollView();
            sidebar.AddToClassList("am-sidebar");
            into.Add(sidebar);

            var center = new VisualElement();
            center.AddToClassList("am-gallery");
            var toolbar = new VisualElement();
            toolbar.AddToClassList("am-toolbar");
            var search = new ToolbarSearchField { value = assetSearch, tooltip = "이름, 샵, 태그로 찾아요." };
            search.AddToClassList("am-search");
            search.RegisterValueChangedCallback(e =>
            {
                assetSearch = e.newValue ?? "";
                Filter();
            });
            toolbar.Add(search);
            countLabel = new Label();
            countLabel.AddToClassList("am-count");
            toolbar.Add(countLabel);
            center.Add(toolbar);
            var hint = new Label("Project 창에서 에셋 폴더나 프리팹을 고르면 인스펙터에서 바로 연결·조립할 수 있어요.");
            hint.AddToClassList("am-hint");
            center.Add(hint);

            gallery = new ListView
            {
                makeItem = MakeRow,
                bindItem = BindRow,
                fixedItemHeight = RowHeight,
                selectionType = SelectionType.None,
                virtualizationMethod = CollectionVirtualizationMethod.FixedHeight,
                focusable = true,
                tooltip = "카드를 누른 뒤 방향키로 옮길 수 있어요.",
            };
            gallery.AddToClassList("am-list");
            noMatch = new VisualElement();
            noMatch.AddToClassList("am-hidden");
            center.Add(noMatch);
            gallery.RegisterCallback<GeometryChangedEvent>(_ => Resize());
            gallery.RegisterCallback<KeyDownEvent>(OnGalleryKey, TrickleDown.TrickleDown);
            center.Add(gallery);
            into.Add(center);

            detail = new ScrollView();
            detail.AddToClassList("am-detail");
            into.Add(detail);

            BuildSidebar();
            Filter();
            BuildDetail();
        }

        private void RefreshAssetsPage()
        {
            if (gallery == null || AssetStore.Project.assets.Count == 0)
            {
                BuildPage();
                return;
            }
            BuildSidebar();
            Filter();
            BuildDetail();
        }

        private void RefreshImages()
        {
            gallery?.RefreshItems();
            ScheduleDetail();
        }

        // The Project selection decides what ‘고른 폴더 넣기’ can add.
        private void OnSelectionChanged() => ScheduleDetail();

        // Notices can arrive while the assembly form (IMGUI) is drawing: the detail is rebuilt on the next frame, once.
        private void ScheduleDetail()
        {
            if (detail == null || root == null) return;
            detailItem?.Pause();
            detailItem = root.schedule.Execute(BuildDetail);
        }

        // After the page is laid out, so the list knows its rows.
        private void RevealSelected()
        {
            root?.schedule.Execute(() =>
            {
                if (gallery == null) return;
                var index = shown.FindIndex(a => a.id == selectedAsset);
                if (index >= 0) gallery.ScrollToItem(index / 2);
            }).StartingIn(50);
        }

        // ---- Filters ----

        private void BuildSidebar()
        {
            if (sidebar == null) return;
            sidebar.Clear();
            var assets = AssetStore.Project.assets;
            Head("종류");
            Item("전체", assets.Count, kindFilter < 0, () => kindFilter = -1);
            foreach (AssetKind kind in Enum.GetValues(typeof(AssetKind)))
            {
                var count = assets.Count(a => a.kind == kind);
                if (count == 0 && (int)kind != kindFilter) continue;
                Item(KindName(kind), count, kindFilter == (int)kind, () => kindFilter = kindFilter == (int)kind ? -1 : (int)kind);
            }
            Head("Booth");
            var linked = assets.Count(a => a.boothId > 0);
            Item("연결됨", linked, boothFilter == 1, () => boothFilter = boothFilter == 1 ? 0 : 1);
            Item("미연결", assets.Count - linked, boothFilter == 2, () => boothFilter = boothFilter == 2 ? 0 : 2);
            var shops = assets.Select(ShopOf).Where(s => s.Length > 0).GroupBy(s => s)
                .OrderByDescending(g => g.Count()).ThenBy(g => g.Key, StringComparer.CurrentCultureIgnoreCase).Take(10).ToList();
            if (shops.Count > 0 || shopFilter.Length > 0)
            {
                Head("샵");
                if (shopFilter.Length > 0 && shops.All(g => g.Key != shopFilter))
                    Item(shopFilter, assets.Count(a => ShopOf(a) == shopFilter), true, () => shopFilter = "");
                foreach (var shop in shops)
                    Item(shop.Key, shop.Count(), shopFilter == shop.Key, () => shopFilter = shopFilter == shop.Key ? "" : shop.Key);
            }

            void Head(string text)
            {
                var label = new Label(text);
                label.AddToClassList("am-side-head");
                label.EnableInClassList("am-side-head--first", sidebar.childCount == 0);
                sidebar.Add(label);
            }

            void Item(string text, int count, bool on, Action choose)
            {
                var button = new Button(() =>
                {
                    choose();
                    BuildSidebar();
                    Filter();
                }) { tooltip = text };
                button.AddToClassList("am-side-item");
                button.EnableInClassList("am-side-item--on", on);
                var name = new Label(text);
                name.AddToClassList("am-side-name");
                var number = new Label(count.ToString());
                number.AddToClassList("am-side-count");
                button.Add(name);
                button.Add(number);
                sidebar.Add(button);
            }
        }

        private static string ShopOf(AssetRecord asset) => AssetStore.Item(asset.boothId)?.shop ?? "";

        private void Filter()
        {
            shown.Clear();
            shown.AddRange(AssetStore.Project.assets
                .Where(a => kindFilter < 0 || (int)a.kind == kindFilter)
                .Where(a => boothFilter == 0 || (boothFilter == 1) == (a.boothId > 0))
                .Where(a => shopFilter.Length == 0 || ShopOf(a) == shopFilter)
                .Where(a => assetSearch.Length == 0 || Matches(a, assetSearch))
                .OrderBy(a => a.name, StringComparer.CurrentCultureIgnoreCase));
            if (countLabel != null) countLabel.text = $"{shown.Count}개 / 전체 {AssetStore.Project.assets.Count}개";
            if (gallery == null) return;
            gallery.itemsSource = Enumerable.Range(0, (shown.Count + 1) / 2).ToList();
            gallery.RefreshItems();
            gallery.EnableInClassList("am-hidden", shown.Count == 0);
            if (noMatch == null) return;
            noMatch.Clear();
            noMatch.EnableInClassList("am-hidden", shown.Count > 0);
            if (shown.Count > 0) return;
            var hiding = new List<string>();
            if (assetSearch.Length > 0) hiding.Add($"검색어 ‘{assetSearch}’");
            if (kindFilter >= 0) hiding.Add($"종류 ‘{KindNames[kindFilter]}’");
            if (boothFilter > 0) hiding.Add(boothFilter == 1 ? "‘연결됨’" : "‘미연결’");
            if (shopFilter.Length > 0) hiding.Add($"샵 ‘{shopFilter}’");
            noMatch.Add(UiEmpty("보이는 에셋이 없어요", $"{string.Join(", ", hiding)} 조건에 맞는 에셋이 없어요. 왼쪽에서 조건을 풀어 보세요.",
                ("조건 모두 풀기", () =>
                {
                    assetSearch = "";
                    kindFilter = -1;
                    boothFilter = 0;
                    shopFilter = "";
                    BuildPage();
                })));
        }

        private static bool Matches(AssetRecord asset, string text)
        {
            var item = AssetStore.Item(asset.boothId);
            return asset.name.IndexOf(text, StringComparison.CurrentCultureIgnoreCase) >= 0 ||
                   asset.boothName.IndexOf(text, StringComparison.CurrentCultureIgnoreCase) >= 0 ||
                   item != null && (item.shop.IndexOf(text, StringComparison.CurrentCultureIgnoreCase) >= 0 ||
                                    item.tags.Any(t => t.IndexOf(text, StringComparison.CurrentCultureIgnoreCase) >= 0));
        }

        // ---- Gallery: rows of two cards ----

        private float RowHeight => cardWidth + CardBody + RowGap;

        // Two cards share the row's width; the image stays square, so the row height follows the width.
        private void Resize()
        {
            if (gallery == null) return;
            var viewport = gallery.Q<ScrollView>()?.contentViewport;
            var width = (viewport != null && viewport.layout.width > 0 ? viewport.layout.width : gallery.contentRect.width - ScrollBarRoom) - 1;
            if (width <= 0) return;
            var card = Mathf.Max(60, Mathf.Floor((width - RowGap) / 2));
            if (Mathf.Abs(card - cardWidth) < 1) return;
            cardWidth = card;
            gallery.fixedItemHeight = RowHeight;
            gallery.Rebuild();
        }

        private VisualElement MakeRow()
        {
            var row = new VisualElement();
            row.AddToClassList("am-row");
            row.Add(MakeCard("am-card--left"));
            row.Add(MakeCard("am-card--right"));
            return row;
        }

        private VisualElement MakeCard(string side)
        {
            var card = new VisualElement();
            card.AddToClassList("am-card");
            card.AddToClassList(side);
            var image = new VisualElement { name = "image" };
            image.AddToClassList("am-card-image");
            var placeholder = new Label { name = "placeholder" };
            placeholder.AddToClassList("am-card-placeholder");
            image.Add(placeholder);
            card.Add(image);
            var body = new VisualElement();
            body.AddToClassList("am-card-body");
            var name = new Label { name = "name" };
            name.AddToClassList("am-card-name");
            var shop = new Label { name = "shop" };
            shop.AddToClassList("am-card-shop");
            var chips = new VisualElement { name = "chips" };
            chips.AddToClassList("am-chips");
            body.Add(name);
            body.Add(shop);
            body.Add(chips);
            card.Add(body);
            card.RegisterCallback<ClickEvent>(e =>
            {
                if (!(card.userData is AssetRecord asset)) return;
                gallery?.Focus();
                if (e.clickCount == 2) RevealFolder(asset);
                else SelectAsset(asset);
            });
            return card;
        }

        private void BindRow(VisualElement row, int index)
        {
            BindCard(row[0], index * 2 < shown.Count ? shown[index * 2] : null);
            BindCard(row[1], index * 2 + 1 < shown.Count ? shown[index * 2 + 1] : null);
        }

        private void BindCard(VisualElement card, AssetRecord asset)
        {
            card.userData = asset;
            card.EnableInClassList("am-card--blank", asset == null);
            if (asset == null) return;
            card.EnableInClassList("am-card--on", asset.id == selectedAsset);
            card.tooltip = asset.name;
            var image = card.Q("image");
            image.style.height = cardWidth;
            var texture = AssetTexture(asset, RefreshImagesSoon) as Texture2D;
            image.style.backgroundImage = texture ? new StyleBackground(texture) : new StyleBackground(StyleKeyword.None);
            var placeholder = card.Q<Label>("placeholder");
            placeholder.text = texture ? "" : KindName(asset.kind);
            card.Q<Label>("name").text = asset.name;
            var shop = ShopOf(asset);
            card.Q<Label>("shop").text = shop.Length > 0 ? shop : asset.boothId > 0 ? $"상품 {asset.boothId}" : "샵 모름";
            var chips = card.Q("chips");
            chips.Clear();
            chips.Add(UiChip(KindName(asset.kind), ""));
            chips.Add(asset.boothId > 0 ? UiChip("Booth", "am-chip--ok") : UiChip("미연결", "am-chip--warn"));
        }

        private bool imagesQueued;

        // A preview still loading asks again a little later (AssetPreview has no notice of its own).
        private void RefreshImagesSoon()
        {
            if (imagesQueued || root == null) return;
            imagesQueued = true;
            root.schedule.Execute(() =>
            {
                imagesQueued = false;
                gallery?.RefreshItems();
            }).StartingIn(300);
        }

        private static Label UiChip(string text, string kind)
        {
            var chip = new Label(text);
            chip.AddToClassList("am-chip");
            if (kind.Length > 0) chip.AddToClassList(kind);
            return chip;
        }

        private void OnGalleryKey(KeyDownEvent e)
        {
            int step;
            switch (e.keyCode)
            {
                case KeyCode.LeftArrow: step = -1; break;
                case KeyCode.RightArrow: step = 1; break;
                case KeyCode.UpArrow: step = -2; break;
                case KeyCode.DownArrow: step = 2; break;
                default: return;
            }
            if (shown.Count == 0) return;
            var index = shown.FindIndex(a => a.id == selectedAsset);
            index = index < 0 ? 0 : Mathf.Clamp(index + step, 0, shown.Count - 1);
            SelectAsset(shown[index]);
            gallery.ScrollToItem(index / 2);
            e.StopImmediatePropagation();
            e.PreventDefault();
        }

        private void SelectAsset(AssetRecord asset)
        {
            if (selectedAsset == asset.id) return;
            selectedAsset = asset.id;
            gallery?.RefreshItems();
            BuildDetail();
        }

        // Double click: the asset's folder in the Project window (its panel shows in the Inspector).
        private static void RevealFolder(AssetRecord asset)
        {
            var folder = AssetFolders.ExistingFolders(asset).FirstOrDefault();
            if (folder == null) return;
            var target = AssetDatabase.LoadAssetAtPath<DefaultAsset>(folder);
            Selection.activeObject = target;
            EditorGUIUtility.PingObject(target);
        }

        // ---- Detail ----

        private void BuildDetail()
        {
            if (detail == null) return;
            var scroll = (ScrollView)detail;
            var offset = scroll.scrollOffset;
            detail.Clear();
            var content = new VisualElement();
            content.AddToClassList("am-detail-content");
            detail.Add(content);
            var asset = SelectedAsset;
            if (asset == null)
            {
                content.Add(UiEmpty("에셋을 골라 주세요", "왼쪽 갤러리에서 카드를 누르면 Booth 연결, 폴더, 조립을 여기서 볼 수 있어요."));
                return;
            }

            var image = new VisualElement();
            image.AddToClassList("am-detail-image");
            image.style.height = 256;
            var texture = AssetTexture(asset, RefreshDetailSoon) as Texture2D;
            if (texture) image.style.backgroundImage = new StyleBackground(texture);
            else image.Add(UiText(KindName(asset.kind), "am-card-placeholder"));
            content.Add(image);
            var title = UiText(asset.name, "am-detail-title");
            title.tooltip = asset.name;
            content.Add(title);
            var (bytes, files) = AssetFolders.Size(asset);
            var shop = ShopOf(asset);
            content.Add(UiText((shop.Length > 0 ? shop + " · " : "") + $"{AssetFolders.FormatSize(bytes)} · 파일 {files}개" +
                             (asset.package.Length > 0 ? $" · {asset.package}" : ""), "am-detail-meta"));
            var chips = new VisualElement();
            chips.AddToClassList("am-chips");
            chips.Add(UiChip(KindName(asset.kind), ""));
            chips.Add(asset.boothId > 0 ? UiChip("Booth", "am-chip--ok") : UiChip("미연결", "am-chip--warn"));
            content.Add(chips);

            // Name and kind.
            var nameField = new TextField { value = asset.name, isDelayed = true, tooltip = "에셋 이름. Enter로 바꿔요." };
            nameField.AddToClassList("am-field");
            nameField.RegisterValueChangedCallback(e =>
            {
                if (string.IsNullOrWhiteSpace(e.newValue) || e.newValue.Trim() == asset.name) return;
                asset.name = e.newValue.Trim();
                AssetStore.SaveProject();
            });
            content.Add(nameField);
            var kindField = new DropdownField(KindNames.ToList(), (int)asset.kind) { tooltip = "에셋 종류" };
            kindField.AddToClassList("am-field");
            kindField.RegisterValueChangedCallback(_ =>
            {
                asset.kind = (AssetKind)kindField.index;
                AssetStore.SaveProject();
            });
            content.Add(kindField);

            var actions = new VisualElement();
            actions.AddToClassList("am-actions");
            if (asset.boothId > 0) actions.Add(UiButton("Booth 페이지", "", () => Application.OpenURL(BoothUrl(asset.boothId))));
            actions.Add(UiButton("폴더 보기", "am-button--quiet", () => RevealFolder(asset)));
            content.Add(actions);

            content.Add(BoothSection(asset));
            content.Add(FolderSection(asset));
            content.Add(AssemblySection(asset));

            var footer = new VisualElement();
            footer.AddToClassList("am-actions");
            footer.style.marginTop = 14;
            footer.Add(UiButton("에셋 목록에서 빼기", "am-button--danger", () =>
            {
                if (!EditorUtility.DisplayDialog("에셋 목록에서 빼기",
                        $"‘{asset.name}’을(를) 에셋 목록에서 뺄까요?\n파일은 지우지 않고, Booth 연결과 폴더 지정만 사라져요.", "빼기", "취소")) return;
                AssetFolders.Delete(asset);
                selectedAsset = null;
                RefreshAssetsPage();
            }, "에셋 지정만 풀어요. 파일은 지우지 않아요."));
            content.Add(footer);
            scroll.scrollOffset = offset;
        }

        private bool detailQueued;

        private void RefreshDetailSoon()
        {
            if (detailQueued || root == null) return;
            detailQueued = true;
            root.schedule.Execute(() =>
            {
                detailQueued = false;
                BuildDetail();
            }).StartingIn(300);
        }

        private VisualElement BoothSection(AssetRecord asset)
        {
            var section = UiSection("Booth");
            if (asset.boothId > 0)
            {
                var item = AssetStore.Item(asset.boothId);
                section.Add(UiText(item?.name.Length > 0 ? item.name : asset.boothName.Length > 0 ? asset.boothName : $"상품 {asset.boothId}", "am-candidate-name"));
                if (item == null || item.name.Length == 0) section.Add(UiText("Booth에서 상품 정보를 받지 못해 번호로만 연결했어요.", "am-text"));
                var row = new VisualElement();
                row.AddToClassList("am-actions");
                row.Add(UiButton("다른 상품으로 바꾸기", "am-button--quiet", () => BoothLinker.Unlink(asset), "연결을 풀고 후보를 다시 보여 줘요."));
                section.Add(row);
                return section;
            }
            var cache = AssetStore.SearchFor(asset.id);
            var searching = cache == null || !cache.done || BoothLinker.IsSearching(asset.id);
            if ((cache == null || !cache.done) && !BoothLinker.IsSearching(asset.id))
                BoothLinker.SearchSoon(asset.id, asset.name, AssetFolders.ExistingFolders(asset), asset.package);
            if (boothQueryFor != asset.id)
            {
                boothQueryFor = asset.id;
                boothQuery = cache?.query ?? BoothClient.QueryFrom(asset.name);
                boothAddress = "";
                boothMessage = null;
            }
            section.Add(UiText("아직 Booth 상품과 연결하지 않았어요. 맞는 후보의 ‘연결’을 누르세요.", "am-text"));
            if (searching) section.Add(UiNote("Booth에서 찾고 있어요…", false));
            else if (cache.error.Length > 0) section.Add(UiNote("검색하지 못했어요: " + cache.error, true));
            else if (cache.results.Count == 0) section.Add(UiNote($"‘{cache.query}’(으)로 찾은 상품이 없어요. 검색어를 바꾸거나 주소를 넣으세요.", false));
            if (cache != null)
                foreach (var candidate in cache.results.Take(6))
                {
                    var row = new VisualElement();
                    row.AddToClassList("am-candidate");
                    var thumb = new VisualElement();
                    thumb.AddToClassList("am-candidate-image");
                    var picture = AssetStore.Thumbnail(candidate.thumbnail, null);
                    if (picture) thumb.style.backgroundImage = new StyleBackground(picture);
                    row.Add(thumb);
                    var text = new VisualElement();
                    text.AddToClassList("am-candidate-text");
                    text.Add(UiText(candidate.name, "am-candidate-name"));
                    var source = candidate.id == cache.readmeItem ? "설명서 링크 · "
                        : AssetStore.HintFor(asset.package) == candidate.id || AssetStore.HintFor(asset.name) == candidate.id ? "이전 연결 · " : "";
                    text.Add(UiText(source + candidate.shop, "am-candidate-shop"));
                    row.Add(text);
                    var chosen = candidate;
                    row.Add(UiButton("연결", "am-button--primary", () => BoothLinker.Link(asset, chosen), $"‘{chosen.name}’에 연결해요."));
                    row.Add(UiButton("보기", "am-button--quiet", () => Application.OpenURL(chosen.Url), "브라우저에서 상품 페이지를 열어 확인해요."));
                    section.Add(row);
                }
            if (cache != null && cache.results.Count > 6) section.Add(UiText($"후보 {cache.results.Count - 6}개가 더 있어요. 검색어를 좁혀 보세요.", "am-text"));

            var query = new TextField("직접 검색") { value = boothQuery };
            query.AddToClassList("am-field");
            query.RegisterValueChangedCallback(e => boothQuery = e.newValue);
            section.Add(query);
            var searchRow = new VisualElement();
            searchRow.AddToClassList("am-actions");
            searchRow.Add(UiButton("검색", "", () =>
            {
                if (string.IsNullOrWhiteSpace(boothQuery) || BoothLinker.IsSearching(asset.id)) return;
                BoothLinker.Search(asset.id, boothQuery.Trim(), AssetFolders.ExistingFolders(asset), new[] { asset.package, asset.name }, false);
                BuildDetail();
            }, "검색어로 Booth를 다시 찾아요."));
            section.Add(searchRow);
            var address = new TextField("상품 주소") { value = boothAddress, tooltip = "booth.pm 상품 주소 또는 상품 번호" };
            address.AddToClassList("am-field");
            address.RegisterValueChangedCallback(e => boothAddress = e.newValue);
            section.Add(address);
            var linkRow = new VisualElement();
            linkRow.AddToClassList("am-actions");
            linkRow.Add(UiButton("주소로 연결", "", () =>
            {
                var id = BoothClient.ParseItemId(boothAddress);
                if (id <= 0)
                {
                    boothMessage = "Booth 상품 주소나 번호를 넣으세요.";
                    boothMessageWarn = true;
                    BuildDetail();
                    return;
                }
                boothMessage = "상품 정보를 받고 있어요…";
                boothMessageWarn = false;
                BoothLinker.LinkById(asset, id, error =>
                {
                    boothMessage = error;
                    boothMessageWarn = true;
                    BuildDetail();
                });
                BuildDetail();
            }));
            section.Add(linkRow);
            if (!string.IsNullOrEmpty(boothMessage)) section.Add(UiNote(boothMessage, boothMessageWarn));
            return section;
        }

        private string folderMessage;

        private VisualElement FolderSection(AssetRecord asset)
        {
            var section = UiSection("폴더");
            foreach (var guid in asset.folders.Concat(asset.sharedFolders).ToList())
            {
                var path = AssetDatabase.GUIDToAssetPath(guid);
                var row = new VisualElement();
                row.AddToClassList("am-folder");
                var text = new VisualElement();
                text.AddToClassList("am-folder-text");
                var exists = path.Length > 0 && AssetDatabase.IsValidFolder(path);
                text.Add(UiText(exists ? Path.GetFileName(path) : "⚠ 폴더를 찾지 못했어요", "am-candidate-name"));
                var where = UiText(exists ? path : "지웠거나 프로젝트 밖으로 옮겼어요", "am-folder-path");
                where.tooltip = path;
                text.Add(where);
                row.Add(text);
                if (asset.sharedFolders.Contains(guid)) row.Add(UiChip("공용", ""));
                if (exists) row.Add(UiButton("보기", "am-button--quiet", () => EditorGUIUtility.PingObject(AssetDatabase.LoadAssetAtPath<DefaultAsset>(path))));
                var id = guid;
                row.Add(UiButton("빼기", "am-button--quiet", () => AssetFolders.RemoveFolder(asset, id), "이 폴더를 에셋에서 빼요. 파일은 지우지 않아요."));
                section.Add(row);
            }
            if (asset.folders.Count == 0) section.Add(UiNote("이 에셋의 폴더가 없어요. Project 창에서 폴더를 고른 뒤 ‘고른 폴더 넣기’를 누르세요.", true));
            var selected = Selection.assetGUIDs.Select(AssetDatabase.GUIDToAssetPath).Where(AssetDatabase.IsValidFolder).ToList();
            var add = new VisualElement();
            add.AddToClassList("am-actions");
            add.style.marginTop = 8;
            var addOwn = UiButton($"고른 폴더 넣기 ({selected.Count})", "", () => AddFolders(asset, selected, false), "Project 창에서 고른 폴더를 이 에셋만 쓰는 폴더로 넣어요.");
            var addShared = UiButton("공용 폴더로 넣기", "am-button--quiet", () => AddFolders(asset, selected, true), "같은 샵의 Common 폴더처럼 여러 에셋이 함께 쓰는 폴더로 넣어요.");
            addOwn.SetEnabled(selected.Count > 0);
            addShared.SetEnabled(selected.Count > 0);
            add.Add(addOwn);
            add.Add(addShared);
            section.Add(add);
            if (selected.Count == 0) section.Add(UiText("Project 창에서 폴더를 고르면 넣을 수 있어요.", "am-text"));
            if (!string.IsNullOrEmpty(folderMessage)) section.Add(UiNote(folderMessage, true));
            return section;
        }

        private void AddFolders(AssetRecord asset, List<string> paths, bool shared)
        {
            var problems = new List<string>();
            foreach (var path in paths)
            {
                try { AssetFolders.AddFolder(asset, path, shared); }
                catch (InvalidOperationException e) { problems.Add($"{Path.GetFileName(path)}: {e.Message}"); }
            }
            folderMessage = problems.Count > 0 ? string.Join("\n", problems) : null;
            BuildDetail();
        }

        // The assembly form is shared with the Inspector panel (IMGUI); here it sits in a section of the page.
        private VisualElement AssemblySection(AssetRecord asset)
        {
            var section = UiSection("조립");
            IMGUIContainer form = null;
            // A choice can add or remove fields: the container measures again, not only repaints.
            void Relayout()
            {
                form?.MarkDirtyLayout();
                Repaint();
            }
            form = new IMGUIContainer(() =>
            {
                var current = SelectedAsset;
                if (current != null) assembly.Draw(current, null, true, Relayout);
            });
            form.AddToClassList("am-imgui-section");
            section.Add(form);
            return section;
        }

        // ---- Small builders ----

        private static VisualElement UiSection(string title)
        {
            var section = new VisualElement();
            section.AddToClassList("am-section");
            section.Add(UiText(title, "am-section-title"));
            return section;
        }

        private static Label UiText(string text, string kind)
        {
            var label = new Label(text);
            label.AddToClassList(kind);
            return label;
        }

        private static VisualElement UiNote(string text, bool warn)
        {
            var note = UiText(text, "am-note");
            note.EnableInClassList("am-note--warn", warn);
            return note;
        }

        private static Button UiButton(string text, string kind, Action click, string tooltip = null)
        {
            var button = new Button(click) { text = text, tooltip = tooltip };
            button.AddToClassList("am-button");
            if (kind.Length > 0) button.AddToClassList(kind);
            return button;
        }

        private static T Tip<T>(T element, string tooltip) where T : VisualElement
        {
            element.tooltip = tooltip;
            return element;
        }

        private static VisualElement Spacer()
        {
            var spacer = new VisualElement();
            spacer.AddToClassList("am-grow");
            return spacer;
        }

        private static VisualElement FolderIcon()
        {
            var icon = new VisualElement();
            icon.AddToClassList("am-icon");
            icon.style.backgroundImage = new StyleBackground(EditorGUIUtility.IconContent("Folder Icon").image as Texture2D);
            return icon;
        }

        private static VisualElement UiEmpty(string title, string body, params (string Label, Action Click)[] actions)
        {
            var empty = new VisualElement();
            empty.AddToClassList("am-empty");
            empty.Add(UiText(title, "am-empty-title"));
            empty.Add(UiText(body, "am-empty-body"));
            var row = new VisualElement();
            row.AddToClassList("am-actions");
            foreach (var (label, click) in actions) row.Add(UiButton(label, "", click));
            empty.Add(row);
            return empty;
        }
    }
}
