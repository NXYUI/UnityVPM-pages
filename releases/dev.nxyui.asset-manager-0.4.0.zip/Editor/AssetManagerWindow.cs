using System;
using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;

namespace NXYUI.AssetManager
{
    // Window shell, built with UI Toolkit: the header with the tabs, and the page of the chosen tab (에셋: Assets.cs,
    // 가져오기: Import.cs, 폴더 지정: Folders.cs). Only the assembly form in the detail pane is IMGUI (it is shared with the
    // Inspector panel). Look: Editor/AssetManager.uss, design-system/unityvpm/pages/asset-manager.md.
    internal sealed partial class AssetManagerWindow : EditorWindow
    {
        // Every NXYUI package puts its windows under the top-level "NXYUI" menu (checked by tools/test_build_repo.py).
        private const string MenuPath = "NXYUI/Asset Manager";
        private const string StylePath = "Packages/dev.nxyui.asset-manager/Editor/AssetManager.uss";

        [SerializeField] private int tab;

        private VisualElement root, page;
        private Button[] tabs;
        private bool darkSkin;
        private IVisualElementScheduledItem refreshItem, queueItem;

        [MenuItem(MenuPath)]
        private static void OpenFromMenu() => Open();

        internal static AssetManagerWindow Open()
        {
            // Docked next to the Inspector when it is open, like the other panels the user works beside.
            var inspector = typeof(Editor).Assembly.GetType("UnityEditor.InspectorWindow");
            var window = inspector != null ? GetWindow<AssetManagerWindow>("Asset Manager", true, inspector) : GetWindow<AssetManagerWindow>("Asset Manager");
            window.minSize = new Vector2(740, 420);
            window.Show();
            return window;
        }

        internal static void ShowAsset(AssetRecord asset)
        {
            var window = Open();
            window.selectedAsset = asset?.id;
            window.SetTab(0);
            window.RevealSelected();
        }

        internal static void ShowFolders() => Open().SetTab(2);

        private void OnEnable()
        {
            AssetStore.Changed += Refresh;
            AssetStore.ThumbnailsChanged += RefreshImages;
            BoothLinker.Updated += OnBoothUpdated;
            ImportQueue.Changed += OnQueueChanged;
            EditorApplication.projectChanged += OnProjectChanged;
            EditorApplication.hierarchyChanged += Repaint;
            EditorApplication.update += TickImportTab;
            EditorApplication.update += WatchSkin;
            Selection.selectionChanged += OnSelectionChanged;
        }

        private void OnDisable()
        {
            AssetStore.Changed -= Refresh;
            AssetStore.ThumbnailsChanged -= RefreshImages;
            BoothLinker.Updated -= OnBoothUpdated;
            ImportQueue.Changed -= OnQueueChanged;
            EditorApplication.projectChanged -= OnProjectChanged;
            EditorApplication.hierarchyChanged -= Repaint;
            EditorApplication.update -= TickImportTab;
            EditorApplication.update -= WatchSkin;
            Selection.selectionChanged -= OnSelectionChanged;
        }

        private void OnProjectChanged()
        {
            AssetFolders.ForgetSizes();
            unassignedCache = null;
            Refresh();
        }

        private void CreateGUI()
        {
            root = rootVisualElement;
            root.Clear();
            root.AddToClassList("am-root");
            var style = AssetDatabase.LoadAssetAtPath<StyleSheet>(StylePath);
            if (style) root.styleSheets.Add(style);
            else Debug.LogWarning($"[Asset Manager] {StylePath}을(를) 찾지 못해 기본 모양으로 보여요. 패키지를 다시 설치해 주세요.");
            // Docked, the window can be narrower than its minimum: the sidebar folds away first, the gallery keeps two columns.
            root.RegisterCallback<GeometryChangedEvent>(e => root.EnableInClassList("am-narrow", e.newRect.width < 760));
            darkSkin = EditorGUIUtility.isProSkin;
            ApplySkin();

            var header = new VisualElement();
            header.AddToClassList("am-header");
            var brand = new VisualElement();
            brand.AddToClassList("am-brand");
            var icon = new VisualElement();
            icon.AddToClassList("am-brand-icon");
            icon.style.backgroundImage = new StyleBackground(EditorGUIUtility.IconContent("d_Prefab Icon").image as Texture2D);
            brand.Add(icon);
            var title = new Label("Asset Manager");
            title.AddToClassList("am-brand-title");
            brand.Add(title);
            header.Add(brand);
            tabs = new Button[3];
            for (var i = 0; i < tabs.Length; i++)
            {
                var index = i;
                tabs[i] = new Button(() => SetTab(index));
                tabs[i].AddToClassList("am-tab");
                header.Add(tabs[i]);
            }
            root.Add(header);

            page = new VisualElement();
            page.AddToClassList("am-page");
            root.Add(page);
            BuildPage();
        }

        // The editor skin can change while the window is open: the tokens follow it.
        private void WatchSkin()
        {
            if (root == null || darkSkin == EditorGUIUtility.isProSkin) return;
            darkSkin = EditorGUIUtility.isProSkin;
            ApplySkin();
        }

        private void ApplySkin()
        {
            root.EnableInClassList("am-dark", darkSkin);
            root.EnableInClassList("am-light", !darkSkin);
        }

        private void SetTab(int index)
        {
            tab = Mathf.Clamp(index, 0, 2);
            if (page != null) BuildPage();
        }

        private void BuildPage()
        {
            RememberImportScrolls();
            RememberFoldersScroll();
            page.Clear();
            // Only the shown page has elements; the others' refreshes see null and wait for their page to be built.
            gallery = null;
            detail = null;
            sidebar = null;
            scanList = null;
            readButton = null;
            foldersBody = null;
            joinBar = null;
            UpdateTabs();
            switch (tab)
            {
                case 0:
                    BuildAssetsPage(page);
                    break;
                case 1:
                    BuildImportPage(page);
                    break;
                default:
                    BuildFoldersPage(page);
                    break;
            }
        }

        private void UpdateTabs()
        {
            if (tabs == null) return;
            var proposals = AssetStore.State.proposals.Count;
            tabs[0].text = $"에셋 {AssetStore.Project.assets.Count}";
            tabs[1].text = ImportQueue.Running ? "가져오기 · 진행 중" : "가져오기";
            tabs[2].text = proposals > 0 ? $"폴더 지정 · 제안 {proposals}" : "폴더 지정";
            for (var i = 0; i < tabs.Length; i++) tabs[i].EnableInClassList("am-tab--on", i == tab);
        }

        // Asset data changed (a link, a rename, a new asset): the page is drawn again once, after the notices settle.
        private void Refresh()
        {
            if (root == null) return;
            refreshItem?.Pause();
            refreshItem = root.schedule.Execute(() =>
            {
                UpdateTabs();
                if (tab == 0) RefreshAssetsPage();
                else if (tab == 1) RefreshImportPage();
                else ScheduleFolders();
            });
        }

        // The queue reports each step of an import: the tab label follows, and the import page when it is shown.
        private void OnQueueChanged()
        {
            if (root == null) return;
            queueItem?.Pause();
            queueItem = root.schedule.Execute(() =>
            {
                UpdateTabs();
                if (tab == 1) RefreshImportPage();
            });
        }

        // A rebuilt part keeps the keyboard focus at the same place (the n-th control that takes focus), so a background
        // update does not throw a keyboard user out of the list.
        private int FocusSlot(VisualElement area)
        {
            if (area == null || !(root?.panel?.focusController?.focusedElement is VisualElement focused) || !area.Contains(focused)) return -1;
            return Focusables(area).IndexOf(focused);
        }

        private static void RestoreFocus(VisualElement area, int slot)
        {
            if (slot < 0) return;
            var list = Focusables(area);
            if (list.Count > 0) list[Mathf.Min(slot, list.Count - 1)].Focus();
        }

        private static System.Collections.Generic.List<VisualElement> Focusables(VisualElement area) =>
            area.Query<VisualElement>().Where(v => v.focusable && v.enabledInHierarchy && v.resolvedStyle.display != DisplayStyle.None).ToList();

        // A page built again shows its list where the user left it, once the list knows its size.
        private static void KeepScroll(ScrollView scroll, Vector2 offset)
        {
            if (scroll == null || offset == Vector2.zero) return;
            void Apply(GeometryChangedEvent e)
            {
                scroll.contentContainer.UnregisterCallback<GeometryChangedEvent>(Apply);
                scroll.scrollOffset = offset;
            }
            scroll.contentContainer.RegisterCallback<GeometryChangedEvent>(Apply);
        }

        // Booth results: the detail of the chosen asset, or the proposals' "Booth 후보" line.
        private void OnBoothUpdated()
        {
            if (tab == 0) ScheduleDetail();
            else if (tab == 2) ScheduleFolders();
        }
    }
}
