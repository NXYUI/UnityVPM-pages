#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Linq;
using nadena.dev.ndmf;
using UnityEditor;
using UnityEngine;
using VRC.SDK3.Avatars.Components;
using VRC.SDK3.Avatars.ScriptableObjects;
using Control = VRC.SDK3.Avatars.ScriptableObjects.VRCExpressionsMenu.Control;
using Object = UnityEngine.Object;

[assembly: ExportsPlugin(typeof(AvatarMenuTools.FavoriteMenuPlugin))]

namespace AvatarMenuTools
{
    public sealed class FavoriteMenuPlugin : Plugin<FavoriteMenuPlugin>
    {
        public override string QualifiedName => "local.avatar-menu-favorites";
        public override string DisplayName => "Avatar Menu Favorites";

        protected override void Configure()
        {
            InPhase(BuildPhase.Resolving).Run("Read avatar menu settings", FavoriteMenuBuilder.ReadSettings);
            InPhase(BuildPhase.PlatformFinish)
                .AfterPlugin("nadena.dev.modular-avatar")
                .Run("Apply menu names and favorites", FavoriteMenuBuilder.Build);
        }
    }

    internal static class FavoriteMenuBuilder
    {
        private const string MoreIconPath = "Packages/nadena.dev.modular-avatar/Runtime/Icons/Icon_More_A.png";

        private sealed class State
        {
            internal string PageLabel;
            internal FavoriteMenuGroup[] Menus;
            internal MenuNameOverride[] Overrides;
        }

        internal sealed class Scan : IDisposable
        {
            internal readonly GameObject Avatar;
            internal FavoriteMenuKey[] Menu;
            internal string Result;
            internal bool HasWarnings;
            internal Scan(GameObject avatar) { Avatar = avatar; activeScan = this; }
            public void Dispose() { if (activeScan == this) activeScan = null; }
        }

        private static Scan activeScan;

        internal static void ReadSettings(BuildContext context)
        {
            var c = context.AvatarRootObject.GetComponent<AvatarMenuFavorites>();
            if (!c || !c.enabled) return;
            var state = context.GetState<State>();
            state.Menus = new[] { c.GetMenu(0) }.Concat(c.additionalMenus ?? Enumerable.Empty<FavoriteMenuGroup>())
                .Where(menu => (menu?.entries?.Count ?? 0) > 0).ToArray();
            state.Overrides = c.nameOverrides?.ToArray() ?? Array.Empty<MenuNameOverride>();
            state.PageLabel = string.IsNullOrWhiteSpace(c.nextPageLabel) ? null : c.nextPageLabel.Trim();
        }

        internal static void Build(BuildContext context)
        {
            var avatar = context.AvatarRootObject;
            var descriptor = avatar.GetComponent<VRCAvatarDescriptor>();
            if (!descriptor) return;
            var scan = activeScan?.Avatar == avatar ? activeScan : null;
            var config = context.GetState<State>();
            bool configured = config.Menus != null &&
                (config.Menus.Length > 0 || config.Overrides.Length > 0 || config.PageLabel != null);
            if (!configured && scan == null) return;
            var root = descriptor.expressionsMenu;
            var moreIcon = AssetDatabase.LoadAssetAtPath<Texture2D>(MoreIconPath);

            bool IsPage(VRCExpressionsMenu menu, Control c) =>
                menu.controls?.Count == VRCExpressionsMenu.MAX_CONTROLS &&
                c != null && c == menu.controls.LastOrDefault() && c.type == Control.ControlType.SubMenu &&
                c.subMenu && c.name == "More" && string.IsNullOrEmpty(c.parameter?.name) &&
                (moreIcon ? c.icon == moreIcon : !c.icon);

            var items = new Dictionary<FavoriteMenuKey, Control>();
            var orderedKeys = new List<FavoriteMenuKey>();
            var groups = new Dictionary<Control, int>();
            void Walk(VRCExpressionsMenu menu, string[] path, HashSet<VRCExpressionsMenu> active, int depth)
            {
                if (!menu || menu.controls == null || depth > 64 || !active.Add(menu)) return;
                foreach (var c in menu.controls)
                {
                    if (c == null) continue;
                    if (IsPage(menu, c))
                    {
                        Walk(c.subMenu, path, active, depth);
                        continue;
                    }
                    var next = path.Concat(new[] { c.name ?? "" }).ToArray();
                    if (!groups.TryGetValue(c, out int group)) groups.Add(c, group = groups.Count + 1);
                    var key = new FavoriteMenuKey
                    {
                        path = next, type = c.type, value = c.value, sharedControl = group,
                        parameter = c.parameter?.name ?? "",
                        subParameters = (c.subParameters ?? Array.Empty<Control.Parameter>())
                            .Select(p => p?.name ?? "").ToArray(),
                    };
                    items.Add(key, c);
                    orderedKeys.Add(key);
                    if (c.type == Control.ControlType.SubMenu) Walk(c.subMenu, next, active, depth + 1);
                }
                active.Remove(menu);
            }
            Walk(root, Array.Empty<string>(), new HashSet<VRCExpressionsMenu>(), 0);
            var keys = orderedKeys.ToArray();
            if (scan != null) scan.Menu = keys;
            if (!root || !configured) return;

            var warnings = new List<string>();
            Control Match(FavoriteMenuKey requested)
            {
                var key = FavoriteMenuKey.Resolve(keys, requested);
                return key == null ? null : items[key];
            }

            var names = new Dictionary<Control, string>();
            var missingNames = new List<string>();
            foreach (var rule in config.Overrides)
            {
                if (rule?.source == null || string.IsNullOrWhiteSpace(rule.label)) continue;
                var control = Match(rule.source);
                var label = rule.label.Trim();
                if (control == null || (names.TryGetValue(control, out var prior) && prior != label))
                    missingNames.Add(rule.source.DisplayPath);
                else names[control] = label;
            }
            if (missingNames.Count > 0) warnings.Add("이름을 바꾸지 못한 항목: " + string.Join(", ", missingNames));

            string NameOf(Control c) => names.TryGetValue(c, out var label) ? label : c.name;

            var created = new List<VRCExpressionsMenu>();
            var copies = new Dictionary<VRCExpressionsMenu, VRCExpressionsMenu>();
            VRCExpressionsMenu Clone(VRCExpressionsMenu original)
            {
                if (!original) return null;
                if (copies.TryGetValue(original, out var existing)) return existing;
                var clone = Object.Instantiate(original);
                clone.name = original.name;
                copies.Add(original, clone);
                created.Add(clone);
                clone.controls = (original.controls ?? new List<Control>()).Where(c => c != null)
                    .Select(c => Copy(c, config.PageLabel != null && IsPage(original, c)
                        ? config.PageLabel : NameOf(c), Clone)).ToList();
                return clone;
            }

            string pageLabel = config.PageLabel ?? "More";
            VRCExpressionsMenu Paginate(VRCExpressionsMenu page)
            {
                int keep = VRCExpressionsMenu.MAX_CONTROLS - 1;
                while (page.controls.Count > VRCExpressionsMenu.MAX_CONTROLS)
                {
                    var next = NewMenu(page.name + " (More)", created);
                    next.controls.AddRange(page.controls.Skip(keep));
                    page.controls.RemoveRange(keep, page.controls.Count - keep);
                    var link = Submenu(pageLabel, next);
                    link.icon = moreIcon;
                    page.controls.Add(link);
                    page = next;
                }
                return page;
            }

            int menuCount = 0, favoriteCount = 0, folderCount = 0;
            var skipped = new List<string>();
            var tails = new Dictionary<VRCExpressionsMenu, VRCExpressionsMenu>();
            var installedNames = new Dictionary<VRCExpressionsMenu, HashSet<string>>();
            foreach (var menu in config.Menus)
            {
                string menuName = menu.DisplayName;
                var destination = menu.useRoot ? root : Match(menu.destination)?.subMenu;
                if (!destination)
                {
                    warnings.Add($"‘{menuName}’ 메뉴의 설치 위치를 찾을 수 없습니다. 설정 창에서 위치를 다시 선택해 주세요.");
                    continue;
                }
                var end = destination;
                var seen = new HashSet<VRCExpressionsMenu>();
                bool duplicate = false;
                while (seen.Add(end))
                {
                    var last = end.controls?.LastOrDefault();
                    if (end.controls != null && end.controls.Any(c => c != null && !IsPage(end, c) &&
                        c.type == Control.ControlType.SubMenu && NameOf(c) == menuName)) duplicate = true;
                    if (!IsPage(end, last) || seen.Contains(last.subMenu)) break;
                    end = last.subMenu;
                }
                if (duplicate || (installedNames.TryGetValue(end, out var siblings) && siblings.Contains(menuName)))
                {
                    warnings.Add($"같은 위치에 ‘{menuName}’ 메뉴가 이미 있습니다. 메뉴 이름을 바꿔 주세요.");
                    continue;
                }

                var destinationCopy = Clone(destination);
                var endCopy = Clone(end);
                var target = tails.TryGetValue(end, out var tail) ? tail : endCopy;
                var children = menu.entries.Where(x => x != null).ToLookup(x => x.Parent);
                var madeFolders = new HashSet<string>();
                List<Control> MakeChildren(string parent, int depth)
                {
                    var controls = new List<Control>();
                    foreach (var entry in children[parent])
                    {
                        if (entry.IsFolder)
                        {
                            string label = string.IsNullOrWhiteSpace(entry.label) ? "새 폴더" : entry.label.Trim();
                            if (depth >= 64 || !madeFolders.Add(entry.folderId)) { skipped.Add($"{menuName} / {label}"); continue; }
                            var sub = NewMenu(label, created);
                            sub.controls = MakeChildren(entry.folderId, depth + 1);
                            Paginate(sub);
                            controls.Add(Submenu(label, sub));
                            folderCount++;
                            continue;
                        }
                        if (entry.source?.path == null || entry.source.path.Length == 0) continue;
                        var control = Match(entry.source);
                        // Check the build graph, including the menus already installed at other destinations.
                        if (control == null || (control.type == Control.ControlType.SubMenu &&
                            (!control.subMenu || Reaches(Clone(control.subMenu), destinationCopy, target, new HashSet<VRCExpressionsMenu>()))))
                        {
                            skipped.Add($"{menuName} / {entry.source.DisplayPath}");
                            continue;
                        }
                        controls.Add(Copy(control, string.IsNullOrWhiteSpace(entry.label) ? NameOf(control) : entry.label.Trim(), Clone));
                        favoriteCount++;
                    }
                    return controls;
                }

                var chosen = MakeChildren("", 0);
                if (chosen.Count == 0) continue;
                var favorites = NewMenu(menuName, created);
                favorites.controls = chosen;
                Paginate(favorites);
                target.controls.Add(Submenu(menuName, favorites));
                tails[end] = Paginate(target);
                if (!installedNames.TryGetValue(end, out var used)) installedNames.Add(end, used = new HashSet<string>());
                used.Add(menuName);
                menuCount++;
            }
            if (menuCount > 0 || names.Count > 0 || config.PageLabel != null)
            {
                // All edits belong to this avatar's build copy.
                var newRoot = Clone(root);
                context.AssetSaver.SaveAssets(created);
                descriptor.expressionsMenu = newRoot;
            }
            else foreach (var unused in created) Object.DestroyImmediate(unused);
            if (skipped.Count > 0)
                warnings.Add("찾을 수 없거나 순환 메뉴가 되는 즐겨찾기를 건너뛰었습니다: " + string.Join(", ", skipped));
            if (scan != null)
            {
                scan.HasWarnings = warnings.Count > 0;
                scan.Result = $"메뉴 {menuCount}개 · 즐겨찾기 {favoriteCount}개 · 폴더 {folderCount}개 · 이름 변경 {names.Count}개";
                if (scan.HasWarnings) scan.Result += "\n" + string.Join("\n", warnings);
            }
            else foreach (var warning in warnings) Debug.LogWarning("[Avatar Menu Favorites] " + warning, avatar);
        }

        private static bool Reaches(VRCExpressionsMenu menu, VRCExpressionsMenu destination, VRCExpressionsMenu end,
            HashSet<VRCExpressionsMenu> seen)
        {
            if (!menu || !seen.Add(menu)) return false;
            if (menu == destination || menu == end) return true;
            return menu.controls != null && menu.controls.Any(c => c?.type == Control.ControlType.SubMenu &&
                Reaches(c.subMenu, destination, end, seen));
        }

        private static Control Copy(Control c, string name, Func<VRCExpressionsMenu, VRCExpressionsMenu> map) => new Control
        {
            name = name, type = c.type, icon = c.icon, value = c.value, style = c.style,
            parameter = new Control.Parameter { name = c.parameter?.name ?? "" },
            subParameters = (c.subParameters ?? Array.Empty<Control.Parameter>())
                .Select(p => new Control.Parameter { name = p?.name ?? "" }).ToArray(),
            labels = (c.labels ?? Array.Empty<Control.Label>()).ToArray(),
            subMenu = c.type == Control.ControlType.SubMenu ? map(c.subMenu) : c.subMenu,
        };

        private static Control Submenu(string name, VRCExpressionsMenu menu) => new Control
        {
            name = name, type = Control.ControlType.SubMenu, subMenu = menu, parameter = new Control.Parameter(),
        };

        private static VRCExpressionsMenu NewMenu(string name, List<VRCExpressionsMenu> created)
        {
            var menu = ScriptableObject.CreateInstance<VRCExpressionsMenu>();
            menu.name = name;
            menu.controls = new List<Control>();
            created.Add(menu);
            return menu;
        }
    }
}
#endif
