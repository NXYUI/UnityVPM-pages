#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using nadena.dev.ndmf;
using nadena.dev.ndmf.platform;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using VRC.SDK3.Avatars.Components;
using Control = VRC.SDK3.Avatars.ScriptableObjects.VRCExpressionsMenu.Control;
using Object = UnityEngine.Object;

namespace AvatarMenuTools
{
    internal sealed class AvatarMenuFavoritesWindow : EditorWindow
    {
        private const string MenuPath = "Tools/Avatar Menu Favorites/즐겨찾기 설정";
        [SerializeField] private VRCAvatarDescriptor avatar;
        [SerializeField] private string search = "";
        [SerializeField] private int tab;
        [SerializeField] private int menuIndex;
        private FavoriteMenuKey[] catalogue = Array.Empty<FavoriteMenuKey>();
        private FavoriteMenuKey selectedKey;
        private string addParent = "";
        private readonly HashSet<string> collapsed = new HashSet<string>();
        private Vector2 optionsScroll, favoritesScroll;
        private bool scanning;
        private string status;
        private MessageType statusType;

        [MenuItem(MenuPath)]
        private static void Open()
        {
            var window = GetWindow<AvatarMenuFavoritesWindow>("Avatar Menu Favorites");
            window.minSize = new Vector2(740, 420);
            if (Selection.activeGameObject)
            {
                var selected = Selection.activeGameObject.GetComponentInParent<VRCAvatarDescriptor>(true);
                if (IsSceneAvatar(selected)) window.SelectAvatar(selected);
            }
            window.Show();
        }

        private static bool IsSceneAvatar(VRCAvatarDescriptor selected) =>
            selected && !EditorUtility.IsPersistent(selected) && selected.gameObject.scene.IsValid() &&
            selected.gameObject.scene.isLoaded && !EditorSceneManager.IsPreviewScene(selected.gameObject.scene) &&
            PrefabStageUtility.GetPrefabStage(selected.gameObject) == null;

        private void SelectAvatar(VRCAvatarDescriptor selected)
        {
            if (avatar == selected) return;
            avatar = selected;
            catalogue = Array.Empty<FavoriteMenuKey>();
            selectedKey = null;
            SelectMenu(0);
            status = null;
            optionsScroll = Vector2.zero;
        }

        private void SelectMenu(int index)
        {
            menuIndex = index;
            addParent = "";
            collapsed.Clear();
            favoritesScroll = Vector2.zero;
        }

        private void Change(string action, Action<AvatarMenuFavorites> edit)
        {
            if (!IsSceneAvatar(avatar)) return;
            var config = avatar.GetComponent<AvatarMenuFavorites>();
            if (!config) config = Undo.AddComponent<AvatarMenuFavorites>(avatar.gameObject);
            Undo.RecordObject(config, action);
            edit(config);
            PrefabUtility.RecordPrefabInstancePropertyModifications(config);
            EditorUtility.SetDirty(config);
            EditorSceneManager.MarkSceneDirty(config.gameObject.scene);
        }

        private void ChangeEntries(string action, Action<List<FavoriteMenuEntry>> edit)
        {
            Change(action, c =>
            {
                if (menuIndex == 0) edit(c.entries ??= new List<FavoriteMenuEntry>());
                else if (c.GetMenu(menuIndex) is FavoriteMenuGroup menu)
                    edit(menu.entries ??= new List<FavoriteMenuEntry>());
            });
        }

        private void SetLocation(FavoriteMenuKey key)
        {
            Change("Move favorites menu", c =>
            {
                if (menuIndex == 0)
                {
                    c.useRoot = key == null;
                    if (key != null) c.destination = key;
                }
                else if (c.GetMenu(menuIndex) is FavoriteMenuGroup menu)
                {
                    menu.useRoot = key == null;
                    if (key != null) menu.destination = key;
                }
            });
        }

        private void DrawMenuSelector(AvatarMenuFavorites config)
        {
            int count = config ? config.additionalMenus?.Count ?? 0 : 0;
            if (menuIndex < 0 || menuIndex > count || (menuIndex != 0 && config.GetMenu(menuIndex) == null)) SelectMenu(0);
            var names = Enumerable.Range(0, count + 1).Select(i =>
                $"{i + 1}. {(config ? config.GetMenu(i)?.DisplayName ?? "이름 없는 메뉴" : "즐겨찾기")}").ToArray();
            using (new EditorGUILayout.HorizontalScope())
            {
                int index = EditorGUILayout.Popup("편집할 메뉴", menuIndex, names);
                if (index != menuIndex) { SelectMenu(index); GUIUtility.ExitGUI(); }
                if (GUILayout.Button("+ 메뉴", GUILayout.Width(72)))
                {
                    var used = new HashSet<string>(Enumerable.Range(0, count + 1)
                        .Select(i => config ? config.GetMenu(i)?.DisplayName : "즐겨찾기"));
                    string label = "새 메뉴";
                    for (int i = 2; used.Contains(label); i++) label = "새 메뉴 " + i;
                    Change("Add favorites menu", c =>
                        (c.additionalMenus ??= new List<FavoriteMenuGroup>()).Add(new FavoriteMenuGroup { name = label }));
                    SelectMenu(count + 1);
                    GUIUtility.ExitGUI();
                }
                using (new EditorGUI.DisabledScope(menuIndex == 0))
                    if (GUILayout.Button("메뉴 삭제", GUILayout.Width(72)) && EditorUtility.DisplayDialog(
                        "메뉴 삭제", $"‘{config.GetMenu(menuIndex).DisplayName}’ 메뉴와 그 안의 즐겨찾기 설정을 삭제할까요?", "삭제", "취소"))
                    {
                        Change("Remove favorites menu", c => c.additionalMenus.RemoveAt(menuIndex - 1));
                        SelectMenu(Math.Max(0, menuIndex - 1));
                        GUIUtility.ExitGUI();
                    }
            }
        }

        private void OnGUI()
        {
            using (new EditorGUILayout.HorizontalScope())
            {
                using (new EditorGUI.DisabledScope(scanning))
                    SelectAvatar((VRCAvatarDescriptor)EditorGUILayout.ObjectField("아바타", avatar, typeof(VRCAvatarDescriptor), true));
                using (new EditorGUI.DisabledScope(!IsSceneAvatar(avatar) || scanning || EditorApplication.isPlayingOrWillChangePlaymode))
                    if (GUILayout.Button("빌드 메뉴 읽기", GUILayout.Width(116)))
                    {
                        scanning = true;
                        var selected = avatar;
                        EditorApplication.delayCall += () => { if (this) Scan(selected); };
                    }
            }
            if (!IsSceneAvatar(avatar))
            {
                EditorGUILayout.HelpBox("Hierarchy에서 아바타를 선택하거나 위 필드에 Avatar Descriptor를 넣어 주세요.", MessageType.Info);
                return;
            }
            if (EditorApplication.isPlayingOrWillChangePlaymode)
            {
                EditorGUILayout.HelpBox("플레이 모드를 종료한 뒤 설정해 주세요.", MessageType.Info);
                return;
            }
            if (scanning)
                EditorGUILayout.HelpBox("복제본에서 빌드 메뉴를 읽고 있습니다.", MessageType.Info);
            else if (!string.IsNullOrEmpty(status))
                EditorGUILayout.HelpBox(status, statusType);

            var config = avatar.GetComponent<AvatarMenuFavorites>();
            if ((!config || (config.entries?.Count ?? 0) == 0) && LegacySettingsAvailable() &&
                GUILayout.Button("기존 루루네 즐겨찾기 가져오기", GUILayout.Width(215)))
                ImportLegacy();

            config = avatar.GetComponent<AvatarMenuFavorites>();
            using (new EditorGUI.DisabledScope(scanning))
            {
                int nextTab = GUILayout.Toolbar(tab, new[] { "즐겨찾기 편집", "원본 메뉴 이름 수정" });
                if (nextTab != tab) { tab = nextTab; favoritesScroll = Vector2.zero; }
                if (tab == 0) DrawMenuSelector(config);
                var view = new MenuView(catalogue, config);
                var activeMenu = config ? config.GetMenu(menuIndex) : null;
                EditorGUILayout.LabelField("왼쪽에서 빌드 메뉴를 고르세요. 설정은 아바타별로 씬에 저장돼요.", EditorStyles.wordWrappedMiniLabel);
                using (new EditorGUILayout.HorizontalScope())
                {
                    using (new EditorGUILayout.VerticalScope(GUILayout.Width(position.width * .48f)))
                        DrawOptions(view, activeMenu);
                    using (new EditorGUILayout.VerticalScope(GUILayout.ExpandWidth(true)))
                        if (tab == 0) DrawFavorites(activeMenu, view);
                        else DrawNames(config, view);
                }
            }
        }

        private sealed class MenuView
        {
            private readonly FavoriteMenuKey[] keys;
            private readonly Dictionary<FavoriteMenuKey, FavoriteMenuKey> resolved = new Dictionary<FavoriteMenuKey, FavoriteMenuKey>();
            internal readonly Dictionary<int, int> RuleByControl = new Dictionary<int, int>();
            private readonly Dictionary<int, string> labels = new Dictionary<int, string>();
            private readonly Dictionary<string, FavoriteMenuKey> paths;

            internal MenuView(FavoriteMenuKey[] catalogue, AvatarMenuFavorites config)
            {
                keys = catalogue;
                paths = keys.Where(x => x.type == Control.ControlType.SubMenu)
                    .GroupBy(x => string.Join("\u001f", x.path))
                    .Where(g => g.Count() == 1).ToDictionary(g => g.Key, g => g.First());
                if (!config || config.nameOverrides == null) return;
                for (int i = 0; i < config.nameOverrides.Count; i++)
                {
                    var rule = config.nameOverrides[i];
                    var key = Resolve(rule?.source);
                    if (key == null || RuleByControl.ContainsKey(key.sharedControl)) continue;
                    RuleByControl.Add(key.sharedControl, i);
                    if (!string.IsNullOrWhiteSpace(rule.label)) labels.Add(key.sharedControl, rule.label.Trim());
                }
            }

            internal FavoriteMenuKey Resolve(FavoriteMenuKey key)
            {
                if (key == null) return null;
                if (!resolved.TryGetValue(key, out var match))
                    resolved.Add(key, match = FavoriteMenuKey.Resolve(keys, key));
                return match;
            }

            internal string Name(FavoriteMenuKey key) =>
                labels.TryGetValue(key.sharedControl, out var name) ? name : key.Name;

            internal string Display(FavoriteMenuKey key)
            {
                var parts = (string[])key.path.Clone();
                for (int i = 0; i < parts.Length - 1; i++)
                    if (paths.TryGetValue(string.Join("\u001f", key.path.Take(i + 1)), out var parent))
                        parts[i] = Name(parent);
                parts[parts.Length - 1] = Name(key);
                return string.Join(" / ", parts.Select(p => string.IsNullOrWhiteSpace(p) ? "(이름 없음)" : p));
            }
        }

        private void DrawOptions(MenuView view, FavoriteMenuGroup menu)
        {
            EditorGUILayout.LabelField($"빌드 메뉴 · {catalogue.Length}개", EditorStyles.boldLabel);
            search = EditorGUILayout.TextField(search, EditorStyles.toolbarSearchField);
            var terms = (search ?? "").Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            using var scroll = new EditorGUILayout.ScrollViewScope(optionsScroll, GUILayout.ExpandHeight(true));
            optionsScroll = scroll.scrollPosition;
            if (catalogue.Length == 0)
                EditorGUILayout.HelpBox("‘빌드 메뉴 읽기’로 생성된 메뉴를 불러오세요.", MessageType.Info);
            var currentFolder = menu?.entries?.Where(e => e != null && !e.IsFolder && e.Parent == addParent)
                .Select(e => view.Resolve(e.source)?.sharedControl ?? 0).ToHashSet() ?? new HashSet<int>();
            var itemStyle = new GUIStyle(EditorStyles.miniButton) { alignment = TextAnchor.MiddleLeft, clipping = TextClipping.Clip };

            foreach (var key in catalogue)
            {
                string path = view.Display(key);
                // Keep the filtered rows stable while the label field is being edited.
                var searchable = key.DisplayPath + " " + key.Binding;
                if (terms.Any(term => searchable.IndexOf(term, StringComparison.OrdinalIgnoreCase) < 0)) continue;
                using (new EditorGUILayout.HorizontalScope())
                {
                    var tooltip = key.DisplayPath + "\n" + key.type + (key.Binding.Length == 0 ? "" : " · " + key.Binding);
                    bool selected = ReferenceEquals(selectedKey, key);
                    if (GUILayout.Toggle(selected, new GUIContent(path, tooltip), itemStyle,
                        GUILayout.MinWidth(0), GUILayout.ExpandWidth(true)) && !selected)
                    {
                        selectedKey = key;
                        if (tab == 1) favoritesScroll = Vector2.zero;
                    }
                    if (tab != 0) continue;
                    if (key.type == Control.ControlType.SubMenu && GUILayout.Button(new GUIContent("위치",
                        "편집 중인 메뉴를 이 서브메뉴에 설치"), GUILayout.Width(40)))
                        if (SelectUsable(view, key))
                            SetLocation(key);
                    bool exists = currentFolder.Contains(key.sharedControl);
                    using (new EditorGUI.DisabledScope(exists))
                        if (GUILayout.Button(new GUIContent(exists ? "✓" : "+", "선택한 즐겨찾기 폴더에 바로가기 추가"),
                            GUILayout.Width(26)) && SelectUsable(view, key))
                        {
                            string parent = addParent;
                            ChangeEntries("Add favorite", entries => entries.Add(new FavoriteMenuEntry { source = key, parentId = parent }));
                            Reveal(parent, menu?.entries);
                            GUIUtility.ExitGUI();
                        }
                }
            }
        }

        private bool SelectUsable(MenuView view, FavoriteMenuKey key)
        {
            if (view.Resolve(key) != null) return true;
            status = "경로와 동작 설정이 똑같은 항목이 여러 개라 안전하게 구분할 수 없어요.";
            statusType = MessageType.Warning;
            return false;
        }

        private sealed class FolderChoice
        {
            internal string Id, Path;
            internal FavoriteMenuEntry Entry;
        }

        private static List<FolderChoice> FolderChoices(IReadOnlyList<FavoriteMenuEntry> entries, string menuName)
        {
            var choices = new List<FolderChoice> { new FolderChoice { Id = "", Path = menuName + " 첫 화면" } };
            var folders = entries.Where(e => e != null && e.IsFolder).ToLookup(e => e.Parent);
            var visited = new HashSet<string>();
            void Walk(string parent, string prefix, int depth)
            {
                if (depth >= 64) return;
                foreach (var entry in folders[parent])
                {
                    if (!visited.Add(entry.folderId)) continue;
                    string name = string.IsNullOrWhiteSpace(entry.label) ? "새 폴더" : entry.label.Trim();
                    var path = prefix + name;
                    choices.Add(new FolderChoice { Id = entry.folderId, Path = path, Entry = entry });
                    Walk(entry.folderId, path + " › ", depth + 1);
                }
            }
            Walk("", "", 0);
            return choices;
        }

        private void DrawFavorites(FavoriteMenuGroup menu, MenuView view)
        {
            string previousName = menu != null ? menu.name ?? "" : "즐겨찾기";
            string name = EditorGUILayout.TextField("메뉴 이름", previousName);
            if (name != previousName) Change("Rename favorites menu", c =>
            {
                if (menuIndex == 0) c.menuName = name;
                else if (c.GetMenu(menuIndex) is FavoriteMenuGroup group) group.name = name;
            });
            bool atRoot = menu == null || menu.useRoot;
            var destination = atRoot ? null : view.Resolve(menu.destination);
            using (new EditorGUILayout.HorizontalScope())
            {
                string path = atRoot ? "최상위" : destination != null ? view.Display(destination) : menu.destination?.DisplayPath ?? "";
                EditorGUILayout.LabelField("설치 위치", path);
                using (new EditorGUI.DisabledScope(atRoot))
                    if (GUILayout.Button("최상위로", GUILayout.Width(74)))
                    { SetLocation(null); GUIUtility.ExitGUI(); }
            }

            var entries = menu?.entries ?? new List<FavoriteMenuEntry>();
            var choices = FolderChoices(entries, menu?.DisplayName ?? "즐겨찾기");
            using (new EditorGUILayout.HorizontalScope())
            {
                int selected = Math.Max(0, choices.FindIndex(x => x.Id == addParent));
                int next = EditorGUILayout.Popup("추가할 위치", selected, choices.Select(x => x.Path).ToArray());
                addParent = choices[next].Id;
                if (GUILayout.Button("+ 폴더", GUILayout.Width(68)))
                {
                    string parent = addParent;
                    string id = Guid.NewGuid().ToString("N");
                    var names = new HashSet<string>(entries.Where(e => e != null && e.Parent == parent).Select(e => e.label));
                    string newName = "새 폴더";
                    for (int n = 2; names.Contains(newName); n++) newName = "새 폴더 " + n;
                    ChangeEntries("Create favorites folder", list =>
                        list.Add(new FavoriteMenuEntry { folderId = id, parentId = parent, label = newName }));
                    Reveal(parent, entries);
                    addParent = id;
                    GUIUtility.ExitGUI();
                }
            }
            EditorGUILayout.LabelField("‘+’로 바로가기를 추가하고 ‘이동’으로 다른 폴더에 넣어요.", EditorStyles.wordWrappedMiniLabel);
            using var scroll = new EditorGUILayout.ScrollViewScope(favoritesScroll, GUILayout.ExpandHeight(true));
            favoritesScroll = scroll.scrollPosition;
            var siblings = entries.Select((e, i) => (e, i)).Where(x => x.e != null).ToLookup(x => x.e.Parent);
            var drawn = new HashSet<string>();
            void DrawChildren(string parent, int depth)
            {
                if (depth > 64 || !drawn.Add(parent)) return;
                var rows = siblings[parent].ToArray();
                for (int n = 0; n < rows.Length; n++)
                {
                    var (entry, index) = rows[n];
                    var current = entry.IsFolder ? null : view.Resolve(entry.source);
                    using (new EditorGUILayout.HorizontalScope())
                    {
                        GUILayout.Space(Math.Min(5, depth) * 12);
                        using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
                        {
                            using (new EditorGUILayout.HorizontalScope())
                            {
                                if (entry.IsFolder)
                                {
                                    bool expanded = !collapsed.Contains(entry.folderId);
                                    if (GUILayout.Button(expanded ? "▾" : "▸", GUILayout.Width(20)))
                                    {
                                        if (expanded) collapsed.Add(entry.folderId);
                                        else collapsed.Remove(entry.folderId);
                                        GUIUtility.ExitGUI();
                                    }
                                }
                                string previous = entry.label ?? "";
                                string label = EditorGUILayout.TextField(previous, GUILayout.MinWidth(48));
                                if (label != previous) ChangeEntries("Rename favorites item", list => list[index].label = label);
                                if (GUILayout.Button("이동", GUILayout.Width(39))) ShowMove(entry, choices);
                                using (new EditorGUI.DisabledScope(n == 0))
                                    if (GUILayout.Button("↑", GUILayout.Width(23))) Move(index, rows[n - 1].i);
                                using (new EditorGUI.DisabledScope(n + 1 == rows.Length))
                                    if (GUILayout.Button("↓", GUILayout.Width(23))) Move(index, rows[n + 1].i);
                                if (GUILayout.Button(new GUIContent("×", entry.IsFolder ? "폴더만 삭제하고 내용은 한 단계 위로 이동" : "바로가기 삭제"),
                                    GUILayout.Width(23)))
                                {
                                    ChangeEntries("Remove favorites item", list => RemoveEntry(list, index));
                                    GUIUtility.ExitGUI();
                                }
                            }
                            if (!entry.IsFolder)
                            {
                                string path = current != null ? view.Display(current) : entry.source?.DisplayPath ?? "(원본 없음)";
                                bool missing = current == null && catalogue.Length > 0;
                                using (new EditorGUILayout.HorizontalScope())
                                {
                                    EditorGUILayout.LabelField(new GUIContent((missing ? "⚠ 연결 필요 · " : "") + path, path), EditorStyles.miniLabel);
                                    if (missing)
                                        using (new EditorGUI.DisabledScope(selectedKey == null))
                                            if (GUILayout.Button(new GUIContent("다시 연결", "왼쪽에서 새 원본 항목을 선택한 후 누르세요."),
                                                GUILayout.Width(65)) && SelectUsable(view, selectedKey))
                                            {
                                                ChangeEntries("Relink favorite", list => list[index].source = selectedKey);
                                                GUIUtility.ExitGUI();
                                            }
                                }
                            }
                        }
                    }
                    if (entry.IsFolder && !collapsed.Contains(entry.folderId)) DrawChildren(entry.folderId, depth + 1);
                }
            }
            DrawChildren("", 0);
            if (entries.Count == 0) EditorGUILayout.LabelField("항목이나 폴더를 추가하면 빌드에 이 메뉴가 표시돼요.", EditorStyles.miniLabel);
            else EditorGUILayout.LabelField("별칭을 비우면 원본 메뉴의 현재 이름을 따라가요.", EditorStyles.miniLabel);
        }

        private void DrawNames(AvatarMenuFavorites config, MenuView view)
        {
            string page = config ? config.nextPageLabel ?? "" : "";
            string next = EditorGUILayout.TextField(new GUIContent("‘More’ 이름", "자동으로 만들어진 다음 페이지 버튼의 이름. 비우면 기본값."),
                page);
            if (next != page) Change("Rename more pages", c => c.nextPageLabel = next);
            EditorGUILayout.HelpBox("빌드된 아바타의 표시 이름만 바꿔요. 원본 에셋과 동작은 그대로 유지돼요.", MessageType.Info);
            var rules = (config ? config.nameOverrides : null) ?? new List<MenuNameOverride>();
            var key = selectedKey;
            if (key != null)
            {
                bool hasRule = view.RuleByControl.TryGetValue(key.sharedControl, out int index);
                string old = hasRule ? rules[index].label ?? "" : "";
                EditorGUILayout.LabelField(new GUIContent("원래 경로", key.DisplayPath), new GUIContent(key.DisplayPath, key.DisplayPath));
                using (new EditorGUI.DisabledScope(view.Resolve(key) == null))
                using (new EditorGUILayout.HorizontalScope())
                {
                    string label = EditorGUILayout.TextField(new GUIContent("새 표시 이름", "비워 두면 원래 표시 이름"), old);
                    if (old != label)
                        Change("Rename built menu item", c =>
                        {
                            if (hasRule) c.nameOverrides[index].label = label;
                            else c.nameOverrides.Add(new MenuNameOverride { source = key, label = label });
                        });
                    using (new EditorGUI.DisabledScope(!hasRule))
                        if (GUILayout.Button("원래대로", GUILayout.Width(64)))
                        {
                            Change("Reset menu name", c => c.nameOverrides.RemoveAt(index));
                            GUIUtility.ExitGUI();
                        }
                }
                if (catalogue.Count(x => x.sharedControl == key.sharedControl) > 1)
                    EditorGUILayout.LabelField("공유된 메뉴예요. 같은 항목을 보여 주는 다른 경로에도 반영돼요.", EditorStyles.wordWrappedMiniLabel);
            }
            else EditorGUILayout.LabelField("왼쪽 목록에서 이름을 바꿀 항목을 선택하세요.", EditorStyles.wordWrappedMiniLabel);

            EditorGUILayout.LabelField($"저장한 이름 변경 · {rules.Count(x => !string.IsNullOrWhiteSpace(x?.label))}개", EditorStyles.boldLabel);
            using var scroll = new EditorGUILayout.ScrollViewScope(favoritesScroll, GUILayout.ExpandHeight(true));
            favoritesScroll = scroll.scrollPosition;
            for (int i = 0; i < rules.Count; i++)
            {
                var rule = rules[i];
                if (string.IsNullOrWhiteSpace(rule?.label)) continue;
                int index = i;
                var current = view.Resolve(rule.source);
                string path = current?.DisplayPath ?? rule.source?.DisplayPath ?? "";
                bool missing = current == null && catalogue.Length > 0;
                using (new EditorGUILayout.HorizontalScope())
                {
                    EditorGUILayout.LabelField(new GUIContent((missing ? "⚠ " : "") + path + " → " + rule.label, path));
                    if (missing)
                    {
                        using (new EditorGUI.DisabledScope(selectedKey == null ||
                            view.RuleByControl.ContainsKey(selectedKey.sharedControl)))
                            if (GUILayout.Button("다시 연결", GUILayout.Width(65)) && SelectUsable(view, selectedKey))
                            {
                                Change("Relink menu name", c => c.nameOverrides[index].source = selectedKey);
                                GUIUtility.ExitGUI();
                            }
                    }
                    else using (new EditorGUI.DisabledScope(current == null))
                        if (GUILayout.Button("보기", GUILayout.Width(43))) selectedKey = current;
                    if (GUILayout.Button("×", GUILayout.Width(23)))
                    {
                        Change("Reset menu name", c => c.nameOverrides.RemoveAt(index));
                        GUIUtility.ExitGUI();
                    }
                }
            }
        }

        private void Reveal(string id, IReadOnlyList<FavoriteMenuEntry> entries)
        {
            var seen = new HashSet<string>();
            while (!string.IsNullOrEmpty(id) && seen.Add(id))
            {
                collapsed.Remove(id);
                id = entries?.FirstOrDefault(e => e != null && e.folderId == id)?.Parent;
            }
        }

        private void ShowMove(FavoriteMenuEntry entry, List<FolderChoice> choices)
        {
            var menu = new GenericMenu();
            var parents = choices.ToDictionary(x => x.Id, x => x.Entry?.Parent);
            foreach (var choice in choices)
            {
                string target = choice.Id;
                if (entry.IsFolder)
                {
                    string id = target;
                    var seen = new HashSet<string>();
                    while (!string.IsNullOrEmpty(id) && id != entry.folderId && seen.Add(id))
                        id = parents.TryGetValue(id, out var parent) ? parent : null;
                    if (id == entry.folderId) continue;
                }
                var title = new GUIContent(choice.Path.Replace("/", "／"));
                if (target == entry.Parent) menu.AddDisabledItem(title, true);
                else
                {
                    var selectedAvatar = avatar;
                    var selectedMenuIndex = menuIndex;
                    menu.AddItem(title, false, () =>
                    {
                        if (avatar != selectedAvatar || menuIndex != selectedMenuIndex) return;
                        ChangeEntries("Move favorites item", list =>
                        {
                            if (!list.Remove(entry)) return;
                            entry.parentId = target;
                            list.Add(entry);
                            Reveal(target, list);
                        });
                        Repaint();
                    });
                }
            }
            menu.ShowAsContext();
        }

        private static void RemoveEntry(List<FavoriteMenuEntry> entries, int index)
        {
            var entry = entries[index];
            entries.RemoveAt(index);
            if (!entry.IsFolder) return;
            var children = entries.Where(e => e != null && e.Parent == entry.folderId).ToArray();
            var following = entries.Skip(index).FirstOrDefault(e => e != null && e.Parent == entry.Parent);
            foreach (var child in children) { entries.Remove(child); child.parentId = entry.Parent; }
            entries.InsertRange(following == null ? entries.Count : entries.IndexOf(following), children);
        }

        private void Move(int from, int to)
        {
            ChangeEntries("Reorder favorites", list => (list[to], list[from]) = (list[from], list[to]));
            GUIUtility.ExitGUI();
        }

        private void Scan(VRCAvatarDescriptor selected)
        {
            Scene preview = default;
            GameObject clone = null;
            string temporary = null;
            try
            {
                if (!IsSceneAvatar(selected) || EditorApplication.isPlayingOrWillChangePlaymode)
                    throw new InvalidOperationException("편집 모드에서 아바타를 선택해 주세요.");
                preview = EditorSceneManager.NewPreviewScene();
                clone = Object.Instantiate(selected.gameObject);
                SceneManager.MoveGameObjectToScene(clone, preview);
                clone.SetActive(true);
                var folderName = "__AvatarMenuFavoritesScan_" + Guid.NewGuid().ToString("N");
                temporary = AssetDatabase.GUIDToAssetPath(AssetDatabase.CreateFolder("Assets", folderName));
                if (string.IsNullOrEmpty(temporary))
                    throw new InvalidOperationException("임시 빌드 폴더를 만들 수 없습니다.");
                using var scan = new FavoriteMenuBuilder.Scan(clone);
                BuildContext context;
                using (new OverrideTemporaryDirectoryScope(temporary))
                    context = nadena.dev.ndmf.AvatarProcessor.ProcessAvatar(clone, AmbientPlatform.DefaultPlatform);
                bool captured = scan.Menu != null;
                if (captured && avatar == selected)
                {
                    catalogue = scan.Menu;
                    selectedKey = FavoriteMenuKey.Resolve(catalogue, selectedKey);
                }
                statusType = context.Successful && captured && !scan.HasWarnings ? MessageType.Info : MessageType.Warning;
                status = captured ? $"빌드 메뉴에서 {scan.Menu.Length}개 항목을 읽었어요." :
                    "빌드 메뉴를 읽지 못했어요. Unity Console 또는 NDMF 빌드 보고서를 확인해 주세요.";
                if (!context.Successful && captured) status += " 일부 에셋에 빌드 오류가 있어 메뉴가 빠질 수 있어요.";
                if (captured && !string.IsNullOrEmpty(scan.Result)) status += "\n" + scan.Result;
            }
            catch (Exception e)
            {
                statusType = MessageType.Error;
                status = "메뉴 읽기 실패: " + e.Message;
                Debug.LogException(e);
            }
            finally
            {
                try
                {
                    if (clone) Object.DestroyImmediate(clone);
                    if (preview.IsValid()) EditorSceneManager.ClosePreviewScene(preview);
                    if (!string.IsNullOrEmpty(temporary) && temporary.StartsWith("Assets/__AvatarMenuFavoritesScan_", StringComparison.Ordinal))
                        AssetDatabase.DeleteAsset(temporary);
                }
                finally { scanning = false; Repaint(); }
            }
        }

        [Serializable]
        private sealed class LegacySettings
        {
            public string menuName = "";
            public bool rootMenu = false;
            public List<FavoriteMenuEntry> entries = new List<FavoriteMenuEntry>();
        }

        private bool LegacySettingsAvailable() => avatar.name == "X-MAS Chibi Shell PCSS" &&
            File.Exists("ProjectSettings/RuruneMenuFavorites.asset");

        private void ImportLegacy()
        {
            try
            {
                var type = TypeCache.GetTypesDerivedFrom<ScriptableObject>()
                    .FirstOrDefault(t => t.FullName == "RuruneTools.RuruneFavoriteSettings");
                var previous = type?.GetProperty("instance", BindingFlags.Static | BindingFlags.Public | BindingFlags.FlattenHierarchy)
                    ?.GetValue(null) as ScriptableObject;
                var old = previous ? JsonUtility.FromJson<LegacySettings>(EditorJsonUtility.ToJson(previous)) : null;
                if (old?.entries == null || old.entries.Count == 0)
                    throw new InvalidOperationException("이전 즐겨찾기 항목이 없거나 루루네 라우터를 찾을 수 없어요.");
                Change("Import Rurune favorites", c =>
                {
                    c.menuName = old.menuName;
                    c.useRoot = old.rootMenu;
                    c.destination = new FavoriteMenuKey
                    {
                        path = new[] { "기믹" }, type = Control.ControlType.SubMenu, parameter = ""
                    };
                    c.entries = old.entries;
                });
                status = $"이전 즐겨찾기 {old.entries.Count}개를 가져왔어요. 씬을 저장해 주세요.";
                statusType = MessageType.Info;
            }
            catch (Exception e)
            {
                status = e.Message;
                statusType = MessageType.Warning;
            }
        }
    }
}
#endif
