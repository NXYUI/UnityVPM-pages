using System;
using System.Collections.Generic;
using System.Linq;
using nadena.dev.ndmf;
using UnityEngine;
using Control = VRC.SDK3.Avatars.ScriptableObjects.VRCExpressionsMenu.Control;

namespace AvatarMenuTools
{
    [DisallowMultipleComponent]
    [AddComponentMenu("Avatar Menu Favorites/Avatar Menu Favorites")]
    public sealed class AvatarMenuFavorites : MonoBehaviour, INDMFEditorOnly
    {
        // Keep the first menu in its original serialized fields. Existing scenes and prefab overrides need no migration.
        public string menuName = "즐겨찾기";
        public bool useRoot = true;
        public FavoriteMenuKey destination = new FavoriteMenuKey();
        public List<FavoriteMenuEntry> entries = new List<FavoriteMenuEntry>();
        public List<MenuNameOverride> nameOverrides = new List<MenuNameOverride>();
        public string nextPageLabel = "";
        public List<FavoriteMenuGroup> additionalMenus = new List<FavoriteMenuGroup>();

        public FavoriteMenuGroup GetMenu(int index)
        {
            if (index == 0)
                return new FavoriteMenuGroup { name = menuName, useRoot = useRoot, destination = destination, entries = entries };
            return index > 0 && additionalMenus != null && index <= additionalMenus.Count ? additionalMenus[index - 1] : null;
        }
    }

    [Serializable]
    public sealed class FavoriteMenuGroup
    {
        public string name = "새 메뉴";
        public bool useRoot = true;
        public FavoriteMenuKey destination;
        public List<FavoriteMenuEntry> entries = new List<FavoriteMenuEntry>();

        public string DisplayName => string.IsNullOrWhiteSpace(name) ? "즐겨찾기" : name.Trim();
    }

    [Serializable]
    public sealed class FavoriteMenuKey
    {
        public string[] path;
        public Control.ControlType type;
        public string parameter;
        public string[] subParameters;
        public float value;
        [NonSerialized] public int sharedControl;

        public string DisplayPath => string.Join(" / ", path ?? Array.Empty<string>());
        public string Binding => string.Join(", ", new[] { parameter }.Concat(subParameters ?? Array.Empty<string>())
            .Where(p => !string.IsNullOrEmpty(p)));
        public string Name => path?.LastOrDefault() ?? "";

        public bool SamePath(FavoriteMenuKey other) => type == other.type &&
            (path ?? Array.Empty<string>()).SequenceEqual(other.path ?? Array.Empty<string>(), StringComparer.Ordinal);

        public bool SameBinding(FavoriteMenuKey other) => type == other.type && value.Equals(other.value) &&
            string.Equals(parameter ?? "", other.parameter ?? "", StringComparison.Ordinal) &&
            (subParameters ?? Array.Empty<string>()).SequenceEqual(other.subParameters ?? Array.Empty<string>(), StringComparer.Ordinal);

        public static FavoriteMenuKey Resolve(IReadOnlyList<FavoriteMenuKey> catalogue, FavoriteMenuKey key)
        {
            if (key?.path == null || key.path.Length == 0) return null;
            var atPath = catalogue.Where(x => key.SamePath(x)).ToArray();
            var exact = UniqueControl(atPath.Where(x => key.SameBinding(x)));
            if (exact != null) return exact;
            if (atPath.Length == 1) return atPath[0]; // Generated parameter names may change between builds.
            if (atPath.Length > 0 || key.Binding.Length == 0) return null;
            var sameBinding = catalogue.Where(x => key.SameBinding(x)).ToArray();
            var sameName = UniqueControl(sameBinding.Where(x => x.Name == key.Name));
            return sameName ?? UniqueControl(sameBinding);
        }

        private static FavoriteMenuKey UniqueControl(IEnumerable<FavoriteMenuKey> keys)
        {
            FavoriteMenuKey first = null;
            foreach (var key in keys)
            {
                if (first == null) first = key;
                else if (first.sharedControl == 0 || key.sharedControl != first.sharedControl) return null;
            }
            return first;
        }
    }

    [Serializable]
    public sealed class FavoriteMenuEntry
    {
        public FavoriteMenuKey source;
        public string label;
        public string folderId;
        public string parentId;
        public bool IsFolder => !string.IsNullOrEmpty(folderId);
        public string Parent => parentId ?? "";
    }

    [Serializable]
    public sealed class MenuNameOverride
    {
        public FavoriteMenuKey source;
        public string label;
    }
}
