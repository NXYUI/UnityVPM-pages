#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;
using VRC.SDK3.Avatars.ScriptableObjects;
using Control = VRC.SDK3.Avatars.ScriptableObjects.VRCExpressionsMenu.Control;
using Object = UnityEngine.Object;

namespace AvatarMenuTools
{
    // What the window works the final menu out from: the last read's copy of the avatar's menu and the avatar in the scene.
    internal sealed class FinalContext
    {
        internal MenuSnapshot Tree;
        internal Transform Root;
        internal IReadOnlyDictionary<string, VRCExpressionParameters.ValueType> Parameters;

        internal MenuComposition Compose(AvatarCustomizer c, List<FavoriteMenuBuilder.Issue> issues, BlendshapeControlBuilder.State shapes = null)
        {
            shapes ??= new BlendshapeControlBuilder.State();
            BlendshapeControlBuilder.Plan(c, Root, shapes);
            return MenuComposer.Compose(Tree?.Root, MenuSettings.From(c), shapes, Parameters, issues, true, HideFlags.HideAndDontSave, Tree?.PageLinks);
        }
    }

    // One edit of the final menu, made on a copy of the settings (Work) so the result can be checked before it is kept.
    // Whoever gets it back copies it into the component (CopyTo) and disposes it.
    internal sealed class FinalEdit : IDisposable
    {
        internal readonly AvatarCustomizer Work;
        // The final menu the edit starts from: the settings as they are, before the edit.
        internal readonly FinalMenu Now;
        internal readonly FinalContext Context;
        // Said to the user when the edit is kept, and the item to select then (an id in the level it ends up in).
        internal string Note, Select;
        // How the edit checks where things landed, run on the final menu after the edit (and after Repoint).
        internal Func<FinalMenu, List<FavoriteMenuBuilder.Issue>, string> Verify;
        // What the build kept before the edit, as Work's objects: favorites entries and menus.
        internal readonly HashSet<object> KeptBefore;
        private readonly GameObject holder;

        internal FinalEdit(AvatarCustomizer settings, FinalMenu now, FinalContext context)
        {
            Now = now;
            Context = context;
            holder = new GameObject("Avatar Customizer edit") { hideFlags = HideFlags.HideAndDontSave };
            Work = holder.AddComponent<AvatarCustomizer>();
            if (settings) EditorJsonUtility.FromJsonOverwrite(EditorJsonUtility.ToJson(settings), Work);
            Work.enabled = true;
            // Work is still a plain copy, so the menu shown (worked out from settings) names its entries by index.
            KeptBefore = FinalMenuEdits.Kept(now, Work);
        }

        internal MenuOrganizer Organizer => Now.Composition.Organizer;

        // Works the final menu out from Work and hands it to check; check's message (null when it passes) comes back.
        internal string Check(Func<FinalMenu, List<FavoriteMenuBuilder.Issue>, string> check)
        {
            var issues = new List<FavoriteMenuBuilder.Issue>();
            var composition = Context.Compose(Work, issues);
            try { return check(new FinalMenu(composition), issues); }
            finally { composition.Destroy(); }
        }

        internal void CopyTo(AvatarCustomizer c)
        {
            bool enabled = c.enabled;
            EditorJsonUtility.FromJsonOverwrite(EditorJsonUtility.ToJson(Work), c);
            c.enabled = enabled;
        }

        public void Dispose()
        {
            if (holder) Object.DestroyImmediate(holder);
        }
    }

    // Turns an edit of the final menu into the simplest settings of the earlier steps: "원본 메뉴 정리" rules for the
    // avatar's own items and made folders (keyed by the avatar's menu: Original), favorites entries for everything in a
    // favorites menu (keyed by the organized menu, as the favorites tab is). Every edit is tried on a copy of the settings
    // and checked by working the final menu out again; one that does not land where it was asked is refused with a reason.
    internal static class FinalMenuEdits
    {
        // An edit that would change nothing.
        internal const string NoChange = "";

        // ---------------------------------------------------------------- entry points

        internal static FinalEdit Rename(AvatarCustomizer settings, FinalMenu now, FinalContext context, FinalMenu.Item item, string name,
            out string error) => Try(settings, now, context, e => Rename(e, item, name), out error);

        internal static FinalEdit Delete(AvatarCustomizer settings, FinalMenu now, FinalContext context, FinalMenu.Item item, out string error) =>
            Try(settings, now, context, e => Delete(e, item), out error);

        // Puts item before `before` (an item of level; null: at the end of level).
        internal static FinalEdit Move(AvatarCustomizer settings, FinalMenu now, FinalContext context, FinalMenu.Item item,
            FinalMenu.Level level, FinalMenu.Item before, out string error)
        {
            // One of the avatar's items put back where it was in its menu needs no rule at all; try that first.
            if (item.Origin.Kind == MenuOriginKind.Original || IsPairedShortcut(settings, now, item))
            {
                var home = Try(settings, now, context, e => Move(e, item, level, before, true), out error);
                if (home != null || error == NoChange) return home;
            }
            return Try(settings, now, context, e => Move(e, item, level, before, false), out error);
        }

        // A new empty folder before `before` (null: at the end of level).
        internal static FinalEdit NewFolder(AvatarCustomizer settings, FinalMenu now, FinalContext context, FinalMenu.Level level,
            FinalMenu.Item before, out string error) => Try(settings, now, context, e => NewFolder(e, level, before), out error);

        // Takes off what was done to an item: an original's rename and move, or a shortcut that moved an original.
        internal static FinalEdit Restore(AvatarCustomizer settings, FinalMenu now, FinalContext context, FinalMenu.Item item, out string error) =>
            Try(settings, now, context, e => Restore(e, item), out error);

        // A shortcut to one of the avatar's items, which stays where it is, at the end of a favorites level.
        internal static FinalEdit AddShortcut(AvatarCustomizer settings, FinalMenu now, FinalContext context, FinalMenu.Item item,
            FinalMenu.Level level, out string error) => Try(settings, now, context, e => AddShortcut(e, item, level), out error);

        private static FinalEdit Try(AvatarCustomizer settings, FinalMenu now, FinalContext context, Func<FinalEdit, string> edit, out string error)
        {
            var e = new FinalEdit(settings, now, context);
            try
            {
                error = edit(e) ?? Repoint(e) ?? Verify(e);
                if (error != null) { e.Dispose(); return null; }
                return e;
            }
            catch
            {
                e.Dispose();
                throw;
            }
        }

        // ---------------------------------------------------------------- rename

        private static string Rename(FinalEdit e, FinalMenu.Item item, string name)
        {
            name = (name ?? "").Trim();
            if (name.Length == 0) return "이름을 비울 수 없어요.";
            if (name == item.Control.name) return NoChange;
            var origin = item.Origin;
            var w = e.Work;
            switch (origin.Kind)
            {
                case MenuOriginKind.Original:
                {
                    var rules = SameItemRules(e, w.nameOverrides, r => r?.source, origin.Key);
                    bool back = name == e.Organizer.OriginalNameOf(item.Control);
                    if (back || rules.Count > 1)
                        foreach (var rule in rules.Skip(back ? 0 : 1).Reverse()) w.nameOverrides.Remove(rule);
                    if (!back)
                    {
                        if (rules.Count > 0) rules[0].label = name;
                        else (w.nameOverrides ??= new List<MenuNameOverride>()).Add(new MenuNameOverride { source = origin.Key, label = name });
                    }
                    break;
                }
                case MenuOriginKind.Shortcut:
                    EntryOf(e, origin).label = name == origin.Target?.displayName ? "" : name;
                    break;
                case MenuOriginKind.Shape:
                {
                    string built = origin.Id == BlendshapeControl.ResetId ? BlendshapeControlBuilder.ResetName : w.FindShape(origin.Id)?.blendshape;
                    EntryOf(e, origin).label = name == built ? "" : name;
                    break;
                }
                case MenuOriginKind.FavoritesFolder:
                    EntryOf(e, origin).label = name;
                    break;
                case MenuOriginKind.FavoritesMenu:
                    if (origin.MenuIndex == 0) w.menuName = name;
                    else w.additionalMenus[origin.MenuIndex - 1].name = name;
                    break;
                case MenuOriginKind.MadeFolder:
                    w.createdFolders.First(f => f != null && f.id == origin.Id).name = name;
                    break;
                case MenuOriginKind.LegacyFolder:
                {
                    if (Promote(e, origin.Id, out string id) is string error) return error;
                    w.createdFolders.First(f => f.id == id).name = name;
                    origin = new MenuOrigin { Kind = MenuOriginKind.MadeFolder, Id = id };
                    break;
                }
                default: return "이 항목은 이름을 바꿀 수 없어요.";
            }
            var expected = origin;
            return Later(e, (menu, issues) =>
            {
                var found = Find(menu, i => Same(i.Origin, expected), out _);
                if (found == null) return "이 이름으로는 메뉴에 남지 못해요." + IssueOf(issues, expected);
                e.Select = found.Id;
                return found.Control.name == name ? null : "이름이 바뀌지 않았어요." + IssueOf(issues, expected);
            });
        }

        // ---------------------------------------------------------------- delete

        private static string Delete(FinalEdit e, FinalMenu.Item item)
        {
            var origin = item.Origin;
            var w = e.Work;
            switch (origin.Kind)
            {
                case MenuOriginKind.Original:
                    if (SameItemRules(e, w.hiddenItems, h => h?.source, origin.Key).Count == 0)
                        (w.hiddenItems ??= new List<MenuHideRule>()).Add(new MenuHideRule { source = origin.Key });
                    e.Note = "숨겼어요. ‘숨긴 항목’에서 다시 보이게 할 수 있어요.";
                    return null;
                case MenuOriginKind.Shortcut:
                case MenuOriginKind.Shape:
                {
                    KeepLegacyDefaults(e);
                    var list = EntriesOf(w, origin.MenuIndex);
                    list.Remove(list[origin.EntryIndex]);
                    // With no blendshape control left in any menu, the reset button has nothing to reset.
                    if (origin.Kind == MenuOriginKind.Shape && !Groups(w).Any(g => g.Entries.Any(x => x != null && x.IsShape && !x.IsShapeReset)))
                        foreach (var (_, entries) in Groups(w)) entries.RemoveAll(x => x != null && x.IsShapeReset);
                    return null;
                }
                case MenuOriginKind.FavoritesFolder:
                {
                    KeepLegacyDefaults(e);
                    RemoveEntry(EntriesOf(w, origin.MenuIndex), origin.EntryIndex);
                    return null;
                }
                case MenuOriginKind.FavoritesMenu:
                    KeepLegacyDefaults(e);
                    if (origin.MenuIndex == 0) EntriesOf(w, 0).Clear();
                    else w.additionalMenus.RemoveAt(origin.MenuIndex - 1);
                    return null;
                case MenuOriginKind.MadeFolder:
                    return Ungroup(e, origin.Id, item);
                case MenuOriginKind.LegacyFolder:
                {
                    if (Promote(e, origin.Id, out string id) is string error) return error;
                    return Ungroup(e, id, item);
                }
                default: return "이 항목은 지울 수 없어요.";
            }
        }

        // A made folder leaves and what it held takes its place, in the order shown now. Favorites menus installed in it
        // go to the menu it was in.
        private static string Ungroup(FinalEdit e, string id, FinalMenu.Item folderItem)
        {
            var w = e.Work;
            var rule = w.createdFolders.First(f => f != null && f.id == id);
            var inside = folderItem.Opens != null ? e.Now.LevelAt(e.Organizer.FirstPage(folderItem.Opens)).Items : new List<FinalMenu.Item>();
            var parent = rule.parent ?? new FavoriteMenuKey();
            string parentFolder = rule.parentFolder ?? "";
            var anchor = (Key: rule.before ?? new FavoriteMenuKey(), Folder: rule.beforeFolder ?? "");
            // What a rule can name, in order: the avatar's items by key, made folders by id.
            var placed = inside.Where(i => i.Origin.Kind == MenuOriginKind.Original || i.Origin.Kind == MenuOriginKind.MadeFolder).ToList();
            for (int i = placed.Count - 1; i >= 0; i--)
            {
                var child = placed[i].Origin;
                var next = i + 1 < placed.Count ? AnchorFor(placed[i + 1]) : anchor;
                if (child.Kind == MenuOriginKind.MadeFolder)
                {
                    var folder = w.createdFolders.First(f => f != null && f.id == child.Id);
                    folder.parent = parent;
                    folder.parentFolder = parentFolder;
                    folder.before = next.Key;
                    folder.beforeFolder = next.Folder;
                }
                else
                {
                    var moves = SameItemRules(e, w.menuMoves, m => m?.source, child.Key);
                    if (moves.Count == 0) continue;
                    Place(moves[0], parent, parentFolder, next);
                }
            }
            // Rules that put something before the folder now put it before what it held.
            var first = placed.Count > 0 ? AnchorFor(placed[0]) : anchor;
            foreach (var move in w.menuMoves ?? new List<MenuMoveRule>())
            {
                if (move == null) continue;
                if (move.beforeFolder == id) { move.before = first.Key; move.beforeFolder = first.Folder; }
                // Anything else still aimed inside (a move that did not land) goes where the folder was.
                if (move.destinationFolder == id) Place(move, parent, parentFolder, anchor);
            }
            foreach (var folder in w.createdFolders)
            {
                if (folder == null || folder == rule) continue;
                if (folder.beforeFolder == id) { folder.before = first.Key; folder.beforeFolder = first.Folder; }
                if (folder.parentFolder == id) { folder.parent = parent; folder.parentFolder = parentFolder; }
            }
            int reinstalled = 0;
            for (int index = 0; index <= (w.additionalMenus?.Count ?? 0); index++)
            {
                var group = w.GetMenu(index);
                if (group == null || !group.InFolder || group.destinationFolder != id) continue;
                if (parentFolder.Length > 0) SetInstall(w, index, false, group.destination, parentFolder);
                else if (parent.IsEmpty) SetInstall(w, index, true, group.destination, "");
                else
                {
                    var key = OrganizedKeyOfLevel(e, e.Now.LevelAt(e.Organizer.FirstPage(LevelOfItem(e.Now, folderItem).First)));
                    if (key == null) return "폴더 안의 즐겨찾기 메뉴를 옮길 곳을 찾지 못했어요.";
                    SetInstall(w, index, false, key, "");
                }
                reinstalled++;
            }
            w.createdFolders.Remove(rule);
            if (reinstalled > 0) e.Note = "폴더 안에 있던 즐겨찾기 메뉴는 폴더가 있던 메뉴에 다시 설치했어요.";
            return Later(e, (menu, issues) =>
                placed.All(p => Find(menu, i => Same(i.Origin, p.Origin), out _) != null) ? null : "폴더를 풀면 안의 항목이 메뉴에서 빠져요.");
        }

        private static void Place(MenuMoveRule move, FavoriteMenuKey parent, string parentFolder, (FavoriteMenuKey Key, string Folder) anchor)
        {
            move.positioned = true;
            move.newFolder = "";
            move.destination = parent;
            move.destinationFolder = parentFolder;
            move.before = anchor.Key;
            move.beforeFolder = anchor.Folder;
        }

        private static (FavoriteMenuKey Key, string Folder) AnchorFor(FinalMenu.Item item) =>
            item.Origin.Kind == MenuOriginKind.MadeFolder ? (new FavoriteMenuKey(), item.Origin.Id) : (item.Origin.Key, "");

        // ---------------------------------------------------------------- move

        // Why item cannot go before `before` in level (null: it may; the edit itself checks where it really lands). Quick
        // enough for a drag passing over rows.
        internal static string CanMove(AvatarCustomizer settings, FinalMenu now, FinalMenu.Item item, FinalMenu.Level level, FinalMenu.Item before)
        {
            var organizer = now.Composition.Organizer;
            bool favorites = level.Where.Kind == MenuLevelKind.Favorites;
            if (level.Where.Kind == MenuLevelKind.Unknown) return "여기에는 놓을 수 없어요.";
            if (before != null && before.Control == item.Control) return NoChange;
            if (item.Opens != null && Reaches(organizer, item.Opens, level.First)) return "메뉴를 자기 안으로 옮길 수 없어요.";
            switch (item.Origin.Kind)
            {
                case MenuOriginKind.Original: return null;
                case MenuOriginKind.Shortcut:
                    return favorites || IsPairedShortcut(settings, now, item) ? null : "바로가기는 즐겨찾기 안에서만 옮길 수 있어요. 원본을 옮기려면 원본 항목을 옮기세요.";
                case MenuOriginKind.Shape:
                    return favorites ? null : "즐겨찾기 항목은 즐겨찾기 안에서만 옮길 수 있어요.";
                case MenuOriginKind.FavoritesFolder:
                    if (!favorites) return "즐겨찾기 폴더는 즐겨찾기 안에서만 옮길 수 있어요.";
                    if (settings && level.Where.MenuIndex == item.Origin.MenuIndex &&
                        IsWithin(EntriesOf(settings, level.Where.MenuIndex), level.Where.Id, item.Origin.Id))
                        return "폴더를 자기 안으로 옮길 수 없어요.";
                    return null;
                case MenuOriginKind.FavoritesMenu:
                    if (favorites) return "즐겨찾기 메뉴 안에는 즐겨찾기 메뉴를 넣을 수 없어요.";
                    if (before == null) return null;
                    var full = now.LevelAt(organizer.FirstPage(level.First));
                    int at = full.Items.FindIndex(i => i.Control == before.Control);
                    bool front = at >= 0 && full.Items.Take(at).All(i => i.Control == item.Control ||
                        i.Origin.Kind == MenuOriginKind.FavoritesMenu && settings && settings.GetMenu(i.Origin.MenuIndex)?.pinToFirstPage == true);
                    return front ? null : "즐겨찾기 메뉴는 첫 페이지 맨 앞(고정)이나 맨 끝에만 놓을 수 있어요.";
                case MenuOriginKind.MadeFolder:
                case MenuOriginKind.LegacyFolder:
                    return favorites ? "새 폴더는 즐겨찾기 안으로 옮길 수 없어요. 즐겨찾기에는 즐겨찾기 폴더를 만드세요." : null;
                default: return "이 항목은 옮길 수 없어요.";
            }
        }

        private static string Move(FinalEdit e, FinalMenu.Item item, FinalMenu.Level level, FinalMenu.Item before, bool home)
        {
            if (CanMove(e.Work, e.Now, item, level, before) is string refused) return refused;
            var origin = item.Origin;
            var target = level.Where;
            bool favorites = target.Kind == MenuLevelKind.Favorites;
            var here = LevelOfItem(e.Now, item);
            // Dropped where it is already, it changes nothing, unless its rule lost what it was placed before: then it is
            // saved again for where it is now, which clears the warning.
            if (here != null && SameLevel(here.Where, target) && Next(e.Now, here, item)?.Control == before?.Control && !LostAnchor(e, item))
                return NoChange;
            switch (origin.Kind)
            {
                case MenuOriginKind.Original:
                    return favorites ? Pair(e, item, level, before) : MoveOriginal(e, item, origin.Key, level, before, home);
                case MenuOriginKind.Shortcut:
                    if (favorites) return MoveEntry(e, item, level, before);
                    if (!IsPairedShortcut(e.Work, e.Now, item))
                        return "바로가기는 즐겨찾기 안에서만 옮길 수 있어요. 원본을 옮기려면 원본 항목을 옮기세요.";
                    if (origin.Key == null) return "바로가기의 원본을 찾지 못했어요.";
                    Unpair(e, origin);
                    return MoveOriginal(e, item, origin.Key, level, before, home);
                case MenuOriginKind.Shape:
                case MenuOriginKind.FavoritesFolder:
                    return favorites ? MoveEntry(e, item, level, before) : "즐겨찾기 항목은 즐겨찾기 안에서만 옮길 수 있어요.";
                case MenuOriginKind.FavoritesMenu:
                    return favorites ? "즐겨찾기 메뉴 안에는 즐겨찾기 메뉴를 넣을 수 없어요." : MoveFavoritesMenu(e, item, level, before);
                case MenuOriginKind.MadeFolder:
                    return favorites ? "새 폴더는 즐겨찾기 안으로 옮길 수 없어요. 즐겨찾기에는 즐겨찾기 폴더를 만드세요." : MoveFolder(e, item, origin.Id, level, before);
                case MenuOriginKind.LegacyFolder:
                {
                    if (favorites) return "이 폴더는 즐겨찾기 안으로 옮길 수 없어요.";
                    if (Promote(e, origin.Id, out string id) is string error) return error;
                    return MoveFolder(e, item, id, level, before);
                }
                default: return "이 항목은 옮길 수 없어요.";
            }
        }

        // Whether the rule that places item names something to go before that is gone (from the avatar's menu, or a deleted
        // made folder), so the build put it at the end with a warning.
        private static bool LostAnchor(FinalEdit e, FinalMenu.Item item)
        {
            var w = e.Work;
            bool Lost(FavoriteMenuKey before, string beforeFolder) =>
                !string.IsNullOrEmpty(beforeFolder) ? w.createdFolders?.Any(f => f != null && f.id == beforeFolder) != true :
                !(before?.IsEmpty ?? true) && FavoriteMenuKey.Resolve(e.Organizer.Original, before) == null;
            if (item.Origin.Kind == MenuOriginKind.Original)
                return SameItemRules(e, w.menuMoves, m => m?.source, item.Origin.Key).Any(m => m.positioned && Lost(m.before, m.beforeFolder));
            if (item.Origin.Kind == MenuOriginKind.MadeFolder)
                return w.createdFolders?.FirstOrDefault(f => f != null && f.id == item.Origin.Id) is MenuFolderRule rule && Lost(rule.before, rule.beforeFolder);
            return false;
        }

        // One of the avatar's items into a menu level the organizer makes: its first move rule takes the place (a rule
        // without a place becomes one), and later rules for it go. Back where it was in the avatar's menu (home), it needs
        // no rule.
        private static string MoveOriginal(FinalEdit e, FinalMenu.Item item, FavoriteMenuKey key, FinalMenu.Level level,
            FinalMenu.Item before, bool home)
        {
            var w = e.Work;
            var anchor = Anchor(level, before, item);
            if (!TargetOf(e, level.Where, out var destination, out string folder, out string error)) return error;
            var moves = SameItemRules(e, w.menuMoves, m => m?.source, key);
            if (home)
            {
                var parent = e.Organizer.OriginalParentOf(key);
                bool sameLevel = level.Where.Kind == MenuLevelKind.Root ? parent == null :
                    level.Where.Kind == MenuLevelKind.Original && parent != null && Same(level.Where.Key, parent);
                // Its neighbours that are hidden or moved away no longer say where it goes: the next one still shown does.
                var full = e.Now.LevelAt(e.Organizer.FirstPage(level.First));
                bool Shown(FavoriteMenuKey k) => full.Items.Any(i => i.Origin.Kind == MenuOriginKind.Original && Same(i.Origin.Key, k));
                var next = e.Organizer.OriginalNextOf(key);
                while (next != null && !Shown(next)) next = e.Organizer.OriginalNextOf(next);
                bool sameSpot = anchor.Folder.Length == 0 && (next == null ? anchor.Key.IsEmpty : Same(anchor.Key, next));
                if (!sameLevel || !sameSpot) return "not home";
                foreach (var move in moves) w.menuMoves.Remove(move);
            }
            else
            {
                foreach (var move in moves.Skip(1)) w.menuMoves.Remove(move);
                if (moves.Count == 0) (w.menuMoves ??= new List<MenuMoveRule>()).Add(new MenuMoveRule { source = key });
                var rule = moves.Count > 0 ? moves[0] : w.menuMoves.Last();
                Place(rule, destination, folder, anchor);
            }
            return CheckPlace(e, i => i.Origin.Kind == MenuOriginKind.Original && Same(i.Origin.Key, key), level, before, folder);
        }

        private static string MoveFolder(FinalEdit e, FinalMenu.Item item, string id, FinalMenu.Level level, FinalMenu.Item before)
        {
            if (level.Where.Kind == MenuLevelKind.MadeFolder && level.Where.Id == id) return "폴더를 자기 안으로 옮길 수 없어요.";
            var anchor = Anchor(level, before, item);
            if (!TargetOf(e, level.Where, out var destination, out string folder, out string error)) return error;
            var rule = e.Work.createdFolders.First(f => f != null && f.id == id);
            rule.parent = destination;
            rule.parentFolder = folder;
            rule.before = anchor.Key;
            rule.beforeFolder = anchor.Folder;
            return CheckPlace(e, i => i.Origin.Kind == MenuOriginKind.MadeFolder && i.Origin.Id == id, level, before, folder);
        }

        // A favorites menu button goes into a menu level only at the front of its first page (pinned) or at its end.
        private static string MoveFavoritesMenu(FinalEdit e, FinalMenu.Item item, FinalMenu.Level level, FinalMenu.Item before)
        {
            var origin = item.Origin;
            bool pin;
            if (before == null) pin = false;
            else
            {
                // The pinned front: the items before `before` in the level are all pinned favorites menus.
                var full = e.Now.LevelAt(e.Organizer.FirstPage(level.First));
                int at = full.Items.FindIndex(i => i.Control == before.Control);
                pin = at >= 0 && full.Items.Take(at).All(i => i.Control == item.Control || IsPinnedMenu(e.Work, i));
                if (!pin) return "즐겨찾기 메뉴는 첫 페이지 맨 앞(고정)이나 맨 끝에만 놓을 수 있어요.";
            }
            string folder = "";
            FavoriteMenuKey destination = null;
            bool root = false;
            switch (level.Where.Kind)
            {
                case MenuLevelKind.Root: root = true; break;
                case MenuLevelKind.MadeFolder: folder = level.Where.Id; break;
                case MenuLevelKind.LegacyFolder:
                    if (Promote(e, level.Where.Id, out folder) is string error) return error;
                    break;
                case MenuLevelKind.Original:
                    destination = OrganizedKeyOfLevel(e, level);
                    if (destination == null) return "이 메뉴는 즐겨찾기 메뉴를 설치할 곳으로 가리킬 수 없어요.";
                    break;
                default: return "여기에는 즐겨찾기 메뉴를 놓을 수 없어요.";
            }
            SetInstall(e.Work, origin.MenuIndex, root, destination ?? e.Work.GetMenu(origin.MenuIndex).destination, folder);
            if (origin.MenuIndex == 0) e.Work.pinToFirstPage = pin;
            else e.Work.additionalMenus[origin.MenuIndex - 1].pinToFirstPage = pin;
            return CheckPlace(e, i => i.Origin.Kind == MenuOriginKind.FavoritesMenu && i.Origin.MenuIndex == origin.MenuIndex, level, before, folder,
                "즐겨찾기 메뉴끼리의 순서는 메뉴 순서(즐겨찾기 편집 탭)를 따라서, 그 자리에는 놓을 수 없어요.");
        }

        private static bool IsPinnedMenu(AvatarCustomizer w, FinalMenu.Item item) =>
            item.Origin.Kind == MenuOriginKind.FavoritesMenu && w.GetMenu(item.Origin.MenuIndex)?.pinToFirstPage == true;

        // A favorites entry (a shortcut, blendshape control or folder with all it holds) to a place in a favorites level.
        private static string MoveEntry(FinalEdit e, FinalMenu.Item item, FinalMenu.Level level, FinalMenu.Item before)
        {
            var origin = item.Origin;
            var w = e.Work;
            var from = EntriesOf(w, origin.MenuIndex);
            var entry = from[origin.EntryIndex];
            int into = level.Where.MenuIndex;
            string parent = level.Where.Id ?? "";
            var to = EntriesOf(w, into);
            if (entry.IsFolder && (parent == entry.folderId || (from == to && IsWithin(to, parent, entry.folderId))))
                return "폴더를 자기 안으로 옮길 수 없어요.";
            var anchor = EntryBefore(w, before, into);
            KeepLegacyDefaults(e);
            var moving = new List<FavoriteMenuEntry> { entry };
            if (entry.IsFolder && from != to) moving.AddRange(from.Where(x => x != null && x != entry && IsWithin(from, x.Parent, entry.folderId)));
            foreach (var x in moving) from.Remove(x);
            entry.parentId = parent;
            int at = InsertAt(to, parent, anchor);
            to.Insert(at, entry);
            to.AddRange(moving.Skip(1));
            return CheckEntry(e, entry, into, level, before);
        }

        // One of the avatar's items into favorites: a shortcut there and the original hidden, as one edit that can be taken
        // back. When no shortcut comes of it, nothing is kept.
        private static string Pair(FinalEdit e, FinalMenu.Item item, FinalMenu.Level level, FinalMenu.Item before)
        {
            var source = ShortcutKey(e, item, out string error);
            if (source == null) return error;
            string pair = Guid.NewGuid().ToString("N");
            var w = e.Work;
            int into = level.Where.MenuIndex;
            string parent = level.Where.Id ?? "";
            var to = EntriesOf(w, into);
            var entry = new FavoriteMenuEntry { source = source, parentId = parent, pairId = pair };
            to.Insert(InsertAt(to, parent, EntryBefore(w, before, into)), entry);
            (w.hiddenItems ??= new List<MenuHideRule>()).Add(new MenuHideRule { source = item.Origin.Key, pairId = pair });
            e.Note = "즐겨찾기로 옮겼어요. 원래 자리에서는 숨겼고, 바로가기를 원래 메뉴로 다시 끌어 놓으면 되돌아가요.";
            return CheckEntry(e, entry, into, level, before);
        }

        private static string AddShortcut(FinalEdit e, FinalMenu.Item item, FinalMenu.Level level)
        {
            if (level.Where.Kind != MenuLevelKind.Favorites) return "즐겨찾기 메뉴나 폴더를 골라 주세요.";
            if (item.Origin.Kind != MenuOriginKind.Original) return "아바타 메뉴의 항목만 즐겨찾기에 추가할 수 있어요.";
            var source = ShortcutKey(e, item, out string error);
            if (source == null) return error;
            int into = level.Where.MenuIndex;
            string parent = level.Where.Id ?? "";
            var to = EntriesOf(e.Work, into);
            var entry = new FavoriteMenuEntry { source = source, parentId = parent };
            to.Insert(InsertAt(to, parent, null), entry);
            return CheckEntry(e, entry, into, level, null);
        }

        // The organized menu's key for a shortcut to item, when it names exactly that item.
        private static FavoriteMenuKey ShortcutKey(FinalEdit e, FinalMenu.Item item, out string error)
        {
            error = null;
            var key = e.Organizer.OrganizedKeyOf(item.Control);
            if (key == null || FavoriteMenuKey.Resolve(Organized(e.Organizer), key, out var match) != key || match != FavoriteMenuMatch.Exact)
            {
                error = "이 항목은 즐겨찾기에서 가리킬 수 없어요. 같은 경로와 동작의 항목이 둘 이상 있어요.";
                return null;
            }
            return key;
        }

        // A shortcut that moved one of the avatar's items into favorites: its own hide rule hides that very item (a shortcut
        // linked again to something else is a plain shortcut).
        internal static bool IsPairedShortcut(AvatarCustomizer w, FinalMenu now, FinalMenu.Item item)
        {
            if (!w || item.Origin.Kind != MenuOriginKind.Shortcut || item.Origin.Key == null) return false;
            var entry = EntriesOf(w, item.Origin.MenuIndex).ElementAtOrDefault(item.Origin.EntryIndex);
            if (string.IsNullOrEmpty(entry?.pairId)) return false;
            var hide = w.hiddenItems?.FirstOrDefault(h => h?.pairId == entry.pairId);
            var hidden = hide?.source == null ? null : FavoriteMenuKey.Resolve(now.Composition.Organizer.Original, hide.source);
            return Same(hidden, item.Origin.Key);
        }

        // The shortcut goes and its original shows again, where its own move rules put it.
        private static void Unpair(FinalEdit e, MenuOrigin origin)
        {
            var list = EntriesOf(e.Work, origin.MenuIndex);
            var entry = list[origin.EntryIndex];
            KeepLegacyDefaults(e);
            e.Work.hiddenItems.RemoveAll(h => h?.pairId == entry.pairId);
            list.Remove(entry);
        }

        // ---------------------------------------------------------------- new folder and restore

        private static string NewFolder(FinalEdit e, FinalMenu.Level level, FinalMenu.Item before)
        {
            var w = e.Work;
            var names = new HashSet<string>(level.Items.Select(i => i.Control.name));
            string name = "새 폴더";
            for (int n = 2; names.Contains(name); n++) name = "새 폴더 " + n;
            string id = Guid.NewGuid().ToString("N");
            if (level.Where.Kind == MenuLevelKind.Favorites)
            {
                int into = level.Where.MenuIndex;
                string parent = level.Where.Id ?? "";
                var to = EntriesOf(w, into);
                var entry = new FavoriteMenuEntry { folderId = id, parentId = parent, label = name };
                to.Insert(InsertAt(to, parent, EntryBefore(w, before, into)), entry);
                return CheckEntry(e, entry, into, level, before);
            }
            if (!TargetOf(e, level.Where, out var destination, out string folder, out string error)) return error;
            var anchor = Anchor(level, before, null);
            (w.createdFolders ??= new List<MenuFolderRule>()).Add(new MenuFolderRule
            {
                id = id, name = name, parent = destination, parentFolder = folder, before = anchor.Key, beforeFolder = anchor.Folder,
            });
            e.Note = "빈 폴더는 빌드에서 빠져요. 항목을 넣어 주세요.";
            return CheckPlace(e, i => i.Origin.Kind == MenuOriginKind.MadeFolder && i.Origin.Id == id, level, before, folder);
        }

        private static string Restore(FinalEdit e, FinalMenu.Item item)
        {
            var origin = item.Origin;
            var w = e.Work;
            if (origin.Kind == MenuOriginKind.Original)
            {
                var renames = SameItemRules(e, w.nameOverrides, r => r?.source, origin.Key);
                var moves = SameItemRules(e, w.menuMoves, m => m?.source, origin.Key);
                if (renames.Count + moves.Count == 0) return NoChange;
                foreach (var rule in renames) w.nameOverrides.Remove(rule);
                foreach (var rule in moves) w.menuMoves.Remove(rule);
                return null;
            }
            if (!IsPairedShortcut(w, e.Now, item)) return "되돌릴 것이 없어요.";
            if (origin.Key == null) return "바로가기의 원본을 찾지 못했어요.";
            Unpair(e, origin);
            var key = origin.Key;
            return Later(e, (menu, issues) =>
            {
                var found = Find(menu, i => i.Origin.Kind == MenuOriginKind.Original && Same(i.Origin.Key, key), out _);
                if (found == null) e.Note = "원본을 다시 보이게 했지만, 숨긴 메뉴 안에 있어서 아직 메뉴에 나오지 않아요.";
                else e.Select = found.Id;
                return null;
            });
        }

        // ---------------------------------------------------------------- the old "새 최상위 폴더"

        // A top-level folder made by name by moves without a place (before 2.7.0) becomes a made folder in the same spot,
        // with those moves into it, before it is edited. Nothing in the built menu changes.
        private static string Promote(FinalEdit e, string name, out string id)
        {
            id = null;
            var w = e.Work;
            var control = e.Organizer.LegacyFolders.FirstOrDefault(p => p.Value == name).Key;
            var item = control == null ? null : Find(e.Now, i => i.Control == control, out _);
            if (item == null) return "폴더를 찾지 못했어요.";
            var level = LevelOfItem(e.Now, item);
            // An old-style folder cannot be named as "before", so the ones right after this one change kind with it.
            var chain = new List<FinalMenu.Item>();
            for (var at = item; at != null && at.Origin.Kind == MenuOriginKind.LegacyFolder; at = Next(e.Now, level, at)) chain.Add(at);
            var keys = Organized(e.Organizer);
            foreach (var folder in chain)
            {
                // Shortcuts name the organized menu by path, never a made folder: one that opens such a folder would break.
                var key = e.Organizer.OrganizedKeyOf(folder.Control);
                if (Groups(w).Any(g => g.Entries.Any(x => x != null && !x.IsFolder && !x.IsShape && FavoriteMenuKey.Resolve(keys, x.source) == key)))
                    return $"‘{folder.Origin.Id}’ 폴더를 여는 즐겨찾기 바로가기가 있어서 편집할 수 없어요. 원본 메뉴 정리 탭에서 바꿔 주세요.";
            }
            var anchor = Anchor(level, Next(e.Now, level, chain[chain.Count - 1]), chain[chain.Count - 1]);
            for (int i = chain.Count - 1; i >= 0; i--)
            {
                string folderName = chain[i].Origin.Id, folderId = Guid.NewGuid().ToString("N");
                var key = e.Organizer.OrganizedKeyOf(chain[i].Control);
                (w.createdFolders ??= new List<MenuFolderRule>()).Add(new MenuFolderRule
                {
                    id = folderId, name = folderName, parent = new FavoriteMenuKey(), parentFolder = "", before = anchor.Key, beforeFolder = anchor.Folder,
                });
                foreach (var move in w.menuMoves ?? new List<MenuMoveRule>())
                    if (move?.source != null && !move.positioned && move.Folder == folderName)
                        Place(move, new FavoriteMenuKey(), folderId, (new FavoriteMenuKey(), ""));
                for (int index = 0; index <= (w.additionalMenus?.Count ?? 0); index++)
                {
                    var group = w.GetMenu(index);
                    if (group != null && !group.useRoot && !group.InFolder && FavoriteMenuKey.Resolve(keys, group.destination) == key)
                        SetInstall(w, index, false, group.destination, folderId);
                }
                if (folderName == name) id = folderId;
                anchor = (new FavoriteMenuKey(), folderId);
            }
            return null;
        }

        // Favorites settings name the organized menu by path. An edit that moves an item (or a submenu with what it holds)
        // changes those paths, so each shortcut, install place and starting value that named an item before is pointed
        // at the same item again.
        private static string Repoint(FinalEdit e)
        {
            var w = e.Work;
            var before = Organized(e.Organizer);
            var links = new List<(Func<FavoriteMenuKey> Get, Action<FavoriteMenuKey> Set, FavoriteMenuKey Original)>();
            void Link(Func<FavoriteMenuKey> get, Action<FavoriteMenuKey> set)
            {
                var saved = get();
                var key = saved == null || saved.IsEmpty ? null : FavoriteMenuKey.Resolve(before, saved);
                var original = key == null ? null : e.Organizer.OriginalKeyOf(e.Organizer.OrganizedItems[key]);
                if (original != null) links.Add((get, set, original));
            }
            foreach (var (_, entries) in Groups(w))
                foreach (var entry in entries)
                    if (entry != null && !entry.IsFolder && !entry.IsShape) Link(() => entry.source, k => entry.source = k);
            if (!w.useRoot && string.IsNullOrEmpty(w.destinationFolder)) Link(() => w.destination, k => w.destination = k);
            foreach (var group in w.additionalMenus ?? new List<FavoriteMenuGroup>())
                if (group != null && !group.useRoot && !group.InFolder) Link(() => group.destination, k => group.destination = k);
            foreach (var rule in w.defaultOverrides ?? new List<MenuDefaultOverride>())
                if (rule != null) Link(() => rule.source, k => rule.source = k);
            if (links.Count == 0) return null;
            var composition = e.Context.Compose(w, new List<FavoriteMenuBuilder.Issue>());
            try
            {
                var organizer = composition.Organizer;
                var after = Organized(organizer);
                foreach (var link in links)
                {
                    var now = FavoriteMenuKey.Resolve(after, link.Get(), out var match);
                    var wanted = after.FirstOrDefault(k => Same(organizer.OriginalKeyOf(organizer.OrganizedItems[k]), link.Original));
                    if (wanted == null || (now == wanted && match == FavoriteMenuMatch.Exact)) continue;
                    // A key that would name two items alike is no better than the one there.
                    if (FavoriteMenuKey.Resolve(after, wanted, out var check) != wanted || check != FavoriteMenuMatch.Exact)
                        return $"그 자리로 옮기면 즐겨찾기가 가리키는 ‘{wanted.displayName ?? wanted.Name}’을 같은 경로·동작의 다른 항목과 구별할 수 없어요.";
                    link.Set(wanted);
                }
            }
            finally { composition.Destroy(); }
            return null;
        }

        // The edit's own check, and then that the build still keeps every favorites entry and menu it kept before, unless
        // the edit took it out of the settings: no edit may make something else drop out (a name clash, a loop, a
        // shortcut that no longer finds its item).
        private static string Verify(FinalEdit e) => e.Check((menu, issues) =>
        {
            if (e.Verify?.Invoke(menu, issues) is string error) return error;
            var kept = Kept(menu, e.Work);
            foreach (var thing in e.KeptBefore)
            {
                if (kept.Contains(thing) || !StillThere(e.Work, thing)) continue;
                return $"이렇게 바꾸면 ‘{Describe(thing)}’이(가) 빌드에서 빠져서 바꾸지 않았어요.";
            }
            return null;
        });

        // The favorites entries and menus a final menu built, as objects of the settings it was worked out from.
        // Leaves a check for after Repoint (Verify).
        private static string Later(FinalEdit e, Func<FinalMenu, List<FavoriteMenuBuilder.Issue>, string> check)
        {
            e.Verify = check;
            return null;
        }

        internal static HashSet<object> Kept(FinalMenu menu, AvatarCustomizer settings)
        {
            var kept = new HashSet<object>();
            foreach (var level in Levels(menu))
                foreach (var item in level.Items)
                {
                    if (item.Dropped) continue;
                    var origin = item.Origin;
                    switch (origin.Kind)
                    {
                        case MenuOriginKind.FavoritesMenu:
                            kept.Add(origin.MenuIndex == 0 ? (object)settings : settings.additionalMenus[origin.MenuIndex - 1]);
                            break;
                        case MenuOriginKind.Shortcut:
                        case MenuOriginKind.Shape:
                        case MenuOriginKind.FavoritesFolder:
                            kept.Add(EntriesOf(settings, origin.MenuIndex)[origin.EntryIndex]);
                            break;
                    }
                }
            return kept;
        }

        private static bool StillThere(AvatarCustomizer w, object thing) =>
            ReferenceEquals(thing, w) ? (w.entries?.Count ?? 0) > 0 :
            thing is FavoriteMenuGroup group ? w.additionalMenus?.Contains(group) == true :
            thing is FavoriteMenuEntry entry && Groups(w).Any(g => g.Entries.Contains(entry));

        private static string Describe(object thing) =>
            thing is AvatarCustomizer c ? c.GetMenu(0).DisplayName :
            thing is FavoriteMenuGroup group ? group.DisplayName :
            thing is FavoriteMenuEntry entry ? (!string.IsNullOrWhiteSpace(entry.label) ? entry.label.Trim() : entry.source?.Name ?? "항목") : "항목";

        // ---------------------------------------------------------------- checks

        // After the edit, the item (match) is in level, right before `before` (or last).
        private static string CheckPlace(FinalEdit e, Func<FinalMenu.Item, bool> match, FinalMenu.Level level, FinalMenu.Item before,
            string promotedFolder, string refusal = null)
        {
            var where = level.Where.Kind == MenuLevelKind.LegacyFolder
                ? new MenuLevel { Kind = MenuLevelKind.MadeFolder, Id = promotedFolder }
                : level.Where;
            string wanted = before?.Id;
            return Later(e, (menu, issues) =>
            {
                var found = Find(menu, match, out var at);
                if (found == null || !SameLevel(at.Where, where)) return refusal ?? "그 자리에 놓을 수 없어요.";
                if (!Lands(menu, at, found, wanted)) return refusal ?? "그 자리에는 놓을 수 없어요. 고정한 즐겨찾기 메뉴 사이처럼 규칙으로 정할 수 없는 자리예요.";
                e.Select = found.Id;
                return null;
            });
        }

        // Whether found sits right before the item with id wanted; with none wanted, after every item the organizer places
        // (favorites menu buttons go in after it, at the end, so they may follow).
        private static bool Lands(FinalMenu menu, FinalMenu.Level level, FinalMenu.Item found, string wanted)
        {
            if (wanted != null) return Next(menu, level, found)?.Id == wanted;
            var full = menu.LevelAt(menu.Composition.Organizer.FirstPage(level.First));
            int at = full.Items.FindIndex(i => i.Control == found.Control);
            return at >= 0 && full.Items.Skip(at + 1).All(i => i.Origin.Kind == MenuOriginKind.FavoritesMenu);
        }

        private static string CheckEntry(FinalEdit e, FavoriteMenuEntry entry, int menuIndex, FinalMenu.Level level, FinalMenu.Item before)
        {
            int index = EntriesOf(e.Work, menuIndex).IndexOf(entry);
            string wanted = before?.Id;
            return Later(e, (menu, issues) =>
            {
                var found = Find(menu, i => i.Origin.MenuIndex == menuIndex && i.Origin.EntryIndex == index &&
                                            (i.Origin.Kind == MenuOriginKind.Shortcut || i.Origin.Kind == MenuOriginKind.Shape ||
                                             i.Origin.Kind == MenuOriginKind.FavoritesFolder), out var at);
                if (found == null)
                    return "즐겨찾기에 넣을 수 없어요." + IssueOf(issues.Where(i => i.MenuIndex == menuIndex && i.ItemIndex == index), null);
                if (!SameLevel(at.Where, level.Where) || Next(menu, at, found)?.Id != wanted) return "그 자리에 놓을 수 없어요.";
                e.Select = found.Id;
                return null;
            });
        }

        private static string IssueOf(IEnumerable<FavoriteMenuBuilder.Issue> issues, MenuOrigin origin)
        {
            var issue = issues.Where(i => origin == null || i.MenuIndex == origin.MenuIndex && i.ItemIndex == origin.EntryIndex)
                .FirstOrDefault(i => i.Warning);
            return issue == null ? "" : $" ({issue.Detail})";
        }

        // ---------------------------------------------------------------- finding things

        // Every level of the final menu from the top, each once (whole, from its first page).
        internal static IEnumerable<FinalMenu.Level> Levels(FinalMenu menu)
        {
            if (!menu.Root) yield break;
            var organizer = menu.Composition.Organizer;
            var seen = new HashSet<VRCExpressionsMenu>();
            var pending = new Queue<VRCExpressionsMenu>();
            pending.Enqueue(menu.Root);
            seen.Add(menu.Root);
            while (pending.Count > 0)
            {
                var level = menu.LevelAt(pending.Dequeue());
                yield return level;
                foreach (var item in level.Items)
                {
                    if (item.Opens == null) continue;
                    var first = organizer.FirstPage(item.Opens);
                    if (seen.Add(first)) pending.Enqueue(first);
                }
            }
        }

        internal static FinalMenu.Item Find(FinalMenu menu, Func<FinalMenu.Item, bool> match, out FinalMenu.Level level)
        {
            foreach (var candidate in Levels(menu))
            {
                var item = candidate.Items.FirstOrDefault(match);
                if (item == null) continue;
                level = candidate;
                return item;
            }
            level = null;
            return null;
        }

        // The whole level an item sits in.
        internal static FinalMenu.Level LevelOfItem(FinalMenu menu, FinalMenu.Item item) =>
            Levels(menu).FirstOrDefault(l => l.Items.Contains(item)) ??
            Levels(menu).FirstOrDefault(l => l.Items.Any(i => i.Control == item.Control));

        // The item after item in its whole level, or null at the end.
        internal static FinalMenu.Item Next(FinalMenu menu, FinalMenu.Level level, FinalMenu.Item item)
        {
            var full = menu.LevelAt(menu.Composition.Organizer.FirstPage(level.First ?? menu.Root));
            int at = full.Items.FindIndex(i => i == item || i.Control == item.Control);
            return at >= 0 && at + 1 < full.Items.Count ? full.Items[at + 1] : null;
        }

        internal static bool SameLevel(MenuLevel a, MenuLevel b)
        {
            if (a == null || b == null || a.Kind != b.Kind) return false;
            switch (a.Kind)
            {
                case MenuLevelKind.Root: return true;
                case MenuLevelKind.Original: return Same(a.Key, b.Key);
                case MenuLevelKind.Favorites: return a.MenuIndex == b.MenuIndex && (a.Id ?? "") == (b.Id ?? "");
                default: return a.Id == b.Id;
            }
        }

        // The same item of the avatar's menu, from the same read (keys of two compositions of one read are alike).
        internal static bool Same(FavoriteMenuKey a, FavoriteMenuKey b) =>
            a != null && b != null && a.sharedControl == b.sharedControl && a.SamePath(b) && a.SameBinding(b);

        private static bool Same(MenuOrigin a, MenuOrigin b)
        {
            if (a.Kind != b.Kind) return false;
            switch (a.Kind)
            {
                case MenuOriginKind.Original: return Same(a.Key, b.Key);
                case MenuOriginKind.MadeFolder:
                case MenuOriginKind.LegacyFolder: return a.Id == b.Id;
                case MenuOriginKind.FavoritesMenu: return a.MenuIndex == b.MenuIndex;
                default: return a.MenuIndex == b.MenuIndex && a.EntryIndex == b.EntryIndex;
            }
        }

        private static bool Reaches(MenuOrganizer organizer, VRCExpressionsMenu from, VRCExpressionsMenu to) =>
            FavoriteMenuBuilder.Reaches(organizer.FirstPage(from), organizer.FirstPage(to), null, new HashSet<VRCExpressionsMenu>()) ||
            FavoriteMenuBuilder.Reaches(from, to, null, new HashSet<VRCExpressionsMenu>());

        // The rules (in list order) that name the same item of the avatar's menu as key.
        private static List<T> SameItemRules<T>(FinalEdit e, List<T> list, Func<T, FavoriteMenuKey> source, FavoriteMenuKey key) =>
            list?.Where(r => source(r) != null && FavoriteMenuKey.Resolve(e.Organizer.Original, source(r)) is FavoriteMenuKey k && Same(k, key)).ToList()
            ?? new List<T>();

        // The organized menu's items a favorites setting can name (made folders are named by id instead).
        private static FavoriteMenuKey[] Organized(MenuOrganizer organizer) => organizer.Organized.Where(k => k.createdFolder == null).ToArray();

        // The organized key of the avatar's submenu shown as level, for a favorites menu to be installed in.
        private static FavoriteMenuKey OrganizedKeyOfLevel(FinalEdit e, FinalMenu.Level level)
        {
            var key = e.Organizer.OrganizedKeyOfMenu(level.First);
            return key != null && FavoriteMenuKey.Resolve(Organized(e.Organizer), key, out var match) == key && match == FavoriteMenuMatch.Exact ? key : null;
        }

        // The rule fields for a level the organizer makes: the avatar's submenu by key, a made folder by id, the top level
        // with neither. An old-style folder becomes a made folder first.
        private static bool TargetOf(FinalEdit e, MenuLevel level, out FavoriteMenuKey destination, out string folder, out string error)
        {
            destination = new FavoriteMenuKey();
            folder = "";
            error = null;
            switch (level.Kind)
            {
                case MenuLevelKind.Root: return true;
                case MenuLevelKind.Original: destination = level.Key; return true;
                case MenuLevelKind.MadeFolder:
                    if (e.Work.createdFolders?.Any(f => f != null && f.id == level.Id) != true) break;
                    folder = level.Id;
                    return true;
                case MenuLevelKind.LegacyFolder:
                    error = Promote(e, level.Id, out folder);
                    return error == null;
            }
            error ??= "여기에는 놓을 수 없어요.";
            return false;
        }

        // What a rule names as "before": the first item from `before` on that a rule can name (the avatar's item by key,
        // a made folder by id), skipping the moving item; none means the end. Favorites menu buttons cannot be named, and
        // they go in after the organizing anyway.
        private static (FavoriteMenuKey Key, string Folder) Anchor(FinalMenu.Level level, FinalMenu.Item before, FinalMenu.Item moving)
        {
            int at = before == null ? -1 : level.Items.FindIndex(i => i.Control == before.Control);
            for (int i = at; i >= 0 && i < level.Items.Count; i++)
            {
                var item = level.Items[i];
                if (item.Control == moving?.Control) continue;
                if (item.Origin.Kind == MenuOriginKind.Original) return (item.Origin.Key, "");
                if (item.Origin.Kind == MenuOriginKind.MadeFolder) return (new FavoriteMenuKey(), item.Origin.Id);
            }
            return (new FavoriteMenuKey(), "");
        }

        // ---------------------------------------------------------------- favorites lists

        internal static List<FavoriteMenuEntry> EntriesOf(AvatarCustomizer c, int index) =>
            index == 0 ? c.entries ??= new List<FavoriteMenuEntry>() : c.additionalMenus[index - 1].entries ??= new List<FavoriteMenuEntry>();

        private static IEnumerable<(int Index, List<FavoriteMenuEntry> Entries)> Groups(AvatarCustomizer c)
        {
            yield return (0, c.entries ?? new List<FavoriteMenuEntry>());
            for (int i = 0; i < (c.additionalMenus?.Count ?? 0); i++)
                if (c.additionalMenus[i] != null) yield return (i + 1, c.additionalMenus[i].entries ?? new List<FavoriteMenuEntry>());
        }

        private static FavoriteMenuEntry EntryOf(FinalEdit e, MenuOrigin origin) => EntriesOf(e.Work, origin.MenuIndex)[origin.EntryIndex];

        // The entry a favorites item shown in menu `index` stands for, when it is one there.
        private static FavoriteMenuEntry EntryBefore(AvatarCustomizer w, FinalMenu.Item before, int index) =>
            before != null && before.Origin.MenuIndex == index && before.Origin.EntryIndex >= 0 &&
            (before.Origin.Kind == MenuOriginKind.Shortcut || before.Origin.Kind == MenuOriginKind.Shape || before.Origin.Kind == MenuOriginKind.FavoritesFolder)
                ? EntriesOf(w, index).ElementAtOrDefault(before.Origin.EntryIndex)
                : null;

        // Where an entry goes to show before `before` (an entry of the same folder), or after the folder's last entry.
        private static int InsertAt(List<FavoriteMenuEntry> list, string parent, FavoriteMenuEntry before)
        {
            int at = before == null ? -1 : list.IndexOf(before);
            if (at >= 0) return at;
            int last = list.FindLastIndex(x => x != null && x.Parent == parent);
            return last < 0 ? list.Count : last + 1;
        }

        // Whether folder `id` is `parent` or holds it.
        private static bool IsWithin(List<FavoriteMenuEntry> list, string parent, string id)
        {
            var seen = new HashSet<string>();
            for (string at = parent ?? ""; at.Length > 0 && seen.Add(at); at = list.FirstOrDefault(x => x != null && x.folderId == at)?.Parent ?? "")
                if (at == id) return true;
            return false;
        }

        // Removes a favorites entry; a folder's contents take its place (as the favorites tab does).
        internal static void RemoveEntry(List<FavoriteMenuEntry> entries, int index)
        {
            var entry = entries[index];
            entries.RemoveAt(index);
            if (!entry.IsFolder) return;
            var children = entries.Where(e => e != null && e.Parent == entry.folderId).ToArray();
            var following = entries.Skip(index).FirstOrDefault(e => e != null && e.Parent == entry.Parent);
            foreach (var child in children) { entries.Remove(child); child.parentId = entry.Parent; }
            entries.InsertRange(following == null ? entries.Count : entries.IndexOf(following), children);
        }

        private static void SetInstall(AvatarCustomizer w, int index, bool root, FavoriteMenuKey destination, string folder)
        {
            if (index == 0)
            {
                w.useRoot = root;
                if (destination != null) w.destination = destination;
                w.destinationFolder = folder;
                return;
            }
            var group = w.additionalMenus[index - 1];
            group.useRoot = root;
            if (destination != null) group.destination = destination;
            group.destinationFolder = folder;
        }

        // Starting values saved on favorites by 2.0.0 depend on where the favorites are (the first one for a parameter
        // wins). Before favorites are deleted or moved, the ones that count move to the shared list, which comes first.
        private static void KeepLegacyDefaults(FinalEdit e)
        {
            var w = e.Work;
            if (!Groups(w).Any(g => g.Entries.Any(x => x != null && x.overrideDefault))) return;
            var keys = Organized(e.Organizer);
            string Parameter(FavoriteMenuKey source)
            {
                var key = source == null ? null : FavoriteMenuKey.Resolve(keys, source);
                if (key == null) return null;
                var c = e.Organizer.OrganizedItems[key];
                return c.type == Control.ControlType.Toggle ? c.parameter?.name :
                    c.type == Control.ControlType.RadialPuppet ? c.subParameters?.FirstOrDefault()?.name : null;
            }
            var taken = new HashSet<string>((w.defaultOverrides ?? new List<MenuDefaultOverride>())
                .Where(o => o?.source != null).Select(o => Parameter(o.source)).Where(p => !string.IsNullOrEmpty(p)));
            w.defaultOverrides ??= new List<MenuDefaultOverride>();
            foreach (var (_, entries) in Groups(w))
                foreach (var entry in entries)
                {
                    if (entry == null || entry.IsFolder || entry.IsShape || !entry.overrideDefault) continue;
                    string parameter = Parameter(entry.source);
                    if (string.IsNullOrEmpty(parameter)) continue;
                    if (taken.Add(parameter))
                        w.defaultOverrides.Add(new MenuDefaultOverride { source = entry.source, value = entry.defaultValue });
                    entry.overrideDefault = false;
                }
        }
    }
}
#endif
