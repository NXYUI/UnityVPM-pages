#if UNITY_EDITOR
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using nadena.dev.ndmf;
using nadena.dev.ndmf.platform;
using UnityEditor;
using UnityEngine;
using VRC.SDK3.Avatars.Components;
using VRC.SDK3.Avatars.ScriptableObjects;
using Control = VRC.SDK3.Avatars.ScriptableObjects.VRCExpressionsMenu.Control;
using Object = UnityEngine.Object;

[assembly: ExportsPlugin(typeof(AvatarMenuTools.FavoriteMenuPlugin))]

namespace AvatarMenuTools
{
    public sealed class FavoriteMenuPlugin : Plugin<FavoriteMenuPlugin>
    {
        public override string QualifiedName => "dev.nxyui.avatar-customizer";
        public override string DisplayName => "Avatar Customizer";

        protected override void Configure()
        {
            InPhase(BuildPhase.Resolving).Run("Read avatar menu settings", FavoriteMenuBuilder.ReadSettings);
            InPhase(BuildPhase.Generating)
                .BeforePlugin("nadena.dev.modular-avatar")
                .Run("Generate blendshape controls", BlendshapeControlBuilder.Generate);
            InPhase(BuildPhase.PlatformFinish)
                .AfterPlugin("nadena.dev.modular-avatar")
                .Run("Apply menu names and favorites", FavoriteMenuBuilder.Build);
        }
    }

    internal static class FavoriteMenuBuilder
    {
        // Modular Avatar names its overflow link "More" and gives it Runtime/Icons/Icon_More_A.png (MenuInstallHook).
        // Find the icon by GUID first, so a moved file still matches.
        private const string MoreIconGuid = "2509fbb49062a464dbb0843b7c4f59d8";
        private const string MoreIconPath = "Packages/nadena.dev.modular-avatar/Runtime/Icons/Icon_More_A.png";
        private const string ModularAvatarRoot = "Packages/nadena.dev.modular-avatar/";
        // The window's reads build into a folder with this name (deleted afterwards).
        internal const string ScanFolderPrefix = "__AvatarCustomizerScan_";

        internal static Texture2D LoadMoreIcon()
        {
            var path = AssetDatabase.GUIDToAssetPath(MoreIconGuid);
            var icon = string.IsNullOrEmpty(path) ? null : AssetDatabase.LoadAssetAtPath<Texture2D>(path);
            return icon ? icon : AssetDatabase.LoadAssetAtPath<Texture2D>(MoreIconPath);
        }

        // Either signal is enough, so a change to only the label or only the icon keeps working.
        // A "More" link with the user's own icon is still treated as a normal submenu, as before.
        internal static bool IsMoreLink(Control c, Texture2D moreIcon) =>
            (moreIcon && c.icon == moreIcon) ||
            (c.name == "More" && (!c.icon || AssetDatabase.GetAssetPath(c.icon).StartsWith(ModularAvatarRoot, StringComparison.Ordinal)));

        // A texture that goes away with a read's build: never saved, or saved into the read's temporary folder.
        internal static bool BuildOnly(Texture2D texture) =>
            !EditorUtility.IsPersistent(texture) ||
            AssetDatabase.GetAssetPath(texture).StartsWith("Assets/" + ScanFolderPrefix, StringComparison.Ordinal);

        internal sealed class Scan : IDisposable
        {
            internal readonly GameObject Avatar;
            internal FavoriteMenuKey[] Menu;
            // Expression parameter defaults before this tool changes any, by parameter name.
            internal Dictionary<string, float> Defaults;
            // Expression parameter types (MenuComposer.ParameterTypes), so the window can work out defaults like the build.
            internal Dictionary<string, VRCExpressionParameters.ValueType> ParameterTypes;
            internal string Result;
            internal bool HasWarnings;
            internal readonly List<Issue> Issues = new List<Issue>();
            // The favorites menus this build made, so the review can point them out.
            internal readonly HashSet<VRCExpressionsMenu> FavoriteMenus = new HashSet<VRCExpressionsMenu>();
            // The menu after "원본 메뉴 정리" (renames, moves, hidden items marked): what the favorites tab picks from.
            internal FavoriteMenuKey[] Organized;
            // Each blendshape control the menus use, by id: why the build left it out, or null when it was built. The
            // window checks the scene and can tell when the build saw it differently.
            internal Dictionary<string, string> Shapes = new Dictionary<string, string>();
            // A copy of the menu as the avatar's tools built it, kept apart from the build's assets so the window can
            // work the final menu out again without building. Whoever takes it destroys it.
            internal MenuSnapshot Tree;
            internal Scan(GameObject avatar) { Avatar = avatar; activeScan = this; }
            public void Dispose() { if (activeScan == this) activeScan = null; }
        }

        internal enum RepairTarget { None, Shortcut, Destination, NameOverride, Move, MoveDestination, Hide }

        internal sealed class Issue
        {
            internal string Title, Detail;
            internal bool Warning;
            internal RepairTarget Target;
            internal int MenuIndex, ItemIndex;
            internal FavoriteMenuKey Saved, Current;
        }

        internal static string Describe(FavoriteMenuKey key)
        {
            if (key == null) return "(없음)";
            if (key.type == Control.ControlType.SubMenu && key.Binding.Length == 0)
                return key.DisplayPath;
            var parameters = (key.subParameters ?? Array.Empty<string>())
                .Select(p => string.IsNullOrEmpty(p) ? "—" : p);
            string binding = string.Join(" · ", new[] { key.parameter }.Concat(parameters)
                .Where(p => !string.IsNullOrEmpty(p)));
            return $"{key.DisplayPath}  [{key.type} · {binding} · 값 {key.value}]";
        }

        private static Scan activeScan;

        internal static void ReadSettings(BuildContext context) =>
            context.GetState<MenuSettings>().Read(context.AvatarRootObject.GetComponent<AvatarCustomizer>());

        internal static string MatchDetail(FavoriteMenuMatch match)
        {
            switch (match)
            {
                case FavoriteMenuMatch.Moved: return "경로가 바뀌었지만 같은 동작에 연결됩니다.";
                case FavoriteMenuMatch.Changed: return "같은 경로에서 동작이 바뀌었습니다. 아래 내용을 확인하세요.";
                case FavoriteMenuMatch.Ambiguous: return "원본 후보가 여러 개라 빌드에서 제외됩니다.";
                default: return "원본을 찾을 수 없어 빌드에서 제외됩니다.";
            }
        }

        internal static void Build(BuildContext context)
        {
            var avatar = context.AvatarRootObject;
            var descriptor = avatar.GetComponent<VRCAvatarDescriptor>();
            if (!descriptor) return;
            var scan = activeScan?.Avatar == avatar ? activeScan : null;
            var config = context.GetState<MenuSettings>();
            bool configured = config.Configured;
            if (!configured && scan == null) return;
            var root = descriptor.expressionsMenu;
            var parameters = descriptor.expressionParameters;
            var issues = scan?.Issues ?? new List<Issue>();
            var parameterTypes = MenuComposer.ParameterTypes(parameters);

            if (scan != null)
            {
                scan.Tree = MenuOrganizer.Snapshot(root, LoadMoreIcon(), BuildOnly);
                scan.Defaults = (parameters ? parameters.parameters : null)?.Where(p => p != null && !string.IsNullOrEmpty(p.name))
                    .GroupBy(p => p.name).ToDictionary(g => g.Key, g => g.First().defaultValue) ?? new Dictionary<string, float>();
                scan.ParameterTypes = parameterTypes;
            }
            // Both edits, worked out the same way as the window's preview. Only the shapes state needs the build: the
            // blendshape controls it generated earlier.
            var shapes = configured ? context.GetState<BlendshapeControlBuilder.State>() : new BlendshapeControlBuilder.State();
            if (scan != null)
                scan.Shapes = config.Shapes.Keys.ToDictionary(id => id, id => BlendshapeControlBuilder.Verdict(shapes, id));
            var composition = MenuComposer.Compose(root, config, shapes, parameterTypes, issues, scan != null);
            var organizer = composition.Organizer;
            if (scan != null)
            {
                scan.Menu = organizer.Original;
                scan.Organized = organizer.Organized;
                scan.FavoriteMenus.UnionWith(composition.FavoriteMenus);
            }
            if (!configured)
            {
                composition.Destroy();
                return;
            }

            int defaultCount = 0;
            if (composition.Defaults.Count > 0)
            {
                // Never edit the project's asset: the build gets its own copy.
                var copy = Object.Instantiate(parameters);
                copy.name = parameters.name;
                foreach (var pair in composition.Defaults)
                {
                    copy.parameters.First(x => x != null && x.name == pair.Key).defaultValue = pair.Value;
                    defaultCount++;
                }
                context.AssetSaver.SaveAsset(copy);
                descriptor.expressionParameters = copy;
            }

            int nameCount = organizer.NameCount, moveCount = organizer.MoveCount, hideCount = organizer.HideCount;
            composition.DestroyStandIns();
            if (composition.MenuChanged)
            {
                // All edits belong to this avatar's build copy.
                context.AssetSaver.SaveAssets(organizer.Created);
                descriptor.expressionsMenu = composition.Root;
            }
            else composition.Destroy();
            var warnings = issues.Where(i => i.Warning).Select(i => i.Title + " · " + i.Detail).ToArray();
            if (scan != null)
            {
                scan.HasWarnings = warnings.Length > 0;
                scan.Result = $"메뉴 {composition.MenuCount}개 · 즐겨찾기 {composition.FavoriteCount}개 · 폴더 {composition.FolderCount}개 · 이름 변경 {nameCount}개" +
                    (moveCount > 0 ? $" · 이동 {moveCount}개" : "") +
                    (organizer.FolderCount > 0 ? $" · 새 폴더 {organizer.FolderCount}개" : "") + (hideCount > 0 ? $" · 숨김 {hideCount}개" : "") +
                    (composition.ShapeCount > 0 ? $" · 블렌드쉐이프 {composition.ShapeCount}개" : "") + (defaultCount > 0 ? $" · 기본값 {defaultCount}개" : "");
                if (scan.HasWarnings) scan.Result += "\n" + string.Join("\n", warnings);
            }
            else foreach (var warning in warnings) Debug.LogWarning("[Avatar Customizer] " + warning, avatar);
        }

        // Runs every installed NDMF plug-in through the Transforming phase (where Modular Avatar installs menus),
        // then this tool's menu pass, skipping optimisers. Returns null, before touching the avatar, when this NDMF
        // version lacks the internals used here. assetFolder holds the build's generated assets, as in a full build:
        // many plug-ins store theirs next to the build's asset container (AssetDatabase.AddObjectToAsset) and fail
        // without one. The caller deletes the folder; null keeps everything in memory.
        internal static BuildContext ProcessFast(GameObject root, string assetFolder)
        {
            const BindingFlags all = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static;
            var asm = typeof(BuildContext).Assembly;
            var resolverType = asm.GetType("nadena.dev.ndmf.PluginResolver", false);
            var concreteType = asm.GetType("nadena.dev.ndmf.ConcretePass", false);
            var find = resolverType?.GetMethod("FindPluginTypes", all);
            var ctor = resolverType?.GetConstructor(all, null,
                new[] { typeof(IEnumerable<Type>), typeof(INDMFPlatformProvider), typeof(bool) }, null);
            var passesProperty = resolverType?.GetProperty("Passes", all);
            var run = concreteType == null ? null : typeof(BuildContext).GetMethod("RunPass", all, null, new[] { concreteType }, null);
            if (find == null || ctor == null || passesProperty == null || run == null ||
                !typeof(IEnumerable<Type>).IsAssignableFrom(find.ReturnType))
                return null;
            var platform = AmbientPlatform.DefaultPlatform;
            var plan = new List<object>();
            using (new AmbientPlatform.Scope(platform))
            {
                var resolver = ctor.Invoke(new[] { find.Invoke(null, null), platform, false });
                if (!(passesProperty.GetValue(resolver) is IEnumerable phases)) return null;
                foreach (var pair in phases)
                {
                    var type = pair?.GetType();
                    var phaseField = type?.GetField("Item1");
                    var passesField = type?.GetField("Item2");
                    if (phaseField?.FieldType != typeof(BuildPhase) || passesField == null || !(passesField.GetValue(pair) is IEnumerable passes))
                        return null;
                    var phase = (BuildPhase)phaseField.GetValue(pair);
                    if (phase == BuildPhase.Optimizing) break;
                    foreach (var pass in passes)
                    {
                        if (!concreteType.IsInstanceOfType(pass)) return null;
                        plan.Add(pass);
                    }
                    if (phase == BuildPhase.Transforming) break;
                }
            }
            var context = new BuildContext(root, assetFolder, platform);
            try
            {
                using (new AmbientPlatform.Scope(platform))
                {
                    foreach (var pass in plan) run.Invoke(context, new[] { pass });
                    Build(context);
                }
            }
            catch (TargetInvocationException e) when (e.InnerException != null)
            {
                throw new InvalidOperationException(e.InnerException.Message, e.InnerException);
            }
            finally
            {
                try { context.DeactivateAllExtensionContexts(); }
                finally { context.AssetSaver.Dispose(); }
            }
            return context;
        }

        internal static bool Reaches(VRCExpressionsMenu menu, VRCExpressionsMenu destination, VRCExpressionsMenu end,
            HashSet<VRCExpressionsMenu> seen)
        {
            if (!menu || !seen.Add(menu)) return false;
            if (menu == destination || menu == end) return true;
            return menu.controls != null && menu.controls.Any(c => c?.type == Control.ControlType.SubMenu &&
                Reaches(c.subMenu, destination, end, seen));
        }

        internal static Control Copy(Control c, string name, Func<VRCExpressionsMenu, VRCExpressionsMenu> map) => new Control
        {
            name = name, type = c.type, icon = c.icon, value = c.value, style = c.style,
            parameter = new Control.Parameter { name = c.parameter?.name ?? "" },
            subParameters = (c.subParameters ?? Array.Empty<Control.Parameter>())
                .Select(p => new Control.Parameter { name = p?.name ?? "" }).ToArray(),
            labels = (c.labels ?? Array.Empty<Control.Label>()).ToArray(),
            subMenu = c.type == Control.ControlType.SubMenu ? map(c.subMenu) : c.subMenu,
        };

        internal static Control Submenu(string name, VRCExpressionsMenu menu) => new Control
        {
            name = name, type = Control.ControlType.SubMenu, subMenu = menu, parameter = new Control.Parameter(),
        };

        internal static VRCExpressionsMenu NewMenu(string name, List<VRCExpressionsMenu> created)
        {
            var menu = ScriptableObject.CreateInstance<VRCExpressionsMenu>();
            menu.name = name;
            menu.controls = new List<Control>();
            created.Add(menu);
            return menu;
        }
    }
}
#endif
