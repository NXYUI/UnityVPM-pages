#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;
using VRC.SDK3.Avatars.ScriptableObjects;
using Control = VRC.SDK3.Avatars.ScriptableObjects.VRCExpressionsMenu.Control;

namespace AvatarMenuTools
{
    // The "빌드 결과" tab: the final menu worked out from the last read and the settings as they are now (MenuComposer, as
    // the build does), shown level by level with where each item comes from and what an edit of it would change.
    internal sealed partial class AvatarCustomizerWindow
    {
        // The last read of this avatar.
        private DateTime readTime;
        private bool readSuccessful, readFailed;
        private Dictionary<string, VRCExpressionParameters.ValueType> parameterTypes;
        private Dictionary<string, (string Settings, string Problem)> readShapes = new Dictionary<string, (string, string)>();

        // The final menu, worked out again only when the read, the component or the scene changed (finalFor).
        private MenuComposition final;
        private FinalMenu finalMenu;
        private MenuView finalView;
        private FavoriteMenuBuilder.Issue[] finalIssues = Array.Empty<FavoriteMenuBuilder.Issue>();
        private string finalFor, finalError;
        private int sceneVersion;
        // The way down from the top level, as item ids, and the selected item of the level shown.
        private readonly List<string> finalPath = new List<string>();
        private string finalSelected;
        // 0 the selected item, 1 the review list, 2 hidden items.
        [SerializeField] private int finalTab = 1;
        private Vector2 finalScroll, detailScroll, hiddenScroll;

        private static Color SelectionColor => EditorGUIUtility.isProSkin ? new Color(.17f, .36f, .53f) : new Color(.72f, .82f, .96f);

        private void ClearReview()
        {
            repairIssue = null;
            readTime = default;
            readSuccessful = readFailed = false;
            parameterTypes = null;
            readShapes = new Dictionary<string, (string, string)>();
            renameFor = renameText = renameBase = null;
            finalPath.Clear();
            finalSelected = null;
            ResetFinal();
        }

        // shapes: the build's verdict on each blendshape control (null when built); config: the settings it was read with.
        private void SetRead(bool successful, Dictionary<string, VRCExpressionParameters.ValueType> types,
            Dictionary<string, string> shapes, AvatarCustomizer config)
        {
            readTime = DateTime.Now;
            readSuccessful = successful;
            readFailed = false;
            parameterTypes = types;
            // Settings as the scene had them when read: the build's copy may already have lost a renderer to another tool.
            var settings = MenuSettings.From(config).Shapes;
            readShapes = (shapes ?? new Dictionary<string, string>()).ToDictionary(s => s.Key,
                s => (settings.TryGetValue(s.Key, out var print) ? print : null, s.Value));
            repairIssue = null;
            renameFor = renameText = renameBase = null;
            issuesScroll = Vector2.zero;
            ResetFinal();
        }

        private void ResetFinal()
        {
            DestroyFinal();
            finalFor = null;
        }

        private void DestroyFinal()
        {
            final?.Destroy();
            final = null;
            finalMenu = null;
            finalView = null;
            finalIssues = Array.Empty<FavoriteMenuBuilder.Issue>();
        }

        // What the final menu was worked out from: the read, the scene and the component's settings.
        private string FinalSignature(AvatarCustomizer config) =>
            (TreeRoot ? TreeRoot.GetInstanceID() : 0) + ":" + sceneVersion + ":" +
            (config ? $"{config.GetInstanceID()}:{EditorUtility.GetDirtyCount(config)}:{config.enabled}" : "-");

        private void ComposeFinal(AvatarCustomizer config)
        {
            string signature = FinalSignature(config);
            if (signature == finalFor) return;
            finalFor = signature;
            DestroyFinal();
            finalError = null;
            if (tree == null) return;
            var issues = new List<FavoriteMenuBuilder.Issue>();
            try
            {
                var shapes = new BlendshapeControlBuilder.State();
                BlendshapeControlBuilder.Plan(config, avatar.transform, shapes);
                var settings = MenuSettings.From(config);
                final = MenuComposer.Compose(TreeRoot, settings, shapes, parameterTypes, issues, true,
                    HideFlags.HideAndDontSave, tree.PageLinks);
                // The scene is checked here, the build's copy at build time: a tool that changes meshes during the build
                // can make them differ. Say so for a control unchanged since the read.
                foreach (var read in readShapes)
                {
                    if (!settings.Shapes.TryGetValue(read.Key, out var now) || now != read.Value.Settings) continue;
                    string problem = BlendshapeControlBuilder.Verdict(shapes, read.Key);
                    if ((problem == null) == (read.Value.Problem == null)) continue;
                    issues.Add(new FavoriteMenuBuilder.Issue
                    {
                        Title = $"블렌드쉐이프 / {config.FindShape(read.Key)?.blendshape}", Warning = true, MenuIndex = -1, ItemIndex = -1,
                        Detail = problem == null
                            ? $"마지막 읽기의 빌드에서는 만들지 못했어요({read.Value.Problem}). 빌드 중에 다른 도구가 이 메시를 바꾸는지 확인해 주세요."
                            : "마지막 읽기의 빌드에서는 만들어졌어요. 씬을 바꿨다면 다시 읽어 확인해 주세요.",
                    });
                }
                finalMenu = new FinalMenu(final);
                finalView = new MenuView(final.Organizer.Original, config);
                finalIssues = issues.ToArray();
            }
            catch (Exception e)
            {
                DestroyFinal();
                finalError = e.Message;
                Debug.LogException(e);
            }
            // A repair in progress follows its message about the very same saved setting (two rules can save the same
            // item); when it is gone the problem was fixed or the rules changed under it, and Undo makes new objects.
            if (repairIssue != null)
                repairIssue = finalIssues.FirstOrDefault(i => i.Target == repairIssue.Target && i.MenuIndex == repairIssue.MenuIndex &&
                                                              i.ItemIndex == repairIssue.ItemIndex && i.Title == repairIssue.Title &&
                                                              ReferenceEquals(i.Saved, repairIssue.Saved));
            // Find the way down and the selection again: where an id is gone or names one of several items alike, stop at
            // the last level still found and let go of the selection.
            if (finalMenu == null) return;
            if (!finalMenu.Root)
            {
                finalPath.Clear();
                finalSelected = null;
                return;
            }
            var level = finalMenu.LevelAt(finalMenu.Root);
            for (int i = 0; i < finalPath.Count; i++)
            {
                var item = level.Find(finalPath[i]);
                if (item?.Opens == null)
                {
                    finalPath.RemoveRange(i, finalPath.Count - i);
                    finalSelected = null;
                    break;
                }
                level = finalMenu.LevelAt(item.Opens);
            }
            if (level.Find(finalSelected) == null) finalSelected = null;
        }

        private void DrawReview(AvatarCustomizer config)
        {
            if (tree == null)
            {
                EditorGUILayout.HelpBox("‘빌드 메뉴 읽기’를 눌러 최종 메뉴를 확인하세요. 한 번 읽은 뒤에는 설정을 바꿀 때마다 바로 다시 계산해요.",
                    MessageType.Info);
                return;
            }
            ComposeFinal(config);
            string when = readTime == default ? "" : $" · {readTime:HH:mm}";
            EditorGUILayout.LabelField($"마지막 읽기: {lastScanMode ?? "-"}{when}. 설정을 바꾸면 바로 다시 계산해요. " +
                                       "메뉴·파라미터 에셋이나 다른 도구의 설정을 바꿨다면 다시 읽어 주세요.", EditorStyles.wordWrappedMiniLabel);
            if (readFailed)
                EditorGUILayout.HelpBox("마지막 읽기가 실패해서, 그 전에 읽은 메뉴로 계산하고 있어요.", MessageType.Warning);
            else if (!readSuccessful)
                EditorGUILayout.HelpBox("마지막 읽기에서 다른 도구의 빌드 오류가 있었어요. 메뉴 일부가 빠졌을 수 있고, 그 오류는 아래 검토 목록에 " +
                                        "나오지 않아요. Unity Console이나 NDMF 빌드 보고서를 확인해 주세요.", MessageType.Warning);
            if (config && !config.enabled)
                EditorGUILayout.HelpBox("Avatar Customizer 컴포넌트가 꺼져 있어 설정이 빌드에 적용되지 않습니다.", MessageType.Info);
            if (finalMenu == null)
            {
                EditorGUILayout.HelpBox($"최종 메뉴를 계산하지 못했어요: {finalError}\nUnity Console을 확인해 주세요.", MessageType.Error);
                return;
            }
            bool canRepair = readSuccessful && !readFailed;
            using var columns = new EditorGUILayout.HorizontalScope();
            using (new EditorGUILayout.VerticalScope(GUILayout.Width(position.width * .48f)))
            {
                if (repairIssue == null) DrawFinalMenu(config);
                else DrawOptions(RepairView(repairIssue, config), null);
            }
            using (new EditorGUILayout.VerticalScope(GUILayout.ExpandWidth(true)))
            {
                if (repairIssue != null)
                {
                    DrawRepair(config, canRepair);
                    return;
                }
                int warnings = finalIssues.Count(i => i.Warning);
                int hidden = config ? config.hiddenItems?.Count(h => h?.source != null) ?? 0 : 0;
                finalTab = GUILayout.Toolbar(finalTab, new[]
                {
                    "선택한 항목", $"검토 {finalIssues.Length}" + (warnings > 0 ? $" · ⚠{warnings}" : ""), $"숨긴 항목 {hidden}",
                });
                if (finalTab == 0) DrawFinalDetail(config);
                else if (finalTab == 1) DrawIssues(canRepair);
                else DrawHiddenItems(config);
            }
        }

        // ---------------------------------------------------------------- the menu

        // The levels from the top down to the one shown. An id no longer found cuts the way there and lets go of the
        // selection.
        private List<(FinalMenu.Item Via, FinalMenu.Level Level)> FinalLevels()
        {
            var result = new List<(FinalMenu.Item, FinalMenu.Level)> { (null, finalMenu.LevelAt(finalMenu.Root)) };
            for (int i = 0; i < finalPath.Count; i++)
            {
                var level = result[result.Count - 1].Item2;
                var item = level.Items.FirstOrDefault(x => x.Id == finalPath[i]);
                if (item?.Opens == null || result.Any(r => r.Item2.First == item.Opens))
                {
                    finalPath.RemoveRange(i, finalPath.Count - i);
                    finalSelected = null;
                    break;
                }
                result.Add((item, finalMenu.LevelAt(item.Opens)));
            }
            return result;
        }

        private void DrawFinalMenu(AvatarCustomizer config)
        {
            EditorGUILayout.LabelField("최종 메뉴", EditorStyles.boldLabel);
            if (!finalMenu.Root)
            {
                EditorGUILayout.LabelField("아바타에 Expressions Menu가 없어 최종 메뉴가 없어요. 즐겨찾기를 설치할 곳이 없으니 검토 목록을 확인해 주세요.",
                    EditorStyles.wordWrappedMiniLabel);
                return;
            }
            var levels = FinalLevels();
            var level = levels[levels.Count - 1].Level;
            FinalKeys(config, levels);
            if (Event.current.type == EventType.DragExited)
            {
                dropOn = null;
                dropEnd = false;
                dropReason = null;
            }
            using (new EditorGUILayout.HorizontalScope())
            {
                using (new EditorGUI.DisabledScope(levels.Count == 1))
                    if (GUILayout.Button(new GUIContent("←", "한 단계 위로"), GUILayout.Width(28)))
                    {
                        // Back up with the submenu just left selected, so it is easy to find again.
                        finalSelected = finalPath[finalPath.Count - 1];
                        finalPath.RemoveAt(finalPath.Count - 1);
                        finalScroll = Vector2.zero;
                        GUIUtility.ExitGUI();
                    }
                string path = PathText(levels);
                EditorGUILayout.LabelField(new GUIContent(path, path), EditorStyles.miniLabel);
                string blocked = EditBlocked(config);
                using (new EditorGUI.DisabledScope(blocked != null))
                    if (GUILayout.Button(new GUIContent("+ 새 폴더", blocked ?? "선택한 항목 앞에(없으면 맨 끝에) 빈 폴더를 만들어요."),
                        EditorStyles.miniButton, GUILayout.Width(64)))
                        NewFolderFinal(config, level, level.Items.FirstOrDefault(i => i.Id == finalSelected), true);
            }
            int opened = finalMenu.Places(level.First).Count;
            string where = "편집 위치: " + LevelName(level.Where, config) +
                           (opened > 1 ? $" · {opened}곳에서 열려요. 안에서 바꾸면 모두 바뀌어요" : "") +
                           (level.FirstNumber > 1 ? $" · {level.FirstNumber}페이지부터 열려요" : "") +
                           (level.Slots.Count == 1 ? $" · {level.Slots[0]}/{VRCExpressionsMenu.MAX_CONTROLS}칸" : "");
            EditorGUILayout.LabelField(where, EditorStyles.wordWrappedMiniLabel);

            using (var scroll = new EditorGUILayout.ScrollViewScope(finalScroll, GUILayout.ExpandHeight(true)))
            {
                finalScroll = scroll.scrollPosition;
                if (level.Items.Count == 0) EditorGUILayout.LabelField("비어 있는 메뉴예요. 항목을 끌어다 놓을 수 있어요.", EditorStyles.wordWrappedMiniLabel);
                DrawFinalRows(config, levels, level);
                FinalDropEnd(config, GUILayoutUtility.GetRect(0f, 28f, GUILayout.ExpandWidth(true)), level);
            }
            if (DraggedFinal() != null && dropReason != null)
                EditorGUILayout.LabelField("⚠ " + dropReason, EditorStyles.wordWrappedMiniLabel);
        }

        private void DrawFinalRows(AvatarCustomizer config, List<(FinalMenu.Item Via, FinalMenu.Level Level)> levels, FinalMenu.Level level)
        {
            int page = 0, number = 0;
            for (int i = 0; i < level.Items.Count; i++)
            {
                var item = level.Items[i];
                // An empty made folder belongs with the page of the item after it.
                int shown = item.Page;
                for (int next = i; shown == 0 && next < level.Items.Count; next++) shown = level.Items[next].Page;
                if (shown == 0) shown = Math.Max(page, 1);
                if (shown != page)
                {
                    page = shown;
                    if (level.Slots.Count > 1 || level.FirstNumber > 1) DrawPageBreak(level, page);
                }
                DrawFinalRow(config, levels, level, item, i + 1 < level.Items.Count ? level.Items[i + 1] : null, item.Dropped ? 0 : ++number);
            }
        }

        private static string PathText(List<(FinalMenu.Item Via, FinalMenu.Level Level)> levels) =>
            string.Join(" › ", new[] { "최상위" }.Concat(levels.Skip(1).Select(l => FinalMenu.Name(l.Via.Control))));

        private void DrawPageBreak(FinalMenu.Level level, int page)
        {
            string label = $"{level.FirstNumber + page - 1}페이지" + (page > 1 ? $" · ‘{level.Links[page - 2]}’ 안" : "") +
                           $" · {level.Slots[page - 1]}/{VRCExpressionsMenu.MAX_CONTROLS}칸";
            EditorGUILayout.Space(2);
            var rect = GUILayoutUtility.GetRect(0f, 16f, GUILayout.ExpandWidth(true));
            GUI.Label(rect, label, EditorStyles.miniBoldLabel);
            float width = EditorStyles.miniBoldLabel.CalcSize(new GUIContent(label)).x + 6;
            if (Event.current.type == EventType.Repaint && rect.width > width)
                EditorGUI.DrawRect(new Rect(rect.x + width, rect.center.y, rect.width - width, 1f), new Color(.5f, .5f, .5f, .5f));
        }

        private void DrawFinalRow(AvatarCustomizer config, List<(FinalMenu.Item Via, FinalMenu.Level Level)> levels, FinalMenu.Level level,
            FinalMenu.Item item, FinalMenu.Item next, int number)
        {
            var rect = GUILayoutUtility.GetRect(0f, 22f, GUILayout.ExpandWidth(true));
            var e = Event.current;
            bool selected = finalSelected == item.Id;
            if (e.type == EventType.Repaint)
            {
                if (selected) EditorGUI.DrawRect(rect, SelectionColor);
                else EditorStyles.helpBox.Draw(rect, false, false, false, false);
            }
            var inner = new Rect(rect.x + 4, rect.y + 2, rect.width - 8, 18);
            var color = GUI.color;
            if (item.Dropped) GUI.color = new Color(color.r, color.g, color.b, color.a * .55f);
            if (item.Control.icon) GUI.DrawTexture(new Rect(inner.x, inner.y, 18, 18), item.Control.icon, ScaleMode.ScaleToFit);
            float right = inner.xMax;
            if (item.Opens != null)
            {
                bool loop = levels.Any(l => l.Level.First == item.Opens);
                using (new EditorGUI.DisabledScope(loop))
                    if (GUI.Button(new Rect(right - 40, inner.y, 40, 18), new GUIContent("열기", loop ? "이미 열려 있는 메뉴예요." : ""),
                        EditorStyles.miniButton))
                    {
                        GUI.color = color;
                        finalPath.Add(item.Id);
                        finalSelected = null;
                        finalScroll = Vector2.zero;
                        GUIUtility.ExitGUI();
                    }
                right -= 44;
            }
            foreach (var (text, tip) in Badges(item).Reverse())
            {
                var content = new GUIContent(text, tip);
                float width = EditorStyles.miniBoldLabel.CalcSize(content).x;
                right -= width;
                GUI.Label(new Rect(right, inner.y, width, 18), content, EditorStyles.miniBoldLabel);
                right -= 4;
            }
            var type = new GUIContent(TypeLabel(item.Control.type));
            float typeWidth = EditorStyles.miniLabel.CalcSize(type).x;
            right -= typeWidth;
            GUI.Label(new Rect(right, inner.y, typeWidth, 18), type, EditorStyles.miniLabel);
            var style = selected ? EditorStyles.boldLabel : EditorStyles.label;
            string name = FinalMenu.Name(item.Control);
            string label = (number > 0 ? $"{number}. " : "– ") + name;
            var nameRect = new Rect(inner.x + 22, inner.y, Math.Max(0, right - 4 - (inner.x + 22)), 18);
            GUI.Label(nameRect, new GUIContent(Fit(label, style, nameRect.width), name + "\n" + OriginLine(item)), style);
            GUI.color = color;
            if (e.type == EventType.ContextClick && rect.Contains(e.mousePosition))
            {
                finalSelected = item.Id;
                GUIUtility.keyboardControl = 0;
                e.Use();
                if (EditBlocked(config) is string blocked)
                {
                    status = blocked;
                    statusType = MessageType.Warning;
                }
                else ShowItemMenu(config, level, item);
                Repaint();
            }
            FinalDragStart(rect, item);
            FinalDropRow(config, rect, level, item, next);
            if (e.type == EventType.MouseDown && e.button == 0 && rect.Contains(e.mousePosition))
            {
                finalSelected = item.Id;
                finalPressed = item.Id;
                GUIUtility.keyboardControl = 0;
                finalTab = 0;
                detailScroll = Vector2.zero;
                if (e.clickCount == 2 && item.Opens != null && !levels.Any(l => l.Level.First == item.Opens))
                {
                    finalPath.Add(item.Id);
                    finalSelected = null;
                    finalScroll = Vector2.zero;
                }
                e.Use();
                Repaint();
            }
            GUILayout.Space(2);
        }

        // One mark of where the item comes from and one of what stands out about it, most important first.
        private IEnumerable<(string Text, string Tip)> Badges(FinalMenu.Item item)
        {
            var origin = item.Origin;
            switch (origin.Kind)
            {
                case MenuOriginKind.MadeFolder: yield return ("새 폴더", "빌드 결과에서 만든 폴더"); break;
                case MenuOriginKind.LegacyFolder: yield return ("폴더", "원본 메뉴 정리의 이동으로 생긴 폴더"); break;
                case MenuOriginKind.FavoritesMenu: yield return ("즐겨찾기", "이 도구가 만든 즐겨찾기 메뉴"); break;
                case MenuOriginKind.FavoritesFolder: yield return ("폴더", "즐겨찾기 안의 폴더"); break;
                case MenuOriginKind.Shortcut: yield return ("바로가기", "즐겨찾기에 넣은 원본 항목의 바로가기"); break;
                case MenuOriginKind.Shape: yield return ("쉐이프", "블렌드쉐이프 컨트롤"); break;
                case MenuOriginKind.Unknown: yield return ("?", "출처를 알 수 없는 항목"); break;
            }
            int opened = item.Opens != null ? finalMenu.Places(item.Opens).Count : 0;
            if (item.Dropped) yield return ("빌드 제외", "비어 있어 빌드에서 빠져요.");
            else if (opened > 1) yield return ("공유", $"{opened}곳에서 열리는 같은 메뉴예요. 안에서 바꾸면 모두 바뀌어요.");
            else if (origin.Kind == MenuOriginKind.Original && final.Organizer.MovedControls.Contains(item.Control))
                yield return ("옮김", "원본 메뉴 정리로 옮긴 항목");
            else if (origin.Kind == MenuOriginKind.Original && final.Organizer.OriginalNameOf(item.Control) != item.Control.name)
                yield return ("이름 변경", $"원래 이름: {final.Organizer.OriginalNameOf(item.Control)}");
            else if (origin.Kind == MenuOriginKind.Shortcut && origin.Target?.hidden == true)
                yield return ("원본 숨김", "원본은 원본 메뉴 정리에서 숨겼어요.");
        }

        // Text that fits width, cut with "…" (the full text goes in the tooltip).
        private static string Fit(string text, GUIStyle style, float width)
        {
            if (width <= 0) return "";
            if (style.CalcSize(new GUIContent(text)).x <= width) return text;
            int low = 0, high = text.Length;
            while (low < high)
            {
                int middle = (low + high + 1) / 2;
                if (style.CalcSize(new GUIContent(text.Substring(0, middle) + "…")).x <= width) low = middle;
                else high = middle - 1;
            }
            return text.Substring(0, low) + "…";
        }

        // ---------------------------------------------------------------- where things come from

        private string MenuName(AvatarCustomizer config, int index) =>
            config && config.GetMenu(index) is FavoriteMenuGroup menu ? menu.DisplayName : $"{index + 1}번째 메뉴";

        private string FavoritesFolderName(AvatarCustomizer config, int index, string folderId)
        {
            var entry = config ? config.GetMenu(index)?.entries?.FirstOrDefault(e => e != null && e.IsFolder && e.folderId == folderId) : null;
            return entry == null ? "폴더" : string.IsNullOrWhiteSpace(entry.label) ? "새 폴더" : entry.label.Trim();
        }

        private string MadeFolderName(AvatarCustomizer config, string id) =>
            (config ? config.createdFolders?.FirstOrDefault(f => f != null && f.id == id)?.DisplayName : null) ?? "새 폴더";

        // The setting a level belongs to, as the user knows it.
        private string LevelName(MenuLevel level, AvatarCustomizer config)
        {
            switch (level.Kind)
            {
                case MenuLevelKind.Root: return "최상위 메뉴";
                case MenuLevelKind.Original: return $"원본 메뉴 ‘{finalView.Display(level.Key)}’";
                case MenuLevelKind.MadeFolder: return $"새 폴더 ‘{MadeFolderName(config, level.Id)}’";
                case MenuLevelKind.LegacyFolder: return $"‘{level.Id}’ 폴더 (원본 메뉴 정리의 이동)";
                case MenuLevelKind.Favorites:
                    return $"즐겨찾기 ‘{MenuName(config, level.MenuIndex)}’" +
                           (string.IsNullOrEmpty(level.Id) ? "" : $" 안의 ‘{FavoritesFolderName(config, level.MenuIndex, level.Id)}’");
                default: return "알 수 없는 메뉴";
            }
        }

        private string OriginLine(FinalMenu.Item item)
        {
            var origin = item.Origin;
            var config = avatar ? avatar.GetComponent<AvatarCustomizer>() : null;
            switch (origin.Kind)
            {
                case MenuOriginKind.Original: return $"아바타 메뉴의 항목 · 원래 위치: {origin.Key.DisplayPath}";
                case MenuOriginKind.Shortcut:
                    return $"즐겨찾기 ‘{MenuName(config, origin.MenuIndex)}’의 바로가기 · 원본: " +
                           (origin.Key != null ? finalView.Display(origin.Key) : origin.Target?.DisplayPath ?? "(알 수 없음)");
                case MenuOriginKind.FavoritesMenu: return $"이 도구가 만든 즐겨찾기 메뉴 ({origin.MenuIndex + 1}번째)";
                case MenuOriginKind.FavoritesFolder: return $"즐겨찾기 ‘{MenuName(config, origin.MenuIndex)}’ 안의 폴더";
                case MenuOriginKind.MadeFolder: return "빌드 결과에서 만든 새 폴더" + (item.Dropped ? " · 비어 있어 빌드에서 빠져요" : "");
                case MenuOriginKind.LegacyFolder: return $"원본 메뉴 정리에서 ‘{origin.Id}’ 폴더로 옮기면서 생긴 폴더";
                case MenuOriginKind.Shape:
                    if (origin.Id == BlendshapeControl.ResetId) return "블렌드쉐이프 초기화 버튼";
                    var shape = config ? config.FindShape(origin.Id) : null;
                    return shape == null ? "블렌드쉐이프 컨트롤" :
                        $"블렌드쉐이프 컨트롤 · {(shape.renderer ? shape.renderer.name : "(오브젝트 없음)")} / {shape.blendshape}";
                default: return "출처를 알 수 없는 항목";
            }
        }

        // ---------------------------------------------------------------- the selected item

        private void DrawFinalDetail(AvatarCustomizer config)
        {
            var levels = FinalLevels();
            var level = levels[levels.Count - 1].Level;
            var item = finalSelected == null ? null : level.Items.FirstOrDefault(i => i.Id == finalSelected);
            if (item == null)
            {
                EditorGUILayout.LabelField("왼쪽 최종 메뉴에서 항목을 누르면, 어디서 온 항목인지와 바꾸면 무엇이 바뀌는지 보여 줘요.",
                    EditorStyles.wordWrappedMiniLabel);
                return;
            }
            using var scroll = new EditorGUILayout.ScrollViewScope(detailScroll, GUILayout.ExpandHeight(true));
            detailScroll = scroll.scrollPosition;
            var c = item.Control;
            var origin = item.Origin;
            string blocked = EditBlocked(config);
            using (new EditorGUILayout.HorizontalScope())
            {
                var icon = GUILayoutUtility.GetRect(18f, 18f, GUILayout.Width(18f), GUILayout.Height(18f));
                if (c.icon) GUI.DrawTexture(icon, c.icon, ScaleMode.ScaleToFit);
                if (Renamable(item) && blocked == null) DrawNameField(config, item);
                else EditorGUILayout.LabelField(FinalMenu.Name(c), EditorStyles.boldLabel);
            }
            if (blocked != null) EditorGUILayout.LabelField(blocked, EditorStyles.wordWrappedMiniLabel);
            using (new EditorGUI.DisabledScope(blocked != null))
            {
                using (new EditorGUILayout.HorizontalScope())
                {
                    if (GUILayout.Button(new GUIContent("이동…", "다른 메뉴로 옮겨요. 같은 메뉴 안에서는 끌어서 옮길 수 있어요."), EditorStyles.miniButtonLeft))
                        ShowMoveMenu(config, item);
                    if (GUILayout.Button(new GUIContent("이 앞에 새 폴더", "이 항목 앞에 빈 폴더를 만들어요."), EditorStyles.miniButtonMid))
                        NewFolderFinal(config, level, item, true);
                    using (new EditorGUI.DisabledScope(!Renamable(item)))
                        if (GUILayout.Button(new GUIContent(DeleteLabel(item), DeleteTip(item)), EditorStyles.miniButtonRight))
                            DeleteFinal(config, item, true);
                }
                using (new EditorGUILayout.HorizontalScope())
                {
                    if (item.Origin.Kind == MenuOriginKind.Original &&
                        GUILayout.Button(new GUIContent("즐겨찾기에 추가…", "원본은 그대로 두고 즐겨찾기에 바로가기를 넣어요."), EditorStyles.miniButton))
                        ShowAddMenu(config, item);
                    if (CanRestore(config, item) &&
                        GUILayout.Button(new GUIContent("원래대로", item.Origin.Kind == MenuOriginKind.Shortcut
                            ? "바로가기를 빼고 원본을 원래 자리에 다시 보이게 해요."
                            : "이 항목의 이름 변경과 이동을 지워요."), EditorStyles.miniButton))
                        RestoreFinal(config, item, true);
                }
            }
            string binding = string.Join(" · ", new[] { c.parameter?.name }
                .Concat((c.subParameters ?? Array.Empty<Control.Parameter>()).Select(p => p?.name)).Where(p => !string.IsNullOrEmpty(p)));
            EditorGUILayout.LabelField(TypeLabel(c.type) + (binding.Length > 0 ? $" · {binding}" : ""), EditorStyles.miniLabel);

            Section("어디서 왔나요");
            Line(OriginLine(item));
            if (origin.Kind == MenuOriginKind.Original)
            {
                string before = final.Organizer.OriginalNameOf(c);
                if (before != c.name) Line($"이름 변경: 원래 이름 ‘{before}’");
                if (final.Organizer.MovedControls.Contains(c)) Line("원본 메뉴 정리로 옮긴 항목이에요.");
            }
            if (origin.Kind == MenuOriginKind.Shortcut && origin.Target?.hidden == true) Line("원본은 원본 메뉴 정리에서 숨겼어요.");

            Section("들어온 경로");
            Line(PathText(levels) + " › " + FinalMenu.Name(c));

            Section("바꾸면 바뀌는 것");
            Line("이 항목: " + ItemSetting(origin, config));
            if (item.Opens != null)
            {
                var inside = final.LevelOf(item.Opens);
                Line("안의 항목: " + LevelName(inside, config));
                var places = finalMenu.Places(item.Opens);
                if (places.Count > 1)
                    Line($"같은 메뉴가 {places.Count}곳에서 열려요. 안에서 바꾸면 모두 바뀌어요.\n" +
                         string.Join("\n", places.Select(p => "· 최상위 › " + string.Join(" › ", p))));
            }

            if (StartValue(item, config) is string start)
            {
                Section("시작값");
                Line(start);
            }

            if (origin.Kind == MenuOriginKind.Original && finalView.Resolve(origin.Key) is FavoriteMenuKey key)
            {
                var rules = new List<string>();
                if (finalView.RuleByControl.TryGetValue(key.sharedControl, out int rename))
                    rules.Add($"이름 변경 ‘{config.nameOverrides[rename].label?.Trim()}’");
                if (finalView.MoveOf(key) is string move) rules.Add("이동 ⇢ " + move);
                if (rules.Count > 0)
                {
                    Section("걸린 규칙");
                    foreach (var rule in rules) Line(rule);
                }
            }

            EditorGUILayout.Space(8);
            switch (origin.Kind)
            {
                case MenuOriginKind.Original:
                case MenuOriginKind.Shortcut when origin.Key != null:
                    if (GUILayout.Button("원본 메뉴 정리에서 보기"))
                    {
                        tab = 1;
                        search = "";
                        selectedKey = FavoriteMenuKey.Resolve(catalogue, origin.Key);
                        optionsScroll = Vector2.zero;
                        GUIUtility.ExitGUI();
                    }
                    break;
            }
            if (origin.MenuIndex >= 0 && config && config.GetMenu(origin.MenuIndex) != null && origin.Kind != MenuOriginKind.Shape &&
                GUILayout.Button("즐겨찾기 편집에서 보기"))
            {
                tab = 0;
                SelectMenu(origin.MenuIndex);
                GUIUtility.ExitGUI();
            }
            if (origin.Kind == MenuOriginKind.Shape && GUILayout.Button("블렌드쉐이프 탭에서 보기"))
            {
                tab = 2;
                GUIUtility.ExitGUI();
            }

            void Section(string title)
            {
                EditorGUILayout.Space(6);
                EditorGUILayout.LabelField(title, EditorStyles.boldLabel);
            }
            void Line(string text) => EditorGUILayout.LabelField(text, EditorStyles.wordWrappedMiniLabel);
        }

        private string renameFor, renameText, renameBase;

        // Enter keeps the name, Esc drops it; selecting another item drops it too.
        private void DrawNameField(AvatarCustomizer config, FinalMenu.Item item)
        {
            string current = item.Control.name ?? "";
            var e = Event.current;
            bool focused = GUI.GetNameOfFocusedControl() == NameField;
            if (renameFor != item.Id || (!focused && renameBase != current))
            {
                renameFor = item.Id;
                renameText = renameBase = current;
            }
            bool enter = focused && e.type == EventType.KeyDown && (e.keyCode == KeyCode.Return || e.keyCode == KeyCode.KeypadEnter);
            bool escape = focused && e.type == EventType.KeyDown && e.keyCode == KeyCode.Escape;
            GUI.SetNextControlName(NameField);
            renameText = EditorGUILayout.TextField(renameText, EditorStyles.textField);
            if (focusName && e.type == EventType.Repaint)
            {
                focusName = false;
                EditorGUI.FocusTextInControl(NameField);
            }
            bool changed = renameText != current;
            using (new EditorGUI.DisabledScope(!changed))
                if (GUILayout.Button(new GUIContent("적용", "Enter로도 적용돼요. Esc는 취소예요."), EditorStyles.miniButton, GUILayout.Width(40)) || (enter && changed))
                {
                    GUIUtility.keyboardControl = 0;
                    RenameFinal(config, item, renameText);
                }
            if (escape)
            {
                renameText = renameBase = current;
                GUIUtility.keyboardControl = 0;
                e.Use();
                Repaint();
            }
        }

        // Which setting an edit of the item itself (its name, place, removal) belongs to.
        private string ItemSetting(MenuOrigin origin, AvatarCustomizer config)
        {
            switch (origin.Kind)
            {
                case MenuOriginKind.Original: return "원본 메뉴 정리의 규칙(이름 변경·이동·숨기기)이에요. 아바타의 메뉴 에셋은 바뀌지 않아요.";
                case MenuOriginKind.Shortcut: return $"즐겨찾기 ‘{MenuName(config, origin.MenuIndex)}’의 바로가기 설정이에요. 원본은 그대로예요.";
                case MenuOriginKind.FavoritesMenu: return "이 즐겨찾기 메뉴의 설정(이름·설치 위치·첫 페이지 고정)이에요.";
                case MenuOriginKind.FavoritesFolder: return $"즐겨찾기 ‘{MenuName(config, origin.MenuIndex)}’ 안의 폴더 설정이에요.";
                case MenuOriginKind.MadeFolder: return "빌드 결과에서 만든 폴더 설정이에요.";
                case MenuOriginKind.LegacyFolder: return "원본 메뉴 정리의 이동 규칙이 가리키는 폴더 이름이에요.";
                case MenuOriginKind.Shape: return "블렌드쉐이프 컨트롤과 즐겨찾기 설정이에요.";
                default: return "알 수 없어요.";
            }
        }

        // The value a toggle or radial starts at on the built avatar, and what sets it.
        private string StartValue(FinalMenu.Item item, AvatarCustomizer config)
        {
            var c = item.Control;
            bool toggle = c.type == Control.ControlType.Toggle;
            if (!toggle && c.type != Control.ControlType.RadialPuppet) return null;
            string parameter = toggle ? c.parameter?.name : c.subParameters?.FirstOrDefault()?.name;
            if (string.IsNullOrEmpty(parameter)) return null;
            float value;
            string from;
            var shape = config ? config.blendshapeControls?.FirstOrDefault(s => s != null && s.Parameter == parameter) : null;
            if (final.Defaults.TryGetValue(parameter, out value)) from = "기본값 설정";
            // A blendshape control starts where its settings say now, not at what the last read saw.
            else if (shape != null) { value = shape.StartValue; from = "블렌드쉐이프 설정"; }
            else if (parameterDefaults.TryGetValue(parameter, out value)) from = "아바타 그대로";
            else return $"‘{parameter}’ · 알 수 없어요 (Expression Parameters에 없어요)";
            string shown = toggle ? (Mathf.Approximately(value, c.value) ? "켜짐" : "꺼짐") : $"{value * 100f:0}%";
            return $"{shown} · {from} · ‘{parameter}’";
        }

        // ---------------------------------------------------------------- hidden items

        private void DrawHiddenItems(AvatarCustomizer config)
        {
            var hides = config ? config.hiddenItems : null;
            var rules = hides?.Where(h => h?.source != null).ToArray() ?? Array.Empty<MenuHideRule>();
            EditorGUILayout.LabelField($"숨긴 항목 · {rules.Length}개", EditorStyles.boldLabel);
            EditorGUILayout.LabelField("원본 메뉴 정리에서 숨긴 항목이에요. 즐겨찾기 바로가기로는 계속 쓸 수 있어요. " +
                                       "‘다시 보이기’를 누르면 원래 자리로 돌아와요.", EditorStyles.wordWrappedMiniLabel);
            using var scroll = new EditorGUILayout.ScrollViewScope(hiddenScroll, GUILayout.ExpandHeight(true));
            hiddenScroll = scroll.scrollPosition;
            if (rules.Length == 0)
            {
                EditorGUILayout.LabelField("숨긴 항목이 없어요. 원본 메뉴 정리 탭에서 항목을 숨길 수 있어요.", EditorStyles.wordWrappedMiniLabel);
                return;
            }
            foreach (var rule in rules)
                using (new EditorGUILayout.HorizontalScope(EditorStyles.helpBox))
                {
                    var key = finalView.Resolve(rule.source);
                    string label = key != null ? finalView.Display(key) : $"⚠ {rule.source.DisplayPath} (찾을 수 없음)";
                    EditorGUILayout.LabelField(new GUIContent(label, FavoriteMenuBuilder.Describe(rule.source)), EditorStyles.wordWrappedMiniLabel);
                    if (GUILayout.Button(key != null ? "다시 보이기" : "규칙 삭제", GUILayout.Width(76)))
                    {
                        Change("Show hidden menu item", c => c.hiddenItems?.Remove(rule));
                        GUIUtility.ExitGUI();
                    }
                }
        }
    }
}
#endif
