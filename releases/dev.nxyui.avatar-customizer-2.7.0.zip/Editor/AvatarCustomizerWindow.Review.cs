#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;
using VRC.SDK3.Avatars.ScriptableObjects;
using Control = VRC.SDK3.Avatars.ScriptableObjects.VRCExpressionsMenu.Control;

namespace AvatarMenuTools
{
    internal sealed partial class AvatarCustomizerWindow
    {
        private sealed class PreviewPage
        {
            // Favorite: a favorites menu this tool built. Moved: an item "원본 메뉴 정리" moved here.
            internal readonly List<(string Name, Control.ControlType Type, PreviewPage Child, Texture2D Icon, bool Favorite, bool Moved)> Items =
                new List<(string, Control.ControlType, PreviewPage, Texture2D, bool, bool)>();
            // A favorites menu is on this page or somewhere below it.
            internal bool HoldsFavorite;
        }

        private readonly HashSet<FavoriteMenuKey> batchSources = new HashSet<FavoriteMenuKey>();
        private readonly HashSet<FavoriteMenuEntry> batchEntries = new HashSet<FavoriteMenuEntry>();
        private FavoriteMenuBuilder.Issue repairIssue;
        private Vector2 issuesScroll;

        private void QueueScan(bool compare = false)
        {
            scanning = true;
            var selected = avatar;
            EditorApplication.delayCall += () => { if (this) Scan(selected, compare); };
        }

        // Only strings and links, taken before the temporary Unity objects are destroyed.
        private static PreviewPage SnapshotPages(VRCExpressionsMenu root, ICollection<VRCExpressionsMenu> favorites,
            ICollection<Control> moved)
        {
            var pages = new Dictionary<VRCExpressionsMenu, PreviewPage>();
            var pending = new Queue<VRCExpressionsMenu>();
            PreviewPage Snapshot(VRCExpressionsMenu menu)
            {
                if (!menu) return null;
                if (!pages.TryGetValue(menu, out var page))
                {
                    pages.Add(menu, page = new PreviewPage());
                    pending.Enqueue(menu);
                }
                return page;
            }
            var first = Snapshot(root);
            while (pending.Count > 0)
            {
                var menu = pending.Dequeue();
                foreach (var item in menu.controls ?? Enumerable.Empty<Control>())
                    if (item != null)
                        pages[menu].Items.Add((item.name, item.type,
                            item.type == Control.ControlType.SubMenu ? Snapshot(item.subMenu) : null, item.icon,
                            item.type == Control.ControlType.SubMenu && item.subMenu && favorites != null && favorites.Contains(item.subMenu),
                            moved != null && moved.Contains(item)));
            }
            // Mark the way to each favorites menu, so a menu behind "More" or inside a submenu can be followed.
            var visiting = new HashSet<PreviewPage>();
            var done = new HashSet<PreviewPage>();
            bool Holds(PreviewPage page)
            {
                if (done.Contains(page) || !visiting.Add(page)) return page.HoldsFavorite;
                page.HoldsFavorite = page.Items.Any(i => i.Favorite) | page.Items.Where(i => i.Child != null).Select(i => Holds(i.Child)).ToArray().Any(h => h);
                visiting.Remove(page);
                done.Add(page);
                return page.HoldsFavorite;
            }
            foreach (var page in pages.Values) Holds(page);
            return first;
        }

        // A repair picks from the menu its rule refers to: renames and moves from the menu as built, favorites from the
        // organized menu.
        private MenuView RepairView(FavoriteMenuBuilder.Issue issue, AvatarCustomizer config) =>
            issue.Target == FavoriteMenuBuilder.RepairTarget.Shortcut || issue.Target == FavoriteMenuBuilder.RepairTarget.Destination
                ? new MenuView(organized.Length > 0 ? organized : catalogue, config, organizedView: true)
                : new MenuView(catalogue, config);

        private void DrawPreviewPage(List<(string Name, PreviewPage Page)> previewPath, ref Vector2 previewScroll, string title, string empty)
        {
            EditorGUILayout.LabelField(title, EditorStyles.boldLabel);
            if (previewPath.Count == 0)
            {
                EditorGUILayout.LabelField(empty, EditorStyles.wordWrappedMiniLabel);
                return;
            }
            var current = previewPath[previewPath.Count - 1].Page;
            using (new EditorGUILayout.HorizontalScope())
            {
                using (new EditorGUI.DisabledScope(previewPath.Count == 1))
                    if (GUILayout.Button("←", GUILayout.Width(28)))
                    {
                        previewPath.RemoveAt(previewPath.Count - 1);
                        previewScroll = Vector2.zero;
                        GUIUtility.ExitGUI();
                    }
                string path = string.Join(" › ", previewPath.Select(p => p.Name));
                EditorGUILayout.LabelField(new GUIContent(path, path), EditorStyles.miniLabel);
            }
            EditorGUILayout.LabelField($"{current.Items.Count} / {VRCExpressionsMenu.MAX_CONTROLS} 슬롯", EditorStyles.miniLabel);
            using var scroll = new EditorGUILayout.ScrollViewScope(previewScroll, GUILayout.ExpandHeight(true));
            previewScroll = scroll.scrollPosition;
            for (int i = 0; i < current.Items.Count; i++)
            {
                var item = current.Items[i];
                string name = string.IsNullOrWhiteSpace(item.Name) ? "(이름 없음)" : item.Name;
                using (new EditorGUILayout.HorizontalScope(EditorStyles.helpBox))
                {
                    // Icons made only for the build are gone with its temporary assets and show as empty.
                    var icon = GUILayoutUtility.GetRect(18f, 18f, GUILayout.Width(18f), GUILayout.Height(18f));
                    if (item.Icon) GUI.DrawTexture(icon, item.Icon, ScaleMode.ScaleToFit);
                    EditorGUILayout.LabelField(new GUIContent($"{i + 1}. {name}", $"{name} · {item.Type}"));
                    if (item.Moved)
                        GUILayout.Label(new GUIContent("옮김", "원본 메뉴 정리로 옮긴 항목"), EditorStyles.miniBoldLabel, GUILayout.ExpandWidth(false));
                    if (item.Favorite)
                        GUILayout.Label(new GUIContent("즐겨찾기", "이 도구가 만든 즐겨찾기 메뉴"), EditorStyles.miniBoldLabel, GUILayout.ExpandWidth(false));
                    else if (item.Child?.HoldsFavorite == true)
                        GUILayout.Label(new GUIContent("즐겨찾기 있음", "이 안에 즐겨찾기 메뉴가 있어요."), EditorStyles.miniLabel, GUILayout.ExpandWidth(false));
                    if (item.Child == null) continue;
                    using (new EditorGUI.DisabledScope(previewPath.Any(p => p.Page == item.Child)))
                        if (GUILayout.Button("열기", GUILayout.Width(48)))
                        {
                            previewPath.Add((name, item.Child));
                            previewScroll = Vector2.zero;
                            GUIUtility.ExitGUI();
                        }
                }
            }
        }

        private void DrawIssues(bool canRepair)
        {
            int warnings = finalIssues.Count(i => i.Warning);
            EditorGUILayout.LabelField($"검토할 항목 · 경고 {warnings}개 · 안내 {finalIssues.Length - warnings}개",
                EditorStyles.boldLabel);
            EditorGUILayout.LabelField("지금 설정으로 다시 계산한 목록이에요. 다른 도구의 빌드 오류는 여기 나오지 않아요.",
                EditorStyles.wordWrappedMiniLabel);
            if (!canRepair && finalIssues.Any(i => i.Target != FavoriteMenuBuilder.RepairTarget.None))
                EditorGUILayout.LabelField("마지막 읽기에 오류가 있어 연결 확인은 다시 읽은 뒤에 할 수 있어요.", EditorStyles.wordWrappedMiniLabel);
            using var scroll = new EditorGUILayout.ScrollViewScope(issuesScroll, GUILayout.ExpandHeight(true));
            issuesScroll = scroll.scrollPosition;
            if (finalIssues.Length == 0)
                EditorGUILayout.LabelField("표시할 변경이나 문제가 없습니다.", EditorStyles.wordWrappedMiniLabel);
            foreach (var issue in finalIssues.OrderByDescending(i => i.Warning))
            {
                using var card = new EditorGUILayout.VerticalScope(EditorStyles.helpBox);
                EditorGUILayout.LabelField((issue.Warning ? "⚠ " : "") + issue.Title, EditorStyles.wordWrappedMiniLabel);
                EditorGUILayout.LabelField(issue.Detail, EditorStyles.wordWrappedMiniLabel);
                if (issue.Target == FavoriteMenuBuilder.RepairTarget.None) continue;
                using (new EditorGUI.DisabledScope(!canRepair))
                    if (GUILayout.Button("연결 확인", GUILayout.Width(88)))
                    {
                        repairIssue = issue;
                        selectedKey = issue.Current;
                        search = "";
                        optionsScroll = Vector2.zero;
                        GUIUtility.ExitGUI();
                    }
            }
        }

        private void DrawRepair(AvatarCustomizer config, bool canRepair)
        {
            if (GUILayout.Button("← 빌드 결과", GUILayout.Width(104)))
            {
                repairIssue = null;
                GUIUtility.ExitGUI();
            }
            var issue = repairIssue;
            EditorGUILayout.LabelField(issue.Title, EditorStyles.wordWrappedLabel);
            EditorGUILayout.HelpBox(issue.Detail, issue.Warning ? MessageType.Warning : MessageType.Info);
            EditorGUILayout.LabelField("저장된 원본", EditorStyles.boldLabel);
            EditorGUILayout.LabelField(FavoriteMenuBuilder.Describe(issue.Saved), EditorStyles.wordWrappedMiniLabel);
            EditorGUILayout.Space(8);
            EditorGUILayout.LabelField("선택한 원본", EditorStyles.boldLabel);
            EditorGUILayout.LabelField(selectedKey == null ? "왼쪽 목록에서 원본을 선택하세요." :
                FavoriteMenuBuilder.Describe(selectedKey), EditorStyles.wordWrappedMiniLabel);
            var view = RepairView(issue, config);
            bool suitable = selectedKey != null && view.Resolve(selectedKey) != null;
            if (suitable && (issue.Target == FavoriteMenuBuilder.RepairTarget.Destination ||
                             issue.Target == FavoriteMenuBuilder.RepairTarget.MoveDestination))
                suitable = selectedKey.type == Control.ControlType.SubMenu;
            if (suitable && issue.Target == FavoriteMenuBuilder.RepairTarget.Move &&
                view.MoveByControl.TryGetValue(selectedKey.sharedControl, out int moving) && moving != issue.ItemIndex)
            {
                suitable = false;
                EditorGUILayout.LabelField("이미 이동이 등록된 항목입니다.", EditorStyles.wordWrappedMiniLabel);
            }
            if (suitable && issue.Target == FavoriteMenuBuilder.RepairTarget.Hide &&
                view.HideByControl.TryGetValue(selectedKey.sharedControl, out int hiding) && hiding != issue.ItemIndex)
            {
                suitable = false;
                EditorGUILayout.LabelField("이미 숨긴 항목입니다.", EditorStyles.wordWrappedMiniLabel);
            }
            if (suitable && issue.Target == FavoriteMenuBuilder.RepairTarget.NameOverride &&
                view.RuleByControl.TryGetValue(selectedKey.sharedControl, out int existing) && existing != issue.ItemIndex)
            {
                suitable = false;
                EditorGUILayout.LabelField("이미 이름 변경이 등록된 항목입니다.", EditorStyles.wordWrappedMiniLabel);
            }
            using (new EditorGUI.DisabledScope(!canRepair || !suitable))
                if (GUILayout.Button("선택한 원본으로 연결"))
                {
                    var key = selectedKey;
                    // The message names its rule by index: write only when that rule is still the one it was about.
                    if (!RuleStillThere(config, issue))
                    {
                        repairIssue = null;
                        status = "설정이 바뀌어서 연결하지 않았어요. 검토 목록을 다시 확인해 주세요.";
                        statusType = MessageType.Warning;
                        GUIUtility.ExitGUI();
                    }
                    Change("Relink favorites setting", c =>
                    {
                        switch (issue.Target)
                        {
                            case FavoriteMenuBuilder.RepairTarget.Shortcut:
                            {
                                // Linked to something else, it no longer stands for the item its pair hid.
                                var entry = c.GetMenu(issue.MenuIndex).entries[issue.ItemIndex];
                                entry.source = key;
                                if (!string.IsNullOrEmpty(entry.pairId) && !SamePairedItem(c, entry, key)) entry.pairId = "";
                                break;
                            }
                            case FavoriteMenuBuilder.RepairTarget.Destination:
                                if (issue.MenuIndex == 0) { c.useRoot = false; c.destinationFolder = ""; c.destination = key; }
                                else if (c.GetMenu(issue.MenuIndex) is FavoriteMenuGroup menu)
                                { menu.useRoot = false; menu.destinationFolder = ""; menu.destination = key; }
                                break;
                            case FavoriteMenuBuilder.RepairTarget.NameOverride:
                                c.nameOverrides[issue.ItemIndex].source = key;
                                break;
                            case FavoriteMenuBuilder.RepairTarget.Move:
                                c.menuMoves[issue.ItemIndex].source = key;
                                break;
                            case FavoriteMenuBuilder.RepairTarget.Hide:
                                c.hiddenItems[issue.ItemIndex].source = key;
                                break;
                            case FavoriteMenuBuilder.RepairTarget.MoveDestination:
                                c.menuMoves[issue.ItemIndex].newFolder = "";
                                c.menuMoves[issue.ItemIndex].destinationFolder = "";
                                c.menuMoves[issue.ItemIndex].destination = key;
                                break;
                        }
                    });
                    // The final menu is worked out again from the read on the next draw; no need to read again.
                    repairIssue = null;
                    GUIUtility.ExitGUI();
                }
        }

        // Whether a key of the organized menu names the item a shortcut's pair hid.
        private bool SamePairedItem(AvatarCustomizer c, FavoriteMenuEntry entry, FavoriteMenuKey key)
        {
            var organizer = final?.Organizer;
            var hide = c.hiddenItems?.FirstOrDefault(h => h?.pairId == entry.pairId);
            if (organizer == null || hide?.source == null) return false;
            var organized = FavoriteMenuKey.Resolve(organizer.Organized.Where(k => k.createdFolder == null).ToArray(), key);
            var original = organized == null ? null : organizer.OriginalKeyOf(organizer.OrganizedItems[organized]);
            return FinalMenuEdits.Same(original, FavoriteMenuKey.Resolve(organizer.Original, hide.source));
        }

        private static bool RuleStillThere(AvatarCustomizer c, FavoriteMenuBuilder.Issue issue)
        {
            if (!c || issue.Saved == null) return c;
            T At<T>(List<T> list) where T : class => list != null && issue.ItemIndex >= 0 && issue.ItemIndex < list.Count ? list[issue.ItemIndex] : null;
            switch (issue.Target)
            {
                case FavoriteMenuBuilder.RepairTarget.Shortcut: return At(c.GetMenu(issue.MenuIndex)?.entries)?.source == issue.Saved;
                case FavoriteMenuBuilder.RepairTarget.Destination: return c.GetMenu(issue.MenuIndex)?.destination == issue.Saved;
                case FavoriteMenuBuilder.RepairTarget.NameOverride: return At(c.nameOverrides)?.source == issue.Saved;
                case FavoriteMenuBuilder.RepairTarget.Move: return At(c.menuMoves)?.source == issue.Saved;
                case FavoriteMenuBuilder.RepairTarget.MoveDestination: return At(c.menuMoves)?.destination == issue.Saved;
                case FavoriteMenuBuilder.RepairTarget.Hide: return At(c.hiddenItems)?.source == issue.Saved;
                default: return true;
            }
        }

        private void DrawBatchActions(MenuView view, List<FavoriteMenuEntry> entries)
        {
            batchEntries.IntersectWith(entries);
            using var row = new EditorGUILayout.HorizontalScope();
            using (new EditorGUI.DisabledScope(batchSources.Count == 0))
                if (GUILayout.Button($"선택 추가 ({batchSources.Count})"))
                {
                    var existing = entries.Where(e => e != null && !e.IsFolder && e.Parent == addParent)
                        .Select(e => view.Resolve(e.source)?.sharedControl ?? 0).ToHashSet();
                    var added = view.Keys.Where(batchSources.Contains).Select(view.Resolve)
                        .Where(key => key != null && existing.Add(key.sharedControl))
                        .Select(key => new FavoriteMenuEntry { source = key, parentId = addParent }).ToArray();
                    if (added.Length > 0)
                    {
                        ChangeEntries("Add selected favorites", list => list.AddRange(added));
                        Reveal(addParent, entries);
                    }
                    batchSources.Clear();
                    GUIUtility.ExitGUI();
                }
            using (new EditorGUI.DisabledScope(batchEntries.Count == 0))
                if (GUILayout.Button($"선택 이동 ({batchEntries.Count})"))
                    ShowBatchMove(view, entries);
            using (new EditorGUI.DisabledScope(batchSources.Count + batchEntries.Count == 0))
                if (GUILayout.Button("선택 해제", GUILayout.Width(76)))
                {
                    batchSources.Clear();
                    batchEntries.Clear();
                }
        }

        private void ShowBatchMove(MenuView view, List<FavoriteMenuEntry> entries)
        {
            var config = avatar.GetComponent<AvatarCustomizer>();
            if (!config) return;
            var selected = entries.Where(batchEntries.Contains).ToArray();
            var targetMenu = new GenericMenu();
            var selectedAvatar = avatar;
            int sourceIndex = menuIndex;
            int count = config.additionalMenus?.Count ?? 0;
            for (int index = 0; index <= count; index++)
            {
                var group = config.GetMenu(index);
                if (group == null) continue;
                int destinationIndex = index;
                var choices = FolderChoices(group.entries ?? new List<FavoriteMenuEntry>(), group.DisplayName);
                foreach (var choice in choices)
                {
                    var label = new GUIContent($"{index + 1}. {group.DisplayName.Replace("/", "／")}/{choice.Path.Replace("/", "／")}");
                    if (index == sourceIndex && selected.All(e => e.Parent == choice.Id))
                        targetMenu.AddDisabledItem(label, true);
                    else
                        targetMenu.AddItem(label, false, () =>
                        {
                            if (avatar != selectedAvatar || menuIndex != sourceIndex) return;
                            int moved = 0, duplicates = 0;
                            Change("Move selected favorites", c =>
                            {
                                var source = c.GetMenu(sourceIndex)?.entries;
                                var destination = c.GetMenu(destinationIndex);
                                if (source == null || destination == null) return;
                                var target = destinationIndex == 0 ? (c.entries ??= new List<FavoriteMenuEntry>()) :
                                    (destination.entries ??= new List<FavoriteMenuEntry>());
                                if (choice.Id.Length > 0 && !target.Any(e => e != null && e.folderId == choice.Id)) return;
                                foreach (var entry in selected)
                                {
                                    if (!source.Contains(entry) || (source == target && entry.Parent == choice.Id)) continue;
                                    if (target.Any(e => e != null && !e.IsFolder && e.Parent == choice.Id && SameShortcut(view, e, entry)))
                                    {
                                        duplicates++;
                                        continue;
                                    }
                                    source.Remove(entry);
                                    entry.parentId = choice.Id;
                                    target.Add(entry);
                                    batchEntries.Remove(entry);
                                    moved++;
                                }
                            });
                            if (destinationIndex == sourceIndex) Reveal(choice.Id, entries);
                            status = $"선택한 항목 {moved}개를 이동했습니다." +
                                (duplicates > 0 ? $" 이미 같은 바로가기가 있는 {duplicates}개는 원래 위치에 남겼습니다." : "");
                            statusType = MessageType.Info;
                            Repaint();
                        });
                }
            }
            targetMenu.ShowAsContext();
        }

        private static bool SameShortcut(MenuView view, FavoriteMenuEntry left, FavoriteMenuEntry right)
        {
            if ((left.label ?? "").Trim() != (right.label ?? "").Trim() || left.source == null || right.source == null)
                return false;
            var match = view.Resolve(left.source);
            return (match != null && match.sharedControl == view.Resolve(right.source)?.sharedControl) ||
                (left.source.SamePath(right.source) && left.source.SameBinding(right.source));
        }
    }
}
#endif
