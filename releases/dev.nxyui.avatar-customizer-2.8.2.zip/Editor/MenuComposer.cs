#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using VRC.SDK3.Avatars.ScriptableObjects;
using Control = VRC.SDK3.Avatars.ScriptableObjects.VRCExpressionsMenu.Control;
using Object = UnityEngine.Object;

namespace AvatarMenuTools
{
    // The component's settings as the composer reads them. The build takes them in the Resolving phase; the window reads
    // them from the component when it works out the final menu itself.
    internal sealed class MenuSettings
    {
        internal string PageLabel;
        // Every favorites menu, the first one included; null when the component is missing or off.
        internal FavoriteMenuGroup[] Menus;
        internal MenuNameOverride[] Overrides = Array.Empty<MenuNameOverride>();
        internal MenuIconOverride[] Icons = Array.Empty<MenuIconOverride>();
        internal MenuMoveRule[] Moves = Array.Empty<MenuMoveRule>();
        internal MenuHideRule[] Hides = Array.Empty<MenuHideRule>();
        internal MenuDefaultOverride[] Defaults = Array.Empty<MenuDefaultOverride>();
        internal MenuFolderRule[] Folders = Array.Empty<MenuFolderRule>();
        // The blendshape controls the menus use, by id: their settings (BlendshapeControlBuilder.Fingerprint), and how a
        // control looks in the menu (for the window's row of one that cannot be built).
        internal readonly Dictionary<string, string> Shapes = new Dictionary<string, string>();
        internal readonly Dictionary<string, (string Name, bool Radial)> ShapeLooks = new Dictionary<string, (string, bool)>();

        // Something to change. Without it the build leaves the avatar's menu as it is.
        internal bool Configured => Menus != null &&
            (Menus.Any(m => (m?.entries?.Count ?? 0) > 0) || Overrides.Length > 0 || Defaults.Length > 0 || Icons.Any(x => x?.source != null) ||
             Moves.Any(m => m?.source != null) || Hides.Any(h => h?.source != null) || Folders.Length > 0 || PageLabel != null);

        internal void Read(AvatarCustomizer c)
        {
            if (!c || !c.enabled) return;
            Menus = new[] { c.GetMenu(0) }.Concat(c.additionalMenus ?? Enumerable.Empty<FavoriteMenuGroup>()).ToArray();
            Overrides = c.nameOverrides?.ToArray() ?? Array.Empty<MenuNameOverride>();
            Icons = c.iconOverrides?.ToArray() ?? Array.Empty<MenuIconOverride>();
            // Moves and hides keep the component's order and gaps: their review messages carry the index of the rule to
            // repair. The organizer skips empty ones.
            Moves = c.menuMoves?.ToArray() ?? Array.Empty<MenuMoveRule>();
            Hides = c.hiddenItems?.ToArray() ?? Array.Empty<MenuHideRule>();
            Defaults = c.defaultOverrides?.Where(o => o?.source != null).ToArray() ?? Array.Empty<MenuDefaultOverride>();
            Folders = c.createdFolders?.Where(f => f != null && !string.IsNullOrEmpty(f.id)).ToArray() ?? Array.Empty<MenuFolderRule>();
            PageLabel = string.IsNullOrWhiteSpace(c.nextPageLabel) ? null : c.nextPageLabel.Trim();
            foreach (var id in BlendshapeControlBuilder.UsedIds(c))
                if (c.FindShape(id) is BlendshapeControl shape)
                {
                    Shapes[id] = BlendshapeControlBuilder.Fingerprint(shape, c.transform);
                    ShapeLooks[id] = (shape.blendshape, shape.type == BlendshapeControlType.Radial);
                }
        }

        internal static MenuSettings From(AvatarCustomizer c)
        {
            var settings = new MenuSettings();
            settings.Read(c);
            return settings;
        }
    }

    internal enum MenuOriginKind { Unknown, Original, MadeFolder, LegacyFolder, PageLink, FavoritesMenu, FavoritesFolder, Shortcut, Shape }

    // Where a control of the final menu comes from, and so which setting an edit of it changes.
    internal sealed class MenuOrigin
    {
        internal MenuOriginKind Kind;
        // Original: the avatar's own key (names before "이름 변경"). Shortcut: the key of the avatar's item it copies (null
        // for a folder made by an old move rule).
        internal FavoriteMenuKey Key;
        // Shortcut: the item of the organized menu it copies (shown names, hidden mark).
        internal FavoriteMenuKey Target;
        // MadeFolder: its id. LegacyFolder: its name. FavoritesFolder: its folderId. Shape: its shapeId.
        internal string Id;
        // Favorites kinds: the favorites menu (0 = the first) and the entry in it (-1 for the menu itself), and the menu's
        // name, so that a menu taking another's place after a deletion is not taken for it.
        internal int MenuIndex = -1, EntryIndex = -1;
        internal string MenuName;
        // PageLink: made by this tool, not copied from the avatar's menu.
        internal bool Made;
    }

    internal enum MenuLevelKind { Unknown, Root, Original, MadeFolder, LegacyFolder, Favorites }

    // The setting a menu level (all of its pages) belongs to: what an edit inside it changes, wherever it is opened from.
    internal sealed class MenuLevel
    {
        internal MenuLevelKind Kind;
        // Original: the avatar's submenu that opens it.
        internal FavoriteMenuKey Key;
        // MadeFolder: its id. LegacyFolder: its name. Favorites: the folder's folderId, "" for the favorites menu itself.
        internal string Id;
        // Favorites: the favorites menu (0 = the first).
        internal int MenuIndex = -1;
    }

    // A worked-out final menu: the organized copy of the avatar's menu with the favorites menus installed, and the starting
    // values to give the expression parameters. Its menus are Organizer.Created; whoever keeps them saves them (the build)
    // or calls Destroy (everyone else).
    internal sealed class MenuComposition
    {
        internal MenuOrganizer Organizer;
        internal readonly HashSet<VRCExpressionsMenu> FavoriteMenus = new HashSet<VRCExpressionsMenu>();
        // The controls and menus the favorites menus were made of; the rest is told by the organizer (OriginOf, LevelOf).
        internal readonly Dictionary<Control, MenuOrigin> FavoriteOrigins = new Dictionary<Control, MenuOrigin>();
        internal readonly Dictionary<VRCExpressionsMenu, MenuLevel> FavoriteLevels = new Dictionary<VRCExpressionsMenu, MenuLevel>();
        // Favorites folders and menus left out because they held nothing: a stand-in control (in no built menu; its origin
        // is in FavoriteOrigins), the level it would be in, and the control after it (null at the end). Each opens an
        // empty stand-in menu of its own (StandIns), so the window can show the empty folders inside and take drops.
        internal readonly List<(Control Control, VRCExpressionsMenu Level, Control Before)> FavoriteGhosts =
            new List<(Control, VRCExpressionsMenu, Control)>();
        internal readonly List<VRCExpressionsMenu> StandIns = new List<VRCExpressionsMenu>();
        // Why a blendshape control of a favorites entry was not built, by control id. Such an entry shows in the window
        // as a stand-in where it would be (in FavoriteGhosts, its origin in FavoriteOrigins).
        internal readonly Dictionary<string, string> ShapeProblems = new Dictionary<string, string>();
        // Starting values by expression parameter name, already in the parameter's type (a bool 0/1, an int rounded).
        internal readonly Dictionary<string, float> Defaults = new Dictionary<string, float>();
        internal int MenuCount, FavoriteCount, FolderCount, ShapeCount;
        internal bool PageLabelSet;

        internal VRCExpressionsMenu Root => Organizer?.Root;

        // The final menu differs from the avatar's, so the build installs the copy.
        internal bool MenuChanged => Root && (MenuCount > 0 || Organizer.NameCount > 0 || Organizer.IconCount > 0 || Organizer.MoveCount > 0 ||
                                             Organizer.HideCount > 0 || Organizer.FolderCount > 0 || PageLabelSet);

        internal void Destroy()
        {
            DestroyStandIns();
            if (Organizer == null) return;
            foreach (var menu in Organizer.Created) if (menu) Object.DestroyImmediate(menu);
            Organizer.Created.Clear();
        }

        // The build keeps the menus it saved but never the stand-ins.
        internal void DestroyStandIns()
        {
            foreach (var menu in StandIns) if (menu) Object.DestroyImmediate(menu);
            StandIns.Clear();
        }

        internal MenuOrigin OriginOf(Control c)
        {
            if (c == null || Organizer == null) return new MenuOrigin();
            if (FavoriteOrigins.TryGetValue(c, out var made)) return made;
            if (Organizer.PageLinks.ContainsValue(c))
                return new MenuOrigin { Kind = MenuOriginKind.PageLink, Made = !Organizer.OriginalLinks.Contains(c) };
            if (Organizer.FolderIdOf(c) is string id) return new MenuOrigin { Kind = MenuOriginKind.MadeFolder, Id = id };
            if (Organizer.LegacyFolders.TryGetValue(c, out var name)) return new MenuOrigin { Kind = MenuOriginKind.LegacyFolder, Id = name };
            if (Organizer.OriginalKeyOf(c) is FavoriteMenuKey key) return new MenuOrigin { Kind = MenuOriginKind.Original, Key = key };
            return new MenuOrigin();
        }

        // The level a page of the final menu belongs to.
        internal MenuLevel LevelOf(VRCExpressionsMenu page)
        {
            if (Organizer == null || !page) return new MenuLevel();
            var first = Organizer.FirstPage(page);
            if (first == Root) return new MenuLevel { Kind = MenuLevelKind.Root };
            if (FavoriteLevels.TryGetValue(first, out var favorites)) return favorites;
            foreach (var folder in Organizer.Folders)
                if (folder.Value.Menu == first) return new MenuLevel { Kind = MenuLevelKind.MadeFolder, Id = folder.Key };
            foreach (var legacy in Organizer.LegacyFolders)
                if (legacy.Key.subMenu == first) return new MenuLevel { Kind = MenuLevelKind.LegacyFolder, Id = legacy.Value };
            if (Organizer.SubmenuKeyOf(first) is FavoriteMenuKey key) return new MenuLevel { Kind = MenuLevelKind.Original, Key = key };
            return new MenuLevel();
        }
    }

    internal static class MenuComposer
    {
        // Expression parameter types by name (the first of each name, as the build looks them up); null without the asset.
        internal static Dictionary<string, VRCExpressionParameters.ValueType> ParameterTypes(VRCExpressionParameters parameters) =>
            !parameters ? null : (parameters.parameters ?? Array.Empty<VRCExpressionParameters.Parameter>())
                .Where(p => p != null && p.name != null).GroupBy(p => p.name).ToDictionary(g => g.Key, g => g.First().valueType);

        // The build's two edits on a copy of the avatar's finished menu (root): "원본 메뉴 정리", then the favorites menus.
        // Neither root nor any asset is changed. shapes: the blendshape controls that can be built (BlendshapeControlBuilder).
        // parameters: ParameterTypes of the avatar's expression parameters. review: also report what only a read shows
        // (items a pinned menu pushed to a later page). pageLinks: when root is a read's copy, the page links the read found
        // (MenuSnapshot.PageLinks).
        internal static MenuComposition Compose(VRCExpressionsMenu root, MenuSettings settings, BlendshapeControlBuilder.State shapes,
            IReadOnlyDictionary<string, VRCExpressionParameters.ValueType> parameters, List<FavoriteMenuBuilder.Issue> issues,
            bool review, HideFlags flags = HideFlags.None, ICollection<(VRCExpressionsMenu, Control)> pageLinks = null)
        {
            void Report(string title, string detail, bool warning = true,
                FavoriteMenuBuilder.RepairTarget target = FavoriteMenuBuilder.RepairTarget.None,
                int menuIndex = -1, int itemIndex = -1, FavoriteMenuKey saved = null, FavoriteMenuKey current = null)
            {
                issues.Add(new FavoriteMenuBuilder.Issue
                {
                    Title = title, Detail = detail, Warning = warning, Target = target,
                    MenuIndex = menuIndex, ItemIndex = itemIndex, Saved = saved, Current = current,
                });
            }

            bool configured = settings.Configured;
            var result = new MenuComposition { PageLabelSet = configured && settings.PageLabel != null };
            // First edit ("원본 메뉴 정리"): renames, moves and hides, on a copy of the finished menu.
            var organizer = result.Organizer = new MenuOrganizer(root, FavoriteMenuBuilder.LoadMoreIcon(),
                configured ? settings.PageLabel : null, configured ? settings.Overrides : null,
                configured ? settings.Moves : null, configured ? settings.Hides : null, configured ? settings.Folders : null,
                (title, detail, warning, target, index, saved, current) => Report(title, detail, warning, target, -1, index, saved, current),
                flags, pageLinks, configured ? settings.Icons : null);
            if (!configured) return result;

            try { Install(); }
            catch
            {
                // A half-made menu must not outlive the error: the window's copies are never saved, so nothing else frees them.
                result.Destroy();
                throw;
            }
            return result;

            void Install()
            {
                // Second edit: the favorites menus, made from the organized menu.
                // Saved settings point at the avatar's own items; the folders made here are found by id, so they never make
                // an item of the same name and path ambiguous.
                var keys = organizer.Organized.Where(k => k.createdFolder == null).ToArray();
                var items = organizer.OrganizedItems;
                var rootCopy = organizer.Root;
                Control Match(FavoriteMenuKey saved, string title, FavoriteMenuBuilder.RepairTarget target, int menuIndex, int itemIndex,
                    out FavoriteMenuKey current)
                {
                    current = FavoriteMenuKey.Resolve(keys, saved, out var match);
                    if (match != FavoriteMenuMatch.Exact)
                        Report(title, FavoriteMenuBuilder.MatchDetail(match), match != FavoriteMenuMatch.Moved, target, menuIndex, itemIndex, saved, current);
                    return current == null ? null : items[current];
                }

                // Favorites menus placed without a pin, to say afterwards when one ended up behind a page link.
                var placements = new List<(string Name, bool AtRoot, VRCExpressionsMenu First, Control Control)>();
                var pinCounts = new Dictionary<VRCExpressionsMenu, int>();
                var installedNames = new Dictionary<VRCExpressionsMenu, HashSet<string>>();
                for (int menuIndex = 0; menuIndex < settings.Menus.Length; menuIndex++)
                {
                    var menu = settings.Menus[menuIndex];
                    if ((menu?.entries?.Count ?? 0) == 0) continue;
                    string menuName = menu.DisplayName;
                    string location = $"{menuName} / 설치 위치";
                    VRCExpressionsMenu destination;
                    if (menu.InFolder)
                    {
                        // A folder made in the built menu, by id.
                        destination = organizer.Folders.TryGetValue(menu.destinationFolder, out var made) ? made.Menu : null;
                        if (!destination)
                        {
                            Report(location, "설치할 새 폴더를 찾을 수 없습니다.", true, FavoriteMenuBuilder.RepairTarget.None, menuIndex);
                            continue;
                        }
                        if (organizer.Organized.Any(k => k.createdFolder == menu.destinationFolder && k.hidden))
                            Report(location, "설치 위치가 숨긴 메뉴 안에 있어서, 이 메뉴는 그 위치를 여는 즐겨찾기 바로가기로만 열 수 있어요.");
                    }
                    else
                    {
                        destination = menu.useRoot ? rootCopy :
                            Match(menu.destination, location, FavoriteMenuBuilder.RepairTarget.Destination, menuIndex, -1, out _)?.subMenu;
                        if (!destination)
                        {
                            if (menu.useRoot || !issues.Any(i => i.Title == location && i.Current == null))
                                Report(location, "설치할 메뉴가 비어 있거나 찾을 수 없습니다.", true,
                                    menu.useRoot ? FavoriteMenuBuilder.RepairTarget.None : FavoriteMenuBuilder.RepairTarget.Destination,
                                    menuIndex, -1, menu.destination);
                            continue;
                        }
                        if (!menu.useRoot && FavoriteMenuKey.Resolve(keys, menu.destination)?.hidden == true)
                            Report(location, "설치 위치를 원본 메뉴 정리에서 숨겨서, 이 메뉴는 그 위치를 여는 즐겨찾기 바로가기로만 열 수 있어요.");
                    }
                    var links = new HashSet<Control>(organizer.PageLinks.Values);
                    var pages = organizer.Pages(destination).ToArray();
                    var sameName = pages.SelectMany(p => p.controls).Where(c =>
                        c != null && !links.Contains(c) && c.type == Control.ControlType.SubMenu && c.name == menuName).ToArray();
                    bool duplicate = sameName.Any(c => !organizer.IsMadeFolder(c));
                    if (!duplicate && sameName.Length > 0)
                        Report(menuName, "같은 위치에 이름이 같은 새 폴더가 있어요. 빈 폴더면 빌드에서 빠져요.", false);
                    if (duplicate || (installedNames.TryGetValue(destination, out var siblings) && siblings.Contains(menuName)))
                    {
                        Report(menuName, "같은 위치에 이름이 같은 메뉴가 있어 생성을 건너뛰었습니다.");
                        continue;
                    }

                    var target = pages.Last();
                    var children = menu.entries.Select((entry, index) => (entry, index))
                        .Where(x => x.entry != null).ToLookup(x => x.entry.Parent);
                    var madeFolders = new HashSet<string>();
                    // Empty folders by the list they were to sit in, until that list becomes a menu (or a stand-in).
                    var ghosts = new List<(Control Control, Control Before, List<Control> In, List<Control> Inner)>();
                    void PlaceGhosts(List<Control> list, VRCExpressionsMenu menu)
                    {
                        foreach (var ghost in ghosts.Where(g => g.In == list))
                        {
                            result.FavoriteGhosts.Add((ghost.Control, menu, ghost.Before));
                            PlaceGhosts(ghost.Inner, ghost.Control.subMenu);
                        }
                    }
                    VRCExpressionsMenu StandIn(string name, string folderId)
                    {
                        var stand = ScriptableObject.CreateInstance<VRCExpressionsMenu>();
                        stand.name = name;
                        stand.hideFlags = HideFlags.HideAndDontSave;
                        stand.controls = new List<Control>();
                        result.StandIns.Add(stand);
                        result.FavoriteLevels[stand] = new MenuLevel { Kind = MenuLevelKind.Favorites, Id = folderId, MenuIndex = menuIndex };
                        return stand;
                    }
                    List<Control> MakeChildren(string parent, string path, int depth)
                    {
                        var controls = new List<Control>();
                        var empty = new List<(Control Control, int At, List<Control> Inner)>();
                        foreach (var (entry, index) in children[parent])
                        {
                            if (entry.IsFolder)
                            {
                                string label = string.IsNullOrWhiteSpace(entry.label) ? "새 폴더" : entry.label.Trim();
                                string folderPath = $"{path} / {label}";
                                if (depth >= 64 || !madeFolders.Add(entry.folderId))
                                {
                                    Report(folderPath, "폴더 깊이를 초과했거나 폴더가 중복되어 제외됩니다.");
                                    continue;
                                }
                                var contents = MakeChildren(entry.folderId, folderPath, depth + 1);
                                if (contents.Count == 0)
                                {
                                    Report(folderPath, "사용할 수 있는 항목이 없어 빌드에서 생략됩니다.", false);
                                    var stand = FavoriteMenuBuilder.Submenu(label, StandIn(label, entry.folderId));
                                    stand.icon = entry.icon;
                                    result.FavoriteOrigins[stand] = new MenuOrigin
                                        { Kind = MenuOriginKind.FavoritesFolder, Id = entry.folderId, MenuIndex = menuIndex, EntryIndex = index, MenuName = menuName };
                                    empty.Add((stand, controls.Count, contents));
                                    continue;
                                }
                                var sub = organizer.NewMenu(label);
                                sub.controls = contents;
                                PlaceGhosts(contents, sub);
                                organizer.Paginate(sub);
                                var folder = FavoriteMenuBuilder.Submenu(label, sub);
                                folder.icon = entry.icon;
                                controls.Add(folder);
                                result.FavoriteOrigins[folder] = new MenuOrigin
                                    { Kind = MenuOriginKind.FavoritesFolder, Id = entry.folderId, MenuIndex = menuIndex, EntryIndex = index, MenuName = menuName };
                                result.FavoriteLevels[sub] = new MenuLevel { Kind = MenuLevelKind.Favorites, Id = entry.folderId, MenuIndex = menuIndex };
                                result.FolderCount++;
                                continue;
                            }
                            if (entry.IsShape)
                            {
                                if (!shapes.Controls.TryGetValue(entry.shapeId, out var built))
                                {
                                    string problem = shapes.Problems.TryGetValue(entry.shapeId, out var why) ? why : "블렌드쉐이프 컨트롤을 만들 수 없습니다.";
                                    Report($"{path} / {(string.IsNullOrWhiteSpace(entry.label) ? "블렌드쉐이프" : entry.label.Trim())}",
                                        problem + " 이 항목은 빌드에서 제외됩니다.");
                                    // The window still shows it where it would be, greyed, with the reason.
                                    bool reset = entry.shapeId == BlendshapeControl.ResetId;
                                    settings.ShapeLooks.TryGetValue(entry.shapeId, out var look);
                                    var missing = new Control
                                    {
                                        name = !string.IsNullOrWhiteSpace(entry.label) ? entry.label.Trim() :
                                            reset ? BlendshapeControlBuilder.ResetName : look.Name ?? "블렌드쉐이프",
                                        type = reset ? Control.ControlType.Button : look.Radial ? Control.ControlType.RadialPuppet : Control.ControlType.Toggle,
                                        icon = entry.icon, value = 1f, parameter = new Control.Parameter { name = "" },
                                        subParameters = new Control.Parameter[0], labels = new Control.Label[0],
                                    };
                                    result.FavoriteOrigins[missing] = new MenuOrigin
                                        { Kind = MenuOriginKind.Shape, Id = entry.shapeId, MenuIndex = menuIndex, EntryIndex = index, MenuName = menuName };
                                    result.ShapeProblems[entry.shapeId] = problem;
                                    empty.Add((missing, controls.Count, new List<Control>()));
                                    continue;
                                }
                                if (shapes.Notes.TryGetValue(entry.shapeId, out var note))
                                    Report($"{path} / {(string.IsNullOrWhiteSpace(entry.label) ? built.Name : entry.label.Trim())}", note, false);
                                var shape = built.Reset ? new Control
                                {
                                    name = string.IsNullOrWhiteSpace(entry.label) ? built.Name : entry.label.Trim(),
                                    type = Control.ControlType.Button, icon = entry.icon, value = 1f,
                                    parameter = new Control.Parameter { name = built.Parameter },
                                    subParameters = new Control.Parameter[0], labels = new Control.Label[0],
                                } : new Control
                                {
                                    name = string.IsNullOrWhiteSpace(entry.label) ? built.Name : entry.label.Trim(),
                                    type = built.Radial ? Control.ControlType.RadialPuppet : Control.ControlType.Toggle,
                                    icon = entry.icon, value = 1f,
                                    parameter = new Control.Parameter { name = built.Radial ? "" : built.Parameter },
                                    subParameters = built.Radial ? new[] { new Control.Parameter { name = built.Parameter } } : new Control.Parameter[0],
                                    labels = new Control.Label[0],
                                };
                                controls.Add(shape);
                                result.FavoriteOrigins[shape] = new MenuOrigin
                                    { Kind = MenuOriginKind.Shape, Id = entry.shapeId, MenuIndex = menuIndex, EntryIndex = index, MenuName = menuName };
                                result.ShapeCount++;
                                continue;
                            }
                            string title = $"{path} / {entry.source?.DisplayPath ?? "(원본 없음)"}";
                            var control = Match(entry.source, title, FavoriteMenuBuilder.RepairTarget.Shortcut, menuIndex, index, out var current);
                            if (control == null) continue;
                            // Check the build graph, including the menus already installed at other destinations.
                            if (control.type == Control.ControlType.SubMenu &&
                                (!control.subMenu || FavoriteMenuBuilder.Reaches(control.subMenu, destination, target, new HashSet<VRCExpressionsMenu>())))
                            {
                                Report(title, control.subMenu ? "메뉴가 순환하므로 바로가기를 제외했습니다." :
                                    "연결된 하위 메뉴가 없습니다.", true, FavoriteMenuBuilder.RepairTarget.Shortcut, menuIndex, index, entry.source);
                                continue;
                            }
                            // The organized copy already has its shown name; a shortcut opens the same (organized) submenu.
                            var shortcut = FavoriteMenuBuilder.Copy(control, string.IsNullOrWhiteSpace(entry.label) ? control.name : entry.label.Trim(), m => m);
                            if (entry.icon) shortcut.icon = entry.icon;
                            controls.Add(shortcut);
                            result.FavoriteOrigins[shortcut] = new MenuOrigin
                            {
                                Kind = MenuOriginKind.Shortcut, Key = organizer.OriginalKeyOf(control), Target = current,
                                MenuIndex = menuIndex, EntryIndex = index, MenuName = menuName,
                            };
                            result.FavoriteCount++;
                        }
                        foreach (var (stand, at, inner) in empty) ghosts.Add((stand, at < controls.Count ? controls[at] : null, controls, inner));
                        return controls;
                    }

                    var chosen = MakeChildren("", menuName, 0);
                    if (chosen.Count == 0)
                    {
                        Report(menuName, "넣을 수 있는 항목이 없어 이 즐겨찾기 메뉴는 빌드에서 빠져요.", false);
                        // Nothing to build from it: the window still shows it at the end of where it would go, empty.
                        var stand = FavoriteMenuBuilder.Submenu(menuName, StandIn(menuName, ""));
                        stand.icon = menu.icon;
                        result.FavoriteOrigins[stand] = new MenuOrigin { Kind = MenuOriginKind.FavoritesMenu, MenuIndex = menuIndex, MenuName = menuName };
                        result.FavoriteGhosts.Add((stand, destination, null));
                        PlaceGhosts(chosen, stand.subMenu);
                        continue;
                    }
                    var favorites = organizer.NewMenu(menuName);
                    result.FavoriteMenus.Add(favorites);
                    favorites.controls = chosen;
                    PlaceGhosts(chosen, favorites);
                    organizer.Paginate(favorites);
                    var installed = FavoriteMenuBuilder.Submenu(menuName, favorites);
                    installed.icon = menu.icon;
                    result.FavoriteOrigins[installed] = new MenuOrigin { Kind = MenuOriginKind.FavoritesMenu, MenuIndex = menuIndex, MenuName = menuName };
                    result.FavoriteLevels[favorites] = new MenuLevel { Kind = MenuLevelKind.Favorites, Id = "", MenuIndex = menuIndex };
                    pinCounts.TryGetValue(destination, out int slot);
                    if (menu.pinToFirstPage && slot < VRCExpressionsMenu.MAX_CONTROLS - 1)
                    {
                        var before = review ? organizer.OriginalPages(destination) : null;
                        organizer.InsertPinned(destination, slot, installed);
                        pinCounts[destination] = slot + 1;
                        if (before != null)
                        {
                            var after = organizer.OriginalPages(destination);
                            var pushed = before.Where(p => after.TryGetValue(p.Key, out int page) && p.Value != page)
                                .Select(p => $"{p.Key.name} ({p.Value} → {after[p.Key]}페이지)").ToArray();
                            if (pushed.Length > 0)
                                Report(menuName, "고정으로 이동한 기존 항목\n" + string.Join("\n", pushed), false);
                        }
                    }
                    else
                    {
                        if (menu.pinToFirstPage) Report(menuName, "고정할 수 있는 자리가 가득 차 마지막 페이지에 배치됩니다.");
                        target.controls.Add(installed);
                        organizer.Paginate(target);
                    }
                    if (!menu.pinToFirstPage) placements.Add((menuName, menu.useRoot, destination, installed));
                    if (!installedNames.TryGetValue(destination, out var used)) installedNames.Add(destination, used = new HashSet<string>());
                    used.Add(menuName);
                    result.MenuCount++;
                }

                // Made folders still empty now are left out of the build; their pages close up before the notes below. The
                // window shows them where they were (Organizer.Dropped), so they can be filled.
                organizer.DropEmptyFolders();

                // Behind a page link a favorites menu is easy to miss, so say where it ended up.
                foreach (var placed in placements)
                {
                    int placedPage = organizer.PageOf(placed.First, placed.Control);
                    if (placedPage > 1)
                        Report(placed.Name, $"{(placed.AtRoot ? "최상위 메뉴" : "설치 위치")}의 {placedPage}페이지" +
                            (placedPage == 2 ? $"(‘{organizer.PageLabel}’ 안)" : "") + "에 들어갔어요. 앞 페이지가 가득 찼기 때문이에요. " +
                            "첫 페이지에 두려면 이 메뉴의 ‘첫 페이지에 고정’을 켜세요.", false);
                }

                // Default values: the starting value of the parameter behind a favorite.
                var defaults = new Dictionary<string, (float Value, string Title)>();
                void AddDefault(FavoriteMenuKey source, float stored, string title, bool reportMissing)
                {
                    var key = FavoriteMenuKey.Resolve(keys, source);
                    if (key == null)
                    {
                        if (reportMissing) Report(title, "원본 메뉴 항목을 찾을 수 없어 기본값을 적용하지 못했습니다.");
                        return;
                    }
                    var control = items[key];
                    string parameter;
                    float value;
                    if (control.type == Control.ControlType.Toggle)
                    {
                        parameter = control.parameter?.name;
                        value = stored >= .5f ? control.value : 0f;
                    }
                    else if (control.type == Control.ControlType.RadialPuppet)
                    {
                        parameter = control.subParameters?.FirstOrDefault()?.name;
                        value = Mathf.Clamp01(stored);
                    }
                    else
                    {
                        Report(title, "토글과 래디얼만 기본값을 정할 수 있어 제외했습니다.", false);
                        return;
                    }
                    if (string.IsNullOrEmpty(parameter))
                    {
                        Report(title, "파라미터가 없는 항목이라 기본값을 정할 수 없습니다.");
                        return;
                    }
                    if (defaults.TryGetValue(parameter, out var prior))
                    {
                        if (!Mathf.Approximately(prior.Value, value))
                            Report(title, $"‘{parameter}’의 기본값은 먼저 정한 {prior.Title}을 따릅니다. 이 값은 제외했습니다.");
                        return;
                    }
                    defaults.Add(parameter, (value, title));
                }
                foreach (var rule in settings.Defaults)
                    AddDefault(rule.source, rule.value, $"기본값 / {rule.source.DisplayPath}", true);
                // Defaults saved on a favorite by 2.0.0. A missing original is already reported for the shortcut.
                foreach (var menu in settings.Menus)
                    foreach (var entry in menu?.entries ?? new List<FavoriteMenuEntry>())
                        if (entry != null && !entry.IsFolder && !entry.IsShape && entry.overrideDefault)
                            AddDefault(entry.source, entry.defaultValue, $"{menu.DisplayName} / {entry.source?.DisplayPath} · 기본값", false);
                if (defaults.Count > 0 && parameters == null)
                    Report("기본값", "Expression Parameters가 없어 기본값을 바꾸지 못했습니다.");
                else
                    foreach (var pair in defaults)
                    {
                        if (!parameters.TryGetValue(pair.Key, out var type))
                        {
                            Report(pair.Value.Title, $"‘{pair.Key}’이 Expression Parameters에 없어 기본값을 바꾸지 못했습니다.");
                            continue;
                        }
                        float value = pair.Value.Value;
                        result.Defaults[pair.Key] = type == VRCExpressionParameters.ValueType.Bool ? (value >= .5f ? 1f : 0f)
                            : type == VRCExpressionParameters.ValueType.Int ? Mathf.Round(value) : value;
                    }
            }
        }
    }
}
#endif
