#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using VRC.SDK3.Avatars.Components;
using Object = UnityEngine.Object;

namespace AssemblyChecker
{
    // "조립 점검기": builds a copy of the avatar with NDMF and shows what would go wrong in VRChat (점검), every texture
    // with where it sits (텍스처), and the synced bits and the parameter cleanup (파라미터). The scene avatar is changed
    // only by the cleanup settings on the parameter tab.
    internal sealed class AssemblyCheckerWindow : EditorWindow
    {
        private static readonly string[] TextureFilters = { "전체", "꺼진 칸", "애니메이션 전용", "셰이더에 없는 칸" };

        private VRCAvatarDescriptor avatar;
        private int tab;
        private string status;
        private MessageType statusType;

        // The last check (null before one) and the avatar it was made for.
        private VRCAvatarDescriptor checkedAvatar;
        private List<Finding> findings;
        private List<TextureRow> textures;
        private List<BitSource> sources;
        private int totalBits;
        private ParameterCleanup.Report cleanup;

        private Finding selectedFinding;
        private TextureRow selectedTexture;
        private BitSource selectedSource;
        private int textureFilter;
        private string keepDraft = "";
        private Vector2 leftScroll, rightScroll;

        private GUIStyle wrappedBold;
        private GUIStyle WrappedBold => wrappedBold ??= new GUIStyle(EditorStyles.boldLabel) { wordWrap = true };

        private static Color Selected => EditorGUIUtility.isProSkin ? new Color(0.24f, 0.48f, 0.9f, 0.28f) : new Color(0.24f, 0.48f, 0.9f, 0.2f);

        [MenuItem("NXYUI/Assembly Checker")]
        private static void Open() => GetWindow<AssemblyCheckerWindow>("조립 점검기");

        // The 파라미터 tab, for the avatar selected now (the window follows the selection).
        internal static void ShowParameters()
        {
            var window = GetWindow<AssemblyCheckerWindow>("조립 점검기");
            window.tab = 2;
            window.Repaint();
        }

        private void OnEnable()
        {
            minSize = new Vector2(740, 420);
            if (!avatar) SetAvatar(FromSelection() ?? FindSceneAvatars().FirstOrDefault());
        }

        private void OnSelectionChange()
        {
            var selected = FromSelection();
            if (selected && selected != avatar)
            {
                SetAvatar(selected);
                Repaint();
            }
        }

        private static VRCAvatarDescriptor FromSelection()
        {
            var go = Selection.activeGameObject;
            var descriptor = go ? go.GetComponentInParent<VRCAvatarDescriptor>(true) : null;
            return descriptor && IsSceneAvatar(descriptor) ? descriptor : null;
        }

        private static IEnumerable<VRCAvatarDescriptor> FindSceneAvatars() =>
            FindObjectsOfType<VRCAvatarDescriptor>(true).Where(IsSceneAvatar);

        private static bool IsSceneAvatar(VRCAvatarDescriptor d) =>
            d && !EditorUtility.IsPersistent(d) && d.gameObject.scene.IsValid() && d.gameObject.scene.isLoaded &&
            !EditorSceneManager.IsPreviewScene(d.gameObject.scene) && PrefabStageUtility.GetPrefabStage(d.gameObject) == null;

        private void SetAvatar(VRCAvatarDescriptor next)
        {
            avatar = next;
            if (avatar == checkedAvatar) return;
            findings = null;
            textures = null;
            sources = null;
            cleanup = null;
            checkedAvatar = null;
            selectedFinding = null;
            selectedTexture = null;
            selectedSource = null;
            status = null;
        }

        private void OnGUI()
        {
            DrawHeader();
            if (findings == null)
            {
                EditorGUILayout.HelpBox("아바타를 고르고 ‘점검하기’를 누르세요. 복제본을 NDMF로 빌드해서 업로드될 모습 그대로 점검해요. " +
                                        "씬의 아바타는 바뀌지 않아요.", MessageType.Info);
                return;
            }
            int warnings = findings.Count(f => f.Severity == Severity.Warning);
            var labels = new[] { warnings > 0 ? $"점검 · 경고 {warnings}" : "점검", $"텍스처 {textures.Count}", $"파라미터 {totalBits}비트" };
            int next = GUILayout.Toolbar(tab, labels);
            if (next != tab)
            {
                tab = next;
                leftScroll = rightScroll = Vector2.zero;
            }
            EditorGUILayout.Space(4);
            using (new EditorGUILayout.HorizontalScope())
            {
                using (new EditorGUILayout.VerticalScope(GUILayout.Width(position.width * 0.48f)))
                using (var scroll = new EditorGUILayout.ScrollViewScope(leftScroll))
                {
                    leftScroll = scroll.scrollPosition;
                    if (tab == 0) DrawFindings();
                    else if (tab == 1) DrawTextureList();
                    else DrawSources();
                }
                using (new EditorGUILayout.VerticalScope())
                using (var scroll = new EditorGUILayout.ScrollViewScope(rightScroll))
                {
                    rightScroll = scroll.scrollPosition;
                    if (tab == 0) DrawFindingDetails();
                    else if (tab == 1) DrawTextureDetails();
                    else DrawCleanup();
                }
            }
        }

        private void DrawHeader()
        {
            using (new EditorGUILayout.HorizontalScope())
            {
                var next = (VRCAvatarDescriptor)EditorGUILayout.ObjectField("아바타", avatar, typeof(VRCAvatarDescriptor), true);
                if (next != avatar) SetAvatar(next && IsSceneAvatar(next) ? next : null);
                bool can = avatar && !EditorApplication.isPlayingOrWillChangePlaymode;
                var label = new GUIContent("점검하기", can ? "복제본을 빌드해서 점검해요. 씬의 아바타는 바뀌지 않아요." : "편집 모드에서 씬의 아바타를 골라 주세요.");
                using (new EditorGUI.DisabledScope(!can))
                    if (GUILayout.Button(label, GUILayout.Width(90)))
                    {
                        RunCheck();
                        GUIUtility.ExitGUI();
                    }
            }
            if (!avatar && EditorApplication.isPlayingOrWillChangePlaymode)
                EditorGUILayout.LabelField("플레이 모드에서는 점검할 수 없어요.", EditorStyles.wordWrappedMiniLabel);
            if (!string.IsNullOrEmpty(status)) EditorGUILayout.HelpBox(status, statusType);
        }

        private void RunCheck()
        {
            var target = avatar;
            try
            {
                EditorUtility.DisplayProgressBar("조립 점검기", "복제본을 빌드하고 있어요…", 0.2f);
                using (var built = BuiltAvatar.Build(target))
                {
                    EditorUtility.DisplayProgressBar("조립 점검기", "점검하고 있어요…", 0.7f);
                    findings = AssemblyChecks.Run(built);
                    textures = TextureReport.Collect(built);
                    sources = ParameterBits.Attribute(built, out totalBits);
                    cleanup = built.Cleanup;
                    checkedAvatar = target;
                    selectedFinding = null;
                    selectedTexture = null;
                    selectedSource = null;
                    int warnings = findings.Count(f => f.Severity == Severity.Warning);
                    if (built.Successful)
                    {
                        status = $"점검을 마쳤어요 ({DateTime.Now:HH:mm}): 경고 {warnings}개, 참고 {findings.Count - warnings}개.";
                        statusType = warnings > 0 ? MessageType.Warning : MessageType.Info;
                    }
                    else
                    {
                        status = "빌드 중 오류가 있었어요. NDMF 콘솔을 확인해 주세요. 오류가 난 부분은 결과에서 빠질 수 있어요.";
                        statusType = MessageType.Warning;
                    }
                }
            }
            catch (Exception e)
            {
                status = "점검 실패: " + e.Message;
                statusType = MessageType.Error;
                Debug.LogException(e);
            }
            finally
            {
                EditorUtility.ClearProgressBar();
                Repaint();
            }
        }

        // A list row in a helpBox frame that selects on click. Returns true when clicked.
        private bool Row(bool selected, Action draw)
        {
            var rect = EditorGUILayout.BeginVertical(EditorStyles.helpBox);
            draw();
            EditorGUILayout.EndVertical();
            if (selected && Event.current.type == EventType.Repaint) EditorGUI.DrawRect(rect, Selected);
            if (Event.current.type == EventType.MouseDown && rect.Contains(Event.current.mousePosition))
            {
                Event.current.Use();
                Repaint();
                return true;
            }
            return false;
        }

        private static void Badge(string text, float width = 0f)
        {
            if (width > 0f) GUILayout.Label(text, EditorStyles.miniBoldLabel, GUILayout.Width(width));
            else GUILayout.Label(text, EditorStyles.miniBoldLabel, GUILayout.ExpandWidth(false));
        }

        private static void Select(Object target)
        {
            if (!target) return;
            Selection.activeObject = target;
            EditorGUIUtility.PingObject(target);
        }

        // ---- 점검 -----------------------------------------------------------------------------------------------------

        private void DrawFindings()
        {
            foreach (var check in AssemblyChecks.Order)
            {
                var items = findings.Where(f => f.Check == check).ToList();
                EditorGUILayout.LabelField(check, items.Count == 0 ? "문제 없음" : $"{items.Count}개", EditorStyles.boldLabel);
                if (items.Count == 0)
                {
                    EditorGUILayout.LabelField(AssemblyChecks.About[check], EditorStyles.wordWrappedMiniLabel);
                    EditorGUILayout.Space(4);
                    continue;
                }
                foreach (var finding in items)
                    if (Row(finding == selectedFinding, () =>
                        {
                            using (new EditorGUILayout.HorizontalScope())
                            {
                                Badge(finding.Severity == Severity.Warning ? "⚠ 경고" : "참고", 46);
                                GUILayout.Label(new GUIContent(finding.Title, finding.Title), EditorStyles.label);
                            }
                        }))
                        selectedFinding = finding;
                EditorGUILayout.Space(8);
            }
        }

        private void DrawFindingDetails()
        {
            if (selectedFinding == null)
            {
                int warnings = findings.Count(f => f.Severity == Severity.Warning);
                EditorGUILayout.LabelField($"경고 {warnings}개 · 참고 {findings.Count - warnings}개", EditorStyles.boldLabel);
                EditorGUILayout.LabelField("왼쪽에서 항목을 고르면 자세한 내용과 고치는 방법이 나와요. 경고는 VRChat에서 보이는 문제이고, " +
                                           "참고는 상황에 따라 괜찮을 수 있는 것이에요.", EditorStyles.wordWrappedMiniLabel);
                EditorGUILayout.Space(8);
                EditorGUILayout.LabelField("점검하는 것", EditorStyles.boldLabel);
                foreach (var check in AssemblyChecks.Order)
                    EditorGUILayout.LabelField($"{check}: {AssemblyChecks.About[check]}", EditorStyles.wordWrappedMiniLabel);
                return;
            }
            var f = selectedFinding;
            using (new EditorGUILayout.HorizontalScope())
            {
                Badge(f.Severity == Severity.Warning ? "⚠ 경고" : "참고");
                Badge("· " + f.Check);
                GUILayout.FlexibleSpace();
            }
            EditorGUILayout.LabelField(f.Title, WrappedBold);
            EditorGUILayout.Space(4);
            EditorGUILayout.LabelField(f.Detail, EditorStyles.wordWrappedLabel);
            EditorGUILayout.Space(8);
            using (new EditorGUI.DisabledScope(!f.Target))
                if (GUILayout.Button(new GUIContent("씬에서 선택", f.Target ? "Hierarchy에서 이 오브젝트를 골라요." : "씬에서 이 오브젝트를 찾지 못했어요."), GUILayout.Width(110)))
                    Select(f.Target);
        }

        // ---- 텍스처 ---------------------------------------------------------------------------------------------------

        private IEnumerable<TextureRow> FilteredTextures()
        {
            switch (textureFilter)
            {
                case 1: return textures.Where(r => r.AnyOff);
                case 2: return textures.Where(r => r.OnlyAnimated);
                case 3: return textures.Where(r => r.AnyStale);
                default: return textures;
            }
        }

        private void DrawTextureList()
        {
            long all = textures.Sum(r => r.Bytes);
            long unseen = textures.Where(r => r.Unused).Sum(r => r.Bytes);
            EditorGUILayout.LabelField($"텍스처 {textures.Count}개 · 약 {TextureReport.Size(all)}", EditorStyles.boldLabel);
            EditorGUILayout.LabelField(unseen > 0
                    ? $"꺼진 칸이나 셰이더에 없는 칸에만 있는 텍스처가 {TextureReport.Size(unseen)}예요. 보이지 않는데 업로드될 수 있어요."
                    : "크기는 그래픽 메모리(VRAM) 추정치예요.", EditorStyles.wordWrappedMiniLabel);
            int filter = GUILayout.Toolbar(textureFilter, TextureFilters, EditorStyles.miniButton);
            if (filter != textureFilter)
            {
                textureFilter = filter;
                selectedTexture = null;
            }
            EditorGUILayout.Space(4);
            var rows = FilteredTextures().ToList();
            if (rows.Count == 0)
                EditorGUILayout.LabelField(textureFilter == 0 ? "이 아바타에는 텍스처가 없어요." : "이 조건에 맞는 텍스처가 없어요.", EditorStyles.wordWrappedMiniLabel);
            foreach (var row in rows)
                if (Row(row == selectedTexture, () =>
                    {
                        GUILayout.Label(new GUIContent(row.Name, row.AssetPath ?? row.Name), EditorStyles.label);
                        using (new EditorGUILayout.HorizontalScope())
                        {
                            GUILayout.Label($"{row.Width}×{row.Height} · {TextureReport.Size(row.Bytes)} · {row.Format}", EditorStyles.miniLabel);
                            GUILayout.FlexibleSpace();
                            if (row.Unused) Badge("안 보임");
                            else if (row.AnyOff) Badge("꺼진 칸");
                            if (row.AnyStale) Badge("셰이더에 없음");
                            if (row.OnlyAnimated) Badge("애니메이션");
                            if (!row.Asset) Badge("빌드 생성");
                        }
                    }))
                    selectedTexture = row;
        }

        private void DrawTextureDetails()
        {
            var row = selectedTexture;
            if (row == null)
            {
                EditorGUILayout.LabelField("왼쪽에서 텍스처를 고르면 어느 오브젝트의 어떤 머티리얼, 어떤 칸에 있는지 보여 줘요.", EditorStyles.wordWrappedMiniLabel);
                EditorGUILayout.Space(8);
                EditorGUILayout.LabelField("표시", EditorStyles.boldLabel);
                EditorGUILayout.LabelField("꺼진 칸: lilToon에서 그 기능을 껐는데 텍스처가 남은 칸이에요.", EditorStyles.wordWrappedMiniLabel);
                EditorGUILayout.LabelField("셰이더에 없는 칸: 예전 셰이더의 칸에 남은 텍스처예요. 머티리얼에 남아 함께 올라가요.", EditorStyles.wordWrappedMiniLabel);
                EditorGUILayout.LabelField("애니메이션: 애니메이션이 바꿔 넣는 머티리얼에만 있는 텍스처예요.", EditorStyles.wordWrappedMiniLabel);
                EditorGUILayout.LabelField("빌드 생성: TexTransTool 같은 도구가 빌드 중에 만든 텍스처예요.", EditorStyles.wordWrappedMiniLabel);
                return;
            }
            EditorGUILayout.LabelField(row.Name, WrappedBold);
            EditorGUILayout.LabelField($"{row.Width}×{row.Height} · {TextureReport.Size(row.Bytes)} · {row.Format}", EditorStyles.miniLabel);
            EditorGUILayout.LabelField(row.AssetPath ?? "빌드 중에 만든 텍스처라 에셋이 없어요.", EditorStyles.wordWrappedMiniLabel);
            using (new EditorGUILayout.HorizontalScope())
            {
                if (row.Asset is Texture2D preview)
                {
                    var rect = GUILayoutUtility.GetRect(96, 96, GUILayout.Width(96), GUILayout.Height(96));
                    EditorGUI.DrawPreviewTexture(rect, preview, null, ScaleMode.ScaleToFit);
                }
                using (new EditorGUI.DisabledScope(!row.Asset))
                    if (GUILayout.Button("에셋 선택", GUILayout.Width(80))) Select(row.Asset);
                GUILayout.FlexibleSpace();
            }
            EditorGUILayout.Space(8);
            EditorGUILayout.LabelField($"쓰는 곳 {row.Uses.Count}곳", EditorStyles.boldLabel);
            foreach (var use in row.Uses)
                using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
                {
                    EditorGUILayout.LabelField($"{use.Path} › {use.Material} › {use.Slot}", EditorStyles.wordWrappedLabel);
                    using (new EditorGUILayout.HorizontalScope())
                    {
                        if (use.Off) Badge("꺼진 칸");
                        if (use.Stale) Badge("셰이더에 없는 칸");
                        if (use.Animated) Badge("애니메이션 · " + use.Clip);
                        GUILayout.FlexibleSpace();
                        using (new EditorGUI.DisabledScope(!use.MaterialAsset))
                            if (GUILayout.Button(new GUIContent("머티리얼", use.MaterialAsset ? "머티리얼 에셋을 골라요." : "빌드 중에 만든 머티리얼이에요."),
                                    EditorStyles.miniButton, GUILayout.Width(60)))
                                Select(use.MaterialAsset);
                    }
                }
            if (row.AnyOff || row.AnyStale)
                EditorGUILayout.LabelField("쓰지 않는 칸이면 머티리얼에서 그 칸을 비우세요. 셰이더에 없는 칸은 lilToon의 ‘사용하지 않는 프로퍼티 삭제’ 같은 " +
                                           "기능으로 정리할 수 있어요.", EditorStyles.wordWrappedMiniLabel);
        }

        // ---- 파라미터 -------------------------------------------------------------------------------------------------

        private void DrawSources()
        {
            EditorGUILayout.LabelField("동기화 파라미터", EditorStyles.boldLabel);
            var bar = GUILayoutUtility.GetRect(18, 18, GUILayout.ExpandWidth(true));
            EditorGUI.ProgressBar(bar, Mathf.Clamp01(totalBits / (float)ParameterBits.Limit), $"{totalBits} / {ParameterBits.Limit} 비트");
            if (cleanup != null && cleanup.applied)
                EditorGUILayout.LabelField($"정리로 {cleanup.bitsBefore - cleanup.bitsAfter}비트를 줄인 뒤예요 (정리 전 {cleanup.bitsBefore}비트).", EditorStyles.wordWrappedMiniLabel);
            if (totalBits > ParameterBits.Limit)
                EditorGUILayout.HelpBox($"⚠ {ParameterBits.Limit}비트를 넘어서 업로드할 수 없어요.", MessageType.Warning);
            EditorGUILayout.Space(4);
            if (sources.Count == 0)
                EditorGUILayout.LabelField("동기화 파라미터가 없어요.", EditorStyles.wordWrappedMiniLabel);
            foreach (var source in sources)
                if (Row(source == selectedSource, () =>
                    {
                        using (new EditorGUILayout.HorizontalScope())
                        {
                            GUILayout.Label(new GUIContent(source.Name, source.Name), EditorStyles.label);
                            GUILayout.FlexibleSpace();
                            GUILayout.Label($"{source.Bits}비트 · {source.Parameters.Count}개", EditorStyles.miniLabel, GUILayout.ExpandWidth(false));
                        }
                    }))
                    selectedSource = source;
            EditorGUILayout.Space(4);
            EditorGUILayout.LabelField("프리팹은 Modular Avatar Parameters로 찾아요. 빌드 중에 이름이 바뀐 파라미터는 ‘빌드 중에 생긴 파라미터’에 모여요.",
                EditorStyles.wordWrappedMiniLabel);
        }

        private void DrawCleanup()
        {
            if (selectedSource != null)
            {
                EditorGUILayout.LabelField(selectedSource.Name, WrappedBold);
                EditorGUILayout.LabelField($"{selectedSource.Bits}비트 · {selectedSource.Parameters.Count}개", EditorStyles.miniLabel);
                foreach (var parameter in selectedSource.Parameters) EditorGUILayout.LabelField("· " + parameter, EditorStyles.wordWrappedMiniLabel);
                if (selectedSource.Target && GUILayout.Button("선택", GUILayout.Width(60))) Select(selectedSource.Target);
                EditorGUILayout.Space(12);
            }

            EditorGUILayout.LabelField("안 쓰는 파라미터 정리", EditorStyles.boldLabel);
            EditorGUILayout.LabelField("켜 두면 업로드(빌드)할 때마다 애니메이터, 메뉴, Contact·PhysBone 어디에도 없는 Expression Parameter를 지워요. " +
                                       "씬의 아바타와 에셋은 바뀌지 않아요. 아바타 루트의 Assembly Checker 컴포넌트가 켜져 있을 때만 돌아요.",
                EditorStyles.wordWrappedMiniLabel);
            var settings = avatar ? avatar.GetComponent<AssemblyCheckerSettings>() : null;
            bool enabled = settings && settings.CleansUp;
            using (new EditorGUI.DisabledScope(!avatar))
            {
                bool next = EditorGUILayout.ToggleLeft("이 아바타에서 정리하기", enabled);
                if (next != enabled)
                    EditSettings(next ? "Turn parameter cleanup on" : "Turn parameter cleanup off", s =>
                    {
                        s.enabled = next;
                        if (next) s.removeUnusedParameters = true;
                    });
            }
            EditorGUILayout.LabelField(
                !settings ? "꺼져 있어요. 켜면 아바타 루트에 Assembly Checker 컴포넌트를 붙여요."
                : enabled ? "켜져 있어요. 컴포넌트의 체크를 끄면 멈춰요."
                : "꺼져 있어요(컴포넌트의 체크가 꺼져 있어요). 예외 목록은 그대로 남아요.", EditorStyles.wordWrappedMiniLabel);
            EditorGUILayout.Space(4);
            EditorGUILayout.LabelField("예외 목록", EditorStyles.boldLabel);
            EditorGUILayout.LabelField($"여기 있는 이름은 지우지 않아요. 끝에 *를 붙이면 그 이름으로 시작하는 것 모두예요. " +
                                       $"기본으로 남기는 이름: {string.Join(", ", ParameterCleanup.OutsideNames)}", EditorStyles.wordWrappedMiniLabel);
            var keep = settings && settings.keepParameters != null ? settings.keepParameters : new List<string>();
            for (int i = 0; i < keep.Count; i++)
                using (new EditorGUILayout.HorizontalScope())
                {
                    EditorGUILayout.LabelField(keep[i]);
                    if (GUILayout.Button(new GUIContent("×", "예외 목록에서 빼기"), GUILayout.Width(22)))
                    {
                        int index = i;
                        EditSettings("Remove parameter exception", s => s.keepParameters.RemoveAt(index));
                        GUIUtility.ExitGUI();
                    }
                }
            using (new EditorGUILayout.HorizontalScope())
            using (new EditorGUI.DisabledScope(!avatar))
            {
                keepDraft = EditorGUILayout.TextField(keepDraft);
                using (new EditorGUI.DisabledScope(string.IsNullOrWhiteSpace(keepDraft)))
                    if (GUILayout.Button("추가", GUILayout.Width(50)))
                    {
                        AddException(keepDraft.Trim());
                        keepDraft = "";
                        GUI.FocusControl(null);
                        GUIUtility.ExitGUI();
                    }
            }

            EditorGUILayout.Space(12);
            EditorGUILayout.LabelField("점검 결과 (복제본 빌드)", EditorStyles.boldLabel);
            if (cleanup == null)
                EditorGUILayout.LabelField("이번 점검에서는 정리 단계가 돌지 않았어요. 빌드 오류가 있었는지 확인해 주세요.", EditorStyles.wordWrappedMiniLabel);
            else if (!string.IsNullOrEmpty(cleanup.skipped))
                EditorGUILayout.LabelField(cleanup.skipped, EditorStyles.wordWrappedMiniLabel);
            else
            {
                string head = cleanup.removed.Count == 0 ? "지울 파라미터가 없어요."
                    : cleanup.applied ? $"지울 파라미터 {cleanup.removed.Count}개 · 동기화 {cleanup.bitsBefore} → {cleanup.bitsAfter}비트"
                    : $"정리가 꺼져 있어요. 켜면 {cleanup.removed.Count}개를 지우고 동기화 {cleanup.bitsBefore} → {cleanup.bitsAfter}비트가 돼요.";
                EditorGUILayout.LabelField(head, EditorStyles.wordWrappedLabel);
                foreach (var entry in cleanup.removed)
                    using (new EditorGUILayout.HorizontalScope(EditorStyles.helpBox))
                    {
                        GUILayout.Label(new GUIContent(entry.name, entry.reason), EditorStyles.label);
                        GUILayout.FlexibleSpace();
                        GUILayout.Label(entry.bits > 0 ? $"{entry.type} · {entry.bits}비트" : $"{entry.type} · 동기화 안 함", EditorStyles.miniLabel, GUILayout.ExpandWidth(false));
                        bool kept = keep.Contains(entry.name);
                        using (new EditorGUI.DisabledScope(kept || !avatar))
                            if (GUILayout.Button(new GUIContent(kept ? "예외됨" : "남기기", "예외 목록에 넣어 지우지 않게 해요. 다시 점검하면 반영돼요."),
                                    EditorStyles.miniButton, GUILayout.Width(52)))
                            {
                                AddException(entry.name);
                                GUIUtility.ExitGUI();
                            }
                    }
                if (cleanup.kept.Count > 0)
                {
                    EditorGUILayout.Space(4);
                    EditorGUILayout.LabelField($"쓰이지 않는 것 같지만 남긴 파라미터 {cleanup.kept.Count}개", EditorStyles.boldLabel);
                    foreach (var entry in cleanup.kept)
                    {
                        bool warn = !entry.reason.StartsWith("예외", StringComparison.Ordinal);
                        EditorGUILayout.LabelField($"{(warn ? "⚠ " : "")}{entry.name}: {entry.reason}", EditorStyles.wordWrappedMiniLabel);
                    }
                }
                EditorGUILayout.LabelField("설정을 바꿨다면 다시 점검해야 결과에 반영돼요.", EditorStyles.wordWrappedMiniLabel);
            }

            EditorGUILayout.Space(12);
            EditorGUILayout.LabelField("마지막 빌드", EditorStyles.boldLabel);
            var builds = avatar
                ? ParameterCleanup.Platforms.Select(p => ParameterCleanup.LastBuild(avatar.gameObject.name, p)).Where(r => r != null).ToList()
                : new List<ParameterCleanup.Report>();
            if (builds.Count == 0)
                EditorGUILayout.LabelField(enabled ? "이번 에디터 세션에서 이 아바타를 업로드하거나 플레이한 기록이 없어요."
                    : "정리가 꺼져 있으면 빌드할 때 아무것도 하지 않아서 기록도 남지 않아요.", EditorStyles.wordWrappedMiniLabel);
            foreach (var last in builds)
            {
                string what = !string.IsNullOrEmpty(last.skipped) ? last.skipped
                    : last.applied ? $"{last.removed.Count}개를 지웠어요 · 동기화 {last.bitsBefore} → {last.bitsAfter}비트"
                    : !last.enabled && last.removed.Count > 0 ? $"정리가 꺼져 있었어요 (지울 수 있던 파라미터 {last.removed.Count}개)"
                    : "지울 파라미터가 없었어요.";
                EditorGUILayout.LabelField($"{last.platform} · {last.time}: {what}", EditorStyles.wordWrappedLabel);
                if (last.applied) EditorGUILayout.LabelField("지운 것: " + string.Join(", ", last.removed.Select(e => e.name)), EditorStyles.wordWrappedMiniLabel);
            }
            // PC and Quest must end with the same synced list in the same order.
            var lists = builds.Where(r => string.IsNullOrEmpty(r.skipped)).ToList();
            if (lists.Count > 1 && lists.Any(r => !r.synced.SequenceEqual(lists[0].synced)))
            {
                // Names the cleanup removed on one platform that another platform's final list still has.
                var restore = lists.SelectMany(r => r.applied ? r.removed.Where(e => e.bits > 0).Select(e => e.name) : Enumerable.Empty<string>())
                    .Where(name => lists.Any(other => other.synced.Contains(name))).Distinct().ToList();
                EditorGUILayout.HelpBox(restore.Count > 0
                    ? "⚠ 플랫폼마다 최종 동기화 파라미터가 달라 PC와 Quest의 동기화가 어긋날 수 있어요. 한쪽에서만 지워진 이름을 예외 목록에 넣고 " +
                      $"두 플랫폼 모두 다시 업로드해 주세요: {string.Join(", ", restore)}"
                    : "⚠ 플랫폼마다 최종 동기화 파라미터가 달라요. 정리 때문은 아니에요. 두 버전의 파라미터 구성을 확인해 주세요.", MessageType.Warning);
            }
            if (builds.Count > 0) EditorGUILayout.LabelField("NDMF 콘솔에도 같은 내용이 남아요.", EditorStyles.wordWrappedMiniLabel);
        }

        private void AddException(string name)
        {
            if (string.IsNullOrEmpty(name)) return;
            EditSettings("Add parameter exception", s =>
            {
                s.keepParameters ??= new List<string>();
                if (!s.keepParameters.Contains(name)) s.keepParameters.Add(name);
            });
        }

        // One Undo step on the avatar's settings component, added when it is not there yet.
        private void EditSettings(string action, Action<AssemblyCheckerSettings> change)
        {
            if (!IsSceneAvatar(avatar)) return;
            var settings = avatar.GetComponent<AssemblyCheckerSettings>();
            if (!settings)
            {
                // Added for an exception (or to turn it on): it starts off, so adding an exception never turns the cleanup on.
                settings = Undo.AddComponent<AssemblyCheckerSettings>(avatar.gameObject);
                settings.enabled = false;
            }
            Undo.RecordObject(settings, action);
            change(settings);
            PrefabUtility.RecordPrefabInstancePropertyModifications(settings);
            EditorUtility.SetDirty(settings);
            EditorSceneManager.MarkSceneDirty(settings.gameObject.scene);
            Repaint();
        }
    }
}
#endif
