#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;

namespace AssemblyChecker
{
    // The component's Inspector: says whether the cleanup runs at build time (the checkbox next to its name is the
    // switch), then the exceptions, and a way to the checker's 파라미터 tab.
    [CustomEditor(typeof(AssemblyCheckerSettings))]
    internal sealed class AssemblyCheckerSettingsEditor : Editor
    {
        public override void OnInspectorGUI()
        {
            var settings = (AssemblyCheckerSettings)target;
            if (!settings.removeUnusedParameters)
            {
                EditorGUILayout.HelpBox("예전 버전에서 정리를 끈 설정이 남아 있어서 꺼져 있어요.", MessageType.Info);
                if (GUILayout.Button("정리 켜기"))
                {
                    Undo.RecordObject(settings, "Turn parameter cleanup on");
                    settings.removeUnusedParameters = true;
                    settings.enabled = true;
                    EditorUtility.SetDirty(settings);
                }
            }
            else
                EditorGUILayout.HelpBox(settings.enabled
                    ? "켜져 있어요. 업로드(빌드)할 때마다 애니메이터, 메뉴, Contact·PhysBone 어디에도 없는 Expression Parameter를 지워요. " +
                      "이름 옆 체크를 끄면 멈춰요."
                    : "꺼져 있어요. 업로드할 때 파라미터를 지우지 않아요. 이름 옆 체크를 켜면 정리해요.", MessageType.Info);
            DrawDefaultInspector();
            if (GUILayout.Button(new GUIContent("지울 파라미터 미리 보기", "조립 점검기의 파라미터 탭을 열어요. ‘점검하기’를 누르면 지울 것과 남길 것을 보여 줘요.")))
                AssemblyCheckerWindow.ShowParameters();
        }
    }
}
#endif
