using System;
using System.Linq;
using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;

namespace NXYUI.AssetManager
{
    // Window shell, built with UI Toolkit: the header with the tabs, and the page of the chosen tab (에셋: Assets.cs,
    // 가져오기: Import.cs, 폴더 지정: Folders.cs). Only the assembly form in the detail pane is IMGUI (it is shared with the
    // Inspector panel). Look: Editor/AssetManager.uss, design-system/unityvpm/pages/asset-manager.md.
    internal sealed partial class AssetManagerWindow : EditorWindow
    {
        // Every NXYUI package puts its windows under the top-level "NXYUI" menu (checked by tools/test_build_repo.py).
        private const string MenuPath = "NXYUI/Asset Manager";
        private const string StylePath = "Packages/dev.nxyui.asset-manager/Editor/AssetManager.uss";

        [SerializeField] private int tab;

        private const float MinWidth = 320, MinHeight = 360;

        private VisualElement root, page;
        private ScrollView pageScroll;
        private Button[] tabs;
        // ‘사용 방법’: the quiet button in the header and the bar it opens above the page (AssetManagerUsage).
        private Button usageToggle;
        private VisualElement usageBar;
        private bool darkSkin;
        private IVisualElementScheduledItem refreshItem, queueItem;

        [MenuItem(MenuPath)]
        private static void OpenFromMenu() => Open();

        internal static AssetManagerWindow Open()
        {
            // Docked next to the Inspector when it is open, like the other panels the user works beside.
            var inspector = typeof(Editor).Assembly.GetType("UnityEditor.InspectorWindow");
            var window = inspector != null ? GetWindow<AssetManagerWindow>("Asset Manager", true, inspector) : GetWindow<AssetManagerWindow>("Asset Manager");
            // It often sits as a tab beside the Inspector: the pages fold to one column when narrow. At this height the
            // tabs, each page's bar and a few lines of its lists show; a page that needs more scrolls as a whole.
            window.minSize = new Vector2(MinWidth, MinHeight);
            window.Show();
            return window;
        }

        internal static void ShowAsset(AssetRecord asset)
        {
            var window = Open();
            window.selectedAsset = asset?.id;
            window.detailOpen = asset != null;
            if (asset != null && !window.PassesFilters(asset)) window.ClearFilters();
            window.SetTab(0);
            window.RevealSelected();
        }

        internal static void ShowFolders() => Open().SetTab(2);

        private void OnEnable()
        {
            AssetStore.Changed += Refresh;
            AssetStore.ThumbnailsChanged += RefreshImages;
            BoothLinker.Updated += OnBoothUpdated;
            ImportQueue.Changed += OnQueueChanged;
            EditorApplication.projectChanged += OnProjectChanged;
            EditorApplication.hierarchyChanged += Repaint;
            EditorApplication.update += TickImportTab;
            EditorApplication.update += WatchSkin;
            Selection.selectionChanged += OnSelectionChanged;
        }

        private void OnDisable()
        {
            AssetStore.Changed -= Refresh;
            AssetStore.ThumbnailsChanged -= RefreshImages;
            BoothLinker.Updated -= OnBoothUpdated;
            ImportQueue.Changed -= OnQueueChanged;
            EditorApplication.projectChanged -= OnProjectChanged;
            EditorApplication.hierarchyChanged -= Repaint;
            EditorApplication.update -= TickImportTab;
            EditorApplication.update -= WatchSkin;
            Selection.selectionChanged -= OnSelectionChanged;
        }

        private void OnProjectChanged()
        {
            AssetFolders.ForgetSizes();
            // The folder scan reads the disk. A burst of project changes (an import, a save, a move) costs one scan, a
            // moment after the last of them, and only while the folder tab is the one shown.
            scanStale = true;
            if (tab == 2 && root != null) ScheduleFoldersLater();
            else Refresh();
        }

        private void CreateGUI()
        {
            // A window restored with the editor's layout keeps the minimum it was saved with.
            minSize = new Vector2(MinWidth, MinHeight);
            root = rootVisualElement;
            root.Clear();
            root.AddToClassList("am-root");
            var style = AssetDatabase.LoadAssetAtPath<StyleSheet>(StylePath);
            if (style) root.styleSheets.Add(style);
            else Debug.LogWarning($"[Asset Manager] {StylePath}을(를) 찾지 못해 기본 모양으로 보여요. 패키지를 다시 설치해 주세요.");
            root.RegisterCallback<GeometryChangedEvent>(e => ApplyWidth(e.newRect.width));
            root.RegisterCallback<KeyDownEvent>(OnRootKey, TrickleDown.TrickleDown);
            darkSkin = EditorGUIUtility.isProSkin;
            ApplySkin();

            var header = new VisualElement();
            header.AddToClassList("am-header");
            var brand = new VisualElement();
            brand.AddToClassList("am-brand");
            var icon = new VisualElement();
            icon.AddToClassList("am-brand-icon");
            icon.style.backgroundImage = new StyleBackground(EditorGUIUtility.IconContent("d_Prefab Icon").image as Texture2D);
            brand.Add(icon);
            var title = new Label("Asset Manager");
            title.AddToClassList("am-brand-title");
            brand.Add(title);
            header.Add(brand);
            tabs = new Button[3];
            for (var i = 0; i < tabs.Length; i++)
            {
                var index = i;
                tabs[i] = new Button(() => SetTab(index));
                tabs[i].AddToClassList("am-tab");
                header.Add(tabs[i]);
            }
            // At the right end of the header's line. Narrow, the brand is left out and the tabs may wrap: the button then
            // goes on to the next line (at its right end too), it is never pushed out of the window. The slot around it
            // takes the rest of whichever line it is on.
            usageToggle = UiButton("사용 방법", "am-button--quiet", ToggleUsage, "이 창을 쓰는 순서를 펼치거나 접어요.");
            usageToggle.AddToClassList("am-usage-toggle");
            var usageSlot = new VisualElement();
            usageSlot.AddToClassList("am-usage-slot");
            usageSlot.Add(usageToggle);
            header.Add(usageSlot);
            root.Add(header);

            // The page under the tabs. Its lists scroll in their own areas and its bars keep their height; only a window
            // shorter than the page's own minimum (its bars and a few lines of each list) scrolls the page as a whole.
            pageScroll = new ScrollView(ScrollViewMode.Vertical);
            // The page is as wide as the window: a horizontal bar would only take height from it.
            pageScroll.horizontalScrollerVisibility = ScrollerVisibility.Hidden;
            pageScroll.AddToClassList("am-page-scroll");
            pageScroll.AddToClassList("am-scroll-area");
            pageScroll.contentViewport.RegisterCallback<GeometryChangedEvent>(_ => FitPage());
            page = new VisualElement();
            page.AddToClassList("am-page");
            // In a window short enough for the page to scroll as a whole, Tab reaches controls outside the view.
            page.RegisterCallback<FocusInEvent>(OnPageFocus);
            root.RegisterCallback<PointerDownEvent>(_ => focusByPointer = true, TrickleDown.TrickleDown);
            root.RegisterCallback<KeyDownEvent>(_ => focusByPointer = false, TrickleDown.TrickleDown);
            // The usage bar is a bar of the page: it scrolls with it and never shrinks, and the page gets the room the
            // bar leaves (FitPage). Outside the page scroll, a tall bar in a short window would push the page out of
            // the window instead.
            usageBar = BuildUsageBar();
            pageScroll.Add(usageBar);
            pageScroll.Add(page);
            root.Add(pageScroll);
            ApplyUsage();
            BuildPage();
        }

        // Closed until the user presses ‘사용 방법’ (no key stored: closed).
        private static bool UsageOpen => EditorPrefs.GetBool(AssetManagerUsage.WindowPref, false);

        // The same numbered list as the Inspector panels and README_KO.txt. It never changes with the tool's state.
        private VisualElement BuildUsageBar()
        {
            var bar = new VisualElement { name = "am-usage" };
            bar.AddToClassList("am-usage");
            var box = new VisualElement();
            box.AddToClassList("am-usage-box");
            for (var i = 0; i < AssetManagerUsage.Steps.Length; i++)
                box.Add(UiText($"{i + 1}. {AssetManagerUsage.Steps[i]}", "am-usage-step"));
            var foot = new VisualElement();
            foot.AddToClassList("am-usage-foot");
            foot.Add(UiButton(AssetManagerUsage.MoreButton, "", () => Application.OpenURL(AssetManagerUsage.Url), AssetManagerUsage.Url));
            foot.Add(UiText(AssetManagerUsage.ReadmeNote, "am-usage-note"));
            box.Add(foot);
            bar.Add(box);
            // Its height follows the width (the steps wrap): the page's height is worked out again.
            bar.RegisterCallback<GeometryChangedEvent>(OnPartResized);
            bar.RegisterCallback<FocusInEvent>(OnPageFocus);
            return bar;
        }

        // Opens or closes the bar; the choice is kept for this computer.
        private void ToggleUsage()
        {
            var open = !UsageOpen;
            EditorPrefs.SetBool(AssetManagerUsage.WindowPref, open);
            ApplyUsage();
            // Opened, it shows at the top of the page, where a page scrolled down would hide it.
            if (open && pageScroll != null) pageScroll.scrollOffset = Vector2.zero;
        }

        private void ApplyUsage()
        {
            var open = UsageOpen;
            usageBar?.EnableInClassList("am-hidden", !open);
            usageToggle?.EnableInClassList("am-usage-toggle--on", open);
            FitPage();
        }

        // Set by a press of the pointer, cleared by a key: a control focused by clicking it is where the pointer is, and
        // scrolling the page under the pointer between its press and its release would lose the click.
        private bool focusByPointer;

        private void OnPageFocus(FocusInEvent e)
        {
            if (focusByPointer || !(e.target is VisualElement focused)) return;
            // After this event: a list that holds the control scrolls to it first, and the layout follows.
            focused.schedule.Execute(() =>
            {
                // Only while it is still where the keyboard left the focus: a press since then has its own, and the page
                // stays put under the pointer.
                if (focusByPointer || focused.focusController?.focusedElement != focused) return;
                RevealInPage(focused);
            });
        }

        // Scrolls the page (not the lists inside it) so that a control the keyboard moved to is in view. Nothing moves
        // while the control is in view already, which is always so when the window is tall enough for the page.
        // The usage bar above the page scrolls with it, so its button counts too.
        private void RevealInPage(VisualElement focused)
        {
            if (pageScroll == null || page == null || focused?.panel == null || !pageScroll.contentContainer.Contains(focused)) return;
            var view = pageScroll.contentViewport.worldBound;
            var at = focused.worldBound;
            if (float.IsNaN(at.height) || at.yMin >= view.yMin - 1 && at.yMax <= view.yMax + 1) return;
            pageScroll.ScrollTo(focused);
        }

        // The classes of the parts that stretch with the page (the page's columns and the import panes); every other part
        // of a page is a bar or a text as tall as what it holds, or a scrolling area (am-scroll-area) with its least height.
        private static readonly string[] Stretching = { "am-page", "am-gallery", "am-detail", "am-import", "am-panes", "am-pane", "am-folders", "am-empty" };

        private static bool Stretches(VisualElement e) => Stretching.Any(e.ClassListContains);

        // The page is given an exact height: the room under the tabs, or what its parts need at least when that is more
        // (then the page scrolls as a whole). Inside a scroll view a page of no set height is measured with no limit, and
        // a part that may grow then claims all of it (the found packages came out 4000 px high), so the height is worked
        // out here instead: the bars as they are, each scrolling area at its least height. The stacked import panes get
        // their least height too, so neither takes the other's share.
        // The width is set too (the viewport's, less the scroll bar when it shows), so the page is never measured against
        // an open width either (a wrapping bar then squeezed its folder field to 2 px).
        // The usage bar, while open, sits above the page in the same scroll: it gets the same width, and the room under
        // the tabs less its height is what the page has. A tall bar in a short window then scrolls with the page.
        private void FitPage()
        {
            if (pageScroll == null || page == null) return;
            var room = pageScroll.contentViewport.layout;
            if (float.IsNaN(room.height) || room.height <= 0 || float.IsNaN(room.width) || room.width <= 0) return;
            var width = Mathf.Floor(room.width);
            Set(page, width, e => e.style.width, (e, v) => e.style.width = v);
            float above = 0;
            if (usageBar != null)
            {
                Set(usageBar, width, e => e.style.width, (e, v) => e.style.width = v);
                above = Least(usageBar);
            }
            foreach (var pane in page.Query(className: "am-pane").ToList())
                Set(pane, Mathf.Ceil(Least(pane)), e => e.style.minHeight, (e, v) => e.style.minHeight = v);
            var least = Least(page);
            var left = Mathf.Max(0, Mathf.Floor(room.height - above));
            var height = float.IsNaN(least) ? left : Mathf.Max(left, Mathf.Ceil(least));
            Set(page, height, e => e.style.height, (e, v) => e.style.height = v);
        }

        // Only a change is written: each write lays the page out again.
        private static void Set(VisualElement e, float value, Func<VisualElement, StyleLength> get, Action<VisualElement, float> set)
        {
            var now = get(e);
            if (now.keyword == StyleKeyword.Undefined && Mathf.Approximately(now.value.value, value)) return;
            set(e, value);
        }

        // The least height a part of the page can take without squeezing anything.
        private static float Least(VisualElement e)
        {
            var style = e.resolvedStyle;
            if (style.display == DisplayStyle.None) return 0;
            if (e.ClassListContains("am-scroll-area")) return style.minHeight.value;
            // A part not laid out yet has no height.
            if (!Stretches(e)) return float.IsNaN(e.layout.height) ? 0 : e.layout.height;
            var column = style.flexDirection == FlexDirection.Column || style.flexDirection == FlexDirection.ColumnReverse;
            float inner = 0;
            foreach (var child in e.Children())
            {
                var part = child.resolvedStyle;
                if (part.display == DisplayStyle.None || part.position == Position.Absolute) continue;
                var height = Least(child) + part.marginTop + part.marginBottom;
                inner = column ? inner + height : Mathf.Max(inner, height);
            }
            return inner + style.paddingTop + style.paddingBottom + style.borderTopWidth + style.borderBottomWidth;
        }

        // A bar that appears, wraps or grows changes what the page needs: each part tells FitPage when its size changes
        // (the lists inside their scrolling areas do not count).
        private void WatchPage(VisualElement e)
        {
            e.RegisterCallback<GeometryChangedEvent>(OnPartResized);
            if (!Stretches(e)) return;
            foreach (var child in e.Children()) WatchPage(child);
        }

        private void OnPartResized(GeometryChangedEvent e) => FitPage();

        // Under 720 px the asset page shows the gallery or the detail, not both; the gallery keeps two columns.
        private const float NarrowWidth = 720;

        // Wide shows both; narrowing again starts on the gallery, so a click made while wide never opens the detail later.
        private void ApplyWidth(float width)
        {
            if (root == null) return;
            var narrow = width < NarrowWidth;
            if (!narrow) detailOpen = false;
            root.EnableInClassList("am-narrow", narrow);
            ApplyDetailOpen();
        }

        // The editor skin can change while the window is open: the tokens follow it.
        private void WatchSkin()
        {
            if (root == null || darkSkin == EditorGUIUtility.isProSkin) return;
            darkSkin = EditorGUIUtility.isProSkin;
            ApplySkin();
        }

        private void ApplySkin()
        {
            root.EnableInClassList("am-dark", darkSkin);
            root.EnableInClassList("am-light", !darkSkin);
        }

        private void SetTab(int index)
        {
            tab = Mathf.Clamp(index, 0, 2);
            if (page == null) return;
            // Another page starts at its top (a short window scrolls the page as a whole).
            pageScroll.scrollOffset = Vector2.zero;
            BuildPage();
            // With the usage bar open above the page in a window too short for both, the top is the page's own: left at
            // the bar's first line, nothing on screen would show that the tab changed. Set once the new page is laid out
            // (only then is the scroll's range known; with room for both there is no range and nothing moves).
            if (UsageOpen && usageBar != null)
                pageScroll.schedule.Execute(() =>
                {
                    if (UsageOpen && usageBar != null && !float.IsNaN(usageBar.layout.height))
                        pageScroll.scrollOffset = new Vector2(0f, usageBar.layout.height);
                });
        }

        private void BuildPage()
        {
            RememberAssetsScrolls();
            RememberImportScrolls();
            RememberFoldersScroll();
            page.Clear();
            // Only the shown page has elements; the others' refreshes see null and wait for their page to be built.
            gallery = null;
            detail = null;
            filterBar = null;
            detailPosition = null;
            detailBack = null;
            scanList = null;
            readButton = null;
            foldersBody = null;
            joinBar = null;
            UpdateTabs();
            switch (tab)
            {
                case 0:
                    BuildAssetsPage(page);
                    break;
                case 1:
                    BuildImportPage(page);
                    break;
                default:
                    BuildFoldersPage(page);
                    break;
            }
            // The new parts have no size yet: the page starts at the room it has and grows once they are laid out.
            WatchPage(page);
            FitPage();
        }

        private void UpdateTabs()
        {
            if (tabs == null) return;
            var proposals = AssetStore.State.proposals.Count;
            tabs[0].text = $"에셋 {AssetStore.Project.assets.Count}";
            tabs[1].text = ImportQueue.Running ? "가져오기 · 진행 중" : "가져오기";
            tabs[2].text = proposals > 0 ? $"폴더 지정 · 제안 {proposals}" : "폴더 지정";
            for (var i = 0; i < tabs.Length; i++) tabs[i].EnableInClassList("am-tab--on", i == tab);
        }

        // Asset data changed (a link, a rename, a new asset): the page is drawn again once, after the notices settle.
        private void Refresh()
        {
            if (root == null) return;
            refreshItem?.Pause();
            refreshItem = root.schedule.Execute(() =>
            {
                UpdateTabs();
                if (tab == 0) RefreshAssetsPage();
                else if (tab == 1) RefreshImportPage();
                else ScheduleFolders();
            });
        }

        // The queue reports each step of an import: the tab label follows, and the import page when it is shown.
        private void OnQueueChanged()
        {
            if (root == null) return;
            queueItem?.Pause();
            queueItem = root.schedule.Execute(() =>
            {
                UpdateTabs();
                if (tab == 1) RefreshImportPage();
            });
        }

        // A rebuilt part keeps the keyboard focus at the same place (the n-th control that takes focus), so a background
        // update does not throw a keyboard user out of the list.
        // A control with a name of ours ("am-…") is found again by that name, whatever was added or removed around it (a
        // ‘다시 찾기’ button that appears above the search field must not take the field's focus); others by their place.
        private (string Name, int Slot) FocusSlot(VisualElement area)
        {
            if (area == null || !(root?.panel?.focusController?.focusedElement is VisualElement focused) || !area.Contains(focused)) return (null, -1);
            string name = null;
            for (var e = focused; e != null && e != area; e = e.parent)
                if (!string.IsNullOrEmpty(e.name) && e.name.StartsWith("am-", System.StringComparison.Ordinal))
                {
                    name = e.name;
                    break;
                }
            return (name, Focusables(area).IndexOf(focused));
        }

        private static void RestoreFocus(VisualElement area, (string Name, int Slot) at)
        {
            if (at.Name != null)
            {
                // Gone with the rebuild (its section is no longer shown): the focus is not handed to whatever sits there now.
                area.Q(at.Name)?.Focus();
                return;
            }
            if (at.Slot < 0) return;
            var list = Focusables(area);
            if (list.Count > 0) list[Mathf.Min(at.Slot, list.Count - 1)].Focus();
        }

        private static System.Collections.Generic.List<VisualElement> Focusables(VisualElement area) =>
            area.Query<VisualElement>().Where(v => v.focusable && v.enabledInHierarchy && v.resolvedStyle.display != DisplayStyle.None).ToList();

        // A page built again shows its list where the user left it, once the list knows its size.
        private static void KeepScroll(ScrollView scroll, Vector2 offset)
        {
            if (scroll == null || offset == Vector2.zero) return;
            void Apply(GeometryChangedEvent e)
            {
                scroll.contentContainer.UnregisterCallback<GeometryChangedEvent>(Apply);
                scroll.scrollOffset = offset;
            }
            scroll.contentContainer.RegisterCallback<GeometryChangedEvent>(Apply);
        }

        // Booth results: the detail of the chosen asset, or the proposals' "Booth 후보" line.
        private void OnBoothUpdated()
        {
            if (tab == 0) ScheduleDetail();
            else if (tab == 2) ScheduleFolders();
        }
    }
}
