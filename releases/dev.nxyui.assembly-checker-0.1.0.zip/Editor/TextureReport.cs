#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;
using UnityEngine.Experimental.Rendering;
using UnityEngine.Rendering;

namespace AssemblyChecker
{
    // One place a texture is used: object › material › slot.
    internal sealed class TextureUse
    {
        internal string Path, Material, Slot, Property;
        internal Material MaterialAsset;
        // Off: the slot's feature is turned off. Stale: the shader has no such slot (left from another shader).
        internal bool Off, Stale;
        // The clip that swaps the material in, for a material only animations use.
        internal string Clip;
        internal bool Animated => Clip != null;
    }

    internal sealed class TextureRow
    {
        internal string Name, Format, AssetPath;
        // The asset, or null for a texture the build made.
        internal Texture Asset;
        internal int Width, Height;
        internal long Bytes;
        internal readonly List<TextureUse> Uses = new List<TextureUse>();

        // Everything that uses it is a turned-off or missing slot: it uploads without being seen.
        internal bool Unused => Uses.All(u => u.Off || u.Stale);
        internal bool OnlyAnimated => Uses.All(u => u.Animated);
        internal bool AnyStale => Uses.Any(u => u.Stale);
        internal bool AnyOff => Uses.Any(u => u.Off);
    }

    // Every texture the built avatar uploads, with where it sits: the object (by its scene path), the material and the
    // slot, named in Korean for lilToon. Materials only animations swap in, slots whose feature is off and slots the
    // shader no longer has are marked.
    internal static class TextureReport
    {
        internal static List<TextureRow> Collect(BuiltAvatar b)
        {
            var rows = new Dictionary<Texture, TextureRow>();
            var placed = new HashSet<Material>();
            foreach (var renderer in b.Clone.GetComponentsInChildren<Renderer>(true))
            {
                string path = b.Label(renderer.transform);
                foreach (var material in renderer.sharedMaterials)
                {
                    if (!material) continue;
                    placed.Add(material);
                    Slots(rows, material, path, null);
                }
            }
            foreach (var (clip, start) in b.Clips())
                foreach (var binding in AnimationUtility.GetObjectReferenceCurveBindings(clip))
                {
                    if (!binding.propertyName.StartsWith("m_Materials.Array.data[", StringComparison.Ordinal)) continue;
                    var target = BuiltAvatar.Find(start, binding.path);
                    string path = target ? b.Label(target) : binding.path;
                    foreach (var key in AnimationUtility.GetObjectReferenceCurve(clip, binding))
                        if (key.value is Material material && !placed.Contains(material)) Slots(rows, material, path, clip.name);
                }
            return rows.Values.OrderByDescending(r => r.Bytes).ThenBy(r => r.Name).ToList();
        }

        private static void Slots(Dictionary<Texture, TextureRow> rows, Material material, string path, string clip)
        {
            var shader = material.shader;
            if (!shader) return;
            bool lil = LilToon.Is(shader);
            var known = new HashSet<string>();
            void Use(Texture texture, string property, string slot, bool off, bool stale)
            {
                if (!rows.TryGetValue(texture, out var row)) rows[texture] = row = RowOf(texture);
                row.Uses.Add(new TextureUse
                {
                    Path = path, Material = material.name, MaterialAsset = EditorUtility.IsPersistent(material) ? material : null,
                    Property = property, Slot = slot, Off = off, Stale = stale, Clip = clip,
                });
            }
            for (int i = 0; i < shader.GetPropertyCount(); i++)
            {
                if (shader.GetPropertyType(i) != ShaderPropertyType.Texture) continue;
                string property = shader.GetPropertyName(i);
                known.Add(property);
                var texture = material.GetTexture(property);
                if (!texture) continue;
                string description = shader.GetPropertyDescription(i);
                string slot = (lil ? LilToon.Label(property) : null) ?? (string.IsNullOrEmpty(description) ? property : description);
                Use(texture, property, slot, lil && LilToon.Off(material, property), false);
            }
            // A material keeps the textures of slots its earlier shader had; they upload with it.
            using (var serialized = new SerializedObject(material))
            {
                var saved = serialized.FindProperty("m_SavedProperties.m_TexEnvs");
                for (int i = 0; saved != null && i < saved.arraySize; i++)
                {
                    var entry = saved.GetArrayElementAtIndex(i);
                    string property = entry.FindPropertyRelative("first")?.stringValue;
                    var texture = entry.FindPropertyRelative("second.m_Texture")?.objectReferenceValue as Texture;
                    if (texture && !string.IsNullOrEmpty(property) && !known.Contains(property))
                        Use(texture, property, $"셰이더에 없는 칸 ({property})", false, true);
                }
            }
        }

        private static TextureRow RowOf(Texture texture)
        {
            bool asset = EditorUtility.IsPersistent(texture);
            return new TextureRow
            {
                Name = texture.name, Asset = asset ? texture : null, AssetPath = asset ? AssetDatabase.GetAssetPath(texture) : null,
                Width = texture.width, Height = texture.height, Bytes = Bytes(texture), Format = FormatOf(texture),
            };
        }

        private static string FormatOf(Texture texture) =>
            texture is Texture2D || texture is Cubemap || texture is Texture2DArray || texture is Texture3D
                ? texture.graphicsFormat.ToString() : texture.GetType().Name;

        // What the texture takes in video memory: every mip level in its GPU format.
        internal static long Bytes(Texture texture)
        {
            try
            {
                switch (texture)
                {
                    case Texture2D t: return Levels(t.width, t.height, t.mipmapCount, t.graphicsFormat);
                    case Cubemap t: return 6 * Levels(t.width, t.height, t.mipmapCount, t.graphicsFormat);
                    case Texture2DArray t: return t.depth * Levels(t.width, t.height, t.mipmapCount, t.graphicsFormat);
                    case Texture3D t: return t.depth * Levels(t.width, t.height, t.mipmapCount, t.graphicsFormat);
                }
            }
            catch (ArgumentException) { }
            return UnityEngine.Profiling.Profiler.GetRuntimeMemorySizeLong(texture);
        }

        private static long Levels(int width, int height, int mips, GraphicsFormat format)
        {
            long block = GraphicsFormatUtility.GetBlockSize(format);
            long blockWidth = Math.Max(1, GraphicsFormatUtility.GetBlockWidth(format));
            long blockHeight = Math.Max(1, GraphicsFormatUtility.GetBlockHeight(format));
            long total = 0;
            for (int level = 0; level < Math.Max(1, mips); level++)
            {
                total += (width + blockWidth - 1) / blockWidth * ((height + blockHeight - 1) / blockHeight) * block;
                width = Math.Max(1, width / 2);
                height = Math.Max(1, height / 2);
            }
            return total;
        }

        internal static string Size(long bytes) =>
            bytes >= 1024 * 1024 ? $"{bytes / (1024f * 1024f):0.0} MB" : $"{Math.Max(1, bytes / 1024)} KB";
    }

    // lilToon's texture slots in Korean, and whether the feature a slot belongs to is turned off.
    internal static class LilToon
    {
        internal static bool Is(Shader shader) =>
            shader.name.IndexOf("lilToon", StringComparison.OrdinalIgnoreCase) >= 0 || shader.name.StartsWith("_lil/", StringComparison.Ordinal);

        private static readonly Dictionary<string, string> Labels = new Dictionary<string, string>
        {
            ["_MainTex"] = "메인 컬러",
            ["_MainColorAdjustMask"] = "메인 색 보정 마스크",
            ["_MainGradationTex"] = "메인 그라데이션 맵",
            ["_Main2ndTex"] = "메인 컬러 2nd",
            ["_Main2ndBlendMask"] = "메인 컬러 2nd 마스크",
            ["_Main2ndDissolveMask"] = "메인 컬러 2nd 디졸브 마스크",
            ["_Main2ndDissolveNoiseMask"] = "메인 컬러 2nd 디졸브 노이즈",
            ["_Main3rdTex"] = "메인 컬러 3rd",
            ["_Main3rdBlendMask"] = "메인 컬러 3rd 마스크",
            ["_Main3rdDissolveMask"] = "메인 컬러 3rd 디졸브 마스크",
            ["_Main3rdDissolveNoiseMask"] = "메인 컬러 3rd 디졸브 노이즈",
            ["_AlphaMask"] = "알파 마스크",
            ["_BumpMap"] = "노멀 맵",
            ["_Bump2ndMap"] = "노멀 맵 2nd",
            ["_Bump2ndScaleMask"] = "노멀 맵 2nd 마스크",
            ["_AnisotropyTangentMap"] = "비등방성 반사 탄젠트 맵",
            ["_AnisotropyScaleMask"] = "비등방성 반사 마스크",
            ["_AnisotropyShiftNoiseMask"] = "비등방성 반사 노이즈",
            ["_ShadowStrengthMask"] = "그림자 마스크",
            ["_ShadowBorderMask"] = "그림자 경계 마스크",
            ["_ShadowBlurMask"] = "그림자 흐림 마스크",
            ["_ShadowColorTex"] = "그림자 색 1",
            ["_Shadow2ndColorTex"] = "그림자 색 2",
            ["_Shadow3rdColorTex"] = "그림자 색 3",
            ["_RimShadeMask"] = "림 셰이드 마스크",
            ["_BacklightColorTex"] = "역광",
            ["_SmoothnessTex"] = "반사 · 매끄러움",
            ["_MetallicGlossMap"] = "반사 · 메탈릭",
            ["_ReflectionColorTex"] = "반사 · 색",
            ["_ReflectionCubeTex"] = "반사 · 큐브맵",
            ["_MatCapTex"] = "매트캡",
            ["_MatCapBlendMask"] = "매트캡 마스크",
            ["_MatCapBumpMap"] = "매트캡 노멀 맵",
            ["_MatCap2ndTex"] = "매트캡 2nd",
            ["_MatCap2ndBlendMask"] = "매트캡 2nd 마스크",
            ["_MatCap2ndBumpMap"] = "매트캡 2nd 노멀 맵",
            ["_RimColorTex"] = "림 라이트",
            ["_GlitterColorTex"] = "글리터 색",
            ["_GlitterShapeTex"] = "글리터 모양",
            ["_EmissionMap"] = "발광",
            ["_EmissionBlendMask"] = "발광 마스크",
            ["_EmissionGradTex"] = "발광 그라데이션",
            ["_Emission2ndMap"] = "발광 2nd",
            ["_Emission2ndBlendMask"] = "발광 2nd 마스크",
            ["_Emission2ndGradTex"] = "발광 2nd 그라데이션",
            ["_ParallaxMap"] = "시차 맵",
            ["_AudioLinkMask"] = "AudioLink 마스크",
            ["_AudioLinkLocalMap"] = "AudioLink 로컬 맵",
            ["_DissolveMask"] = "디졸브 마스크",
            ["_DissolveNoiseMask"] = "디졸브 노이즈",
            ["_OutlineTex"] = "윤곽선 색",
            ["_OutlineWidthMask"] = "윤곽선 굵기 마스크",
            ["_OutlineVectorTex"] = "윤곽선 방향 맵",
            ["_FurNoiseMask"] = "퍼 노이즈",
            ["_FurMask"] = "퍼 마스크",
            ["_FurLengthMask"] = "퍼 길이 마스크",
            ["_FurVectorTex"] = "퍼 방향 맵",
        };

        // A slot and the float that turns its feature on.
        private static readonly Dictionary<string, string> Switches = new Dictionary<string, string>
        {
            ["_Main2ndTex"] = "_UseMain2ndTex", ["_Main2ndBlendMask"] = "_UseMain2ndTex",
            ["_Main2ndDissolveMask"] = "_UseMain2ndTex", ["_Main2ndDissolveNoiseMask"] = "_UseMain2ndTex",
            ["_Main3rdTex"] = "_UseMain3rdTex", ["_Main3rdBlendMask"] = "_UseMain3rdTex",
            ["_Main3rdDissolveMask"] = "_UseMain3rdTex", ["_Main3rdDissolveNoiseMask"] = "_UseMain3rdTex",
            ["_AlphaMask"] = "_AlphaMaskMode",
            ["_BumpMap"] = "_UseBumpMap",
            ["_Bump2ndMap"] = "_UseBump2ndMap", ["_Bump2ndScaleMask"] = "_UseBump2ndMap",
            ["_AnisotropyTangentMap"] = "_UseAnisotropy", ["_AnisotropyScaleMask"] = "_UseAnisotropy",
            ["_AnisotropyShiftNoiseMask"] = "_UseAnisotropy",
            ["_ShadowStrengthMask"] = "_UseShadow", ["_ShadowBorderMask"] = "_UseShadow", ["_ShadowBlurMask"] = "_UseShadow",
            ["_ShadowColorTex"] = "_UseShadow", ["_Shadow2ndColorTex"] = "_UseShadow", ["_Shadow3rdColorTex"] = "_UseShadow",
            ["_RimShadeMask"] = "_UseRimShade",
            ["_BacklightColorTex"] = "_UseBacklight",
            ["_SmoothnessTex"] = "_UseReflection", ["_MetallicGlossMap"] = "_UseReflection",
            ["_ReflectionColorTex"] = "_UseReflection", ["_ReflectionCubeTex"] = "_UseReflection",
            ["_MatCapTex"] = "_UseMatCap", ["_MatCapBlendMask"] = "_UseMatCap", ["_MatCapBumpMap"] = "_UseMatCap",
            ["_MatCap2ndTex"] = "_UseMatCap2nd", ["_MatCap2ndBlendMask"] = "_UseMatCap2nd", ["_MatCap2ndBumpMap"] = "_UseMatCap2nd",
            ["_RimColorTex"] = "_UseRim",
            ["_GlitterColorTex"] = "_UseGlitter", ["_GlitterShapeTex"] = "_UseGlitter",
            ["_EmissionMap"] = "_UseEmission", ["_EmissionBlendMask"] = "_UseEmission", ["_EmissionGradTex"] = "_UseEmission",
            ["_Emission2ndMap"] = "_UseEmission2nd", ["_Emission2ndBlendMask"] = "_UseEmission2nd",
            ["_Emission2ndGradTex"] = "_UseEmission2nd",
            ["_ParallaxMap"] = "_UseParallax",
            ["_AudioLinkMask"] = "_UseAudioLink", ["_AudioLinkLocalMap"] = "_UseAudioLink",
        };

        internal static string Label(string property) => Labels.TryGetValue(property, out var label) ? label : null;

        // Whether the slot's feature is off in this material. Unknown slots count as on.
        internal static bool Off(Material material, string property)
        {
            if (Switches.TryGetValue(property, out var toggle))
                return material.HasProperty(toggle) && material.GetFloat(toggle) == 0f;
            string shader = material.shader.name;
            switch (property)
            {
                case "_OutlineTex":
                case "_OutlineWidthMask":
                case "_OutlineVectorTex":
                    // The outline is a shader variant ("...Outline"); lilToonMulti decides it with a keyword.
                    if (shader.IndexOf("Multi", StringComparison.OrdinalIgnoreCase) >= 0) return false;
                    return shader.IndexOf("Outline", StringComparison.OrdinalIgnoreCase) < 0;
                case "_FurNoiseMask":
                case "_FurMask":
                case "_FurLengthMask":
                case "_FurVectorTex":
                    return shader.IndexOf("Fur", StringComparison.OrdinalIgnoreCase) < 0;
                case "_DissolveMask":
                case "_DissolveNoiseMask":
                    return material.HasProperty("_DissolveParams") && material.GetVector("_DissolveParams").x == 0f;
                case "_MainGradationTex":
                    return material.HasProperty("_MainGradationStrength") && material.GetFloat("_MainGradationStrength") == 0f;
                default:
                    return false;
            }
        }
    }
}
#endif
