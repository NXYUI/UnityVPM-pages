#if UNITY_EDITOR
using System.Collections.Generic;
using System.Linq;
using nadena.dev.modular_avatar.core;
using UnityEditor;
using UnityEngine;
using VRC.SDK3.Avatars.Components;
using Object = UnityEngine.Object;

namespace AssemblyChecker
{
    // The synced parameters of one source: a prefab (by its Modular Avatar Parameters), the avatar's own list, or what
    // the build made without saying where.
    internal sealed class BitSource
    {
        internal string Name;
        internal Object Target;
        internal int Bits;
        internal readonly List<string> Parameters = new List<string>();
    }

    internal static class ParameterBits
    {
        internal const int Limit = 256;
        private const string Own = "아바타 기본 파라미터", Unknown = "빌드 중에 생긴 파라미터", VRCFury = "VRCFury";

        // The built avatar's synced parameters, grouped by where they come from, most bits first.
        internal static List<BitSource> Attribute(BuiltAvatar b, out int total)
        {
            total = 0;
            var built = b.Clone.GetComponent<VRCAvatarDescriptor>();
            var parameters = built && built.customExpressions && built.expressionParameters ? built.expressionParameters.parameters : null;
            var sources = new Dictionary<string, BitSource>();
            if (parameters == null) return new List<BitSource>();

            // Outer components first, so a name a parent remaps belongs to the parent's prefab.
            var fromPrefab = new Dictionary<string, GameObject>();
            foreach (var component in b.Source.GetComponentsInChildren<ModularAvatarParameters>(true))
            {
                if (component.parameters == null) continue;
                var group = Group(b.Source.transform, component.transform);
                foreach (var p in component.parameters)
                {
                    if (p.isPrefix || p.internalParameter) continue;
                    string name = string.IsNullOrEmpty(p.remapTo) ? p.nameOrPrefix : p.remapTo;
                    if (!string.IsNullOrEmpty(name) && !fromPrefab.ContainsKey(name)) fromPrefab[name] = group;
                }
            }
            var descriptor = b.Source.GetComponent<VRCAvatarDescriptor>();
            var ownList = descriptor && descriptor.expressionParameters ? descriptor.expressionParameters : null;
            var own = new HashSet<string>(ownList && ownList.parameters != null ? ownList.parameters.Where(p => p != null).Select(p => p.name) : Enumerable.Empty<string>());
            bool vrcfury = AssemblyChecks.HasVRCFury(b.Source);

            foreach (var p in parameters.Where(p => p != null && p.networkSynced && !string.IsNullOrEmpty(p.name)))
            {
                string key;
                Object target = null;
                if (fromPrefab.TryGetValue(p.name, out var group)) { key = group.name; target = group; }
                else if (own.Contains(p.name)) { key = Own; target = ownList; }
                else if (vrcfury && p.name.StartsWith("VF")) key = VRCFury;
                else key = Unknown;
                if (!sources.TryGetValue(key, out var source)) sources[key] = source = new BitSource { Name = key, Target = target };
                int bits = ParameterCleanup.Cost(p.valueType);
                source.Bits += bits;
                source.Parameters.Add($"{p.name} ({p.valueType}, {bits}비트)");
                total += bits;
            }
            return sources.Values.OrderByDescending(s => s.Bits).ThenBy(s => s.Name).ToList();
        }

        // The prefab a component belongs to: the outermost prefab placed in the avatar that holds it, else the object
        // right below the avatar root.
        private static GameObject Group(Transform root, Transform t)
        {
            Transform top = null, prefab = null;
            for (var at = t; at && at != root; at = at.parent)
            {
                top = at;
                if (PrefabUtility.IsAnyPrefabInstanceRoot(at.gameObject)) prefab = at;
            }
            return (prefab ? prefab : top ? top : root).gameObject;
        }
    }
}
#endif
