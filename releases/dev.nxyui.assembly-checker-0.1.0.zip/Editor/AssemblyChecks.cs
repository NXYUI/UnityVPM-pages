#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;
using VRC.SDK3.Dynamics.PhysBone.Components;

namespace AssemblyChecker
{
    internal enum Severity { Note, Warning }

    internal sealed class Finding
    {
        internal string Check;
        internal Severity Severity;
        internal string Title, Detail;
        // The scene object to select, or null.
        internal GameObject Target;
    }

    // The checks for problems that usually show up only in VRChat, run on the built copy so that Modular Avatar's
    // merges and settings are already applied. Objects are named by their path in the scene avatar.
    internal static class AssemblyChecks
    {
        internal const string Armature = "의상 아마추어", PhysBones = "PhysBone 중복", Anchors = "Anchor Override", Bounds = "Bounds",
            Shrink = "바디 줄이기", Hidden = "꺼진 오브젝트";

        internal static readonly string[] Order = { Armature, PhysBones, Anchors, Bounds, Shrink, Hidden };

        internal static readonly Dictionary<string, string> About = new Dictionary<string, string>
        {
            [Armature] = "의상 본이 아바타 아마추어에 합쳐졌는지 봐요.",
            [PhysBones] = "PhysBone 두 개가 같은 본을 움직이는지 봐요.",
            [Anchors] = "렌더러의 Anchor Override가 바디와 같은지 봐요.",
            [Bounds] = "Bounds가 메시를 다 덮는지, Root Bone이 있는지 봐요.",
            [Shrink] = "의상을 입었는데 바디 줄이기 쉐이프키가 모두 0인지 봐요.",
            [Hidden] = "꺼진 채로 어디서도 켜지지 않는데 업로드되는 오브젝트를 찾아요.",
        };

        internal static List<Finding> Run(BuiltAvatar built)
        {
            var findings = new List<Finding>();
            void Guard(string check, Action<BuiltAvatar, List<Finding>> run)
            {
                try { run(built, findings); }
                catch (Exception e)
                {
                    Debug.LogException(e);
                    findings.Add(new Finding { Check = check, Severity = Severity.Warning, Title = "이 점검을 마치지 못했어요", Detail = e.Message });
                }
            }
            Guard(Armature, Armatures);
            Guard(PhysBones, DuplicatePhysBones);
            Guard(Anchors, AnchorOverrides);
            Guard(Bounds, MeshBounds);
            Guard(Shrink, ShrinkKeys);
            Guard(Hidden, HiddenObjects);
            return findings;
        }

        // ---- 의상 아마추어 -------------------------------------------------------------------------------------------

        // A skinned mesh that still uses its own hips, spine or chest outside the avatar's armature was not merged.
        private static void Armatures(BuiltAvatar b, List<Finding> list)
        {
            var root = b.Clone.transform;
            var hips = HumanBone(b, HumanBodyBones.Hips);
            if (!hips)
            {
                list.Add(new Finding
                {
                    Check = Armature, Severity = Severity.Note, Title = "휴머노이드 본을 찾지 못해 건너뛰었어요",
                    Detail = "아바타의 Animator에 Humanoid Avatar가 있어야 해요.", Target = b.Source,
                });
                return;
            }
            // Merged bones end up below the avatar's own hips; an outfit's hips beside them (even in the same Armature)
            // were not merged.
            var reported = new HashSet<Transform>();
            foreach (var skinned in root.GetComponentsInChildren<SkinnedMeshRenderer>(true))
            {
                var bone = skinned.bones.FirstOrDefault(t => t && !t.IsChildOf(hips) && Core(t.name));
                var top = bone ? TopBelow(root, bone) : null;
                if (!top || !reported.Add(top)) continue;
                var scene = b.InScene(top);
                bool vrcfury = scene && HasVRCFury(scene.gameObject);
                list.Add(new Finding
                {
                    Check = Armature, Severity = vrcfury ? Severity.Note : Severity.Warning,
                    Title = $"‘{top.name}’의 아마추어가 아바타 본에 합쳐지지 않았어요",
                    Detail = $"{b.Label(skinned.transform)}이(가) 아바타 아마추어 밖의 본 ‘{bone.name}’을 써요. 그대로 올리면 의상이 몸을 따라 " +
                             "움직이지 않아요. 의상을 우클릭해 Modular Avatar › Setup Outfit을 해 주세요." +
                             (vrcfury ? "\nVRCFury가 있어요. Armature Link로 연결했다면 업로드 때 합쳐지니 무시해도 돼요." : ""),
                    Target = scene ? scene.gameObject : null,
                });
            }
        }

        private static string Normalize(string name) => new string(name.Where(char.IsLetter).ToArray()).ToLowerInvariant();

        // Hips, spine and chest under any naming: "Hips", "J_Bip_C_Spine", "Chest.001".
        private static bool Core(string name)
        {
            string n = Normalize(name);
            return n.Contains("hips") || n.Contains("spine") || n.Contains("chest");
        }

        // The object right below the avatar root that holds t, or null when t is not inside the avatar.
        private static Transform TopBelow(Transform root, Transform t)
        {
            if (!t || t == root || !t.IsChildOf(root)) return null;
            while (t.parent != root) t = t.parent;
            return t;
        }

        private static Transform HumanBone(BuiltAvatar b, HumanBodyBones bone)
        {
            var animator = b.Clone.GetComponent<Animator>();
            return animator && animator.isHuman ? animator.GetBoneTransform(bone) : null;
        }

        internal static bool HasVRCFury(GameObject go) =>
            go.GetComponentsInChildren<Component>(true).Any(c => c && (c.GetType().Namespace ?? "").StartsWith("VF", StringComparison.Ordinal));

        // ---- PhysBone 중복 -------------------------------------------------------------------------------------------

        // The bones a PhysBone moves are its root's descendants, less the ignored ones and theirs, and with "Ignore Other
        // PhysBones" less the chains other PhysBones start. Two PhysBones that move the same bones fight over them.
        private static void DuplicatePhysBones(BuiltAvatar b, List<Finding> list)
        {
            var movers = new Dictionary<Transform, List<VRCPhysBone>>();
            var every = b.Clone.GetComponentsInChildren<VRCPhysBone>(true);
            var all = every.Where(pb => pb.enabled).ToList();
            Transform Start(VRCPhysBone pb) => pb.rootTransform ? pb.rootTransform : pb.transform;
            // "Ignore Other PhysBones" leaves out the chain of any other PhysBone, a disabled one too.
            var starts = every.GroupBy(Start).ToDictionary(g => g.Key, g => g.ToList());
            foreach (var pb in all)
            {
                var start = Start(pb);
                var ignored = new HashSet<Transform>((pb.ignoreTransforms ?? new List<Transform>()).Where(t => t));
                void Walk(Transform t)
                {
                    foreach (Transform child in t)
                    {
                        if (ignored.Contains(child)) continue;
                        if (pb.ignoreOtherPhysBones && starts.TryGetValue(child, out var others) && others.Any(o => o != pb)) continue;
                        if (!movers.TryGetValue(child, out var by)) movers[child] = by = new List<VRCPhysBone>();
                        if (!by.Contains(pb)) by.Add(pb);
                        Walk(child);
                    }
                }
                Walk(start);
            }
            var pairs = new Dictionary<(VRCPhysBone, VRCPhysBone), List<Transform>>();
            foreach (var pair in movers.Where(p => p.Value.Count > 1))
            {
                var by = pair.Value.OrderBy(pb => pb.GetInstanceID()).ToList();
                for (int i = 0; i < by.Count; i++)
                    for (int j = i + 1; j < by.Count; j++)
                    {
                        if (!pairs.TryGetValue((by[i], by[j]), out var bones)) pairs[(by[i], by[j])] = bones = new List<Transform>();
                        bones.Add(pair.Key);
                    }
            }
            string Name(VRCPhysBone pb) =>
                b.Label(pb.transform) + (pb.rootTransform && pb.rootTransform != pb.transform ? $" (Root: {pb.rootTransform.name})" : "");
            foreach (var pair in pairs)
            {
                var (first, second) = pair.Key;
                var bones = pair.Value;
                list.Add(new Finding
                {
                    Check = PhysBones, Severity = Severity.Warning,
                    Title = $"PhysBone 두 개가 같은 본 {bones.Count}개를 움직여요",
                    Detail = $"· {Name(first)}\n· {Name(second)}\n겹치는 본: {string.Join(", ", bones.Take(6).Select(t => t.name))}" +
                             (bones.Count > 6 ? " …" : "") +
                             "\n의상과 아바타에 같은 머리카락·꼬리 PhysBone이 있으면 하나를 지우거나, 한쪽의 Ignore Transforms에 넣어 주세요.",
                    Target = b.SceneObject(first),
                });
            }
        }

        // ---- Anchor Override / Bounds --------------------------------------------------------------------------------

        // The avatar's body: the skinned mesh named "Body", else the one with the most blendshapes.
        internal static SkinnedMeshRenderer Body(BuiltAvatar b)
        {
            var skinned = b.Clone.GetComponentsInChildren<SkinnedMeshRenderer>(true).Where(s => s.sharedMesh).ToList();
            return skinned.FirstOrDefault(s => s.name.Equals("Body", StringComparison.OrdinalIgnoreCase)) ??
                   skinned.OrderByDescending(s => s.sharedMesh.blendShapeCount).FirstOrDefault();
        }

        private static List<Renderer> MeshRenderers(BuiltAvatar b) =>
            b.Clone.GetComponentsInChildren<Renderer>(true).Where(r => r is SkinnedMeshRenderer || r is MeshRenderer).ToList();

        private static string NameOf(Transform t) => t ? t.name : "없음";

        // Renderers lit from a different place than the body look brighter or darker beside it.
        private static void AnchorOverrides(BuiltAvatar b, List<Finding> list)
        {
            var renderers = MeshRenderers(b);
            var body = Body(b);
            var expected = body ? body.probeAnchor :
                renderers.GroupBy(r => r.probeAnchor).OrderByDescending(g => g.Count()).Select(g => g.Key).FirstOrDefault();
            string against = body ? $"바디(‘{body.name}’)" : "대부분의 렌더러";
            foreach (var group in renderers.Where(r => r != body && r.probeAnchor != expected).GroupBy(r => r.probeAnchor))
            {
                var odd = group.ToList();
                list.Add(new Finding
                {
                    Check = Anchors, Severity = Severity.Warning,
                    Title = $"Anchor Override가 {against}와 다른 렌더러 {odd.Count}개",
                    Detail = $"이 렌더러들: {NameOf(group.Key)} · {against}: {NameOf(expected)}\n" +
                             string.Join("\n", odd.Take(10).Select(r => "· " + b.Label(r.transform))) + (odd.Count > 10 ? "\n· …" : "") +
                             "\n다르면 같은 자리에서도 밝기가 달라 보여요. 아바타 루트에 MA Mesh Settings를 두면 한 번에 맞출 수 있어요.",
                    Target = b.SceneObject(odd[0]),
                });
            }
        }

        // A skinned mesh draws only while its Bounds is on screen: Bounds smaller than the mesh make parts vanish at the
        // screen's edge. The mesh is measured in its pose in the scene.
        private static void MeshBounds(BuiltAvatar b, List<Finding> list)
        {
            var body = Body(b);
            var measure = new Mesh();
            try
            {
                foreach (var skinned in MeshRenderers(b).OfType<SkinnedMeshRenderer>())
                {
                    if (!skinned.sharedMesh) continue;
                    if (!skinned.rootBone)
                        list.Add(new Finding
                        {
                            Check = Bounds, Severity = Severity.Note, Title = $"‘{skinned.name}’의 Root Bone이 비어 있어요",
                            Detail = b.Label(skinned.transform) + "\nRoot Bone이 없으면 Bounds가 렌더러 위치를 따라가요. 바디와 같은 본(보통 Hips)을 넣어 주세요.",
                            Target = b.SceneObject(skinned),
                        });
                    skinned.BakeMesh(measure, true);
                    if (measure.vertexCount == 0) continue;
                    var place = Matrix4x4.TRS(skinned.transform.position, skinned.transform.rotation, Vector3.one);
                    var mesh = WorldBox(measure.bounds, place);
                    var anchor = skinned.rootBone ? skinned.rootBone : skinned.transform;
                    var box = WorldBox(skinned.localBounds, anchor.localToWorldMatrix);
                    float outside = Mathf.Max(0f, Max(box.min - mesh.min), Max(mesh.max - box.max));
                    if (outside < 0.02f) continue;
                    list.Add(new Finding
                    {
                        Check = Bounds, Severity = Severity.Warning,
                        Title = $"‘{skinned.name}’의 Bounds가 메시보다 작아요",
                        Detail = $"{b.Label(skinned.transform)}\n메시가 Bounds 밖으로 최대 {outside * 100f:0}cm 나가요. 화면 가장자리에서 일부가 사라질 수 있어요." +
                                 (body && skinned != body ? " 바디의 Bounds에 맞추거나 MA Mesh Settings로 한 번에 정해 주세요." : " Bounds를 넉넉하게 늘려 주세요."),
                        Target = b.SceneObject(skinned),
                    });
                }
            }
            finally { UnityEngine.Object.DestroyImmediate(measure); }
        }

        private static float Max(Vector3 v) => Mathf.Max(v.x, Mathf.Max(v.y, v.z));

        // The world box around a local box.
        private static UnityEngine.Bounds WorldBox(UnityEngine.Bounds local, Matrix4x4 matrix)
        {
            var box = new UnityEngine.Bounds(matrix.MultiplyPoint3x4(local.center), Vector3.zero);
            for (int corner = 0; corner < 8; corner++)
                box.Encapsulate(matrix.MultiplyPoint3x4(local.center + Vector3.Scale(local.extents,
                    new Vector3((corner & 1) == 0 ? -1 : 1, (corner & 2) == 0 ? -1 : 1, (corner & 4) == 0 ? -1 : 1))));
            return box;
        }

        // ---- 바디 줄이기 ---------------------------------------------------------------------------------------------

        private static readonly string[] ShrinkWords = { "shrink", "縮", "hide", "隠", "消" };

        // An outfit is on (another mesh moves with the hips, spine, chest or legs), the body has shrink shapekeys, and none
        // is set, animated, or applied by deleting the body's vertices.
        private static void ShrinkKeys(BuiltAvatar b, List<Finding> list)
        {
            var body = Body(b);
            if (!body) return;
            var mesh = body.sharedMesh;
            var keys = Enumerable.Range(0, mesh.blendShapeCount)
                .Where(i => ShrinkWords.Any(w => mesh.GetBlendShapeName(i).IndexOf(w, StringComparison.OrdinalIgnoreCase) >= 0)).ToList();
            if (keys.Count == 0 || keys.Any(i => body.GetBlendShapeWeight(i) > 0f)) return;
            // Only the body's own curves count: an outfit's "hide" key is another mesh's.
            var animated = new HashSet<string>(b.Clips().SelectMany(c => AnimationUtility.GetCurveBindings(c.Clip)
                    .Where(x => x.type == typeof(SkinnedMeshRenderer) && x.propertyName.StartsWith("blendShape.", StringComparison.Ordinal) &&
                                BuiltAvatar.Find(c.Root, x.path) == body.transform))
                .Select(x => x.propertyName.Substring(11)));
            if (keys.Any(i => animated.Contains(mesh.GetBlendShapeName(i)))) return;
            var sceneBody = b.InScene(body.transform) is Transform at ? at.GetComponent<SkinnedMeshRenderer>() : null;
            if (sceneBody && sceneBody.sharedMesh && sceneBody.sharedMesh.vertexCount > mesh.vertexCount) return;
            var torso = new HashSet<Transform>(new[] { HumanBodyBones.Hips, HumanBodyBones.Spine, HumanBodyBones.Chest, HumanBodyBones.UpperChest,
                HumanBodyBones.LeftUpperLeg, HumanBodyBones.RightUpperLeg }.Select(x => HumanBone(b, x)).Where(t => t));
            bool dressed = b.Clone.GetComponentsInChildren<SkinnedMeshRenderer>(false)
                .Any(s => s != body && s.bones.Any(x => x && torso.Contains(x)));
            if (!dressed) return;
            var names = keys.Select(i => mesh.GetBlendShapeName(i)).ToList();
            list.Add(new Finding
            {
                Check = Shrink, Severity = Severity.Note,
                Title = $"바디 줄이기 쉐이프키 {names.Count}개가 모두 0이에요",
                Detail = $"‘{body.name}’: {string.Join(", ", names.Take(8))}{(names.Count > 8 ? " …" : "")}\n" +
                         "의상 밖으로 바디가 비치면 맞는 키를 올려 주세요. MA Shape Changer를 쓰면 의상을 끌 때 같이 돌아가요.",
                Target = sceneBody ? sceneBody.gameObject : null,
            });
        }

        // ---- 꺼진 오브젝트 -------------------------------------------------------------------------------------------

        // An object that is off in the scene and in the build, not EditorOnly, and turned on by no animation uploads for
        // nothing: usually the original of an outfit that was converted or duplicated.
        private static void HiddenObjects(BuiltAvatar b, List<Finding> list)
        {
            // The scene objects some clip turns on (a path names the first object of that name, as the Animator finds it).
            var turnedOn = new HashSet<Transform>();
            foreach (var (clip, start) in b.Clips())
                foreach (var binding in AnimationUtility.GetCurveBindings(clip))
                {
                    if (binding.type != typeof(GameObject) || binding.propertyName != "m_IsActive") continue;
                    var curve = AnimationUtility.GetEditorCurve(clip, binding);
                    if (curve == null || !curve.keys.Any(k => k.value > 0.5f)) continue;
                    var scene = b.InScene(BuiltAvatar.Find(start, binding.path));
                    if (scene) turnedOn.Add(scene);
                }
            var root = b.Source.transform;
            bool vrcfury = HasVRCFury(b.Source);
            void Visit(Transform t)
            {
                foreach (Transform child in t)
                {
                    if (child.CompareTag("EditorOnly")) continue;
                    string path = BuiltAvatar.PathOf(root, child);
                    if (child.gameObject.activeSelf || turnedOn.Contains(child))
                    {
                        Visit(child);
                        continue;
                    }
                    int renderers = child.GetComponentsInChildren<Renderer>(true).Length;
                    // Gone from the build (an optimizer removed it), turned on by the build (Modular Avatar sets a
                    // toggle's starting state), or nothing to draw.
                    var built = b.Built(child);
                    if (renderers == 0 || !built) continue;
                    if (built.gameObject.activeSelf)
                    {
                        Visit(child);
                        continue;
                    }
                    list.Add(new Finding
                    {
                        Check = Hidden, Severity = Severity.Warning,
                        Title = $"‘{child.name}’이(가) 꺼진 채로 함께 올라가요",
                        Detail = $"{path} · 렌더러 {renderers}개\n꺼져 있고, 어떤 애니메이션도 켜지 않아요. 쓰지 않는 원본 의상이면 EditorOnly 태그를 " +
                                 "붙이거나 지워 주세요." + (vrcfury ? "\nVRCFury 토글로 켜는 오브젝트라면 무시해도 돼요(이 점검은 NDMF 빌드만 봐요)." : ""),
                        Target = child.gameObject,
                    });
                }
            }
            Visit(root);
        }
    }
}
#endif
