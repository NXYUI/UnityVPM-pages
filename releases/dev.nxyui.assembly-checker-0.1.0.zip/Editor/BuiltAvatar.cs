#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using nadena.dev.ndmf;
using nadena.dev.ndmf.platform;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using VRC.SDK3.Avatars.Components;
using Object = UnityEngine.Object;

namespace AssemblyChecker
{
    // A copy of a scene avatar built by NDMF in a preview scene, with the path each of its objects had before the build.
    // The scene avatar is not changed; the copy, its scene and the build's temporary assets go away on Dispose.
    internal sealed class BuiltAvatar : IDisposable
    {
        private const string FolderPrefix = "__AssemblyCheckerBuild_";
        private static readonly Regex FolderName = new Regex("^" + FolderPrefix + "[0-9a-f]{32}$");
        // Folders of builds that have not been disposed yet.
        private static readonly HashSet<string> Open = new HashSet<string>();

        internal GameObject Source { get; private set; }
        internal GameObject Clone { get; private set; }
        internal bool Successful { get; private set; }
        // The parameter cleanup's report from this build (null when the pass did not run).
        internal ParameterCleanup.Report Cleanup { get; private set; }
        // Each object of the copy and its path below the avatar before the build ("" for the root).
        internal readonly Dictionary<Transform, string> Before = new Dictionary<Transform, string>();
        // Each object of the copy and the scene object it was copied from, and the other way round: paths can repeat
        // (two siblings with one name).
        private readonly Dictionary<Transform, Transform> toScene = new Dictionary<Transform, Transform>();
        private readonly Dictionary<Transform, Transform> toCopy = new Dictionary<Transform, Transform>();

        private Scene scene;
        private string folder;

        internal static BuiltAvatar Build(VRCAvatarDescriptor avatar)
        {
            DeleteStaleFolders();
            var built = new BuiltAvatar { Source = avatar.gameObject };
            try
            {
                built.scene = EditorSceneManager.NewPreviewScene();
                var clone = Object.Instantiate(avatar.gameObject);
                clone.name = avatar.gameObject.name;
                SceneManager.MoveGameObjectToScene(clone, built.scene);
                clone.SetActive(true);
                built.Clone = clone;
                foreach (var t in clone.GetComponentsInChildren<Transform>(true)) built.Before[t] = PathOf(clone.transform, t);
                built.Pair(avatar.transform, clone.transform);
                built.folder = AssetDatabase.GUIDToAssetPath(AssetDatabase.CreateFolder("Assets", FolderPrefix + Guid.NewGuid().ToString("N")));
                if (string.IsNullOrEmpty(built.folder)) throw new InvalidOperationException("임시 빌드 폴더를 만들 수 없어요.");
                Open.Add(built.folder);
                ParameterCleanup.Previewing = true;
                ParameterCleanup.Preview = null;
                try
                {
                    using (new OverrideTemporaryDirectoryScope(built.folder))
                        built.Successful = AvatarProcessor.ProcessAvatar(clone, AmbientPlatform.DefaultPlatform).Successful;
                }
                finally
                {
                    ParameterCleanup.Previewing = false;
                    built.Cleanup = ParameterCleanup.Preview;
                    ParameterCleanup.Preview = null;
                }
                return built;
            }
            catch
            {
                built.Dispose();
                throw;
            }
        }

        // A copy keeps the order of children, so the two hierarchies pair up child by child.
        private void Pair(Transform scene, Transform copy)
        {
            toScene[copy] = scene;
            toCopy[scene] = copy;
            for (int i = 0; i < Math.Min(scene.childCount, copy.childCount); i++) Pair(scene.GetChild(i), copy.GetChild(i));
        }

        public void Dispose()
        {
            if (Clone) Object.DestroyImmediate(Clone);
            Clone = null;
            if (scene.IsValid()) EditorSceneManager.ClosePreviewScene(scene);
            if (!string.IsNullOrEmpty(folder))
            {
                Open.Remove(folder);
                if (FolderName.IsMatch(Path.GetFileName(folder))) AssetDatabase.DeleteAsset(folder);
            }
            folder = null;
        }

        // Folders left by a check that did not finish (an editor crash): only this tool's names, none still in use.
        private static void DeleteStaleFolders()
        {
            foreach (var stale in AssetDatabase.GetSubFolders("Assets").Where(f => FolderName.IsMatch(Path.GetFileName(f)) && !Open.Contains(f)))
                AssetDatabase.DeleteAsset(stale);
        }

        internal static string PathOf(Transform root, Transform t)
        {
            var names = new List<string>();
            for (var at = t; at && at != root; at = at.parent) names.Add(at.name);
            names.Reverse();
            return string.Join("/", names);
        }

        // The path an object of the copy had before the build, or null for one the build made.
        internal string PathBefore(Transform built) => built && Before.TryGetValue(built, out var path) ? path : null;

        // What became of a scene object in the built copy, or null when the build removed it.
        internal Transform Built(Transform scene) => scene && toCopy.TryGetValue(scene, out var t) && t ? t : null;

        // The scene object an object of the copy came from, or null for one the build made.
        internal Transform InScene(Transform built) => built && toScene.TryGetValue(built, out var t) && t ? t : null;

        internal GameObject SceneObject(Component built)
        {
            var t = built ? InScene(built.transform) : null;
            return t ? t.gameObject : null;
        }

        // How to name an object of the copy for the user: its path before the build when it had one.
        internal string Label(Transform built)
        {
            if (!built) return "(없음)";
            string path = PathBefore(built);
            if (path != null) return path.Length == 0 ? Source.name : path;
            return PathOf(Clone.transform, built) + " (빌드에서 생김)";
        }

        internal IEnumerable<RuntimeAnimatorController> Controllers()
        {
            var descriptor = Clone.GetComponent<VRCAvatarDescriptor>();
            return descriptor ? ParameterUses.Controllers(descriptor) : Enumerable.Empty<RuntimeAnimatorController>();
        }

        private List<(AnimationClip Clip, Transform Root)> clips;

        // Every clip that can play on the built avatar, with the object its paths start from: the playable layers' clips
        // from the root, and the clips of any other Animator in the avatar from that Animator's object.
        internal IReadOnlyList<(AnimationClip Clip, Transform Root)> Clips()
        {
            if (clips != null) return clips;
            clips = Controllers().SelectMany(c => c.animationClips).Where(c => c).Distinct().Select(c => (c, Clone.transform)).ToList();
            foreach (var animator in Clone.GetComponentsInChildren<Animator>(true))
                if (animator.transform != Clone.transform && animator.runtimeAnimatorController)
                    clips.AddRange(animator.runtimeAnimatorController.animationClips.Where(c => c).Distinct().Select(c => (c, animator.transform)));
            return clips;
        }

        // The object a clip's binding path names, from the clip's root.
        internal static Transform Find(Transform root, string path) => path.Length == 0 ? root : root.Find(path);

    }
}
#endif
