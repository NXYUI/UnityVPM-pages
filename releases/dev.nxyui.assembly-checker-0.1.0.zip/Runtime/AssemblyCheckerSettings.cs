using System.Collections.Generic;
using nadena.dev.ndmf;
using UnityEngine;

namespace AssemblyChecker
{
    // The Assembly Checker's settings for one avatar, on its root. Without this component the build uses the defaults:
    // unused parameters are removed, and only the built-in exceptions are kept.
    [DisallowMultipleComponent]
    [AddComponentMenu("NXYUI/Assembly Checker Settings")]
    public sealed class AssemblyCheckerSettings : MonoBehaviour, INDMFEditorOnly
    {
        [Tooltip("빌드할 때 애니메이터, 메뉴, Contact·PhysBone 어디에도 없는 Expression Parameter를 지워요.")]
        public bool removeUnusedParameters = true;

        [Tooltip("지우지 않을 파라미터 이름이에요. 끝에 *를 붙이면 그 이름으로 시작하는 파라미터를 모두 남겨요.")]
        public List<string> keepParameters = new List<string>();
    }
}
