#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using net.rs64.TexTransTool;
using net.rs64.TexTransTool.Decal;
using net.rs64.TexTransTool.IslandSelector;
using net.rs64.TexTransTool.MultiLayerImage;
using UnityEditor;
using UnityEngine;
using VRC.SDK3.Avatars.Components;
using Object = UnityEngine.Object;
using TTTPropertyName = net.rs64.TexTransTool.PropertyName;
using MaterialProperty = net.rs64.TexTransTool.MaterialProperty;

namespace NXYUI.HairGradation
{
    // Turns HairGradationSettings into TexTransTool components below the settings object. Without a pattern and into the
    // main texture, one SingleGradationDecal paints every part. Otherwise each hair texture gets a canvas: the original
    // (main texture only), the gradient above it, and the pattern clipped to the gradient on top. Into lilToon's 2nd or
    // 3rd color, a MaterialModifier gives each material a blank texture of its own there, which the canvas paints.
    // The gradient runs along the avatar's down axis by 3D height, so it continues across parts.
    internal static class HairGradationBuilder
    {
        internal const string ContainerName = "[TTT] Hair Gradation";
        internal const string AssetRoot = "Assets/NXYUI/Hair Gradation";
        private const string MainTex = "_MainTex";

        // Blend modes offered, by TexTransTool key, with Korean labels. lilToon's 2nd/3rd colors have only the first four.
        internal static readonly (string Key, string Label)[] Blends =
        {
            ("Normal", "보통"), ("Addition", "더하기"), ("Screen", "스크린"), ("Mul", "곱하기"), ("Overlay", "오버레이"),
            ("SoftLight", "소프트 라이트"), ("HardLight", "하드 라이트"), ("Color", "색상"), ("Luminosity", "밝기"),
        };
        internal const int LilToonBlends = 4;

        // ---- what takes part ---------------------------------------------------------------------------------------

        internal sealed class Part
        {
            internal Renderer Renderer;
            internal bool Included;
            // Why a renderer cannot take part (off, no mesh), or null.
            internal string Blocked;
        }

        // Every mesh renderer below the hair root, and whether it takes part.
        internal static List<Part> Parts(HairGradationSettings s)
        {
            var parts = new List<Part>();
            foreach (var renderer in s.GetComponentsInChildren<Renderer>(true))
            {
                if (!(renderer is SkinnedMeshRenderer) && !(renderer is MeshRenderer)) continue;
                string blocked = null;
                if (!MeshOf(renderer)) blocked = "메시 없음";
                else if (!renderer.gameObject.activeInHierarchy || !renderer.enabled) blocked = "꺼져 있음";
                parts.Add(new Part { Renderer = renderer, Blocked = blocked, Included = blocked == null && !s.excluded.Contains(renderer) });
            }
            return parts;
        }

        internal static List<Renderer> Included(HairGradationSettings s) => Parts(s).Where(p => p.Included).Select(p => p.Renderer).ToList();

        internal static Mesh MeshOf(Renderer renderer) =>
            renderer is SkinnedMeshRenderer skinned ? skinned.sharedMesh :
            renderer.TryGetComponent<MeshFilter>(out var filter) ? filter.sharedMesh : null;

        // A hair texture and the materials (of the parts) that show it.
        internal sealed class Group
        {
            internal Texture2D Texture;
            internal readonly List<Material> Materials = new List<Material>();
            internal readonly List<Renderer> Renderers = new List<Renderer>();
        }

        internal static List<Group> Groups(IEnumerable<Renderer> renderers, List<string> problems)
        {
            var groups = new Dictionary<Texture2D, Group>();
            foreach (var renderer in renderers)
            {
                var mesh = MeshOf(renderer);
                var materials = renderer.sharedMaterials;
                for (int i = 0; i < Math.Min(materials.Length, mesh ? mesh.subMeshCount : 0); i++)
                {
                    var material = materials[i];
                    if (!material) continue;
                    var texture = material.HasProperty(MainTex) ? material.GetTexture(MainTex) as Texture2D : null;
                    if (!texture)
                    {
                        string note = $"‘{material.name}’에 메인 텍스처가 없어 건너뛰어요.";
                        if (!problems.Contains(note)) problems.Add(note);
                        continue;
                    }
                    if (!groups.TryGetValue(texture, out var group)) groups[texture] = group = new Group { Texture = texture };
                    if (!group.Materials.Contains(material)) group.Materials.Add(material);
                    if (!group.Renderers.Contains(renderer)) group.Renderers.Add(renderer);
                }
            }
            return groups.Values.OrderBy(g => g.Texture.name).ToList();
        }

        internal static bool IsLilToon(Material material) =>
            material.shader && material.shader.name.IndexOf("lilToon", StringComparison.OrdinalIgnoreCase) >= 0;

        // ---- where the hair is -------------------------------------------------------------------------------------

        // The hair measured along the avatar's own axes (right, up, forward), from the meshes as they are posed.
        internal struct Measure
        {
            internal Vector3 Right, Up, Forward;
            internal Vector2 R, U, F; // (min, max) along each axis
            internal bool Valid;
            internal float Height => U.y - U.x;
        }

        internal static Transform AvatarRoot(Component c)
        {
            var descriptor = c.GetComponentInParent<VRCAvatarDescriptor>(true);
            return descriptor ? descriptor.transform : c.transform.root;
        }

        internal static Measure Measured(HairGradationSettings s, IEnumerable<Renderer> renderers)
        {
            var root = AvatarRoot(s);
            var m = new Measure
            {
                Up = root.up, Forward = root.forward, Right = root.right,
                R = new Vector2(float.MaxValue, float.MinValue), U = new Vector2(float.MaxValue, float.MinValue), F = new Vector2(float.MaxValue, float.MinValue),
            };
            void Add(Vector3 p)
            {
                float r = Vector3.Dot(p, m.Right), u = Vector3.Dot(p, m.Up), f = Vector3.Dot(p, m.Forward);
                m.R = new Vector2(Mathf.Min(m.R.x, r), Mathf.Max(m.R.y, r));
                m.U = new Vector2(Mathf.Min(m.U.x, u), Mathf.Max(m.U.y, u));
                m.F = new Vector2(Mathf.Min(m.F.x, f), Mathf.Max(m.F.y, f));
                m.Valid = true;
            }
            foreach (var p in renderers.SelectMany(WorldVertices)) Add(p);
            return m;
        }

        // The vertices of a renderer in the world, as posed now.
        internal static IEnumerable<Vector3> WorldVertices(Renderer renderer)
        {
            var (vertices, toWorld) = Posed(renderer);
            foreach (var v in vertices) yield return toWorld.MultiplyPoint3x4(v);
        }

        internal static (Vector3[] Vertices, Matrix4x4 ToWorld) Posed(Renderer renderer)
        {
            if (renderer is SkinnedMeshRenderer skinned)
            {
                var baked = new Mesh();
                try
                {
                    // The renderer's scale baked in, so only its place and turn are left.
                    skinned.BakeMesh(baked, true);
                    return (baked.vertices, Matrix4x4.TRS(skinned.transform.position, skinned.transform.rotation, Vector3.one));
                }
                finally { Object.DestroyImmediate(baked); }
            }
            var mesh = MeshOf(renderer);
            return (mesh ? mesh.vertices : Array.Empty<Vector3>(), renderer.transform.localToWorldMatrix);
        }

        // Where on the gradient a point is: 0 at the start, 1 at the end (clamped).
        internal static float GradientAt(HairGradationSettings s, Measure m, Vector3 p)
        {
            float from = m.U.y - Mathf.Clamp01(s.start) * m.Height;
            float length = Mathf.Max(0.001f, (Mathf.Clamp01(s.end) - Mathf.Clamp01(s.start)) * m.Height);
            return Mathf.Clamp01((from - Vector3.Dot(p, m.Up)) / length);
        }

        // ---- the components ----------------------------------------------------------------------------------------

        // What the generated objects depend on that a live update cannot change: then they are made again.
        internal static string Structure(HairGradationSettings s)
        {
            var parts = Included(s);
            string Material(Material m) =>
                !m ? "0" : m.GetInstanceID() + "/" + (m.HasProperty(MainTex) && m.GetTexture(MainTex) ? m.GetTexture(MainTex).GetInstanceID() : 0);
            var ids = parts.Select(r => r.GetInstanceID() + ":" + string.Join(",", r.sharedMaterials.Select(Material)));
            string pattern = s.pattern ? $"{s.pattern.GetInstanceID()}x{s.patternRepeat}/{Hash(s.pattern)}" : "-";
            return $"{s.output}|{pattern}|{string.Join(";", ids)}";
        }

        private static string Hash(Object asset)
        {
            string path = AssetDatabase.GetAssetPath(asset);
            return string.IsNullOrEmpty(path) ? "0" : AssetDatabase.GetAssetDependencyHash(path).ToString().Substring(0, 8);
        }

        internal static bool Current(HairGradationSettings s) => s.generated && s.generatedFor == Structure(s);

        // Makes the generated objects again, as one Undo step. Returns what could not be done.
        internal static List<string> Rebuild(HairGradationSettings s)
        {
            var problems = new List<string>();
            var parts = Included(s);
            Undo.SetCurrentGroupName("Hair Gradation");
            int undo = Undo.GetCurrentGroup();
            if (s.generated) Undo.DestroyObjectImmediate(s.generated);
            if (parts.Count == 0)
            {
                Undo.RecordObject(s, "Hair Gradation");
                s.generated = null;
                s.generatedFor = "";
                problems.Add("넣을 렌더러가 없어요. 헤어 루트 아래의 켜진 메시를 하나 이상 골라 주세요.");
                Undo.CollapseUndoOperations(undo);
                return problems;
            }
            var groups = Groups(parts, problems);
            bool lilToon = s.output != GradationOutput.MainTexture;
            if (lilToon)
                foreach (var material in groups.SelectMany(g => g.Materials).Distinct().Where(m => !IsLilToon(m)))
                    problems.Add($"‘{material.name}’은(는) lilToon이 아니라서 2nd/3rd 컬러에 넣을 수 없어요. 결과를 ‘메인 텍스처’로 바꾸거나 lilToon으로 바꿔 주세요.");

            // TexTransTool replaces a texture (and changes a material) everywhere it is used.
            var avatar = AvatarRoot(s).GetComponentsInChildren<Renderer>(true).Where(r => !parts.Contains(r)).ToList();
            foreach (var group in groups)
            {
                var others = avatar.Where(r => r.sharedMaterials.Any(m => m && (group.Materials.Contains(m) || (!lilToon && TextureOf(m) == group.Texture))))
                    .Select(r => $"‘{r.name}’").Distinct().ToList();
                if (others.Count > 0)
                    problems.Add($"칠하지 않는 메시도 ‘{group.Texture.name}’을(를) 써요: {string.Join(", ", others.Take(5))}{(others.Count > 5 ? " …" : "")}. " +
                                 "그 메시에도 바뀐 결과가 보여요. 따로 두려면 그 메시의 머티리얼과 텍스처를 복제해 주세요.");
            }

            var container = new GameObject(ContainerName);
            Undo.RegisterCreatedObjectUndo(container, "Hair Gradation");
            container.transform.SetParent(s.transform, false);
            GameObject Child(string name, Transform parent)
            {
                var go = new GameObject(name);
                go.transform.SetParent(parent, false);
                return go;
            }

            bool canvases = s.pattern || lilToon;
            if (!canvases)
            {
                var decal = Child("Gradient", container.transform).AddComponent<SingleGradationDecal>();
                decal.RendererSelector.Mode = RendererSelectMode.Manual;
                decal.RendererSelector.ManualSelections = parts.ToList();
                decal.TargetPropertyName = new TTTPropertyName(MainTex);
            }
            else
            {
                // Inside a canvas a decal paints every renderer that shows the canvas's texture; this keeps it to the parts.
                var selector = Child("Hair Renderers", container.transform).AddComponent<RendererIslandSelector>();
                selector.RendererList = parts.ToList();
                var tiled = s.pattern ? TiledPattern(s, problems) : null;
                foreach (var group in groups.Where(g => !lilToon || g.Materials.All(IsLilToon)))
                {
                    var target = group.Texture;
                    if (lilToon)
                    {
                        target = BlankTexture(s, group.Texture, problems);
                        if (!target) continue;
                        foreach (var material in group.Materials)
                        {
                            var modifier = Child("Material · " + material.name, container.transform).AddComponent<MaterialModifier>();
                            modifier.TargetMaterial = material;
                            modifier.OverrideProperties = LilToonProperties(material, s, target);
                        }
                    }
                    var canvas = Child("Canvas · " + group.Texture.name, container.transform).AddComponent<MultiLayerImageCanvas>();
                    canvas.TargetTexture.SelectTexture = target;
                    // The first child is the top layer.
                    if (tiled)
                    {
                        var pattern = Child("Pattern", canvas.transform).AddComponent<SimpleDecal>();
                        pattern.DecalTexture = tiled;
                        pattern.FixedAspect = false;
                        pattern.IslandSelector = selector;
                        pattern.TargetPropertyName = new TTTPropertyName(MainTex);
                        pattern.gameObject.AddComponent<AsLayer>();
                    }
                    var gradient = Child("Gradient", canvas.transform).AddComponent<SingleGradationDecal>();
                    gradient.IslandSelector = selector;
                    gradient.TargetPropertyName = new TTTPropertyName(MainTex);
                    gradient.gameObject.AddComponent<AsLayer>();
                    if (!lilToon) Child("Original", canvas.transform).AddComponent<RasterLayer>().RasterTexture = group.Texture;
                }
            }
            // Recorded after the objects are made, so Undo and Redo bring the reference back with them.
            Undo.RecordObject(s, "Hair Gradation");
            s.generated = container;
            s.generatedFor = Structure(s);
            Sync(s, Measured(s, parts));
            EditorUtility.SetDirty(s);
            Undo.CollapseUndoOperations(undo);
            return problems;
        }

        // Puts the settings a live edit can change into the generated components (recorded for Undo).
        internal static void Sync(HairGradationSettings s, Measure m)
        {
            if (!s.generated || !m.Valid) return;
            var components = s.generated.GetComponentsInChildren<Component>(true).Where(c => !(c is Transform)).ToArray();
            Undo.RecordObjects(components.Concat(s.generated.GetComponentsInChildren<Transform>(true)).ToArray(), "Hair Gradation");
            bool lilToon = s.output != GradationOutput.MainTexture;

            // The gradient: origin at the start height, local +Y down the hair, as long as start to end.
            float from = m.U.y - Mathf.Clamp01(s.start) * m.Height;
            float length = Mathf.Max(0.001f, (Mathf.Clamp01(s.end) - Mathf.Clamp01(s.start)) * m.Height);
            var center = m.Right * ((m.R.x + m.R.y) / 2f) + m.Forward * ((m.F.x + m.F.y) / 2f);
            var gradientRotation = Quaternion.LookRotation(m.Forward, -m.Up);
            var gradientScale = new Vector3(m.R.y - m.R.x, length, m.F.y - m.F.x);
            // Into lilToon the gradient is painted plain on a blank texture; lilToon blends it with the chosen mode.
            string gradientBlend = lilToon ? "Normal" : s.blend;
            foreach (var decal in components.OfType<SingleGradationDecal>())
            {
                Place(decal.transform, center + m.Up * from, gradientRotation, gradientScale);
                decal.Gradient = new Gradient { mode = s.gradient.mode, colorKeys = s.gradient.colorKeys, alphaKeys = s.gradient.alphaKeys };
                decal.Alpha = s.opacity;
                // Off: TexTransTool stretches the end colors past the range (on, it leaves the rest unpainted).
                decal.GradientClamp = false;
                decal.BlendTypeKey = gradientBlend;
                decal.Padding = s.padding;
                if (decal.TryGetComponent<AsLayer>(out var layer))
                {
                    layer.Opacity = 1f;
                    layer.Clipping = false;
                    layer.BlendTypeKey = gradientBlend;
                }
            }

            // The pattern: a square box over the hair's front, projecting backwards through it.
            float side = Mathf.Max(m.R.y - m.R.x, m.Height) * 1.05f;
            float margin = 0.01f;
            var patternPlace = m.Right * ((m.R.x + m.R.y) / 2f) + m.Up * ((m.U.x + m.U.y) / 2f) + m.Forward * (m.F.y + margin);
            foreach (var decal in components.OfType<SimpleDecal>())
            {
                Place(decal.transform, patternPlace, Quaternion.LookRotation(-m.Forward, m.Up), new Vector3(side, side, m.F.y - m.F.x + 2f * margin));
                decal.Color = s.patternColor;
                decal.BackCulling = !s.patternOnBack;
                decal.BlendTypeKey = s.patternBlend;
                decal.Padding = s.padding;
                if (decal.TryGetComponent<AsLayer>(out var layer))
                {
                    layer.Opacity = s.patternOpacity;
                    layer.Clipping = s.patternInsideGradient;
                    layer.BlendTypeKey = s.patternBlend;
                }
            }

            // lilToon: the 2nd/3rd color blends as chosen.
            int mode = LilToonBlendMode(s);
            foreach (var modifier in components.OfType<MaterialModifier>())
                for (int i = 0; i < modifier.OverrideProperties.Count; i++)
                {
                    var property = modifier.OverrideProperties[i];
                    if (!property.PropertyName.EndsWith("TexBlendMode", StringComparison.Ordinal)) continue;
                    modifier.OverrideProperties[i] = Number(property, mode);
                }
            foreach (var c in components) EditorUtility.SetDirty(c);
        }

        private static Texture2D TextureOf(Material material) =>
            material && material.HasProperty(MainTex) ? material.GetTexture(MainTex) as Texture2D : null;

        private static int LilToonBlendMode(HairGradationSettings s)
        {
            int mode = Array.FindIndex(Blends, b => b.Key == s.blend);
            return mode >= 0 && mode < LilToonBlends ? mode : 0;
        }

        // A number property set to a value, whether the shader declares it Float, Range or Int.
        private static MaterialProperty Number(MaterialProperty p, float value)
        {
            p.FloatValue = value;
            p.IntValue = Mathf.RoundToInt(value);
            return p;
        }

        // lilToon's 2nd/3rd color turned on with the texture to paint, white, blended as chosen.
        private static List<MaterialProperty> LilToonProperties(Material material, HairGradationSettings s, Texture2D blank)
        {
            var list = new List<MaterialProperty>();
            if (!material || !blank) return list;
            string n = s.output == GradationOutput.LilToonMain3rd ? "3rd" : "2nd";
            void Set(string name, Func<MaterialProperty, MaterialProperty> value)
            {
                if (MaterialProperty.TryGet(material, name, out var property)) list.Add(value(property));
            }
            Set($"_UseMain{n}Tex", p => Number(p, 1f));
            Set($"_Main{n}Tex", p =>
            {
                p.TextureValue = blank;
                p.TextureScaleValue = Vector2.one;
                p.TextureOffsetValue = Vector2.zero;
                return p;
            });
            Set($"_Color{n}", p =>
            {
                p.ColorValue = Color.white;
                return p;
            });
            Set($"_Main{n}TexBlendMode", p => Number(p, LilToonBlendMode(s)));
            return list;
        }

        // Places an object in the world below any parent: each local axis is scaled by how much the parent stretches it.
        private static void Place(Transform t, Vector3 position, Quaternion rotation, Vector3 worldScale)
        {
            t.SetPositionAndRotation(position, rotation);
            if (!t.parent)
            {
                t.localScale = worldScale;
                return;
            }
            var parent = t.parent.localToWorldMatrix;
            float Stretch(Vector3 axis) => Mathf.Max(1e-6f, parent.MultiplyVector(t.localRotation * axis).magnitude);
            t.localScale = new Vector3(worldScale.x / Stretch(Vector3.right), worldScale.y / Stretch(Vector3.up), worldScale.z / Stretch(Vector3.forward));
        }

        // Where the parts are now, cheaply: the measure is taken again when they move.
        internal static string Placement(IEnumerable<Renderer> renderers) =>
            string.Join(";", renderers.Select(r => r.bounds).Select(b => $"{b.center.x:0.000},{b.center.y:0.000},{b.center.z:0.000},{b.size.x:0.000},{b.size.y:0.000},{b.size.z:0.000}"));

        // ---- assets ------------------------------------------------------------------------------------------------

        private static string Folder(HairGradationSettings s)
        {
            string name = string.Concat(AvatarRoot(s).name.Select(ch => Path.GetInvalidFileNameChars().Contains(ch) ? '_' : ch)).Trim();
            string folder = AssetRoot + "/" + (string.IsNullOrEmpty(name) ? "Avatar" : name);
            if (!AssetDatabase.IsValidFolder(folder))
            {
                string at = "Assets";
                foreach (var part in folder.Split('/').Skip(1))
                {
                    if (!AssetDatabase.IsValidFolder(at + "/" + part)) AssetDatabase.CreateFolder(at, part);
                    at += "/" + part;
                }
            }
            return folder;
        }

        private static string Safe(string name) => string.Concat(name.Select(ch => Path.GetInvalidFileNameChars().Contains(ch) ? '_' : ch));

        // The pattern repeated into one square texture (TexTransTool's decal shows its texture once).
        private static Texture2D TiledPattern(HairGradationSettings s, List<string> problems)
        {
            string path = $"{Folder(s)}/Pattern_{Safe(s.pattern.name)}_{s.patternRepeat}x_{Hash(s.pattern)}.png";
            var existing = AssetDatabase.LoadAssetAtPath<Texture2D>(path);
            if (existing) return existing;
            int size = Mathf.Clamp(Mathf.NextPowerOfTwo(Mathf.Max(s.pattern.width, s.pattern.height) * s.patternRepeat), 256, 4096);
            var (wrapU, wrapV, wrapW) = (s.pattern.wrapModeU, s.pattern.wrapModeV, s.pattern.wrapModeW);
            var target = RenderTexture.GetTemporary(size, size, 0, RenderTextureFormat.ARGB32, RenderTextureReadWrite.sRGB);
            var active = RenderTexture.active;
            var image = new Texture2D(size, size, TextureFormat.RGBA32, false);
            try
            {
                s.pattern.wrapMode = TextureWrapMode.Repeat;
                Graphics.Blit(s.pattern, target, new Vector2(s.patternRepeat, s.patternRepeat), Vector2.zero);
                RenderTexture.active = target;
                image.ReadPixels(new Rect(0, 0, size, size), 0, 0);
                image.Apply();
                return Save(image, path, problems);
            }
            finally
            {
                s.pattern.wrapModeU = wrapU;
                s.pattern.wrapModeV = wrapV;
                s.pattern.wrapModeW = wrapW;
                RenderTexture.active = active;
                RenderTexture.ReleaseTemporary(target);
                Object.DestroyImmediate(image);
            }
        }

        // A transparent texture the size of a hair texture, for lilToon's 2nd/3rd color to be painted at build.
        private static Texture2D BlankTexture(HairGradationSettings s, Texture2D like, List<string> problems)
        {
            string guid = AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(like));
            string tag = s.output == GradationOutput.LilToonMain3rd ? "3rd" : "2nd";
            int width = Mathf.Min(4096, like.width), height = Mathf.Min(4096, like.height);
            // One per hair root and size: two hairs on one texture each paint their own.
            string path = $"{Folder(s)}/{Safe(s.name)}_{Safe(like.name)}_{tag}_{width}x{height}_{(guid.Length >= 8 ? guid.Substring(0, 8) : "new")}.png";
            var existing = AssetDatabase.LoadAssetAtPath<Texture2D>(path);
            if (existing) return existing;
            var image = new Texture2D(width, height, TextureFormat.RGBA32, false);
            try
            {
                image.SetPixels32(new Color32[width * height]);
                image.Apply();
                return Save(image, path, problems);
            }
            finally { Object.DestroyImmediate(image); }
        }

        private static Texture2D Save(Texture2D image, string path, List<string> problems)
        {
            try { File.WriteAllBytes(path, image.EncodeToPNG()); }
            catch (Exception e)
            {
                if (File.Exists(path)) File.Delete(path);
                problems.Add($"텍스처를 저장하지 못했어요 ({path}): {e.Message}");
                return null;
            }
            AssetDatabase.ImportAsset(path, ImportAssetOptions.ForceUpdate);
            if (AssetImporter.GetAtPath(path) is TextureImporter importer)
            {
                importer.alphaIsTransparency = true;
                importer.mipmapEnabled = true;
                // VRChat requires mip streaming on every texture it uploads (NDMF checks it at build).
                importer.streamingMipmaps = true;
                importer.wrapMode = TextureWrapMode.Clamp;
                importer.maxTextureSize = Mathf.Max(image.width, image.height);
                importer.SaveAndReimport();
            }
            return AssetDatabase.LoadAssetAtPath<Texture2D>(path);
        }
    }
}
#endif
