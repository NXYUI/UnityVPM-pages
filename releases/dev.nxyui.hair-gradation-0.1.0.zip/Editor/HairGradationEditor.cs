#if UNITY_EDITOR
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace NXYUI.HairGradation
{
    [CustomEditor(typeof(HairGradationSettings))]
    internal sealed class HairGradationEditor : Editor
    {
        private static readonly string[] Outputs = { "메인 텍스처에 합치기", "lilToon 메인 컬러 2nd", "lilToon 메인 컬러 3rd" };

        private bool partsOpen = true;
        private List<string> problems;
        private List<UVOverlap.Result> overlaps;
        // The hair measured for the structure it was measured with.
        private HairGradationBuilder.Measure measure;
        private string measuredFor;

        private GUIStyle wrappedBold;
        private GUIStyle WrappedBold => wrappedBold ??= new GUIStyle(EditorStyles.boldLabel) { wordWrap = true };

        public override void OnInspectorGUI()
        {
            var s = (HairGradationSettings)target;
            serializedObject.Update();
            EditorGUILayout.LabelField("헤어 하나에 그라데이션 하나", WrappedBold);
            EditorGUILayout.LabelField("이 오브젝트 아래의 켜진 헤어 메시를 모아, 파츠가 나뉘어 있어도 높이에 따라 이어지는 그라데이션을 만들어요. " +
                                       "TexTransTool이 빌드할 때 적용하고, 원본 텍스처는 바뀌지 않아요.", EditorStyles.wordWrappedMiniLabel);
            EditorGUILayout.Space(6);

            DrawParts(s);
            EditorGUILayout.Space(6);
            bool lilToon = s.output != GradationOutput.MainTexture;

            EditorGUILayout.LabelField("그라데이션", EditorStyles.boldLabel);
            EditorGUILayout.PropertyField(serializedObject.FindProperty("gradient"), new GUIContent("색", "왼쪽이 시작(위), 오른쪽이 끝(아래)이에요. 알파로 서서히 나타나게 할 수 있어요."));
            EditorGUILayout.Slider(serializedObject.FindProperty("opacity"), 0f, 1f, new GUIContent("불투명도"));
            Blend(serializedObject.FindProperty("blend"), "섞는 방식", lilToon);
            var start = serializedObject.FindProperty("start");
            var end = serializedObject.FindProperty("end");
            float from = start.floatValue, to = end.floatValue;
            using (new EditorGUILayout.HorizontalScope())
            {
                EditorGUILayout.PrefixLabel(new GUIContent("범위", "헤어의 맨 위(0)부터 가장 아래 끝(1)까지 중 그라데이션이 펼쳐지는 구간이에요. 범위 밖은 양 끝 색이 이어져요."));
                GUILayout.Label("위", EditorStyles.miniLabel, GUILayout.ExpandWidth(false));
                EditorGUILayout.MinMaxSlider(ref from, ref to, 0f, 1f);
                GUILayout.Label("아래", EditorStyles.miniLabel, GUILayout.ExpandWidth(false));
            }
            if (!Mathf.Approximately(from, start.floatValue) || !Mathf.Approximately(to, end.floatValue))
            {
                start.floatValue = from;
                end.floatValue = Mathf.Max(to, from + 0.01f);
            }
            EditorGUILayout.LabelField($"시작 {start.floatValue * 100f:0}% · 끝 {end.floatValue * 100f:0}%", EditorStyles.miniLabel);
            EditorGUILayout.Space(6);

            EditorGUILayout.LabelField("패턴 (선택)", EditorStyles.boldLabel);
            EditorGUILayout.PropertyField(serializedObject.FindProperty("pattern"), new GUIContent("텍스처", "앞에서 헤어 전체에 투영해요. 비워 두면 그라데이션만 넣어요."));
            if (s.pattern)
            {
                EditorGUILayout.PropertyField(serializedObject.FindProperty("patternColor"), new GUIContent("색"));
                EditorGUILayout.Slider(serializedObject.FindProperty("patternOpacity"), 0f, 1f, new GUIContent("불투명도"));
                EditorGUILayout.IntSlider(serializedObject.FindProperty("patternRepeat"), 1, 16, new GUIContent("반복", "헤어 전체에 패턴이 몇 번 반복되는지예요."));
                EditorGUILayout.PropertyField(serializedObject.FindProperty("patternInsideGradient"), new GUIContent("그라데이션 안에만", "켜면 그라데이션이 보이는 곳에만 패턴이 나와요. 패턴은 그라데이션과 한 묶음이 되어 그라데이션의 섞는 방식으로 섞여요."));
                EditorGUILayout.PropertyField(serializedObject.FindProperty("patternOnBack"), new GUIContent("뒤쪽에도", "켜면 앞에서 투영한 패턴이 뒷머리에도 들어가요."));
                Blend(serializedObject.FindProperty("patternBlend"), "섞는 방식", false);
                EditorGUILayout.LabelField("패턴은 앞에서 평행하게 투영해서, 옆머리에서는 늘어나 보일 수 있어요.", EditorStyles.wordWrappedMiniLabel);
            }
            EditorGUILayout.Space(6);

            EditorGUILayout.LabelField("결과", EditorStyles.boldLabel);
            var output = serializedObject.FindProperty("output");
            output.enumValueIndex = EditorGUILayout.Popup(new GUIContent("넣을 곳",
                "메인 텍스처: 빌드할 때 텍스처를 새로 만들어 바꿔요. lilToon 2nd/3rd: 메인 텍스처는 두고 그 칸에 그라데이션을 넣어요."), output.enumValueIndex, Outputs);
            EditorGUILayout.Slider(serializedObject.FindProperty("padding"), 0f, 32f, new GUIContent("여백", "UV 섬 가장자리 밖으로 칠하는 픽셀 수예요. 이음매가 비치면 늘리세요."));
            bool changed = serializedObject.ApplyModifiedProperties();
            EditorGUILayout.Space(8);

            DrawBuild(s);
            if (changed && HairGradationBuilder.Current(s))
            {
                var included = HairGradationBuilder.Included(s);
                // Measured again when the parts change or move.
                string key = HairGradationBuilder.Structure(s) + "|" + HairGradationBuilder.Placement(included);
                if (measuredFor != key)
                {
                    measure = HairGradationBuilder.Measured(s, included);
                    measuredFor = key;
                }
                HairGradationBuilder.Sync(s, measure);
            }
        }

        private void DrawParts(HairGradationSettings s)
        {
            var parts = HairGradationBuilder.Parts(s);
            int included = parts.Count(p => p.Included);
            partsOpen = EditorGUILayout.Foldout(partsOpen, $"칠할 메시 {included}/{parts.Count}개", true);
            if (!partsOpen) return;
            if (parts.Count == 0)
            {
                EditorGUILayout.HelpBox("이 오브젝트 아래에 메시가 없어요. 헤어의 루트 오브젝트에 붙여 주세요.", MessageType.Info);
                return;
            }
            foreach (var part in parts)
                using (new EditorGUILayout.HorizontalScope())
                using (new EditorGUI.DisabledScope(part.Blocked != null))
                {
                    bool next = EditorGUILayout.ToggleLeft(new GUIContent(part.Renderer.name, part.Blocked ?? "끄면 이 메시는 칠하지 않아요."), part.Included);
                    if (part.Blocked != null) GUILayout.Label(part.Blocked, EditorStyles.miniLabel, GUILayout.ExpandWidth(false));
                    if (next == part.Included || part.Blocked != null) continue;
                    Undo.RecordObject(s, "Hair Gradation parts");
                    if (next) s.excluded.Remove(part.Renderer);
                    else if (!s.excluded.Contains(part.Renderer)) s.excluded.Add(part.Renderer);
                    s.excluded.RemoveAll(r => !r);
                    EditorUtility.SetDirty(s);
                }
            EditorGUILayout.LabelField("악세서리처럼 칠하지 않을 메시는 체크를 끄세요. 꺼진 오브젝트는 들어가지 않아요.", EditorStyles.wordWrappedMiniLabel);
        }

        private static void Blend(SerializedProperty property, string label, bool lilToon)
        {
            var blends = HairGradationBuilder.Blends.Take(lilToon ? HairGradationBuilder.LilToonBlends : HairGradationBuilder.Blends.Length).ToArray();
            int index = System.Array.FindIndex(blends, b => b.Key == property.stringValue);
            int next = EditorGUILayout.Popup(label, Mathf.Max(0, index), blends.Select(b => b.Label).ToArray());
            if (next != index) property.stringValue = blends[next].Key;
        }

        private void DrawBuild(HairGradationSettings s)
        {
            EditorGUILayout.LabelField("TexTransTool 구성", EditorStyles.boldLabel);
            bool current = HairGradationBuilder.Current(s);
            if (!s.generated)
                EditorGUILayout.HelpBox("아직 구성이 없어요. ‘구성 만들기’를 누르면 이 오브젝트 아래에 TexTransTool 컴포넌트를 만들어요.", MessageType.Info);
            else if (!current)
                EditorGUILayout.HelpBox("⚠ 메시, 텍스처, 패턴이나 넣을 곳이 바뀌었어요. ‘구성 다시 만들기’를 눌러야 반영돼요.", MessageType.Warning);
            else
                EditorGUILayout.LabelField("구성이 최신이에요. 색과 범위는 바꾸는 즉시 반영돼요. 만든 오브젝트는 직접 고치지 마세요.", EditorStyles.wordWrappedMiniLabel);
            using (new EditorGUILayout.HorizontalScope())
            {
                if (GUILayout.Button(s.generated ? "구성 다시 만들기" : "구성 만들기"))
                {
                    problems = HairGradationBuilder.Rebuild(s);
                    measuredFor = null;
                    overlaps = null;
                    GUIUtility.ExitGUI();
                }
                if (GUILayout.Button(new GUIContent("UV 겹침 확인", "파츠들이 텍스처의 같은 곳을 다른 높이에서 쓰는지 봐요.")))
                {
                    overlaps = UVOverlap.Check(s, HairGradationBuilder.Included(s));
                    GUIUtility.ExitGUI();
                }
            }
            if (problems != null)
                foreach (var problem in problems) EditorGUILayout.HelpBox("⚠ " + problem, MessageType.Warning);
            if (overlaps != null)
            {
                if (overlaps.Count == 0) EditorGUILayout.HelpBox("UV가 다른 높이에서 겹치는 곳이 없어요.", MessageType.Info);
                foreach (var o in overlaps)
                    EditorGUILayout.HelpBox($"⚠ ‘{o.Texture}’: 칠하는 곳의 {o.Share * 100f:0.#}%에서 높이가 다른 부분이 텍스처의 같은 곳을 써요 ({o.Between}). " +
                                            "그 자리는 한쪽 높이로만 칠해져 색이 어긋나요. 한쪽 파츠의 머티리얼과 텍스처를 복제해서 따로 쓰세요.", MessageType.Warning);
            }
            EditorGUILayout.LabelField("Scene 뷰의 NDMF 미리보기가 켜져 있으면 결과가 바로 보여요.", EditorStyles.wordWrappedMiniLabel);
        }
    }

    internal static class HairGradationMenu
    {
        [MenuItem("NXYUI/Hair Gradation")]
        private static void Add() => AddTo(Selection.activeGameObject);

        [MenuItem("GameObject/NXYUI/Hair Gradation", false, 20)]
        private static void AddFromHierarchy(MenuCommand command) => AddTo(command.context as GameObject ? (GameObject)command.context : Selection.activeGameObject);

        private static void AddTo(GameObject go)
        {
            if (!go || EditorUtility.IsPersistent(go))
            {
                EditorUtility.DisplayDialog("Hair Gradation", "Hierarchy에서 헤어의 루트 오브젝트를 먼저 골라 주세요.", "확인");
                return;
            }
            if (!go.TryGetComponent<HairGradationSettings>(out _)) Undo.AddComponent<HairGradationSettings>(go);
            Selection.activeGameObject = go;
        }
    }
}
#endif
