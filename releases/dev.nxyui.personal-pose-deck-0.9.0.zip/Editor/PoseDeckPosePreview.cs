using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEditor.Animations;
using UnityEngine;
using UnityEngine.Animations;
using UnityEngine.Playables;
using UnityEngine.Rendering;
using UnityEngine.SceneManagement;
using Object = UnityEngine.Object;

namespace PersonalPoseDeck
{
    // Copies the rig and renderers only. No scene behaviours or controllers are instantiated.
    internal sealed class PoseDeckPosePreview : IDisposable
    {
        private readonly PreviewRenderUtility preview;
        private readonly Dictionary<Transform, Transform> rig = new Dictionary<Transform, Transform>();
        private readonly List<Renderer> renderers = new List<Renderer>();
        private readonly List<(Transform bone, Vector3 position, Quaternion rotation, Vector3 scale)> rest =
            new List<(Transform, Vector3, Quaternion, Vector3)>();
        private Animator animator;
        private Transform previewRoot;
        private readonly PoseDeckPreviewConstraints constraints;
        private PlayableGraph graph;
        private AnimationClipPlayable playable;
        private AnimationClip clip;
        private Bounds frame;
        private float yaw = 45f, pitch = -25f, zoom = .90f;
        private bool freeLook, freeMouseHeld, panMouseHeld;
        private Vector3 orbitPan;
        private Vector3 freePosition;
        private float freeYaw, freePitch, freeFov;
        private double lastCameraTick;
        private readonly HashSet<KeyCode> movementKeys = new HashSet<KeyCode>();
        // Mirroring goes through a one-state, in-memory controller so Unity mirrors the pose exactly as GoGoLoco's
        // "Right" states (AnimatorState.mirror) do in game.
        private static readonly int MirrorStateHash = Animator.StringToHash("Pose");
        private AnimatorController mirrorController;
        private AnimatorControllerPlayable controllerPlayable;
        private bool mirror;
        private GameObject floor;
        private Mesh floorMesh;
        private Material floorMaterial;

        internal bool HasHumanoidAvatar => animator && animator.avatar && animator.avatar.isValid && animator.avatar.isHuman;
        internal bool HasRenderers => renderers.Count != 0;
        // Lowest point of the rendered meshes above the avatar root (the floor), measured after the last draw.
        internal float? LowestPoint { get; private set; }

        internal bool ShowFloor
        {
            get => floor && floor.activeSelf;
            set { if (floor) floor.SetActive(value); }
        }

        internal bool Mirror
        {
            get => mirror;
            set
            {
                if (mirror == value) return;
                mirror = value;
                var current = clip;
                clip = null;
                SetClip(current);
            }
        }

        internal PoseDeckPosePreview(GameObject avatar)
        {
            preview = new PreviewRenderUtility();
            try
            {
                Transform root = MakeNode(avatar.transform, null, true);
                previewRoot = root;
                CopyRenderers(avatar.transform, true);
                animator = root.gameObject.AddComponent<Animator>();
                var original = avatar.GetComponent<Animator>();
                if (original) animator.avatar = original.avatar;
                animator.applyRootMotion = false;
                animator.fireEvents = false;
                animator.cullingMode = AnimatorCullingMode.AlwaysAnimate;
                animator.Rebind();
                foreach (var bone in rig.Values) rest.Add((bone, bone.localPosition, bone.localRotation, bone.localScale));
                constraints = new PoseDeckPreviewConstraints(avatar, Map);
                constraints.Apply();
                preview.camera.clearFlags = CameraClearFlags.Color;
                preview.camera.backgroundColor = new Color(.24f, .26f, .29f, 1f);
                preview.camera.orthographic = true;
                preview.ambientColor = new Color(.65f, .65f, .65f, 1f);
                preview.lights[0].intensity = 1.55f;
                preview.lights[0].transform.rotation = Quaternion.Euler(34f, -151f, 0f);
                preview.lights[1].intensity = 1.10f;
                preview.lights[1].transform.rotation = Quaternion.Euler(17f, 143f, 0f);
                Fit();
                CreateFloor(Mathf.Max(1.5f, frame.size.y * 1.6f));
            }
            catch
            {
                Dispose();
                throw;
            }
        }

        private Transform MakeNode(Transform source, Transform parent, bool isRoot)
        {
            var obj = EditorUtility.CreateGameObjectWithHideFlags(source.name, HideFlags.HideAndDontSave);
            obj.layer = source.gameObject.layer;
            var node = obj.transform;
            if (isRoot)
            {
                preview.AddSingleGO(obj);
                node.localScale = source.lossyScale;
            }
            else
            {
                SceneManager.MoveGameObjectToScene(obj, parent.gameObject.scene);
                node.SetParent(parent, false);
                node.localPosition = source.localPosition;
                node.localRotation = source.localRotation;
                node.localScale = source.localScale;
                obj.SetActive(source.gameObject.activeSelf);
            }
            rig.Add(source, node);
            foreach (Transform child in source) MakeNode(child, node, false);
            return node;
        }

        private Transform Map(Transform source) => source && rig.TryGetValue(source, out var node) ? node : null;

        // A line grid on the avatar's floor (y = 0 under the root), so floating or sinking poses are visible.
        private void CreateFloor(float size)
        {
            var shader = Shader.Find("Hidden/Internal-Colored");
            if (!shader) return;
            floorMaterial = new Material(shader) { hideFlags = HideFlags.HideAndDontSave };
            floorMaterial.SetInt("_SrcBlend", (int)BlendMode.SrcAlpha);
            floorMaterial.SetInt("_DstBlend", (int)BlendMode.OneMinusSrcAlpha);
            floorMaterial.SetInt("_Cull", (int)CullMode.Off);
            floorMaterial.SetInt("_ZWrite", 1);
            var vertices = new List<Vector3>();
            var colors = new List<Color>();
            const int lines = 10;
            float half = size * .5f, step = size / lines;
            for (int i = 0; i <= lines; i++)
            {
                float o = -half + i * step;
                var color = i == lines / 2 ? new Color(.66f, .70f, .76f, .95f) : new Color(.46f, .49f, .55f, .55f);
                vertices.AddRange(new[] { new Vector3(o, 0, -half), new Vector3(o, 0, half), new Vector3(-half, 0, o), new Vector3(half, 0, o) });
                colors.AddRange(new[] { color, color, color, color });
            }
            floorMesh = new Mesh { name = "Pose Deck floor", hideFlags = HideFlags.HideAndDontSave };
            floorMesh.SetVertices(vertices);
            floorMesh.SetColors(colors);
            floorMesh.SetIndices(Enumerable.Range(0, vertices.Count).ToArray(), MeshTopology.Lines, 0);
            floor = EditorUtility.CreateGameObjectWithHideFlags("Pose Deck floor", HideFlags.HideAndDontSave,
                typeof(MeshFilter), typeof(MeshRenderer));
            floor.GetComponent<MeshFilter>().sharedMesh = floorMesh;
            var meshRenderer = floor.GetComponent<MeshRenderer>();
            meshRenderer.sharedMaterial = floorMaterial;
            meshRenderer.shadowCastingMode = ShadowCastingMode.Off;
            meshRenderer.receiveShadows = false;
            preview.AddSingleGO(floor);
        }

        internal void SetView(float viewYaw, float viewPitch)
        {
            yaw = viewYaw;
            pitch = Mathf.Clamp(viewPitch, -85f, 85f);
            orbitPan = Vector3.zero;
            freeLook = false;
            StopCameraDrag();
        }

        private void CopyRenderers(Transform source, bool visible)
        {
            var node = rig[source];
            foreach (var original in source.GetComponents<Light>())
            {
                var light = node.gameObject.AddComponent<Light>();
                EditorUtility.CopySerialized(original, light);
            }
            if (visible)
            {
                foreach (var old in source.GetComponents<SkinnedMeshRenderer>())
                {
                    if (!old.enabled || !old.sharedMesh) continue;
                    var oldBones = old.bones;
                    if (oldBones.Any(b => b && !rig.ContainsKey(b))) continue;
                    var copy = node.gameObject.AddComponent<SkinnedMeshRenderer>();
                    copy.sharedMesh = old.sharedMesh;
                    copy.sharedMaterials = old.sharedMaterials;
                    copy.bones = oldBones.Select(Map).ToArray();
                    copy.rootBone = Map(old.rootBone);
                    copy.localBounds = old.localBounds;
                    copy.updateWhenOffscreen = true;
                    copy.quality = old.quality;
                    for (int i = 0; i < old.sharedMesh.blendShapeCount; i++) copy.SetBlendShapeWeight(i, old.GetBlendShapeWeight(i));
                    renderers.Add(copy);
                }
                var oldFilter = source.GetComponent<MeshFilter>();
                var oldMesh = source.GetComponent<MeshRenderer>();
                if (oldFilter && oldFilter.sharedMesh && oldMesh && oldMesh.enabled)
                {
                    node.gameObject.AddComponent<MeshFilter>().sharedMesh = oldFilter.sharedMesh;
                    var copy = node.gameObject.AddComponent<MeshRenderer>();
                    copy.sharedMaterials = oldMesh.sharedMaterials;
                    renderers.Add(copy);
                }
            }
            foreach (Transform child in source) CopyRenderers(child, visible && child.gameObject.activeSelf);
        }

        internal void SetClip(AnimationClip value)
        {
            if (clip == value) return;
            if (graph.IsValid()) graph.Destroy();
            DestroyMirrorController();
            clip = value;
            animator.Rebind();
            foreach (var (bone, pos, rot, scale) in rest)
            {
                bone.localPosition = pos;
                bone.localRotation = rot;
                bone.localScale = scale;
            }
            if (!clip || clip.legacy || (clip.humanMotion && !HasHumanoidAvatar)) return;
            graph = PlayableGraph.Create("Pose Deck preview");
            graph.SetTimeUpdateMode(DirectorUpdateMode.Manual);
            var output = AnimationPlayableOutput.Create(graph, "Pose Deck pose", animator);
            if (mirror)
            {
                mirrorController = new AnimatorController { name = "Pose Deck mirror", hideFlags = HideFlags.HideAndDontSave };
                mirrorController.AddLayer("Pose");
                var state = mirrorController.layers[0].stateMachine.AddState("Pose");
                state.motion = clip;
                state.mirror = true;
                state.iKOnFeet = false;
                state.writeDefaultValues = true;
                state.speed = 0f;
                controllerPlayable = AnimatorControllerPlayable.Create(graph, mirrorController);
                output.SetSourcePlayable(controllerPlayable);
            }
            else
            {
                playable = AnimationClipPlayable.Create(graph, clip);
                playable.SetApplyFootIK(false);
                playable.SetApplyPlayableIK(false);
                playable.SetSpeed(0);
                output.SetSourcePlayable(playable);
            }
            graph.Play();
        }

        private void DestroyMirrorController()
        {
            if (!mirrorController) return;
            var machine = mirrorController.layers.Length > 0 ? mirrorController.layers[0].stateMachine : null;
            if (machine)
            {
                foreach (var child in machine.states) if (child.state) Object.DestroyImmediate(child.state);
                Object.DestroyImmediate(machine);
            }
            Object.DestroyImmediate(mirrorController);
            mirrorController = null;
        }

        internal void Sample(float time)
        {
            constraints.ResetTargets();
            if (graph.IsValid())
            {
                var t = Mathf.Clamp(time, 0, Mathf.Max(0, clip.length));
                if (mirror && controllerPlayable.IsValid())
                    controllerPlayable.Play(MirrorStateHash, 0, clip.length > 0 ? t / clip.length : 0f);
                else
                    playable.SetTime(t);
                graph.Evaluate(0f);
            }
            constraints.Apply();
        }

        internal void Fit()
        {
            if (renderers.Count > 0)
            {
                frame = renderers[0].bounds;
                for (int i = 1; i < renderers.Count; i++) frame.Encapsulate(renderers[i].bounds);
            }
            else frame = new Bounds(Vector3.up * .8f, new Vector3(.8f, 1.6f, .5f));
            zoom = .90f;
            orbitPan = Vector3.zero;
            freeLook = false;
            StopCameraDrag();
        }

        internal void Draw(Rect rect, bool invertVertical)
        {
            HandleCamera(rect, invertVertical);
            var evt = Event.current;
            if (evt.type != EventType.Repaint || rect.width < 2 || rect.height < 2) return;
            if (freeLook)
            {
                var camera = preview.camera;
                camera.orthographic = false;
                camera.fieldOfView = freeFov;
                camera.transform.SetPositionAndRotation(freePosition, Quaternion.Euler(freePitch, freeYaw, 0f));
            }
            else Aim(rect.width / rect.height, yaw, pitch, zoom);
            preview.BeginPreview(rect, GUIStyle.none);
            try { preview.Render(true, false); }
            finally
            {
                var texture = preview.EndPreview();
                if (texture) GUI.DrawTexture(rect, texture, ScaleMode.StretchToFill, false);
            }
            // Skinned bounds follow the pose once it has been rendered (updateWhenOffscreen is on).
            LowestPoint = renderers.Count == 0 ? (float?)null :
                renderers.Where(r => r && r.enabled && r.gameObject.activeInHierarchy).Select(r => r.bounds.min.y)
                    .DefaultIfEmpty(0f).Min() - previewRoot.position.y;
        }

        private void HandleCamera(Rect rect, bool invertVertical)
        {
            var evt = Event.current;
            int id = GUIUtility.GetControlID("PoseDeckPreviewCamera".GetHashCode(), FocusType.Passive, rect);
            if (GUIUtility.hotControl == id && !freeMouseHeld && !panMouseHeld) GUIUtility.hotControl = 0;
            if (evt.type == EventType.MouseDown && evt.button == 2 && rect.Contains(evt.mousePosition))
            {
                StopCameraDrag();
                panMouseHeld = true;
                GUIUtility.hotControl = id;
                evt.Use();
                return;
            }
            if (panMouseHeld && GUIUtility.hotControl == id)
            {
                if (evt.type == EventType.MouseUp && evt.button == 2 || evt.type == EventType.Ignore)
                {
                    StopCameraDrag();
                    GUIUtility.hotControl = 0;
                    if (evt.type != EventType.Ignore) evt.Use();
                    return;
                }
                if (evt.type == EventType.MouseDrag && evt.button == 2)
                {
                    var camera = preview.camera;
                    float halfHeight = freeLook
                        ? Mathf.Max(.05f, Vector3.Distance(freePosition, frame.center)) * Mathf.Tan(freeFov * Mathf.Deg2Rad * .5f)
                        : camera.orthographicSize;
                    var delta = (-camera.transform.right * evt.delta.x + camera.transform.up * evt.delta.y) *
                        (2f * halfHeight / Mathf.Max(1f, rect.height));
                    if (freeLook) freePosition += delta; else orbitPan += delta;
                    evt.Use();
                    GUI.changed = true;
                    return;
                }
            }
            if (evt.type == EventType.MouseDown && evt.button == 1 && rect.Contains(evt.mousePosition))
            {
                if (!freeLook)
                {
                    Aim(rect.width / Mathf.Max(1, rect.height), yaw, pitch, zoom);
                    var camera = preview.camera;
                    freePosition = camera.transform.position;
                    var angles = camera.transform.eulerAngles;
                    freePitch = Mathf.DeltaAngle(0, angles.x);
                    freeYaw = angles.y;
                    float distance = Mathf.Max(.01f, Vector3.Distance(freePosition, frame.center));
                    freeFov = Mathf.Clamp(Mathf.Atan(camera.orthographicSize / distance) * 2f * Mathf.Rad2Deg, 10f, 65f);
                    freeLook = true;
                }
                StopCameraDrag();
                freeMouseHeld = true;
                lastCameraTick = EditorApplication.timeSinceStartup;
                GUIUtility.hotControl = id;
                GUIUtility.keyboardControl = 0;
                evt.Use();
                GUI.changed = true;
                return;
            }
            if (freeMouseHeld && GUIUtility.hotControl == id)
            {
                if (evt.type == EventType.MouseUp && evt.button == 1 || evt.type == EventType.Ignore ||
                    evt.type == EventType.KeyDown && evt.keyCode == KeyCode.Escape)
                {
                    StopCameraDrag();
                    GUIUtility.hotControl = 0;
                    if (evt.type != EventType.Ignore) evt.Use();
                    return;
                }
                if (evt.type == EventType.MouseDrag && evt.button == 1)
                {
                    freeYaw += evt.delta.x * .25f;
                    freePitch = Mathf.Clamp(freePitch + evt.delta.y * (invertVertical ? -.25f : .25f), -88f, 88f);
                    evt.Use();
                    GUI.changed = true;
                    return;
                }
                if ((evt.type == EventType.KeyDown || evt.type == EventType.KeyUp) && IsCameraKey(evt.keyCode))
                {
                    if (evt.type == EventType.KeyDown) movementKeys.Add(evt.keyCode); else movementKeys.Remove(evt.keyCode);
                    evt.Use();
                    return;
                }
            }
            if (rect.Contains(evt.mousePosition) && evt.type == EventType.MouseDrag && evt.button == 0)
            {
                freeLook = false;
                yaw += evt.delta.x * .65f;
                pitch = Mathf.Clamp(pitch - evt.delta.y * .65f, -80f, 80f);
                evt.Use();
                GUI.changed = true;
            }
            else if (rect.Contains(evt.mousePosition) && evt.type == EventType.ScrollWheel)
            {
                if (freeLook) freeFov = Mathf.Clamp(freeFov * Mathf.Exp(evt.delta.y * .065f), 7f, 80f);
                else zoom = Mathf.Clamp(zoom * Mathf.Exp(evt.delta.y * .065f), .3f, 3.5f);
                evt.Use();
                GUI.changed = true;
            }
        }

        private static bool IsCameraKey(KeyCode key) => key == KeyCode.W || key == KeyCode.S ||
            key == KeyCode.A || key == KeyCode.D || key == KeyCode.Q || key == KeyCode.E ||
            key == KeyCode.LeftShift || key == KeyCode.RightShift;

        internal bool TickCamera()
        {
            if (!freeMouseHeld) return false;
            double now = EditorApplication.timeSinceStartup;
            float dt = Mathf.Clamp((float)(now - lastCameraTick), 0f, .08f);
            lastCameraTick = now;
            float Axis(KeyCode plus, KeyCode minus) => (movementKeys.Contains(plus) ? 1 : 0) - (movementKeys.Contains(minus) ? 1 : 0);
            var local = new Vector3(Axis(KeyCode.D, KeyCode.A), 0f, Axis(KeyCode.W, KeyCode.S));
            var move = Quaternion.Euler(freePitch, freeYaw, 0f) * local + Vector3.up * Axis(KeyCode.E, KeyCode.Q);
            if (move.sqrMagnitude < .001f) return false;
            float multiplier = movementKeys.Contains(KeyCode.LeftShift) || movementKeys.Contains(KeyCode.RightShift) ? 2.5f : 1f;
            freePosition += move.normalized * (Mathf.Max(.2f, frame.extents.magnitude) * .8f * multiplier * dt);
            return true;
        }

        internal void StopCameraDrag()
        {
            freeMouseHeld = false;
            panMouseHeld = false;
            movementKeys.Clear();
        }

        internal Texture2D CaptureThumbnail(AnimationClip animation, int size)
        {
            SetClip(animation);
            Sample(animation.length * .5f);
            Fit();
            Aim(1f, 45f, -25f, 1f);
            bool showFloor = ShowFloor;
            ShowFloor = false;
            preview.BeginStaticPreview(new Rect(0, 0, size, size));
            Texture2D result = null;
            bool succeeded = false;
            try
            {
                preview.Render(true, false);
                succeeded = true;
            }
            finally
            {
                result = preview.EndStaticPreview();
                ShowFloor = showFloor;
                if (!succeeded && result) Object.DestroyImmediate(result);
            }
            if (result)
            {
                result.hideFlags = HideFlags.HideAndDontSave;
                result.filterMode = FilterMode.Bilinear;
                result.Apply(false, true);
            }
            return result;
        }

        private void Aim(float aspect, float viewYaw, float viewPitch, float viewZoom)
        {
            var size = frame.extents;
            float radius = Mathf.Max(.12f, size.magnitude);
            var rotation = Quaternion.Euler(viewPitch, viewYaw, 0);
            var cam = preview.camera;
            cam.orthographic = true;
            var center = frame.center + orbitPan;
            cam.transform.position = center + rotation * Vector3.forward * radius * 4;
            cam.transform.rotation = Quaternion.LookRotation(center - cam.transform.position, Vector3.up);
            cam.nearClipPlane = Mathf.Max(.001f, radius * .01f);
            cam.farClipPlane = radius * 16;
            // Enclose the bounds in camera space, including the vertical extent added by the elevated view.
            var right = cam.transform.right;
            var up = cam.transform.up;
            float HalfSpan(Vector3 axis) => Mathf.Abs(axis.x) * size.x + Mathf.Abs(axis.y) * size.y + Mathf.Abs(axis.z) * size.z;
            cam.orthographicSize = Mathf.Max(HalfSpan(up), HalfSpan(right) / Mathf.Max(.2f, aspect), .07f) * 1.10f * viewZoom;
        }

        public void Dispose()
        {
            StopCameraDrag();
            if (graph.IsValid()) graph.Destroy();
            DestroyMirrorController();
            preview.Cleanup();
            if (floorMesh) Object.DestroyImmediate(floorMesh);
            if (floorMaterial) Object.DestroyImmediate(floorMaterial);
        }
    }
}
