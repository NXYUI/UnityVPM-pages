using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;
using static NXYUI.AssetManager.AssetGui;
using Object = UnityEngine.Object;

namespace NXYUI.AssetManager
{
    // Panels at the top of the Inspector for what is selected in the Project window: a folder no asset owns gets a
    // card to designate it, an asset's folder gets the asset panel (Booth link, prefabs), and a prefab inside an asset
    // gets the assembly panel. Drawn after Unity's own header (Editor.finishedDefaultHeaderGUI), so they must stay
    // cheap, restore the GUI state they change, and never ExitGUI (that would skip other tools' headers too).
    // Also the Project window's right-click entries.
    [InitializeOnLoad]
    internal static class InspectorPanels
    {
        private const string DesignateMenu = "Assets/NXYUI/에셋으로 지정";
        private const string ShowMenu = "Assets/NXYUI/Asset Manager에서 보기";
        private const string AssetFold = "NXYUI.AssetManager.Panel.Asset";
        private const string AssemblyFold = "NXYUI.AssetManager.Panel.Assembly";

        private enum Kind { None, Folder, AssetFolder, Prefab }

        private sealed class Target
        {
            internal int Version;
            internal Kind Kind;
            internal string Path, Guid;
            internal AssetRecord Asset;
            internal bool Own;
            internal List<AssetRecord> SharedBy;
        }

        private static readonly Dictionary<int, Target> Targets = new Dictionary<int, Target>();
        private static readonly Dictionary<string, BoothForm> BoothForms = new Dictionary<string, BoothForm>();
        private static readonly Dictionary<string, AssemblyForm> AssemblyForms = new Dictionary<string, AssemblyForm>();
        private static readonly Dictionary<string, (int Version, List<GameObject> Prefabs)> AssetPrefabs = new Dictionary<string, (int, List<GameObject>)>();
        // The editors a panel was drawn in, to repaint when a Booth result or an image arrives.
        private static readonly List<WeakReference<Editor>> Drawn = new List<WeakReference<Editor>>();
        private static bool repaintQueued;

        static InspectorPanels()
        {
            Editor.finishedDefaultHeaderGUI += Draw;
            AssetStore.Changed += RepaintAll;
            AssetStore.ThumbnailsChanged += RepaintAll;
            BoothLinker.Updated += RepaintAll;
        }

        // Repaints the Inspectors that show a panel, once per batch of notices.
        internal static void RepaintAll()
        {
            if (repaintQueued) return;
            repaintQueued = true;
            EditorApplication.delayCall += () =>
            {
                repaintQueued = false;
                Drawn.RemoveAll(w => !w.TryGetTarget(out var e) || !e);
                foreach (var weak in Drawn)
                    if (weak.TryGetTarget(out var editor) && editor) editor.Repaint();
            };
        }

        private static void Remember(Editor editor)
        {
            if (Drawn.Any(w => w.TryGetTarget(out var e) && e == editor)) return;
            Drawn.RemoveAll(w => !w.TryGetTarget(out var e) || !e);
            Drawn.Add(new WeakReference<Editor>(editor));
        }

        private static Target Look(Object target)
        {
            var id = target.GetInstanceID();
            if (Targets.TryGetValue(id, out var known) && known.Version == ProjectVersion) return known;
            var path = AssetDatabase.GetAssetPath(target);
            var found = new Target { Version = ProjectVersion, Kind = Kind.None, Path = path, Guid = AssetDatabase.AssetPathToGUID(path) };
            if (path.StartsWith("Assets/", StringComparison.Ordinal))
            {
                if (target is DefaultAsset && AssetDatabase.IsValidFolder(path))
                {
                    found.Asset = AssetStore.AssetAt(path);
                    found.Kind = found.Asset != null ? Kind.AssetFolder : Kind.Folder;
                    found.Own = found.Asset != null && found.Asset.folders.Contains(found.Guid);
                    found.SharedBy = AssetStore.Project.assets.Where(a => a.sharedFolders.Contains(found.Guid)).ToList();
                }
                else if (target is GameObject go && IsPrefab(go))
                {
                    found.Asset = AssetStore.AssetAt(Path.GetDirectoryName(path)?.Replace('\\', '/') ?? "");
                    if (found.Asset != null) found.Kind = Kind.Prefab;
                }
            }
            Targets[id] = found;
            return found;
        }

        private static bool IsPrefab(GameObject go)
        {
            var type = PrefabUtility.GetPrefabAssetType(go);
            return type == PrefabAssetType.Regular || type == PrefabAssetType.Variant;
        }

        private static void Draw(Editor editor)
        {
            if (editor.targets.Length != 1) return;
            var target = editor.target;
            if (!target || !EditorUtility.IsPersistent(target)) return;
            var found = Look(target);
            if (found.Kind == Kind.None) return;
            Remember(editor);
            var labelWidth = EditorGUIUtility.labelWidth;
            try
            {
                switch (found.Kind)
                {
                    case Kind.Folder: DrawFolderCard(found); break;
                    case Kind.AssetFolder: DrawAssetPanel(found, editor.GetInstanceID()); break;
                    case Kind.Prefab: DrawAssemblyPanel(found, (GameObject)target); break;
                }
            }
            finally { EditorGUIUtility.labelWidth = labelWidth; }
        }

        // A foldout title kept per panel kind; a change waits for the next pass (it adds or removes the panel's body).
        private static bool Fold(string key, string title)
        {
            var open = EditorPrefs.GetBool(key, true);
            var next = EditorGUILayout.Foldout(open, title, true, EditorStyles.foldoutHeader);
            if (next != open) Later(() => EditorPrefs.SetBool(key, next), RepaintAll);
            return open;
        }

        // ‘사용 방법’, first in the asset and the assembly panel: the same steps as the window's bar and README_KO.txt,
        // closed (one line) until the user opens it. Opening or closing waits for the next pass like the panel's own fold
        // (a panel never ends the GUI pass: that would skip the headers other tools draw after it). Nothing in it
        // changes with the tool's state. The assembly panel has no other way to the window, so its list is followed by
        // the button that opens it; the asset panel ends with ‘Asset Manager에서 열기’ already.
        private static void DrawUsage(AssetRecord asset, bool windowButton)
        {
            var open = EditorPrefs.GetBool(AssetManagerUsage.InspectorPref, false);
            var next = EditorGUILayout.Foldout(open, "사용 방법", true);
            if (next != open) Later(() => EditorPrefs.SetBool(AssetManagerUsage.InspectorPref, next), RepaintAll);
            if (!open) return;
            using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
            {
                for (var i = 0; i < AssetManagerUsage.Steps.Length; i++)
                    GUILayout.Label($"{i + 1}. {AssetManagerUsage.Steps[i]}", EditorStyles.wordWrappedLabel);
                var more = new GUIContent(AssetManagerUsage.MoreButton, AssetManagerUsage.Url);
                var note = new GUIContent(AssetManagerUsage.ReadmeNote);
                // The button and the line share a row when the Inspector is wide enough, else the line goes under it.
                // The width of the view is the same in Layout and Repaint, so both passes draw the same controls.
                var oneRow = EditorStyles.miniButton.CalcSize(more).x + EditorStyles.miniLabel.CalcSize(note).x + 60 <= EditorGUIUtility.currentViewWidth;
                using (new EditorGUILayout.HorizontalScope())
                {
                    if (GUILayout.Button(more, EditorStyles.miniButton, GUILayout.ExpandWidth(false))) Application.OpenURL(AssetManagerUsage.Url);
                    if (oneRow) GUILayout.Label(note, EditorStyles.miniLabel);
                    GUILayout.FlexibleSpace();
                }
                if (!oneRow) GUILayout.Label(note, EditorStyles.miniLabel);
            }
            if (!windowButton) return;
            using (new EditorGUILayout.HorizontalScope())
            {
                GUILayout.FlexibleSpace();
                if (GUILayout.Button(new GUIContent("Asset Manager에서 열기", "창의 에셋 탭에서 이 에셋을 열어요."), EditorStyles.miniButton))
                    Later(() => AssetManagerWindow.ShowAsset(asset), null);
            }
            GUILayout.Space(4);
        }

        // ---- A folder no asset owns ----

        private static void DrawFolderCard(Target found)
        {
            using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
            {
                if (found.SharedBy.Count > 0)
                {
                    GUILayout.Label("Asset Manager · 공용 폴더: " + string.Join(", ", found.SharedBy.Select(a => a.name)), EditorStyles.wordWrappedMiniLabel);
                    return;
                }
                var problem = AssetFolders.Problem(found.Path);
                using (new EditorGUILayout.HorizontalScope())
                {
                    GUILayout.Label("Asset Manager: 에셋으로 지정하지 않은 폴더예요.", EditorStyles.wordWrappedMiniLabel);
                    using (new EditorGUI.DisabledScope(problem != null))
                        if (GUILayout.Button(new GUIContent("에셋으로 지정", problem ?? "이 폴더를 상품 하나로 등록해요."), EditorStyles.miniButton, GUILayout.Width(90)))
                        {
                            var path = found.Path;
                            Later(() => Designate(new[] { path }), RepaintAll);
                        }
                }
                if (problem != null) GUILayout.Label(problem, EditorStyles.wordWrappedMiniLabel);
            }
        }

        // ---- An asset's folder ----

        // view: the editor the Inspector draws this folder with. The Inspector makes a new one when it shows something
        // else, so a choice of another Booth product begun here ends when the user moves on, and stays while they don't
        // (a locked Inspector too).
        private static void DrawAssetPanel(Target found, int view)
        {
            var asset = found.Asset;
            using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
            {
                if (!Fold(AssetFold, "Asset Manager · " + asset.name)) return;
                DrawUsage(asset, false);
                using (new EditorGUILayout.HorizontalScope())
                {
                    DrawThumbnail(AssetTexture(asset, RepaintAll), 40, KindName(asset.kind));
                    using (new EditorGUILayout.VerticalScope())
                    {
                        ClippedLabel(asset.name, EditorStyles.boldLabel);
                        using (new EditorGUILayout.HorizontalScope())
                        {
                            DrawBadge(KindName(asset.kind));
                            if (asset.boothId > 0) DrawBadge("Booth", "good", "Booth 상품과 연결됨");
                            // Marked as not from Booth: that is a settled state, not something still to do.
                            else if (asset.noBooth) DrawBadge("Booth 아님", "", "Booth에서 산 것이 아니라고 표시한 에셋");
                            else DrawBadge("미연결", "warn", "Booth 상품과 아직 연결하지 않음");
                            GUILayout.FlexibleSpace();
                        }
                        var (bytes, files) = AssetFolders.Size(asset);
                        var shop = AssetStore.Item(asset.boothId)?.shop ?? "";
                        ClippedLabel((shop.Length > 0 ? shop + " · " : "") + $"{AssetFolders.FormatSize(bytes)} · 파일 {files}개", EditorStyles.miniLabel);
                    }
                }
                if (!found.Own) GUILayout.Label($"‘{asset.name}’ 에셋의 폴더 안이에요.", EditorStyles.wordWrappedMiniLabel);

                GUILayout.Space(4);
                if (!BoothForms.TryGetValue(asset.id, out var booth)) BoothForms[asset.id] = booth = new BoothForm();
                booth.Draw(asset, true, RepaintAll, view);

                GUILayout.Space(4);
                var prefabs = PrefabsOf(asset);
                GUILayout.Label(prefabs.Count == 0 ? "프리팹이 없어요." : $"프리팹 {prefabs.Count}개 · 누르면 조립 패널이 열려요", EditorStyles.miniBoldLabel);
                foreach (var prefab in prefabs.Take(5))
                    if (GUILayout.Button(new GUIContent(Fit(AssemblyForm.PrefabLabel(asset, prefab), EditorStyles.miniButtonLeft, EditorGUIUtility.currentViewWidth - 60),
                            AssetDatabase.GetAssetPath(prefab)), EditorStyles.miniButtonLeft))
                    {
                        var chosen = prefab;
                        Later(() =>
                        {
                            Selection.activeObject = chosen;
                            EditorGUIUtility.PingObject(chosen);
                        }, RepaintAll);
                    }
                if (prefabs.Count > 5) GUILayout.Label($"외 {prefabs.Count - 5}개는 Asset Manager 창에서 볼 수 있어요.", EditorStyles.miniLabel);

                using (new EditorGUILayout.HorizontalScope())
                {
                    GUILayout.FlexibleSpace();
                    if (GUILayout.Button("Asset Manager에서 열기", EditorStyles.miniButton)) Later(() => AssetManagerWindow.ShowAsset(asset), null);
                }
            }
        }

        private static List<GameObject> PrefabsOf(AssetRecord asset)
        {
            if (AssetPrefabs.TryGetValue(asset.id, out var known) && known.Version == ProjectVersion && known.Prefabs.All(p => p)) return known.Prefabs;
            var prefabs = AssetFolders.Prefabs(asset).OrderBy(p => AssetDatabase.GetAssetPath(p).Count(c => c == '/'))
                .ThenBy(p => p.name, StringComparer.OrdinalIgnoreCase).ToList();
            AssetPrefabs[asset.id] = (ProjectVersion, prefabs);
            return prefabs;
        }

        // ---- A prefab inside an asset ----

        private static void DrawAssemblyPanel(Target found, GameObject prefab)
        {
            var asset = found.Asset;
            using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
            {
                if (!Fold(AssemblyFold, "Asset Manager · 조립")) return;
                DrawUsage(asset, true);
                using (new EditorGUILayout.HorizontalScope())
                {
                    DrawThumbnail(AssetTexture(asset, RepaintAll), 32, KindName(asset.kind));
                    using (new EditorGUILayout.VerticalScope())
                    {
                        ClippedLabel(asset.name, EditorStyles.boldLabel);
                        ClippedLabel("› " + prefab.name, EditorStyles.miniLabel);
                    }
                }
                if (!AssemblyForms.TryGetValue(found.Guid, out var form)) AssemblyForms[found.Guid] = form = AssemblyForm.Load(found.Guid, asset, prefab);
                var guid = found.Guid;
                form.Draw(asset, prefab, true, RepaintAll, () => form.Save(guid));
            }
        }

        // ---- The Project window's right-click entries ----

        private static string[] SelectedFolders() =>
            Selection.assetGUIDs.Select(AssetDatabase.GUIDToAssetPath).Where(AssetDatabase.IsValidFolder).Distinct().ToArray();

        [MenuItem(DesignateMenu, false, 1100)]
        private static void DesignateSelected() => Designate(SelectedFolders());

        [MenuItem(DesignateMenu, true)]
        private static bool CanDesignate()
        {
            var folders = SelectedFolders();
            return folders.Length > 0 && folders.All(f => AssetFolders.Problem(f) == null);
        }

        [MenuItem(ShowMenu, false, 1101)]
        private static void ShowSelected()
        {
            var folder = SelectedFolders().FirstOrDefault();
            if (folder != null) AssetManagerWindow.ShowAsset(AssetStore.AssetAt(folder));
        }

        [MenuItem(ShowMenu, true)]
        private static bool CanShow() => SelectedFolders().Any(f => AssetStore.AssetAt(f) != null);

        private static void Designate(string[] folders)
        {
            if (folders.Length == 0) return;
            try
            {
                if (folders.Length == 1)
                {
                    Created(AssetFolders.Create(folders, Path.GetFileName(folders[0])));
                    return;
                }
                var choice = EditorUtility.DisplayDialogComplex("에셋으로 지정",
                    $"고른 폴더 {folders.Length}개를 어떻게 지정할까요?\n한 상품이 여러 폴더에 걸쳐 있으면 ‘하나로 묶기’를 고르세요.",
                    "하나로 묶기", "취소", "폴더마다 따로");
                if (choice == 0) Created(AssetFolders.Create(folders, Path.GetFileName(folders[0])));
                else if (choice == 2)
                    foreach (var folder in folders) Created(AssetFolders.Create(new[] { folder }, Path.GetFileName(folder)));
            }
            catch (InvalidOperationException e)
            {
                EditorUtility.DisplayDialog("에셋으로 지정", "지정하지 못했어요: " + e.Message, "확인");
            }
        }

        // A new asset starts looking for its Booth product; the Inspector shows its panel at once (no window opens).
        private static void Created(AssetRecord asset)
        {
            BoothLinker.SearchOnce(asset.id, asset.name, AssetFolders.ExistingFolders(asset), asset.package);
            Targets.Clear();
            RepaintAll();
        }
    }
}
