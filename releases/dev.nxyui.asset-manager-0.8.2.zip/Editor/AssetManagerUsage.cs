namespace NXYUI.AssetManager
{
    // How the tool is used, written once: the window's ‘사용 방법’ bar and the Inspector panels show this list, the
    // package's README_KO.txt has it word for word under "사용 방법", and the public guide at Url walks through the same
    // steps in the same order with the details (design-system/unityvpm/MASTER.md, "Usage guide").
    internal static class AssetManagerUsage
    {
        internal const string Url = "https://github.com/NXYUI/UnityVPM-pages/blob/main/packages/dev.nxyui.asset-manager/README.md";

        internal static readonly string[] Steps =
        {
            "상단 메뉴 ‘NXYUI › Asset Manager’로 이 창을 열어요. 인스펙터가 열려 있으면 그 옆 탭으로 붙어요.",
            "‘폴더 지정’ 탭에서 상품 폴더를 체크하고 아래 막대의 ‘각각 에셋으로 만들기 (n)’를 눌러요. 한 상품이 여러 폴더에 나뉘어 있으면 ‘에셋 이름’을 적고 ‘하나로 묶기’를 눌러요.",
            "‘에셋’ 탭에서 카드를 누르면 상세가 열려요. ‘Booth’에서 맞는 후보의 ‘연결’을 직접 눌러 연결해요. 연결할 에셋이 많으면 위의 ‘Booth 연결 (n)’로 하나씩 연결해요.",
            "상세의 ‘조립’에서 아바타, 넣을 위치, ‘옷 입히기’나 ‘뼈에 붙이기’를 고르고 ‘조립’을 눌러요. Modular Avatar 설정으로 들어가고, 업로드할 때 아바타에 합쳐져요.",
            "새 패키지는 ‘가져오기’ 탭에서 ‘패키지 폴더’를 고르고 ‘폴더 읽기’를 눌러요. 가져올 줄을 누르고 ‘임포트 (n개)’를 누르면 차례로 가져오고, 새 폴더는 ‘폴더 지정’에 후보로 올라와요.",
            "창을 열지 않아도 돼요. Project 창에서 에셋 폴더를 고르면 인스펙터 맨 위에 Booth 연결이, 에셋 안의 프리팹을 고르면 조립 칸이 나와요.",
            "조립은 Ctrl+Z 한 번으로 되돌려요. ‘에셋 목록에서 빼기’는 에셋 지정만 풀고 파일은 지우지 않아요.",
        };

        // The words under the list, and its button.
        internal const string MoreButton = "자세한 설명 열기";
        internal const string ReadmeNote = "패키지 폴더의 README_KO.txt에도 있어요.";

        // Closed until the user opens it (the owner: the details stay out of sight until unfolded); the choice is kept per
        // surface (EditorPrefs of this computer).
        internal const string WindowPref = "NXYUI.AssetManager.Usage.Window";
        internal const string InspectorPref = "NXYUI.AssetManager.Usage.Inspector";
    }
}
