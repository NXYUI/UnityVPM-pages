using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;
using VRC.SDK3.Avatars.Components;

namespace PersonalPoseDeck
{
    internal sealed partial class PoseDeckPoseBrowser : EditorWindow
    {
        private static readonly string[] TypeOptions = { "Humanoid", "전체", "Generic / Legacy" };
        private static readonly string[] SourceOptions = { "모든 위치", "Assets", "Packages" };
        private static readonly HashSet<string> ModelExtensions = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        { ".fbx", ".dae", ".blend", ".ma", ".mb", ".3ds", ".dxf", ".gltf", ".glb", ".bvh" };

        private sealed class Item
        {
            public AnimationClip Clip;
            public string Name, Path, GroupRoot;
            public bool Humanoid;
            public ulong AvatarMask;
        }

        [SerializeField] private PoseDeckPreset preset;
        [SerializeField] private GameObject avatar;
        [SerializeField] private string search = "";
        [SerializeField] private int sourceFilter, typeFilter, category;
        [SerializeField] private bool assemblePreview = true;
        private PoseDeckAssemblyPreview assembled;
        private bool assemblyPending = true;
        private const string InvertCameraPreference = "PersonalPoseDeck.InvertRightDragVertical";
        private bool invertRightDragVertical;
        private string assemblyError;
        private GameObject PreviewRoot => !avatar || (assemblePreview && assemblyPending) ? null : assembled?.Root ?? avatar;
        private readonly List<Item> index = new List<Item>();
        private readonly List<Item> filtered = new List<Item>();
        private readonly HashSet<AnimationClip> queued = new HashSet<AnimationClip>();
        private string[] pending;
        private int cursor, skippedPaths;
        private bool startScan, scanStale, refreshFilter = true;
        private Item active;
        private PoseDeckPosePreview renderer;
        private AnimationClip framedClip;
        private bool previewNeedsBuild, playing, sampleDirty;
        private float time;
        private double lastPlayback;
        private string message, previewError;

        private static GameObject FindAvatar(GameObject target)
        {
            if (!target) return null;
            var descriptor = target.GetComponentInParent<VRCAvatarDescriptor>(true);
            if (descriptor) return descriptor.gameObject;
            var animator = target.GetComponentInParent<Animator>(true);
            return animator ? animator.gameObject : target;
        }

        private void ResetPreview()
        {
            ClearThumbnails();
            renderer?.Dispose();
            renderer = null;
            framedClip = null;
            assembled?.Dispose();
            assembled = null;
            assemblyPending = assemblePreview;
            assemblyError = null;
            previewError = null;
            previewNeedsBuild = true;
            sampleDirty = true;
            playing = false;
        }

        private void ChangeAvatar(GameObject next)
        {
            if (next == avatar) return;
            avatar = next;
            refreshFilter = true;
            if (!target || !avatar || !target.transform.IsChildOf(avatar.transform)) target = FindDeckTarget(avatar);
            ResetPreview();
            LoadAppliedPreset();
        }

        private void TickAssembly()
        {
            if (!assemblePreview || !assemblyPending || !avatar || EditorApplication.isUpdating) return;
            assemblyPending = false;
            try { assembled = new PoseDeckAssemblyPreview(avatar); }
            catch (Exception e) { assemblyError = e.Message; }
            Repaint();
        }

        private static bool IsProjectPath(string path) => path.StartsWith("Assets/", StringComparison.Ordinal) ||
                                                          path.StartsWith("Packages/", StringComparison.Ordinal);

        private void StartIndex()
        {
            startScan = false;
            scanStale = false;
            index.Clear();
            cursor = skippedPaths = 0;
            galleryScroll = Vector2.zero;
            ClearThumbnails();
            refreshFilter = true;
            var paths = new HashSet<string>(StringComparer.Ordinal);
            foreach (var guid in AssetDatabase.FindAssets("t:AnimationClip"))
            {
                var path = AssetDatabase.GUIDToAssetPath(guid);
                if (IsProjectPath(path)) paths.Add(path);
            }
            // Model subassets are not always returned individually by a type search.
            foreach (var path in AssetDatabase.GetAllAssetPaths())
                if (IsProjectPath(path) && (path.EndsWith(".anim", StringComparison.OrdinalIgnoreCase) ||
                                           ModelExtensions.Contains(Path.GetExtension(path)))) paths.Add(path);
            pending = paths.OrderBy(x => x, StringComparer.OrdinalIgnoreCase).ToArray();
        }

        private void IndexStep()
        {
            var end = EditorApplication.timeSinceStartup + .012;
            int count = 0;
            while (cursor < pending.Length && count++ < 80 && (count == 1 || EditorApplication.timeSinceStartup < end))
            {
                string path = pending[cursor++];
                try
                {
                    bool anim = path.EndsWith(".anim", StringComparison.OrdinalIgnoreCase);
                    // Loading a model brings in its meshes and materials too; skip models that import no animation.
                    if (!anim && AssetImporter.GetAtPath(path) is ModelImporter model && !model.importAnimation) continue;
                    var assets = anim
                        ? new UnityEngine.Object[] { AssetDatabase.LoadAssetAtPath<AnimationClip>(path) }
                        : AssetDatabase.LoadAllAssetsAtPath(path);
                    foreach (var clip in assets.OfType<AnimationClip>())
                    {
                        if (!clip || clip.name.StartsWith("__preview__", StringComparison.OrdinalIgnoreCase)) continue;
                        index.Add(new Item
                        {
                            Clip = clip, Name = clip.name, Path = path,
                            Humanoid = clip.humanMotion && !clip.legacy,
                            AvatarMask = DetectAvatarAliases(clip.name + " " + path),
                            GroupRoot = GroupRootFor(path)
                        });
                    }
                }
                catch (Exception) { skippedPaths++; }
            }
            if (cursor >= pending.Length)
            {
                index.Sort((a, b) =>
                {
                    int c = StringComparer.OrdinalIgnoreCase.Compare(a.Name, b.Name);
                    return c != 0 ? c : StringComparer.OrdinalIgnoreCase.Compare(a.Path, b.Path);
                });
                if (active != null) active = index.FirstOrDefault(i => i.Clip == active.Clip);
                queued.RemoveWhere(c => !c || !index.Any(i => i.Clip == c));
                pending = null;
                // Release the meshes and textures loaded with the models. Clips held by the index stay loaded.
                EditorUtility.UnloadUnusedAssetsImmediate(true);
            }
            refreshFilter = true;
            Repaint();
        }

        private bool rendererIsReady => renderer != null && previewError == null;

        private void Filter()
        {
            refreshFilter = false;
            var terms = (search ?? "").Split(new[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries);
            var mask = SelectedAvatarMask();
            PreparePoseRegex();
            filtered.Clear();
            foreach (var item in index)
            {
                if (!item.Clip || (typeFilter == 0 && !item.Humanoid) || (typeFilter == 2 && item.Humanoid)) continue;
                if (sourceFilter == 1 && !item.Path.StartsWith("Assets/", StringComparison.Ordinal)) continue;
                if (sourceFilter == 2 && !item.Path.StartsWith("Packages/", StringComparison.Ordinal)) continue;
                if (!string.IsNullOrEmpty(folderFilter) && item.GroupRoot != folderFilter) continue;
                if (!MatchesAvatarMode(item, mask)) continue;
                if (!terms.All(t => item.Name.IndexOf(t, StringComparison.OrdinalIgnoreCase) >= 0 ||
                                    item.Path.IndexOf(t, StringComparison.OrdinalIgnoreCase) >= 0)) continue;
                filtered.Add(item);
            }
            if (usePoseRegex && poseRegex != null)
            {
                try { var matched = filtered.Where(MatchesPoseRegex).ToArray(); filtered.Clear(); filtered.AddRange(matched); }
                catch (System.Text.RegularExpressions.RegexMatchTimeoutException)
                { poseRegex = null; poseRegexError = "정규식 검색이 너무 오래 걸려 중단했어요."; }
            }
            RebuildGalleryGroups();
        }

        private void Select(Item item)
        {
            if (active == item) return;
            active = item;
            time = 0;
            playing = false;
            sampleDirty = true;
            if (previewError != null)
            {
                renderer?.Dispose();
                renderer = null;
                framedClip = null;
                previewError = null;
                previewNeedsBuild = true;
            }
            SyncDeckSelection();
        }

        private void AddToPreset(IEnumerable<Item> items)
        {
            var known = new HashSet<AnimationClip>(preset.poses.Select(p => p.clip));
            var added = items.Where(i => i != null && i.Clip && i.Humanoid && known.Add(i.Clip)).ToArray();
            if (added.Length == 0) { message = "추가할 새 Humanoid 클립이 없어요."; return; }
            Undo.RecordObject(preset, "Add poses from Pose Browser");
            selectedPose = preset.poses.Count;
            foreach (var item in added)
            {
                preset.poses.Add(new PoseEntry { label = item.Name, clip = item.Clip, category = (PoseCategory)category });
                queued.Remove(item.Clip);
            }
            EditorUtility.SetDirty(preset);
            AssetDatabase.SaveAssetIfDirty(preset);
            message = $"{added.Length}개 추가했어요. Personal Pose Deck에서 생성 및 적용을 눌러 메뉴를 갱신하세요.";
        }

    }
}
