#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using UnityEngine;

namespace NXYUI.AIExpression
{
    // The two ways the window asks Claude through the API. Light: one request, the answer is ids and values as JSON
    // (structured output). Direct edit: Claude sets shapes and looks at the face through two tools until it is satisfied,
    // within a number of rounds and tokens, and can be stopped. Every edit is one Undo step.
    internal static class ExpressionAgent
    {
        internal sealed class Usage
        {
            internal int Input, Output, CacheRead, CacheWrite, Calls;
            internal int Total => Input + Output + CacheRead + CacheWrite;

            internal void Add(JObject response)
            {
                var u = response["usage"];
                Input += (int?)u?["input_tokens"] ?? 0;
                Output += (int?)u?["output_tokens"] ?? 0;
                CacheRead += (int?)u?["cache_read_input_tokens"] ?? 0;
                CacheWrite += (int?)u?["cache_creation_input_tokens"] ?? 0;
                Calls++;
            }

            public override string ToString() =>
                $"입력 {Input:N0} · 캐시 읽기 {CacheRead:N0} · 캐시 쓰기 {CacheWrite:N0} · 출력 {Output:N0} (요청 {Calls}번)";
        }

        internal static bool Running { get; private set; }
        internal static string Status { get; private set; } = "";
        internal static bool Failed { get; private set; }
        // This run's tokens, and all runs' since the editor started.
        internal static Usage Run = new Usage(), All = new Usage();
        private static bool stop;
        internal static event Action Changed;

        private static void Say(string status, bool failed = false)
        {
            Status = status;
            Failed = failed;
            Changed?.Invoke();
        }

        internal static void Stop()
        {
            stop = true;
            ClaudeApi.Abort();
        }

        private static JObject Schema(JObject properties, params string[] required) => new JObject
        {
            ["type"] = "object", ["properties"] = properties, ["required"] = new JArray(required), ["additionalProperties"] = false,
        };

        private static JObject ChangesSchema() => Schema(new JObject
        {
            ["changes"] = new JObject
            {
                ["type"] = "array",
                ["items"] = Schema(new JObject { ["id"] = new JObject { ["type"] = "integer" }, ["value"] = new JObject { ["type"] = "number" } }, "id", "value"),
            },
            ["reset_others"] = new JObject { ["type"] = "boolean" },
        }, "changes", "reset_others");

        // More changes than any face has shapes: refused before anything reaches the main thread.
        internal const int MaxChanges = 1000;

        // Reads changes from an answer or a tool input; null (and what is wrong) when they are not there or not well
        // formed. The JSON types are taken as they are: a conversion would read 1.5 or "3" as some id and move a shape
        // nobody chose, and "true" or 1 as reset_others.
        internal static List<(int Id, float Value)> Changes(JToken input, out bool reset, out string problem)
        {
            reset = false;
            problem = "changes must be a list of {id, value}.";
            var flag = input?["reset_others"];
            if (flag != null && flag.Type != JTokenType.Null)
            {
                if (flag.Type != JTokenType.Boolean) { problem = "reset_others must be true or false."; return null; }
                reset = (bool)flag;
            }
            if (!(input?["changes"] is JArray array)) return null;
            if (array.Count > MaxChanges) { problem = $"At most {MaxChanges} changes at a time."; return null; }
            var list = new List<(int, float)>();
            foreach (var c in array)
            {
                // An integer too large for a long arrives as a BigInteger, and is no id either.
                if (!(c is JObject item) || !(item["id"] is JValue id) || id.Type != JTokenType.Integer || !(id.Value is long whole)) return null;
                double number;
                switch (item["value"] is JValue value ? value.Value : null)
                {
                    case long l: number = l; break;
                    case double d: number = d; break;
                    case decimal m: number = (double)m; break;
                    default: return null;
                }
                if (whole < 0 || whole > int.MaxValue) { problem = $"{whole} is not an id of the face dictionary."; return null; }
                if (double.IsNaN(number) || double.IsInfinity(number) || number < 0 || number > 100)
                {
                    problem = $"The value for id {whole} must be from 0 to 100.";
                    return null;
                }
                list.Add(((int)whole, (float)number));
            }
            problem = null;
            return list;
        }

        private static JObject User(string text) => new JObject { ["role"] = "user", ["content"] = text };

        private static string Ask(string request) => $"Current values (others are 0): {ExpressionCore.CurrentValues()}\nRequest: {request}";

        private static bool Refused(JObject response)
        {
            if ((string)response["stop_reason"] != "refusal") return false;
            string category = (string)response["stop_details"]?["category"];
            Say("Claude가 이 요청을 거절했어요" + (category != null ? $" ({category})" : "") + ". 표현을 바꿔 다시 해 주세요.", true);
            return true;
        }

        // ---- light ---------------------------------------------------------------------------------------------

        internal static async void RunLight(ClaudeApi.Model model, string effort, string request)
        {
            if (Running) return;
            Begin();
            try
            {
                // The answer's ids are for the dictionary sent now: the avatar can be changed while the answer is awaited.
                string version = ExpressionCore.EnsureDictionary().Version;
                string system = ExpressionCore.Instructions() +
                                "\nAnswer with the changes for the user's request: ids and values. Set reset_others to true when the request is a new " +
                                "expression rather than a change to the current one. note: one short sentence in the user's language.";
                var properties = (JObject)ChangesSchema()["properties"];
                properties["note"] = new JObject { ["type"] = "string" };
                var schema = Schema(properties, "changes", "reset_others", "note");
                JObject format = null;
                if (model.structured) format = new JObject { ["type"] = "json_schema", ["schema"] = schema };
                else system += "\nReply with only this JSON and nothing else: " + schema.ToString(Formatting.None);
                Say("Claude에게 묻는 중이에요…");
                var response = await ClaudeApi.Messages(model, effort, system, new JArray(User(Ask(request))), null, format);
                Count(response);
                if (Refused(response)) return;
                if ((string)response["stop_reason"] == "max_tokens") { Say("답이 너무 길어 잘렸어요. 다시 해 주세요.", true); return; }
                string text = ClaudeApi.Text(response);
                var answer = Answer(text);
                var changes = Changes(answer, out bool reset, out _);
                if (changes == null) { Say("답을 읽지 못했어요: " + Shorten(text), true); return; }
                ExpressionCore.Apply(changes, reset, "API", version);
                Say($"{(string)answer["note"]} · {Run}");
            }
            catch (Exception e) { Fail(e); }
            finally { End(); }
        }

        // The JSON object with the changes in an answer. A model without structured output may write around it, braces
        // included ("{id, value} pairs: {...}"), so each "{" is tried as the start until one reads as that object.
        internal static JObject Answer(string text)
        {
            text = text ?? "";
            for (int start = text.IndexOf('{'); start >= 0; start = text.IndexOf('{', start + 1))
            {
                try
                {
                    // Reads one object and stops: what follows it is not looked at.
                    using (var reader = new JsonTextReader(new System.IO.StringReader(text.Substring(start))))
                    {
                        var candidate = JObject.Load(reader);
                        if (candidate["changes"] is JArray) return candidate;
                    }
                }
                catch (JsonException) { }
            }
            return null;
        }

        // ---- direct edit ---------------------------------------------------------------------------------------

        internal static async void RunDirect(ClaudeApi.Model model, string effort, string request, int maxRounds, int maxTokens)
        {
            if (Running) return;
            if (!model.image) { Say("직접 편집은 이미지를 볼 수 있는 모델만 돼요.", true); return; }
            Begin();
            try
            {
                // Every tool call of this run is for the dictionary sent now (see Execute).
                string version = ExpressionCore.EnsureDictionary().Version;
                string system = ExpressionCore.Instructions() +
                                "\nMake the face match the user's request. Use set_shapekeys to change it and capture_face to look at it, and repeat until " +
                                "it looks right; then answer with one short sentence in the user's language. Pictures cost tokens: look only when it helps.";
                var setShapes = new JObject
                {
                    ["name"] = "set_shapekeys",
                    ["description"] = "Set face blendshape weights by dictionary id, 0 to 100. reset_others true first puts every other face shape back to the avatar's default face. Returns the values now.",
                    ["input_schema"] = ChangesSchema(),
                };
                var capture = new JObject
                {
                    ["name"] = "capture_face",
                    ["description"] = "Take a front picture of the avatar's face as it is now.",
                    ["input_schema"] = Schema(new JObject()),
                };
                if (model.structured)
                {
                    setShapes["strict"] = true;
                    capture["strict"] = true;
                }
                var tools = new JArray(setShapes, capture);
                var messages = new JArray(User(Ask(request)));
                // Each request reads the whole conversation again, so the next one costs at least what the last one read and
                // wrote, plus a picture. The first is guessed from its text (about two bytes of UTF-8 a token for the
                // dictionary's short fields), so a dictionary larger than the limit is not sent at all.
                int next = Guess(system, messages, tools);
                for (int round = 1; ; round++)
                {
                    if (stop) { Say($"멈췄어요. · {Run}"); return; }
                    if (round > maxRounds) { Say($"반복 한도({maxRounds}번)에 닿아 멈췄어요. · {Run}"); return; }
                    if (round == 1 && next >= maxTokens)
                    {
                        Say($"얼굴 사전만으로도 토큰 한도({maxTokens:N0})를 넘을 것 같아(약 {next:N0}) 보내지 않았어요. ‘최대 토큰’을 늘리거나 ‘가볍게’로 해 주세요.", true);
                        return;
                    }
                    if (Run.Total + next >= maxTokens) { Say($"다음 요청이 토큰 한도({maxTokens:N0})를 넘을 것 같아 멈췄어요. · {Run}"); return; }
                    var before = (Run.Input + Run.CacheRead + Run.CacheWrite, Run.Output);
                    Say($"Claude가 고치는 중이에요 ({round}번째)…");
                    var response = await ClaudeApi.Messages(model, effort, system, messages, tools);
                    Count(response);
                    if (Refused(response)) return;
                    // Over the limit: nothing more runs, not even the tools this answer asks for.
                    if (Run.Total >= maxTokens) { Say($"토큰 한도({maxTokens:N0})에 닿아 멈췄어요. · {Run}"); return; }
                    next = Run.Input + Run.CacheRead + Run.CacheWrite - before.Item1 + Run.Output - before.Item2 + 1500;
                    // Its whole answer goes back as it came (thinking blocks included).
                    messages.Add(new JObject { ["role"] = "assistant", ["content"] = response["content"] });
                    string reason = (string)response["stop_reason"];
                    if (reason != "tool_use")
                    {
                        Say(reason == "max_tokens" ? "답이 너무 길어 잘렸어요." : $"{Shorten(ClaudeApi.Text(response))} · {Run}", reason == "max_tokens");
                        return;
                    }
                    var results = new JArray();
                    foreach (var block in response["content"].Where(b => (string)b["type"] == "tool_use"))
                        results.Add(Execute(block, version));
                    messages.Add(new JObject { ["role"] = "user", ["content"] = results });
                }
            }
            catch (Exception e) { Fail(e); }
            finally { End(); }
        }

        // A rough count of the tokens the first request reads and writes, before anything is sent: no request is made to
        // count them. Output: what an answer that edits and looks usually takes.
        internal static int Guess(string system, JArray messages, JArray tools) =>
            (System.Text.Encoding.UTF8.GetByteCount(system) + System.Text.Encoding.UTF8.GetByteCount(messages.ToString(Formatting.None)) +
             System.Text.Encoding.UTF8.GetByteCount(tools.ToString(Formatting.None))) / 2 + 1500;

        private static JObject Execute(JToken block, string version)
        {
            // Not a tool error Claude could work around: the avatar or the dictionary changed under the run (the user
            // ended the work and chose another avatar), so the run stops before it edits or photographs the other face.
            ExpressionCore.Expect(version);
            var result = new JObject { ["type"] = "tool_result", ["tool_use_id"] = (string)block["id"] };
            try
            {
                switch ((string)block["name"])
                {
                    case "set_shapekeys":
                        var changes = Changes(block["input"], out bool reset, out string problem);
                        if (changes == null) throw new ArgumentException(problem);
                        result["content"] = ExpressionCore.Apply(changes, reset, "API", version);
                        break;
                    case "capture_face":
                        var png = ExpressionCore.Capture("API");
                        result["content"] = new JArray(new JObject
                        {
                            ["type"] = "image",
                            ["source"] = new JObject { ["type"] = "base64", ["media_type"] = "image/png", ["data"] = Convert.ToBase64String(png) },
                        });
                        break;
                    default:
                        throw new ArgumentException("Unknown tool.");
                }
            }
            catch (Exception e)
            {
                result["content"] = e.Message;
                result["is_error"] = true;
            }
            return result;
        }

        // ---- shared --------------------------------------------------------------------------------------------

        private static void Begin()
        {
            Running = true;
            stop = false;
            ClaudeApi.ResetAbort();
            Run = new Usage();
            Changed?.Invoke();
        }

        private static void End()
        {
            Running = false;
            Changed?.Invoke();
        }

        private static void Count(JObject response)
        {
            Run.Add(response);
            All.Add(response);
        }

        private static void Fail(Exception e)
        {
            if (!(e is ClaudeApi.ApiException) && !(e is InvalidOperationException)) Debug.LogException(e);
            // Its own message is written for an MCP client.
            Say(e is ExpressionCore.StaleDictionaryException
                ? "요청을 보낸 뒤에 아바타나 얼굴 사전이 바뀌어서, 더 고치지 않고 멈췄어요. 다시 보내 주세요."
                : e is ExpressionCore.UnknownIdsException
                    ? "Claude의 답에 얼굴 사전에 없는 번호가 있어서 아무것도 바꾸지 않았어요. 다시 보내 주세요."
                    : e.Message, true);
        }

        private static string Shorten(string text)
        {
            text = (text ?? "").Trim();
            return text.Length > 300 ? text.Substring(0, 300) + "…" : text;
        }
    }
}
#endif
