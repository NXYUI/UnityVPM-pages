#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using VRC.SDK3.Avatars.Components;
using Object = UnityEngine.Object;

namespace NXYUI.AIExpression
{
    // One expression being made. With copies (the default) each face mesh gets an EditorOnly working copy beside it, the
    // original is hidden in the Scene view only (its state is not changed), and AI edits go to the copy. Without copies
    // the edits go to the originals, each one an Undo step. The weights at the start are the baseline: "reset" goes back
    // to it, and the saved clip holds what differs from it.
    internal sealed class WorkSession
    {
        internal const string CopyPrefix = "[AI 작업본] ";

        internal VRCAvatarDescriptor Avatar;
        internal bool Cloned;
        // Each face mesh and the mesh the edits go to (itself without copies).
        internal readonly Dictionary<SkinnedMeshRenderer, SkinnedMeshRenderer> Working = new Dictionary<SkinnedMeshRenderer, SkinnedMeshRenderer>();
        private readonly Dictionary<(SkinnedMeshRenderer, int), float> baseline = new Dictionary<(SkinnedMeshRenderer, int), float>();
        // Each face mesh's mesh at the start: shape indices are only good for it.
        private readonly Dictionary<SkinnedMeshRenderer, Mesh> meshes = new Dictionary<SkinnedMeshRenderer, Mesh>();
        // The originals this session hid. One the user had hidden before is left hidden at the end.
        private readonly HashSet<SkinnedMeshRenderer> hid = new HashSet<SkinnedMeshRenderer>();

        internal IEnumerable<SkinnedMeshRenderer> Originals => Working.Keys;

        // The copies are still there (Undo or the user can remove them) and the meshes are the ones it started with.
        internal bool Valid => Avatar && Working.All(p => p.Key && p.Value &&
            meshes.TryGetValue(p.Key, out var mesh) && p.Key.sharedMesh == mesh && p.Value.sharedMesh == mesh);

        // The copies by instance id: Undo brings a destroyed object back under the id it had.
        internal IEnumerable<int> CopyIds =>
            Cloned ? Working.Values.Where(w => !ReferenceEquals(w, null)).Select(w => w.GetInstanceID()) : Enumerable.Empty<int>();

        internal static WorkSession Start(FaceDictionary dictionary, bool copies)
        {
            var session = new WorkSession { Avatar = dictionary.Avatar, Cloned = copies };
            session.Cover(dictionary);
            return session;
        }

        // Gives every face mesh of the dictionary its working mesh, as one Undo step; false when none was missing. A
        // session found again in the scene can lack one (its copy was deleted), and edits to that mesh would be lost.
        internal bool Cover(FaceDictionary dictionary)
        {
            var missing = dictionary.Renderers.Where(r => !Working.ContainsKey(r)).ToList();
            if (missing.Count == 0) return false;
            // Its own step: called from MCP or after an API answer there is no click that opened one, and the copies
            // would join whatever the user did last (one Ctrl+Z would then take both back).
            Undo.IncrementCurrentGroup();
            Undo.SetCurrentGroupName("AI Expression: start");
            int group = Undo.GetCurrentGroup();
            foreach (var original in missing)
            {
                if (!Cloned)
                {
                    Working[original] = original;
                    Remember(original, null);
                    continue;
                }
                var copy = Copy(original, Avatar.transform);
                Working[original] = copy.GetComponent<SkinnedMeshRenderer>();
                Remember(original, copy.baseline);
                if (copy.hidSource) hid.Add(original);
            }
            Undo.CollapseUndoOperations(group);
            return true;
        }

        // A session whose copies are in the scene: left by an earlier editor run (a script reload, a restart), or brought
        // back by Undo (only: copies of this editor run's sessions that Undo took away, by instance id).
        internal static WorkSession Resume(VRCAvatarDescriptor avatar, ICollection<int> only = null)
        {
            var session = new WorkSession { Avatar = avatar, Cloned = true };
            session.Adopt(only);
            return session.Working.Count > 0 ? session : null;
        }

        // Takes the copies on its avatar that belong to it (see Own) into the work, for meshes it does not hold yet: Undo
        // or Redo brought back copies it had, or the work is found again after a reload. True when one was taken.
        internal bool Adopt(ICollection<int> only = null)
        {
            if (!Cloned || !Avatar) return false;
            bool any = false;
            foreach (var copy in Avatar.GetComponentsInChildren<AIExpressionWorkCopy>(true).Where(Own))
            {
                var working = copy.GetComponent<SkinnedMeshRenderer>();
                var source = copy.source;
                // A second copy of one mesh (the user duplicated it): the first is worked on, the other is left for the
                // clean-up, so edits and the saved clip do not depend on which one was found last. A source outside this
                // avatar, or one that is itself a copy, is not a face mesh of this avatar.
                if (!working || !source || source == working || !source.transform.IsChildOf(Avatar.transform) || source.GetComponent<AIExpressionWorkCopy>() ||
                    Working.ContainsKey(source) || (only != null && !only.Contains(working.GetInstanceID()))) continue;
                Working[source] = working;
                Remember(source, copy.baseline);
                if (copy.hidSource) hid.Add(source);
                Hide(source.gameObject);
                any = true;
            }
            return any;
        }

        // Meshes whose copy Undo took away (the step that made it, as when copies were added to a session found again)
        // leave the work; the rest goes on. Ending it all instead would delete the other copies and their edits, and the
        // new Undo step would drop what Redo could bring back. Returns those copies' ids, for Redo.
        internal List<int> Drop()
        {
            var gone = Cloned ? Working.Where(p => p.Key && !p.Value).ToList() : new List<KeyValuePair<SkinnedMeshRenderer, SkinnedMeshRenderer>>();
            foreach (var p in gone)
            {
                // Undo has normally shown the original again with the step it took back; Show then adds no record.
                if (hid.Contains(p.Key)) Show(p.Key.gameObject);
                Working.Remove(p.Key);
                meshes.Remove(p.Key);
                hid.Remove(p.Key);
                foreach (var key in baseline.Keys.Where(k => k.Item1 == p.Key).ToList()) baseline.Remove(key);
            }
            return gone.Where(p => !ReferenceEquals(p.Value, null)).Select(p => p.Value.GetInstanceID()).ToList();
        }

        // ---- which copies are the tool's own ------------------------------------------------------------------------

        // The ids of the copies this project made, kept in Library: that folder belongs to this project on this computer
        // and never travels with a prefab or a scene. A marker anyone can put in a prefab, so the marker alone never makes
        // the tool take, change or delete an object.
        private const string RecordFile = "Library/NXYUI.AIExpression.WorkCopies.txt";
        private static HashSet<string> record;

        private static HashSet<string> Record
        {
            get
            {
                if (record != null) return record;
                record = new HashSet<string>();
                try
                {
                    if (File.Exists(RecordFile)) record.UnionWith(File.ReadAllLines(RecordFile).Where(l => l.Length > 0));
                }
                catch (IOException e) { Debug.LogWarning("AI Expression: 작업본 기록을 읽지 못했어요. " + e.Message); }
                return record;
            }
        }

        private static string Issue()
        {
            string id = Guid.NewGuid().ToString("N");
            Record.Add(id);
            File.AppendAllText(RecordFile, id + "\n");
            return id;
        }

        // A copy this project made, still shaped as the window made it.
        internal static bool Own(AIExpressionWorkCopy copy) => copy && !string.IsNullOrEmpty(copy.id) && Record.Contains(copy.id) && Disposable(copy);

        // What the window makes: an object of its own inside an avatar with only the copied renderer and the marker, no
        // children. Anything else (an avatar root, an object with children or other components, a part of a prefab) is
        // never deleted because of a marker on it.
        private static bool Disposable(AIExpressionWorkCopy copy)
        {
            if (!copy) return false;
            var go = copy.gameObject;
            if (!go.transform.parent || go.transform.childCount > 0 || go.GetComponent<VRCAvatarDescriptor>()) return false;
            if (!go.transform.parent.GetComponentInParent<VRCAvatarDescriptor>(true)) return false;
            // A missing script reads as null: not something the window made either.
            if (go.GetComponents<Component>().Any(c => !(c is Transform || c is SkinnedMeshRenderer || c is AIExpressionWorkCopy))) return false;
            return !PrefabUtility.IsPartOfPrefabInstance(go) || PrefabUtility.IsAddedGameObjectOverride(go);
        }

        // Scene visibility is recorded for Undo. Asking for the state it already has is skipped: from the Undo callback
        // a new record would drop what could still be redone.
        private static void Hide(GameObject go)
        {
            if (!SceneVisibilityManager.instance.IsHidden(go, false)) SceneVisibilityManager.instance.Hide(go, false);
        }

        private static void Show(GameObject go)
        {
            if (SceneVisibilityManager.instance.IsHidden(go, false)) SceneVisibilityManager.instance.Show(go, false);
        }

        // start: the weights at the start of the work, kept on its copy; without them (no copies) the original's weights now.
        private void Remember(SkinnedMeshRenderer original, float[] start)
        {
            var mesh = original.sharedMesh;
            meshes[original] = mesh;
            // An original that lost its mesh: the session is not Valid then and ends at the next check.
            if (!mesh) return;
            // The original's weights can have changed during the work (the user, another tool): read again after a reload
            // they would move the default face, and the clip would hold keys the AI never touched.
            bool kept = start != null && start.Length == mesh.blendShapeCount;
            for (int i = 0; i < mesh.blendShapeCount; i++) baseline[(original, i)] = kept ? start[i] : original.GetBlendShapeWeight(i);
        }

        // A new object beside the original with a copy of its renderer (not its children), EditorOnly. A mesh on the avatar
        // root itself gets its copy below the root, so the copy stays inside the avatar.
        private static AIExpressionWorkCopy Copy(SkinnedMeshRenderer original, Transform avatar)
        {
            var go = new GameObject(CopyPrefix + original.name);
            Undo.RegisterCreatedObjectUndo(go, "AI Expression: start");
            if (original.transform == avatar) go.transform.SetParent(avatar, false);
            else
            {
                go.transform.SetParent(original.transform.parent, false);
                go.transform.localPosition = original.transform.localPosition;
                go.transform.localRotation = original.transform.localRotation;
                go.transform.localScale = original.transform.localScale;
            }
            go.tag = "EditorOnly";
            go.layer = original.gameObject.layer;
            var renderer = go.AddComponent<SkinnedMeshRenderer>();
            // As visible as the original, no more: a face that is off (an alternative face, an accessory that starts off)
            // must not appear in the scene or the picture because it is being worked on. CopySerialized has copied the
            // renderer's own switch.
            EditorUtility.CopySerialized(original, renderer);
            go.SetActive(original.gameObject.activeSelf);
            var marker = go.AddComponent<AIExpressionWorkCopy>();
            marker.source = original;
            marker.id = Issue();
            marker.hidSource = !SceneVisibilityManager.instance.IsHidden(original.gameObject, false);
            var mesh = original.sharedMesh;
            marker.baseline = mesh ? Enumerable.Range(0, mesh.blendShapeCount).Select(original.GetBlendShapeWeight).ToArray() : new float[0];
            Hide(original.gameObject);
            return marker;
        }

        internal float Baseline(FaceDictionary.Entry e) => baseline.TryGetValue((e.Renderer, e.Index), out float v) ? v : 0f;

        // Something to save: a shape that differs from the start, of the dictionary's when one is given (as the clip
        // takes them), else of any shape of the meshes worked on (a session found again has no dictionary yet).
        internal bool Differs(FaceDictionary dictionary) => dictionary != null
            ? dictionary.Entries.Any(e => Mathf.Abs(Get(e) - Baseline(e)) > 0.01f)
            : baseline.Any(p => Working.TryGetValue(p.Key.Item1, out var w) && w && w.sharedMesh && p.Key.Item2 < w.sharedMesh.blendShapeCount &&
                                Mathf.Abs(w.GetBlendShapeWeight(p.Key.Item2) - p.Value) > 0.01f);

        internal float Get(FaceDictionary.Entry e) =>
            Working.TryGetValue(e.Renderer, out var working) && working ? working.GetBlendShapeWeight(e.Index) : 0f;

        // Sets weights as one Undo step. resetOthers: every other dictionary shape goes back to the baseline first.
        internal int Apply(FaceDictionary dictionary, IEnumerable<(int Id, float Value)> changes, bool resetOthers, string action)
        {
            Undo.IncrementCurrentGroup();
            Undo.SetCurrentGroupName(action);
            int group = Undo.GetCurrentGroup();
            Undo.RecordObjects(Working.Values.Where(r => r).Cast<Object>().ToArray(), action);
            if (resetOthers)
                foreach (var e in dictionary.Entries) Set(e, Baseline(e));
            int applied = 0;
            foreach (var (id, value) in changes)
            {
                var e = dictionary.Find(id);
                if (e == null) continue;
                Set(e, Mathf.Clamp(value, 0f, 100f));
                applied++;
            }
            foreach (var r in Working.Values.Where(r => r)) EditorUtility.SetDirty(r);
            Undo.CollapseUndoOperations(group);
            return applied;
        }

        private void Set(FaceDictionary.Entry e, float value)
        {
            if (Working.TryGetValue(e.Renderer, out var working) && working) working.SetBlendShapeWeight(e.Index, value);
        }

        internal void Reset(FaceDictionary dictionary) =>
            Apply(dictionary, Enumerable.Empty<(int, float)>(), true, "AI Expression: reset");

        // The shapes that differ from the baseline now, as an expression clip on the original meshes' paths.
        internal string SaveClip(FaceDictionary dictionary, string name)
        {
            var changed = dictionary.Entries.Where(e => Mathf.Abs(Get(e) - Baseline(e)) > 0.01f).ToList();
            if (changed.Count == 0) throw new InvalidOperationException("기본 표정과 달라진 쉐이프키가 없어요. 표정을 먼저 만들어 주세요.");
            // A clip finds its mesh by the names on the path. With another object of the same name beside the mesh or one
            // of its parents, the animation moves whichever comes first, and two such meshes cannot be told apart.
            var ambiguous = changed.Select(e => e.Renderer).Distinct().FirstOrDefault(r => Ambiguous(r.transform, Avatar.transform));
            if (ambiguous)
                throw new InvalidOperationException($"‘{AnimationUtility.CalculateTransformPath(ambiguous.transform, Avatar.transform)}’ 옆에 이름이 같은 오브젝트가 있어서, " +
                                                    "클립이 어느 쪽을 움직일지 정해지지 않아요. 한쪽 이름을 바꾼 뒤 다시 저장해 주세요.");
            var clip = new AnimationClip { name = name };
            foreach (var e in changed)
            {
                string path = AnimationUtility.CalculateTransformPath(e.Renderer.transform, Avatar.transform);
                var binding = EditorCurveBinding.FloatCurve(path, typeof(SkinnedMeshRenderer), "blendShape." + e.Name);
                AnimationUtility.SetEditorCurve(clip, binding, AnimationCurve.Constant(0f, 1f / 60f, Get(e)));
            }
            string folder = Folder(Avatar.name);
            string file = AssetDatabase.GenerateUniqueAssetPath($"{folder}/{Safe(name)}.anim");
            AssetDatabase.CreateAsset(clip, file);
            // Only the clip: SaveAssets would write every unsaved asset of the project along with it.
            AssetDatabase.SaveAssetIfDirty(clip);
            return file;
        }

        private static bool Ambiguous(Transform t, Transform root)
        {
            for (; t && t != root && t.parent; t = t.parent)
                foreach (Transform sibling in t.parent)
                    if (sibling != t && sibling.name == t.name) return true;
            return false;
        }

        // Puts the expression on the originals, one Undo step; only meshes this session works on. Only the shapes that
        // differ from the start go over: a shape the AI left alone keeps what the original has now (the user may have
        // changed it meanwhile), as the clip leaves it out too.
        internal void ApplyToOriginals(FaceDictionary dictionary)
        {
            if (!Valid) throw new InvalidOperationException("작업 중에 메시가 바뀌었어요. 원본에 반영하지 않고 끝내 주세요.");
            Undo.IncrementCurrentGroup();
            Undo.SetCurrentGroupName("AI Expression: apply to the original");
            Undo.RecordObjects(Working.Keys.Cast<Object>().ToArray(), "AI Expression: apply to the original");
            foreach (var e in dictionary.Entries.Where(e => Working.TryGetValue(e.Renderer, out var w) && w && Mathf.Abs(Get(e) - Baseline(e)) > 0.01f))
                e.Renderer.SetBlendShapeWeight(e.Index, Get(e));
            foreach (var r in Working.Keys) EditorUtility.SetDirty(r);
        }

        // Ends the session: copies go, originals are shown again. One Undo step of its own, or (ownStep false) part of
        // the step the caller has opened, as when the weights go to the originals first.
        internal void End(bool ownStep = true)
        {
            // Only what this session hid is shown again: without copies nothing was, and an original the user had hidden
            // before the work stays hidden.
            var hidden = Cloned ? Working.Keys.Where(o => o && hid.Contains(o) && SceneVisibilityManager.instance.IsHidden(o.gameObject, false)).ToList() : new List<SkinnedMeshRenderer>();
            // A copy something was added to since (a child, a component) is not deleted; the window lists it to delete by hand.
            var copies = Cloned ? Working.Values.Where(c => c && Disposable(c.GetComponent<AIExpressionWorkCopy>())).ToList() : new List<SkinnedMeshRenderer>();
            // Nothing left to do after an Undo took the copies away: then no step is opened either.
            if (hidden.Count + copies.Count > 0)
            {
                if (ownStep)
                {
                    Undo.IncrementCurrentGroup();
                    Undo.SetCurrentGroupName("AI Expression: end");
                }
                int group = Undo.GetCurrentGroup();
                foreach (var original in hidden) Show(original.gameObject);
                foreach (var copy in copies) Undo.DestroyObjectImmediate(copy.gameObject);
                Undo.CollapseUndoOperations(group);
            }
            Working.Clear();
            if (Avatar) EditorSceneManager.MarkSceneDirty(Avatar.gameObject.scene);
        }

        // This project's working copies in the open scenes that no session holds.
        internal static List<AIExpressionWorkCopy> Leftovers(WorkSession current) =>
            Object.FindObjectsOfType<AIExpressionWorkCopy>(true).Where(Own)
                .Where(c => current == null || !current.Working.Values.Any(w => w && w.gameObject == c.gameObject)).ToList();

        // Markers in the open scenes the tool does not touch: not made in this project (a prefab or scene from elsewhere,
        // a copy made before 0.2.0), or changed since. The user can delete them by hand.
        internal static List<AIExpressionWorkCopy> Strangers() =>
            Object.FindObjectsOfType<AIExpressionWorkCopy>(true).Where(c => !Own(c)).ToList();

        // Removes copies no session holds, as one Undo step. current: the session going on, if any.
        internal static void CleanUp(IEnumerable<AIExpressionWorkCopy> copies, WorkSession current)
        {
            Undo.IncrementCurrentGroup();
            Undo.SetCurrentGroupName("AI Expression: clean up");
            int group = Undo.GetCurrentGroup();
            foreach (var copy in copies.Where(Own))
            {
                // The original stays hidden while the session works on another copy of it; shown, the two would overlap.
                // One the user had hidden before the copy was made stays hidden.
                if (copy.source && copy.hidSource && (current == null || !current.Working.ContainsKey(copy.source))) Show(copy.source.gameObject);
                Undo.DestroyObjectImmediate(copy.gameObject);
            }
            Undo.CollapseUndoOperations(group);
        }

        internal static string Folder(string avatar)
        {
            string folder = "Assets/NXYUI/AI Expression/" + Safe(avatar);
            string at = "Assets";
            foreach (var part in folder.Split('/').Skip(1))
            {
                if (!AssetDatabase.IsValidFolder(at + "/" + part)) AssetDatabase.CreateFolder(at, part);
                at += "/" + part;
            }
            return folder;
        }

        private const int NameLimit = 64;
        // Names Windows keeps for devices, with or without an extension, and the folder name Unity skips.
        private static readonly HashSet<string> Reserved = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        {
            "CON", "PRN", "AUX", "NUL", "COM1", "COM2", "COM3", "COM4", "COM5", "COM6", "COM7", "COM8", "COM9",
            "LPT1", "LPT2", "LPT3", "LPT4", "LPT5", "LPT6", "LPT7", "LPT8", "LPT9", "cvs",
        };

        // A file or folder name that both Unity and Windows take, from a name the user, the avatar or the AI gave: no
        // path characters; no dot in front and no "~" at the end (Unity does not import those); no dot or space at the
        // end and no device name (Windows drops or refuses those); not too long for a path.
        internal static string Safe(string name)
        {
            var invalid = Path.GetInvalidFileNameChars();
            string safe = string.Concat((name ?? "").Select(ch => char.IsControl(ch) || "<>:\"/\\|?*".IndexOf(ch) >= 0 || invalid.Contains(ch) ? '_' : ch));
            safe = safe.TrimStart('.', ' ').TrimEnd('.', ' ', '~');
            if (safe.Length > NameLimit)
                safe = safe.Substring(0, char.IsHighSurrogate(safe[NameLimit - 1]) ? NameLimit - 1 : NameLimit).TrimEnd('.', ' ', '~');
            if (Reserved.Contains(safe.Split('.')[0].TrimEnd())) safe = "_" + safe;
            return string.IsNullOrEmpty(safe) ? "Expression" : safe;
        }
    }
}
#endif
