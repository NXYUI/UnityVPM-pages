#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;

namespace NXYUI.AIExpression
{
    // The marker the window puts on a face mesh's working copy. Someone who finds the object in the Hierarchy learns what
    // it is and how the tool is used, and gets to the window; the fields follow as before.
    [CustomEditor(typeof(AIExpressionWorkCopy))]
    internal sealed class AIExpressionWorkCopyEditor : Editor
    {
        public override void OnInspectorGUI()
        {
            // One short line; the rest is in the tooltip and the guide (a narrow inspector showed five lines before the usage).
            EditorGUILayout.LabelField(new GUIContent("AI 표정 창이 고치는 얼굴 메시의 작업본이에요. 업로드되지 않고, 창에서 작업을 끝내면 지워져요.",
                "작업하는 동안 원본 메시는 바꾸지 않고 Scene 뷰에서만 숨겨 둬요. 이 오브젝트는 EditorOnly라 업로드에 들어가지 않아요. " +
                "창은 이 프로젝트에서 자기가 만든 작업본만 지우니, 다른 데서 온 것은 직접 지우세요."), EditorStyles.wordWrappedMiniLabel);
            EditorGUILayout.Space(4);
            AIExpressionUsage.Draw(AIExpressionUsage.InspectorKey, Repaint);
            if (GUILayout.Button("AI 표정 창 열기"))
            {
                AIExpressionWindow.Open();
                GUIUtility.ExitGUI();
            }
            EditorGUILayout.Space(8);
            DrawDefaultInspector();
        }
    }
}
#endif
