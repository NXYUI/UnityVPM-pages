#if UNITY_EDITOR
using System;
using UnityEditor;
using UnityEngine;

namespace NXYUI.AIExpression
{
    // How the tool is used, in one place: the window and the work copy's inspector draw these steps, README_KO.txt lists
    // them word for word (a test checks that) and the public guide walks through them with the details.
    internal static class AIExpressionUsage
    {
        internal static readonly string[] Steps =
        {
            "상단 메뉴 NXYUI › AI Expression을 열고, 맨 위 ‘아바타’ 칸에 씬의 아바타를 넣어요. Hierarchy에서 아바타를 고르면 자동으로 들어가요.",
            "왼쪽 ‘얼굴 사전’에서 ‘사전 만들기’를 누르면 얼굴 쉐이프키가 무엇을 움직이는지 읽어 둬요. 누르지 않아도 처음 요청할 때 자동으로 만들어요.",
            "‘작업본에서 작업 (권장)’이 켜져 있으면 Claude가 처음 고칠 때 얼굴 메시의 작업본(EditorOnly 복사본)이 생기고, 원본은 Scene 뷰에서만 숨겨져요.",
            "Claude API로 할 때: 오른쪽 ‘Claude API’ 탭에서 ‘API 키’를 넣고 ‘저장’한 뒤, ‘어떤 표정을 원하세요?’ 칸에 표정을 적고 ‘보내기’를 눌러요.",
            "Claude Code로 할 때: ‘MCP (Claude Code)’ 탭에서 ‘MCP 서버 켜기’를 켜고, 그 탭의 1~3번대로 ‘추가 명령 복사’한 명령을 실행하고 Claude Code를 새로 시작한 뒤 표정을 말로 부탁해요.",
            "마음에 들면 왼쪽 ‘표정 클립으로 저장’에 이름을 넣고 ‘저장’을 눌러요. Assets/NXYUI/AI Expression/<아바타>/에 클립이 생겨요. FX나 Gesture 레이어에 넣어 쓰세요.",
            "다 되면 ‘버리고 끝내기’를 눌러요. 작업본이 지워지고 원본 얼굴은 그대로예요(저장한 클립은 남아요). 지금 표정을 아바타의 기본 얼굴로 쓸 때만 ‘원본에 반영하고 끝내기’를 눌러요. 작업본 없이 했다면 ‘끝내기’예요.",
        };

        internal const string Url = "https://github.com/NXYUI/UnityVPM-pages/blob/main/packages/dev.nxyui.ai-expression/README.md";

        // Closed until the user opens it (only its one line shows), then as they left it, per surface; EditorPrefs because
        // it is the user's own taste, not the project's.
        internal const string InspectorKey = "NXYUI.AIExpression.Usage.Inspector", WindowKey = "NXYUI.AIExpression.Usage.Window";

        // The foldout and, open, the numbered steps with the way to the full guide. The same in every pass and every state
        // of the tool; opening or closing ends the pass so Layout and Repaint see the same controls. repaint: the surface's own.
        internal static void Draw(string key, Action repaint) => Show(key, repaint, 0f);

        // In a window: the open list takes at most `room` and scrolls in its frame past that, so the columns below keep
        // the height they need at the window's minimum size.
        internal static void DrawInWindow(string key, Action repaint, float room) => Show(key, repaint, room);

        private static Vector2 scroll;

        // How tall the steps are at the width they get (the view's, less the frame and a scroll bar). The same in the
        // Layout and the Repaint pass of a frame.
        private static float StepsHeight()
        {
            float width = Mathf.Max(120f, EditorGUIUtility.currentViewWidth - 40f), height = 0f;
            for (int i = 0; i < Steps.Length; i++)
                height += EditorStyles.wordWrappedLabel.CalcHeight(new GUIContent($"{i + 1}. {Steps[i]}"), width) + 2f;
            return height;
        }

        private static void Show(string key, Action repaint, float room)
        {
            bool open = EditorPrefs.GetBool(key, false);
            bool next = EditorGUILayout.Foldout(open, "사용 방법", true);
            if (next != open)
            {
                EditorPrefs.SetBool(key, next);
                repaint?.Invoke();
                GUIUtility.ExitGUI();
            }
            if (!open) return;
            using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
            {
                // Taller than the room it may take (a low window): the steps scroll inside the frame.
                bool scrolls = room > 0f && StepsHeight() > room;
                if (scrolls) scroll = EditorGUILayout.BeginScrollView(scroll, GUILayout.Height(room));
                for (int i = 0; i < Steps.Length; i++)
                    EditorGUILayout.LabelField($"{i + 1}. {Steps[i]}", EditorStyles.wordWrappedLabel);
                if (scrolls) EditorGUILayout.EndScrollView();
                using (new EditorGUILayout.HorizontalScope())
                {
                    if (GUILayout.Button(new GUIContent("자세한 설명 열기", Url), EditorStyles.miniButton, GUILayout.ExpandWidth(false)))
                        Application.OpenURL(Url);
                    GUILayout.Label("패키지 폴더의 README_KO.txt에도 있어요.", EditorStyles.miniLabel);
                }
            }
        }
    }
}
#endif
