using nadena.dev.ndmf;
using UnityEngine;

namespace NXYUI.AIExpression
{
    // Marks a working copy of a face mesh made by the AI Expression window. The copy is EditorOnly and never uploads; the
    // window finds copies left behind (an editor restart) and puts their originals back.
    [DisallowMultipleComponent]
    [AddComponentMenu("NXYUI/AI Expression Work Copy")]
    public sealed class AIExpressionWorkCopy : MonoBehaviour, INDMFEditorOnly
    {
        public SkinnedMeshRenderer source;
        // Given by the window when it makes the copy and kept by the project (in Library), so a marker that came in a
        // prefab or a scene from somewhere else is never taken for one of its copies.
        [HideInInspector] public string id;
        // The window hid the source for this copy; a source the user had hidden already stays hidden when the work ends.
        [HideInInspector] public bool hidSource;
        // The source's weights when the work started: reset and the saved clip are measured from them, also after a reload.
        [HideInInspector] public float[] baseline;
    }
}
